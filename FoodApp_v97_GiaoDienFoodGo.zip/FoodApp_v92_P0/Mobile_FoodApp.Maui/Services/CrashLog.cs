namespace FoodApp.Maui.Services;

/// <summary>Ghi lỗi khởi động ra file để biết nguyên nhân thật của mã thoát 0xc000027b.
/// File: %LOCALAPPDATA%\FoodApp_crash.log (Windows)</summary>
public static class CrashLog
{
    public static string DuongDan => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FoodApp_crash.log");

    public static void Ghi(string nguon, object? loi)
    {
        try { File.AppendAllText(DuongDan, $"[{DateTime.Now:HH:mm:ss}] {nguon}\n{loi}\n\n"); } catch { }
    }

    public static void DangKyBatLoiToanCuc()
    {
        AppDomain.CurrentDomain.UnhandledException += (_, e) => Ghi("AppDomain.UnhandledException", e.ExceptionObject);
        TaskScheduler.UnobservedTaskException += (_, e) => { Ghi("UnobservedTaskException", e.Exception); e.SetObserved(); };
    }

    /// <summary>Chạy một bước khởi động; lỗi được ghi lại và bỏ qua thay vì làm sập app.</summary>
    public static void Thu(string ten, Action a)
    {
        try { a(); } catch (Exception ex) { Ghi("Khởi động: " + ten, ex); }
    }
}
