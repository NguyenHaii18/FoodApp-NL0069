using FoodApp.Maui.Views;
using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

public enum KyBaoCao { Ngay, Thang, Nam }

public sealed class TaiXeQuanDto
{
    public int Id { get; set; }
    public string HoTen { get; set; } = "";
    public string Sdt { get; set; } = "";
    public string? PhuongTien { get; set; }
    public string? BienSo { get; set; }
    public bool HoatDong { get; set; }
    public bool DangGiao { get; set; }
}

public sealed class TaiXeQuanDs
{
    public string CheDoGiao { get; set; } = "Ngoai";
    public List<TaiXeQuanDto> TaiXe { get; set; } = new();
}

/// <summary>
/// Nghiệp vụ dùng chung của phía đối tác (gian hàng): xử lý đơn, thông báo, đánh giá, đối soát tài chính, kỳ báo cáo.
/// Dữ liệu hiện lưu cục bộ (MockData + VendorLocalStore); khi có API thật thì thay phần ghi bằng DuLieuService.GhiAsync.
/// </summary>
public static class DoiTacService
{
    /// <summary>Mức chiết khấu mặc định của nền tảng (báo cáo NV09: tỉ lệ % thỏa thuận lúc đăng ký). Mỗi gian hàng có thể có mức riêng (GianHang.TyLeChietKhau).</summary>
    public const decimal TyLeChietKhauMacDinh = 0.15m;

    public static string TaoId(string tienTo) => tienTo + DateTime.Now.Ticks;

    public static IEnumerable<DonHang> DonCuaGianHang(string gianHangId) =>
        MockData.DonHangCuaGianHang.Where(d => d.GianHangId == gianHangId);

    // ====================== THÔNG BÁO ======================

    public static void GuiThongBao(string gianHangId, string loai, string tieuDe, string noiDung, string donHangId = "")
    {
        if (string.IsNullOrEmpty(gianHangId)) return;
        MockData.DanhSachThongBao.Insert(0, new ThongBaoGianHang
        {
            Id = TaoId("tb"), GianHangId = gianHangId, Loai = loai, TieuDe = tieuDe, NoiDung = noiDung,
            DonHangId = donHangId, Ngay = DateTime.Now, DaDoc = false
        });
        while (MockData.DanhSachThongBao.Count > 300) MockData.DanhSachThongBao.RemoveAt(MockData.DanhSachThongBao.Count - 1);
    }

    /// <summary>Online: lấy thông báo thật từ SQL Server (đơn mới, đơn hủy, đánh giá mới), giữ trạng thái "đã đọc" đã có trên máy.</summary>
    public static async Task TaiThongBaoTuMayChuAsync(string gianHangId)
    {
        if (!DuLieuService.DangOnline) return;
        var r = await ApiClient.GetAsync<List<ThongBaoGianHang>>($"api/mobile/gian-hang/{gianHangId}/thong-bao");
        if (!r.ThanhCong || r.DuLieu is null) return;
        var daDoc = MockData.DanhSachThongBao.Where(t => t.GianHangId == gianHangId && t.DaDoc).Select(t => t.Loai + "|" + t.DonHangId).ToHashSet();
        foreach (var cu in MockData.DanhSachThongBao.Where(t => t.GianHangId == gianHangId).ToList()) MockData.DanhSachThongBao.Remove(cu);
        foreach (var t in r.DuLieu)
        {
            t.GianHangId = gianHangId;
            if (string.IsNullOrEmpty(t.Id)) t.Id = $"{t.Loai}-{t.DonHangId}-{t.Ngay.Ticks}";
            t.DaDoc = daDoc.Contains(t.Loai + "|" + t.DonHangId);
            MockData.DanhSachThongBao.Add(t);
        }
        VendorLocalStore.Luu();
    }

    public static List<ThongBaoGianHang> ThongBaoCua(string gianHangId) =>
        MockData.DanhSachThongBao.Where(t => t.GianHangId == gianHangId).OrderByDescending(t => t.Ngay).ToList();

    public static int SoThongBaoChuaDoc(string gianHangId) =>
        MockData.DanhSachThongBao.Count(t => t.GianHangId == gianHangId && !t.DaDoc);

    public static void DanhDauDaDocTatCa(string gianHangId)
    {
        foreach (var t in MockData.DanhSachThongBao.Where(t => t.GianHangId == gianHangId && !t.DaDoc)) t.DaDoc = true;
        VendorLocalStore.Luu();
    }

    // ====================== XỬ LÝ ĐƠN ======================

    public static readonly string[] LyDoTuChoiMau =
    {
        "Hết nguyên liệu / hết món",
        "Quán sắp đóng cửa",
        "Quá tải, không kịp chuẩn bị",
        "Ngoài khu vực phục vụ",
    };

    /// <summary>Xác nhận đơn: server xác nhận trước, thành công mới đổi trạng thái trên máy. Trả false nếu không ghi được.</summary>
    /// <summary>Quán chọn thời gian chuẩn bị dự kiến khi xác nhận đơn. null = quán bấm Hủy.</summary>
    public static async Task<int?> ChonThoiGianChuanBiAsync(DonHang? don = null)
    {
        var trang = Application.Current?.MainPage;
        if (trang is null) return 15;
        var goiY = don is null ? null : VanHanhService.GoiYThoiGianChuanBi(don);
        var chon = new List<string>();
        if (goiY is int g) chon.Add($"{g} phút (theo món)");
        chon.AddRange(new[] { "10 phút", "15 phút", "20 phút", "30 phút", "45 phút", "60 phút" }.Where(x => x != $"{goiY} phút"));
        var kq = await trang.DisplayActionSheet("Thời gian chuẩn bị dự kiến", "Hủy", null, chon.ToArray());
        return int.TryParse(kq?.Split(' ')[0], out var phut) ? phut : null;
    }

    public static async Task<bool> XacNhanDonAsync(DonHang don, int? chuanBiPhut = null)
    {
        if (!await DuLieuService.GhiAsync("PUT", $"api/mobile/don-hang/{don.Id}/xac-nhan", new { chuanBiPhut })) return false;
        don.ThoiGianChuanBiPhut = chuanBiPhut;
        don.TrangThai = TrangThaiDonHang.DangLam;
        don.XacNhanLuc = DateTime.Now;
        TruTonKho(don);
        DonHangService.DongBo(don);   // đồng bộ sang các bản của khách / tài xế (đồng thời lưu)
        return true;
    }

    /// <summary>Trừ tồn kho theo số lượng trong đơn vừa xác nhận; món về 0 phần thì tự chuyển "Hết hàng" (ẩn khỏi thực đơn khách).</summary>
    private static void TruTonKho(DonHang don)
    {
        foreach (var ct in don.ChiTiet)
        {
            var mon = MockData.DanhSachMonAn.FirstOrDefault(m => m.Id == ct.MonAn.Id);
            if (mon?.TonKho is null) continue;
            mon.TonKho = Math.Max(0, mon.TonKho.Value - ct.SoLuong);
            if (mon.TonKho == 0) mon.ConHang = false;
        }
        VendorLocalStore.Luu();
    }

    /// <summary>Từ chối đơn: bắt buộc chọn/nhập lý do (NV04). Trả về true nếu đơn đã được từ chối.</summary>
    public static async Task<bool> TuChoiDonAsync(Page trang, DonHang don)
    {
        const string khac = "Lý do khác…";
        var chon = await trang.DisplayActionSheet($"Lý do từ chối đơn #{don.Id}", "Để sau", null,
            LyDoTuChoiMau.Append(khac).ToArray());
        if (string.IsNullOrEmpty(chon) || chon == "Để sau") return false;

        var lyDo = chon;
        if (chon == khac)
        {
            lyDo = await trang.NhapAsync("Lý do từ chối", "Nhập lý do (bắt buộc, khách hàng sẽ nhìn thấy)",
                "Từ chối", "Hủy", maxLength: 200) ?? "";
            if (string.IsNullOrWhiteSpace(lyDo)) return false;
        }

        if (!await DuLieuService.GhiAsync("PUT", $"api/mobile/don-hang/{don.Id}/tu-choi", new { lyDo = lyDo.Trim() })) return false;
        don.TrangThai = TrangThaiDonHang.DaHuy;
        don.DaHoanTien = true;                       // hoàn tiền tự động theo quy định
        don.LyDoTuChoi = lyDo.Trim();
        DonHangService.DongBo(don);
        return true;
    }

    /// <summary>Hủy đơn đã nhận (trước lúc tài xế lấy hàng): chọn/nhập lý do bắt buộc, server kiểm tra quy tắc và tạo yêu cầu hoàn tiền nếu đã thanh toán online.</summary>
    public static async Task<bool> HuyDonDangLamAsync(Page trang, DonHang don)
    {
        const string khac = "Lý do khác…";
        var mau = new[] { "Hết nguyên liệu / món", "Sự cố bếp, không kịp chuẩn bị", "Không liên lạc được với khách", "Địa chỉ giao không hợp lệ / ngoài vùng", "Khách yêu cầu hủy" };
        var chon = await trang.DisplayActionSheet($"Lý do hủy đơn #{don.Id}", "Để sau", null, mau.Append(khac).ToArray());
        if (string.IsNullOrEmpty(chon) || chon == "Để sau") return false;
        var lyDo = chon;
        if (chon == khac)
        {
            lyDo = await trang.NhapAsync("Lý do hủy", "Nhập lý do (bắt buộc, khách hàng sẽ nhìn thấy)", "Hủy đơn", "Đóng", maxLength: 200) ?? "";
            if (string.IsNullOrWhiteSpace(lyDo)) return false;
        }
        if (!await trang.DisplayAlert("Xác nhận hủy đơn", $"Hủy đơn #{don.Id}? Thao tác không hoàn tác được.", "Hủy đơn", "Giữ đơn")) return false;
        if (!await DuLieuService.GhiAsync("PUT", $"api/mobile/don-hang/{don.Id}/tu-choi", new { lyDo = lyDo.Trim() })) return false;
        don.TrangThai = TrangThaiDonHang.DaHuy;
        don.DaHoanTien = true;
        don.LyDoTuChoi = lyDo.Trim();
        DonHangService.DongBo(don);
        return true;
    }

    /// <summary>
    /// Món đã chuẩn bị xong: bàn giao cho tài xế. Đơn vẫn là "Đang chuẩn bị" (SanSangGiao = true) cho tới khi TÀI XẾ
    /// nhận và lấy hàng; dùng chính đối tượng đơn để thông tin khách, thanh toán, tuyến đường đi theo sang tài xế.
    /// </summary>
    public static async Task<bool> BanGiaoTaiXeAsync(DonHang don)
    {
        // Online: server lưu TrangThaiChuanBi = SanSangGiao (tài xế/khách thấy), lỗi thì không đổi cục bộ.
        if (!await DuLieuService.GhiAsync("PUT", $"api/mobile/don-hang/{don.Id}/san-sang-giao")) return false;
        don.SanSangGiao = true;
        don.TrangThaiChuanBi = "SanSangGiao";
        don.SanSangGiaoLuc = DateTime.Now;
        if (!MockData.DonHangChoTaiXe.Contains(don) && MockData.DonHangDaGiaoCuaTaiXe.All(d => d.Id != don.Id))
            MockData.DonHangChoTaiXe.Add(don);
        DonHangService.DongBo(don);
        return true;
    }

    // ---- v31: người giao = tài xế của quán | shipper ngoài (API TaiXeQuanApiController) ----
    public static async Task<TaiXeQuanDs?> TaiTaiXeQuanAsync()
    {
        var r = await ApiClient.GetAsync<TaiXeQuanDs>("api/mobile/gian-hang/tai-xe");
        if (!r.ThanhCong && Application.Current?.MainPage is { } p) await p.DisplayAlert("Không tải được", r.ThongDiep, "OK");
        return r.ThanhCong ? r.DuLieu : null;
    }

    /// <summary>Chọn người giao cho đơn: nguon = "Quan" (kèm maTaiXe) | "Ngoai". PUT api/mobile/don-hang/{id}/nguoi-giao.</summary>
    public static async Task<bool> ChonNguoiGiaoAsync(DonHang don, string nguon, int? maTaiXe)
    {
        var kq = await ApiClient.PutAsync<object>($"api/mobile/don-hang/{don.Id}/nguoi-giao", new { nguon, maTaiXe });
        if (Application.Current?.MainPage is { } p)
            await p.DisplayAlert(kq.ThanhCong ? "Đã chọn người giao" : "Không chọn được", kq.ThanhCong ? (nguon == "Quan" ? "Đơn đã giao cho tài xế của quán." : "Đơn chuyển cho shipper ngoài.") : kq.ThongDiep, "OK");
        return kq.ThanhCong;
    }

    public static async Task<bool> DatCheDoGiaoAsync(string che)
    {
        var kq = await ApiClient.PutAsync<object>("api/mobile/gian-hang/che-do-giao", new { che });
        if (Application.Current?.MainPage is { } p)
            await p.DisplayAlert(kq.ThanhCong ? "Đã lưu" : "Không lưu được", kq.ThanhCong ? "Đã đổi cách giao mặc định cho đơn mới." : kq.ThongDiep, "OK");
        return kq.ThanhCong;
    }

    public static async Task<bool> ThemTaiXeQuanAsync(string tenDangNhap, string matKhau, string hoTen, string sdt)
    {
        var kq = await ApiClient.PostAsync<object>("api/mobile/gian-hang/tai-xe", new { tenDangNhap, matKhau, hoTen, sdt });
        if (Application.Current?.MainPage is { } p)
            await p.DisplayAlert(kq.ThanhCong ? "Đã thêm tài xế" : "Không thêm được", kq.ThanhCong ? $"Tài xế {hoTen} đăng nhập app tài xế bằng \"{tenDangNhap}\"." : kq.ThongDiep, "OK");
        return kq.ThanhCong;
    }

    public static async Task<bool> DatHoatDongTaiXeQuanAsync(int id, bool hoatDong)
    {
        var kq = await ApiClient.PutAsync<object>($"api/mobile/gian-hang/tai-xe/{id}/hoat-dong", new { hoatDong });
        if (Application.Current?.MainPage is { } p)
            await p.DisplayAlert(kq.ThanhCong ? "Đã cập nhật" : "Không cập nhật được", kq.ThanhCong ? (hoatDong ? "Đã mở khóa tài xế." : "Đã khóa tài xế.") : kq.ThongDiep, "OK");
        return kq.ThanhCong;
    }

    /// <summary>Quán báo "đang chuẩn bị món" (khách được thông báo). PUT api/mobile/don-hang/{id}/bat-dau-chuan-bi.</summary>
    public static async Task<bool> BatDauChuanBiAsync(DonHang don)
    {
        if (!await DuLieuService.GhiAsync("PUT", $"api/mobile/don-hang/{don.Id}/bat-dau-chuan-bi")) return false;
        don.TrangThaiChuanBi = "DangChuanBi";
        DonHangService.DongBo(don);
        return true;
    }

    /// <summary>Quán xác nhận đã trao món cho tài xế (cần tài xế đã nhận đơn). PUT api/mobile/don-hang/{id}/ban-giao.</summary>
    public static async Task<bool> XacNhanBanGiaoAsync(DonHang don)
    {
        if (!await DuLieuService.GhiAsync("PUT", $"api/mobile/don-hang/{don.Id}/ban-giao")) return false;
        don.TrangThaiChuanBi = "SanSangGiao";
        don.SanSangGiao = true;
        don.QuanBanGiaoLuc = DateTime.Now;
        DonHangService.DongBo(don);
        return true;
    }

    /// <summary>
    /// Quy định NV04: quá 5 phút gian hàng không phản hồi thì tự hủy đơn và hoàn tiền cho khách.
    /// Gọi mỗi khi mở/làm mới màn hình đơn hàng. Trả về số đơn đã tự hủy.
    /// </summary>
    public static int HuyDonQuaHan(string gianHangId)
    {
        var quaHan = DonCuaGianHang(gianHangId).Where(d => d.QuaHanPhanHoi).ToList();
        foreach (var d in quaHan)
        {
            d.TrangThai = TrangThaiDonHang.DaHuy;
            d.DaHoanTien = true;
            d.LyDoTuChoi = $"Gian hàng không phản hồi trong {DonHang.PhutPhanHoiToiDa} phút — hệ thống tự hủy";
            GuiThongBao(gianHangId, ThongBaoGianHang.HuyDon, "Đơn bị tự hủy do quá hạn",
                $"Đơn #{d.Id} đã bị hủy vì chưa được phản hồi trong {DonHang.PhutPhanHoiToiDa} phút.", d.Id);
            DonHangService.DongBo(d);
        }
        if (quaHan.Count > 0) VendorLocalStore.Luu();
        return quaHan.Count;
    }

    // ====================== ĐÁNH GIÁ ======================

    private sealed class DanhGiaServerDto
    {
        public int Id { get; set; } public int DonHangId { get; set; } public string? KhachTen { get; set; }
        public int SoSao { get; set; } public int? SoSaoGiaoHang { get; set; } public string? TheNhanXet { get; set; }
        public string? AnhDanhGia { get; set; } public string? NoiDung { get; set; } public DateTime Ngay { get; set; }
        public string? PhanHoi { get; set; } public DateTime? NgayPhanHoi { get; set; }
    }

    /// <summary>Đánh giá của quán lấy từ máy chủ (kèm ảnh khách đính kèm). null = không lấy được → dùng bản lưu trên máy.</summary>
    public static async Task<List<DanhGiaGianHang>?> DanhGiaTuMayChuAsync(string gianHangId)
    {
        if (!DuLieuService.DangOnline || !int.TryParse(gianHangId, out var ma)) return null;
        var r = await ApiClient.GetAsync<List<DanhGiaServerDto>>($"api/mobile/gian-hang/{ma}/danh-gia");
        if (!r.ThanhCong || r.DuLieu is null) return null;
        return r.DuLieu.Select(d => new DanhGiaGianHang
        {
            Id = d.Id.ToString(), GianHangId = gianHangId, DonHangId = d.DonHangId.ToString(), KhachTen = d.KhachTen ?? "Khách hàng",
            SoSaoMonAn = d.SoSao, SoSaoGiaoHang = d.SoSaoGiaoHang ?? 0,
            The = (d.TheNhanXet ?? "").Split('|', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList(),
            NoiDung = d.NoiDung ?? "", Ngay = d.Ngay, PhanHoi = d.PhanHoi ?? "", PhanHoiLuc = d.NgayPhanHoi,
            Anh = (d.AnhDanhGia ?? "").Split('|', StringSplitOptions.RemoveEmptyEntries).ToList(), TuMayChu = true,
        }).ToList();
    }

    /// <summary>Gửi phản hồi của quán lên máy chủ (đánh giá lấy từ máy chủ). Trả về thông báo lỗi, null nếu thành công.</summary>
    public static async Task<string?> PhanHoiMayChuAsync(DanhGiaGianHang dg, string noiDung)
    {
        if (!int.TryParse(dg.GianHangId, out var gh) || !int.TryParse(dg.Id, out var id)) return "Mã đánh giá không hợp lệ.";
        var r = await ApiClient.PutAsync<object>($"api/mobile/gian-hang/{gh}/danh-gia/{id}/phan-hoi", new { noiDung });
        return r.ThanhCong ? null : r.ThongDiep;
    }

    public static List<DanhGiaGianHang> DanhGiaCua(string gianHangId) =>
        MockData.DanhSachDanhGia.Where(d => d.GianHangId == gianHangId).OrderByDescending(d => d.Ngay).ToList();

    /// <summary>Lưu đánh giá của khách (gọi từ ReviewPage), cập nhật điểm trung bình của quán và báo cho quán.</summary>
    public static void GhiDanhGia(DonHang don, int saoMon, int saoGiao, IEnumerable<string> the, string noiDung, IEnumerable<string>? anh = null)
    {
        var dg = MockData.DanhSachDanhGia.FirstOrDefault(d => d.DonHangId == don.Id);
        var laMoi = dg is null;
        if (dg is null)
        {
            dg = new DanhGiaGianHang { Id = TaoId("dg"), GianHangId = don.GianHangId, DonHangId = don.Id };
            MockData.DanhSachDanhGia.Insert(0, dg);
        }
        dg.KhachTen = string.IsNullOrWhiteSpace(don.KhachTen) ? (Phien.Khach?.HoTen ?? "Khách hàng") : don.KhachTen;
        dg.SoSaoMonAn = saoMon;
        dg.SoSaoGiaoHang = saoGiao;
        dg.The = the.ToList();
        dg.NoiDung = noiDung?.Trim() ?? "";
        dg.Anh = anh?.ToList() ?? new();
        dg.Ngay = DateTime.Now;

        CapNhatDiemTrungBinh(don.GianHangId);
        if (laMoi)
            GuiThongBao(don.GianHangId, ThongBaoGianHang.DanhGiaMoi, $"Đánh giá mới {saoMon}★",
                $"{dg.KhachTen} đánh giá đơn #{don.Id}" + (dg.CoNoiDung ? $": “{dg.NoiDung}”" : "."), don.Id);
        VendorLocalStore.Luu();
    }

    public static void CapNhatDiemTrungBinh(string gianHangId)
    {
        var ds = MockData.DanhSachDanhGia.Where(d => d.GianHangId == gianHangId && d.SoSaoMonAn > 0).ToList();
        var gh = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == gianHangId);
        if (gh is not null && ds.Count > 0) gh.DanhGia = Math.Round(ds.Average(d => d.SoSaoMonAn), 1);
    }

    // ====================== KỲ BÁO CÁO & TÀI CHÍNH ======================

    /// <summary>Khoảng thời gian [Tu, Den) của kỳ chứa mốc <paramref name="moc"/>.</summary>
    public static (DateTime Tu, DateTime Den) Khoang(KyBaoCao ky, DateTime moc) => ky switch
    {
        KyBaoCao.Ngay => (moc.Date, moc.Date.AddDays(1)),
        KyBaoCao.Thang => (new DateTime(moc.Year, moc.Month, 1), new DateTime(moc.Year, moc.Month, 1).AddMonths(1)),
        _ => (new DateTime(moc.Year, 1, 1), new DateTime(moc.Year, 1, 1).AddYears(1)),
    };

    public static string NhanKy(KyBaoCao ky, DateTime moc) => ky switch
    {
        KyBaoCao.Ngay => moc.Date == DateTime.Today ? "Hôm nay" : moc.ToString("dd/MM/yyyy"),
        KyBaoCao.Thang => moc.ToString("'Tháng' MM/yyyy"),
        _ => $"Năm {moc.Year}",
    };

    public static DateTime LuiKy(KyBaoCao ky, DateTime moc, int soKy) => ky switch
    {
        KyBaoCao.Ngay => moc.AddDays(soKy),
        KyBaoCao.Thang => moc.AddMonths(soKy),
        _ => moc.AddYears(soKy),
    };

    public static List<DonHang> TrongKy(IEnumerable<DonHang> ds, KyBaoCao ky, DateTime moc)
    {
        var (tu, den) = Khoang(ky, moc);
        return ds.Where(d => d.NgayDat >= tu && d.NgayDat < den).ToList();
    }

    public static decimal TyLeChietKhau(GianHang gh) => gh.TyLeChietKhau ?? TyLeChietKhauMacDinh;

    /// <summary>Phần giảm giá do chính quán tài trợ (mã quán tự tạo). Mã toàn hệ thống do nền tảng chịu nên không trừ vào quán.</summary>
    public static decimal GiamGiaQuanChiu(DonHang d, string gianHangId)
    {
        if (d.GiamGia <= 0 || string.IsNullOrWhiteSpace(d.MaKhuyenMai)) return 0;
        var km = MockData.DanhSachKhuyenMai.FirstOrDefault(k => string.Equals(k.MaCode, d.MaKhuyenMai, StringComparison.OrdinalIgnoreCase));
        return km is not null && !km.ApDungToanHeThong && km.GianHangId == gianHangId ? d.GiamGia : 0;
    }

    /// <summary>
    /// Đối soát các đơn HOÀN THÀNH: phí nền tảng = tỉ lệ chiết khấu × (tiền món − giảm giá quán tài trợ);
    /// thực nhận = tiền món − giảm giá quán tài trợ − phí nền tảng; lợi nhuận = thực nhận − giá vốn món.
    /// Phí giao hàng đi thẳng cho tài xế nên không nằm trong doanh thu của quán.
    /// </summary>
    public static KetQuaTaiChinh TinhTaiChinh(GianHang gh, IEnumerable<DonHang> donHoanThanh)
    {
        var kq = new KetQuaTaiChinh();
        var tyLe = TyLeChietKhau(gh);
        foreach (var d in donHoanThanh.Where(x => x.TrangThai == TrangThaiDonHang.HoanThanh).OrderByDescending(x => x.NgayDat))
        {
            var mon = d.TongTien;
            var giam = Math.Min(GiamGiaQuanChiu(d, gh.Id), mon);
            var phi = Math.Round((mon - giam) * tyLe, 0, MidpointRounding.AwayFromZero);

            decimal giaVon = 0;
            var thieu = false;
            foreach (var ct in d.ChiTiet)
            {
                var gv = MockData.DanhSachMonAn.FirstOrDefault(m => m.Id == ct.MonAn.Id)?.GiaVon ?? ct.MonAn.GiaVon;
                if (gv <= 0) thieu = true;
                giaVon += gv * ct.SoLuong;
            }

            kq.SoDon++;
            kq.DoanhThuMon += mon;
            kq.GiamGiaQuanChiu += giam;
            kq.PhiNenTang += phi;
            kq.TongGiaVon += giaVon;
            if (thieu) kq.SoDonThieuGiaVon++;
            kq.ChiTiet.Add(new DongDonTaiChinh { DonHangId = d.Id, Ngay = d.NgayDat, DoanhThuMon = mon, GiamGiaQuanChiu = giam, PhiNenTang = phi });
        }
        return kq;
    }
}
