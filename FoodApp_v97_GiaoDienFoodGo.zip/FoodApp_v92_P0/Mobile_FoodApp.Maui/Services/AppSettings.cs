using System.Text.Json;

namespace FoodApp.Maui.Services;

/// <summary>Đọc Resources/Raw/appsettings.json (địa chỉ API) khi app khởi động.</summary>
public static class AppSettings
{
    private sealed class Root { public ApiSection Api { get; set; } = new(); }
    public sealed class ApiSection
    {
        public string BaseUrlWindows { get; set; } = "https://localhost:5001";
        public string BaseUrlAndroidEmulator { get; set; } = "http://10.0.2.2:5000";
        public string BaseUrlThietBiThat { get; set; } = "";
        /// <summary>v84: môi trường của bản build: Development (mặc định) | Staging | Production.</summary>
        public string MoiTruong { get; set; } = "Development";
        /// <summary>Địa chỉ máy chủ khi MoiTruong = Staging / Production (https://...). Rỗng = rơi về địa chỉ Development.</summary>
        public string BaseUrlStaging { get; set; } = "";
        public string BaseUrlProduction { get; set; } = "";
        public bool DungThietBiThat { get; set; }
        public int TimeoutGiay { get; set; } = 15;
        public bool ChoPhepChungChiTuKy { get; set; } = true;
    }

    public static ApiSection Api { get; private set; } = new();

    /// <summary>Địa chỉ máy chủ do người dùng nhập ở Cài đặt (ưu tiên hơn appsettings.json). Rỗng = dùng mặc định.</summary>
    public static string BaseUrlTuyChinh
    {
        get => Preferences.Default.Get("api-base-url", "");
        set => Preferences.Default.Set("api-base-url", (value ?? "").Trim());
    }

    // Production/Staging bỏ qua địa chỉ do người dùng tự nhập ở Cài đặt (chống bị trỏ sang máy chủ lạ).
    public static string BaseUrl => LaDevelopment && !string.IsNullOrWhiteSpace(BaseUrlTuyChinh) ? BaseUrlTuyChinh : BaseUrlMacDinh;

    /// <summary>
    /// Môi trường THỰC TẾ. Bản Release không bao giờ chạy ở Development: nếu appsettings ghi Development (hoặc sai tên) thì ép thành
    /// Production, để không lỡ phát hành app trỏ vào localhost / máy phát triển hoặc nạp dữ liệu mẫu.
    /// Chỉ bản Debug mới được dùng Development.
    /// </summary>
    public static string MoiTruongThucTe
    {
        get
        {
            var m = (Api.MoiTruong ?? "").Trim();
            if (m.Equals("Staging", StringComparison.OrdinalIgnoreCase)) return "Staging";
            if (m.Equals("Production", StringComparison.OrdinalIgnoreCase)) return "Production";
#if DEBUG
            return "Development";
#else
            return "Production";
#endif
        }
    }

    public static bool LaProduction => MoiTruongThucTe == "Production";
    public static bool LaStaging => MoiTruongThucTe == "Staging";
    public static bool LaDevelopment => MoiTruongThucTe == "Development";

    /// <summary>Chỉ Development mới được nạp quán/tài xế/tài khoản MẪU và tự sinh OTP trên máy. Staging/Production KHÔNG bao giờ dùng dữ liệu giả.</summary>
    public static bool DuocDungDuLieuMau => LaDevelopment;

    /// <summary>Production/Staging chưa điền địa chỉ máy chủ https → app không gọi mạng (tránh rơi về localhost).</summary>
    public static bool CauHinhMayChuThieu => !LaDevelopment && !BaseUrl.StartsWith("https://", StringComparison.OrdinalIgnoreCase);

    /// <summary>Tên môi trường để hiển thị (Staging được gắn nhãn rõ để không nhầm với dữ liệu khách thật).</summary>
    public static string TenMoiTruong => LaProduction ? "Production" : LaStaging ? "STAGING (thử nghiệm)" : "Development";

    /// <summary>Production không bao giờ chấp nhận chứng chỉ tự ký, bất kể cài đặt.</summary>
    public static bool ChoPhepChungChiTuKy => Api.ChoPhepChungChiTuKy && !LaProduction;

    /// <summary>Production/Staging: CHỈ dùng địa chỉ đã cấu hình cho môi trường đó (rỗng = chưa cấu hình, không rơi về localhost/10.0.2.2).</summary>
    public static string BaseUrlMacDinh =>
        LaProduction ? (Api.BaseUrlProduction ?? "").Trim()
        : LaStaging ? (Api.BaseUrlStaging ?? "").Trim()
        : DeviceInfo.Platform == DevicePlatform.Android
            ? (Api.DungThietBiThat && !string.IsNullOrWhiteSpace(Api.BaseUrlThietBiThat)
                ? Api.BaseUrlThietBiThat : Api.BaseUrlAndroidEmulator)
            : Api.BaseUrlWindows;

    public static async Task NapAsync()
    {
        try
        {
            using var stream = await FileSystem.OpenAppPackageFileAsync("appsettings.json");
            var root = await JsonSerializer.DeserializeAsync<Root>(stream,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            if (root is not null) Api = root.Api;
        }
        catch { /* thiếu file: dùng giá trị mặc định */ }
    }
}
