using System.Text.Json;
using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

public record GiaoDichVi(DateTime Luc, string Loai, decimal SoTien, string MoTa)   // Loai: ThuNhap | Thuong | Nap | Rut
{
    public bool LaThu => Loai is "ThuNhap" or "Thuong" or "Nap";
    public string Icon => Loai switch { "ThuNhap" => "🧾", "Thuong" => "🎁", "Nap" => "➕", _ => "🏦" };
}

/// <summary>
/// Ví tài khoản của tài xế (màn "Ví tài khoản" trong mẫu FOODAPP).
/// Số dư = thu nhập đã ghi nhận từ các chuyến giao thành công (phí giao + phụ cấp đêm + thưởng ngày) + tiền nạp − tiền rút.
/// Nạp/rút hiện chỉ ghi sổ trên thiết bị (Preferences, theo số điện thoại tài xế): CHƯA nối cổng thanh toán / ngân hàng thật.
/// </summary>
public static class ViTaiXeService
{
    public const decimal RutToiThieu = 50000;
    public const decimal NapToiThieu = 10000;

    private static string Khoa => "vi-taixe-" + (MockData.TaiXeHienTai?.SoDienThoai ?? "");

    private static List<GiaoDichVi> DocSo()
    {
        try { return JsonSerializer.Deserialize<List<GiaoDichVi>>(Preferences.Default.Get(Khoa, "[]")) ?? new(); }
        catch { return new(); }
    }
    private static void GhiSo(List<GiaoDichVi> ds)
    {
        try { Preferences.Default.Set(Khoa, JsonSerializer.Serialize(ds)); } catch { /* bỏ qua lỗi lưu */ }
    }

    /// <summary>Toàn bộ giao dịch (mới nhất trước): thu nhập từng đơn + thưởng ngày + nạp/rút.</summary>
    public static List<GiaoDichVi> DanhSach()
    {
        var ds = new List<GiaoDichVi>(DocSo());
        foreach (var d in ThuNhapService.DonThanhCong())
            ds.Add(new GiaoDichVi(d.GiaoLuc!.Value, "ThuNhap", d.PhiGiaoHang + d.PhuCap, $"Thu nhập đơn #{d.Id} · {d.TenGianHang}"));
        var ngay = ThuNhapService.DonThanhCong().Select(d => d.GiaoLuc!.Value.Date).Distinct().ToList();
        foreach (var n in ngay)
        {
            var th = ThuNhapService.ThuongNgay(n);
            if (th > 0) ds.Add(new GiaoDichVi(n.AddHours(23).AddMinutes(59), "Thuong", th, $"Thưởng ngày {n:dd/MM/yyyy}"));
        }
        return ds.OrderByDescending(x => x.Luc).ToList();
    }

    public static decimal SoDu() => DanhSach().Sum(g => g.LaThu ? g.SoTien : -g.SoTien);

    public static string? Nap(decimal soTien)
    {
        if (soTien < NapToiThieu) return $"Số tiền nạp tối thiểu {NapToiThieu:N0}đ.";
        var ds = DocSo(); ds.Add(new GiaoDichVi(DateTime.Now, "Nap", soTien, "Nạp tiền vào ví")); GhiSo(ds);
        return null;
    }

    public static string? Rut(decimal soTien)
    {
        if (soTien < RutToiThieu) return $"Số tiền rút tối thiểu {RutToiThieu:N0}đ.";
        if (soTien > SoDu()) return "Số dư không đủ để rút.";
        var ds = DocSo(); ds.Add(new GiaoDichVi(DateTime.Now, "Rut", soTien, "Rút tiền về ngân hàng")); GhiSo(ds);
        return null;
    }

    /// <summary>Đọc số tiền người dùng gõ ("200.000", "200000", "200k").</summary>
    public static bool DocSoTien(string? chu, out decimal soTien)
    {
        soTien = 0;
        var s = (chu ?? "").Trim().ToLowerInvariant().Replace(".", "").Replace(",", "").Replace("đ", "").Replace(" ", "");
        var nhan = 1m;
        if (s.EndsWith("k")) { nhan = 1000; s = s[..^1]; }
        return decimal.TryParse(s, out soTien) && (soTien *= nhan) > 0;
    }
}
