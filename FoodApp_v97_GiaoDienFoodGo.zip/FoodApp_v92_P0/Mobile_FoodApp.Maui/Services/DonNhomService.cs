namespace FoodApp.Maui.Services;

public sealed class MonNhomDto { public int MonAnId { get; set; } public int SoLuong { get; set; } }
public sealed class ThanhVienNhomDto { public string Ten { get; set; } = ""; public bool LaToi { get; set; } public bool LaChuNhom { get; set; } public bool Xong { get; set; } public List<MonNhomDto> Mon { get; set; } = new(); }
public sealed class NhomDto
{
    public string Ma { get; set; } = "";
    public string GianHangId { get; set; } = "";
    public string TenGianHang { get; set; } = "";
    public bool LaChuNhom { get; set; }
    public bool DaChot { get; set; }
    public List<ThanhVienNhomDto> ThanhVien { get; set; } = new();
}

/// <summary>Đơn hàng nhóm: gọi api/mobile/don-hang... → api/mobile/don-nhom (cần online + đăng nhập khách).</summary>
public static class DonNhomService
{
    public static string? DangO { get; set; }   // mã nhóm đang tham gia (nhớ khi mở lại trang)

    private static string Ten => Phien.Khach?.HoTen is { Length: > 0 } t ? t : "Thành viên";

    public static async Task<ApiKetQua<NhomDto>> TaoAsync(string gianHangId, string tenGianHang)
    {
        var r = await ApiClient.PostAsync<NhomDto>("api/mobile/don-nhom", new { gianHangId, tenGianHang, ten = Ten });
        if (r.ThanhCong && r.DuLieu is not null) DangO = r.DuLieu.Ma;
        return r;
    }

    public static async Task<ApiKetQua<NhomDto>> VaoAsync(string ma)
    {
        var r = await ApiClient.PostAsync<NhomDto>($"api/mobile/don-nhom/{Uri.EscapeDataString(ma.Trim().ToUpperInvariant())}/vao", new { ten = Ten });
        if (r.ThanhCong && r.DuLieu is not null) DangO = r.DuLieu.Ma;
        return r;
    }

    public static Task<ApiKetQua<NhomDto>> XemAsync(string ma) => ApiClient.GetAsync<NhomDto>($"api/mobile/don-nhom/{Uri.EscapeDataString(ma)}");

    public static Task<ApiKetQua<NhomDto>> DatMonAsync(string ma, IEnumerable<MonNhomDto> mon, bool xong) =>
        ApiClient.PutAsync<NhomDto>($"api/mobile/don-nhom/{Uri.EscapeDataString(ma)}/mon", new { mon, xong });

    public static Task<ApiKetQua<NhomDto>> ChotAsync(string ma) => ApiClient.PutAsync<NhomDto>($"api/mobile/don-nhom/{Uri.EscapeDataString(ma)}/chot", null);

    public static async Task<ApiKetQua<object>> RoiAsync(string ma)
    {
        var r = await ApiClient.DeleteAsync<object>($"api/mobile/don-nhom/{Uri.EscapeDataString(ma)}");
        DangO = null;
        return r;
    }
}
