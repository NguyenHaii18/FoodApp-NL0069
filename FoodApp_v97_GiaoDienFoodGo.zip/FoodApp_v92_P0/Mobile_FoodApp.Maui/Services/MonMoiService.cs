using System.Text.Json;
using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>
/// Nhận diện "món mới": máy chủ chưa lưu ngày tạo món nên app ghi nhớ lần đầu thấy từng món.
/// Lần chạy đầu tiên chỉ lập sổ (không món nào được coi là mới); các món xuất hiện sau đó được gắn nhãn "Mới" trong 14 ngày.
/// </summary>
public static class MonMoiService
{
    private const string Khoa = "mon-lan-dau-thay";
    private const string KhoaKhoiTao = "mon-lan-dau-thay-khoi-tao";

    public static void CapNhat(IEnumerable<MonAn> dsMon)
    {
        try
        {
            var so = new Dictionary<string, DateTime>();
            try { so = JsonSerializer.Deserialize<Dictionary<string, DateTime>>(Preferences.Default.Get(Khoa, "{}")) ?? new(); } catch { }
            var laLanDau = !Preferences.Default.ContainsKey(KhoaKhoiTao);
            var doi = false;
            foreach (var m in dsMon)
            {
                if (string.IsNullOrEmpty(m.Id)) continue;
                if (!so.TryGetValue(m.Id, out var luc))
                {
                    luc = laLanDau ? DateTime.Now.AddYears(-1) : DateTime.Now;   // lần đầu: coi là món cũ
                    so[m.Id] = luc; doi = true;
                }
                if (m.NgayTao is null) m.NgayTao = luc;   // máy chủ có trả ngayTao thì giữ nguyên
            }
            if (laLanDau) Preferences.Default.Set(KhoaKhoiTao, "1");
            if (doi) Preferences.Default.Set(Khoa, JsonSerializer.Serialize(so));
        }
        catch (Exception ex) { CrashLog.Ghi("MonMoi.CapNhat", ex); }
    }
}
