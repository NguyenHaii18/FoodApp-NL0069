using System.Diagnostics;

namespace FoodApp.Maui.Services;

/// <summary>Một lần gọi API được ghi lại để giám sát.</summary>
public sealed record GoiApiGhi(DateTime Luc, string Method, string Url, int MaHttp, long Ms, bool Loi, bool MatKetNoi, bool LienQuanThanhToan, string ThongDiep);

public sealed record ThongKeApi(int Tong, int Loi, int LoiMang, int LoiThanhToan, double TyLeLoi, long TrungBinhMs, long P95Ms);

/// <summary>Giám sát phía ứng dụng: ghi lại mọi lời gọi API (thời gian phản hồi, lỗi, lỗi thanh toán) trong bộ nhớ,
/// và kiểm tra tình trạng máy chủ qua /health. Chỉ giữ 300 lần gọi gần nhất; không gửi dữ liệu ra ngoài.</summary>
public static class GiamSatService
{
    private const int ToiDa = 300;
    private static readonly List<GoiApiGhi> _ds = new();
    private static readonly object _khoa = new();

    public static DateTime KhoiDongLuc { get; } = DateTime.Now;
    public static (bool Ok, long Ms, string ThongDiep, DateTime Luc)? SucKhoeCuoi { get; private set; }

    public static void Ghi(string method, string url, int maHttp, long ms, bool loi, bool matKetNoi, string thongDiep)
    {
        var u = url.Trim('/').ToLowerInvariant();
        bool tt = u.Contains("thanh-toan") || u.Contains("vnpay") || u.StartsWith("api/mobile/vi") || (method == "POST" && u == "api/mobile/don-hang");
        lock (_khoa)
        {
            _ds.Add(new GoiApiGhi(DateTime.Now, method, url, maHttp, ms, loi, matKetNoi, tt, thongDiep));
            if (_ds.Count > ToiDa) _ds.RemoveRange(0, _ds.Count - ToiDa);
        }
        if (loi && (tt || matKetNoi || maHttp >= 500))
            CrashLog.Ghi("API " + method + " " + url, $"HTTP {maHttp} · {ms}ms · {thongDiep}");
    }

    public static List<GoiApiGhi> TatCa() { lock (_khoa) return _ds.ToList(); }

    public static List<GoiApiGhi> LoiGanDay(int n = 10) { lock (_khoa) return _ds.Where(x => x.Loi).OrderByDescending(x => x.Luc).Take(n).ToList(); }

    public static ThongKeApi ThongKe()
    {
        var ds = TatCa();
        if (ds.Count == 0) return new(0, 0, 0, 0, 0, 0, 0);
        var ms = ds.Select(x => x.Ms).OrderBy(x => x).ToList();
        int loi = ds.Count(x => x.Loi);
        return new(ds.Count, loi, ds.Count(x => x.MatKetNoi), ds.Count(x => x.Loi && x.LienQuanThanhToan),
            Math.Round(100.0 * loi / ds.Count, 1), (long)ms.Average(), ms[Math.Min(ms.Count - 1, (int)Math.Ceiling(ms.Count * 0.95) - 1)]);
    }

    /// <summary>Gọi GET /health của máy chủ (kiểm tra ứng dụng + SQL Server).</summary>
    public static async Task<(bool Ok, long Ms, string ThongDiep)> KiemTraSucKhoeAsync()
    {
        var sw = Stopwatch.StartNew();
        var r = await ApiClient.GetAsync<object>("health");
        sw.Stop();
        var kq = (r.ThanhCong, sw.ElapsedMilliseconds, r.ThanhCong ? "Máy chủ và SQL Server hoạt động" : r.ThongDiep);
        SucKhoeCuoi = (kq.ThanhCong, kq.ElapsedMilliseconds, kq.Item3, DateTime.Now);
        return kq;
    }
}
