namespace FoodApp.Maui.Services;

/// <summary>Thông tin một nhân viên của quán (máy chủ trả về).</summary>
public sealed class NhanVienDto
{
    public int MaNV { get; set; }
    public string TenDangNhap { get; set; } = "";
    public string HoTen { get; set; } = "";
    public List<string> Quyen { get; set; } = new();
    public bool TrangThai { get; set; } = true;
    public DateTime? LanDangNhapCuoi { get; set; }
}

/// <summary>
/// Phiên làm việc của NHÂN VIÊN quán: đăng nhập bằng tài khoản nhân viên (chủ quán tạo) và chỉ dùng được các mục được cấp quyền.
/// Chủ quán đăng nhập bình thường thì <see cref="LaNhanVien"/> = false và có mọi quyền. Máy chủ vẫn kiểm tra quyền ở mỗi yêu cầu —
/// việc ẩn/chặn trên app chỉ để dễ dùng.
/// </summary>
public static class NhanVienQuan
{
    public const string DonHang = "DonHang", ThucDon = "ThucDon", KhuyenMai = "KhuyenMai", DanhGia = "DanhGia", TaiChinh = "TaiChinh";

    public static readonly (string Ma, string Ten, string Mota)[] TatCaQuyen =
    {
        (DonHang, "Đơn hàng", "Xem, xác nhận, chuẩn bị, bàn giao đơn; mở/đóng nhận đơn"),
        (ThucDon, "Thực đơn", "Thêm, sửa, tạm ngừng món và tùy chọn"),
        (KhuyenMai, "Khuyến mãi", "Tạo và sửa mã khuyến mãi, chiến dịch"),
        (DanhGia, "Đánh giá", "Xem và phản hồi đánh giá của khách"),
        (TaiChinh, "Tài chính", "Xem doanh thu và đối soát"),
    };

    public static bool LaNhanVien { get; private set; }
    public static string HoTen { get; private set; } = "";
    public static List<string> Quyen { get; private set; } = new();

    public static void DatLai() { LaNhanVien = false; HoTen = ""; Quyen = new(); }

    public static void DangNhap(NhanVienDto nv) { LaNhanVien = true; HoTen = nv.HoTen; Quyen = nv.Quyen.ToList(); }

    /// <summary>Chủ quán: luôn có quyền. Nhân viên: chỉ khi được cấp.</summary>
    public static bool Co(string quyen) => !LaNhanVien || Quyen.Contains(quyen);

    public static string Nhan(string ma) => TatCaQuyen.FirstOrDefault(q => q.Ma == ma).Ten ?? ma;

    /// <summary>Hỏi máy chủ quyền hiện tại (chủ quán có thể vừa đổi quyền). Lỗi mạng → giữ nguyên.</summary>
    public static async Task LamMoiAsync()
    {
        if (!LaNhanVien || !DuLieuService.DangOnline) return;
        var r = await ApiClient.GetAsync<NhanVienDto>("api/mobile/nhan-vien/toi");
        if (r.ThanhCong && r.DuLieu is not null) Quyen = r.DuLieu.Quyen.ToList();
    }
}
