using System.Text.Json;
using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>
/// Nhật ký thao tác: mọi hành động quản trị quan trọng + đăng nhập / đăng xuất / đổi mật khẩu / xóa tài khoản.
/// Lưu trên máy (Preferences), tối đa <see cref="ToiDa"/> dòng mới nhất. Khi có server: POST api/mobile/nhat-ky (tùy chọn).
/// </summary>
public static class NhatKyService
{
    private const string Key = "nhat-ky-v1";
    public const int ToiDa = 1500;
    private static List<NhatKyThaoTac>? _ds;

    private static List<NhatKyThaoTac> Ds => _ds ??= Nap();

    private static List<NhatKyThaoTac> Nap()
    {
        try { return JsonSerializer.Deserialize<List<NhatKyThaoTac>>(Preferences.Default.Get(Key, "[]")) ?? new(); }
        catch (JsonException) { return new(); }
    }

    private static void Luu()
    {
        if (Ds.Count > ToiDa) Ds.RemoveRange(0, Ds.Count - ToiDa);
        Preferences.Default.Set(Key, JsonSerializer.Serialize(Ds));
    }

    public static void Ghi(string vaiTro, string taiKhoan, string hanhDong, string doiTuong = "", string chiTiet = "", bool thanhCong = true)
    {
        Ds.Add(new NhatKyThaoTac
        {
            VaiTro = vaiTro, TaiKhoan = taiKhoan, HanhDong = hanhDong, DoiTuong = doiTuong, ChiTiet = chiTiet, ThanhCong = thanhCong,
        });
        Luu();
    }

    /// <summary>Ghi thao tác của quản trị viên đang đăng nhập.</summary>
    public static void GhiQuanTri(string hanhDong, string doiTuong = "", string chiTiet = "", bool thanhCong = true)
    {
        var q = MockData.QuanTriVienHienTai;
        Ghi("QuanTri:" + q.VaiTro, q.Email, hanhDong, doiTuong, chiTiet, thanhCong);
    }

    /// <summary>Mô tả thiết bị đăng nhập, ví dụ "Windows · Desktop".</summary>
    public static string ThietBi() => $"{DeviceInfo.Platform} · {DeviceInfo.Model}";

    private sealed class DongNhatKyServer
    {
        public DateTime ThoiGian { get; set; }
        public string? MucDo { get; set; }
        public string? Nguon { get; set; }
        public string? ThongDiep { get; set; }
        public int? MaTK { get; set; }
        public string? DiaChiIP { get; set; }
        public string? PhuongThuc { get; set; }
        public string? DuongDan { get; set; }
        public int? MaTrangThai { get; set; }
        public string? ChiTiet { get; set; }
        public string? TenDangNhap { get; set; }
        public string? VaiTro { get; set; }
    }

    /// <summary>Online (Admin tổng): lấy nhật ký từ Web — GET api/mobile/admin/nhat-ky. Trả null nếu không lấy được.</summary>
    /// <param name="ngay">0 = tất cả; &gt; 0 = chỉ lấy dòng trong N ngày gần nhất (1 = từ 0h hôm nay).</param>
    public static async Task<List<NhatKyThaoTac>?> TaiTuServerAsync(int ngay = 0)
    {
        if (!DuLieuService.DangOnline) return null;
        var url = "api/mobile/admin/nhat-ky?trang=1&kichThuoc=500";
        if (ngay > 0) url += "&tuNgay=" + Uri.EscapeDataString(DateTime.Today.AddDays(1 - ngay).ToString("yyyy-MM-ddTHH:mm:ss"));
        var r = await ApiClient.GetAsync<List<DongNhatKyServer>>(url);
        if (!r.ThanhCong || r.DuLieu is null) return null;
        return r.DuLieu.Select(d => new NhatKyThaoTac
        {
            ThoiGian = d.ThoiGian,
            VaiTro = "Server:" + (d.Nguon ?? ""),
            TaiKhoan = !string.IsNullOrWhiteSpace(d.TenDangNhap) ? $"{d.TenDangNhap} ({d.VaiTro})" : d.MaTK?.ToString() ?? "",
            HanhDong = d.ThongDiep ?? "",
            ChiTiet = $"{d.PhuongThuc} {d.DuongDan} → {d.MaTrangThai}  ·  IP {d.DiaChiIP}".Trim() + (string.IsNullOrWhiteSpace(d.ChiTiet) ? "" : "\n" + d.ChiTiet),
            ThanhCong = d.MucDo is null or "Info",
        }).OrderByDescending(x => x.ThoiGian).ToList();
    }

    private static string CotCsv(string? s)
    {
        s ??= "";
        return s.Contains('"') || s.Contains(',') || s.Contains('\n') ? "\"" + s.Replace("\"", "\"\"") + "\"" : s;
    }

    /// <summary>Xuất các dòng nhật ký đang hiển thị ra CSV (UTF-8 có BOM, mở được bằng Excel) rồi mở hộp chia sẻ. Ghi lại việc xuất vào nhật ký.</summary>
    public static async Task XuatCsvAsync(Page trang, IReadOnlyCollection<NhatKyThaoTac> ds)
    {
        if (ds.Count == 0) { await trang.DisplayAlert("Chưa có dữ liệu", "Không có dòng nhật ký nào để xuất.", "Đóng"); return; }
        try
        {
            var sb = new System.Text.StringBuilder("Thời gian,Nguồn/vai trò,Tài khoản,Hành động,Đối tượng,Chi tiết,Kết quả\r\n");
            foreach (var x in ds)
                sb.Append(string.Join(",", x.ThoiGian.ToString("dd/MM/yyyy HH:mm:ss"), CotCsv(x.VaiTro), CotCsv(x.TaiKhoan), CotCsv(x.HanhDong), CotCsv(x.DoiTuong), CotCsv(x.ChiTiet), x.ThanhCong ? "Thành công" : "Thất bại")).Append("\r\n");
            var duongDan = Path.Combine(FileSystem.CacheDirectory, $"NhatKy_{DateTime.Now:yyyyMMdd_HHmm}.csv");
            await File.WriteAllTextAsync(duongDan, sb.ToString(), new System.Text.UTF8Encoding(true));
            GhiQuanTri("Xuất nhật ký thao tác", $"{ds.Count} dòng");
            await Share.Default.RequestAsync(new ShareFileRequest { Title = "Nhật ký thao tác", File = new ShareFile(duongDan) });
        }
        catch (Exception ex) { await trang.DisplayAlert("Không xuất được nhật ký", ex.Message, "Đóng"); }
    }

    public static List<NhatKyThaoTac> TatCa() => Ds.OrderByDescending(x => x.ThoiGian).ToList();

    /// <summary>Lịch sử đăng nhập (thành công và thất bại) của một tài khoản.</summary>
    public static List<NhatKyThaoTac> LichSuDangNhap(string vaiTro, string taiKhoan) =>
        Ds.Where(x => x.VaiTro == vaiTro && x.HanhDong.StartsWith("Đăng nhập")
                      && string.Equals(x.TaiKhoan, taiKhoan, StringComparison.OrdinalIgnoreCase))
          .OrderByDescending(x => x.ThoiGian).Take(100).ToList();

    public static void Xoa()
    {
        Ds.Clear();
        Luu();
    }
}
