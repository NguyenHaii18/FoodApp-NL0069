namespace FoodApp.Maui.Services;

/// <summary>
/// Ghi nhớ tài khoản + mật khẩu đăng nhập theo từng vai trò ("khach", "gianhang", "nhanvien", "taixe", "quantri").
/// Lưu bằng SecureStorage (Keystore trên Android, Keychain trên iOS). Lỗi lưu/đọc được nuốt để không chặn đăng nhập.
/// </summary>
public static class GhiNhoDangNhap
{
    private static string KTk(string vaiTro) => $"dn.{vaiTro}.tk";
    private static string KMk(string vaiTro) => $"dn.{vaiTro}.mk";
    private static string KCo(string vaiTro) => $"dn.{vaiTro}.co";

    /// <summary>Nạp tài khoản/mật khẩu đã lưu vào 2 ô nhập và tích ô "Ghi nhớ" tương ứng.</summary>
    public static async void Nap(string vaiTro, Entry tk, Entry mk, CheckBox chk)
    {
        try
        {
            var co = await SecureStorage.Default.GetAsync(KCo(vaiTro));
            if (co != "1") { chk.IsChecked = false; return; }
            tk.Text = await SecureStorage.Default.GetAsync(KTk(vaiTro)) ?? "";
            mk.Text = await SecureStorage.Default.GetAsync(KMk(vaiTro)) ?? "";
            chk.IsChecked = true;
        }
        catch { /* SecureStorage không khả dụng (vd. Windows chưa đóng gói) -> bỏ qua */ }
    }

    /// <summary>Gọi sau khi đăng nhập THÀNH CÔNG. Bỏ tích thì xóa thông tin đã lưu.</summary>
    public static async void Luu(string vaiTro, string? tk, string? mk, bool ghiNho)
    {
        try
        {
            if (ghiNho && !string.IsNullOrWhiteSpace(tk) && !string.IsNullOrEmpty(mk))
            {
                await SecureStorage.Default.SetAsync(KTk(vaiTro), tk.Trim());
                await SecureStorage.Default.SetAsync(KMk(vaiTro), mk);
                await SecureStorage.Default.SetAsync(KCo(vaiTro), "1");
            }
            else Xoa(vaiTro);
        }
        catch { }
    }

    public static void Xoa(string vaiTro)
    {
        try { SecureStorage.Default.Remove(KTk(vaiTro)); SecureStorage.Default.Remove(KMk(vaiTro)); SecureStorage.Default.Remove(KCo(vaiTro)); }
        catch { }
    }
}
