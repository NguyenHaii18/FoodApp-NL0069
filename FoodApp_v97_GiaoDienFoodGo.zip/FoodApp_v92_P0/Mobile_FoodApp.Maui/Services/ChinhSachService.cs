using System.Text.Json;
using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>Chính sách chung của nền tảng hiển thị cho khách (GET api/mobile/chinh-sach). Có giá trị mặc định khi ngoại tuyến.</summary>
public sealed class ChinhSachChung
{
    public decimal PhiMoiKm { get; set; }
    public decimal PhiMacDinh { get; set; }
    public decimal BanKinhKm { get; set; }
    public int TuHuyPhut { get; set; } = 5;
    public string QuyDinhHuyDon { get; set; } = "";
    public string ChinhSachHoanTien { get; set; } = "";
    public int DuKienPhut { get; set; }
    public int VoucherToiDaMoiKhach { get; set; }
    /// <summary>v90 (tùy chọn, máy chủ chưa trả thì = 0): phí dịch vụ cố định mỗi đơn khách trả cho nền tảng.</summary>
    public decimal PhiDichVu { get; set; }
    /// <summary>v90 (tùy chọn): số điện thoại / email chăm sóc khách hàng.</summary>
    public string HotlineCskh { get; set; } = "";
    public string EmailCskh { get; set; } = "";
}

/// <summary>Đọc và lưu đệm chính sách chung. Không bao giờ ném lỗi: không tải được thì dùng bản đã lưu, rồi đến mặc định.</summary>
public static class ChinhSachService
{
    private const string Khoa = "chinh-sach-chung";
    private static ChinhSachChung? _bo;

    public static ChinhSachChung HienTai
    {
        get
        {
            if (_bo is not null) return _bo;
            try { _bo = JsonSerializer.Deserialize<ChinhSachChung>(Preferences.Default.Get(Khoa, "")); } catch { }
            return _bo ??= MacDinh();
        }
    }

    private static ChinhSachChung MacDinh() => new()
    {
        PhiMacDinh = GiaoHangService.PhiCoBan,
        BanKinhKm = 15,
        TuHuyPhut = Models.DonHang.PhutPhanHoiToiDa,
        QuyDinhHuyDon = "Hủy miễn phí khi quán chưa xác nhận. Sau khi quán đã nhận đơn, gửi yêu cầu để quản trị viên xem xét.",
        ChinhSachHoanTien = "Đơn đã thanh toán online mà bị hủy sẽ được hoàn tiền về hình thức đã thanh toán.",
    };

    /// <summary>Làm mới từ máy chủ (gọi ngầm khi mở trang quán / thanh toán).</summary>
    public static async Task LamMoiAsync()
    {
        if (!DuLieuService.DangOnline) return;
        try
        {
            var r = await ApiClient.GetAsync<ChinhSachChung>("api/mobile/chinh-sach");
            if (!r.ThanhCong || r.DuLieu is null) return;
            _bo = r.DuLieu;
            Preferences.Default.Set(Khoa, JsonSerializer.Serialize(r.DuLieu));
        }
        catch (Exception ex) { CrashLog.Ghi("ChinhSach.LamMoi", ex); }
    }

    /// <summary>Bán kính giao hàng áp dụng cho quán: của riêng quán nếu có, không thì theo chính sách chung.</summary>
    public static double BanKinhGiao(GianHang g) => g.BanKinhGiaoKm > 0 ? g.BanKinhGiaoKm : (double)HienTai.BanKinhKm;

    /// <summary>Phí dịch vụ của một đơn (0 = chưa áp dụng).</summary>
    public static decimal PhiDichVu => Math.Max(0, HienTai.PhiDichVu);
}
