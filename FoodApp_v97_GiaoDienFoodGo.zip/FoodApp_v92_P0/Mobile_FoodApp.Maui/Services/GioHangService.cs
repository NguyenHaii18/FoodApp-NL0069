using System.Collections.ObjectModel;
using System.Text.Json;
using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>
/// Giỏ hàng của khách: MỘT giỏ duy nhất (một quán). Lưu bền theo tài khoản:
///  • online: đồng bộ với server (GET/PUT api/mobile/khach-hang/gio-hang) → đổi máy / cài lại vẫn còn giỏ;
///  • luôn ghi thêm một bản trên máy (Preferences) để khôi phục khi mất mạng hoặc chế độ ngoại tuyến.
/// Trang thực đơn và trang thanh toán dùng chung đối tượng <see cref="Gio"/>; mọi thay đổi gọi <see cref="LuuAsync"/>.
/// </summary>
public static class GioHangService
{
    public static ObservableCollection<MucGioHang> Gio { get; } = new();
    public static string GianHangId { get; private set; } = "";

    private static string? _chuGio;          // khách đang nạp giỏ (email viết thường)
    private static bool _daTai;
    private static readonly SemaphoreSlim _khoa = new(1, 1);

    private sealed class DongLuu { public string MonAnId { get; set; } = ""; public int SoLuong { get; set; } = 1; public string GhiChu { get; set; } = ""; public List<string> TuyChon { get; set; } = new(); }
    private sealed class GioLuu { public string GianHangId { get; set; } = ""; public bool ChuaDongBo { get; set; } public List<DongLuu> Dong { get; set; } = new(); }
    private sealed class GioServerDto { public int? MaGianHang { get; set; } public List<DongServerDto>? ChiTiet { get; set; } }
    private sealed class DongServerDto { public int MaMonAn { get; set; } public int SoLuong { get; set; } public string? GhiChu { get; set; } public List<string>? TuyChon { get; set; } public bool ConBan { get; set; } = true; }

    private static string Chu() => Phien.Khach?.Email?.ToLowerInvariant() is { Length: > 0 } e ? e : "khach";
    private static string Khoa(string chu) => $"gio-hang:{chu}";
    private static bool CoTheDongBo => DuLieuService.DangOnline && !string.IsNullOrEmpty(ApiClient.Token) && Phien.Khach is not null;

    /// <summary>Xóa giỏ đang giữ trong bộ nhớ (đăng xuất). Bản đã lưu theo tài khoản vẫn còn để khôi phục khi đăng nhập lại.</summary>
    public static void DatLai()
    {
        Gio.Clear();
        GianHangId = "";
        _chuGio = null;
        _daTai = false;
    }

    /// <summary>Khôi phục giỏ khi mở app / vào thực đơn: server (online) hoặc bản lưu trên máy.</summary>
    public static async Task TaiAsync()
    {
        var chu = Chu();
        if (_chuGio == chu && _daTai) return;
        if (_chuGio != chu) { Gio.Clear(); GianHangId = ""; _chuGio = chu; }

        var luu = DocMay(chu);
        if (CoTheDongBo)
        {
            // Lần trước lưu server thất bại (mất mạng) → bản trên máy mới hơn, đẩy lên thay vì ghi đè nó
            if (luu is { ChuaDongBo: true })
            {
                ApDungMay(luu);
                _daTai = true;
                await LuuAsync();
                return;
            }
            var r = await ApiClient.GetAsync<GioServerDto>("api/mobile/khach-hang/gio-hang");
            if (r.ThanhCong && r.DuLieu is not null)
            {
                var boQua = ApDungServer(r.DuLieu);
                _daTai = true;
                if (boQua > 0) await LuuAsync();      // có món đã ngừng bán / không còn → cập nhật lại giỏ cho khớp
                else GhiMay(chu, false);
                return;
            }
        }
        if (luu is not null) ApDungMay(luu);
        _daTai = !CoTheDongBo;      // đang online nhưng lỗi mạng → để lần sau thử lại
    }

    // ---------- thao tác giỏ ----------
    /// <summary>Giỏ đang có món của quán khác (khách phải xác nhận trước khi thay).</summary>
    public static bool CoMonQuanKhac(string gianHangId) => Gio.Count > 0 && GianHangId != gianHangId;

    public static void LamTrong() { Gio.Clear(); GianHangId = ""; }

    /// <summary>Thêm nhanh từ thực đơn: món có size thì tự chọn size đầu tiên (khách đổi được ở Chi tiết món).</summary>
    public static void Them(MonAn mon) => Them(mon, 1, "", TuyChonMacDinh(mon));

    public static List<TuyChonMon> TuyChonMacDinh(MonAn mon)
    {
        var size = mon.TuyChon.FirstOrDefault(t => t.Loai == TuyChonMon.Size);
        return size is null ? new() : new() { size };
    }

    /// <summary>Khớp tên tùy chọn đã lưu (giỏ cũ / đơn cũ) với tùy chọn hiện có của món; tên không còn thì bỏ qua.</summary>
    public static List<TuyChonMon> TuyChonTuTen(MonAn mon, IEnumerable<string>? ten)
    {
        var kq = new List<TuyChonMon>();
        foreach (var t in ten ?? Enumerable.Empty<string>())
        {
            var m = mon.TuyChon.FirstOrDefault(x => string.Equals(x.Ten, t.Trim(), StringComparison.OrdinalIgnoreCase));
            if (m != null && !kq.Contains(m)) kq.Add(m);
        }
        return kq;
    }

    public static List<string> TachTuyChon(string? text) =>
        string.IsNullOrWhiteSpace(text) ? new() : text.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();

    /// <summary>Thêm món với số lượng và ghi chú chọn ở trang Chi tiết món.</summary>
    public static void Them(MonAn mon, int soLuong, string ghiChu, List<TuyChonMon>? tuyChon = null)
    {
        if (GianHangId != mon.GianHangId) { Gio.Clear(); GianHangId = mon.GianHangId; }
        soLuong = Math.Clamp(soLuong, 1, 99);
        tuyChon ??= new();
        var ky = string.Join("|", tuyChon.Select(t => t.Ten).OrderBy(x => x, StringComparer.OrdinalIgnoreCase));
        var dong = Gio.FirstOrDefault(x => x.MonAn.Id == mon.Id && x.ChuKyTuyChon == ky);
        if (dong is null) Gio.Add(new MucGioHang { MonAn = mon, SoLuong = soLuong, GhiChu = ghiChu ?? "", TuyChonDaChon = tuyChon, GiaLucThem = mon.Gia + tuyChon.Sum(t => t.GiaThem) });
        else
        {
            dong.SoLuong = Math.Min(99, dong.SoLuong + soLuong);
            if (!string.IsNullOrWhiteSpace(ghiChu)) dong.GhiChu = ghiChu.Trim();
        }
    }

    // ---------- v90: kiểm tra giá & tình trạng món trước khi đặt ----------
    public sealed record DoiGiaMon(MucGioHang Dong, decimal GiaCu, decimal GiaMoi, bool TuyChonDoi);
    public sealed record KetQuaKiemTraGio(List<MucGioHang> DongKhongBan, List<string> LyDoKhongBan, List<DoiGiaMon> DoiGia)
    {
        public bool CoVanDe => DongKhongBan.Count > 0 || DoiGia.Count > 0;
    }

    /// <summary>
    /// Làm mới món ăn từ máy chủ (nếu online) rồi so từng dòng trong giỏ với dữ liệu mới nhất:
    /// món hết / tạm ngừng / ngoài giờ bán / quán đóng → "không bán"; đơn giá (gồm phụ thu) khác lúc thêm → "đổi giá".
    /// Hàm này cập nhật tham chiếu món + tùy chọn theo dữ liệu mới nhưng KHÔNG xóa dòng nào — nơi gọi hỏi khách rồi mới xóa.
    /// </summary>
    public static async Task<KetQuaKiemTraGio> KiemTraAsync()
    {
        try { await DuLieuService.LamMoiMonAnAsync(); }
        catch (Exception ex) { CrashLog.Ghi("GioHang.LamMoiMon", ex); }

        var khongBan = new List<MucGioHang>(); var lyDo = new List<string>(); var doi = new List<DoiGiaMon>();
        foreach (var dong in Gio.ToList())
        {
            var ten = dong.MonAn.TenMon;
            var moi = MockData.DanhSachMonAn.FirstOrDefault(m => m.Id == dong.MonAn.Id);
            if (moi is null) { khongBan.Add(dong); lyDo.Add($"{ten} — không còn trong thực đơn"); continue; }
            if (moi.TamNgungBan) { khongBan.Add(dong); lyDo.Add($"{ten} — quán tạm ngừng bán"); continue; }
            if (!moi.ConHang) { khongBan.Add(dong); lyDo.Add($"{ten} — đã hết"); continue; }
            if (moi.TonKho is { } ton && ton < dong.SoLuong) { khongBan.Add(dong); lyDo.Add(ton <= 0 ? $"{ten} — đã hết" : $"{ten} — chỉ còn {ton} phần (bạn chọn {dong.SoLuong})"); continue; }
            if (!moi.TrongKhungGioBan) { khongBan.Add(dong); lyDo.Add($"{ten} — ngoài giờ bán ({moi.BanTuGio}–{moi.BanDenGio})"); continue; }

            var tenTuyChon = dong.TuyChonDaChon.Select(t => t.Ten).ToList();
            var tuyChonMoi = TuyChonTuTen(moi, tenTuyChon);
            var cu = dong.GiaLucThem > 0 ? dong.GiaLucThem : dong.DonGiaTinh;
            dong.MonAn = moi;
            dong.TuyChonDaChon = tuyChonMoi;
            var moiGia = dong.DonGiaTinh;
            var tuyChonDoi = tuyChonMoi.Count != tenTuyChon.Count;
            if (moiGia != cu || tuyChonDoi) doi.Add(new DoiGiaMon(dong, cu, moiGia, tuyChonDoi));
        }
        return new KetQuaKiemTraGio(khongBan, lyDo, doi);
    }

    /// <summary>Khách đã đồng ý với giá mới: ghi nhận lại để lần kiểm tra sau không báo nữa.</summary>
    public static void ChotGia()
    {
        foreach (var d in Gio) d.GiaLucThem = d.DonGiaTinh;
    }

    /// <summary>Sửa tùy chọn của một dòng trong giỏ; trùng với dòng khác (cùng món, cùng tùy chọn) thì gộp số lượng.</summary>
    public static void DoiTuyChon(MucGioHang dong, List<TuyChonMon> tuyChonMoi)
    {
        dong.TuyChonDaChon = tuyChonMoi;
        dong.GiaLucThem = dong.DonGiaTinh;
        var trung = Gio.FirstOrDefault(x => !ReferenceEquals(x, dong) && x.MonAn.Id == dong.MonAn.Id && x.ChuKyTuyChon == dong.ChuKyTuyChon);
        if (trung is null) return;
        trung.SoLuong = Math.Min(99, trung.SoLuong + dong.SoLuong);
        if (string.IsNullOrWhiteSpace(trung.GhiChu)) trung.GhiChu = dong.GhiChu;
        Gio.Remove(dong);
    }

    /// <summary>Lưu giỏ hiện tại (máy + server). Gọi sau MỌI thay đổi: thêm/bớt/xóa món, sửa ghi chú, dọn giỏ.</summary>
    public static async Task LuuAsync()
    {
        var chu = Chu();
        _chuGio = chu;
        await _khoa.WaitAsync();
        try
        {
            if (!CoTheDongBo) { GhiMay(chu, false); return; }

            GhiMay(chu, true);          // đánh dấu chưa đồng bộ cho tới khi server nhận
            var ds = Gio.Select(x => (Id: int.TryParse(x.MonAn.Id, out var i) ? i : 0, x.SoLuong, x.GhiChu, Ten: x.TuyChonDaChon.Select(t => t.Ten).ToList())).ToList();
            if (ds.Any(x => x.Id == 0)) { GhiMay(chu, false); return; }   // món mẫu ngoại tuyến, không có trên server
            var ma = int.TryParse(GianHangId, out var g) ? g : 0;
            var kq = await ApiClient.PutAsync<object>("api/mobile/khach-hang/gio-hang", new
            {
                maGianHang = ma,
                chiTiet = ds.Select(x => new { maMonAn = x.Id, soLuong = x.SoLuong, ghiChu = x.GhiChu, tuyChon = x.Ten })
            });
            if (kq.ThanhCong) GhiMay(chu, false);   // lỗi mạng: giữ cờ ChuaDongBo, lần mở app sau sẽ đẩy lại
        }
        finally { _khoa.Release(); }
    }

    /// <summary>Dọn giỏ sau khi đặt hàng thành công.</summary>
    public static async Task XoaAsync()
    {
        LamTrong();
        await LuuAsync();
    }

    // ---------- lưu trên máy ----------
    private static GioLuu? DocMay(string chu)
    {
        try { return JsonSerializer.Deserialize<GioLuu>(Preferences.Default.Get(Khoa(chu), "")); }
        catch { return null; }
    }

    private static void GhiMay(string chu, bool chuaDongBo)
    {
        try
        {
            if (Gio.Count == 0) { Preferences.Default.Remove(Khoa(chu)); return; }
            Preferences.Default.Set(Khoa(chu), JsonSerializer.Serialize(new GioLuu
            {
                GianHangId = GianHangId, ChuaDongBo = chuaDongBo,
                Dong = Gio.Select(x => new DongLuu { MonAnId = x.MonAn.Id, SoLuong = x.SoLuong, GhiChu = x.GhiChu, TuyChon = x.TuyChonDaChon.Select(t => t.Ten).ToList() }).ToList()
            }));
        }
        catch (Exception ex) { CrashLog.Ghi("GioHang.GhiMay", ex); }
    }

    private static void ApDungMay(GioLuu luu)
    {
        Gio.Clear();
        GianHangId = luu.GianHangId;
        foreach (var d in luu.Dong)
        {
            var mon = MockData.DanhSachMonAn.FirstOrDefault(m => m.Id == d.MonAnId);
            if (mon is null || !mon.ConHang) continue;
            var dongMay = new MucGioHang { MonAn = mon, SoLuong = Math.Clamp(d.SoLuong, 1, 99), GhiChu = d.GhiChu ?? "", TuyChonDaChon = TuyChonTuTen(mon, d.TuyChon) };
            dongMay.GiaLucThem = dongMay.DonGiaTinh;
            Gio.Add(dongMay);
        }
        if (Gio.Count == 0) GianHangId = "";
    }

    /// <summary>Trả về số dòng bị bỏ (món không còn / ngừng bán).</summary>
    private static int ApDungServer(GioServerDto dto)
    {
        Gio.Clear();
        GianHangId = dto.MaGianHang?.ToString() ?? "";
        var boQua = 0;
        foreach (var d in dto.ChiTiet ?? new())
        {
            var mon = MockData.DanhSachMonAn.FirstOrDefault(m => m.Id == d.MaMonAn.ToString());
            if (mon is null || !d.ConBan || !mon.ConHang) { boQua++; continue; }
            var dongSv = new MucGioHang { MonAn = mon, SoLuong = Math.Clamp(d.SoLuong, 1, 99), GhiChu = d.GhiChu ?? "", TuyChonDaChon = TuyChonTuTen(mon, d.TuyChon) };
            dongSv.GiaLucThem = dongSv.DonGiaTinh;
            Gio.Add(dongSv);
        }
        if (Gio.Count == 0) GianHangId = "";
        return boQua;
    }
}
