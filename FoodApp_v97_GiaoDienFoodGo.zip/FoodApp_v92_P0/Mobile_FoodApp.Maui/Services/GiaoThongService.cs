namespace FoodApp.Maui.Services;

/// <summary>
/// Hệ số kẹt xe theo khung giờ (TP.HCM, xe máy) — cùng bảng với máy chủ (GiaoThongTheoGio).
/// LƯU Ý: đây là ƯỚC TÍNH THEO GIỜ CAO ĐIỂM, không phải dữ liệu giao thông thời gian thực.
/// </summary>
public static class GiaoThongService
{
    public static (double HeSo, string Nhan) Tinh(DateTime? luc = null)
    {
        var t = luc ?? DateTime.Now;
        var phut = t.Hour * 60 + t.Minute;
        var cuoiTuan = t.DayOfWeek is DayOfWeek.Saturday or DayOfWeek.Sunday;
        bool Trong(int tu, int den) => phut >= tu && phut < den;
        if (Trong(16 * 60 + 30, 19 * 60 + 30)) return (cuoiTuan ? 1.25 : 1.45, "Giờ cao điểm chiều");
        if (Trong(7 * 60, 9 * 60)) return (cuoiTuan ? 1.05 : 1.35, "Giờ cao điểm sáng");
        if (Trong(11 * 60 + 30, 13 * 60)) return (1.15, "Giờ ăn trưa");
        if (phut >= 22 * 60 || phut < 5 * 60 + 30) return (0.9, "Đêm vắng xe");
        return (1.0, "Giờ thường");
    }

    /// <summary>Chuỗi ngắn gọn cho giao diện, vd "giờ cao điểm chiều ×1.45"; rỗng khi giờ thường.</summary>
    public static string GhiChu(DateTime? luc = null)
    {
        var (h, n) = Tinh(luc);
        return Math.Abs(h - 1.0) < 0.01 ? "" : $"{n.ToLowerInvariant()} ×{h:0.##}";
    }
}
