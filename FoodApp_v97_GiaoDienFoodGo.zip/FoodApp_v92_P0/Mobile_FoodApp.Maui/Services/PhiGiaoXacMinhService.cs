namespace FoodApp.Maui.Services;

/// <summary>Kết quả máy chủ trả cho POST api/mobile/map/phi-giao-hang.</summary>
public sealed class PhiXacMinhDto
{
    public decimal PhiGiaoHang { get; set; }
    public double KhoangCachKm { get; set; }
    public int ThoiGianDuKienPhut { get; set; }
    public bool NgoaiThanh { get; set; }
    /// <summary>true = máy chủ đo được quãng đường THẬT (Goong); false = máy chủ đang dùng phí mặc định vì không đo được.</summary>
    public bool DaXacMinh { get; set; }
    public string Nguon { get; set; } = "";
    public string GhiChu { get; set; } = "";
}

/// <summary>
/// v94: hỏi MÁY CHỦ phí giao + quãng đường theo tuyến đường thật trước khi khách đặt đơn.
/// Ước tính cục bộ (GiaoHangService.UocTinh: tâm quận × hệ số) chỉ để hiển thị tạm — KHÔNG phải căn cứ thu tiền.
/// Có nhớ đệm ngắn (5 phút) và nghỉ 20 giây sau khi lỗi mạng để không gọi dồn khi khách đang gõ địa chỉ.
/// </summary>
public static class PhiGiaoXacMinhService
{
    private static readonly Dictionary<string, (DateTime Luc, PhiXacMinhDto Kq)> _nho = new();
    private static DateTime _nghiDen = DateTime.MinValue;
    private static readonly TimeSpan ThoiGianNho = TimeSpan.FromMinutes(5);

    private static string Khoa(string a, string b) => (a.Trim() + "|" + b.Trim()).ToLowerInvariant();

    /// <param name="boQuaNho">true: bỏ nhớ đệm và bỏ thời gian nghỉ (dùng ngay trước khi đặt đơn).</param>
    public static async Task<(PhiXacMinhDto? Kq, string LyDo)> LayAsync(string diaChiLay, string diaChiGiao, bool boQuaNho = false)
    {
        if (!DuLieuService.DangOnline) return (null, "Đang ngoại tuyến — chỉ có phí ước tính.");
        if (string.IsNullOrWhiteSpace(diaChiLay) || string.IsNullOrWhiteSpace(diaChiGiao)) return (null, "Thiếu địa chỉ quán hoặc địa chỉ nhận.");
        var khoa = Khoa(diaChiLay, diaChiGiao);
        if (!boQuaNho)
        {
            if (_nho.TryGetValue(khoa, out var da) && DateTime.Now - da.Luc < ThoiGianNho) return (da.Kq, "");
            if (DateTime.Now < _nghiDen) return (null, "Máy chủ vừa lỗi, sẽ thử lại sau ít giây.");
        }
        var r = await ApiClient.PostAsync<PhiXacMinhDto>("api/mobile/map/phi-giao-hang", new { diaChiLay, diaChiGiao });
        if (!r.ThanhCong || r.DuLieu is null)
        {
            _nghiDen = DateTime.Now.AddSeconds(20);
            return (null, string.IsNullOrWhiteSpace(r.ThongDiep) ? "Không hỏi được máy chủ." : r.ThongDiep);
        }
        if (_nho.Count > 50) _nho.Clear();
        _nho[khoa] = (DateTime.Now, r.DuLieu);
        return (r.DuLieu, "");
    }

    public static void XoaNho() { _nho.Clear(); _nghiDen = DateTime.MinValue; }
}
