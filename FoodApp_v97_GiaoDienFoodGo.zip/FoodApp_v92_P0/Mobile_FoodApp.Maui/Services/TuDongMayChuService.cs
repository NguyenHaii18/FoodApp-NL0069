using System.Text.Json;

namespace FoodApp.Maui.Services;

public sealed class TuDongTrangThaiDto
{
    public bool Bat { get; set; }
    public DateTime? LanChayCuoi { get; set; }
    public int TongDaPhanCong { get; set; }
    public string KetQuaCuoi { get; set; } = "";
    public bool QuanTriDieuPhoi { get; set; } = true;
}

/// <summary>Tự động phân công chạy NỀN trên máy chủ (api/mobile/admin/dieu-phoi/tu-dong): bật/tắt, xem trạng thái, chạy ngay.</summary>
public static class TuDongMayChuService
{
    private const string Url = "api/mobile/admin/dieu-phoi/tu-dong";
    private sealed class KetQuaPut { public string ThongDiep { get; set; } = ""; public TuDongTrangThaiDto? TrangThai { get; set; } }

    public static async Task<ApiKetQua<TuDongTrangThaiDto>> XemAsync() => await ApiClient.GetAsync<TuDongTrangThaiDto>(Url);

    public static async Task<(bool Ok, string ThongDiep, TuDongTrangThaiDto? TrangThai)> DatAsync(bool bat)
    {
        var r = await ApiClient.PutAsync<KetQuaPut>(Url, new { bat });
        if (r.ThanhCong) NhatKyService.GhiQuanTri(bat ? "Bật tự động phân công (máy chủ)" : "Tắt tự động phân công (máy chủ)");
        return (r.ThanhCong, r.ThanhCong ? r.DuLieu?.ThongDiep ?? "" : r.ThongDiep, r.DuLieu?.TrangThai);
    }

    public static async Task<(bool Ok, string ThongDiep)> ChayNgayAsync()
    {
        var r = await ApiClient.PostAsync<KetQuaPut>(Url + "/chay-ngay", null);
        return (r.ThanhCong, r.ThanhCong ? r.DuLieu?.ThongDiep ?? "" : r.ThongDiep);
    }

    public static string Tom(TuDongTrangThaiDto t) =>
        $"{(t.Bat ? "🟢 ĐANG BẬT" : "⚪ Đang tắt")} (chạy nền trên máy chủ, 30 giây/lượt)\n" +
        (t.QuanTriDieuPhoi ? "" : "⚠ Hệ thống đang ở chế độ hàng chờ chung nên không phân công.\n") +
        $"Tổng đã phân công từ lúc máy chủ khởi động: {t.TongDaPhanCong}\n" +
        (t.LanChayCuoi is { } l ? $"Lần chạy cuối {l:HH:mm:ss dd/MM}: {t.KetQuaCuoi}" : "Chưa chạy lần nào kể từ khi máy chủ khởi động.");
}
