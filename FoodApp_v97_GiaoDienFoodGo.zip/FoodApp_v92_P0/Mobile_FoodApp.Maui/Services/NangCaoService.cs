using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

public sealed record HangThanhVienKq(string Ten, string Icon, int Diem, decimal TongChi, string? HangTiepTheo, decimal ConThieu, double TienDo, string QuyenLoi);
public sealed record MoiTruongKq(double TongKm, double KgCo2, double KgCo2NeuOto, int SoDon);
public sealed record GoiYMonKq(MonAn Mon, string LyDo, double Diem);
public sealed record DuBaoGioKq(int Gio, double DonTrungBinh, int TaiXeCan);
public sealed record GoiYTaiXeKq(TaiXe TaiXe, int DonDangGiu, double Diem);
public sealed record GoiYGhepKq(DonHang A, DonHang B, string LyDo);

/// <summary>Các tính năng nâng cao tính trên dữ liệu đơn hàng hiện có (luật + thống kê, KHÔNG phải mô hình học máy).
/// Kết quả là GỢI Ý để người dùng/quản trị quyết định; không tự thay đổi đơn hay giá.</summary>
public static class NangCaoService
{
    // Hệ số phát thải ước tính (kg CO2 / km) — giả định tham khảo, ghi rõ trong giao diện.
    public const double HeSoXeMay = 0.07;
    public const double HeSoOto = 0.17;

    private static IEnumerable<DonHang> DonCuaKhach(string? email) =>
        MockData.LichSuDonHang.Concat(MockData.DonHangCuaGianHang).GroupBy(d => d.Id).Select(g => g.First())
            .Where(d => !string.IsNullOrEmpty(email) && string.Equals(d.KhachEmail, email, StringComparison.OrdinalIgnoreCase));

    // ---------------------------------------------------------------- Thành viên
    private static readonly (string Ten, string Icon, decimal Nguong, string QuyenLoi)[] Hang =
    {
        ("Đồng", "🥉", 0m, "Tích điểm mỗi đơn hoàn thành"),
        ("Bạc", "🥈", 500_000m, "Ưu tiên nhận mã khuyến mãi mới"),
        ("Vàng", "🥇", 2_000_000m, "Ưu tiên hỗ trợ + mã ưu đãi độc quyền"),
        ("Kim cương", "💎", 5_000_000m, "Ưu đãi cao nhất + hỗ trợ ưu tiên"),
    };

    /// <summary>Hạng theo tổng chi tiêu của các đơn đã hoàn thành. 1 điểm = 1.000đ. Quyền lợi chỉ để hiển thị, chưa tự áp vào giá.</summary>
    public static HangThanhVienKq ThanhVien(string? email)
    {
        var tong = DonCuaKhach(email).Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).Sum(d => d.TongThanhToan);
        int i = 0;
        for (int k = 0; k < Hang.Length; k++) if (tong >= Hang[k].Nguong) i = k;
        var h = Hang[i];
        if (i == Hang.Length - 1) return new(h.Ten, h.Icon, (int)(tong / 1000), tong, null, 0, 1, h.QuyenLoi);
        var tiep = Hang[i + 1];
        var tienDo = (double)((tong - h.Nguong) / (tiep.Nguong - h.Nguong));
        return new(h.Ten, h.Icon, (int)(tong / 1000), tong, tiep.Ten, tiep.Nguong - tong, Math.Clamp(tienDo, 0, 1), h.QuyenLoi);
    }

    // ---------------------------------------------------------------- Môi trường
    public static MoiTruongKq MoiTruong(string? email)
    {
        var ds = DonCuaKhach(email).Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).ToList();
        double km = ds.Sum(d => d.KhoangCachThucTeKm > 0 ? d.KhoangCachThucTeKm : d.KhoangCachKm);
        return new(Math.Round(km, 1), Math.Round(km * HeSoXeMay, 2), Math.Round(km * HeSoOto, 2), ds.Count);
    }

    /// <summary>Ước tính CO2 (kg) cho một quãng đường giao bằng xe máy.</summary>
    public static double Co2(double km) => Math.Round(km * HeSoXeMay, 2);

    // ---------------------------------------------------------------- Gợi ý món
    /// <summary>Gợi ý món theo lịch sử đặt: ưa thích quán / danh mục đã đặt nhiều, ưu tiên quán điểm cao, bỏ món hết hàng.
    /// Khách chưa có lịch sử → gợi ý món của quán được đánh giá cao.</summary>
    public static List<GoiYMonKq> GoiYMon(string? email, int soLuong = 6)
    {
        var da = DonCuaKhach(email).Where(d => d.TrangThai != TrangThaiDonHang.DaHuy).ToList();
        var quan = da.GroupBy(d => d.GianHangId).ToDictionary(g => g.Key, g => g.Count());
        var dm = da.SelectMany(d => d.ChiTiet).Where(c => c.MonAn is not null).GroupBy(c => c.MonAn.DanhMuc).ToDictionary(g => g.Key, g => g.Sum(c => c.SoLuong));
        var daDat = da.SelectMany(d => d.ChiTiet).Where(c => c.MonAn is not null).Select(c => c.MonAn.Id).ToHashSet();
        var diemQuan = MockData.DanhSachGianHang.ToDictionary(g => g.Id, g => g.DanhGia);

        var kq = new List<GoiYMonKq>();
        foreach (var m in MockData.DanhSachMonAn.Where(m => m.ConHang && !m.TamNgungBan))
        {
            double diem = 0; string ly = "";
            if (quan.TryGetValue(m.GianHangId, out var q)) { diem += 2 * q; ly = "Từ quán bạn hay đặt"; }
            if (dm.TryGetValue(m.DanhMuc, out var c)) { diem += c; ly = ly == "" ? $"Bạn thích {m.DanhMuc}" : ly + $" · thích {m.DanhMuc}"; }
            if (diemQuan.TryGetValue(m.GianHangId, out var sao)) { diem += sao / 2; if (ly == "") ly = "Quán được đánh giá cao"; }
            if (daDat.Contains(m.Id)) diem -= 1;      // món đã đặt: hạ nhẹ để có món mới
            kq.Add(new GoiYMonKq(m, ly, diem));
        }
        return kq.OrderByDescending(x => x.Diem).Take(soLuong).ToList();
    }

    // ---------------------------------------------------------------- Dự báo nhu cầu
    /// <summary>Số đơn trung bình mỗi giờ trong ngày (theo ngày có dữ liệu) và số tài xế đề xuất (1 tài xế ≈ 2 đơn/giờ).</summary>
    public static List<DuBaoGioKq> DuBaoNhuCau()
    {
        var ds = MockData.TatCaDonHangHeThong.Where(d => d.TrangThai != TrangThaiDonHang.DaHuy).ToList();
        int soNgay = Math.Max(1, ds.Select(d => d.NgayDat.Date).Distinct().Count());
        return Enumerable.Range(0, 24).Select(g =>
        {
            double tb = Math.Round(ds.Count(d => d.NgayDat.Hour == g) / (double)soNgay, 1);
            return new DuBaoGioKq(g, tb, (int)Math.Ceiling(tb / 2.0));
        }).ToList();
    }

    // ---------------------------------------------------------------- Phân công tài xế
    /// <summary>Xếp hạng tài xế sẵn sàng cho một đơn: ít đơn đang giữ và điểm đánh giá cao thì ưu tiên.</summary>
    public static List<GoiYTaiXeKq> GoiYTaiXe(int top = 3)
    {
        var dang = MockData.TatCaDonHangHeThong
            .Where(d => !string.IsNullOrEmpty(d.TaiXeId) && (d.TrangThai == TrangThaiDonHang.DangLam || d.TrangThai == TrangThaiDonHang.DangGiao))
            .GroupBy(d => d.TaiXeId ?? "").ToDictionary(g => g.Key, g => g.Count());
        return MockData.DanhSachTaiXe.Where(t => t.NhanDuocDon && t.DaDuyet)
            .Select(t => { dang.TryGetValue(t.Id, out var n); return new GoiYTaiXeKq(t, n, Math.Round(t.DanhGia * 2 - n * 1.5, 1)); })
            .OrderByDescending(x => x.Diem).Take(top).ToList();
    }

    public static List<DonHang> DonChoTaiXe() => MockData.TatCaDonHangHeThong.Where(d => d.DangChoTaiXe).OrderBy(d => d.NgayDat).ToList();

    // ---------------------------------------------------------------- Ghép đơn
    /// <summary>Hai đơn cùng quán đang chờ tài xế, quãng đường giao chênh nhau ≤ 1,5 km → có thể giao chung một chuyến.</summary>
    public static List<GoiYGhepKq> GoiYGhepDon()
    {
        var cho = DonChoTaiXe();
        var kq = new List<GoiYGhepKq>();
        for (int i = 0; i < cho.Count; i++)
            for (int j = i + 1; j < cho.Count; j++)
            {
                var a = cho[i]; var b = cho[j];
                if (a.GianHangId != b.GianHangId) continue;
                if (Math.Abs(a.KhoangCachKm - b.KhoangCachKm) > 1.5) continue;
                kq.Add(new GoiYGhepKq(a, b, $"Cùng quán {a.TenGianHang}, chênh {Math.Abs(a.KhoangCachKm - b.KhoangCachKm):0.#} km"));
            }
        return kq;
    }
}
