using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>Một thông báo lấy từ bảng ThongBao trên SQL Server (GET api/mobile/thong-bao).</summary>
public sealed class ThongBaoMayChu
{
    public long Id { get; set; }
    public string Loai { get; set; } = "";
    public string TieuDe { get; set; } = "";
    public string NoiDung { get; set; } = "";
    public string? MaThamChieu { get; set; }
    public bool DaDoc { get; set; }
    public DateTime Ngay { get; set; }
}

public sealed class ThongBaoMayChuTraVe
{
    public int ChuaDoc { get; set; }
    public List<ThongBaoMayChu> Items { get; set; } = new();
}

/// <summary>Thông báo thật từ máy chủ cho mọi vai trò (khách, quán, tài xế). Offline: giữ danh sách cũ, không báo lỗi.</summary>
public static class ThongBaoMayChuService
{
    public static List<ThongBaoMayChu> DanhSach { get; private set; } = new();
    public static int ChuaDoc { get; private set; }

    public static async Task TaiAsync()
    {
        if (!DuLieuService.DangOnline || string.IsNullOrEmpty(ApiClient.Token)) return;
        var r = await ApiClient.GetAsync<ThongBaoMayChuTraVe>("api/mobile/thong-bao?soLuong=50");
        if (r.ThanhCong && r.DuLieu is not null)
        {
            DanhSach = r.DuLieu.Items;
            ChuaDoc = r.DuLieu.ChuaDoc;
        }
    }

    public static async Task DocTatCaAsync()
    {
        if (!DuLieuService.DangOnline || string.IsNullOrEmpty(ApiClient.Token)) return;
        var r = await ApiClient.PutAsync<object>("api/mobile/thong-bao/doc-tat-ca", null);
        if (r.ThanhCong)
        {
            foreach (var t in DanhSach) t.DaDoc = true;
            ChuaDoc = 0;
        }
    }

    public static string Icon(string loai) => loai switch
    {
        "DonHang" => "📦",
        "KhuyenMai" => "🏷️",
        "TinNhan" => "💬",
        _ => "🔔",
    };
}
