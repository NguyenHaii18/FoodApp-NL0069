using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>v75 — Dữ liệu cho các mục bổ sung ở Trang chủ: món bán chạy, quán được đề xuất, đơn gần đây để đặt lại.</summary>
public static class TrangChuService
{
    /// <summary>Món bán chạy nhất (theo số phần của các đơn không hủy / không giao thất bại) của các quán đang hiển thị.</summary>
    public static List<(MonAn Mon, int DaBan)> MonBanChay(int n = 8)
    {
        var quanOk = MockData.DanhSachGianHang.Where(TimKiemService.QuanHienThi).Select(g => g.Id).ToHashSet();
        return TimKiemService.DonTinhBanChay().Where(d => quanOk.Contains(d.GianHangId))
            .SelectMany(d => d.ChiTiet).Where(c => c.MonAn is not null)
            .GroupBy(c => c.MonAn.Id)
            .Select(g => (Mon: MockData.DanhSachMonAn.FirstOrDefault(m => m.Id == g.Key) ?? g.First().MonAn, Ban: g.Sum(c => c.SoLuong)))
            .Where(x => x.Mon.ConHang && !x.Mon.TamNgungBan)
            .OrderByDescending(x => x.Ban).Take(n).ToList();
    }

    /// <summary>
    /// Món ăn kèm gợi ý cho một món: các món khác CỦA CÙNG QUÁN thường nằm chung đơn với món này (đếm trên các đơn đã có),
    /// bổ sung bằng món bán chạy khác danh mục; chỉ món còn bán. Trả kèm lý do ngắn.
    /// </summary>
    public static List<(MonAn Mon, string LyDo)> MonAnKem(MonAn mon, int n = 6)
    {
        var cungQuan = MockData.DanhSachMonAn.Where(m => m.GianHangId == mon.GianHangId && m.Id != mon.Id && m.ConHang && !m.TamNgungBan).ToList();
        if (cungQuan.Count == 0) return new();
        var don = TimKiemService.DonTinhBanChay().Where(d => d.GianHangId == mon.GianHangId && d.ChiTiet.Any(c => c.MonAn?.Id == mon.Id)).ToList();
        var chung = don.SelectMany(d => d.ChiTiet.Where(c => c.MonAn is not null && c.MonAn.Id != mon.Id).Select(c => c.MonAn.Id).Distinct())
            .GroupBy(x => x).ToDictionary(g => g.Key, g => g.Count());
        var banChay = TimKiemService.DaBanTheoMon(mon.GianHangId);
        return cungQuan
            .Select(m => (Mon: m, Chung: chung.GetValueOrDefault(m.Id), Ban: banChay.GetValueOrDefault(m.Id),
                          KhacMuc: !string.Equals(m.DanhMuc, mon.DanhMuc, StringComparison.OrdinalIgnoreCase)))
            .OrderByDescending(x => x.Chung).ThenByDescending(x => x.KhacMuc).ThenByDescending(x => x.Ban)
            .Take(n)
            .Select(x => (x.Mon, x.Chung > 0 ? $"{x.Chung} đơn gọi cùng" : x.Ban > 0 ? $"🔥 Đã bán {x.Ban}" : x.Mon.DanhMuc))
            .ToList();
    }

    /// <summary>Đơn của khách (nhận diện theo email), mới nhất trước, bỏ đơn hủy.</summary>
    private static IEnumerable<DonHang> DonCuaKhach(string? email) =>
        MockData.LichSuDonHang.Concat(MockData.DonHangCuaGianHang).GroupBy(d => d.Id).Select(g => g.First())
            .Where(d => !string.IsNullOrEmpty(email) && string.Equals(d.KhachEmail, email, StringComparison.OrdinalIgnoreCase)
                        && d.TrangThai != TrangThaiDonHang.DaHuy && d.ChiTiet.Count > 0)
            .OrderByDescending(d => d.NgayDat);

    /// <summary>Mỗi quán lấy đơn gần nhất của khách (tối đa n quán) để hiện mục "Đặt lại".</summary>
    public static List<DonHang> DonGanDay(string? email, int n = 5)
    {
        var quanOk = MockData.DanhSachGianHang.Where(TimKiemService.QuanHienThi).Select(g => g.Id).ToHashSet();
        return DonCuaKhach(email).Where(d => quanOk.Contains(d.GianHangId)).GroupBy(d => d.GianHangId).Select(g => g.First()).Take(n).ToList();
    }

    /// <summary>
    /// Quán được đề xuất (chỉ quán đang mở): điểm = đánh giá làm mượt (Bayes) + độ bán chạy (log) + có khuyến mãi + quán khách đã đặt
    /// − phạt khoảng cách (khi biết). Trả kèm lý do để hiển thị. Là xếp hạng thống kê, không phải cam kết chất lượng.
    /// </summary>
    public static List<(QuanKetQua Q, string LyDo)> QuanDeXuat(string? email, int n = 6)
    {
        var daDat = DonCuaKhach(email).GroupBy(d => d.GianHangId).ToDictionary(g => g.Key, g => g.Count());
        var kq = new List<(QuanKetQua Q, string LyDo, double Diem)>();
        foreach (var q in TimKiemService.Tim(new BoLocTimKiem()))
        {
            if (!q.DangMo || !q.Gh.DangNhanDon) continue;
            var sao = q.SoDanhGia > 0 ? q.Sao : q.Gh.DanhGia;
            var w = q.SoDanhGia > 0 ? q.SoDanhGia : (q.Gh.DanhGia > 0 ? 1 : 0);
            var saoMuot = (sao * w + 4.0 * 3) / (w + 3);
            daDat.TryGetValue(q.Gh.Id, out var lanDat);
            var diem = saoMuot + Math.Log(1 + q.DaBan) * 0.35 + (q.CoKhuyenMai ? 0.3 : 0) + Math.Min(lanDat, 3) * 0.25
                       - (q.Km is { } km ? Math.Min(km, 10) * 0.05 : 0);
            var ly = new List<string>();
            if (lanDat > 0) ly.Add($"bạn đã đặt {lanDat} lần");
            if (w > 0 && sao >= 4) ly.Add($"đánh giá {sao:0.0}★");
            if (q.DaBan >= 5) ly.Add("bán chạy");
            if (q.CoKhuyenMai) ly.Add("có ưu đãi");
            if (q.Km is { } k2 && k2 <= 3) ly.Add($"gần ({k2:0.#} km)");
            kq.Add((q, ly.Count == 0 ? "đang mở cửa" : string.Join(" · ", ly), diem));
        }
        return kq.OrderByDescending(x => x.Diem).Take(n).Select(x => (x.Q, x.LyDo)).ToList();
    }

    /// <summary>Đưa các món của đơn cũ vào giỏ (bỏ món đã hết/ngừng bán). Trả (số món đã thêm, số món bỏ qua).</summary>
    public static (int Them, int BoQua) DatLai(DonHang don)
    {
        int them = 0, bo = 0;
        foreach (var c in don.ChiTiet)
        {
            var mon = MockData.DanhSachMonAn.FirstOrDefault(m => m.Id == c.MonAn?.Id);
            if (mon is null || !mon.ConHang || mon.TamNgungBan) { bo++; continue; }
            GioHangService.Them(mon, c.SoLuong, c.GhiChu);
            them++;
        }
        return (them, bo);
    }
}
