namespace FoodApp.Maui.Services;

public sealed class GoongTrangThaiDto
{
    public bool DaCauHinh { get; set; }
    public string KhoaDaAn { get; set; } = "";
    public string Nguon { get; set; } = "";
}

/// <summary>Quản lý khóa Goong từ ứng dụng quản trị (chỉ Admin tổng). Máy chủ không bao giờ trả khóa đầy đủ.</summary>
public static class GoongKhoaService
{
    private const string Url = "api/mobile/admin/goong";
    private sealed class KqLuu { public string ThongDiep { get; set; } = ""; public GoongTrangThaiDto? TrangThai { get; set; } }
    private sealed class KqThu { public bool Ok { get; set; } public string ThongDiep { get; set; } = ""; }

    public static Task<ApiKetQua<GoongTrangThaiDto>> XemAsync() => ApiClient.GetAsync<GoongTrangThaiDto>(Url);

    public static async Task<(bool Ok, string ThongDiep, GoongTrangThaiDto? TrangThai)> LuuAsync(string khoa)
    {
        var r = await ApiClient.PutAsync<KqLuu>(Url, new { khoa });
        if (r.ThanhCong) NhatKyService.GhiQuanTri(string.IsNullOrWhiteSpace(khoa) ? "Xóa khóa bản đồ Goong" : "Cập nhật khóa bản đồ Goong");
        return (r.ThanhCong, r.ThanhCong ? r.DuLieu?.ThongDiep ?? "" : r.ThongDiep, r.DuLieu?.TrangThai);
    }

    public static async Task<(bool Ok, string ThongDiep)> KiemTraAsync()
    {
        var r = await ApiClient.PostAsync<KqThu>(Url + "/kiem-tra", null);
        return r.ThanhCong && r.DuLieu is { } d ? (d.Ok, d.ThongDiep) : (false, r.ThongDiep);
    }
}
