﻿using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace FoodApp.Maui.Services;

public sealed record ApiKetQua<T>(bool ThanhCong, T? DuLieu, string ThongDiep, bool MatKetNoi = false, int MaHttp = 0);

/// <summary>Gọi Web API (FoodServiceApp.Web). Mọi lỗi mạng được gói lại, không ném exception ra màn hình.</summary>
public static class ApiClient
{
    private static readonly JsonSerializerOptions Json = new()
    {
        PropertyNameCaseInsensitive = true,
        Converters = { new JsonStringEnumConverter(), new ChuoiLinhHoatConverter() }
    };

    private static HttpClient? _http;
    private static HttpClient Http => _http ??= Tao();

    private static string? _token;
    private static int _daBaoHetPhien;

    /// <summary>JWT của phiên hiện tại. Gán token mới (đăng nhập lại) sẽ bật lại cảnh báo hết phiên.</summary>
    public static string? Token
    {
        get => _token;
        set
        {
            _token = value;
            if (!string.IsNullOrEmpty(value)) Interlocked.Exchange(ref _daBaoHetPhien, 0);
            // Có JWT -> mở kênh thời gian thực; đăng xuất (null) -> đóng.
            if (!string.IsNullOrEmpty(value)) RealtimeService.Bat(); else RealtimeService.Tat();
        }
    }

    /// <summary>Phát khi máy chủ trả 401 cho một phiên đang đăng nhập (token hết hạn/bị thu hồi). Chỉ phát một lần mỗi phiên.</summary>
    public static event Action? PhienHetHan;

    private static bool LaPhienHetHan(System.Net.HttpStatusCode ma, bool coToken, string url)
    {
        if (ma != System.Net.HttpStatusCode.Unauthorized || !coToken) return false;
        if (url.Contains("dang-nhap", StringComparison.OrdinalIgnoreCase) || url.Contains("dang-ky", StringComparison.OrdinalIgnoreCase)) return false;
        if (Interlocked.Exchange(ref _daBaoHetPhien, 1) == 0)
        {
            _token = null;
            RealtimeService.Tat();
            try { PhienHetHan?.Invoke(); } catch { /* không để lỗi giao diện làm hỏng luồng gọi API */ }
        }
        return true;
    }

    /// <summary>Tạo lại HttpClient (sau khi đổi địa chỉ máy chủ).</summary>
    public static void TaiLai()
    {
        _http?.Dispose(); _http = null;
        if (!string.IsNullOrEmpty(_token)) RealtimeService.Bat();      // đổi máy chủ: nối lại kênh thời gian thực
    }

    private static HttpClient Tao()
    {
        var handler = new HttpClientHandler();
#if DEBUG
        // Chứng chỉ https dev của ASP.NET không được máy ảo/Android tin cậy.
        if (AppSettings.ChoPhepChungChiTuKy)
            handler.ServerCertificateCustomValidationCallback = (_, _, _, _) => true;
#endif
        var c = new HttpClient(handler)
        {
            // Production/Staging chưa cấu hình https → địa chỉ "không tồn tại" để mọi yêu cầu thất bại gọn (app báo mất kết nối),
            // thay vì rơi về localhost hay ném UriFormatException.
            BaseAddress = new Uri(AppSettings.CauHinhMayChuThieu ? "https://may-chu-chua-cau-hinh.invalid/" : AppSettings.BaseUrl.TrimEnd('/') + "/"),
            Timeout = TimeSpan.FromSeconds(AppSettings.Api.TimeoutGiay)
        };
        // v69: tên thiết bị để máy chủ hiện trong "Phiên đăng nhập" (chỉ ký tự ASCII để hợp lệ trong header).
        try
        {
            var tb = $"{DeviceInfo.Current.Manufacturer} {DeviceInfo.Current.Model} ({DeviceInfo.Current.Platform} {DeviceInfo.Current.VersionString})";
            tb = new string(tb.Where(ch => ch >= 32 && ch < 127).ToArray());
            c.DefaultRequestHeaders.TryAddWithoutValidation("X-Thiet-Bi", tb);
        }
        catch { }
        return c;
    }

    public static Task<ApiKetQua<T>> GetAsync<T>(string url) => GuiAsync<T>(HttpMethod.Get, url, null);
    public static Task<ApiKetQua<T>> PostAsync<T>(string url, object? body) => GuiAsync<T>(HttpMethod.Post, url, body);
    public static Task<ApiKetQua<T>> PutAsync<T>(string url, object? body) => GuiAsync<T>(HttpMethod.Put, url, body);
    public static Task<ApiKetQua<T>> DeleteAsync<T>(string url) => GuiAsync<T>(HttpMethod.Delete, url, null);

    /// <summary>Tải một tệp lên (multipart/form-data, trường mặc định "file") — vd POST api/mobile/don-hang/{id}/bang-chung.</summary>
    public static async Task<ApiKetQua<T>> PostFileAsync<T>(string url, string duongDanTep, string tenTruong = "file")
    {
        try
        {
            await using var luong = File.OpenRead(duongDanTep);
            using var noiDung = new MultipartFormDataContent();
            var phan = new StreamContent(luong);
            var duoi = Path.GetExtension(duongDanTep).ToLowerInvariant();
            phan.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(duoi switch
            {
                ".png" => "image/png", ".webp" => "image/webp", ".gif" => "image/gif", _ => "image/jpeg"
            });
            noiDung.Add(phan, tenTruong, Path.GetFileName(duongDanTep));

            using var req = new HttpRequestMessage(HttpMethod.Post, url.TrimStart('/')) { Content = noiDung };
            if (!string.IsNullOrEmpty(Token)) req.Headers.Authorization = new("Bearer", Token);
            var coToken = !string.IsNullOrEmpty(Token);
            using var res = await Http.SendAsync(req);
            var text = await res.Content.ReadAsStringAsync();
            if (LaPhienHetHan(res.StatusCode, coToken, url)) return new(false, default, "Phiên đăng nhập đã hết hạn, vui lòng đăng nhập lại.");
            if (!res.IsSuccessStatusCode) return new(false, default, DocThongDiepLoi(text, (int)res.StatusCode));
            if (string.IsNullOrWhiteSpace(text) || typeof(T) == typeof(object)) return new(true, default, "");
            return new(true, JsonSerializer.Deserialize<T>(text, Json), "");
        }
        catch (IOException ex) { return new(false, default, "Không đọc được tệp ảnh: " + ex.Message); }
        catch (TaskCanceledException) { return new(false, default, "Máy chủ phản hồi quá lâu", true); }
        catch (HttpRequestException ex) { return new(false, default, "Không kết nối được máy chủ: " + ex.Message, true); }
        catch (JsonException) { return new(false, default, "Dữ liệu máy chủ trả về không đúng định dạng"); }
    }

    private const string LoiKhongKetNoi = "Không kết nối được máy chủ";

    /// <summary>Gửi yêu cầu, ghi số liệu giám sát; GET gặp lỗi kết nối tức thời (không phải quá thời gian) được thử lại 1 lần.
    /// POST/PUT KHÔNG tự thử lại để không tạo thao tác trùng (đặt đơn đã có mã yêu cầu chống trùng riêng).</summary>
    private static async Task<ApiKetQua<T>> GuiAsync<T>(HttpMethod method, string url, object? body)
    {
        var sw = System.Diagnostics.Stopwatch.StartNew();
        // Đường dẫn chuẩn (api/restaurants, api/orders, ...) trước; máy chủ chưa có thì dùng đường dẫn cũ api/mobile/...
        ApiKetQua<T> kq;
        var chuan = ApiChuan.Dich(method, url);
        if (chuan is { } c)
        {
            kq = await GuiMotLanAsync<T>(c.Method, c.Url, body);
            if (ApiChuan.NenDungDuongCu(kq)) kq = await GuiMotLanAsync<T>(method, url, body);
        }
        else kq = await GuiMotLanAsync<T>(method, url, body);
        if (!kq.ThanhCong && kq.MatKetNoi && method == HttpMethod.Get && kq.ThongDiep.StartsWith(LoiKhongKetNoi))
        {
            await Task.Delay(500);
            kq = await GuiMotLanAsync<T>(method, url, body);
        }
        sw.Stop();
        GiamSatService.Ghi(method.Method, url, kq.ThanhCong ? 200 : kq.MaHttp, sw.ElapsedMilliseconds, !kq.ThanhCong, kq.MatKetNoi, kq.ThongDiep);
        return kq;
    }

    private static async Task<ApiKetQua<T>> GuiMotLanAsync<T>(HttpMethod method, string url, object? body)
    {
        try
        {
            using var req = new HttpRequestMessage(method, url.TrimStart('/'));
            if (!string.IsNullOrEmpty(Token))
                req.Headers.Authorization = new("Bearer", Token);
            if (body is not null)
                req.Content = JsonContent.Create(body, options: Json);

            var coToken = !string.IsNullOrEmpty(Token);
            using var res = await Http.SendAsync(req);
            var text = await res.Content.ReadAsStringAsync();

            if (LaPhienHetHan(res.StatusCode, coToken, url))
                return new(false, default, "Phiên đăng nhập đã hết hạn, vui lòng đăng nhập lại.", false, 401);

            // 401 khi KHÔNG có token (đăng nhập ngoại tuyến, hoặc phiên đã bị xóa sau lần hết hạn trước) -> báo đúng nguyên nhân thay vì "Sai tài khoản hoặc mật khẩu".
            if (res.StatusCode == System.Net.HttpStatusCode.Unauthorized && !coToken
                && !url.Contains("dang-nhap", StringComparison.OrdinalIgnoreCase) && !url.Contains("dang-ky", StringComparison.OrdinalIgnoreCase))
                return new(false, default, "Chưa đăng nhập với máy chủ hoặc phiên đã hết hạn. Hãy đăng xuất rồi đăng nhập lại khi Web đang chạy.", false, 401);

            if (!res.IsSuccessStatusCode)
                return new(false, default, DocThongDiepLoi(text, (int)res.StatusCode), false, (int)res.StatusCode);

            if (string.IsNullOrWhiteSpace(text) || typeof(T) == typeof(object))
                return new(true, default, "");

            return new(true, JsonSerializer.Deserialize<T>(text, Json), "");
        }
        catch (TaskCanceledException)
        {
            return new(false, default, "Máy chủ phản hồi quá lâu", true);
        }
        catch (HttpRequestException ex)
        {
            return new(false, default, "Không kết nối được máy chủ: " + ex.Message, true);
        }
        catch (JsonException)
        {
            return new(false, default, "Dữ liệu máy chủ trả về không đúng định dạng");
        }
        catch (Exception ex) when (ex is InvalidOperationException or UriFormatException or ObjectDisposedException or IOException or NotSupportedException)
        {
            // Địa chỉ máy chủ sai/HttpClient đã đóng...: coi như mất kết nối, không để văng ra giao diện.
            CrashLog.Ghi("ApiClient " + url, ex);
            return new(false, default, "Không kết nối được máy chủ: " + ex.Message, true);
        }
    }

    private static string DocThongDiepLoi(string text, int status)
    {
        try
        {
            using var doc = JsonDocument.Parse(text);
            if (doc.RootElement.ValueKind == JsonValueKind.Object)
                foreach (var k in new[] { "thongDiep", "message", "title", "error" })
                    if (doc.RootElement.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.String)
                        return v.GetString()!;
        }
        catch { }
        return status switch
        {
            401 => "Sai tài khoản hoặc mật khẩu",
            403 => "Bạn không có quyền thực hiện",
            404 => "Không tìm thấy dữ liệu",
            423 => "Tài khoản đang bị khóa tạm thời do nhập sai nhiều lần, vui lòng thử lại sau",
            429 => "Bạn thao tác quá nhanh, vui lòng thử lại sau ít phút",
            _ => $"Lỗi máy chủ ({status})"
        };
    }
}

/// <summary>SQL thường trả Id là số; model MAUI dùng string nên đọc cả hai.</summary>
public sealed class ChuoiLinhHoatConverter : JsonConverter<string>
{
    public override string? Read(ref Utf8JsonReader r, Type t, JsonSerializerOptions o) => r.TokenType switch
    {
        JsonTokenType.String => r.GetString(),
        JsonTokenType.Number => r.TryGetInt64(out var l) ? l.ToString() : r.GetDouble().ToString(),
        JsonTokenType.True => "true",
        JsonTokenType.False => "false",
        _ => null
    };
    public override void Write(Utf8JsonWriter w, string v, JsonSerializerOptions o) => w.WriteStringValue(v);
}
