using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>
/// Đồng bộ dữ liệu SQL (qua API) vào MockData để các màn hình dùng chung.
/// Nếu không kết nối được API thì giữ nguyên dữ liệu mẫu (chế độ demo ngoại tuyến).
/// </summary>
public static class DuLieuService
{
    public static bool DangOnline { get; private set; }

    /// <summary>Tải gian hàng, món ăn, khuyến mãi. Trả về false nếu không có API.</summary>
    public static async Task<bool> TaiDanhMucAsync()
    {
        var gh = await ApiClient.GetAsync<List<GianHang>>("api/mobile/gian-hang");
        if (!gh.ThanhCong || gh.DuLieu is null) { DangOnline = false; return false; }

        DangOnline = true;
        ThayThe(MockData.DanhSachGianHang, gh.DuLieu);

        var mon = await ApiClient.GetAsync<List<MonAn>>("api/mobile/mon-an");
        if (mon.ThanhCong && mon.DuLieu is not null)
        {
            ThayThe(MockData.DanhSachMonAn, mon.DuLieu);
            MonMoiService.CapNhat(MockData.DanhSachMonAn);      // v90: gắn nhãn "Món mới"
            MockData.DanhMucTheoGianHang.Clear();
            foreach (var nhom in mon.DuLieu.GroupBy(m => m.GianHangId))
                MockData.DanhMucTheoGianHang[nhom.Key] =
                    nhom.Select(m => m.DanhMuc).Where(s => !string.IsNullOrWhiteSpace(s)).Distinct().ToList();
        }

        var km = await ApiClient.GetAsync<List<KhuyenMai>>("api/mobile/khuyen-mai");
        if (km.ThanhCong && km.DuLieu is not null)
            ThayThe(MockData.DanhSachKhuyenMai, km.DuLieu);

        if (MockData.DanhSachGianHang.Count > 0 &&
            MockData.DanhSachGianHang.All(g => g.Id != MockData.GianHangHienTai?.Id))
            MockData.GianHangHienTai = MockData.DanhSachGianHang[0];

        return true;
    }

    /// <summary>v90: làm mới món ăn (giá, tình trạng còn/hết) ngay trước khi đặt. Không đổi trạng thái online/offline của app.</summary>
    public static async Task<bool> LamMoiMonAnAsync()
    {
        if (!DangOnline) return false;
        var mon = await ApiClient.GetAsync<List<MonAn>>("api/mobile/mon-an");
        if (!mon.ThanhCong || mon.DuLieu is null) return false;
        ThayThe(MockData.DanhSachMonAn, mon.DuLieu);
        MonMoiService.CapNhat(MockData.DanhSachMonAn);
        return true;
    }

    public static async Task TaiDonHangKhachAsync()
    {
        if (!DangOnline) return;
        var r = await ApiClient.GetAsync<List<DonHang>>("api/mobile/khach-hang/don-hang");
        if (r.ThanhCong && r.DuLieu is not null) ThayThe(MockData.LichSuDonHang, r.DuLieu);
    }

    public static async Task TaiDonHangGianHangAsync(string gianHangId)
    {
        if (!DangOnline) return;
        var r = await ApiClient.GetAsync<List<DonHang>>($"api/mobile/gian-hang/{gianHangId}/don-hang");
        if (r.ThanhCong && r.DuLieu is not null) ThayThe(MockData.DonHangCuaGianHang, r.DuLieu);
    }

    /// <summary>Tài xế (online): lấy đơn đã sẵn sàng giao từ API và thêm vào hàng đợi (không ghi đè đơn đang xử lý).</summary>
    public static async Task TaiDonChoTaiXeAsync()
    {
        if (!DangOnline) return;
        var r = await ApiClient.GetAsync<List<DonHang>>("api/mobile/tai-xe/don-cho-nhan");
        if (!r.ThanhCong || r.DuLieu is null) return;
        foreach (var d in r.DuLieu)
        {
            var cu = MockData.DonHangChoTaiXe.FirstOrDefault(x => x.Id == d.Id);
            if (cu is not null) { cu.HanPhanHoiLuc = d.HanPhanHoiLuc; continue; }     // cập nhật hạn phản hồi cho đơn đã có
            if (MockData.DonHangDaGiaoCuaTaiXe.All(x => x.Id != d.Id))
                MockData.DonHangChoTaiXe.Add(d);
        }
    }

    public static async Task TaiQuanTriAsync()
    {
        if (!DangOnline) return;
        var kh = await ApiClient.GetAsync<List<KhachHang>>("api/mobile/admin/khach-hang");
        if (kh.ThanhCong && kh.DuLieu is not null) ThayThe(MockData.DanhSachKhachHang, kh.DuLieu);
        var vd = await ApiClient.GetAsync<List<VanDeHeThong>>("api/mobile/admin/van-de");
        if (vd.ThanhCong && vd.DuLieu is not null) ThayThe(MockData.DanhSachVanDe, vd.DuLieu);
        await TaiDonToanHeThongAsync();
    }

    /// <summary>Quản trị: nạp toàn bộ đơn thật từ SQL Server cho màn thống kê.</summary>
    public static async Task TaiDonToanHeThongAsync()
    {
        if (!DangOnline) return;
        var r = await ApiClient.GetAsync<List<DonHang>>("api/mobile/admin/don-hang");
        if (r.ThanhCong && r.DuLieu is not null) ThayThe(MockData.DonHangHeThongTuMayChu, r.DuLieu);
    }

    /// <summary>Tài xế: nạp lịch sử chuyến đã xong từ SQL Server (thu nhập, đánh giá, thống kê).</summary>
    public static async Task TaiDonDaGiaoTaiXeAsync()
    {
        if (!DangOnline) return;
        var r = await ApiClient.GetAsync<List<DonHang>>("api/mobile/tai-xe/don-da-giao");
        if (r.ThanhCong && r.DuLieu is not null) ThayThe(MockData.DonHangDaGiaoCuaTaiXe, r.DuLieu);
    }

    // ===== Kết quả ghi: PHẢI phân biệt 3 tình huống, không dùng chung một thông báo "thành công" =====
    //  DaDongBo   : máy chủ đã nhận và lưu.
    //  LuuTrenMay : đang ngoại tuyến (demo) — thay đổi chỉ nằm trên máy này, CHƯA gửi lên máy chủ.
    //  ThatBai    : máy chủ từ chối / không gọi được — thay đổi KHÔNG được ghi (đã báo lỗi cho người dùng).
    public enum KetQuaGhi { DaDongBo, LuuTrenMay, ThatBai }

    /// <summary>Kết quả của lần ghi gần nhất (để màn hình chọn nội dung thông báo cho đúng).</summary>
    public static KetQuaGhi LanGhiCuoi { get; private set; } = KetQuaGhi.DaDongBo;

    /// <summary>Câu cảnh báo thêm vào mọi thông báo "thành công" khi thay đổi chỉ lưu trên máy.</summary>
    public const string CanhBaoNgoaiTuyen = "⚠ Đang ngoại tuyến: thay đổi mới chỉ lưu trên máy này, CHƯA gửi lên máy chủ.";

    /// <summary>
    /// Gọi SAU khi ghi thành công: nếu lần ghi vừa rồi chỉ lưu trên máy thì kèm cảnh báo ngoại tuyến,
    /// ngược lại giữ nguyên thông báo (đã đồng bộ máy chủ).
    /// </summary>
    public static string ChuThichGhi(string thongDiep) =>
        LanGhiCuoi == KetQuaGhi.LuuTrenMay ? thongDiep + "\n\n" + CanhBaoNgoaiTuyen : thongDiep;

    /// <summary>Ghi thay đổi lên API (PUT/POST) và trả về trạng thái 3 mức. Lỗi: tự báo người dùng.</summary>
    public static async Task<KetQuaGhi> GhiTrangThaiAsync(string method, string url, object? body = null)
    {
        if (!DangOnline) return LanGhiCuoi = KetQuaGhi.LuuTrenMay;
        var kq = method == "POST"
            ? await ApiClient.PostAsync<object>(url, body)
            : await ApiClient.PutAsync<object>(url, body);
        if (!kq.ThanhCong && Application.Current?.MainPage is { } p)
            await p.DisplayAlert("Không lưu được", kq.ThongDiep, "OK");
        return LanGhiCuoi = kq.ThanhCong ? KetQuaGhi.DaDongBo : KetQuaGhi.ThatBai;
    }

    /// <summary>
    /// Ghi lên API. true = không bị máy chủ từ chối (đã đồng bộ HOẶC đang ngoại tuyến — xem <see cref="LanGhiCuoi"/>
    /// và <see cref="ChuThichGhi"/> để thông báo đúng). false = thất bại.
    /// </summary>
    public static async Task<bool> GhiAsync(string method, string url, object? body = null)
        => await GhiTrangThaiAsync(method, url, body) != KetQuaGhi.ThatBai;

    /// <summary>
    /// Như <see cref="GhiAsync"/> nhưng khi THẤT BẠI thì chạy <paramref name="hoanTac"/> để trả lại thay đổi đã áp dụng
    /// trên máy trước khi gọi máy chủ (tránh máy hiển thị đã đổi trong khi máy chủ chưa đổi).
    /// </summary>
    public static async Task<bool> GhiHoanTacAsync(string method, string url, object? body, Action hoanTac)
    {
        if (await GhiTrangThaiAsync(method, url, body) != KetQuaGhi.ThatBai) return true;
        hoanTac();
        return false;
    }

    /// <summary>Như <see cref="GhiAsync"/> nhưng trả cả dữ liệu server gửi lại (vd da-lay-hang trả coMaXacNhan). Offline: (true, null).</summary>
    public static async Task<(bool ThanhCong, T? DuLieu)> GhiLayAsync<T>(string method, string url, object? body = null)
    {
        if (!DangOnline) { LanGhiCuoi = KetQuaGhi.LuuTrenMay; return (true, default); }
        var kq = method == "POST" ? await ApiClient.PostAsync<T>(url, body) : await ApiClient.PutAsync<T>(url, body);
        if (!kq.ThanhCong && Application.Current?.MainPage is { } p)
            await p.DisplayAlert("Không lưu được", kq.ThongDiep, "OK");
        LanGhiCuoi = kq.ThanhCong ? KetQuaGhi.DaDongBo : KetQuaGhi.ThatBai;
        return (kq.ThanhCong, kq.DuLieu);
    }

    /// <summary>Tài xế tải ảnh bằng chứng giao hàng lên server (POST api/mobile/don-hang/{id}/bang-chung). Offline: bỏ qua, trả true (LanGhiCuoi = LuuTrenMay).</summary>
    public static async Task<bool> TaiBangChungAsync(string donId, string duongDanAnh, bool baoLoi = true)
    {
        if (!DangOnline) { LanGhiCuoi = KetQuaGhi.LuuTrenMay; return true; }
        var kq = await ApiClient.PostFileAsync<object>($"api/mobile/don-hang/{donId}/bang-chung", duongDanAnh);
        if (!kq.ThanhCong && baoLoi && Application.Current?.MainPage is { } p)
            await p.DisplayAlert("Không tải được ảnh", kq.ThongDiep, "OK");
        LanGhiCuoi = kq.ThanhCong ? KetQuaGhi.DaDongBo : KetQuaGhi.ThatBai;
        return kq.ThanhCong;
    }

    private static void ThayThe<T>(IList<T> dich, IEnumerable<T> nguon)
    {
        var moi = nguon.ToList();
        dich.Clear();
        foreach (var x in moi) dich.Add(x);
    }
}

public class DangNhapKhachDto { public string? Token { get; set; } public KhachHang? KhachHang { get; set; } }
public class DangNhapGianHangDto { public string? Token { get; set; } public GianHang? GianHang { get; set; } public NhanVienDto? NhanVien { get; set; } }
public class DangNhapQuanTriDto { public string? Token { get; set; } public string? VaiTro { get; set; } public string? HoTen { get; set; } public List<string>? Quyen { get; set; } }
public class DaLayHangDto { public bool CoMaXacNhan { get; set; } }
public class DatHangDto { public string? Id { get; set; } public string? MaXacNhanGiao { get; set; } public decimal? TongTien { get; set; } public string? PaymentUrl { get; set; } public decimal? PhiGiaoHang { get; set; } public double? KhoangCachKm { get; set; } public int? ThoiGianDuKienPhut { get; set; } public bool? DaXacMinhTuyen { get; set; } }
