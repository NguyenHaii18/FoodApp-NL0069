using System.Text.Json;
using Microsoft.Maui.Devices.Sensors;
using FoodApp.Maui.Views;

namespace FoodApp.Maui.Services;

/// <summary>
/// v86 — Nhịp kết nối của tài xế (heartbeat) và nhận ĐỀ NGHỊ GIAO ĐƠN từ hệ thống phân phối.
/// Khi tài xế đang Online: cứ ~20 giây báo "còn kết nối" kèm vị trí GPS lên máy chủ (để hệ thống biết ai còn trực tuyến, ai mất GPS/mạng).
/// Phản hồi của nhịp cho biết có đề nghị đang chờ không, nên dù kênh thời gian thực đứt vẫn nhận được đề nghị.
/// Đề nghị hiện dưới dạng cửa sổ có đếm ngược (<see cref="DriverOfferPopupPage"/>) trên mọi màn hình.
/// </summary>
public static class DriverPresenceService
{
    private static IDispatcherTimer? _timer;
    private static bool _bat, _dangGoi, _dangMo;

    public static string TrangThai { get; private set; } = "Chưa gửi nhịp kết nối";
    public static DateTime? LanCuoi { get; private set; }

    public static void CapNhat(bool online) { if (online) Bat(); else Tat(); }

    public static void Bat()
    {
        if (_bat) { _ = NhipAsync(); return; }
        var dp = Application.Current?.Dispatcher;
        if (dp is null) return;
        _bat = true;
        DriverCaLamViecService.BatDauPhien();
        DriverCanhBaoService.Bat();
        _ = DriverCaLamViecService.KhoiPhucAsync();
        _timer ??= dp.CreateTimer();
        _timer.Interval = TimeSpan.FromSeconds(20);
        _timer.Tick -= OnTick;
        _timer.Tick += OnTick;
        _timer.Start();
        RealtimeService.CoThayDoi -= OnRealtime;
        RealtimeService.CoThayDoi += OnRealtime;
        _ = NhipAsync();
    }

    public static void Tat()
    {
        _bat = false;
        DriverCaLamViecService.KetThucPhien();
        DriverCanhBaoService.Tat();
        _timer?.Stop();
        RealtimeService.CoThayDoi -= OnRealtime;
        TrangThai = "Đã tắt (đang offline)";
    }

    private static async void OnTick(object? sender, EventArgs e) => await NhipAsync();

    private static void OnRealtime(RealtimeSuKien e)
    {
        if (e.Loai is "DriverOffer" or "DongBo") _ = KiemTraDeNghiAsync();
    }

    private static async Task NhipAsync()
    {
        if (!_bat || _dangGoi || !DuLieuService.DangOnline) return;
        _dangGoi = true;
        try
        {
            double? lat = null, lng = null;
            try
            {
                if (await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>() == PermissionStatus.Granted)
                {
                    var vt = await MainThread.InvokeOnMainThreadAsync(() =>
                        Geolocation.Default.GetLocationAsync(new GeolocationRequest(GeolocationAccuracy.Medium, TimeSpan.FromSeconds(6))));
                    if (vt is not null) { lat = vt.Latitude; lng = vt.Longitude; }
                }
            }
            catch { /* không có GPS: vẫn gửi nhịp để biết còn mạng */ }

            var kq = await ApiClient.PostAsync<JsonElement>("api/mobile/driver/nhip", new { viDo = lat, kinhDo = lng });
            if (kq.ThanhCong)
            {
                LanCuoi = DateTime.Now;
                TrangThai = lat is null ? "⚠ Đã gửi nhịp nhưng chưa có GPS — hãy bật định vị" : $"📡 Đã báo kết nối + vị trí lúc {LanCuoi:HH:mm:ss}";
                if (kq.DuLieu.ValueKind == JsonValueKind.Object && kq.DuLieu.TryGetProperty("coDeNghi", out var c) && c.ValueKind == JsonValueKind.True)
                    await KiemTraDeNghiAsync();
            }
            else TrangThai = "⚠ Chưa báo được kết nối: " + kq.ThongDiep;
        }
        catch (Exception ex) { TrangThai = "⚠ " + ex.Message; }
        finally { _dangGoi = false; }
    }

    /// <summary>Hỏi máy chủ có đề nghị đang chờ không; có thì mở cửa sổ đếm ngược (mỗi lần chỉ một cửa sổ).</summary>
    public static async Task KiemTraDeNghiAsync()
    {
        if (_dangMo || !_bat) return;
        var r = await ApiClient.GetAsync<JsonElement>("api/mobile/driver/de-nghi");
        if (!r.ThanhCong || r.DuLieu.ValueKind != JsonValueKind.Object) return;
        var d = r.DuLieu;
        if (!d.TryGetProperty("coDeNghi", out var c) || c.ValueKind != JsonValueKind.True) return;
        await MainThread.InvokeOnMainThreadAsync(async () =>
        {
            if (_dangMo) return;
            _dangMo = true;
            try
            {
                var trang = Application.Current?.Windows?.FirstOrDefault()?.Page;
                if (trang?.Navigation is null) { _dangMo = false; return; }
                await trang.Navigation.PushModalAsync(new DriverOfferPopupPage(d));
            }
            catch (Exception ex) { _dangMo = false; CrashLog.Ghi("DriverOfferPopup", ex); }
        });
    }

    internal static void DaDongCuaSo() => _dangMo = false;
}
