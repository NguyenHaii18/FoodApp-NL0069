﻿using System.Text;
using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>Xuất báo cáo doanh thu ra file CSV (mở được bằng Excel) rồi mở hộp chia sẻ của hệ điều hành.</summary>
public static class BaoCaoXuatService
{
    private static string Cot(string? s)
    {
        s ??= "";
        return s.Contains('"') || s.Contains(',') || s.Contains('\n') ? "\"" + s.Replace("\"", "\"\"") + "\"" : s;
    }

    /// <summary>Hỏi định dạng (Excel .xlsx nhiều sheet / CSV) rồi xuất báo cáo doanh thu.</summary>
    public static async Task XuatAsync(Page trang)
    {
        var chon = await trang.DisplayActionSheet("Xuất báo cáo doanh thu", "Đóng", null, "Excel (.xlsx) — đơn, theo ngày, theo quán", "CSV (đơn hàng)");
        if (chon is null or "Đóng") return;
        if (chon.StartsWith("Excel")) await XuatExcelAsync(trang); else await XuatDoanhThuAsync(trang);
    }

    public static async Task XuatExcelAsync(Page trang)
    {
        if (!await PhanQuyenService.KiemTraAsync(trang, Quyen.XemThongKe)) return;
        try
        {
            await DuLieuService.TaiDonToanHeThongAsync();
            var ds = MockData.TatCaDonHangHeThong.OrderByDescending(d => d.NgayDat).ToList();
            if (ds.Count == 0) { await trang.DisplayAlert("Chưa có dữ liệu", "Chưa có đơn hàng nào để xuất báo cáo.", "Đóng"); return; }
            var xong = ds.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).ToList();

            var donHang = new List<object?[]> { new object?[] { "Mã đơn", "Ngày đặt", "Quán", "Trạng thái", "Tạm tính", "Phí giao", "Giảm giá", "Thanh toán", "Hình thức" } };
            donHang.AddRange(ds.Select(d => new object?[] { d.Id, d.NgayDat.ToString("dd/MM/yyyy HH:mm"), d.TenGianHang, d.TrangThai.Nhan(),
                d.TongTien, d.PhiGiaoHang, d.GiamGia, d.TongThanhToan, d.HinhThucHienThi }));
            donHang.Add(new object?[] { "Tổng doanh thu đơn hoàn thành", null, null, null, null, null, null, xong.Sum(d => d.TongThanhToan) });

            var theoNgay = new List<object?[]> { new object?[] { "Ngày", "Số đơn", "Hoàn thành", "Đã hủy", "Doanh thu (hoàn thành)" } };
            theoNgay.AddRange(ds.GroupBy(d => d.NgayDat.Date).OrderByDescending(g => g.Key).Select(g => new object?[] { g.Key.ToString("dd/MM/yyyy"), g.Count(),
                g.Count(d => d.TrangThai == TrangThaiDonHang.HoanThanh), g.Count(d => d.TrangThai == TrangThaiDonHang.DaHuy),
                g.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).Sum(d => d.TongThanhToan) }));

            var theoQuan = new List<object?[]> { new object?[] { "Quán", "Số đơn", "Hoàn thành", "Doanh thu (hoàn thành)" } };
            theoQuan.AddRange(ds.GroupBy(d => d.TenGianHang).Select(g => new
            {
                g.Key, N = g.Count(), X = g.Count(d => d.TrangThai == TrangThaiDonHang.HoanThanh),
                T = g.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).Sum(d => d.TongThanhToan)
            }).OrderByDescending(x => x.T).Select(x => new object?[] { x.Key, x.N, x.X, x.T }));

            var duongDan = Path.Combine(FileSystem.CacheDirectory, $"BaoCaoDoanhThu_{DateTime.Now:yyyyMMdd_HHmm}.xlsx");
            new XlsxWriter().ThemSheet("Don hang", donHang).ThemSheet("Theo ngay", theoNgay).ThemSheet("Theo quan", theoQuan).Luu(duongDan);
            NhatKyService.GhiQuanTri("Xuất báo cáo doanh thu (Excel)", $"{ds.Count} đơn");
            await Share.Default.RequestAsync(new ShareFileRequest { Title = "Báo cáo doanh thu", File = new ShareFile(duongDan) });
        }
        catch (Exception ex)
        {
            await trang.DisplayAlert("Không xuất được báo cáo", ex.Message, "Đóng");
        }
    }

    public static async Task XuatDoanhThuAsync(Page trang)
    {
        if (!await PhanQuyenService.KiemTraAsync(trang, Quyen.XemThongKe)) return;
        try
        {
            await DuLieuService.TaiDonToanHeThongAsync();
            var ds = MockData.TatCaDonHangHeThong.OrderByDescending(d => d.NgayDat).ToList();
            if (ds.Count == 0) { await trang.DisplayAlert("Chưa có dữ liệu", "Chưa có đơn hàng nào để xuất báo cáo.", "Đóng"); return; }

            var sb = new StringBuilder();
            sb.AppendLine("Mã đơn,Ngày đặt,Quán,Trạng thái,Tạm tính,Phí giao,Giảm giá,Thanh toán,Hình thức");
            foreach (var d in ds)
                sb.AppendLine(string.Join(",", Cot(d.Id), d.NgayDat.ToString("dd/MM/yyyy HH:mm"), Cot(d.TenGianHang), Cot(d.TrangThai.Nhan()),
                    d.TongTien.ToString("0"), d.PhiGiaoHang.ToString("0"), d.GiamGia.ToString("0"), d.TongThanhToan.ToString("0"), Cot(d.HinhThucHienThi)));
            var doanhThu = ds.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).Sum(d => d.TongThanhToan);
            sb.AppendLine($"Tổng doanh thu đơn hoàn thành,,,,,,,{doanhThu:0},");

            var duongDan = Path.Combine(FileSystem.CacheDirectory, $"BaoCaoDoanhThu_{DateTime.Now:yyyyMMdd_HHmm}.csv");
            await File.WriteAllTextAsync(duongDan, sb.ToString(), new UTF8Encoding(true));
            NhatKyService.GhiQuanTri("Xuất báo cáo doanh thu", $"{ds.Count} đơn");
            await Share.Default.RequestAsync(new ShareFileRequest { Title = "Báo cáo doanh thu", File = new ShareFile(duongDan) });
        }
        catch (Exception ex)
        {
            await trang.DisplayAlert("Không xuất được báo cáo", ex.Message, "Đóng");
        }
    }

    // ====================================================================== v81: xuất Excel theo khoảng thời gian / tài khoản
    /// <summary>Nạp dữ liệu mới nhất (online) rồi trả về false nếu không có gì để xuất.</summary>
    private static async Task NapMoiAsync()
    {
        try { await DuLieuService.TaiDanhMucAsync(); await DuLieuService.TaiQuanTriAsync(); }
        catch (Exception ex) { CrashLog.Ghi("BaoCaoXuat.NapMoi", ex); }
    }

    private static async Task ChiaSeAsync(Page trang, string tenTep, string tieuDe, XlsxWriter xlsx)
    {
        var duongDan = Path.Combine(FileSystem.CacheDirectory, $"{tenTep}_{DateTime.Now:yyyyMMdd_HHmm}.xlsx");
        xlsx.Luu(duongDan);
        await Share.Default.RequestAsync(new ShareFileRequest { Title = tieuDe, File = new ShareFile(duongDan) });
    }

    /// <summary>Doanh thu Excel: soNgay = số ngày gần nhất (1 = hôm nay); null = toàn bộ thời gian. 4 sheet: Tổng hợp, Theo ngày, Theo quán, Đơn hàng.</summary>
    public static async Task XuatDoanhThuKhoangAsync(Page trang, int? soNgay, string nhanKhoang)
    {
        if (!await PhanQuyenService.KiemTraAsync(trang, Quyen.XemThongKe)) return;
        try
        {
            await NapMoiAsync();
            var tu = soNgay is int n ? DateTime.Today.AddDays(-(n - 1)) : DateTime.MinValue;
            var ds = MockData.TatCaDonHangHeThong.ToList().Where(d => d.NgayDat.Date >= tu).OrderByDescending(d => d.NgayDat).ToList();
            if (ds.Count == 0) { await trang.DisplayAlert("Chưa có dữ liệu", $"Không có đơn hàng nào trong khoảng \"{nhanKhoang}\".", "Đóng"); return; }
            var xong = ds.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).ToList();
            var doanhThu = xong.Sum(d => d.TongThanhToan);

            var tongHop = new List<object?[]>
            {
                new object?[] { "BÁO CÁO DOANH THU", nhanKhoang },
                new object?[] { "Xuất lúc", DateTime.Now.ToString("dd/MM/yyyy HH:mm") },
                new object?[] { "Tổng số đơn", ds.Count },
                new object?[] { "Đơn hoàn thành", xong.Count },
                new object?[] { "Đơn đã hủy", ds.Count(d => d.TrangThai == TrangThaiDonHang.DaHuy) },
                new object?[] { "Đơn đang xử lý", ds.Count(d => d.TrangThai is TrangThaiDonHang.ChoXacNhan or TrangThaiDonHang.DangLam or TrangThaiDonHang.DangGiao) },
                new object?[] { "Doanh thu (đơn hoàn thành)", doanhThu },
                new object?[] { "Giá trị đơn trung bình", xong.Count == 0 ? 0m : Math.Round(doanhThu / xong.Count) },
                new object?[] { "Tổng phí giao (hoàn thành)", xong.Sum(d => d.PhiGiaoHang) },
                new object?[] { "Tổng giảm giá (hoàn thành)", xong.Sum(d => d.GiamGia) },
            };

            var theoNgay = new List<object?[]> { new object?[] { "Ngày", "Số đơn", "Hoàn thành", "Đã hủy", "Doanh thu (hoàn thành)" } };
            theoNgay.AddRange(ds.GroupBy(d => d.NgayDat.Date).OrderByDescending(g => g.Key).Select(g => new object?[]
            {
                g.Key.ToString("dd/MM/yyyy"), g.Count(), g.Count(d => d.TrangThai == TrangThaiDonHang.HoanThanh),
                g.Count(d => d.TrangThai == TrangThaiDonHang.DaHuy), g.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).Sum(d => d.TongThanhToan)
            }));
            theoNgay.Add(new object?[] { "TỔNG", ds.Count, xong.Count, ds.Count(d => d.TrangThai == TrangThaiDonHang.DaHuy), doanhThu });

            var theoQuan = new List<object?[]> { new object?[] { "Quán", "Số đơn", "Hoàn thành", "Doanh thu (hoàn thành)", "Tỷ trọng" } };
            theoQuan.AddRange(ds.GroupBy(d => d.TenGianHang).Select(g => new
            {
                g.Key, N = g.Count(), X = g.Count(d => d.TrangThai == TrangThaiDonHang.HoanThanh),
                T = g.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).Sum(d => d.TongThanhToan)
            }).OrderByDescending(x => x.T).Select(x => new object?[] { x.Key, x.N, x.X, x.T, doanhThu == 0 ? "0%" : (x.T / doanhThu).ToString("P1") }));

            var donHang = new List<object?[]> { new object?[] { "Mã đơn", "Ngày đặt", "Quán", "Khách", "Trạng thái", "Tạm tính", "Phí giao", "Giảm giá", "Thanh toán", "Hình thức" } };
            donHang.AddRange(ds.Select(d => new object?[] { d.Id, d.NgayDat.ToString("dd/MM/yyyy HH:mm"), d.TenGianHang, d.KhachTen, d.TrangThai.Nhan(),
                d.TongTien, d.PhiGiaoHang, d.GiamGia, d.TongThanhToan, d.HinhThucHienThi }));

            await ChiaSeAsync(trang, "DoanhThu", "Báo cáo doanh thu",
                new XlsxWriter().ThemSheet("Tong hop", tongHop).ThemSheet("Theo ngay", theoNgay).ThemSheet("Theo quan", theoQuan).ThemSheet("Don hang", donHang));
            NhatKyService.GhiQuanTri("Xuất Excel doanh thu", $"{nhanKhoang}: {ds.Count} đơn");
        }
        catch (Exception ex) { await trang.DisplayAlert("Không xuất được báo cáo", ex.Message, "Đóng"); }
    }

    /// <summary>Danh sách tài khoản khách hàng (không gồm mật khẩu), kèm số đơn và tổng chi tiêu tính từ đơn hoàn thành.</summary>
    public static async Task XuatKhachHangAsync(Page trang)
    {
        if (!await PhanQuyenService.KiemTraAsync(trang, Quyen.XemTaiKhoan)) return;
        try
        {
            await NapMoiAsync();
            var kh = MockData.DanhSachKhachHang.ToList();
            if (kh.Count == 0) { await trang.DisplayAlert("Chưa có dữ liệu", "Chưa có tài khoản khách hàng nào.", "Đóng"); return; }
            var don = MockData.TatCaDonHangHeThong.ToList();

            var hang = new List<object?[]> { new object?[] { "STT", "Mã KH", "Họ tên", "Email", "Số điện thoại", "Địa chỉ", "Ngày đăng ký", "Email đã xác thực", "Trạng thái", "Số đơn", "Đơn hoàn thành", "Tổng chi tiêu (hoàn thành)" } };
            var i = 0;
            foreach (var k in kh.OrderByDescending(x => x.NgayDangKy))
            {
                var cua = don.Where(d => !string.IsNullOrEmpty(k.Email) && string.Equals(d.KhachEmail, k.Email, StringComparison.OrdinalIgnoreCase)).ToList();
                var xong = cua.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).ToList();
                hang.Add(new object?[] { ++i, k.Id, k.HoTen, k.Email, k.SoDienThoai, k.DiaChi, k.NgayDangKy.ToString("dd/MM/yyyy"),
                    k.EmailDaXacThuc ? "Có" : "Chưa", k.TaiKhoanBiKhoa ? "Bị khóa" : "Hoạt động", Math.Max(k.TongSoDon, cua.Count), xong.Count, xong.Sum(d => d.TongThanhToan) });
            }
            var tomTat = new List<object?[]>
            {
                new object?[] { "TÀI KHOẢN KHÁCH HÀNG" },
                new object?[] { "Xuất lúc", DateTime.Now.ToString("dd/MM/yyyy HH:mm") },
                new object?[] { "Tổng số tài khoản", kh.Count },
                new object?[] { "Đang hoạt động", kh.Count(k => !k.TaiKhoanBiKhoa) },
                new object?[] { "Bị khóa", kh.Count(k => k.TaiKhoanBiKhoa) },
                new object?[] { "Đăng ký mới hôm nay", kh.Count(k => k.NgayDangKy.Date == DateTime.Today) },
            };
            await ChiaSeAsync(trang, "TaiKhoanKhachHang", "Danh sách khách hàng", new XlsxWriter().ThemSheet("Tong hop", tomTat).ThemSheet("Khach hang", hang));
            NhatKyService.GhiQuanTri("Xuất Excel tài khoản khách hàng", $"{kh.Count} tài khoản");
        }
        catch (Exception ex) { await trang.DisplayAlert("Không xuất được danh sách", ex.Message, "Đóng"); }
    }

    /// <summary>Danh sách tài khoản quán/gian hàng (không gồm mật khẩu, CCCD), kèm số đơn và doanh thu.</summary>
    public static async Task XuatGianHangAsync(Page trang)
    {
        if (!await PhanQuyenService.KiemTraAsync(trang, Quyen.XemTaiKhoan)) return;
        try
        {
            await NapMoiAsync();
            var gh = MockData.DanhSachGianHang.ToList();
            if (gh.Count == 0) { await trang.DisplayAlert("Chưa có dữ liệu", "Chưa có tài khoản quán nào.", "Đóng"); return; }
            var don = MockData.TatCaDonHangHeThong.ToList();

            var hang = new List<object?[]> { new object?[] { "STT", "Mã quán", "Tên quán", "Email", "Số điện thoại", "Địa chỉ", "Ngày đăng ký", "Hồ sơ", "Tài khoản", "Mở bán", "Giờ hoạt động", "Hoa hồng riêng", "Mã số thuế", "Giấy phép KD", "Số đơn", "Đơn hoàn thành", "Doanh thu (hoàn thành)" } };
            var i = 0;
            foreach (var g in gh.OrderByDescending(x => x.NgayDangKy))
            {
                var cua = don.Where(d => d.GianHangId == g.Id).ToList();
                var xong = cua.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).ToList();
                hang.Add(new object?[] { ++i, g.Id, g.TenGianHang, g.Email, g.SoDienThoai, g.DiaChi, g.NgayDangKy.ToString("dd/MM/yyyy"),
                    g.TrangThaiDangKy.Nhan(), g.TaiKhoanBiKhoa ? "Bị khóa" : "Hoạt động", g.DangMoCua ? "Đang mở" : "Tạm đóng",
                    $"{g.GioMoCua} - {g.GioDongCua}", g.TyLeChietKhau is decimal t ? t.ToString("0.##") + "%" : "Mặc định",
                    g.MaSoThue, g.SoGiayPhepKinhDoanh, cua.Count, xong.Count, xong.Sum(d => d.TongThanhToan) });
            }
            var tomTat = new List<object?[]>
            {
                new object?[] { "TÀI KHOẢN QUÁN / GIAN HÀNG" },
                new object?[] { "Xuất lúc", DateTime.Now.ToString("dd/MM/yyyy HH:mm") },
                new object?[] { "Tổng số quán", gh.Count },
                new object?[] { "Đã duyệt", gh.Count(g => g.TrangThaiDangKy == TrangThaiDangKyGianHang.DaDuyet) },
                new object?[] { "Chờ duyệt", gh.Count(g => g.TrangThaiDangKy == TrangThaiDangKyGianHang.ChoDuyet) },
                new object?[] { "Bị từ chối", gh.Count(g => g.TrangThaiDangKy == TrangThaiDangKyGianHang.TuChoi) },
                new object?[] { "Tài khoản bị khóa", gh.Count(g => g.TaiKhoanBiKhoa) },
            };
            await ChiaSeAsync(trang, "TaiKhoanQuan", "Danh sách quán", new XlsxWriter().ThemSheet("Tong hop", tomTat).ThemSheet("Quan", hang));
            NhatKyService.GhiQuanTri("Xuất Excel tài khoản quán", $"{gh.Count} quán");
        }
        catch (Exception ex) { await trang.DisplayAlert("Không xuất được danh sách", ex.Message, "Đóng"); }
    }
}
