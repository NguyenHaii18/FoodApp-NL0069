using System.Globalization;
using System.Text.Json;

namespace FoodApp.Maui.Services;

/// <summary>
/// v90: "Voucher của tôi" (lưu trên máy theo tài khoản) và ngày sinh để nhận ưu đãi sinh nhật.
/// Nhận voucher = lưu mã để dùng nhanh; việc mã còn dùng được hay không vẫn do máy chủ quyết định lúc thanh toán.
/// </summary>
public static class VoucherCuaToiService
{
    private static string Chu() => Phien.Khach?.Email?.ToLowerInvariant() is { Length: > 0 } e ? e : "khach";

    public static List<string> DanhSach()
    {
        try { return JsonSerializer.Deserialize<List<string>>(Preferences.Default.Get("voucher-cua-toi:" + Chu(), "[]")) ?? new(); }
        catch { return new(); }
    }

    public static bool DaNhan(string? ma) => !string.IsNullOrWhiteSpace(ma) && DanhSach().Contains(ma.Trim(), StringComparer.OrdinalIgnoreCase);

    public static void Nhan(string ma)
    {
        var ds = DanhSach();
        if (ds.Contains(ma.Trim(), StringComparer.OrdinalIgnoreCase)) return;
        ds.Insert(0, ma.Trim());
        Preferences.Default.Set("voucher-cua-toi:" + Chu(), JsonSerializer.Serialize(ds));
    }

    public static void Bo(string ma)
    {
        var ds = DanhSach();
        if (ds.RemoveAll(x => string.Equals(x, ma, StringComparison.OrdinalIgnoreCase)) > 0)
            Preferences.Default.Set("voucher-cua-toi:" + Chu(), JsonSerializer.Serialize(ds));
    }

    // ---- ngày sinh
    public static DateTime? NgaySinh
    {
        get => DateTime.TryParseExact(Preferences.Default.Get("ngay-sinh:" + Chu(), ""), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d) ? d : null;
        set { if (value is { } v) Preferences.Default.Set("ngay-sinh:" + Chu(), v.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)); else Preferences.Default.Remove("ngay-sinh:" + Chu()); }
    }

    public static bool DangThangSinhNhat => NgaySinh is { } n && n.Month == DateTime.Now.Month;
}
