using FoodApp.Maui.Models;
using FoodApp.Maui.Views;   // UploadAnhDto (khai báo trong Views/DriverProfilePage.xaml.cs)

namespace FoodApp.Maui.Services;

/// <summary>v68 — Đồng bộ thực đơn của quán với máy chủ (api/mobile/gian-hang/{id}/...). Khi ONLINE máy chủ là nguồn đúng:
/// mọi thay đổi gửi lên máy chủ trước, bị từ chối hoặc mất mạng thì KHÔNG lưu trên máy (tránh bị ghi đè âm thầm ở lần đồng bộ sau).
/// Khi ngoại tuyến: giữ hành vi cũ (lưu trên máy). Món tạo lúc ngoại tuyến (Id không phải số) được đẩy lên ở lần đồng bộ kế tiếp.</summary>
public static class VendorThucDonService
{
    private sealed class DanhMucDto { public string Ten { get; set; } = ""; public bool DaAn { get; set; } }
    private sealed class ThucDonDto { public List<DanhMucDto> DanhMuc { get; set; } = new(); public List<MonAn> Mon { get; set; } = new(); }
    private sealed class KetQuaXoa { public bool DaXoa { get; set; } public string ThongDiep { get; set; } = ""; }

    private static string Goc => $"api/mobile/gian-hang/{MockData.GianHangHienTai.Id}";

    /// <summary>true khi cần/có thể gọi máy chủ: đang online và gian hàng hiện tại có Id số (gian hàng thật trên máy chủ).</summary>
    public static bool DongBoDuoc => DuLieuService.DangOnline && int.TryParse(MockData.GianHangHienTai?.Id, out _);

    private static async Task<bool> BaoLoiAsync<T>(ApiKetQua<T> kq)
    {
        if (kq.ThanhCong) return true;
        if (Application.Current?.MainPage is { } p)
            await p.DisplayAlert(kq.MatKetNoi ? "Chưa kết nối được máy chủ" : "Máy chủ từ chối",
                (string.IsNullOrWhiteSpace(kq.ThongDiep) ? "Lỗi không xác định." : kq.ThongDiep) + "\n\nThay đổi CHƯA được lưu.", "Đóng");
        return false;
    }

    // ---------------------------------------------------------------- tải thực đơn từ máy chủ (thay phần của quán này trên máy)
    public static async Task<bool> DongBoAsync()
    {
        if (!DongBoDuoc) return false;
        var id = MockData.GianHangHienTai.Id;

        // 1) đẩy món tạo lúc ngoại tuyến (Id không phải số) lên máy chủ
        foreach (var mon in MockData.DanhSachMonAn.Where(m => m.GianHangId == id && !int.TryParse(m.Id, out _)).ToList())
        {
            var r = await LuuMonAsync(mon, moi: true, baoLoi: false);
            if (!r.Ok) break;   // lỗi mạng/từ chối: giữ nguyên trên máy, thử lại lần sau
        }

        // 2) kéo thực đơn
        var kq = await ApiClient.GetAsync<ThucDonDto>($"{Goc}/thuc-don");
        if (!kq.ThanhCong || kq.DuLieu is null) return false;

        var conLocal = MockData.DanhSachMonAn.Where(m => m.GianHangId == id && !int.TryParse(m.Id, out _)).ToList();   // chưa đẩy được
        MockData.DanhSachMonAn.RemoveAll(m => m.GianHangId == id);
        foreach (var m in kq.DuLieu.Mon) { m.GianHangId = id; MockData.DanhSachMonAn.Add(m); }
        foreach (var m in conLocal) MockData.DanhSachMonAn.Add(m);

        var ds = MockData.DanhMucCuaGianHang(id);
        ds.Clear();
        ds.AddRange(kq.DuLieu.DanhMuc.Where(d => !d.DaAn).Select(d => d.Ten));
        foreach (var m in conLocal) if (!string.IsNullOrWhiteSpace(m.DanhMuc) && !ds.Contains(m.DanhMuc, StringComparer.OrdinalIgnoreCase)) ds.Add(m.DanhMuc);
        VendorLocalStore.Luu();
        return true;
    }

    // ---------------------------------------------------------------- món
    private static object Body(MonAn m, string hinhAnh) => new
    {
        tenMon = m.TenMon, gia = m.Gia, giaVon = m.GiaVon, moTa = m.MoTa, hinhAnh, danhMuc = m.DanhMuc,
        tinhTrang = m.TamNgungBan ? "TamNgung" : m.ConHang ? "ConHang" : "HetHang", noiBat = false, choGhiChu = m.ChoGhiChu,
    };

    /// <summary>Thêm hoặc sửa món trên máy chủ (kèm tải ảnh nếu có). Thành công thì cập nhật Id/ảnh của <paramref name="mon"/> theo máy chủ.</summary>
    public static async Task<(bool Ok, string Msg)> LuuMonAsync(MonAn mon, bool moi, bool baoLoi = true)
    {
        if (!DongBoDuoc) return (true, "");
        var hinhAnh = mon.HinhAnh;
        if (mon.CoAnhTuMay)
        {
            var up = await ApiClient.PostFileAsync<UploadAnhDto>($"{Goc}/mon-an/anh", mon.AnhPath);
            if (!up.ThanhCong || string.IsNullOrWhiteSpace(up.DuLieu?.ImageUrl)) { if (baoLoi) await BaoLoiAsync(up); return (false, up.ThongDiep); }
            hinhAnh = up.DuLieu!.ImageUrl!;
        }
        var coId = int.TryParse(mon.Id, out _);
        var kq = (moi || !coId)
            ? await ApiClient.PostAsync<MonAn>($"{Goc}/mon-an", Body(mon, hinhAnh))
            : await ApiClient.PutAsync<MonAn>($"{Goc}/mon-an/{mon.Id}", Body(mon, hinhAnh));
        if (!kq.ThanhCong || kq.DuLieu is null) { if (baoLoi) await BaoLoiAsync(kq); return (false, kq.ThongDiep); }
        if (!string.IsNullOrEmpty(mon.AnhPath)) { try { File.Delete(mon.AnhPath); } catch { } mon.AnhPath = ""; }
        mon.Id = kq.DuLieu.Id;
        mon.HinhAnh = kq.DuLieu.HinhAnh;
        return (true, "");
    }

    public static async Task<bool> DoiTinhTrangAsync(MonAn mon, string tinhTrang)
    {
        if (!DongBoDuoc || !int.TryParse(mon.Id, out _)) return true;
        return await BaoLoiAsync(await ApiClient.PutAsync<object>($"{Goc}/mon-an/{mon.Id}/tinh-trang", new { tinhTrang }));
    }

    /// <returns>Ok = có thể bỏ khỏi danh sách trên máy; DaXoa=false nghĩa là máy chủ chỉ chuyển sang "tạm ngừng bán" (món đã có trong đơn cũ).</returns>
    public static async Task<(bool Ok, bool DaXoa, string Msg)> XoaMonAsync(MonAn mon)
    {
        if (!DongBoDuoc || !int.TryParse(mon.Id, out _)) return (true, true, "");
        var kq = await ApiClient.DeleteAsync<KetQuaXoa>($"{Goc}/mon-an/{mon.Id}");
        if (!await BaoLoiAsync(kq)) return (false, false, kq.ThongDiep);
        return (true, kq.DuLieu?.DaXoa ?? true, kq.DuLieu?.ThongDiep ?? "");
    }

    // ---------------------------------------------------------------- danh mục (theo tên)
    public static async Task<bool> TaoDanhMucAsync(string ten) =>
        !DongBoDuoc || await BaoLoiAsync(await ApiClient.PostAsync<object>($"{Goc}/danh-muc", new { ten }));

    public static async Task<bool> DoiTenDanhMucAsync(string tenCu, string tenMoi) =>
        !DongBoDuoc || await BaoLoiAsync(await ApiClient.PutAsync<object>($"{Goc}/danh-muc/doi-ten", new { tenCu, tenMoi }));

    public static async Task<bool> XoaDanhMucAsync(string ten, string? chuyenSang) =>
        !DongBoDuoc || await BaoLoiAsync(await ApiClient.DeleteAsync<object>($"{Goc}/danh-muc?ten={Uri.EscapeDataString(ten)}" + (string.IsNullOrEmpty(chuyenSang) ? "" : "&chuyenSang=" + Uri.EscapeDataString(chuyenSang))));

    // ---------------------------------------------------------------- thông tin quán
    public static async Task<bool> CapNhatThongTinAsync(GianHang gh) =>
        !DongBoDuoc || await BaoLoiAsync(await ApiClient.PutAsync<object>($"{Goc}/thong-tin",
            new { tenGianHang = gh.TenGianHang, diaChi = gh.DiaChi, soDienThoai = gh.SoDienThoai, moTa = gh.MoTa }));
}
