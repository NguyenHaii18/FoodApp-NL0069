using System.Globalization;
using CommunityToolkit.Maui.Media;
using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>
/// Đặt món / tìm món bằng giọng nói (tiếng Việt). Nhận giọng bằng CommunityToolkit.Maui SpeechToText (dịch vụ nhận giọng của hệ điều hành),
/// rồi tự tách "số lượng + tên món" khớp với thực đơn. Cần quyền micro (Android RECORD_AUDIO, iOS NSMicrophone/NSSpeechRecognition).
/// </summary>
public static class GiongNoiService
{
    private static readonly Dictionary<string, int> So = new()
    {
        ["mot"] = 1, ["hai"] = 2, ["ba"] = 3, ["bon"] = 4, ["tu"] = 4, ["nam"] = 5, ["lam"] = 5,
        ["sau"] = 6, ["bay"] = 7, ["tam"] = 8, ["chin"] = 9, ["muoi"] = 10,
    };

    /// <summary>Nghe một câu (tối đa ~8 giây). Trả null nếu bị từ chối quyền / không nghe được.</summary>
    public static async Task<string?> NgheAsync()
    {
        var stt = SpeechToText.Default;
        if (!await stt.RequestPermissions(CancellationToken.None)) return null;

        var xong = new TaskCompletionSource<string?>();
        void KetThuc(object? s, SpeechToTextRecognitionResultCompletedEventArgs e) =>
            xong.TrySetResult(string.IsNullOrWhiteSpace(e.RecognitionResult) ? null : e.RecognitionResult);
        stt.RecognitionResultCompleted += KetThuc;
        try
        {
            await stt.StartListenAsync(new CultureInfo("vi-VN"), CancellationToken.None);
            var thang = await Task.WhenAny(xong.Task, Task.Delay(TimeSpan.FromSeconds(8)));
            if (thang != xong.Task) await stt.StopListenAsync(CancellationToken.None);
            return await Task.WhenAny(xong.Task, Task.Delay(TimeSpan.FromSeconds(3))) == xong.Task ? xong.Task.Result : null;
        }
        finally
        {
            stt.RecognitionResultCompleted -= KetThuc;
        }
    }

    /// <summary>"đặt hai phở bò" → (Phở bò, 2). Trả null nếu không món nào khớp đủ (≥ 60% số từ của tên món).</summary>
    public static (MonAn Mon, int SoLuong)? PhanTichDatMon(string? cau, IEnumerable<MonAn> thucDon)
    {
        if (string.IsNullOrWhiteSpace(cau)) return null;
        var tu = TimKiemService.BoDau(cau).Split(' ', StringSplitOptions.RemoveEmptyEntries).ToList();
        var soLuong = 1;
        foreach (var t in tu)
        {
            if (int.TryParse(t, out var n) && n is > 0 and < 100) { soLuong = n; break; }
            if (So.TryGetValue(t, out var v)) { soLuong = v; break; }
        }

        MonAn? tot = null; var diemTot = 0.0;
        foreach (var m in thucDon.Where(m => m.ConHang && !m.TamNgungBan))
        {
            var tenTu = TimKiemService.BoDau(m.TenMon).Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (tenTu.Length == 0) continue;
            var diem = (double)tenTu.Count(tu.Contains) / tenTu.Length;
            if (diem > diemTot || (diem == diemTot && tot is not null && m.TenMon.Length > tot.TenMon.Length)) { diemTot = diem; tot = m; }
        }
        return tot is not null && diemTot >= 0.6 ? (tot, soLuong) : null;
    }
}
