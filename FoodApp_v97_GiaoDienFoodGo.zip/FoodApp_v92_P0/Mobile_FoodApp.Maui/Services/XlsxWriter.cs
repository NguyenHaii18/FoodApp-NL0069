﻿using System.IO.Compression;
using System.Security;
using System.Text;

namespace FoodApp.Maui.Services;

/// <summary>
/// Ghi file .xlsx tối giản (Open XML thuần, chỉ dùng System.IO.Compression — không cần thêm gói NuGet).
/// Ô là chuỗi (inline string) hoặc số; hàng đầu của mỗi sheet in đậm không hỗ trợ — chỉ dữ liệu, Excel/Google Sheets mở trực tiếp.
/// </summary>
public sealed class XlsxWriter
{
    private readonly List<(string Ten, List<object?[]> Hang)> _sheets = new();

    public XlsxWriter ThemSheet(string ten, IEnumerable<object?[]> hang)
    {
        var sach = new string(ten.Where(c => !"[]:*?/\\".Contains(c)).ToArray());
        if (sach.Length == 0) sach = "Sheet" + (_sheets.Count + 1);
        if (sach.Length > 31) sach = sach[..31];
        _sheets.Add((sach, hang.ToList()));
        return this;
    }

    private static string Cot(int i)   // 0 -> A, 25 -> Z, 26 -> AA
    {
        var s = "";
        for (i++; i > 0; i = (i - 1) / 26) s = (char)('A' + (i - 1) % 26) + s;
        return s;
    }

    private static string Xml(string s) => SecurityElement.Escape(s) ?? "";

    private static string XmlSheet(List<object?[]> hang)
    {
        var sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
        // Độ rộng cột tự co theo nội dung (tối thiểu 8, tối đa 50 ký tự) để mở ra là đọc được ngay.
        var soCot = hang.Count == 0 ? 0 : hang.Max(h => h.Length);
        if (soCot > 0)
        {
            sb.Append("<cols>");
            for (var c = 0; c < soCot; c++)
            {
                var dai = hang.Where(h => c < h.Length && h[c] is not null).Select(h => (h[c]!.ToString() ?? "").Length).DefaultIfEmpty(8).Max();
                var rong = Math.Clamp(dai + 2, 8, 50).ToString(System.Globalization.CultureInfo.InvariantCulture);
                sb.Append($"<col min=\"{c + 1}\" max=\"{c + 1}\" width=\"{rong}\" customWidth=\"1\"/>");
            }
            sb.Append("</cols>");
        }
        sb.Append("<sheetData>");
        for (var r = 0; r < hang.Count; r++)
        {
            sb.Append($"<row r=\"{r + 1}\">");
            for (var c = 0; c < hang[r].Length; c++)
            {
                var v = hang[r][c];
                if (v is null) continue;
                var tc = Cot(c) + (r + 1);
                if (v is int or long or short or byte or decimal or double or float)
                    sb.Append($"<c r=\"{tc}\"><v>{Convert.ToString(v, System.Globalization.CultureInfo.InvariantCulture)}</v></c>");
                else
                    sb.Append($"<c r=\"{tc}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">{Xml(v.ToString() ?? "")}</t></is></c>");
            }
            sb.Append("</row>");
        }
        return sb.Append("</sheetData></worksheet>").ToString();
    }

    public void Luu(string duongDan)
    {
        if (_sheets.Count == 0) throw new InvalidOperationException("Chưa có sheet nào.");
        if (File.Exists(duongDan)) File.Delete(duongDan);
        using var fs = new FileStream(duongDan, FileMode.Create);
        using var zip = new ZipArchive(fs, ZipArchiveMode.Create);
        void Them(string ten, string noiDung)
        {
            var e = zip.CreateEntry(ten, CompressionLevel.Optimal);
            using var w = new StreamWriter(e.Open(), new UTF8Encoding(false));
            w.Write(noiDung);
        }

        var ct = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>");
        for (var i = 0; i < _sheets.Count; i++)
            ct.Append($"<Override PartName=\"/xl/worksheets/sheet{i + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
        Them("[Content_Types].xml", ct.Append("</Types>").ToString());

        Them("_rels/.rels", "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");

        var wb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>");
        var rel = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
        for (var i = 0; i < _sheets.Count; i++)
        {
            wb.Append($"<sheet name=\"{Xml(_sheets[i].Ten)}\" sheetId=\"{i + 1}\" r:id=\"rId{i + 1}\"/>");
            rel.Append($"<Relationship Id=\"rId{i + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet{i + 1}.xml\"/>");
            Them($"xl/worksheets/sheet{i + 1}.xml", XmlSheet(_sheets[i].Hang));
        }
        Them("xl/workbook.xml", wb.Append("</sheets></workbook>").ToString());
        Them("xl/_rels/workbook.xml.rels", rel.Append("</Relationships>").ToString());
    }
}
