using System.IO.Compression;
using System.Text;
using System.Security;

namespace FoodApp.Maui.Services;

/// <summary>
/// Ghi file .xlsx thật (OpenXML tối giản, không cần gói NuGet). Mỗi sheet là danh sách dòng; ô số ghi dạng số,
/// còn lại ghi dạng chuỗi. Dòng đầu của mỗi sheet được in đậm.
/// </summary>
public static class XlsxXuat
{
    public record Sheet(string Ten, List<object?[]> Dong);

    public static void Ghi(string duongDan, params Sheet[] sheets)
    {
        if (File.Exists(duongDan)) File.Delete(duongDan);
        using var fs = new FileStream(duongDan, FileMode.Create);
        using var zip = new ZipArchive(fs, ZipArchiveMode.Create);

        Them(zip, "[Content_Types].xml",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
            "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
            string.Concat(sheets.Select((_, i) => $"<Override PartName=\"/xl/worksheets/sheet{i + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>")) +
            "</Types>");
        Them(zip, "_rels/.rels",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        Them(zip, "xl/workbook.xml",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets>" +
            string.Concat(sheets.Select((s, i) => $"<sheet name=\"{Esc(TenSheet(s.Ten))}\" sheetId=\"{i + 1}\" r:id=\"rId{i + 1}\"/>")) + "</sheets></workbook>");
        Them(zip, "xl/_rels/workbook.xml.rels",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            string.Concat(sheets.Select((_, i) => $"<Relationship Id=\"rId{i + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet{i + 1}.xml\"/>")) +
            $"<Relationship Id=\"rId{sheets.Length + 1}\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
        Them(zip, "xl/styles.xml",
            "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
            "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Arial\"/></font><font><b/><sz val=\"11\"/><name val=\"Arial\"/></font></fonts>" +
            "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
            "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
            "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
            "<cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/><xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>" +
            "<xf numFmtId=\"3\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/></cellXfs></styleSheet>");

        for (int i = 0; i < sheets.Length; i++)
        {
            var sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
            sb.Append("<cols><col min=\"1\" max=\"8\" width=\"22\" customWidth=\"1\"/></cols><sheetData>");
            for (int r = 0; r < sheets[i].Dong.Count; r++)
            {
                sb.Append($"<row r=\"{r + 1}\">");
                var dong = sheets[i].Dong[r];
                for (int c = 0; c < dong.Length; c++)
                {
                    var o = dong[c]; if (o is null) continue;
                    var ref_ = $"{Cot(c)}{r + 1}";
                    if (o is IConvertible and not string and not DateTime and not bool && IsSo(o))
                        sb.Append($"<c r=\"{ref_}\" s=\"2\"><v>{Convert.ToDecimal(o, System.Globalization.CultureInfo.InvariantCulture).ToString(System.Globalization.CultureInfo.InvariantCulture)}</v></c>");
                    else
                    {
                        var text = o is DateTime dt ? dt.ToString("dd/MM/yyyy HH:mm") : o.ToString() ?? "";
                        sb.Append($"<c r=\"{ref_}\" t=\"inlineStr\"{(r == 0 ? " s=\"1\"" : "")}><is><t xml:space=\"preserve\">{Esc(text)}</t></is></c>");
                    }
                }
                sb.Append("</row>");
            }
            sb.Append("</sheetData></worksheet>");
            Them(zip, $"xl/worksheets/sheet{i + 1}.xml", sb.ToString());
        }
    }

    private static bool IsSo(object o) => o is int or long or decimal or double or float or short;
    private static string Esc(string s) => SecurityElement.Escape(s) ?? "";
    private static string TenSheet(string t) { var x = new string(t.Where(ch => !"[]:*?/\\".Contains(ch)).ToArray()); return x.Length > 31 ? x[..31] : x; }
    private static string Cot(int i) { var s = ""; for (i++; i > 0; i = (i - 1) / 26) s = (char)('A' + (i - 1) % 26) + s; return s; }

    private static void Them(ZipArchive zip, string ten, string noiDung)
    {
        var e = zip.CreateEntry(ten, CompressionLevel.Optimal);
        using var w = new StreamWriter(e.Open(), new UTF8Encoding(false));
        w.Write(noiDung);
    }
}
