using Microsoft.Maui.Dispatching;
using System.Text;
using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>
/// v80 — Vận hành quán nâng cao (Đối tác): đếm đơn đang chuẩn bị, giới hạn giờ cao điểm,
/// chuông/rung khi có đơn mới, thông số riêng của từng món, đối soát theo tháng, xuất báo cáo CSV.
/// </summary>
public static class VanHanhService
{
    private const string KhoaBaoDon = "vh-bao-don";
    private const string KhoaDonDaBao = "vh-don-da-bao";

    public sealed class SoLieuVanHanh
    {
        public int ChoXacNhan { get; set; }
        public int DangNau { get; set; }
        public int SanSangGiao { get; set; }
        public int ToiDaDonDong { get; set; }
        public bool QuaTai => ToiDaDonDong > 0 && DangNau >= ToiDaDonDong;
    }

    /// <summary>Đếm từ danh sách đơn đang có trên máy (đã được làm mới từ máy chủ khi online).</summary>
    public static SoLieuVanHanh DemDon(string gianHangId)
    {
        var don = MockData.DonHangCuaGianHang.Where(d => d.GianHangId == gianHangId).ToList();
        var gh = MockData.GianHangHienTai;
        return new SoLieuVanHanh
        {
            ChoXacNhan = don.Count(d => d.TrangThai == TrangThaiDonHang.ChoXacNhan),
            DangNau = don.Count(d => d.TrangThai == TrangThaiDonHang.DangLam && !d.SanSangGiao),
            SanSangGiao = don.Count(d => d.TrangThai == TrangThaiDonHang.DangLam && d.SanSangGiao),
            ToiDaDonDong = gh.ToiDaDonDong,
        };
    }

    public static async Task<bool> DatToiDaDonDongAsync(int soDon)
    {
        var gh = MockData.GianHangHienTai;
        var cu = gh.ToiDaDonDong;
        gh.ToiDaDonDong = soDon;
        var ok = await DuLieuService.GhiHoanTacAsync("PUT", $"api/mobile/gian-hang/{gh.Id}/cau-hinh-cao-diem",
            new { toiDaDonDong = soDon }, () => gh.ToiDaDonDong = cu);
        if (ok) VendorLocalStore.Luu();
        return ok;
    }

    /// <summary>Gửi thời gian chuẩn bị / khung giờ bán / món kèm của món lên máy chủ (món đã có mã số trên máy chủ). Offline: chỉ lưu máy.</summary>
    public static async Task<bool> DongBoMonAsync(MonAn mon)
    {
        if (!int.TryParse(mon.Id, out _)) return true;
        return await DuLieuService.GhiAsync("PUT", $"api/mobile/gian-hang/{MockData.GianHangHienTai.Id}/mon-an/{mon.Id}/van-hanh",
            new
            {
                thoiGianChuanBiPhut = mon.ThoiGianChuanBiPhut,
                banTuGio = mon.CoKhungGioBan ? mon.BanTuGio : null,
                banDenGio = mon.CoKhungGioBan ? mon.BanDenGio : null,
                monAnKem = string.IsNullOrWhiteSpace(mon.MonAnKem) ? null : mon.MonAnKem.Trim(),
            });
    }

    private sealed class MonVanHanhDto
    {
        public int MaMon { get; set; }
        public int? ThoiGianChuanBiPhut { get; set; }
        public string? BanTuGio { get; set; }
        public string? BanDenGio { get; set; }
        public string? MonAnKem { get; set; }
    }

    /// <summary>Online: kéo thông số vận hành của món từ máy chủ về máy (để thiết bị mới thấy đủ).</summary>
    public static async Task TaiThongSoMonAsync()
    {
        if (!DuLieuService.DangOnline) return;
        var r = await ApiClient.GetAsync<List<MonVanHanhDto>>($"api/mobile/gian-hang/{MockData.GianHangHienTai.Id}/mon-an/van-hanh");
        if (!r.ThanhCong || r.DuLieu is null) return;
        foreach (var d in r.DuLieu)
        {
            var mon = MockData.DanhSachMonAn.FirstOrDefault(m => m.Id == d.MaMon.ToString());
            if (mon is null) continue;
            mon.ThoiGianChuanBiPhut = d.ThoiGianChuanBiPhut;
            mon.BanTuGio = d.BanTuGio ?? "";
            mon.BanDenGio = d.BanDenGio ?? "";
            mon.MonAnKem = d.MonAnKem ?? "";
        }
    }

    /// <summary>Gợi ý thời gian chuẩn bị cho đơn = món lâu nhất trong đơn (nếu quán đã nhập riêng từng món).</summary>
    public static int? GoiYThoiGianChuanBi(DonHang don)
    {
        var ds = don.ChiTiet
            .Select(c => MockData.DanhSachMonAn.FirstOrDefault(m => m.Id == c.MonAn.Id)?.ThoiGianChuanBiPhut ?? c.MonAn.ThoiGianChuanBiPhut)
            .Where(x => x is > 0).Select(x => x!.Value).ToList();
        return ds.Count == 0 ? null : ds.Max();
    }

    // ------------------------------------------------------------------ chuông / rung đơn mới
    public static bool BaoDonMoiBat
    {
        get => Preferences.Default.Get(KhoaBaoDon, true);
        set => Preferences.Default.Set(KhoaBaoDon, value);
    }

    private static readonly HashSet<string> _daBao = new();
    private static bool _daKhoiTao;
    private static IDispatcherTimer? _boDem;
    private static bool _dangNap;

    /// <summary>Bật theo dõi đơn mới (30 giây một lần khi đang mở màn hình quán). Gọi trong OnAppearing.</summary>
    public static void BatDauTheoDoi(Action? khiCoDonMoi = null)
    {
        _boDem ??= Application.Current?.Dispatcher.CreateTimer();
        if (_boDem is null) return;
        _boDem.Interval = TimeSpan.FromSeconds(30);
        _boDem.Tick -= Tick;
        _boDem.Tick += Tick;
        _khiCoDonMoi = khiCoDonMoi;
        if (!_boDem.IsRunning) _boDem.Start();
    }

    public static void DungTheoDoi() { _boDem?.Stop(); _khiCoDonMoi = null; }

    private static Action? _khiCoDonMoi;

    private static async void Tick(object? s, EventArgs e) => await KiemTraDonMoiAsync();

    /// <summary>Làm mới đơn từ máy chủ rồi báo nếu có đơn ChoXacNhan chưa từng báo. Lần đầu chỉ ghi nhớ.</summary>
    public static async Task KiemTraDonMoiAsync()
    {
        if (_dangNap) return;
        _dangNap = true;
        try
        {
            var gh = MockData.GianHangHienTai;
            if (string.IsNullOrEmpty(gh.Id)) return;
            await DuLieuService.TaiDonHangGianHangAsync(gh.Id);
            var moi = MockData.DonHangCuaGianHang
                .Where(d => d.GianHangId == gh.Id && d.TrangThai == TrangThaiDonHang.ChoXacNhan && _daBao.Add(d.Id)).ToList();
            var coBao = _daKhoiTao && moi.Count > 0;
            _daKhoiTao = true;
            if (coBao)
            {
                if (BaoDonMoiBat) PhatBao();
                _khiCoDonMoi?.Invoke();
            }
        }
        catch (Exception ex) { CrashLog.Ghi("VanHanh.DonMoi", ex); }
        finally { _dangNap = false; }
    }

    private static void PhatBao()
    {
        try { Vibration.Default.Vibrate(TimeSpan.FromMilliseconds(700)); } catch { /* máy không hỗ trợ / chưa cấp quyền */ }
#if ANDROID
        try
        {
            var uri = Android.Media.RingtoneManager.GetDefaultUri(Android.Media.RingtoneType.Notification);
            Android.Media.RingtoneManager.GetRingtone(Android.App.Application.Context, uri)?.Play();
        }
        catch { /* không phát được âm báo: bỏ qua */ }
#endif
    }

    // ------------------------------------------------------------------ báo cáo
    public sealed class DongDoiSoatThang
    {
        public string Thang { get; set; } = "";
        public int SoDon { get; set; }
        public decimal DoanhThu { get; set; }
        public decimal PhiNenTang { get; set; }
        public decimal ThucNhan { get; set; }
    }

    /// <summary>Lịch sử đối soát N tháng gần nhất (mới nhất trước), tính từ các đơn hoàn thành.</summary>
    public static List<DongDoiSoatThang> DoiSoatTheoThang(GianHang gh, int soThang = 6)
    {
        var dau = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(soThang - 1));
        var hoanThanh = MockData.DonHangCuaGianHang
            .Where(d => d.GianHangId == gh.Id && d.TrangThai == TrangThaiDonHang.HoanThanh && d.NgayDat >= dau).ToList();
        var kq = new List<DongDoiSoatThang>();
        for (var i = 0; i < soThang; i++)
        {
            var t = dau.AddMonths(i);
            var trongThang = hoanThanh.Where(d => d.NgayDat.Year == t.Year && d.NgayDat.Month == t.Month).ToList();
            var tc = DoiTacService.TinhTaiChinh(gh, trongThang);
            kq.Add(new DongDoiSoatThang { Thang = t.ToString("MM/yyyy"), SoDon = tc.SoDon, DoanhThu = tc.DoanhThuMon, PhiNenTang = tc.PhiNenTang, ThucNhan = tc.ThucNhan });
        }
        kq.Reverse();
        return kq;
    }

    public sealed class DongMonBanChay
    {
        public string TenMon { get; set; } = "";
        public int SoLuong { get; set; }
        public decimal DoanhThu { get; set; }
    }

    public static List<DongMonBanChay> MonBanChay(string gianHangId, DateTime tu, DateTime den, int top = 10) =>
        MockData.DonHangCuaGianHang
            .Where(d => d.GianHangId == gianHangId && d.TrangThai == TrangThaiDonHang.HoanThanh && d.NgayDat >= tu && d.NgayDat < den)
            .SelectMany(d => d.ChiTiet)
            .GroupBy(c => c.MonAn.TenMon)
            .Select(g => new DongMonBanChay { TenMon = g.Key, SoLuong = g.Sum(x => x.SoLuong), DoanhThu = g.Sum(x => x.ThanhTien) })
            .OrderByDescending(x => x.SoLuong).Take(top).ToList();

    private static string O(string? s)
    {
        s ??= "";
        if (s.Length > 0 && "=+-@".Contains(s[0])) s = "'" + s;   // chống chèn công thức khi mở bằng Excel
        return "\"" + s.Replace("\"", "\"\"") + "\"";
    }

    /// <summary>Tạo tệp CSV báo cáo đơn trong kỳ và mở hộp thoại chia sẻ (gửi mail / lưu / mở bằng Excel).</summary>
    public static async Task<string?> XuatCsvAsync(GianHang gh, DateTime tu, DateTime den)
    {
        var don = MockData.DonHangCuaGianHang
            .Where(d => d.GianHangId == gh.Id && d.NgayDat >= tu && d.NgayDat < den).OrderBy(d => d.NgayDat).ToList();
        var sb = new StringBuilder();
        sb.Append('﻿');
        sb.AppendLine("Mã đơn,Ngày đặt,Trạng thái,Tiền món,Giảm giá quán tài trợ,Phí nền tảng,Thực nhận,Lý do hủy/từ chối");
        foreach (var d in don)
        {
            var hoanThanh = d.TrangThai == TrangThaiDonHang.HoanThanh;
            var tc = hoanThanh ? DoiTacService.TinhTaiChinh(gh, new[] { d }) : null;
            sb.AppendLine(string.Join(",", O(d.Id), d.NgayDat.ToString("yyyy-MM-dd HH:mm"), O(d.TrangThai.Nhan()),
                tc?.DoanhThuMon ?? 0, tc?.GiamGiaQuanChiu ?? 0, tc?.PhiNenTang ?? 0, tc?.ThucNhan ?? 0, O(d.LyDoTuChoi)));
        }
        var duongDan = Path.Combine(FileSystem.CacheDirectory, $"BaoCao_{tu:yyyyMMdd}_{den.AddDays(-1):yyyyMMdd}.csv");
        await File.WriteAllTextAsync(duongDan, sb.ToString(), new UTF8Encoding(false));
        try
        {
            await Share.Default.RequestAsync(new ShareFileRequest { Title = "Báo cáo doanh thu", File = new ShareFile(duongDan) });
        }
        catch (Exception ex) { CrashLog.Ghi("VanHanh.XuatCsv", ex); return null; }
        return duongDan;
    }
}
