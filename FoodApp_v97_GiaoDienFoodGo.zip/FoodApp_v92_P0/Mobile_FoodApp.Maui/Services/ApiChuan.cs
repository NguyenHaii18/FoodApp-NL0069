using System.Text.RegularExpressions;

namespace FoodApp.Maui.Services;

/// <summary>
/// Lớp API chuẩn (REST, tiếng Anh) cho app: mọi thao tác đi qua Backend API, app không nối thẳng SQL.
/// Các màn hình vẫn gọi đường dẫn cũ <c>api/mobile/...</c>; <see cref="ApiClient"/> dịch sang đường dẫn chuẩn bên dưới trước khi gửi.
/// Máy chủ chưa có đường dẫn chuẩn (404/405/403) thì tự gọi lại đường dẫn cũ nên app vẫn chạy với Web bản cũ.
/// Đăng nhập/đăng ký (POST api/auth/login, api/auth/register) giữ luồng riêng của từng vai trò vì cần trả kèm hồ sơ.
/// </summary>
public static class ApiChuan
{
    private sealed record Luat(HttpMethod Cu, Regex Mau, HttpMethod Chuan, string Dich);

    private static Luat L(HttpMethod cu, string mau, HttpMethod chuan, string dich) =>
        new(cu, new Regex("^" + mau + "$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant), chuan, dich);

    private static readonly HttpMethod Get = HttpMethod.Get, Post = HttpMethod.Post, Put = HttpMethod.Put;

    // Bảng ánh xạ: đường dẫn cũ (api/mobile/...) -> đường dẫn chuẩn.
    private static readonly Luat[] Luats =
    {
        L(Get,  @"api/mobile/gian-hang",                        Get,  "api/restaurants"),                          // danh sách nhà hàng
        L(Get,  @"api/mobile/gian-hang/(\d+)",                  Get,  "api/restaurants/$1"),                       // chi tiết nhà hàng
        L(Post, @"api/mobile/don-hang",                         Post, "api/orders"),                               // tạo đơn
        L(Put,  @"api/mobile/don-hang/(\d+)/huy",               Post, "api/orders/$1/cancel"),                     // khách hủy đơn
        L(Put,  @"api/mobile/don-hang/(\d+)/xac-nhan",          Post, "api/restaurant/orders/$1/confirm"),         // nhà hàng xác nhận
        L(Put,  @"api/mobile/don-hang/(\d+)/san-sang-giao",     Post, "api/restaurant/orders/$1/ready"),           // nhà hàng báo món xong
        L(Put,  @"api/mobile/tai-xe/trang-thai",                Post, "api/driver/availability"),                  // tài xế bật/tắt nhận đơn
        L(Put,  @"api/mobile/tai-xe/vi-tri",                    Post, "api/driver/location"),                      // tài xế cập nhật vị trí
        L(Put,  @"api/mobile/tai-xe/don-hang/(\d+)/nhan",       Post, "api/driver/orders/$1/accept"),              // tài xế nhận đơn
        L(Put,  @"api/mobile/don-hang/(\d+)/da-lay-hang",       Post, "api/driver/orders/$1/pickup"),              // xác nhận lấy món
        L(Put,  @"api/mobile/don-hang/(\d+)/hoan-thanh",        Post, "api/driver/orders/$1/complete"),            // xác nhận giao hàng
        L(Get,  @"api/mobile/don-hang/(\d+)/vi-tri",            Get,  "api/orders/$1/tracking"),                   // theo dõi đơn
        L(Get,  @"api/mobile/admin/bao-cao",                    Get,  "api/admin/reports/revenue"),                // quản trị: báo cáo doanh thu
    };

    /// <summary>Bật/tắt việc dùng đường dẫn chuẩn (mặc định bật). Tắt = luôn gọi đường dẫn cũ api/mobile/...</summary>
    public static bool Bat
    {
        get => Preferences.Default.Get("api-chuan", true);
        set => Preferences.Default.Set("api-chuan", value);
    }

    /// <summary>Đường dẫn chuẩn tương ứng, hoặc null nếu yêu cầu này không có trong bảng.</summary>
    public static (HttpMethod Method, string Url)? Dich(HttpMethod method, string url)
    {
        if (!Bat || string.IsNullOrEmpty(url)) return null;
        var sach = url.TrimStart('/');
        var q = sach.IndexOf('?');
        var duongDan = q >= 0 ? sach[..q] : sach;
        var truyVan = q >= 0 ? sach[q..] : "";
        foreach (var l in Luats)
        {
            if (l.Cu != method) continue;
            var m = l.Mau.Match(duongDan);
            if (m.Success) return (l.Chuan, m.Result(l.Dich) + truyVan);
        }
        return null;
    }

    /// <summary>Đường dẫn chuẩn chưa có trên máy chủ (hoặc vai trò không khớp) thì thử lại đường dẫn cũ.</summary>
    public static bool NenDungDuongCu<T>(ApiKetQua<T> kq) =>
        !kq.ThanhCong && !kq.MatKetNoi && kq.MaHttp is 403 or 404 or 405;
}
