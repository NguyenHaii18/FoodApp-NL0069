using System.Globalization;
using System.Text.Json;

namespace FoodApp.Maui.Services;

public sealed class KqToaDo
{
    public bool TimThay { get; init; }
    public double Lat { get; init; }
    public double Lng { get; init; }
    /// <summary>"Goong" (máy chủ) hoặc "OpenStreetMap" (Nominatim, dự phòng).</summary>
    public string Nguon { get; init; } = "";
    public string LyDo { get; init; } = "";
}

/// <summary>
/// v94: đổi địa chỉ → tọa độ. Ưu tiên Goong qua máy chủ (khớp địa chỉ Việt Nam tốt hơn, và là cùng nguồn máy chủ dùng để tính phí);
/// không có khóa/máy chủ lỗi thì dùng Nominatim (OpenStreetMap). Địa chỉ được chuẩn hóa (thêm "TP.HCM" nếu thiếu) và có nhớ đệm.
/// </summary>
public static class DiaChiToaDoService
{
    private sealed class GoongDto { public bool TimThay { get; set; } public double Lat { get; set; } public double Lng { get; set; } public string LyDo { get; set; } = ""; }

    private static readonly Dictionary<string, KqToaDo> _nho = new();
    private static readonly HttpClient Http = TaoHttp();
    private static DateTime _lanOsm = DateTime.MinValue;       // Nominatim: tối đa 1 lượt/giây

    private static HttpClient TaoHttp()
    {
        var c = new HttpClient { Timeout = TimeSpan.FromSeconds(12) };
        c.DefaultRequestHeaders.UserAgent.ParseAdd("FoodApp.Maui/1.0 (do-an-mon-hoc)");
        c.DefaultRequestHeaders.AcceptLanguage.ParseAdd("vi");
        return c;
    }

    /// <summary>Thêm tỉnh/thành mặc định khi địa chỉ chưa có (giúp geocode không nhảy sang tỉnh khác).</summary>
    public static string ChuanHoa(string? diaChi)
    {
        var d = (diaChi ?? "").Trim().Trim(',');
        if (d.Length == 0) return "";
        var kd = d.Normalize(System.Text.NormalizationForm.FormD);
        var sb = new System.Text.StringBuilder();
        foreach (var c in kd) if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
        var t = sb.ToString().ToLowerInvariant().Replace('đ', 'd');
        return t.Contains("ho chi minh") || t.Contains("hcm") || t.Contains("sai gon") ? d : $"{d}, {GiaoHangService.TinhThanhMacDinh}";
    }

    public static async Task<KqToaDo> TimAsync(string? diaChi, bool chiGoong = false, bool chiOsm = false)
    {
        var d = ChuanHoa(diaChi);
        if (d.Length < 5) return new KqToaDo { LyDo = "Địa chỉ quá ngắn." };
        var khoa = $"{(chiGoong ? "g" : chiOsm ? "o" : "a")}|{d.ToLowerInvariant()}";
        if (_nho.TryGetValue(khoa, out var da)) return da;

        string lyDoGoong = "";
        if (!chiOsm && DuLieuService.DangOnline)
        {
            var r = await ApiClient.PostAsync<GoongDto>("api/map/geocode", new { diaChi = d });
            if (r.ThanhCong && r.DuLieu is { TimThay: true } g) return _nho[khoa] = new KqToaDo { TimThay = true, Lat = g.Lat, Lng = g.Lng, Nguon = "Goong" };
            lyDoGoong = r.ThanhCong ? r.DuLieu?.LyDo ?? "Goong không tìm thấy." : r.ThongDiep;
        }
        else if (!chiOsm) lyDoGoong = "Đang ngoại tuyến.";
        if (chiGoong) return new KqToaDo { LyDo = lyDoGoong };

        var kq = await OsmAsync(d);
        if (kq.TimThay) return _nho[khoa] = kq;
        return new KqToaDo { LyDo = string.IsNullOrEmpty(lyDoGoong) ? kq.LyDo : $"Goong: {lyDoGoong} · OSM: {kq.LyDo}" };
    }

    private static async Task<KqToaDo> OsmAsync(string d)
    {
        try
        {
            var cho = TimeSpan.FromMilliseconds(1100) - (DateTime.Now - _lanOsm);
            if (cho > TimeSpan.Zero) await Task.Delay(cho);
            _lanOsm = DateTime.Now;
            var url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=vn&accept-language=vi&q=" + Uri.EscapeDataString(d);
            using var doc = JsonDocument.Parse(await Http.GetStringAsync(url));
            if (doc.RootElement.GetArrayLength() == 0) return new KqToaDo { LyDo = "không tìm thấy" };
            var p = doc.RootElement[0];
            if (double.TryParse(p.GetProperty("lat").GetString(), NumberStyles.Float, CultureInfo.InvariantCulture, out var lat) &&
                double.TryParse(p.GetProperty("lon").GetString(), NumberStyles.Float, CultureInfo.InvariantCulture, out var lng))
                return new KqToaDo { TimThay = true, Lat = lat, Lng = lng, Nguon = "OpenStreetMap" };
            return new KqToaDo { LyDo = "dữ liệu tọa độ lỗi" };
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or JsonException) { return new KqToaDo { LyDo = "lỗi mạng" }; }
    }
}
