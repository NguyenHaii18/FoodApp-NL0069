using System.Globalization;
using System.Text;
using System.Text.Json;
using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>Các tiêu chí tìm kiếm / lọc / sắp xếp quán ăn trên trang chủ khách.</summary>
public class BoLocTimKiem
{
    public string TuKhoa { get; set; } = "";
    public string LoaiMon { get; set; } = "";      // GianHang.PhanLoai (com, ga, bun...) — rỗng = tất cả
    public string DanhMuc { get; set; } = "";      // MonAn.DanhMuc — rỗng = tất cả
    public string KhuVuc { get; set; } = "";       // chuỗi có trong địa chỉ quán
    public bool ChiDangMo { get; set; }
    public decimal? GiaTu { get; set; }            // quán có ít nhất 1 món đang bán trong khoảng giá
    public decimal? GiaDen { get; set; }
    public double SaoTu { get; set; }              // 0 = không lọc
    public double? KmToiDa { get; set; }
    public int? PhutToiDa { get; set; }            // thời gian giao dự kiến tối đa (phút) — v76
    public bool ChiKhuyenMai { get; set; }         // v90: chỉ quán đang có khuyến mãi
    public bool ChiQuanMoi { get; set; }           // v90: chỉ quán mới tham gia (30 ngày)
    public string SapXep { get; set; } = "";       // "" | gan | sao | giaThap | giaCao | banChay | giaoNhanh

    public bool CoLoc =>
        TuKhoa.Trim().Length > 0 || LoaiMon.Length > 0 || DanhMuc.Length > 0 || KhuVuc.Trim().Length > 0 || ChiDangMo
        || GiaTu is not null || GiaDen is not null || SaoTu > 0 || KmToiDa is not null || PhutToiDa is not null
        || ChiKhuyenMai || ChiQuanMoi;
}

/// <summary>Một quán trong kết quả tìm kiếm, kèm số liệu đã tính sẵn để hiển thị.</summary>
public class QuanKetQua
{
    public GianHang Gh { get; init; } = null!;
    public bool DangMo { get; init; }
    public double Sao { get; init; }
    public int SoDanhGia { get; init; }
    public int DaBan { get; init; }
    public decimal? TuGia { get; init; }
    public double? Km { get; init; }
    public int Phut { get; init; }
    public decimal? Phi { get; init; }

    public string TenGianHang => Gh.TenGianHang;
    public string DiaChi => Gh.DiaChi;
    public string HinhAnh => Gh.HinhAnh;
    public string AnhPath => Gh.AnhHienThi;
    public bool CoAnh => Gh.CoAnh;
    public bool CoEmoji => Gh.CoEmoji;
    public bool CoKhuyenMai => Gh.CoKhuyenMai;
    public string NhanKhuyenMai => Gh.NhanKhuyenMai;
    public bool LaQuanMoi => Gh.LaQuanMoi;
    public string NhanQuanMoi => Gh.LaQuanMoi ? "🆕 Mới tham gia" : "";
    public string TrangThaiText => DangMo ? (Gh.DangNhanDon ? "🟢 Đang mở" : "🟡 Mở · tạm dừng nhận đơn") : "🔴 Đóng cửa";
    public Color TrangThaiMau => Color.FromArgb(DangMo ? (Gh.DangNhanDon ? "#16A34A" : "#D97706") : "#DC2626");
    public string DiemText => SoDanhGia > 0 ? $"⭐ {Sao:0.0} ({SoDanhGia})" : Gh.DanhGia > 0 ? $"⭐ {Gh.DanhGia:0.0}" : "⭐ Mới";
    public string ThoiGianText => Phut > 0 ? $"⏱ ~{Phut} phút" : $"⏱ ~{Gh.ThoiGianGiaoPhut} phút";
    public string KhoangCachText => Km is { } k ? $"📍 {k:0.#} km" : "";
    public bool CoKhoangCach => Km is not null;
    public string GiaText => TuGia is { } g ? $"Từ {g:N0}đ" : "";
    public string PhiText => Phi is { } p ? $"🛵 {p:N0}đ" : $"🛵 từ {GiaoHangService.PhiCoBan:N0}đ";
    public string DaBanText => DaBan > 0 ? $"🔥 {DaBan} món đã bán" : "";
    public bool CoDaBan => DaBan > 0;
}

/// <summary>Tìm kiếm / lọc / sắp xếp quán và món, lịch sử tìm kiếm, gợi ý phổ biến.</summary>
public static class TimKiemService
{
    private const string KhoaLichSu = "tim-kiem-lich-su";
    private const int ToiDaLichSu = 8;

    public static string BoDau(string? s)
    {
        if (string.IsNullOrWhiteSpace(s)) return "";
        var d = s.Trim().ToLowerInvariant().Replace('đ', 'd').Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder(d.Length);
        foreach (var c in d)
            if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
        return sb.ToString();
    }

    // ------------------------------------------------------------- dữ liệu đơn dùng thống kê "bán chạy"
    internal static IEnumerable<DonHang> DonTinhBanChay() =>
        MockData.LichSuDonHang.Concat(MockData.DonHangCuaGianHang).Concat(MockData.DonHangChoTaiXe).Concat(MockData.DonHangDaGiaoCuaTaiXe)
            .Where(d => d.TrangThai != TrangThaiDonHang.DaHuy && !d.GiaoThatBai)
            .GroupBy(d => d.Id).Select(g => g.First());

    /// <summary>Số món đã bán theo quán (không tính đơn hủy / giao thất bại).</summary>
    public static Dictionary<string, int> DaBanTheoQuan() =>
        DonTinhBanChay().GroupBy(d => d.GianHangId).ToDictionary(g => g.Key, g => g.Sum(d => d.ChiTiet.Sum(c => c.SoLuong)));

    /// <summary>Số phần đã bán theo món của một quán (Id món → số lượng).</summary>
    public static Dictionary<string, int> DaBanTheoMon(string gianHangId) =>
        DonTinhBanChay().Where(d => d.GianHangId == gianHangId)
            .SelectMany(d => d.ChiTiet).Where(c => c.MonAn is not null)
            .GroupBy(c => c.MonAn.Id).ToDictionary(g => g.Key, g => g.Sum(c => c.SoLuong));

    // ------------------------------------------------------------- quán hiển thị được cho khách
    public static bool QuanHienThi(GianHang g) =>
        g.TrangThaiDangKy == TrangThaiDangKyGianHang.DaDuyet && !g.TaiKhoanBiKhoa;

    /// <summary>Quán đang mở cửa: bật mở bán và nằm trong giờ hoạt động (tạm dừng nhận đơn vẫn tính là mở).</summary>
    public static bool DangMoCua(GianHang g) => QuanHienThi(g) && g.DangMoCua && g.TrongGioHoatDong;

    public static (double Sao, int So) DiemQuan(GianHang g)
    {
        var ds = MockData.DanhSachDanhGia.Where(d => d.GianHangId == g.Id && d.SoSaoMonAn > 0).ToList();
        return ds.Count == 0 ? (g.DanhGia, 0) : (Math.Round(ds.Average(d => d.SoSaoMonAn), 1), ds.Count);
    }

    // ------------------------------------------------------------- tìm kiếm chính
    public static List<QuanKetQua> Tim(BoLocTimKiem loc)
    {
        var tuKhoa = BoDau(loc.TuKhoa).Split(' ', StringSplitOptions.RemoveEmptyEntries);
        var khuVuc = BoDau(loc.KhuVuc);
        var diaChiKhach = Phien.Khach?.DiaChi;
        var daBan = DaBanTheoQuan();
        var monTheoQuan = MockData.DanhSachMonAn.Where(m => !m.TamNgungBan).ToLookup(m => m.GianHangId);

        var kq = new List<QuanKetQua>();
        foreach (var g in MockData.DanhSachGianHang.Where(QuanHienThi))
        {
            var mons = monTheoQuan[g.Id].ToList();

            // Từ khóa: mọi từ phải xuất hiện đâu đó trong tên quán, địa chỉ, mô tả, loại, tên/mô tả/danh mục món
            if (tuKhoa.Length > 0)
            {
                var co = BoDau(string.Join(' ', new[] { g.TenGianHang, g.DiaChi, g.MoTa, g.PhanLoai }
                    .Concat(mons.SelectMany(m => new[] { m.TenMon, m.MoTa, m.DanhMuc }))));
                if (!tuKhoa.All(co.Contains)) continue;
            }
            if (loc.LoaiMon.Length > 0 && !g.CoLoai(loc.LoaiMon)) continue;
            if (loc.DanhMuc.Length > 0 && !mons.Any(m => string.Equals(m.DanhMuc, loc.DanhMuc, StringComparison.OrdinalIgnoreCase))) continue;
            if (khuVuc.Length > 0 && !BoDau(g.DiaChi).Contains(khuVuc)) continue;

            var mo = DangMoCua(g);
            if (loc.ChiDangMo && !mo) continue;
            if (loc.ChiKhuyenMai && !g.CoKhuyenMai && !MockData.DanhSachKhuyenMai.Any(k => k.DangHoatDong && k.ConHan && !k.ChuaBatDau && k.ConLuot && k.GianHangId == g.Id)) continue;
            if (loc.ChiQuanMoi && !g.LaQuanMoi) continue;

            if (loc.GiaTu is not null || loc.GiaDen is not null)
            {
                var tu = loc.GiaTu ?? 0; var den = loc.GiaDen ?? decimal.MaxValue;
                if (!mons.Any(m => m.ConHang && m.Gia >= tu && m.Gia <= den)) continue;
            }

            var (sao, soDg) = DiemQuan(g);
            if (loc.SaoTu > 0 && (sao < loc.SaoTu || (soDg == 0 && g.DanhGia < loc.SaoTu))) continue;

            var tuyen = GiaoHangService.UocTinh(diaChiKhach, g.DiaChi);
            double? km = tuyen.DaXacDinh ? tuyen.Km : null;
            if (loc.KmToiDa is { } maxKm && (km is null || km > maxKm)) continue;
            // v76: lọc theo thời gian giao dự kiến — dùng đúng số phút đang hiển thị trên thẻ quán (theo tuyến nếu biết, không thì ước tính của quán)
            var phutDuKien = tuyen.DaXacDinh && tuyen.Phut > 0 ? tuyen.Phut : g.ThoiGianGiaoPhut;
            if (loc.PhutToiDa is { } maxPhut && (phutDuKien <= 0 || phutDuKien > maxPhut)) continue;

            var conBan = mons.Where(m => m.ConHang).ToList();
            kq.Add(new QuanKetQua
            {
                Gh = g, DangMo = mo, Sao = sao, SoDanhGia = soDg, DaBan = daBan.GetValueOrDefault(g.Id),
                TuGia = conBan.Count > 0 ? conBan.Min(m => m.Gia) : null,
                Km = km, Phut = tuyen.DaXacDinh ? tuyen.Phut : 0, Phi = tuyen.DaXacDinh ? tuyen.Phi : null,
            });
        }

        IEnumerable<QuanKetQua> sx = loc.SapXep switch
        {
            "gan" => kq.OrderBy(q => q.Km ?? double.MaxValue).ThenByDescending(q => q.DangMo),
            "sao" => kq.OrderByDescending(q => q.Sao).ThenByDescending(q => q.SoDanhGia),
            "giaThap" => kq.OrderBy(q => q.TuGia ?? decimal.MaxValue),
            "giaCao" => kq.OrderByDescending(q => q.TuGia ?? 0),
            "banChay" => kq.OrderByDescending(q => q.DaBan).ThenByDescending(q => q.Sao),
            "giaoNhanh" => kq.OrderBy(q => q.Gh.ThoiGianGiaoPhut > 0 ? q.Gh.ThoiGianGiaoPhut + q.Phut : int.MaxValue).ThenByDescending(q => q.DangMo),
            _ => kq.OrderByDescending(q => q.DangMo).ThenByDescending(q => q.DaBan).ThenByDescending(q => q.Sao),
        };
        return sx.ToList();
    }

    /// <summary>Các món khớp từ khóa trong các quán đã lọc (để khách bấm thẳng vào quán bán món đó).</summary>
    public static List<MonAn> MonKhop(BoLocTimKiem loc, IEnumerable<QuanKetQua> quan, int toiDa = 8)
    {
        var ids = quan.Select(q => q.Gh.Id).ToHashSet();
        var tuKhoa = BoDau(loc.TuKhoa).Split(' ', StringSplitOptions.RemoveEmptyEntries);
        return MockData.DanhSachMonAn
            .Where(m => ids.Contains(m.GianHangId) && m.ConHang
                        && (loc.DanhMuc.Length == 0 || string.Equals(m.DanhMuc, loc.DanhMuc, StringComparison.OrdinalIgnoreCase))
                        && (loc.GiaTu is null || m.Gia >= loc.GiaTu) && (loc.GiaDen is null || m.Gia <= loc.GiaDen)
                        && (tuKhoa.Length == 0 || tuKhoa.All(BoDau(m.TenMon + " " + m.DanhMuc + " " + m.MoTa).Contains)))
            .Take(toiDa).ToList();
    }

    // ------------------------------------------------------------- lịch sử tìm kiếm
    public static List<string> LichSu()
    {
        try { return JsonSerializer.Deserialize<List<string>>(Preferences.Default.Get(KhoaLichSu, "[]")) ?? new(); }
        catch { return new(); }
    }

    public static void ThemLichSu(string? tuKhoa)
    {
        var k = (tuKhoa ?? "").Trim();
        if (k.Length < 2) return;
        if (k.Length > 60) k = k[..60];
        var ds = LichSu();
        ds.RemoveAll(x => x.Equals(k, StringComparison.OrdinalIgnoreCase));
        ds.Insert(0, k);
        if (ds.Count > ToiDaLichSu) ds = ds.Take(ToiDaLichSu).ToList();
        Preferences.Default.Set(KhoaLichSu, JsonSerializer.Serialize(ds));
    }

    public static bool CoDiaChiKhach => !string.IsNullOrWhiteSpace(Phien.Khach?.DiaChi);

    /// <summary>Xóa một từ khóa khỏi lịch sử tìm kiếm.</summary>
    public static void XoaMotLichSu(string? tuKhoa)
    {
        var ds = LichSu();
        if (ds.RemoveAll(x => x.Equals((tuKhoa ?? "").Trim(), StringComparison.OrdinalIgnoreCase)) > 0)
            Preferences.Default.Set(KhoaLichSu, JsonSerializer.Serialize(ds));
    }

    public static void XoaLichSu() => Preferences.Default.Remove(KhoaLichSu);

    // ------------------------------------------------------------- gợi ý phổ biến
    /// <summary>Tên món được đặt nhiều nhất; chưa có đơn thì lấy các món đang bán.</summary>
    public static List<string> MonPhoBien(int n = 8)
    {
        var tenQuanOk = MockData.DanhSachGianHang.Where(QuanHienThi).Select(g => g.Id).ToHashSet();
        var top = DonTinhBanChay().Where(d => tenQuanOk.Contains(d.GianHangId))
            .SelectMany(d => d.ChiTiet).Where(c => c.MonAn is not null)
            .GroupBy(c => c.MonAn.TenMon).OrderByDescending(g => g.Sum(c => c.SoLuong)).Select(g => g.Key).Take(n).ToList();
        if (top.Count >= n) return top;
        var them = MockData.DanhSachMonAn.Where(m => tenQuanOk.Contains(m.GianHangId) && m.ConHang).Select(m => m.TenMon)
            .Where(t => !top.Contains(t)).Distinct().Take(n - top.Count);
        top.AddRange(them);
        return top;
    }

    public static List<string> DanhMucMon() =>
        MockData.DanhSachMonAn.Where(m => !string.IsNullOrWhiteSpace(m.DanhMuc) && !m.TamNgungBan)
            .Select(m => m.DanhMuc.Trim()).Distinct(StringComparer.OrdinalIgnoreCase).OrderBy(x => x).ToList();
}

/// <summary>Một món trong thực đơn của quán (kèm nhãn Bán chạy / Nổi bật).</summary>
public class MonHienThi
{
    public MonAn Mon { get; init; } = null!;
    public string Nhan { get; init; } = "";
    public int DaBan { get; init; }
    public string TenMon => Mon.TenMon;
    public string HinhAnh => Mon.HinhAnh;
    public string AnhPath => Mon.AnhHienThi;
    public bool CoAnh => Mon.CoAnh;
    public bool CoEmoji => Mon.CoEmoji;
    public string MoTa => Mon.MoTa;
    public bool CoMoTa => !string.IsNullOrWhiteSpace(Mon.MoTa);
    public string GiaText => $"{Mon.Gia:N0}đ";
    public bool CoNhan => Nhan.Length > 0;
    public string DanhMuc => Mon.DanhMuc;
    /// <summary>v80: món có tùy chọn (size / topping / mức cay) → "+" mở trang chi tiết để chọn.</summary>
    public bool CoTuyChon => Mon.TuyChon.Count > 0;
    public string TuyChonText => Mon.TuyChon.Count == 0 ? "" : "🧩 " + string.Join(" · ", Mon.TuyChon.Select(t => TuyChonMon.NhanLoai(t.Loai)).Distinct());
    public string TimText => TaiKhoanService.LaYeuThichMon(Mon.Id) ? "♥ Đã thích" : "♡ Yêu thích";
    public string NhanMoi => Mon.LaMonMoi ? "🆕 Món mới" : "";
}

/// <summary>Thông tin tổng hợp để hiển thị trang quán.</summary>
public class ThongTinQuan
{
    public GianHang Gh { get; init; } = null!;
    public bool DangMo { get; init; }
    public bool CoTheDat { get; init; }
    public string LyDoKhongDat { get; init; } = "";
    public string GioKinhDoanh { get; init; } = "";
    public double Sao { get; init; }
    public int SoDanhGia { get; init; }
    public string PhiGiaoText { get; init; } = "";
    public string ThoiGianText { get; init; } = "";
    public List<KhuyenMai> DsKhuyenMai { get; init; } = new();
    public List<MonHienThi> BanChay { get; init; } = new();
    public List<MonHienThi> NoiBat { get; init; } = new();
    public List<MonHienThi> TatCaMon { get; init; } = new();
    public List<DanhGiaGianHang> DanhGia { get; init; } = new();

    // --- v90: thông tin quán bổ sung ---
    public List<string> AnhKhongGian { get; init; } = new();
    public int LuotBan { get; init; }
    public string LuotBanText => LuotBan > 0 ? $"🔥 {LuotBan:N0} món đã bán" : "🔥 Chưa có lượt bán";
    public string ThoiGianChuanBiText { get; init; } = "";
    public string PhamViGiaoText { get; init; } = "";
    public decimal DonToiThieu { get; init; }
    public string DonToiThieuText => DonToiThieu > 0 ? $"🧾 Đơn tối thiểu: {DonToiThieu:N0}đ" : "🧾 Không yêu cầu đơn tối thiểu";
    public string ChinhSachText { get; init; } = "";
    public List<MonHienThi> MonMoi { get; init; } = new();

    public static ThongTinQuan Tao(GianHang g)
    {
        var (sao, so) = TimKiemService.DiemQuan(g);
        var mons = MockData.DanhSachMonAn.Where(m => m.GianHangId == g.Id && m.ConHang).ToList();

        // Bán chạy: theo số phần đã bán. Nổi bật: món trong các đơn được khách chấm >= 4 sao (khác nhóm bán chạy)
        var daBan = TimKiemService.DaBanTheoMon(g.Id);
        var banChayIds = mons.Where(m => daBan.GetValueOrDefault(m.Id) > 0)
            .OrderByDescending(m => daBan[m.Id]).Take(4).Select(m => m.Id).ToList();

        var diemMon = MockData.LichSuDonHang.Concat(MockData.DonHangCuaGianHang).Concat(MockData.DonHangDaGiaoCuaTaiXe)
            .Where(d => d.GianHangId == g.Id && d.DiemMonAn >= 4).GroupBy(d => d.Id).Select(x => x.First())
            .SelectMany(d => d.ChiTiet.Where(c => c.MonAn is not null).Select(c => (c.MonAn.Id, d.DiemMonAn)))
            .GroupBy(x => x.Id).Select(x => (Id: x.Key, Avg: x.Average(y => y.DiemMonAn), Cnt: x.Count()))
            .OrderByDescending(x => x.Avg).ThenByDescending(x => x.Cnt).ToList();
        var noiBatIds = diemMon.Select(x => x.Id).Where(id => !banChayIds.Contains(id) && mons.Any(m => m.Id == id)).Take(4).ToList();

        MonHienThi Map(MonAn m, string nhan = "") => new() { Mon = m, Nhan = nhan, DaBan = daBan.GetValueOrDefault(m.Id) };
        var nhanCuaMon = (MonAn m) => banChayIds.Contains(m.Id) ? "🔥 Bán chạy" : noiBatIds.Contains(m.Id) ? "⭐ Nổi bật" : m.LaMonMoi ? "🆕 Món mới" : "";

        var lyDo = g.TaiKhoanBiKhoa ? "Quán đang tạm ngưng hoạt động."
            : !g.DangMoCua ? "Quán đang tạm đóng cửa."
            : !g.TrongGioHoatDong ? $"Quán ngoài giờ hoạt động ({g.GioMoCua} – {g.GioDongCua})."
            : !g.DangNhanDon ? "Quán tạm dừng nhận đơn mới."
            : "";

        var tuyen = GiaoHangService.UocTinh(Phien.Khach?.DiaChi, g.DiaChi);
        var km = MockData.DanhSachKhuyenMai
            .Where(k => k.DangHoatDong && k.ConHan && !k.ChuaBatDau && k.ConLuot && (k.GianHangId == g.Id || k.ApDungToanHeThong))
            .OrderByDescending(k => k.GianHangId == g.Id).ToList();

        return new ThongTinQuan
        {
            Gh = g, DangMo = TimKiemService.DangMoCua(g), CoTheDat = g.CoTheNhanDon, LyDoKhongDat = lyDo,
            GioKinhDoanh = g.GioMoCua == "00:00" && g.GioDongCua == "23:59" ? "Cả ngày (00:00 – 23:59)" : $"{g.GioMoCua} – {g.GioDongCua}",
            Sao = sao, SoDanhGia = so,
            PhiGiaoText = tuyen.DaXacDinh
                ? $"~{tuyen.Phi:N0}đ (ước tính, {tuyen.Km:0.#} km từ địa chỉ của bạn · phí chính thức xác nhận khi đặt)"
                : $"từ {GiaoHangService.PhiCoBan:N0}đ (tính theo quãng đường thật khi đặt hàng)",
            ThoiGianText = tuyen.DaXacDinh ? $"~{tuyen.Phut} phút (ước tính)" : (g.ThoiGianGiaoPhut > 0 ? $"~{g.ThoiGianGiaoPhut} phút" : "chưa rõ"),
            DsKhuyenMai = km,
            BanChay = banChayIds.Select(id => Map(mons.First(m => m.Id == id), "🔥 Bán chạy")).ToList(),
            NoiBat = noiBatIds.Select(id => Map(mons.First(m => m.Id == id), "⭐ Nổi bật")).ToList(),
            TatCaMon = mons.OrderBy(m => m.DanhMuc).ThenBy(m => m.TenMon).Select(m => Map(m, nhanCuaMon(m))).ToList(),
            DanhGia = DoiTacService.DanhGiaCua(g.Id).Where(d => d.SoSaoMonAn > 0).Take(10).ToList(),
            AnhKhongGian = (string.IsNullOrEmpty(g.AnhBiaUrlDayDu) ? Enumerable.Empty<string>() : new[] { g.AnhBiaUrlDayDu })
                .Concat(g.AnhKhongGianDayDu).Distinct().ToList(),
            LuotBan = daBan.Values.Sum(),
            ThoiGianChuanBiText = ThoiGianChuanBi(g, mons),
            PhamViGiaoText = PhamViGiao(g, tuyen),
            DonToiThieu = g.DonToiThieu,
            ChinhSachText = ChinhSachQuan(g),
            MonMoi = mons.Where(m => m.LaMonMoi).OrderByDescending(m => m.NgayTao).Take(6).Select(m => Map(m, "🆕 Món mới")).ToList(),
        };
    }

    /// <summary>Thời gian chuẩn bị: khai báo của quán; chưa có thì lấy trung bình thời gian chuẩn bị riêng của các món.</summary>
    private static string ThoiGianChuanBi(GianHang g, List<MonAn> mons)
    {
        if (g.ThoiGianChuanBiPhut > 0) return $"~{g.ThoiGianChuanBiPhut} phút";
        var ds = mons.Where(m => m.ThoiGianChuanBiPhut is > 0).Select(m => m.ThoiGianChuanBiPhut!.Value).ToList();
        return ds.Count > 0 ? $"~{(int)Math.Round(ds.Average())} phút (theo từng món)" : "quán xác nhận khi nhận đơn";
    }

    /// <summary>Phạm vi giao: bán kính của quán/chính sách; nếu biết địa chỉ khách thì báo trong hay ngoài phạm vi.</summary>
    private static string PhamViGiao(GianHang g, KetQuaTuyen tuyen)
    {
        var bk = ChinhSachService.BanKinhGiao(g);
        var goc = bk > 0 ? $"Giao trong bán kính {bk:0.#} km quanh quán" : "Quán chưa công bố bán kính giao hàng";
        if (bk <= 0 || !tuyen.DaXacDinh) return goc;
        return tuyen.Km <= bk
            ? $"{goc} · ✅ địa chỉ của bạn (~{tuyen.Km:0.#} km) nằm trong phạm vi"
            : $"{goc} · ⚠ địa chỉ của bạn (~{tuyen.Km:0.#} km) có thể nằm ngoài phạm vi";
    }

    /// <summary>Chính sách quán: quy định riêng (nếu có) + đơn tối thiểu + chính sách hủy/hoàn tiền chung của nền tảng.</summary>
    private static string ChinhSachQuan(GianHang g)
    {
        var cs = ChinhSachService.HienTai;
        var dong = new List<string>();
        if (!string.IsNullOrWhiteSpace(g.ChinhSach)) dong.Add("• " + g.ChinhSach.Trim());
        if (g.DonToiThieu > 0) dong.Add($"• Đơn tối thiểu {g.DonToiThieu:N0}đ.");
        dong.Add($"• Quán cần xác nhận đơn trong {cs.TuHuyPhut} phút; quá hạn đơn tự hủy và được hoàn tiền.");
        if (!string.IsNullOrWhiteSpace(cs.QuyDinhHuyDon)) dong.Add("• Hủy đơn: " + cs.QuyDinhHuyDon.Trim());
        if (!string.IsNullOrWhiteSpace(cs.ChinhSachHoanTien)) dong.Add("• Hoàn tiền: " + cs.ChinhSachHoanTien.Trim());
        return string.Join("\n", dong);
    }
}
