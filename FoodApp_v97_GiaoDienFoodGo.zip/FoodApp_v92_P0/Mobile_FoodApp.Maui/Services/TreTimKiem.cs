namespace FoodApp.Maui.Services;

/// <summary>
/// Làm trễ xử lý khi đang gõ (mặc định 280 ms sau phím cuối). Việc lọc/dựng lại danh sách/tính phí ngay trong từng phím gõ
/// có thể làm bộ gõ tiếng Việt (Telex/VNI) mất đồng bộ, đặc biệt trên Windows; chỉ xử lý khi người dùng ngừng gõ.
/// </summary>
public sealed class TreTimKiem
{
    private CancellationTokenSource? _cts;

    public void Chay(Action viec, int ms = 280)
    {
        _cts?.Cancel();
        var cts = _cts = new CancellationTokenSource();
        _ = Task.Run(async () =>
        {
            try { await Task.Delay(ms, cts.Token); } catch (TaskCanceledException) { return; }
            if (!cts.IsCancellationRequested) MainThread.BeginInvokeOnMainThread(viec);
        });
    }
}
