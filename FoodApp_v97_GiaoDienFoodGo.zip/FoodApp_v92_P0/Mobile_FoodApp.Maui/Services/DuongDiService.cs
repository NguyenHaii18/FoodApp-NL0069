namespace FoodApp.Maui.Services;

public sealed class DuongDiDto
{
    public bool DuongThat { get; set; }
    public double Km { get; set; }
    public int Phut { get; set; }
    public int PhutDuongThoang { get; set; }
    public double HeSoKetXe { get; set; }
    public string KhungGio { get; set; } = "";
    public string Polyline { get; set; } = "";
    /// <summary>Lý do máy chủ không trả được đường thật (khi DuongThat = false).</summary>
    public string LyDo { get; set; } = "";
}

public enum LoaiLoiDuongDi { KhongLoi, NgoaiTuyen, ChuaCoKhoa, KhongTimDuocTuyen, LoiMayChu, ToaDoSai }

/// <summary>Kết quả tìm đường: có đường thật, hoặc lý do + số liệu ước tính theo đường thẳng để vẫn hiển thị được (và được ghi rõ là ước tính).</summary>
public sealed class KqDuongDi
{
    public DuongDiDto? Duong { get; init; }
    public LoaiLoiDuongDi Loi { get; init; }
    public string ThongDiep { get; init; } = "";
    public double KmUocTinh { get; init; }
    public int PhutUocTinh { get; init; }
    public bool CoDuongThat => Duong is not null;
}

/// <summary>Đường đi THẬT giữa hai điểm (Goong Direction qua máy chủ: POST api/map/duong-di) để vẽ trên bản đồ. Cần máy chủ có khóa GoongMaps:ApiKey.
/// v94: phân loại lỗi, tự thử lại 1 lần khi lỗi mạng, và luôn kèm số liệu ước tính theo đường thẳng (đã ghi rõ là ước tính) khi không có đường thật.</summary>
public static class DuongDiService
{
    private static readonly Dictionary<string, DuongDiDto> _cache = new();

    public static void XoaCache() => _cache.Clear();

    /// <summary>Tương thích cũ: (đường thật hoặc null, lý do).</summary>
    public static async Task<(DuongDiDto? Kq, string LyDo)> LayAsync(double tuLat, double tuLng, double denLat, double denLng)
    {
        var k = await LayChiTietAsync(tuLat, tuLng, denLat, denLng);
        return (k.Duong, k.ThongDiep);
    }

    public static async Task<KqDuongDi> LayChiTietAsync(double tuLat, double tuLng, double denLat, double denLng, bool boQuaCache = false)
    {
        var km = Math.Round(GiaoHangService.KmChimBay(tuLat, tuLng, denLat, denLng) * GiaoHangService.HeSoDuongBo, 1);
        var phut = GiaoHangService.UocTinhPhut(km);
        KqDuongDi Loi(LoaiLoiDuongDi l, string tb) => new() { Loi = l, ThongDiep = tb, KmUocTinh = km, PhutUocTinh = phut };

        if (Math.Abs(tuLat) > 90 || Math.Abs(denLat) > 90 || Math.Abs(tuLng) > 180 || Math.Abs(denLng) > 180)
            return Loi(LoaiLoiDuongDi.ToaDoSai, "Tọa độ không hợp lệ.");
        if (!DuLieuService.DangOnline) return Loi(LoaiLoiDuongDi.NgoaiTuyen, "Đang ngoại tuyến.");

        var khoa = $"{tuLat:0.0003},{tuLng:0.0003}>{denLat:0.0003},{denLng:0.0003}";
        if (!boQuaCache && _cache.TryGetValue(khoa, out var da)) return new KqDuongDi { Duong = da, KmUocTinh = km, PhutUocTinh = phut };

        ApiKetQua<DuongDiDto>? r = null;
        for (var lan = 0; lan < 2; lan++)       // lỗi mạng thoáng qua: thử lại 1 lần
        {
            r = await ApiClient.PostAsync<DuongDiDto>("api/map/duong-di", new { tu = new { lat = tuLat, lng = tuLng }, den = new { lat = denLat, lng = denLng } });
            if (r.ThanhCong || !r.MatKetNoi) break;
            await Task.Delay(700);
        }
        if (r is null || !r.ThanhCong || r.DuLieu is null)
            return Loi(LoaiLoiDuongDi.LoiMayChu, string.IsNullOrWhiteSpace(r?.ThongDiep) ? "Máy chủ chưa trả được đường đi." : r!.ThongDiep);

        var d = r.DuLieu;
        if (d.DuongThat && !string.IsNullOrEmpty(d.Polyline))
        {
            if (_cache.Count > 100) _cache.Clear();
            return new KqDuongDi { Duong = _cache[khoa] = d, KmUocTinh = km, PhutUocTinh = phut };
        }
        var chuaKhoa = d.LyDo.Contains("chưa cấu hình", StringComparison.OrdinalIgnoreCase);
        return Loi(chuaKhoa ? LoaiLoiDuongDi.ChuaCoKhoa : LoaiLoiDuongDi.KhongTimDuocTuyen,
            string.IsNullOrWhiteSpace(d.LyDo) ? "Không tìm được tuyến đường giữa hai điểm này." : d.LyDo);
    }
}
