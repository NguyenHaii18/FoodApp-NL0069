using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>v91: tài xế xuất báo cáo thu nhập (Excel .xlsx) theo hôm nay / tuần / tháng rồi chia sẻ qua hộp thoại của hệ điều hành.</summary>
public static class ThuNhapXuatService
{
    public static async Task XuatAsync(Page trang)
    {
        var chon = await trang.DisplayActionSheet("Xuất báo cáo thu nhập", "Đóng", null, "Hôm nay", "Tuần này", "Tháng này", "Tất cả");
        if (chon is null or "Đóng") return;
        var hom = DateTime.Today;
        var (tu, den, ten) = chon switch
        {
            "Hôm nay" => (hom, hom, "hom-nay"),
            "Tuần này" => (ThuNhapService.DauTuan(hom), ThuNhapService.DauTuan(hom).AddDays(6), "tuan"),
            "Tháng này" => (new DateTime(hom.Year, hom.Month, 1), new DateTime(hom.Year, hom.Month, 1).AddMonths(1).AddDays(-1), "thang"),
            _ => (DateTime.MinValue.Date, hom, "tat-ca"),
        };
        try
        {
            var don = MockData.DonHangDaGiaoCuaTaiXe
                .Where(d => d.GiaoLuc is { } g && g.Date >= tu && g.Date <= den)
                .OrderByDescending(d => d.GiaoLuc).ToList();
            if (don.Count == 0) { await trang.DisplayAlert("Chưa có dữ liệu", "Không có đơn nào trong khoảng thời gian này.", "Đóng"); return; }

            var tk = ThuNhapService.Tong(tu, den, gomThuongTuan: true);
            var tong = new List<object?[]>
            {
                new object?[] { "Tài xế", MockData.TaiXeHienTai?.HoTen },
                new object?[] { "Số điện thoại", MockData.TaiXeHienTai?.SoDienThoai },
                new object?[] { "Kỳ báo cáo", chon == "Tất cả" ? "Tất cả" : $"{tu:dd/MM/yyyy} – {den:dd/MM/yyyy}" },
                new object?[] { "Ngày xuất", DateTime.Now.ToString("dd/MM/yyyy HH:mm") },
                new object?[] { },
                new object?[] { "Khoản mục", "Số tiền (đ)" },
                new object?[] { "Tiền giao hàng", tk.Phi },
                new object?[] { "Phụ cấp", tk.PhuCap },
                new object?[] { "Thưởng", tk.Thuong },
                new object?[] { "TỔNG THU NHẬP", tk.Tong },
                new object?[] { },
                new object?[] { "Đơn giao thành công", tk.SoDon },
                new object?[] { "Đơn không thành công", tk.SoThatBai },
            };

            var ct = new List<object?[]> { new object?[] { "Mã đơn", "Giờ giao", "Quán", "Kết quả", "Tiền giao", "Phụ cấp", "Thanh toán", "Khách trả" } };
            ct.AddRange(don.Select(d => new object?[]
            {
                d.Id, d.GiaoLuc!.Value.ToString("dd/MM/yyyy HH:mm"), d.TenGianHang,
                d.GiaoThatBai ? "Không thành công" : "Thành công",
                d.GiaoThatBai ? (d.TinhPhiKhiThatBai ? d.PhiGiaoHang : 0) : d.PhiGiaoHang,
                d.GiaoThatBai ? 0 : d.PhuCap, d.HinhThucHienThi, d.TongThanhToan,
            }));

            var duongDan = Path.Combine(FileSystem.CacheDirectory, $"ThuNhapTaiXe_{ten}_{DateTime.Now:yyyyMMdd_HHmm}.xlsx");
            new XlsxWriter().ThemSheet("Tong ket", tong).ThemSheet("Chi tiet don", ct).Luu(duongDan);
            await Share.Default.RequestAsync(new ShareFileRequest { Title = "Báo cáo thu nhập", File = new ShareFile(duongDan) });
        }
        catch (Exception ex) { await trang.DisplayAlert("Không xuất được báo cáo", ex.Message, "Đóng"); }
    }
}
