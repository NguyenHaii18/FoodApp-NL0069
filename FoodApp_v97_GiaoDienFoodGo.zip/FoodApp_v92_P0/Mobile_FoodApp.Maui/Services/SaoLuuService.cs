using System.Text.Json;

namespace FoodApp.Maui.Services;

public sealed class BanSaoLuu
{
    public string TenTep { get; set; } = "";
    public DateTime Luc { get; set; }
    public long KichThuoc { get; set; }
    public string LyDo { get; set; } = "";
    public bool HopLe { get; set; }
}

/// <summary>Sao lưu / phục hồi dữ liệu cục bộ của ứng dụng (tài khoản, món, đơn, khuyến mãi, đánh giá… do VendorLocalStore lưu).
/// Mỗi bản là một tệp JSON trong thư mục dữ liệu ứng dụng; tự sao lưu mỗi 24 giờ, giữ 7 bản mới nhất.
/// Lưu ý: đây là sao lưu DỮ LIỆU TRÊN THIẾT BỊ. Sao lưu cơ sở dữ liệu SQL Server là việc của máy chủ.</summary>
public static class SaoLuuService
{
    private const string KhoaLanCuoi = "sao-luu-lan-cuoi";
    private const int GiuToiDa = 7;
    private sealed class Goi { public int PhienBan { get; set; } = 1; public DateTime Luc { get; set; } public string LyDo { get; set; } = ""; public string DuLieu { get; set; } = ""; }

    private static string Thu => Path.Combine(FileSystem.AppDataDirectory, "sao-luu");

    public static DateTime? LanCuoi
    {
        get { var s = Preferences.Default.Get(KhoaLanCuoi, ""); return DateTime.TryParse(s, null, System.Globalization.DateTimeStyles.RoundtripKind, out var d) ? d : null; }
    }

    /// <summary>Tạo bản sao lưu mới. Trả về tên tệp, hoặc null nếu chưa có dữ liệu để sao lưu.</summary>
    public static string? Tao(string lyDo)
    {
        VendorLocalStore.Luu();   // chốt trạng thái hiện tại trước khi chụp
        var json = VendorLocalStore.DocTho();
        if (string.IsNullOrWhiteSpace(json)) return null;
        Directory.CreateDirectory(Thu);
        var ten = $"foodapp-{DateTime.Now:yyyyMMdd-HHmmss}.json";
        var goi = new Goi { Luc = DateTime.Now, LyDo = lyDo, DuLieu = json };
        File.WriteAllText(Path.Combine(Thu, ten), JsonSerializer.Serialize(goi));
        Preferences.Default.Set(KhoaLanCuoi, DateTime.Now.ToString("o"));
        DonBanCu();
        return ten;
    }

    /// <summary>Gọi khi mở ứng dụng: tự sao lưu nếu bản gần nhất đã quá 24 giờ.</summary>
    public static void TuDongNeuCan()
    {
        try
        {
            var cuoi = LanCuoi;
            if (cuoi is null || (DateTime.Now - cuoi.Value).TotalHours >= 24) Tao("Tự động");
        }
        catch (Exception ex) { CrashLog.Ghi("SaoLuu.TuDong", ex); }
    }

    public static List<BanSaoLuu> DanhSach()
    {
        if (!Directory.Exists(Thu)) return new();
        var kq = new List<BanSaoLuu>();
        foreach (var f in new DirectoryInfo(Thu).GetFiles("foodapp-*.json").OrderByDescending(x => x.Name))
        {
            var b = new BanSaoLuu { TenTep = f.Name, KichThuoc = f.Length, Luc = f.LastWriteTime };
            var g = Doc(f.Name);
            if (g is not null) { b.Luc = g.Luc; b.LyDo = g.LyDo; b.HopLe = KiemTraJson(g.DuLieu); }
            kq.Add(b);
        }
        return kq;
    }

    private static Goi? Doc(string ten)
    {
        try { return JsonSerializer.Deserialize<Goi>(File.ReadAllText(Path.Combine(Thu, Path.GetFileName(ten)))); }
        catch { return null; }
    }

    private static bool KiemTraJson(string json)
    {
        try { using var d = JsonDocument.Parse(json); return d.RootElement.ValueKind == JsonValueKind.Object && d.RootElement.TryGetProperty("GianHangs", out _); }
        catch { return false; }
    }

    /// <summary>Thử đọc bản sao lưu (không ghi gì) để biết có khôi phục được không. Trả về mô tả nội dung hoặc lỗi.</summary>
    public static (bool Ok, string MoTa) KiemTra(string ten)
    {
        var g = Doc(ten);
        if (g is null) return (false, "Tệp sao lưu bị hỏng hoặc không đọc được.");
        if (!KiemTraJson(g.DuLieu)) return (false, "Nội dung sao lưu không đúng định dạng.");
        using var d = JsonDocument.Parse(g.DuLieu);
        int Dem(string k) => d.RootElement.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.Array ? v.GetArrayLength() : 0;
        return (true, $"{Dem("GianHangs")} gian hàng · {Dem("KhachHangs")} khách · {Dem("MonAns")} món · {Dem("LichSu")} đơn khách · {Dem("KhuyenMais")} khuyến mãi");
    }

    /// <summary>Khôi phục: trước hết tự sao lưu trạng thái hiện tại (để hoàn tác), rồi nạp lại từ bản đã chọn.
    /// Nạp là GỘP vào dữ liệu đang chạy; nên khởi động lại ứng dụng sau khi khôi phục để dữ liệu sạch hoàn toàn.</summary>
    public static (bool Ok, string ThongDiep) KhoiPhuc(string ten)
    {
        var kt = KiemTra(ten);
        if (!kt.Ok) return (false, kt.MoTa);
        var g = Doc(ten)!;
        Tao("Trước khi khôi phục");
        VendorLocalStore.GhiTho(g.DuLieu);
        VendorLocalStore.Nap();
        return (true, "Đã khôi phục. Hãy khởi động lại ứng dụng để dữ liệu hiển thị đầy đủ.");
    }

    public static void Xoa(string ten)
    {
        try { File.Delete(Path.Combine(Thu, Path.GetFileName(ten))); } catch { }
    }

    private static void DonBanCu()
    {
        try
        {
            foreach (var f in new DirectoryInfo(Thu).GetFiles("foodapp-*.json").OrderByDescending(x => x.Name).Skip(GiuToiDa)) f.Delete();
        }
        catch { }
    }
}
