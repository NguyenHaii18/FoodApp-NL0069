﻿namespace FoodApp.Maui.Services;

/// <summary>
/// Sao chép vào clipboard KHÔNG làm văng app. Trên Windows, Clipboard.SetTextAsync hay ném COMException (CLIPBRD_E_CANT_OPEN, message rỗng)
/// khi clipboard đang bị tiến trình khác giữ (Win+V, TeamViewer, RDP...). Hàm này chạy trên UI thread, thử lại tối đa 3 lần,
/// và trả về false (thay vì ném lỗi) nếu vẫn không sao chép được.
/// </summary>
public static class ClipboardAnToan
{
    public static async Task<bool> SaoChepAsync(string? text)
    {
        if (string.IsNullOrEmpty(text)) return false;
        for (int i = 0; i < 3; i++)
        {
            try
            {
                await MainThread.InvokeOnMainThreadAsync(() => Clipboard.Default.SetTextAsync(text));
                return true;
            }
            catch (System.Runtime.InteropServices.COMException)
            {
                await Task.Delay(100);   // clipboard đang bị app khác giữ: đợi rồi thử lại
            }
            catch (Exception)
            {
                break;
            }
        }
        return false;
    }
}
