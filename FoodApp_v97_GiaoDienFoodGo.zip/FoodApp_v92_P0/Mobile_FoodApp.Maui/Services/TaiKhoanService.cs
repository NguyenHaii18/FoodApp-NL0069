using System.Text.Json;
using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

public class DiaChiLuu
{
    /// <summary>Mã bản ghi DiaChiKhachHang trên máy chủ; null = địa chỉ mới chỉ có trên máy (chưa đồng bộ).</summary>
    public int? MaDiaChi { get; set; }
    public string Nhan { get; set; } = "Nhà";
    public string DiaChi { get; set; } = "";
    public bool MacDinh { get; set; }
}

/// <summary>Sổ địa chỉ, quán yêu thích, mã giới thiệu của khách đang đăng nhập (lưu theo email trong Preferences).</summary>
public static class TaiKhoanService
{
    private static string Khoa(string loai) => $"{loai}:{Phien.Khach?.Email?.ToLowerInvariant() ?? "khach"}";

    // ---------- Sổ địa chỉ ----------
    public static List<DiaChiLuu> LayDiaChi()
    {
        List<DiaChiLuu> ds;
        try { ds = JsonSerializer.Deserialize<List<DiaChiLuu>>(Preferences.Default.Get(Khoa("so-dia-chi"), "[]")) ?? new(); }
        catch { ds = new(); }

        // lần đầu: đưa địa chỉ nhập lúc đăng ký vào sổ
        if (ds.Count == 0 && !string.IsNullOrWhiteSpace(Phien.Khach?.DiaChi))
        {
            ds.Add(new DiaChiLuu { Nhan = "Nhà", DiaChi = Phien.Khach!.DiaChi, MacDinh = true });
            LuuDiaChi(ds);
        }
        return ds;
    }

    public static void LuuDiaChi(List<DiaChiLuu> ds)
    {
        if (ds.Count > 0 && !ds.Any(d => d.MacDinh)) ds[0].MacDinh = true;
        Preferences.Default.Set(Khoa("so-dia-chi"), JsonSerializer.Serialize(ds));
        // địa chỉ mặc định = địa chỉ hiển thị ở trang chủ và tự điền khi thanh toán
        if (Phien.Khach is not null)
        {
            Phien.Khach.DiaChi = ds.FirstOrDefault(d => d.MacDinh)?.DiaChi ?? "";
            VendorLocalStore.Luu();
        }
    }

    // ---------- Quán yêu thích ----------
    public static HashSet<string> LayYeuThich()
    {
        try { return JsonSerializer.Deserialize<HashSet<string>>(Preferences.Default.Get(Khoa("yeu-thich"), "[]")) ?? new(); }
        catch { return new(); }
    }

    public static bool LaYeuThich(string gianHangId) => LayYeuThich().Contains(gianHangId);

    /// <summary>Đảo trạng thái yêu thích; trả về true nếu giờ đang là yêu thích.</summary>
    public static bool DaoYeuThich(string gianHangId)
    {
        var ds = LayYeuThich();
        var gio = ds.Add(gianHangId);
        if (!gio) ds.Remove(gianHangId);
        Preferences.Default.Set(Khoa("yeu-thich"), JsonSerializer.Serialize(ds));
        GhiNhoYeuThich("gh", gianHangId, gio);
        return gio;
    }

    // ---------- Món yêu thích ----------
    public static HashSet<string> LayYeuThichMon()
    {
        try { return JsonSerializer.Deserialize<HashSet<string>>(Preferences.Default.Get(Khoa("yeu-thich-mon"), "[]")) ?? new(); }
        catch { return new(); }
    }

    public static bool LaYeuThichMon(string monAnId) => LayYeuThichMon().Contains(monAnId);

    /// <summary>Đảo trạng thái yêu thích của một món; trả về true nếu giờ đang là yêu thích.</summary>
    public static bool DaoYeuThichMon(string monAnId)
    {
        var ds = LayYeuThichMon();
        var gio = ds.Add(monAnId);
        if (!gio) ds.Remove(monAnId);
        Preferences.Default.Set(Khoa("yeu-thich-mon"), JsonSerializer.Serialize(ds));
        GhiNhoYeuThich("mon", monAnId, gio);
        return gio;
    }

    // ---------- Đồng bộ yêu thích với máy chủ (v64) ----------
    // Máy giữ bản sao để dùng ngoại tuyến + hàng đợi thao tác chưa gửi; online thì gửi lên rồi kéo danh sách của máy chủ về gộp lại.
    private sealed class ThaoTacYeuThich { public string Loai { get; set; } = ""; public string Id { get; set; } = ""; public bool Them { get; set; } }
    private sealed class YeuThichMayChuDto { public List<int>? GianHang { get; set; } public List<int>? MonAn { get; set; } }
    private static readonly SemaphoreSlim _khoaYeuThich = new(1, 1);

    private static List<ThaoTacYeuThich> DocCho()
    {
        try { return JsonSerializer.Deserialize<List<ThaoTacYeuThich>>(Preferences.Default.Get(Khoa("yeu-thich-cho"), "[]")) ?? new(); }
        catch { return new(); }
    }

    private static void GhiCho(List<ThaoTacYeuThich> ds) =>
        Preferences.Default.Set(Khoa("yeu-thich-cho"), JsonSerializer.Serialize(ds));

    private static void GhiNhoYeuThich(string loai, string id, bool them)
    {
        var cho = DocCho();
        cho.RemoveAll(x => x.Loai == loai && x.Id == id);     // thao tác sau cùng thắng
        cho.Add(new ThaoTacYeuThich { Loai = loai, Id = id, Them = them });
        GhiCho(cho);
        _ = DongBoYeuThichAsync();                            // lỗi/ngoại tuyến: thao tác nằm lại trong hàng đợi, gửi ở lần sau
    }

    /// <summary>Gửi các thao tác còn chờ rồi kéo danh sách yêu thích của máy chủ về (đổi máy / cài lại vẫn còn). Không ném lỗi.</summary>
    public static async Task DongBoYeuThichAsync()
    {
        if (!DuLieuService.DangOnline || string.IsNullOrEmpty(ApiClient.Token) || Phien.Khach is null) return;
        await _khoaYeuThich.WaitAsync();
        try
        {
            var cho = DocCho();
            foreach (var t in cho.ToList())
            {
                if (!int.TryParse(t.Id, out var ma)) { cho.Remove(t); continue; }      // mã món/quán mẫu ngoại tuyến: không có trên máy chủ
                var url = $"api/mobile/khach-hang/yeu-thich/{(t.Loai == "gh" ? "gian-hang" : "mon-an")}/{ma}";
                var r = t.Them ? await ApiClient.PutAsync<object>(url, null) : await ApiClient.DeleteAsync<object>(url);
                if (r.ThanhCong || !r.MatKetNoi) cho.Remove(t);                         // máy chủ từ chối (quán/món không còn) thì bỏ; lỗi mạng thì giữ lại
                else break;
            }
            GhiCho(cho);

            var s = await ApiClient.GetAsync<YeuThichMayChuDto>("api/mobile/khach-hang/yeu-thich");
            if (!s.ThanhCong || s.DuLieu is null) return;
            GopYeuThich("yeu-thich", "gh", LayYeuThich(), s.DuLieu.GianHang, cho);
            GopYeuThich("yeu-thich-mon", "mon", LayYeuThichMon(), s.DuLieu.MonAn, cho);
        }
        catch (Exception) { /* bản trên máy vẫn dùng được; lần sau đồng bộ lại */ }
        finally { _khoaYeuThich.Release(); }
    }

    private static void GopYeuThich(string khoa, string loai, HashSet<string> tren, List<int>? mayChu, List<ThaoTacYeuThich> cho)
    {
        var kq = (mayChu ?? new()).Select(x => x.ToString()).ToHashSet();
        foreach (var t in cho.Where(x => x.Loai == loai)) { if (t.Them) kq.Add(t.Id); else kq.Remove(t.Id); }   // thao tác chưa gửi vẫn có hiệu lực
        foreach (var cu in tren.Where(x => !int.TryParse(x, out _))) kq.Add(cu);                                // giữ mục mẫu ngoại tuyến (id không phải số)
        Preferences.Default.Set(Khoa(khoa), JsonSerializer.Serialize(kq));
    }

    // ---------- Giới thiệu bạn bè ----------
    public static string MaGioiThieu
    {
        get
        {
            var goc = (Phien.Khach?.Email ?? Phien.Khach?.Id ?? "KHACH").ToUpperInvariant();
            var h = 0;
            foreach (var c in goc) h = unchecked(h * 31 + c);
            return "FOOD" + Math.Abs(h % 1_000_000).ToString("D6");
        }
    }
}
