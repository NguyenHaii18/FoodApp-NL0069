using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>
/// Quản lý khuyến mãi qua API máy chủ (gian hàng: api/mobile/gian-hang/khuyen-mai; quản trị: api/mobile/admin/khuyen-mai).
/// Mỗi hàm trả về null khi thành công, hoặc thông điệp lỗi của máy chủ. Khi app đang ngoại tuyến (không có token/API) các trang
/// dùng lại nhánh lưu cục bộ cũ — xem <see cref="Online"/>.
/// </summary>
public static class KhuyenMaiQuanLyService
{
    public static bool Online => DuLieuService.DangOnline;
    private static string Goc(bool admin) => admin ? "api/mobile/admin/khuyen-mai" : "api/mobile/gian-hang/khuyen-mai";
    private static string Loi(ApiKetQua<object> r) => string.IsNullOrWhiteSpace(r.ThongDiep) ? "Máy chủ không phản hồi hợp lệ. Thử lại sau." : r.ThongDiep;

    private static object Body(KhuyenMai k) => new
    {
        maCode = k.MaCode,
        tenChuongTrinh = k.TenChuongTrinh,
        moTa = k.MoTa,
        loaiGiam = k.LoaiGiam.ToString(),
        giaTriGiam = k.GiaTriGiam,
        giaTriDonToiThieu = k.GiaTriDonToiThieu,
        giamToiDa = k.GiamToiDa,
        ngayBatDau = k.NgayBatDau,
        ngayKetThuc = k.NgayKetThuc,
        soLuongToiDa = k.SoLuongToiDa,
        moiKhachMotLan = k.MoiKhachMotLan,
        dangHoatDong = k.DangHoatDong,
        gianHangId = int.TryParse(k.GianHangId, out var gh) ? gh : (int?)null,
        monApDung = k.MonApDung,
        danhMucApDung = k.DanhMucApDung,
        gianHangApDung = k.GianHangApDung,
    };

    /// <summary>Tải toàn bộ mã của gian hàng hiện tại (hoặc mọi mã nếu là quản trị) vào MockData.DanhSachKhuyenMai.</summary>
    public static async Task<string?> TaiAsync(bool admin)
    {
        if (!Online) return null;
        var r = await ApiClient.GetAsync<List<KhuyenMai>>(Goc(admin));
        if (!r.ThanhCong || r.DuLieu is null) return string.IsNullOrWhiteSpace(r.ThongDiep) ? "Không tải được danh sách khuyến mãi." : r.ThongDiep;
        if (admin) MockData.DanhSachKhuyenMai.Clear();
        else
        {
            var gh = MockData.GianHangHienTai?.Id;
            foreach (var cu in MockData.DanhSachKhuyenMai.Where(k => k.GianHangId == gh).ToList()) MockData.DanhSachKhuyenMai.Remove(cu);
        }
        foreach (var k in r.DuLieu) MockData.DanhSachKhuyenMai.Add(k);
        return null;
    }

    /// <summary>Tạo mới (Id không phải số) hoặc cập nhật (Id là mã máy chủ). Thành công: bản máy chủ trả về thay vào MockData.</summary>
    public static async Task<string?> LuuAsync(KhuyenMai km, bool admin)
    {
        var coId = int.TryParse(km.Id, out var id);
        var r = coId
            ? await ApiClient.PutAsync<KhuyenMai>($"{Goc(admin)}/{id}", Body(km))
            : await ApiClient.PostAsync<KhuyenMai>(Goc(admin), Body(km));
        if (!r.ThanhCong || r.DuLieu is null) return string.IsNullOrWhiteSpace(r.ThongDiep) ? "Không lưu được khuyến mãi." : r.ThongDiep;
        foreach (var cu in MockData.DanhSachKhuyenMai.Where(k => k.Id == r.DuLieu.Id || k.Id == km.Id).ToList()) MockData.DanhSachKhuyenMai.Remove(cu);
        MockData.DanhSachKhuyenMai.Add(r.DuLieu);
        return null;
    }

    public static async Task<string?> BatTatAsync(KhuyenMai km, bool bat, bool admin)
    {
        if (!int.TryParse(km.Id, out var id)) return null;   // mã chỉ có trên máy: không có gì để gọi
        var r = await ApiClient.PutAsync<object>($"{Goc(admin)}/{id}/tinh-trang", new { dangHoatDong = bat });
        return r.ThanhCong ? null : Loi(r);
    }

    public static async Task<string?> XoaAsync(KhuyenMai km, bool admin)
    {
        if (!int.TryParse(km.Id, out var id)) return null;
        var r = await ApiClient.DeleteAsync<object>($"{Goc(admin)}/{id}");
        return r.ThanhCong ? null : Loi(r);
    }
}
