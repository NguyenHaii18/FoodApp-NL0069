using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

public sealed class BuocLoTrinhThat { public int MaDon { get; set; } public string Loai { get; set; } = ""; public string DiaChi { get; set; } = ""; public double Km { get; set; } public int Phut { get; set; } public int PhutKhongKetXe { get; set; } }
public sealed class DiemBanDo { public double Lat { get; set; } public double Lng { get; set; } public int MaDon { get; set; } public string Loai { get; set; } = ""; }
public sealed class LoTrinhThatDto
{
    public bool DuongThat { get; set; }
    public string Nguon { get; set; } = "";
    public double TongKm { get; set; }
    public int TongPhut { get; set; }
    public double? KmThuTuGoc { get; set; }
    public int TongPhutKhongKetXe { get; set; }
    public double HeSoKetXe { get; set; } = 1;
    public string GhiChuKetXe { get; set; } = "";
    public List<DiemBanDo> Diem { get; set; } = new();
    public DiemBanDo? BatDau { get; set; }
    /// <summary>Từng chặng: danh sách [lat,lng]; rỗng nếu Goong không trả đường chi tiết (bản đồ vẽ đường thẳng).</summary>
    public List<List<double[]>> Chang { get; set; } = new();
    public List<BuocLoTrinhThat> Buoc { get; set; } = new();
}

/// <summary>Tối ưu lộ trình theo ĐƯỜNG THẬT: gọi POST api/map/lo-trinh (máy chủ geocode + Goong DistanceMatrix + giải 2-opt có ràng buộc lấy-trước-giao).
/// Nếu máy chủ chưa có khóa Goong / địa chỉ không geocode được / quá 8 điểm → trả lý do để màn hình dùng bản ước tính theo quận/huyện.</summary>
public static class LoTrinhThatService
{
    public const int ToiDaDiem = 8;

    public static async Task<(LoTrinhThatDto? Kq, string LyDoLoi)> ToiUuAsync(IEnumerable<DonTaiXeItem> dons)
    {
        var diem = new List<object>();
        foreach (var d in dons)
        {
            bool daLay = d.TrangThaiGiao == "DangGiao";
            if (!daLay && !string.IsNullOrWhiteSpace(d.DiaChiGianHang)) diem.Add(new { maDon = d.MaDonHang, loai = "lay", diaChi = d.DiaChiGianHang, daLayTruoc = false });
            if (!string.IsNullOrWhiteSpace(d.DiaChiGiaoHang)) diem.Add(new { maDon = d.MaDonHang, loai = "giao", diaChi = d.DiaChiGiaoHang, daLayTruoc = daLay });
        }
        if (diem.Count < 2) return (null, "Không đủ điểm dừng.");
        if (diem.Count > ToiDaDiem) return (null, $"Có {diem.Count} điểm dừng (> {ToiDaDiem}) nên dùng bản ước tính.");

        object? batDau = ViTriTaiXeService.ViTriCuoi is { } v ? new { lat = v.Lat, lng = v.Lng } : null;
        var r = await ApiClient.PostAsync<LoTrinhThatDto>("api/map/lo-trinh", new { diem, batDau });
        if (r.ThanhCong && r.DuLieu is { DuongThat: true }) return (r.DuLieu, "");
        return (null, string.IsNullOrWhiteSpace(r.ThongDiep) ? "Máy chủ không tính được đường thật." : r.ThongDiep);
    }
}
