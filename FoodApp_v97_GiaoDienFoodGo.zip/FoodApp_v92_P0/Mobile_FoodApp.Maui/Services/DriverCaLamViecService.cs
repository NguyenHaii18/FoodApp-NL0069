using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>
/// v91: thời gian hoạt động trong ngày và nghỉ giải lao của tài xế.
/// - Giờ hoạt động = tổng thời gian Online trong ngày (cộng dồn qua nhiều phiên, lưu theo số điện thoại).
/// - Nghỉ giải lao = tạm không nhận đơn trong N phút rồi tự bật nhận đơn lại (vẫn Online, vẫn giữ kết nối).
/// </summary>
public static class DriverCaLamViecService
{
    private static string Ma() => MockData.TaiXeHienTai?.SoDienThoai is { Length: > 0 } s ? s : "tx";
    private static string KhoaNgay() => $"ca-ngay:{Ma()}:{DateTime.Today:yyyyMMdd}";
    private static string KhoaPhien() => $"ca-phien:{Ma()}";
    private static string KhoaNghi() => $"ca-nghi:{Ma()}";
    private static IDispatcherTimer? _timer;

    /// <summary>Phát khi trạng thái nghỉ thay đổi (bắt đầu / kết thúc) để màn hình vẽ lại.</summary>
    public static event Action? ThayDoi;

    // ---------------- giờ hoạt động
    public static void BatDauPhien()
    {
        if (Preferences.Default.ContainsKey(KhoaPhien())) return;   // đang có phiên
        Preferences.Default.Set(KhoaPhien(), DateTime.Now.ToString("o"));
    }

    public static void KetThucPhien()
    {
        var bd = PhienDangChay();
        if (bd is null) return;
        CongDon(bd.Value, DateTime.Now);
        Preferences.Default.Remove(KhoaPhien());
    }

    private static DateTime? PhienDangChay() =>
        DateTime.TryParse(Preferences.Default.Get(KhoaPhien(), ""), null, System.Globalization.DateTimeStyles.RoundtripKind, out var d) ? d : null;

    /// <summary>Cộng thời gian của phiên [bd, kt] vào các ngày tương ứng (phiên qua nửa đêm được tách đôi).</summary>
    private static void CongDon(DateTime bd, DateTime kt)
    {
        for (var ngay = bd.Date; ngay <= kt.Date; ngay = ngay.AddDays(1))
        {
            var tu = bd > ngay ? bd : ngay; var den = kt < ngay.AddDays(1) ? kt : ngay.AddDays(1);
            if (den <= tu) continue;
            var khoa = $"ca-ngay:{Ma()}:{ngay:yyyyMMdd}";
            Preferences.Default.Set(khoa, Preferences.Default.Get(khoa, 0.0) + (den - tu).TotalSeconds);
        }
    }

    /// <summary>Tổng thời gian Online hôm nay (gồm phiên đang chạy).</summary>
    public static TimeSpan HoatDongHomNay()
    {
        var giay = Preferences.Default.Get(KhoaNgay(), 0.0);
        if (PhienDangChay() is { } bd)
        {
            var tu = bd > DateTime.Today ? bd : DateTime.Today;
            giay += Math.Max(0, (DateTime.Now - tu).TotalSeconds);
        }
        return TimeSpan.FromSeconds(giay);
    }

    public static string HoatDongHomNayText()
    {
        var t = HoatDongHomNay();
        return t.TotalMinutes < 1 ? "chưa có" : t.TotalHours >= 1 ? $"{(int)t.TotalHours} giờ {t.Minutes} phút" : $"{t.Minutes} phút";
    }

    // ---------------- nghỉ giải lao
    public static DateTime? NghiDen =>
        DateTime.TryParse(Preferences.Default.Get(KhoaNghi(), ""), null, System.Globalization.DateTimeStyles.RoundtripKind, out var d) && d > DateTime.Now ? d : null;
    public static bool DangNghi => NghiDen is not null;

    public static async Task<bool> BatDauNghiAsync(int phut)
    {
        var t = MockData.TaiXeHienTai;
        if (t is null || !t.DangOnline) return false;
        if (MockData.DonHangDangGiaoCuaTaiXe is not null) return false;      // đang giao đơn: không nghỉ
        Preferences.Default.Set(KhoaNghi(), DateTime.Now.AddMinutes(phut).ToString("o"));
        t.DangHoatDong = false;
        await DongBoAsync(t);
        NhatKyService.Ghi("TaiXe", t.SoDienThoai, $"Nghỉ giải lao {phut} phút");
        BatDongHo();
        ThayDoi?.Invoke();
        return true;
    }

    public static async Task KetThucNghiAsync()
    {
        Preferences.Default.Remove(KhoaNghi());
        _timer?.Stop();
        var t = MockData.TaiXeHienTai;
        if (t is not null && t.DangOnline)
        {
            t.DangHoatDong = true;
            await DongBoAsync(t);
            NhatKyService.Ghi("TaiXe", t.SoDienThoai, "Hết giờ nghỉ — tiếp tục nhận đơn");
            try { _ = CommunityToolkit.Maui.Alerts.Toast.Make("☕ Hết giờ nghỉ — bạn đã sẵn sàng nhận đơn", CommunityToolkit.Maui.Core.ToastDuration.Long).Show(); } catch { }
        }
        ThayDoi?.Invoke();
    }

    /// <summary>Gọi khi mở app / mở màn hình: nghỉ đã quá hạn thì tự bật nhận đơn lại; còn hạn thì đặt hẹn giờ.</summary>
    public static async Task KhoiPhucAsync()
    {
        var raw = Preferences.Default.Get(KhoaNghi(), "");
        if (string.IsNullOrEmpty(raw)) return;
        if (NghiDen is null) await KetThucNghiAsync(); else BatDongHo();
    }

    private static void BatDongHo()
    {
        var dp = Application.Current?.Dispatcher;
        if (dp is null) return;
        _timer ??= dp.CreateTimer();
        _timer.Interval = TimeSpan.FromSeconds(15);
        _timer.Tick -= OnTick; _timer.Tick += OnTick;
        _timer.Start();
    }

    private static async void OnTick(object? s, EventArgs e)
    {
        if (!DangNghi) await KetThucNghiAsync();
    }

    private static async Task DongBoAsync(TaiXe t)
    {
        TaiXeStore.Luu();
        if (DuLieuService.DangOnline)
            await DuLieuService.GhiAsync("PUT", "api/mobile/tai-xe/trang-thai",
                new { trangThai = t.NhanDuocDon ? "SanSang" : t.DangOnline ? "TamNghi" : "NgoaiTuyen" });
    }
}
