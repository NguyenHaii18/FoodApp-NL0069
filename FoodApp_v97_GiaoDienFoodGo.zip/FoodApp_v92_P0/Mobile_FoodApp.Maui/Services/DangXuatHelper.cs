namespace FoodApp.Maui.Services;

/// <summary>
/// Đường lui khi bấm "Đăng xuất" gặp lỗi (mất mạng lúc thu hồi phiên, lỗi điều hướng...). Các nút đăng xuất là async void nên một ngoại lệ
/// không bắt sẽ làm app văng ra màn hình lỗi (Visual Studio dừng tại dòng code). Ở đây: ghi log, vẫn xóa phiên trên máy và đưa về trang đăng nhập.
/// </summary>
public static class DangXuatHelper
{
    public static async Task LoiAsync(Exception ex)
    {
        CrashLog.Ghi("DangXuat", ex);
        try { Phien.DangXuat(); } catch (Exception e2) { CrashLog.Ghi("DangXuat.XoaPhien", e2); }
        try { ApiClient.Token = null; } catch { /* bỏ qua */ }
        try
        {
            await MainThread.InvokeOnMainThreadAsync(async () =>
            {
                if (Shell.Current is not null) await Shell.Current.GoToAsync("//dang-nhap");
            });
        }
        catch (Exception e3) { CrashLog.Ghi("DangXuat.DieuHuong", e3); }
    }
}
