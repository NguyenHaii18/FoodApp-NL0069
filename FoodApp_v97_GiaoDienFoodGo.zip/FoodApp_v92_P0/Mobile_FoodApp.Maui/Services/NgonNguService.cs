using System.Runtime.CompilerServices;

namespace FoodApp.Maui.Services;

/// <summary>
/// Đa ngôn ngữ Việt / Anh. Cách làm: chữ gốc trong XAML/code giữ tiếng Việt (là "khóa"); khi mỗi trang hiện ra, <see cref="AnDung"/> duyệt cây giao diện
/// và thay Label/Button/Entry/Editor/Title... bằng bản tiếng Anh nếu có trong từ điển. Chuyển lại tiếng Việt sẽ khôi phục đúng chữ gốc.
/// GIỚI HẠN: chỉ dịch chữ cố định có trong từ điển; chữ ghép động ($"...{x}"), thông báo DisplayAlert và các mục trong CollectionView chưa dịch.
/// Muốn dịch thêm: bổ sung cặp "tiếng Việt" → "English" vào <see cref="TuDien"/> (hoặc dùng <see cref="T"/> trong code).
/// </summary>
public static class NgonNguService
{
    private const string KhoaLuu = "ngon-ngu";
    public static string Hien { get; private set; } = "vi";
    public static bool LaTiengAnh => Hien == "en";
    public static event Action? DaDoi;

    public static void Nap()
    {
        try { Hien = Preferences.Default.Get(KhoaLuu, "vi") == "en" ? "en" : "vi"; } catch { Hien = "vi"; }
    }

    public static void Dat(string ma)
    {
        Hien = ma == "en" ? "en" : "vi";
        try { Preferences.Default.Set(KhoaLuu, Hien); } catch { }
        DaDoi?.Invoke();
        ApDungChoTrangHienTai();
    }

    /// <summary>Dịch một chuỗi dùng trong code (tiếng Việt → ngôn ngữ hiện tại).</summary>
    public static string T(string? vi)
    {
        if (string.IsNullOrEmpty(vi) || !LaTiengAnh) return vi ?? "";
        return TuDien.TryGetValue(vi.Trim(), out var en) ? en : vi;
    }

    // ---------- Duyệt cây giao diện ----------
    private sealed class Goc { public string? Text, Placeholder, Title; public string? DaDatText, DaDatPlaceholder, DaDatTitle; }
    private static readonly ConditionalWeakTable<Element, Goc> Luu = new();

    private static string? Chon(string? hienTai, ref string? goc, ref string? daDat)
    {
        if (string.IsNullOrEmpty(hienTai)) return hienTai;
        if (hienTai != daDat) goc = hienTai;                     // chữ vừa được code đổi (động) → coi là chữ gốc mới
        var dich = LaTiengAnh && goc is not null && TuDien.TryGetValue(goc.Trim(), out var en) ? en : goc;
        daDat = dich;
        return dich;
    }

    public static void AnDung(Element? e)
    {
        if (e is null) return;
        try
        {
            var g = Luu.GetOrCreateValue(e);
            switch (e)
            {
                case Label l: { var v = Chon(l.Text, ref g.Text, ref g.DaDatText); if (v != null && v != l.Text) l.Text = v; break; }
                case Button b: { var v = Chon(b.Text, ref g.Text, ref g.DaDatText); if (v != null && v != b.Text) b.Text = v; break; }
                case Entry en: { var v = Chon(en.Placeholder, ref g.Placeholder, ref g.DaDatPlaceholder); if (v != null && v != en.Placeholder) en.Placeholder = v; break; }
                case Editor ed: { var v = Chon(ed.Placeholder, ref g.Placeholder, ref g.DaDatPlaceholder); if (v != null && v != ed.Placeholder) ed.Placeholder = v; break; }
                case Page p: { var v = Chon(p.Title, ref g.Title, ref g.DaDatTitle); if (v != null && v != p.Title) p.Title = v; break; }
                case ShellContent sc: { var v = Chon(sc.Title, ref g.Title, ref g.DaDatTitle); if (v != null && v != sc.Title) sc.Title = v; break; }
            }
            if (e is Shell shell)
                foreach (var item in shell.Items) AnDung(item);
            if (e is IVisualTreeElement vt)
                foreach (var con in vt.GetVisualChildren())
                    if (con is Element el) AnDung(el);
            if (e is ShellItem si)
                foreach (var s in si.Items) AnDung(s);
            if (e is ShellSection ss)
                foreach (var c in ss.Items) AnDung(c);
        }
        catch { /* dịch lỗi không được làm hỏng trang */ }
    }

    public static void ApDungChoTrangHienTai()
    {
        try
        {
            if (Application.Current?.MainPage is Shell sh)
            {
                AnDung(sh);
                AnDung(sh.CurrentPage);
            }
        }
        catch { }
    }

    /// <summary>Gắn một lần khi khởi động: mỗi trang hiện ra đều được dịch.</summary>
    public static void KhoiTao()
    {
        Nap();
        if (Application.Current is { } app)
            app.PageAppearing += (_, p) => AnDung(p);
        if (LaTiengAnh) ApDungChoTrangHienTai();
    }

    public static readonly Dictionary<string, string> TuDien = new()
    {
        ["Khởi động"] = "Start",
        ["Đăng nhập"] = "Log in",
        ["Trang chủ"] = "Home",
        ["Đơn hàng"] = "Orders",
        ["Ưu đãi"] = "Offers",
        ["Tài khoản"] = "Account",
        ["Giao đồ ăn"] = "Food delivery",
        ["Thêm địa chỉ giao hàng"] = "Add delivery address",
        ["Món ngon"] = "Tasty dishes",
        ["mỗi ngày"] = "every day",
        ["Ưu đãi hấp dẫn từ nhà hàng"] = "Great deals from restaurants",
        ["Đặt ngay"] = "Order now",
        ["⚙ Bộ lọc &amp; sắp xếp"] = "⚙ Filter & sort",
        ["⚙ Bộ lọc & sắp xếp"] = "⚙ Filter & sort",
        ["Xóa lọc ✕"] = "Clear filters ✕",
        ["Chỉ quán đang mở cửa"] = "Open shops only",
        ["Xóa bộ lọc"] = "Clear filters",
        ["🕘 Tìm kiếm gần đây"] = "🕘 Recent searches",
        ["Xóa lịch sử"] = "Clear history",
        ["🔥 Món phổ biến"] = "🔥 Popular dishes",
        ["🎟️ Ưu đãi hot"] = "🎟️ Hot offers",
        ["Chạm để lấy mã"] = "Tap to get the code",
        ["📰 Tin mới"] = "📰 News",
        ["Xem tất cả ›"] = "See all ›",
        ["🍽️ Món phù hợp"] = "🍽️ Matching dishes",
        ["🏪 Quán gần bạn"] = "🏪 Shops near you",
        ["Xem tất cả  →"] = "See all →",
        ["Danh mục món ăn"] = "Food categories",
        ["Mức giá"] = "Price range",
        ["Đánh giá sao"] = "Star rating",
        ["Khoảng cách"] = "Distance",
        ["Sắp xếp theo"] = "Sort by",
        ["Tìm món ăn, nhà hàng, món ngon..."] = "Search dishes, restaurants...",
        ["Khu vực / địa chỉ (VD: Quận 1, Bình Thạnh)"] = "Area / address (e.g. District 1)",
        ["🏷️ Khuyến mãi"] = "🏷️ Promotions",
        ["🔥 Món bán chạy"] = "🔥 Best sellers",
        ["⭐ Món nổi bật (khách chấm cao)"] = "⭐ Top-rated dishes",
        ["📖 Thực đơn"] = "📖 Menu",
        ["Quán chưa có món nào đang bán."] = "This shop has no dishes on sale.",
        ["💬 Đánh giá của khách"] = "💬 Customer reviews",
        ["Thực đơn"] = "Menu",
        ["Địa chỉ giao hàng"] = "Delivery address",
        ["🗺️ Tìm / chọn địa chỉ trên bản đồ"] = "🗺️ Find / pick address on map",
        ["📒 Chọn từ sổ địa chỉ"] = "📒 Pick from address book",
        ["Thời gian giao"] = "Delivery time",
        ["Hình thức thanh toán"] = "Payment method",
        ["Mã khuyến mãi (nếu có)"] = "Promo code (if any)",
        ["Áp dụng"] = "Apply",
        ["🎟️ Chọn ưu đãi"] = "🎟️ Choose an offer",
        ["Ghi chú cho gian hàng"] = "Note for the shop",
        ["Chi tiết đơn hàng"] = "Order details",
        ["Tạm tính"] = "Subtotal",
        ["Phí giao hàng"] = "Delivery fee",
        ["Giảm giá"] = "Discount",
        ["Tổng cộng"] = "Total",
        ["Thanh toán"] = "Pay",
        ["Chọn thời gian giao"] = "Choose delivery time",
        ["Đơn hàng của tôi"] = "My orders",
        ["Chưa có đơn hàng nào"] = "No orders yet",
        ["Giao diện"] = "Appearance",
        ["Chế độ sáng / tối"] = "Light / dark mode",
        ["☀️ Sáng"] = "☀️ Light",
        ["🌙 Tối"] = "🌙 Dark",
        ["📱 Hệ thống"] = "📱 System",
        ["Màu chủ đề"] = "Theme color",
        ["Thông báo"] = "Notifications",
        ["🔔  Thông báo đơn hàng"] = "🔔  Order notifications",
        ["Báo khi đơn đổi trạng thái"] = "Notify when an order changes status",
        ["🎁  Khuyến mãi & tin mới"] = "🎁  Promotions & news",
        ["🎁  Khuyến mãi &amp; tin mới"] = "🎁  Promotions & news",
        ["Hiện mục Ưu đãi hot và Tin mới ở trang chủ"] = "Show Hot offers and News on the home page",
        ["🔊  Âm thanh & rung"] = "🔊  Sound & vibration",
        ["🔊  Âm thanh &amp; rung"] = "🔊  Sound & vibration",
        ["Phát âm khi có thông báo trong app"] = "Play a sound for in-app notifications",
        ["Quyền riêng tư"] = "Privacy",
        ["📡  Cho phép dùng vị trí"] = "📡  Allow location",
        ["Gợi ý quán gần bạn"] = "Suggest shops near you",
        ["🔒  Hỏi xác nhận trước khi đặt hàng"] = "🔒  Confirm before placing an order",
        ["Tránh đặt nhầm đơn"] = "Avoid ordering by mistake",
        ["Kết nối máy chủ"] = "Server connection",
        ["Kiểm tra kết nối"] = "Test connection",
        ["Đổi địa chỉ"] = "Change address",
        ["Dữ liệu"] = "Data",
        ["🧹  Xóa toàn bộ dữ liệu trên máy"] = "🧹  Erase all data on this device",
        ["Cài đặt"] = "Settings",
        ["Quán yêu thích"] = "Favorite shops",
        ["Chưa có thông báo nào"] = "No notifications yet",
        ["Ghi chú cho quán"] = "Note for the shop",
        ["Chi tiết món"] = "Dish details",
        ["Ví dụ: ít cay, không hành..."] = "e.g. less spicy, no onion...",
        ["Đặt hàng thành công!"] = "Order placed successfully!",
        ["Đặt hàng thành công"] = "Order placed",
        ["Xem chi tiết đơn hàng"] = "View order details",
        ["Về trang chủ"] = "Back to home",
        ["🍜 Món ăn (bắt buộc)"] = "🍜 Dish (required)",
        ["🏪 Quán (phục vụ, đóng gói, thái độ)"] = "🏪 Shop (service, packaging, attitude)",
        ["🛵 Tài xế giao hàng"] = "🛵 Delivery driver",
        ["Bạn thích điều gì? (tuỳ chọn)"] = "What did you like? (optional)",
        ["Nhận xét chi tiết (tuỳ chọn)"] = "Detailed comment (optional)",
        ["Gửi đánh giá"] = "Submit review",
        ["Cảm ơn bạn đã đánh giá!"] = "Thank you for your review!",
        ["Quay lại"] = "Back",
        ["Đánh giá đơn hàng"] = "Rate your order",
        ["Tất cả"] = "All",
        ["Đang xử lý"] = "In progress",
        ["Hoàn thành"] = "Completed",
        ["Đã hủy"] = "Cancelled",
        ["Hủy đơn"] = "Cancel order",
        ["🔁 Đặt lại"] = "🔁 Reorder",
        ["⭐ Đánh giá"] = "⭐ Rate",
        ["Chi tiết ▼"] = "Details ▼",
        ["Thu gọn ▲"] = "Collapse ▲",
        ["Chờ xác nhận"] = "Awaiting confirmation",
        ["Chuẩn bị"] = "Preparing",
        ["Tài xế nhận"] = "Driver accepted",
        ["Đang giao"] = "Delivering",
        ["Thêm vào giỏ hàng"] = "Add to cart",
        ["Tùy chọn của quán"] = "Shop options",
        ["Xem giỏ hàng"] = "View cart",
        ["Đăng xuất"] = "Log out",
        ["Hồ sơ"] = "Profile",
        ["Địa chỉ"] = "Addresses",
        ["Đổi mật khẩu"] = "Change password",
        ["Ngôn ngữ"] = "Language",
        ["Tiếng Việt"] = "Vietnamese",
        ["Tiếng Anh"] = "English",
        ["Đóng"] = "Close",
        ["Hủy"] = "Cancel",
        ["Đồng ý"] = "OK",
        ["Lưu"] = "Save",
        ["Xóa"] = "Delete",
        ["Sửa"] = "Edit",
        ["Thêm"] = "Add"
    };
}
