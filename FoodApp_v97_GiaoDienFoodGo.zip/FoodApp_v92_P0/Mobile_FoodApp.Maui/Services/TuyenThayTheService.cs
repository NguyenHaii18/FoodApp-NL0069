using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>
/// v94: xử lý khi ĐƯỜNG BỊ CHẶN / không tìm được tuyến. Tài xế chọn: tính lại tuyến (bỏ nhớ đệm), mở Google Maps để tự tìm đường khác,
/// hoặc nhắn khách báo trễ. Mọi lựa chọn đều ghi nhật ký để điều phối biết. Không tự ý đổi phí giao: nếu quãng đường thực tế khác hẳn thì dùng
/// "Báo khoảng cách thực tế" (có sẵn) để tính lại theo biểu phí.
/// </summary>
public static class TuyenThayTheService
{
    public static async Task XuLyAsync(Page trang, DonHang don)
    {
        var den = don.TrangThai == TrangThaiDonHang.DangGiao ? don.DiaChiGiao : don.DiaChiLayHang;
        var tenDich = don.TrangThai == TrangThaiDonHang.DangGiao ? "điểm giao" : "quán";
        var chon = await trang.DisplayActionSheet($"Đường tới {tenDich} bị chặn / không đi được?", "Đóng", null,
            "🔄 Tính lại tuyến đường", "🧭 Mở Google Maps (tự tìm đường khác)", "💬 Nhắn khách: đường bị chặn, giao trễ");
        if (chon is null or "Đóng") return;
        NhatKyService.Ghi("TaiXe", MockData.TaiXeHienTai.SoDienThoai, $"Đường bị chặn / tìm tuyến khác — đơn #{don.Id}", doiTuong: don.Id, chiTiet: chon);

        if (chon.StartsWith("🔄")) await TinhLaiAsync(trang, den, tenDich);
        else if (chon.StartsWith("🧭"))
        {
            if (!await GiaoHangService.MoChiDuongAsync(den))
            {
                await ClipboardAnToan.SaoChepAsync(den);
                await trang.DisplayAlert("Không mở được bản đồ", "Đã sao chép địa chỉ để bạn dán vào ứng dụng bản đồ.", "OK");
            }
        }
        else if (chon.StartsWith("💬"))
            await FoodApp.Maui.Views.ChatPage.MoAsync(don.Id, "TaiXe", string.IsNullOrWhiteSpace(don.KhachTen) ? "Khách hàng" : don.KhachTen, don.KhachSdt);
    }

    private static async Task TinhLaiAsync(Page trang, string diaChiDich, string tenDich)
    {
        var viTri = ViTriTaiXeService.ViTriCuoi;
        if (viTri is null)
        {
            await trang.DisplayAlert("Chưa có vị trí của bạn", "Hãy bật \"📡 Chia sẻ vị trí\" / cấp quyền định vị rồi thử lại, hoặc mở Google Maps để tự tìm đường.", "OK");
            return;
        }
        var dich = await DiaChiToaDoService.TimAsync(diaChiDich);
        if (!dich.TimThay)
        {
            await trang.DisplayAlert("Không xác định được điểm đến", $"Không tìm thấy tọa độ của {tenDich} ({dich.LyDo}). Hãy mở Google Maps hoặc gọi khách để hỏi địa chỉ chính xác.", "OK");
            return;
        }
        var kq = await DuongDiService.LayChiTietAsync(viTri.Value.Lat, viTri.Value.Lng, dich.Lat, dich.Lng, boQuaCache: true);
        if (kq.CoDuongThat)
        {
            var d = kq.Duong!;
            await trang.DisplayAlert("Tuyến đường mới", $"Tới {tenDich}: {d.Km:0.#} km, ~{d.Phut} phút ({d.KhungGio.ToLowerInvariant()}).\n" +
                "Thời gian chỉ là ước tính theo giờ cao điểm, chưa phải dữ liệu kẹt xe/đường chặn trực tiếp. Nếu đường vẫn không đi được, hãy mở Google Maps.", "OK");
            return;
        }
        await trang.DisplayAlert("Không tìm được tuyến đường",
            $"{kq.ThongDiep}\n\nƯớc tính theo đường thẳng: ~{kq.KmUocTinh:0.#} km, ~{kq.PhutUocTinh} phút (KHÔNG theo đường đi thật). " +
            "Hãy mở Google Maps để tự tìm đường, hoặc nhắn/gọi khách báo trễ.", "Đã hiểu");
    }
}
