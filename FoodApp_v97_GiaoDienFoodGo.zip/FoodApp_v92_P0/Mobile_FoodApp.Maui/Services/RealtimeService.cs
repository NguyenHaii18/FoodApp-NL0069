using System.Text.Json;
using Microsoft.AspNetCore.SignalR.Client;

namespace FoodApp.Maui.Services;

/// <summary>Một tín hiệu thời gian thực từ máy chủ. Chỉ là TÍN HIỆU: dữ liệu đúng luôn lấy lại từ API.</summary>
/// <param name="Loai">MenuChanged | StoreChanged (v95: quán đổi giá/món/trạng thái → app tải lại từ API, không tự tính giá) | OrderCreated | OrderStatusChanged | OrderDriverAssigned | DriverInvite | NotificationCreated | DongBo (tự phát khi nối lại / mở lại app)</param>
public sealed record RealtimeSuKien(string Loai, string? MaDon = null, string? TrangThai = null, string? MaGianHang = null);

/// <summary>
/// Kết nối SignalR (WebSocket) tới /hubs/don-hang của Backend. Tự bật khi có JWT (đăng nhập) và tắt khi đăng xuất/hết phiên
/// (gắn vào <see cref="ApiClient.Token"/>). Mất mạng thì tự nối lại; nối lại hoặc mở lại app đều phát "DongBo" để màn hình gọi lại API,
/// nên thông báo đẩy/WebSocket không bao giờ là nguồn dữ liệu chính. Không kết nối được thì các bộ đếm giờ sẵn có vẫn làm mới bằng API.
/// </summary>
public static class RealtimeService
{
    private static readonly string[] CacSuKien =
        { "OrderCreated", "OrderStatusChanged", "OrderDriverAssigned", "DriverInvite", "NotificationCreated", "DriverOffer", "DriverOfferEnd", "MenuChanged", "StoreChanged" };

    private static HubConnection? _conn;
    private static CancellationTokenSource? _huy;
    private static int _doi;                       // tăng mỗi lần Bat/Tat để vòng thử nối cũ tự dừng

    /// <summary>Phát trên luồng giao diện, nên trình xử lý được phép chạm vào điều khiển.</summary>
    public static event Action<RealtimeSuKien>? CoThayDoi;

    public static bool DangKetNoi => _conn?.State == HubConnectionState.Connected;

    /// <summary>(Re)bật kết nối với JWT hiện tại. Gọi lại an toàn; không chờ, không ném lỗi.</summary>
    public static void Bat()
    {
        Tat();
        if (string.IsNullOrEmpty(ApiClient.Token)) return;
        var doi = Interlocked.Increment(ref _doi);
        var huy = _huy = new CancellationTokenSource();
        _ = Task.Run(() => VongKetNoiAsync(doi, huy.Token));
    }

    public static void Tat()
    {
        Interlocked.Increment(ref _doi);
        var huy = _huy; _huy = null;
        var conn = _conn; _conn = null;
        try { huy?.Cancel(); } catch { }
        if (conn is not null) _ = Task.Run(async () => { try { await conn.DisposeAsync(); } catch { } });
    }

    /// <summary>Yêu cầu mọi màn hình đồng bộ lại từ API (vd sau khi tài xế nhận đề nghị / hủy nhận đơn).</summary>
    public static void YeuCauDongBo() => Phat(new RealtimeSuKien("DongBo"));

    /// <summary>App vừa được mở lại: nối lại nếu đã rớt, rồi yêu cầu màn hình đồng bộ lại từ API.</summary>
    public static void KhiMoLai()
    {
        if (string.IsNullOrEmpty(ApiClient.Token)) return;
        if (!DangKetNoi && _conn is null) Bat();
        Phat(new RealtimeSuKien("DongBo"));
    }

    private static async Task VongKetNoiAsync(int doi, CancellationToken huy)
    {
        var cho = new[] { 2, 5, 10, 30, 60 };
        var lan = 0;
        while (!huy.IsCancellationRequested && doi == Volatile.Read(ref _doi))
        {
            try
            {
                var conn = Tao();
                conn.Reconnected += _ => { Phat(new RealtimeSuKien("DongBo")); return Task.CompletedTask; };
                await conn.StartAsync(huy);
                if (doi != Volatile.Read(ref _doi)) { await conn.DisposeAsync(); return; }
                _conn = conn;
                Phat(new RealtimeSuKien("DongBo"));          // vừa nối được: lấy trạng thái mới nhất từ API
                return;
            }
            catch (OperationCanceledException) { return; }
            catch (Exception ex)
            {
                GiamSatService.Ghi("WS", "hubs/don-hang", 0, 0, true, true, ex.Message);
            }
            try { await Task.Delay(TimeSpan.FromSeconds(cho[Math.Min(lan++, cho.Length - 1)]), huy); }
            catch (OperationCanceledException) { return; }
        }
    }

    private static HubConnection Tao()
    {
        var url = AppSettings.BaseUrl.TrimEnd('/') + "/hubs/don-hang";
        var conn = new HubConnectionBuilder()
            .WithUrl(url, o =>
            {
                o.AccessTokenProvider = () => Task.FromResult(ApiClient.Token);
#if DEBUG
                if (AppSettings.ChoPhepChungChiTuKy)
                {
                    o.HttpMessageHandlerFactory = h =>
                    {
                        if (h is HttpClientHandler hc) hc.ServerCertificateCustomValidationCallback = (_, _, _, _) => true;
                        return h;
                    };
                    o.WebSocketConfiguration = ws => ws.RemoteCertificateValidationCallback = (_, _, _, _) => true;
                }
#endif
            })
            .WithAutomaticReconnect(new ThuLaiVoHan())
            .Build();

        foreach (var ten in CacSuKien)
        {
            var loai = ten;
            conn.On<JsonElement>(loai, nd =>
            {
                string? ma = null, tt = null, gh = null;
                try
                {
                    if (nd.TryGetProperty("maDon", out var m)) ma = m.ToString();
                    if (nd.TryGetProperty("maGianHang", out var g)) gh = g.ToString();
                    if (nd.TryGetProperty("trangThai", out var t) && t.ValueKind == JsonValueKind.String) tt = t.GetString();
                }
                catch { /* gói tin lạ: vẫn báo có thay đổi để app gọi lại API */ }
                Phat(new RealtimeSuKien(loai, ma, tt, gh));
            });
        }
        return conn;
    }

    private static void Phat(RealtimeSuKien e)
    {
        var h = CoThayDoi;
        if (h is null) return;
        MainThread.BeginInvokeOnMainThread(() =>
        {
            foreach (var d in h.GetInvocationList().Cast<Action<RealtimeSuKien>>())
                try { d(e); } catch (Exception ex) { CrashLog.Ghi("Realtime " + e.Loai, ex); }
        });
    }

    /// <summary>Thử nối lại mãi (0s, 2s, 5s, 10s, rồi 30s một lần) — app ở nền/mất sóng lâu vẫn tự về lại.</summary>
    private sealed class ThuLaiVoHan : IRetryPolicy
    {
        public TimeSpan? NextRetryDelay(RetryContext c) => c.PreviousRetryCount switch
        {
            0 => TimeSpan.Zero, 1 => TimeSpan.FromSeconds(2), 2 => TimeSpan.FromSeconds(5), 3 => TimeSpan.FromSeconds(10),
            _ => TimeSpan.FromSeconds(30)
        };
    }
}
