using CommunityToolkit.Maui.Alerts;
using CommunityToolkit.Maui.Core;
using Microsoft.Maui.Devices.Sensors;

namespace FoodApp.Maui.Services;

/// <summary>Ảnh chụp nhanh tình trạng thiết bị của tài xế để hiển thị ở màn "Trạng thái làm việc".</summary>
public sealed record TinhTrangThietBi(bool CoMang, bool QuyenViTri, bool GpsHoatDong, bool? ChayNenOk)
{
    public bool DuDieuKien => CoMang && QuyenViTri && GpsHoatDong;
}

/// <summary>
/// v91: cảnh báo MẤT MẠNG / MẤT GPS ngay khi tài xế đang Online (không chỉ lúc bật Online) + kiểm tra quyền chạy nền.
/// Chỉ báo khi trạng thái ĐỔI (mất → có, có → mất) để không làm phiền; có thể bật/tắt trong code qua <see cref="Bat"/>/<see cref="Tat"/>.
/// </summary>
public static class DriverCanhBaoService
{
    private static IDispatcherTimer? _timer;
    private static bool _bat;
    private static bool? _coMang, _coGps;

    public static void Bat()
    {
        if (_bat) return;
        var dp = Application.Current?.Dispatcher;
        if (dp is null) return;
        _bat = true;
        _coMang = null; _coGps = null;
        Connectivity.Current.ConnectivityChanged -= OnMang;
        Connectivity.Current.ConnectivityChanged += OnMang;
        _timer ??= dp.CreateTimer();
        _timer.Interval = TimeSpan.FromSeconds(45);
        _timer.Tick -= OnTick; _timer.Tick += OnTick;
        _timer.Start();
        _ = KiemTraGpsAsync();
        OnMang(null, null!);
    }

    public static void Tat()
    {
        _bat = false;
        _timer?.Stop();
        Connectivity.Current.ConnectivityChanged -= OnMang;
    }

    private static void Bao(string noiDung)
    {
        try { _ = MainThread.InvokeOnMainThreadAsync(() => Toast.Make(noiDung, ToastDuration.Long).Show()); } catch { }
    }

    private static void OnMang(object? s, ConnectivityChangedEventArgs? e)
    {
        var co = Connectivity.Current.NetworkAccess == NetworkAccess.Internet;
        if (_coMang is { } cu && cu != co)
            Bao(co ? "✅ Đã có Internet trở lại" : "⚠ Mất Internet — bạn sẽ không nhận được đơn mới cho đến khi có mạng");
        else if (_coMang is null && !co)
            Bao("⚠ Điện thoại đang không có Internet — không nhận được đơn mới");
        _coMang = co;
    }

    private static async void OnTick(object? s, EventArgs e) => await KiemTraGpsAsync();

    private static async Task KiemTraGpsAsync()
    {
        if (!_bat) return;
        var co = (await DoTinhTrangAsync()).GpsHoatDong;
        if (_coGps is { } cu && cu != co)
            Bao(co ? "✅ GPS đã hoạt động trở lại" : "⚠ Mất GPS — hãy bật Vị trí (GPS) để hệ thống phân đơn và khách theo dõi được bạn");
        else if (_coGps is null && !co)
            Bao("⚠ Chưa có GPS — hãy bật Vị trí (GPS) của thiết bị");
        _coGps = co;
    }

    /// <summary>Kiểm tra mạng, quyền vị trí, GPS (lấy được toạ độ) và quyền chạy nền (Android).</summary>
    public static async Task<TinhTrangThietBi> DoTinhTrangAsync()
    {
        var mang = Connectivity.Current.NetworkAccess == NetworkAccess.Internet;
        var quyen = false; var gps = false;
        try
        {
            quyen = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>() == PermissionStatus.Granted;
            if (quyen)
            {
                var vt = await MainThread.InvokeOnMainThreadAsync(() =>
                    Geolocation.Default.GetLocationAsync(new GeolocationRequest(GeolocationAccuracy.Medium, TimeSpan.FromSeconds(6))));
                gps = vt is not null;
            }
        }
        catch { /* GPS tắt / không hỗ trợ → gps = false */ }
        return new TinhTrangThietBi(mang, quyen, gps, ChayNenOk());
    }

    /// <summary>Android: app có được miễn tối ưu hóa pin (chạy nền ổn định) không. null = nền tảng không áp dụng.</summary>
    public static bool? ChayNenOk()
    {
#if ANDROID
        try
        {
            var ctx = Android.App.Application.Context;
            var pm = (Android.OS.PowerManager?)ctx.GetSystemService(Android.Content.Context.PowerService);
            return pm?.IsIgnoringBatteryOptimizations(ctx.PackageName) ?? (bool?)null;
        }
        catch { return null; }
#else
        return null;
#endif
    }

    /// <summary>Mở màn hình cài đặt tối ưu hóa pin để tài xế cho phép app chạy nền.</summary>
    public static bool MoCaiDatChayNen()
    {
#if ANDROID
        try
        {
            var i = new Android.Content.Intent(Android.Provider.Settings.ActionIgnoreBatteryOptimizationSettings);
            i.AddFlags(Android.Content.ActivityFlags.NewTask);
            Android.App.Application.Context.StartActivity(i);
            return true;
        }
        catch { return false; }
#else
        return false;
#endif
    }
}
