using System.Text.Json;
using FoodApp.Maui.Models;

namespace FoodApp.Maui.Services;

/// <summary>
/// Tin nhắn giữa khách hàng và tài xế theo từng đơn hàng. Lưu trên máy (Preferences); khi có API thì đồng bộ qua
/// GET api/mobile/don-hang/{id}/tin-nhan và POST api/mobile/tin-nhan.
/// </summary>
public static class ChatService
{
    private const string Key = "tin-nhan";
    private const int ToiDa = 600;
    private static List<TinNhan>? _ds;

    private static List<TinNhan> Ds => _ds ??= Nap();

    private static List<TinNhan> Nap()
    {
        try { return JsonSerializer.Deserialize<List<TinNhan>>(Preferences.Default.Get(Key, "[]")) ?? new(); }
        catch { return new(); }
    }

    private static void Luu()
    {
        if (Ds.Count > ToiDa) Ds.RemoveRange(0, Ds.Count - ToiDa);
        Preferences.Default.Set(Key, JsonSerializer.Serialize(Ds));
    }

    public static List<TinNhan> Lay(string donId) =>
        Ds.Where(t => t.DonHangId == donId).OrderBy(t => t.ThoiGian).ToList();

    public static TinNhan? CuoiCung(string donId) =>
        Ds.Where(t => t.DonHangId == donId).OrderByDescending(t => t.ThoiGian).FirstOrDefault();

    public static async Task<TinNhan> GuiAsync(string donId, string nguoiGui, string tenNguoiGui, string noiDung)
    {
        var tn = new TinNhan { DonHangId = donId, NguoiGui = nguoiGui, TenNguoiGui = tenNguoiGui, NoiDung = noiDung.Trim(), TrangThaiGui = "DangCho" };
        Ds.Add(tn);
        Luu();
        await ThuGuiAsync(tn);
        return tn;
    }

    /// <summary>
    /// Gửi một tin lên máy chủ và ghi nhận kết quả thật (v64): thành công → DaGui; mất mạng/ngoại tuyến → giữ DangCho và tự gửi lại
    /// ở lần đồng bộ sau (máy chủ chống trùng theo Id); máy chủ từ chối (đơn hết chuyến, không có quyền…) → Loi + lý do, không gửi lại.
    /// </summary>
    private static async Task ThuGuiAsync(TinNhan tn)
    {
        if (!DuLieuService.DangOnline) return;
        var r = await ApiClient.PostAsync<object>("api/mobile/tin-nhan",
            new { id = tn.Id, donHangId = tn.DonHangId, noiDung = tn.NoiDung });
        if (r.ThanhCong) { tn.TrangThaiGui = "DaGui"; tn.LoiGui = ""; }
        else if (!r.MatKetNoi) { tn.TrangThaiGui = "Loi"; tn.LoiGui = string.IsNullOrWhiteSpace(r.ThongDiep) ? "Máy chủ không nhận tin nhắn." : r.ThongDiep; }
        Luu();
    }

    /// <summary>Kéo tin mới từ server (nếu có). Trả về true khi có tin mới.</summary>
    public static async Task<bool> DongBoAsync(string donId)
    {
        if (!DuLieuService.DangOnline) return false;

        var doi = false;
        foreach (var cho in Ds.Where(t => t.DonHangId == donId && t.TrangThaiGui == "DangCho").ToList())
        {
            await ThuGuiAsync(cho);      // tin gửi lúc mất mạng: thử lại
            if (cho.TrangThaiGui != "DangCho") doi = true;
        }

        var r = await ApiClient.GetAsync<List<TinNhan>>($"api/mobile/don-hang/{donId}/tin-nhan");
        if (!r.ThanhCong || r.DuLieu is null) { if (doi) Luu(); return doi; }

        foreach (var x in r.DuLieu)
        {
            var co = Ds.FirstOrDefault(d => d.Id == x.Id);
            if (co is null) continue;
            if (co.TrangThaiGui != "DaGui") { co.TrangThaiGui = "DaGui"; co.LoiGui = ""; doi = true; }   // máy chủ đã có tin này
        }
        var moi = r.DuLieu.Where(x => Ds.All(d => d.Id != x.Id)).ToList();
        if (moi.Count > 0) Ds.AddRange(moi);
        if (moi.Count > 0 || doi) Luu();
        return moi.Count > 0 || doi;
    }
}
