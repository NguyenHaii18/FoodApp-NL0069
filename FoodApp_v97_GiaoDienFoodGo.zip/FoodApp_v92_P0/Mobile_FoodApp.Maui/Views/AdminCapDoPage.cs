namespace FoodApp.Maui.Views;

/// <summary>
/// Phần XIII — Thứ tự ưu tiên xây dựng FoodApp theo 3 cấp độ (MVP / Hoàn thiện vận hành / Quy mô doanh nghiệp).
/// Chạm một dòng để đánh dấu đã hoàn thành. Tiến độ chỉ LƯU TRÊN THIẾT BỊ NÀY (Preferences).
/// </summary>
public sealed class AdminCapDoPage : AdminKyThuatTrang
{
    private static readonly (string Ten, string Nhan, string Mau, string[] Muc)[] Caps =
    {
        ("Cấp độ 1 – MVP", "Bắt buộc trước khi chạy thử", "#DC2626", new[]
        {
            "Khách đăng ký, đăng nhập, đặt món",
            "Nhà hàng quản lý món, xác nhận đơn",
            "Tài xế đăng ký, bật nhận đơn, nhận và giao hàng",
            "Admin quản lý khách, nhà hàng, tài xế, đơn",
            "Backend và SQL kết nối đầy đủ",
            "Thông báo trạng thái đơn",
            "Tính phí giao và thanh toán COD",
            "Điều phối tài xế cơ bản",
        }),
        ("Cấp độ 2 – Hoàn thiện vận hành", "Nâng cấp tiếp theo", "#F97316", new[]
        {
            "GPS realtime và theo dõi lộ trình",
            "Tìm tài xế tự động nâng cao",
            "Thanh toán trực tuyến",
            "Voucher và khuyến mãi",
            "Quản lý nhiều chi nhánh",
            "Đánh giá và khiếu nại",
            "Kế toán và đối soát",
            "Chat khách hàng – nhà hàng – tài xế",
            "Dashboard và xuất Excel",
        }),
        ("Cấp độ 3 – Quy mô doanh nghiệp", "Mở rộng", "#5B3FD9", new[]
        {
            "Phân phối đơn tối ưu theo thời gian thực",
            "Giao nhiều đơn trên một hành trình",
            "Dự báo nhu cầu tài xế theo khu vực",
            "Phân tích hành vi khách hàng",
            "CRM và marketing tự động",
            "Quản lý kho và nguyên liệu",
            "Loyalty và thành viên",
            "Báo cáo lợi nhuận chuyên sâu",
            "Giám sát hiệu suất toàn hệ thống",
            "Hạ tầng chịu tải và mở rộng đa khu vực",
        }),
    };

    public AdminCapDoPage() : base("Thứ tự ưu tiên xây dựng") { }

    private static bool Dat(int c, int i) { try { return Preferences.Default.Get($"capdo-{c}-{i}", false); } catch { return false; } }
    private static void Dat(int c, int i, bool v) { try { Preferences.Default.Set($"capdo-{c}-{i}", v); } catch { } }

    protected override Task DungAsync()
    {
        var tong = Caps.Sum(c => c.Muc.Length);
        var soDat = 0;
        for (var c = 0; c < Caps.Length; c++) for (var i = 0; i < Caps[c].Muc.Length; i++) if (Dat(c, i)) soDat++;

        var dau = new VerticalStackLayout { Spacing = 4 };
        dau.Add(AdminUi.Nhan("Tiến độ xây dựng FoodApp", 14, dam: true));
        var pt = AdminUi.Nhan($"{(int)Math.Round(100.0 * soDat / tong)}%", 28, dam: true);
        pt.TextColor = Color.FromArgb(soDat == tong ? AdminUi.Xanh : AdminUi.Tim);
        dau.Add(pt);
        dau.Add(new ProgressBar { Progress = (double)soDat / tong, ProgressColor = Color.FromArgb(soDat == tong ? AdminUi.Xanh : AdminUi.Tim) });
        dau.Add(AdminUi.Nhan($"{soDat}/{tong} hạng mục · không cần làm tất cả cùng lúc: xong cấp 1 rồi mới sang cấp 2, cấp 3.", 11.5, mo: true));
        Nd.Add(KhoiTheo("", dau));

        for (var k = 0; k < Caps.Length; k++)
        {
            var c = k;
            var (ten, nhan, mau, muc) = Caps[c];
            var datCap = Enumerable.Range(0, muc.Length).Count(i => Dat(c, i));
            var ds = new VerticalStackLayout { Spacing = 2 };
            var td = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            var tieuDe = AdminUi.Nhan(ten, 15, dam: true); tieuDe.TextColor = Color.FromArgb(mau);
            td.Add(tieuDe, 0, 0);
            td.Add(AdminUi.Nhan($"{datCap}/{muc.Length}", 13, dam: true), 1, 0);
            ds.Add(td);
            ds.Add(AdminUi.Nhan(nhan, 12, mo: true));
            ds.Add(new ProgressBar { Progress = (double)datCap / muc.Length, ProgressColor = Color.FromArgb(datCap == muc.Length ? AdminUi.Xanh : mau) });
            for (var j = 0; j < muc.Length; j++)
            {
                var i = j;
                var xong = Dat(c, i);
                var dong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 10, Padding = new Thickness(0, 8) };
                dong.Add(new Label { Text = xong ? "✅" : "⚪", FontSize = 18, VerticalOptions = LayoutOptions.Center }, 0, 0);
                var chu = AdminUi.Nhan(muc[i], 13.5, mo: xong);
                chu.VerticalOptions = LayoutOptions.Center;
                if (xong) chu.TextDecorations = TextDecorations.Strikethrough;
                dong.Add(chu, 1, 0);
                var tap = new TapGestureRecognizer();
                tap.Tapped += async (_, _) => { Dat(c, i, !Dat(c, i)); Nd.Children.Clear(); await DungAsync(); };
                dong.GestureRecognizers.Add(tap);
                ds.Add(dong);
            }
            Nd.Add(KhoiTheo("", ds));
        }

        var datLai = AdminUi.Nut("Đặt lại tiến độ", AdminUi.Xam);
        datLai.Clicked += async (_, _) =>
        {
            if (!await DisplayAlert("Đặt lại?", $"Bỏ đánh dấu toàn bộ {tong} hạng mục trên thiết bị này.", "Đặt lại", "Hủy")) return;
            for (var c = 0; c < Caps.Length; c++) for (var i = 0; i < Caps[c].Muc.Length; i++) Dat(c, i, false);
            Nd.Children.Clear();
            await DungAsync();
        };
        Nd.Add(KhoiTheo("", datLai));
        return Task.CompletedTask;
    }
}
