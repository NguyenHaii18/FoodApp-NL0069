using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

[QueryProperty(nameof(MonAnId), "MonAnId")]
[QueryProperty(nameof(Focus), "Focus")]
public partial class VendorMenuItemEditPage : ContentPage
{
    private static readonly string[] TinhTrangs = { "Còn hàng", "Hết hàng", "Tạm ngừng bán" };

    public string? MonAnId { get; set; }
    public string? Focus { get; set; }          // "size" = mở xong cuộn thẳng tới mục Size

    private MonAn? _monDangSua;
    private string _anhPath = "";        // ảnh đang chọn (chưa chắc đã lưu)

    public VendorMenuItemEditPage()
    {
        InitializeComponent();
        PickerTinhTrang.ItemsSource = TinhTrangs;
        ChonSize.DatMau(new (string, decimal)[] { ("S", 0), ("M", 5000), ("L", 10000), ("XL", 15000), ("Nhỏ", 0), ("Vừa", 10000), ("Lớn", 20000) });
        ChonSize.GiaGoc = () => decimal.TryParse(new string((EntryGia.Text ?? "").Where(char.IsDigit).ToArray()), out var g) ? g : 0;
        EntryGia.TextChanged += (_, _) => ChonSize.CapNhatGiaBan();
        ChonTopping.DatMau(new (string, decimal)[] { ("Trân châu", 5000), ("Thạch dừa", 5000), ("Pudding", 7000), ("Kem cheese", 10000), ("Thạch trái cây", 5000), ("Trứng", 5000), ("Phô mai", 10000) });
        ChonMucCay.DatMau(new (string, decimal)[] { ("Không cay", 0), ("Cay vừa", 0), ("Cay nhiều", 0), ("Siêu cay", 0) }, coGia: false);
        ChonMucDuong.DatMau(new (string, decimal)[] { ("100% đường", 0), ("70% đường", 0), ("50% đường", 0), ("30% đường", 0), ("Không đường", 0) }, coGia: false);
        ChonMucDa.DatMau(new (string, decimal)[] { ("Đá bình thường", 0), ("Ít đá", 0), ("Đá riêng", 0), ("Không đá", 0) }, coGia: false);
        ChonMonKem.DatMau(new (string, decimal)[] { ("Khoai tây chiên", 20000), ("Nước ngọt", 10000), ("Trà đá", 5000), ("Canh", 10000), ("Trứng ốp la", 8000), ("Dưa chua", 0) });
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        var danhMuc = MockData.DanhMucCuaGianHang(MockData.GianHangHienTai.Id).ToList();

        _monDangSua = string.IsNullOrEmpty(MonAnId)
            ? null
            : MockData.DanhSachMonAn.FirstOrDefault(m => m.Id == MonAnId);

        // Món cũ có danh mục không còn trong danh sách → vẫn cho chọn lại đúng danh mục đó.
        if (_monDangSua is not null && !string.IsNullOrWhiteSpace(_monDangSua.DanhMuc) &&
            !danhMuc.Contains(_monDangSua.DanhMuc, StringComparer.OrdinalIgnoreCase))
            danhMuc.Add(_monDangSua.DanhMuc);
        _dsDanhMuc = danhMuc;
        DatDanhMuc(null);

        LblLoi.IsVisible = false;
        if (_monDangSua is not null)
        {
            Title = "Sửa món ăn";
            BtnXoa.IsVisible = true;
            BtnLuu.Text = "Lưu thay đổi";

            _anhPath = _monDangSua.AnhPath;
            EntryHinhAnh.Text = _monDangSua.HinhAnh;
            EntryTenMon.Text = _monDangSua.TenMon;
            EditorMoTa.Text = _monDangSua.MoTa;
            DatDanhMuc(danhMuc.FirstOrDefault(x => string.Equals(x, _monDangSua.DanhMuc, StringComparison.OrdinalIgnoreCase)));
            EntryGia.Text = ((long)_monDangSua.Gia).ToString();
            PickerTinhTrang.SelectedIndex = _monDangSua.TamNgungBan ? 2 : _monDangSua.ConHang ? 0 : 1;
            SwitchChoGhiChu.IsToggled = _monDangSua.ChoGhiChu;
            ChonSize.Dat(DsChon(_monDangSua.TuyChon, TuyChonMon.Size));
            ChonTopping.Dat(DsChon(_monDangSua.TuyChon, TuyChonMon.Topping));
            ChonMucCay.Dat(DsChon(_monDangSua.TuyChon, TuyChonMon.MucCay));
            ChonMucDuong.Dat(DsChon(_monDangSua.TuyChon, TuyChonMon.MucDuong));
            ChonMucDa.Dat(DsChon(_monDangSua.TuyChon, TuyChonMon.MucDa));
            EntryChuanBi.Text = _monDangSua.ThoiGianChuanBiPhut?.ToString() ?? "";
            EntryBanTu.Text = _monDangSua.BanTuGio;
            EntryBanDen.Text = _monDangSua.BanDenGio;
            ChonMonKem.Dat(PhanTichMonKem(_monDangSua.MonAnKem));
            DatTonKho(_monDangSua.TonKho);
        }
        else
        {
            Title = "Thêm món ăn";
            BtnXoa.IsVisible = false;
            BtnLuu.Text = "Lưu món ăn";

            _anhPath = "";
            EntryHinhAnh.Text = "🍲";
            EntryTenMon.Text = "";
            EditorMoTa.Text = "";
            DatDanhMuc(danhMuc.Count == 1 ? danhMuc[0] : null);   // chỉ có 1 danh mục thì chọn sẵn
            EntryGia.Text = "";
            EntryChuanBi.Text = ""; EntryBanTu.Text = ""; EntryBanDen.Text = ""; ChonMonKem.Dat(Array.Empty<(string, decimal)>());
            PickerTinhTrang.SelectedIndex = 0;
            SwitchChoGhiChu.IsToggled = true;
            ChonSize.Dat(Array.Empty<(string, decimal)>()); ChonTopping.Dat(Array.Empty<(string, decimal)>()); ChonMucCay.Dat(Array.Empty<(string, decimal)>());
            ChonMucDuong.Dat(Array.Empty<(string, decimal)>()); ChonMucDa.Dat(Array.Empty<(string, decimal)>());
            DatTonKho(null);
        }
        HienAnh();
        ChonSize.CapNhatGiaBan();
        if (Focus == "size")
        {
            Focus = null;
            Dispatcher.Dispatch(async () =>
            {
                await Task.Delay(300);
                try { await CuonTrang.ScrollToAsync(NhanSize, ScrollToPosition.Start, true); } catch { }
            });
        }
    }

    private List<string> _dsDanhMuc = new();
    private string? _danhMucChon;

    private void DatDanhMuc(string? ten)
    {
        _danhMucChon = string.IsNullOrWhiteSpace(ten) ? null : ten;
        LblDanhMuc.Text = _danhMucChon ?? "Chọn danh mục";
        if (_danhMucChon is null)
            LblDanhMuc.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#6B7280"), Color.FromArgb("#6B7280"));
        else
            LblDanhMuc.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#1F2937"), Color.FromArgb("#F8F5FF"));
        LblGoiYDanhMuc.IsVisible = _dsDanhMuc.Count == 0;
    }

    private async void OnChonDanhMucTapped(object? sender, TappedEventArgs e)
    {
        const string TaoMoi = "＋ Tạo danh mục mới";
        var chon = _dsDanhMuc.Count == 0
            ? TaoMoi
            : await DisplayActionSheet("Chọn danh mục", "Hủy", null, _dsDanhMuc.Append(TaoMoi).ToArray());
        if (string.IsNullOrEmpty(chon) || chon == "Hủy") return;

        if (chon != TaoMoi) { DatDanhMuc(chon); return; }

        var ten = (await this.NhapAsync("Danh mục mới", "Tên danh mục", "Lưu", "Hủy", "VD: Món chính", maxLength: 40))?.Trim();
        if (string.IsNullOrEmpty(ten)) return;

        var daCo = _dsDanhMuc.FirstOrDefault(x => string.Equals(x, ten, StringComparison.OrdinalIgnoreCase));
        if (daCo is null)
        {
            // Ghi vào danh sách danh mục của gian hàng để trang Thực đơn cũng thấy ngay.
            var goc = MockData.DanhMucCuaGianHang(MockData.GianHangHienTai.Id);
            if (!goc.Contains(ten, StringComparer.OrdinalIgnoreCase)) goc.Add(ten);
            _dsDanhMuc.Add(ten);
            VendorLocalStore.Luu();
            daCo = ten;
        }
        DatDanhMuc(daCo);
    }

    private void HienAnh()
    {
        var co = !string.IsNullOrEmpty(_anhPath) && File.Exists(_anhPath);
        ImgAnhMon.Source = co ? ImageSource.FromFile(_anhPath) : null;
        LblChuaCoAnh.IsVisible = !co;
    }

    private async void OnTaiAnhClicked(object sender, EventArgs e)
    {
        try
        {
            var path = await AnhService.ChonVaLuuAsync("mon_" + MockData.GianHangHienTai.Id, "Chọn ảnh món");
            if (path is null) return;
            _anhPath = path;
            HienAnh();
        }
        catch (Exception ex)
        {
            HienLoi("Không tải được ảnh: " + ex.Message);
        }
    }

    private void OnBoAnhClicked(object sender, EventArgs e)
    {
        _anhPath = "";
        HienAnh();
    }

    // ---- tùy chọn: dạng bấm chọn (tên + phụ phí) ----
    private static IEnumerable<(string, decimal)> DsChon(IEnumerable<TuyChonMon> ds, string loai) =>
        ds.Where(x => x.Loai == loai).Select(x => (x.Ten, x.GiaThem)).ToList();

    /// <summary>Món kèm lưu dạng chuỗi "Tên:giá" mỗi dòng (giữ nguyên định dạng cũ để không đổi API).</summary>
    private static IEnumerable<(string, decimal)> PhanTichMonKem(string? text)
    {
        foreach (var dong in (text ?? "").Replace("\r", "").Split('\n'))
        {
            var d = dong.Trim(); if (d.Length == 0) continue;
            var i = d.LastIndexOf(':'); decimal gia = 0; var ten = d;
            if (i >= 0)
            {
                ten = d[..i].Trim();
                var so = new string(d[(i + 1)..].Where(char.IsDigit).ToArray());
                if (so.Length is > 0 and <= 9) gia = decimal.Parse(so);
            }
            if (ten.Length > 0) yield return (ten, gia);
        }
    }

    private async void OnLuuClicked(object sender, EventArgs e)
    {
        LblLoi.IsVisible = false;

        if (string.IsNullOrWhiteSpace(EntryTenMon.Text))
        {
            HienLoi("Vui lòng nhập tên món");
            return;
        }
        if (string.IsNullOrWhiteSpace(_danhMucChon))
        {
            HienLoi("Vui lòng chọn hoặc tạo danh mục cho món");
            return;
        }
        if (!decimal.TryParse(EntryGia.Text, out var gia) || gia <= 0)
        {
            HienLoi("Giá bán không hợp lệ");
            return;
        }
        int? chuanBi = null;
        if (!string.IsNullOrWhiteSpace(EntryChuanBi.Text))
        {
            if (!int.TryParse(EntryChuanBi.Text, out var cb) || cb is < 1 or > 180) { HienLoi("Thời gian chuẩn bị phải từ 1 đến 180 phút"); return; }
            chuanBi = cb;
        }
        var banTu = EntryBanTu.Text?.Trim() ?? "";
        var banDen = EntryBanDen.Text?.Trim() ?? "";
        if (banTu.Length > 0 || banDen.Length > 0)
        {
            if (!TimeSpan.TryParse(banTu, out var tuGio) || !TimeSpan.TryParse(banDen, out var denGio) || tuGio.TotalHours >= 24 || denGio.TotalHours >= 24)
            { HienLoi("Khung giờ bán cần nhập đủ cả hai giờ, dạng HH:mm (vd 06:00 và 10:00)"); return; }
            banTu = $"{tuGio:hh\\:mm}"; banDen = $"{denGio:hh\\:mm}";
        }
        var monKem = string.Join("\n", ChonMonKem.Lay().Select(x => x.Gia > 0 ? $"{x.Ten}:{(long)x.Gia}" : x.Ten));

        var tuyChon = new List<TuyChonMon>();
        foreach (var (loai, chon) in new[] { (TuyChonMon.Size, ChonSize), (TuyChonMon.Topping, ChonTopping), (TuyChonMon.MucCay, ChonMucCay), (TuyChonMon.MucDuong, ChonMucDuong), (TuyChonMon.MucDa, ChonMucDa) })
            tuyChon.AddRange(chon.Lay().Select(x => new TuyChonMon { Loai = loai, Ten = x.Ten, GiaThem = x.Gia }));

        LoadingIndicator.IsVisible = true;
        LoadingIndicator.IsRunning = true;
        BtnLuu.IsEnabled = false;

        try
        {
            var hinhAnh = string.IsNullOrWhiteSpace(EntryHinhAnh.Text) ? "🍲" : EntryHinhAnh.Text.Trim();
            var danhMuc = _danhMucChon!;
            var tinhTrang = PickerTinhTrang.SelectedIndex < 0 ? 0 : PickerTinhTrang.SelectedIndex;   // 0 còn / 1 hết / 2 tạm ngừng

            // v64: món đã có trên máy chủ (Id là số) → đồng bộ tùy chọn lên máy chủ trước; bị từ chối thì ở lại trang để sửa.
            List<TuyChonMon>? tuyChonMayChu = null;
            var canDongBo = _monDangSua is not null && int.TryParse(_monDangSua.Id, out _);
            if (canDongBo)
            {
                var (ok, dsMayChu) = await DuLieuService.GhiLayAsync<List<TuyChonMon>>("PUT",
                    $"api/mobile/gian-hang/{MockData.GianHangHienTai.Id}/mon-an/{_monDangSua!.Id}/tuy-chon",
                    new { tuyChon = tuyChon.Select(t => new { loai = t.Loai, ten = t.Ten, giaThem = t.GiaThem }).ToList() });
                if (!ok) return;
                tuyChonMayChu = dsMayChu;
            }

            var mon = _monDangSua ?? new MonAn
            {
                Id = IdHelper.TiepTheo("ma", MockData.DanhSachMonAn.Select(x => x.Id)),   // max+1: không trùng sau khi xóa món
                GianHangId = MockData.GianHangHienTai.Id,
            };

            if (!string.IsNullOrEmpty(mon.AnhPath) && mon.AnhPath != _anhPath)
            {
                try { File.Delete(mon.AnhPath); } catch { }   // dọn ảnh cũ đã bị thay/bỏ
            }

            mon.TenMon = EntryTenMon.Text.Trim();
            mon.MoTa = EditorMoTa.Text?.Trim() ?? "";
            mon.DanhMuc = danhMuc;
            mon.Gia = gia;
            mon.HinhAnh = hinhAnh;
            mon.AnhPath = _anhPath;
            mon.ConHang = tinhTrang == 0;
            mon.TamNgungBan = tinhTrang == 2;
            mon.ChoGhiChu = SwitchChoGhiChu.IsToggled;
            mon.TuyChon = tuyChonMayChu ?? tuyChon;   // có mã tùy chọn từ máy chủ thì dùng luôn
            mon.ThoiGianChuanBiPhut = chuanBi;
            mon.BanTuGio = banTu;
            mon.BanDenGio = banDen;
            mon.MonAnKem = monKem;
            mon.TonKho = SwitchGioiHanKho.IsToggled ? (int)StepTonKho.Value : null;
            if (mon.TonKho == 0) mon.ConHang = false;                       // kho về 0 => hết hàng
            else if (mon.TonKho > 0 && tinhTrang == 0) mon.ConHang = true;

            if (_monDangSua is null) MockData.DanhSachMonAn.Add(mon);
            VendorLocalStore.Luu();
            if (canDongBo) await VanHanhService.DongBoMonAsync(mon);

            if (canDongBo && DuLieuService.LanGhiCuoi == DuLieuService.KetQuaGhi.LuuTrenMay)
                await DisplayAlert("Đã lưu trên máy", DuLieuService.CanhBaoNgoaiTuyen, "OK");

            await Shell.Current.GoToAsync("..");
        }
        finally
        {
            LoadingIndicator.IsVisible = false;
            LoadingIndicator.IsRunning = false;
            BtnLuu.IsEnabled = true;
        }
    }

    private async void OnXoaClicked(object sender, EventArgs e)
    {
        if (_monDangSua is null) return;

        // Quy định: không xóa món đang nằm trong đơn chưa xong — chỉ cho ẩn (tạm ngừng bán) để đơn không bị mất dữ liệu.
        var dangDung = MockData.DonHangCuaGianHang.Count(d => d.GianHangId == MockData.GianHangHienTai.Id
            && d.TrangThai is TrangThaiDonHang.ChoXacNhan or TrangThaiDonHang.DangLam or TrangThaiDonHang.DangGiao
            && d.ChiTiet.Any(c => c.MonAn.Id == _monDangSua.Id));
        if (dangDung > 0)
        {
            await DisplayAlert("Chưa thể xóa món", $"Món này đang nằm trong {dangDung} đơn chưa hoàn tất. Hãy chọn \"Tạm ngừng bán\" để ẩn món, xóa sau khi các đơn xong.", "Đã hiểu");
            return;
        }
        bool xacNhan = await DisplayAlert("Xóa món ăn", $"Xóa \"{_monDangSua.TenMon}\" khỏi thực đơn?", "Xóa", "Hủy");
        if (!xacNhan) return;

        if (_monDangSua.CoAnh) { try { File.Delete(_monDangSua.AnhPath); } catch { } }
        MockData.DanhSachMonAn.Remove(_monDangSua);
        VendorLocalStore.Luu();

        await Shell.Current.GoToAsync("..");
    }

    private void DatTonKho(int? ton)
    {
        SwitchGioiHanKho.IsToggled = ton is not null;
        StepTonKho.Value = ton ?? 0;
        KhungTonKho.IsVisible = ton is not null;
        LblTonKho.Text = $"{(int)StepTonKho.Value} phần";
    }

    private void OnGioiHanKhoToggled(object? sender, ToggledEventArgs e)
    {
        KhungTonKho.IsVisible = e.Value;
        if (e.Value && StepTonKho.Value == 0) StepTonKho.Value = 20;
    }

    private void OnTonKhoChanged(object? sender, ValueChangedEventArgs e) => LblTonKho.Text = $"{(int)e.NewValue} phần";

    private void OnCongNhanhClicked(object? sender, EventArgs e)
    {
        if (sender is Button { CommandParameter: string p } && int.TryParse(p, out var n))
            StepTonKho.Value = Math.Min(StepTonKho.Maximum, StepTonKho.Value + n);
    }

    private void HienLoi(string thongDiep)
    {
        LblLoi.Text = thongDiep;
        LblLoi.IsVisible = true;
    }
}
