using System.Globalization;
using System.Text.Json;
using FoodApp.Maui.Models;
using FoodApp.Maui.Services;
using Microsoft.Maui.Dispatching;

namespace FoodApp.Maui.Views;

/// <summary>
/// Theo dõi đơn trên bản đồ (khách hàng): quán 🏬, địa chỉ nhận 🏠 và tài xế 🛵 trên cùng một bản đồ OpenStreetMap (Leaflet trong WebView).
/// Vị trí tài xế tự cập nhật mỗi 10 giây (GET đơn của khách); đường nối tài xế → điểm đến kế tiếp (quán khi đang lấy món, khách khi đang giao).
/// Tọa độ quán/khách lấy bằng Nominatim từ địa chỉ (có cache); không có tọa độ thì chỉ hiện những điểm xác định được. Cần Internet.
/// </summary>
public class TheoDoiBanDoPage : ContentPage
{
    private static DonHang? _donMo;
    private static readonly Dictionary<string, (double Lat, double Lng)?> _cache = new();
    private static readonly HttpClient Http = TaoHttp();

    private readonly WebView _wv = new() { VerticalOptions = LayoutOptions.Fill };
    private readonly Label _lblTrangThai = new() { FontAttributes = FontAttributes.Bold, FontSize = 14 };
    private readonly Label _lblChiTiet = new() { FontSize = 12 };
    private readonly Label _lblThongBao = new() { FontSize = 12, IsVisible = false };
    private readonly Label _lblTuyen = new() { FontSize = 12, IsVisible = false };          // v94: trạng thái đường đi (đường thật / chỉ có đường thẳng ước tính)
    private readonly HorizontalStackLayout _hangTuyen = new() { Spacing = 8, IsVisible = false };
    private readonly Queue<DateTime> _mocViTri = new();                                       // v94: các mốc vị trí tài xế khác nhau nhận được (đo độ đều của đồng bộ)
    private DateTime _mocViTriCuoi = DateTime.MinValue;
    private string _dongDuong = "";                      // dòng "đường thật" giữ lại giữa các lần cập nhật chữ
    private IDispatcherTimer? _boDem;
    private DonHang? _don;
    private bool _sanSang, _dangTai, _daDatDiem;
    private (double Lat, double Lng)? _quan, _khach;
    private string _khoaDuong = "";
    private DateTime _lanLayDuong = DateTime.MinValue;
    private DateTime _lanTaiDon = DateTime.MinValue;     // lần tải đầy đủ danh sách đơn gần nhất (trạng thái, tài xế…)

    private static HttpClient TaoHttp()
    {
        var c = new HttpClient { Timeout = TimeSpan.FromSeconds(12) };
        c.DefaultRequestHeaders.UserAgent.ParseAdd("FoodApp.Maui/1.0 (do-an-mon-hoc)");   // Nominatim yêu cầu User-Agent
        c.DefaultRequestHeaders.AcceptLanguage.ParseAdd("vi");
        return c;
    }

    public static async Task MoAsync(DonHang don)
    {
        _donMo = don;
        await Shell.Current.GoToAsync(nameof(TheoDoiBanDoPage));
    }

    private const string Html = """
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>html,body,#map{height:100%;margin:0;background:#eee}</style></head><body><div id="map"></div>
<script>
var map = L.map('map').setView([10.7769, 106.7009], 13);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom: 19, attribution: '&copy; OpenStreetMap'}).addTo(map);
var mk = {}, duong = null, duongThat = null, muctieu = 'khach';
function giaiMa(str){var i=0,lat=0,lng=0,out=[];while(i<str.length){var b,shift=0,res=0;do{b=str.charCodeAt(i++)-63;res|=(b&0x1f)<<shift;shift+=5}while(b>=0x20);lat+=(res&1)?~(res>>1):(res>>1);shift=0;res=0;do{b=str.charCodeAt(i++)-63;res|=(b&0x1f)<<shift;shift+=5}while(b>=0x20);lng+=(res&1)?~(res>>1):(res>>1);out.push([lat/1e5,lng/1e5]);}return out;}
function datDuongThat(enc) { if (duongThat) { map.removeLayer(duongThat); duongThat = null; } if (enc) duongThat = L.polyline(giaiMa(enc), {color: '#6D28D9', weight: 5, opacity: .85}).addTo(map); ve(); }
function icon(e, bg) {
  return L.divIcon({className: '', iconSize: [34, 34], iconAnchor: [17, 17], popupAnchor: [0, -16],
    html: '<div style="background:' + bg + ';color:#fff;border-radius:50%;width:34px;height:34px;line-height:32px;text-align:center;font-size:17px;border:2px solid #fff;box-shadow:0 1px 5px rgba(0,0,0,.4)">' + e + '</div>'});
}
function datDiem(k, lat, lng, nhan) {
  var bieuTuong = {quan: ['🏬', '#6D28D9'], khach: ['🏠', '#16A34A'], taixe: ['🛵', '#EA580C']}[k];
  if (mk[k]) { mk[k].setLatLng([lat, lng]); mk[k].setPopupContent(nhan); }
  else mk[k] = L.marker([lat, lng], {icon: icon(bieuTuong[0], bieuTuong[1])}).addTo(map).bindPopup(nhan);
  ve();
}
function datMucTieu(m) { muctieu = m; ve(); }
function ve() {
  if (duong) { map.removeLayer(duong); duong = null; }
  if (duongThat) return;
  if (mk.taixe && mk[muctieu]) duong = L.polyline([mk.taixe.getLatLng(), mk[muctieu].getLatLng()], {color: '#6D28D9', weight: 4, dashArray: '8 8'}).addTo(map);
}
function vuaKhit() {
  var p = Object.keys(mk).map(function (k) { return mk[k].getLatLng(); });
  if (p.length == 1) map.setView(p[0], 16);
  else if (p.length > 1) map.fitBounds(L.latLngBounds(p), {padding: [40, 40], maxZoom: 16});
}
</script></body></html>
""";

    public TheoDoiBanDoPage()
    {
        Title = "Theo dõi đơn trên bản đồ";
        _lblChiTiet.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#6B7280"), Color.FromArgb("#A3A3B5"));
        _lblThongBao.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#B45309"), Color.FromArgb("#FBBF24"));
        _lblTuyen.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#B45309"), Color.FromArgb("#FBBF24"));

        var nutKhit = new Button { Text = "🎯 Xem toàn tuyến", FontSize = 12.5, HeightRequest = 38, CornerRadius = 19, Padding = new Thickness(14, 0) };
        nutKhit.Clicked += async (_, _) => await ChayJsAsync("vuaKhit();");
        var nutGoi = new Button { Text = "📞 Gọi tài xế", FontSize = 12.5, HeightRequest = 38, CornerRadius = 19, Padding = new Thickness(14, 0) };
        nutGoi.Clicked += async (_, _) => { if (_don is not null) await LienLac.GoiAsync(_don.TaiXeSdt); };
        var hang = new HorizontalStackLayout { Spacing = 8, Children = { nutKhit, nutGoi } };

        // v94: khi không có đường thật (chưa có khóa Goong, đường bị chặn, mất mạng) → thử lại hoặc mở Google Maps; không âm thầm vẽ đường thẳng
        var nutThuLai = new Button { Text = "🔄 Tìm lại tuyến", FontSize = 12.5, HeightRequest = 38, CornerRadius = 19, Padding = new Thickness(14, 0) };
        nutThuLai.Clicked += async (_, _) => { DuongDiService.XoaCache(); _lanLayDuong = DateTime.MinValue; await VeDuongThatAsync(); };
        var nutGoogle = new Button { Text = "🧭 Mở Google Maps", FontSize = 12.5, HeightRequest = 38, CornerRadius = 19, Padding = new Thickness(14, 0) };
        nutGoogle.Clicked += async (_, _) =>
        {
            if (_don is null) return;
            var den = _don.TrangThai == TrangThaiDonHang.DangGiao ? _don.DiaChiGiao : _don.DiaChiLayHang;
            if (!await GiaoHangService.MoChiDuongAsync(den)) HienThongBao("Không mở được ứng dụng bản đồ.");
        };
        _hangTuyen.Add(nutThuLai); _hangTuyen.Add(nutGoogle);

        var thongTin = new VerticalStackLayout { Spacing = 3, Padding = new Thickness(14, 10, 14, 8), Children = { _lblTrangThai, _lblChiTiet, _lblThongBao, _lblTuyen, hang, _hangTuyen } };
        thongTin.SetAppThemeColor(VisualElement.BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
        _lblTrangThai.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#1F1537"), Color.FromArgb("#F8F5FF"));

        var luoi = new Grid { RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Star) } };
        luoi.Add(thongTin, 0, 0);
        luoi.Add(_wv, 0, 1);
        Content = luoi;

        _wv.Source = new HtmlWebViewSource { Html = Html };
        _wv.Navigated += async (_, e) =>
        {
            if (e.Result != WebNavigationResult.Success) { HienThongBao("Không tải được bản đồ (cần Internet)."); return; }
            _sanSang = true;
            await VeLaiAsync(true);
        };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        try
        {
            _don = _donMo ?? _don;
            if (_don is null) { await Shell.Current.GoToAsync(".."); return; }
            CapNhatChu();
            await TimToaDoAsync();
            await VeLaiAsync(true);

            _boDem ??= Dispatcher.CreateTimer();
            _boDem.Interval = TimeSpan.FromSeconds(10);
            _boDem.Tick -= OnTick;
            _boDem.Tick += OnTick;
            _boDem.Start();
        }
        catch (Exception ex) { HienThongBao("Bản đồ gặp lỗi: " + ex.Message); }
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        _boDem?.Stop();
    }

    private async void OnTick(object? sender, EventArgs e)
    {
        if (_dangTai || _don is null) return;
        _dangTai = true;
        try
        {
            if (DuLieuService.DangOnline)
            {
                // v64: mỗi 10 giây chỉ hỏi vị trí tài xế (nhẹ); trạng thái đơn tải đầy đủ mỗi 30 giây hoặc khi chưa có tài xế / đã hết chuyến giao
                var trongChuyen = !string.IsNullOrEmpty(_don.TaiXeId) && _don.TrangThai is TrangThaiDonHang.DangLam or TrangThaiDonHang.DangGiao;
                if (!trongChuyen || DateTime.Now - _lanTaiDon >= TimeSpan.FromSeconds(30))
                {
                    await DuLieuService.TaiDonHangKhachAsync();
                    _lanTaiDon = DateTime.Now;
                }
                else await GiaoHangService.TaiViTriTaiXeAsync(_don);
            }
            _don = MockData.LichSuDonHang.FirstOrDefault(d => d.Id == _don.Id) ?? _don;   // lấy bản mới nhất sau khi tải
            CapNhatChu();
            await VeLaiAsync(false);
            if (_don.TrangThai is TrangThaiDonHang.HoanThanh or TrangThaiDonHang.DaHuy) _boDem?.Stop();
        }
        catch { /* mất mạng: giữ nguyên bản đồ, lần sau thử lại */ }
        finally { _dangTai = false; }
    }

    private void CapNhatChu()
    {
        if (_don is null) return;
        _lblTrangThai.Text = $"Đơn #{_don.Id} · {_don.NhanHienThi}";
        var ten = string.IsNullOrWhiteSpace(_don.TaiXeTen) ? "Chưa có tài xế" : $"🛵 {_don.TaiXeTen}";
        var eta = "";
        if (_don.TrangThai == TrangThaiDonHang.DangGiao && GiaoHangService.ConLaiDenKhach(_don) is { } cl) eta = $" · còn ~{cl.Km:0.#} km, ~{cl.Phut} phút (ước tính)";
        // v94: cho khách thấy vị trí tài xế được cập nhật cách đây bao lâu + độ đều của đồng bộ (đối chiếu bản đồ khách ↔ GPS tài xế)
        var tuoi = "";
        if (_don.ViTriCapNhatLuc is { } capNhat)
        {
            var giay = Math.Max(0, (int)(DateTime.Now - capNhat).TotalSeconds);
            if (capNhat != _mocViTriCuoi)
            {
                _mocViTriCuoi = capNhat; _mocViTri.Enqueue(DateTime.Now);
                while (_mocViTri.Count > 0 && DateTime.Now - _mocViTri.Peek() > TimeSpan.FromMinutes(1)) _mocViTri.Dequeue();
            }
            tuoi = $"\n📡 Vị trí tài xế cập nhật {(giay < 60 ? giay + " giây" : giay / 60 + " phút")} trước · {_mocViTri.Count} lần thay đổi trong 1 phút qua";
        }
        _lblChiTiet.Text = ten + eta + tuoi + (_dongDuong.Length > 0 ? "\n" + _dongDuong : "");
        var matTinHieu = _don.ViTriCapNhatLuc is { } moc && (_don.ViTriCu || DateTime.Now - moc > TimeSpan.FromSeconds(90));
        if (_don.TaiXeLat is null) HienThongBao(string.IsNullOrEmpty(_don.TaiXeId) ? "Đơn chưa có tài xế nhận." : "Tài xế chưa chia sẻ vị trí.");
        else if (matTinHieu) HienThongBao($"⚠ Mất tín hiệu GPS của tài xế — vị trí cuối lúc {_don.ViTriCapNhatLuc:HH:mm:ss}.");
        else HienThongBao(null);
    }

    private void HienThongBao(string? t) { _lblThongBao.Text = t ?? ""; _lblThongBao.IsVisible = !string.IsNullOrEmpty(t); }

    // ---------- tọa độ quán / khách ----------
    private async Task TimToaDoAsync()
    {
        if (_don is null) return;
        var quan = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == _don.GianHangId);
        var diaChiQuan = !string.IsNullOrWhiteSpace(_don.DiaChiLayHang) ? _don.DiaChiLayHang : quan?.DiaChi ?? "";
        _quan = await GeocodeAsync(diaChiQuan);
        _khach = await GeocodeAsync(_don.DiaChiGiao);
    }

    private static async Task<(double Lat, double Lng)?> GeocodeAsync(string diaChi)
    {
        diaChi = (diaChi ?? "").Trim();
        if (diaChi.Length < 5) return null;
        if (_cache.TryGetValue(diaChi, out var da)) return da;
        var kq = await DiaChiToaDoService.TimAsync(diaChi);     // v94: Goong (cùng nguồn với máy chủ tính phí) → OpenStreetMap dự phòng
        if (kq.TimThay) return _cache[diaChi] = (kq.Lat, kq.Lng);
        return null;                                            // không cache khi lỗi để lần sau thử lại
    }

    // ---------- vẽ ----------
    private async Task ChayJsAsync(string js)
    {
        if (!_sanSang) return;
        try { await _wv.EvaluateJavaScriptAsync(js); } catch { /* WebView chưa sẵn sàng */ }
    }

    private static string So(double d) => d.ToString("0.000000", CultureInfo.InvariantCulture);

    /// <summary>Vẽ ĐƯỜNG THẬT (Goong) từ tài xế tới điểm kế tiếp, làm mới tối đa 30 giây/lần; không có thì giữ đường nét đứt thẳng.</summary>
    private async Task VeDuongThatAsync()
    {
        if (_don is null || _don.TaiXeLat is not { } la || _don.TaiXeLng is not { } ln) return;
        var dich = _don.TrangThai == TrangThaiDonHang.DangGiao ? _khach : _quan;
        if (dich is not { } d) return;
        var khoa = $"{(_don.TrangThai == TrangThaiDonHang.DangGiao ? "k" : "q")}";
        if (khoa == _khoaDuong && DateTime.Now - _lanLayDuong < TimeSpan.FromSeconds(30)) return;
        _lanLayDuong = DateTime.Now; _khoaDuong = khoa;
        var ct = await DuongDiService.LayChiTietAsync(la, ln, d.Lat, d.Lng);
        if (!ct.CoDuongThat)
        {
            // không có đường thật: vẽ đường thẳng nét đứt và NÓI RÕ đó chỉ là ước tính, không theo đường đi (đường bị chặn / chưa có khóa / mất mạng)
            await ChayJsAsync("datDuongThat(null);");
            _dongDuong = "";
            var goiY = ct.Loi switch
            {
                LoaiLoiDuongDi.ChuaCoKhoa => "Máy chủ chưa có khóa bản đồ Goong.",
                LoaiLoiDuongDi.KhongTimDuocTuyen => "Không tìm được tuyến đường (đường có thể đang bị chặn).",
                LoaiLoiDuongDi.NgoaiTuyen => "Đang ngoại tuyến.",
                _ => "Chưa lấy được đường đi từ máy chủ.",
            };
            _lblTuyen.Text = $"⚠ {goiY} Đang vẽ đường thẳng nét đứt (~{ct.KmUocTinh:0.#} km, ~{ct.PhutUocTinh} phút, KHÔNG theo đường đi thật). Bạn có thể thử lại hoặc mở Google Maps.";
            _lblTuyen.IsVisible = true; _hangTuyen.IsVisible = true;
            return;
        }
        var kq = ct.Duong!;
        _lblTuyen.IsVisible = false; _hangTuyen.IsVisible = false;
        await ChayJsAsync($"datDuongThat({JsonSerializer.Serialize(kq.Polyline)});");
        var gio = kq.HeSoKetXe > 1.01 ? $" · {kq.KhungGio.ToLowerInvariant()} ×{kq.HeSoKetXe:0.##}" : "";
        _dongDuong = $"🛣 Đường thật: {kq.Km:0.#} km, ~{kq.Phut} phút{gio} (ETA ước tính theo giờ, chưa phải kẹt xe trực tiếp)";
        CapNhatChu();
    }

    private async Task VeLaiAsync(bool khitLai)
    {
        if (!_sanSang || _don is null) return;
        if (_quan is { } q) await ChayJsAsync($"datDiem('quan', {So(q.Lat)}, {So(q.Lng)}, {JsonSerializer.Serialize("Quán: " + _don.TenGianHang)});");
        if (_khach is { } k) await ChayJsAsync($"datDiem('khach', {So(k.Lat)}, {So(k.Lng)}, {JsonSerializer.Serialize("Địa chỉ nhận: " + _don.DiaChiGiao)});");
        if (_don.TaiXeLat is { } la && _don.TaiXeLng is { } ln)
            await ChayJsAsync($"datDiem('taixe', {So(la)}, {So(ln)}, {JsonSerializer.Serialize("Tài xế " + _don.TaiXeTen)});");
        await ChayJsAsync($"datMucTieu('{(_don.TrangThai == TrangThaiDonHang.DangGiao ? "khach" : "quan")}');");
        await VeDuongThatAsync();
        if (khitLai || !_daDatDiem) { await ChayJsAsync("vuaKhit();"); _daDatDiem = _quan is not null || _khach is not null || _don.TaiXeLat is not null; }
    }
}
