using System.Text.RegularExpressions;
using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Tài xế: xem khu vực đang có nhu cầu giao hàng — gom các đơn đang chờ tài xế theo quận/huyện của điểm lấy món,
/// hiện số đơn, tiền công trung bình và đơn chờ lâu nhất để chọn nơi chờ đơn. Dữ liệu là đơn chờ nhận đã đồng bộ từ máy chủ.
/// </summary>
public sealed class DriverNhuCauPage : ContentPage
{
    private readonly VerticalStackLayout _ds = new() { Spacing = 10 };
    private readonly Label _tomTat = new() { FontSize = 12.5 };

    public DriverNhuCauPage()
    {
        Title = "Khu vực có nhu cầu";
        BackgroundColor = DriverPalette.Get("Background");
        _tomTat.TextColor = DriverPalette.Get("TextGrey");
        var lamMoi = new RefreshView { Content = new ScrollView { Content = new VerticalStackLayout { Padding = new Thickness(16), Spacing = 12, Children = { _tomTat, _ds } } } };
        lamMoi.Refreshing += async (_, _) => { await TaiAsync(); lamMoi.IsRefreshing = false; };
        Content = lamMoi;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await TaiAsync();
    }

    private static readonly Regex ReQuan = new(@"(Quận|Q\.?|Huyện|H\.|Thành phố|TP\.?)\s*([0-9]{1,2}|[A-Za-zÀ-ỹ]+(?:\s[A-Za-zÀ-ỹ]+)?)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

    /// <summary>"12 Nguyễn Huệ, Quận 1, TP.HCM" → "Quận 1"; không đoán được → "Khu vực khác".</summary>
    internal static string KhuVuc(string diaChi)
    {
        if (string.IsNullOrWhiteSpace(diaChi)) return "Khu vực khác";
        foreach (Match m in ReQuan.Matches(diaChi))
        {
            var loai = m.Groups[1].Value.Trim().TrimEnd('.').ToLowerInvariant();
            var ten = m.Groups[2].Value.Trim();
            if (loai is "thành phố" or "tp" && !ten.StartsWith("Thủ", StringComparison.OrdinalIgnoreCase)) continue;
            if (loai is "q") return "Quận " + ten;
            if (loai is "h") return "Huyện " + ten;
            return char.ToUpper(loai[0]) + loai[1..] + " " + ten;
        }
        return "Khu vực khác";
    }

    private async Task TaiAsync()
    {
        if (DuLieuService.DangOnline)
        {
            try { await DuLieuService.TaiDonChoTaiXeAsync(); } catch { /* giữ dữ liệu đã có */ }
        }
        _ds.Children.Clear();
        var cho = MockData.TatCaDonHangHeThong.Where(d => d.DangChoTaiXe).ToList();
        if (cho.Count == 0)
        {
            _tomTat.Text = "Hiện chưa có đơn nào đang chờ tài xế. Kéo xuống để làm mới.";
            return;
        }
        var nhom = cho.GroupBy(d => KhuVuc(string.IsNullOrWhiteSpace(d.DiaChiLayHang) ? d.DiaChiGiao : d.DiaChiLayHang))
            .Select(g => (Ten: g.Key, So: g.Count(), PhiTb: g.Average(x => x.PhiGiaoHang + x.PhuCap), Cho: g.Min(x => x.SanSangGiaoLuc ?? x.NgayDat)))
            .OrderByDescending(x => x.So).ThenByDescending(x => x.PhiTb).ToList();
        _tomTat.Text = $"{cho.Count} đơn đang chờ tài xế ở {nhom.Count} khu vực — khu vực nhiều đơn nhất ở trên cùng.";
        var toiDa = nhom.Max(x => x.So);
        foreach (var n in nhom)
        {
            var phut = Math.Max(0, (int)(DateTime.Now - n.Cho).TotalMinutes);
            var st = new VerticalStackLayout { Spacing = 4 };
            st.Children.Add(new Label { Text = $"📍 {n.Ten}", FontAttributes = FontAttributes.Bold, FontSize = 15, TextColor = DriverPalette.Get("Primary") });
            st.Children.Add(new Label { Text = $"{n.So} đơn chờ · công TB {n.PhiTb:N0}đ · đơn chờ lâu nhất {phut} phút", FontSize = 12.5 });
            st.Children.Add(new ProgressBar { Progress = (double)n.So / toiDa, ProgressColor = DriverPalette.Get("Primary"), HeightRequest = 6 });
            _ds.Children.Add(new Border
            {
                StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(14) },
                Padding = 14, StrokeThickness = 1, Stroke = DriverPalette.Get("BorderColor"), Content = st,
            });
        }
    }
}
