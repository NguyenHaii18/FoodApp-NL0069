using FoodApp.Maui.Models;
using FoodApp.Maui.Services;
using Microsoft.Maui.Controls.Shapes;

namespace FoodApp.Maui.Views;

/// <summary>Đặt chung: tạo nhóm cho một quán, chia sẻ mã, mỗi người tự chọn món; chủ nhóm gom tất cả vào giỏ rồi đặt như đơn thường.</summary>
public sealed class DonNhomPage : ContentPage
{
    private readonly VerticalStackLayout _nd = new() { Spacing = 12, Padding = new Thickness(16, 12, 16, 28) };
    private NhomDto? _nhom;
    private readonly Dictionary<int, int> _phanCuaToi = new();   // MonAnId -> số lượng (bản đang sửa)
    private bool _daNapPhanCuaToi;
    private IDispatcher _d = null!;
    private IDispatcherTimer? _timer;
    private bool _dangVe;

    public DonNhomPage()
    {
        Title = "Đặt chung (đơn nhóm)";
        this.SetAppThemeColor(BackgroundColorProperty, Color.FromArgb("#FAF8FF"), Color.FromArgb("#1C1633"));
        Content = new ScrollView { Content = _nd };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        _d = Dispatcher;
        if (!DuLieuService.DangOnline || string.IsNullOrEmpty(ApiClient.Token) || Phien.Khach is null)
        {
            _nd.Children.Clear();
            _nd.Add(Chu("Đơn nhóm cần kết nối máy chủ và đăng nhập tài khoản khách hàng.", 13, mo: true));
            return;
        }
        if (DonNhomService.DangO is { } ma)
        {
            var r = await DonNhomService.XemAsync(ma);
            if (r.ThanhCong) _nhom = r.DuLieu; else { DonNhomService.DangO = null; _nhom = null; }
        }
        Ve();
        _timer = Dispatcher.CreateTimer();
        _timer.Interval = TimeSpan.FromSeconds(5);
        _timer.Tick += async (_, _) => await LamMoiAsync();
        _timer.Start();
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        _timer?.Stop();
    }

    private async Task LamMoiAsync()
    {
        if (_nhom is null || _dangVe) return;
        var r = await DonNhomService.XemAsync(_nhom.Ma);
        if (!r.ThanhCong) return;
        _nhom = r.DuLieu;
        Ve(giuPhanToi: true);
    }

    // ---------------------------------------------------------------- UI helpers
    private static Border The()
    {
        var b = new Border { StrokeThickness = 1, Padding = new Thickness(14), StrokeShape = new RoundRectangle { CornerRadius = new CornerRadius(16) } };
        b.SetAppThemeColor(VisualElement.BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
        b.SetAppTheme<Brush>(Border.StrokeProperty, new SolidColorBrush(Color.FromArgb("#E4DAF7")), new SolidColorBrush(Color.FromArgb("#4D4180")));
        return b;
    }

    private static Label Chu(string t, double size = 13, bool dam = false, bool mo = false)
    {
        var l = new Label { Text = t, FontSize = size, LineBreakMode = LineBreakMode.WordWrap };
        if (dam) l.FontAttributes = FontAttributes.Bold;
        if (mo) l.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#6B6480"), Color.FromArgb("#CFC6EA"));
        else l.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#1F1537"), Color.FromArgb("#F8F5FF"));
        return l;
    }

    private static Button Nut(string t, bool day = true)
    {
        var c = Color.FromArgb("#6D28D9");
        return new Button { Text = t, FontSize = 13, FontAttributes = FontAttributes.Bold, HeightRequest = 42, CornerRadius = 21, BorderWidth = 1, BorderColor = c, BackgroundColor = day ? c : Colors.Transparent, TextColor = day ? Colors.White : c };
    }

    private static MonAn? TimMon(int id) => MockData.DanhSachMonAn.FirstOrDefault(m => m.Id == id.ToString());

    // ---------------------------------------------------------------- vẽ
    private void Ve(bool giuPhanToi = false)
    {
        _dangVe = true;
        try
        {
            _nd.Children.Clear();
            if (_nhom is null) VeChuaCoNhom(); else VeNhom(giuPhanToi);
        }
        finally { _dangVe = false; }
    }

    private void VeChuaCoNhom()
    {
        var quans = MockData.DanhSachGianHang.Where(g => g.TrangThaiDangKy == TrangThaiDangKyGianHang.DaDuyet && !g.TaiKhoanBiKhoa).OrderBy(g => g.TenGianHang).ToList();
        var pk = new Picker { Title = "Chọn quán để đặt chung", ItemsSource = quans.Select(q => q.TenGianHang).ToList() };
        var tao = Nut("Tạo nhóm & lấy mã");
        tao.Clicked += async (_, _) =>
        {
            if (pk.SelectedIndex < 0) { await DisplayAlert("Chọn quán", "Hãy chọn quán trước khi tạo nhóm.", "OK"); return; }
            var q = quans[pk.SelectedIndex];
            var r = await DonNhomService.TaoAsync(q.Id, q.TenGianHang);
            if (!r.ThanhCong) { await DisplayAlert("Không tạo được nhóm", r.ThongDiep, "Đóng"); return; }
            _nhom = r.DuLieu; _daNapPhanCuaToi = false; Ve();
        };
        var st1 = new VerticalStackLayout { Spacing = 8 };
        st1.Add(Chu("Tạo nhóm mới", 15, dam: true));
        st1.Add(Chu("Bạn là chủ nhóm: chọn quán, chia sẻ mã cho bạn bè; mỗi người tự chọn món của mình.", 12, mo: true));
        st1.Add(pk); st1.Add(tao);
        var the1 = The(); the1.Content = st1; _nd.Add(the1);

        var ma = new Entry { Placeholder = "Nhập mã nhóm (5 ký tự)", MaxLength = 8, Keyboard = Keyboard.Text };
        var vao = Nut("Vào nhóm", day: false);
        vao.Clicked += async (_, _) =>
        {
            if (string.IsNullOrWhiteSpace(ma.Text)) return;
            var r = await DonNhomService.VaoAsync(ma.Text);
            if (!r.ThanhCong) { await DisplayAlert("Không vào được nhóm", r.ThongDiep, "Đóng"); return; }
            _nhom = r.DuLieu; _daNapPhanCuaToi = false; Ve();
        };
        var st2 = new VerticalStackLayout { Spacing = 8 };
        st2.Add(Chu("Vào nhóm có sẵn", 15, dam: true));
        st2.Add(ma); st2.Add(vao);
        var the2 = The(); the2.Content = st2; _nd.Add(the2);
        _nd.Add(Chu("Nhóm được giữ trên máy chủ tối đa 2 giờ và mất nếu máy chủ khởi động lại.", 11, mo: true));
    }

    private void VeNhom(bool giuPhanToi)
    {
        var n = _nhom!;
        var toi = n.ThanhVien.FirstOrDefault(t => t.LaToi);
        if (!_daNapPhanCuaToi)
        {
            _phanCuaToi.Clear();
            foreach (var m in toi?.Mon ?? new()) _phanCuaToi[m.MonAnId] = m.SoLuong;
            _daNapPhanCuaToi = true;
        }

        // Thông tin nhóm
        var st = new VerticalStackLayout { Spacing = 4 };
        st.Add(Chu($"🏬 {n.TenGianHang}", 16, dam: true));
        var ma = Chu($"Mã nhóm: {n.Ma}", 22, dam: true); ma.TextColor = Color.FromArgb("#6D28D9");
        st.Add(ma);
        st.Add(Chu(n.DaChot ? "🔒 Nhóm đã chốt" : "Chia sẻ mã này để bạn bè vào nhóm", 12, mo: true));
        var chiaSe = Nut("Chia sẻ mã", day: false);
        chiaSe.Clicked += async (_, _) => await Share.Default.RequestAsync(new ShareTextRequest { Text = $"Vào nhóm đặt món \"{n.TenGianHang}\" trên FoodApp bằng mã: {n.Ma}", Title = "Mời vào nhóm" });
        st.Add(chiaSe);
        var the = The(); the.Content = st; _nd.Add(the);

        // Thành viên
        var tv = new VerticalStackLayout { Spacing = 8 };
        tv.Add(Chu($"Thành viên ({n.ThanhVien.Count})", 15, dam: true));
        decimal tong = 0;
        foreach (var t in n.ThanhVien)
        {
            var dong = new VerticalStackLayout { Spacing = 1 };
            dong.Add(Chu($"{(t.LaChuNhom ? "👑 " : "👤 ")}{t.Ten}{(t.LaToi ? " (bạn)" : "")}{(t.Xong ? " ✅" : "")}", 13, dam: true));
            if (t.Mon.Count == 0) dong.Add(Chu("Chưa chọn món", 11.5, mo: true));
            foreach (var m in t.Mon)
            {
                var mon = TimMon(m.MonAnId);
                if (mon != null) tong += mon.Gia * m.SoLuong;
                dong.Add(Chu($"   {m.SoLuong} × {mon?.TenMon ?? $"Món #{m.MonAnId}"}" + (mon != null ? $" · {mon.Gia * m.SoLuong:N0}đ" : ""), 12, mo: true));
            }
            tv.Add(dong);
        }
        tv.Add(Chu($"Tạm tính cả nhóm: {tong:N0}đ (chưa gồm phí giao / khuyến mãi)", 12.5, dam: true));
        var the2 = The(); the2.Content = tv; _nd.Add(the2);

        // Chọn món của tôi
        if (!n.DaChot)
        {
            var ds = MockData.DanhSachMonAn.Where(m => m.GianHangId == n.GianHangId && m.ConHang && !m.TamNgungBan && int.TryParse(m.Id, out _)).ToList();
            var mo = new VerticalStackLayout { Spacing = 6 };
            mo.Add(Chu("Phần của bạn", 15, dam: true));
            if (ds.Count == 0) mo.Add(Chu("Quán chưa có món nào đang bán.", 12, mo: true));
            foreach (var m in ds)
            {
                int id = int.Parse(m.Id);
                var sl = Chu(_phanCuaToi.GetValueOrDefault(id).ToString(), 14, dam: true);
                sl.HorizontalTextAlignment = TextAlignment.Center; sl.WidthRequest = 28; sl.VerticalOptions = LayoutOptions.Center;
                var tru = new Button { Text = "−", WidthRequest = 36, HeightRequest = 36, Padding = 0, CornerRadius = 18 };
                var cong = new Button { Text = "+", WidthRequest = 36, HeightRequest = 36, Padding = 0, CornerRadius = 18 };
                tru.Clicked += (_, _) => { var v = Math.Max(0, _phanCuaToi.GetValueOrDefault(id) - 1); if (v == 0) _phanCuaToi.Remove(id); else _phanCuaToi[id] = v; sl.Text = v.ToString(); };
                cong.Clicked += (_, _) => { var v = Math.Min(20, _phanCuaToi.GetValueOrDefault(id) + 1); _phanCuaToi[id] = v; sl.Text = v.ToString(); };
                var g = new Grid { ColumnSpacing = 8, ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Auto) } };
                g.Add(new Label { Text = m.HinhAnh, FontSize = 24, VerticalOptions = LayoutOptions.Center }, 0, 0);
                var ten = new VerticalStackLayout { Spacing = 0, VerticalOptions = LayoutOptions.Center };
                ten.Add(Chu(m.TenMon, 13, dam: true)); ten.Add(Chu($"{m.Gia:N0}đ", 11.5, mo: true));
                g.Add(ten, 1, 0); g.Add(tru, 2, 0); g.Add(sl, 3, 0); g.Add(cong, 4, 0);
                mo.Add(g);
            }
            var luu = Nut(toi?.Xong == true ? "Cập nhật phần của tôi" : "Lưu & báo đã chọn xong");
            luu.Clicked += async (_, _) =>
            {
                var r = await DonNhomService.DatMonAsync(n.Ma, _phanCuaToi.Select(k => new MonNhomDto { MonAnId = k.Key, SoLuong = k.Value }), true);
                if (!r.ThanhCong) { await DisplayAlert("Không lưu được", r.ThongDiep, "Đóng"); return; }
                _nhom = r.DuLieu; _daNapPhanCuaToi = true; Ve(giuPhanToi: true);
            };
            mo.Add(luu);
            var the3 = The(); the3.Content = mo; _nd.Add(the3);
        }

        // Chủ nhóm: gom vào giỏ
        if (n.LaChuNhom)
        {
            var chot = Nut(n.DaChot ? "Đưa lại vào giỏ & đặt hàng" : "Chốt nhóm, gom vào giỏ & đặt hàng");
            chot.Clicked += async (_, _) => await ChotVaoGioAsync(n);
            _nd.Add(chot);
        }
        var roi = Nut(n.LaChuNhom ? "Giải tán nhóm" : "Rời nhóm", day: false);
        roi.TextColor = Color.FromArgb("#DC2626"); roi.BorderColor = Color.FromArgb("#DC2626");
        roi.Clicked += async (_, _) =>
        {
            if (!await DisplayAlert(n.LaChuNhom ? "Giải tán nhóm" : "Rời nhóm", "Bạn chắc chắn?", "Đồng ý", "Hủy")) return;
            await DonNhomService.RoiAsync(n.Ma);
            _nhom = null; _daNapPhanCuaToi = false; Ve();
        };
        _nd.Add(roi);
        _nd.Add(Chu("Tự làm mới mỗi 5 giây. Giá, khuyến mãi và thanh toán do máy chủ kiểm tra khi chủ nhóm đặt đơn.", 11, mo: true));
    }

    private async Task ChotVaoGioAsync(NhomDto n)
    {
        var tatCa = n.ThanhVien.SelectMany(t => t.Mon).GroupBy(m => m.MonAnId).Select(g => (Id: g.Key, Sl: g.Sum(x => x.SoLuong))).ToList();
        if (tatCa.Count == 0) { await DisplayAlert("Chưa có món", "Chưa ai chọn món nào.", "OK"); return; }
        var chuaChon = n.ThanhVien.Where(t => !t.Xong).Select(t => t.Ten).ToList();
        if (chuaChon.Count > 0 && !await DisplayAlert("Còn người chưa chọn xong", $"Chưa xong: {string.Join(", ", chuaChon)}. Vẫn chốt?", "Chốt", "Chờ thêm")) return;
        if (GioHangService.Gio.Count > 0 && !await DisplayAlert("Giỏ hàng đang có món", "Giỏ hiện tại sẽ được thay bằng món của cả nhóm.", "Thay", "Hủy")) return;

        var r = await DonNhomService.ChotAsync(n.Ma);
        if (!r.ThanhCong) { await DisplayAlert("Không chốt được", r.ThongDiep, "Đóng"); return; }
        GioHangService.LamTrong();
        int thieu = 0;
        foreach (var (id, sl) in tatCa)
        {
            var mon = TimMon(id);
            if (mon is null || !mon.ConHang) { thieu++; continue; }
            GioHangService.Them(mon, sl, "");
        }
        await GioHangService.LuuAsync();
        var gh = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == n.GianHangId);
        if (thieu > 0) await DisplayAlert("Một vài món không còn bán", $"{thieu} món không thêm được vào giỏ.", "OK");
        if (gh is null) { await DisplayAlert("Không tìm thấy quán", "Hãy mở quán và kiểm tra giỏ hàng.", "OK"); return; }
        await Shell.Current.GoToAsync(nameof(MenuCartPage), new Dictionary<string, object> { { "GianHang", gh } });
    }
}
