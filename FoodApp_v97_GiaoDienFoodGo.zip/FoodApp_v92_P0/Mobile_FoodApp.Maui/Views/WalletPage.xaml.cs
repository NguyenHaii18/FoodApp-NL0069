using FoodApp.Maui.Models;

namespace FoodApp.Maui.Views;

public partial class WalletPage : ContentPage
{
    public WalletPage()
    {
        InitializeComponent();
        // Ví khách chưa có API/bảng giao dịch trên máy chủ nên trang này không hiện số dư hay nút nạp/rút giả.
        // Khi triển khai: thêm bảng ví + giao dịch (ghi sổ kép, idempotent), API số dư/lịch sử, nạp qua VNPay.
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        NapUuDai();
        ToMauThanhToan();
    }

    private void OnThanhToanClicked(object? sender, EventArgs e)
    {
        if (sender is Button { CommandParameter: string ma })
        {
            Preferences.Default.Set("tt-mac-dinh", ma);
            ToMauThanhToan();
        }
    }

    private async void OnLichSuThanhToanClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(LichSuThanhToanPage));

    private void ToMauThanhToan()
    {
        var chinh = Mau("Primary");
        var nhat = Mau("PrimarySoft");
        var hien = Preferences.Default.Get("tt-mac-dinh", "TienMat");
        if (hien != "VNPay") hien = "TienMat";      // mặc định cũ (chuyển khoản / ví điện tử) không còn được hỗ trợ
        foreach (var (nut, ma) in new[] { (BtnTienMat, "TienMat"), (BtnVnPay, "VNPay") })
        {
            var chon = hien == ma;
            nut.BackgroundColor = chon ? chinh : nhat;
            nut.TextColor = chon ? Colors.White : chinh;
        }
    }

    private Color Mau(string khoa) => (Color)Resources[khoa];

    /// <summary>Ưu đãi đang dùng được (cùng điều kiện với trang chủ); chạm "Sử dụng" để sao chép mã.</summary>
    private void NapUuDai()
    {
        DsUuDai.Children.Clear();
        var ds = MockData.DanhSachKhuyenMai
            .Where(k => k.DangHoatDong && k.ConHan && !k.ChuaBatDau && k.ConLuot)
            .OrderByDescending(k => k.ApDungToanHeThong).Take(6).ToList();
        LblKhongUuDai.IsVisible = ds.Count == 0;
        foreach (var km in ds) DsUuDai.Children.Add(VeUuDai(km));
    }

    private View VeUuDai(KhuyenMai km)
    {
        var nut = new Border
        {
            BackgroundColor = Mau("Primary"), StrokeThickness = 0, Padding = new Thickness(14, 6), VerticalOptions = LayoutOptions.Center,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(14) },
            Content = new Label { Text = "Sử dụng", TextColor = Colors.White, FontSize = 12, FontAttributes = FontAttributes.Bold },
        };
        nut.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => await SaoChepAsync(km)) });

        var thongTin = new VerticalStackLayout { Spacing = 2, VerticalOptions = LayoutOptions.Center };
        thongTin.Children.Add(new Label { Text = km.GiaTriGiamHienThi, FontAttributes = FontAttributes.Bold, FontSize = 15, TextColor = Mau("Primary") });
        thongTin.Children.Add(new Label { Text = km.TenChuongTrinh, FontSize = 12, TextColor = Mau("TextGrey"), LineBreakMode = LineBreakMode.TailTruncation });
        thongTin.Children.Add(new Label { Text = $"Đơn từ {km.GiaTriDonToiThieu:N0}đ · HSD {km.NgayKetThuc:dd/MM/yyyy}", FontSize = 11, TextColor = Mau("TextGrey") });

        var bieuTuong = new Border
        {
            WidthRequest = 44, HeightRequest = 44, BackgroundColor = Mau("PrimarySoft"), StrokeThickness = 0, VerticalOptions = LayoutOptions.Center,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(12) },
            Content = new Label { Text = "🏷️", FontSize = 22, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center },
        };

        var hang = new Grid { ColumnSpacing = 12, ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        hang.Add(bieuTuong, 0); hang.Add(thongTin, 1); hang.Add(nut, 2);

        return new Border
        {
            BackgroundColor = Color.FromArgb("#F3EEFF"), Stroke = Mau("BorderColor"), StrokeThickness = 1, Padding = new Thickness(12),
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(16) },
            Content = hang,
        };
    }

    private async Task SaoChepAsync(KhuyenMai km)
    {
        bool daSao = await FoodApp.Maui.Services.ClipboardAnToan.SaoChepAsync(km.MaCode);
        await DisplayAlert(daSao ? "Đã sao chép mã " + km.MaCode : "Mã " + km.MaCode, daSao ? "Dán mã vào ô khuyến mãi khi thanh toán." : "Không sao chép tự động được. Hãy nhập mã này thủ công khi thanh toán.", "OK");
    }
}
