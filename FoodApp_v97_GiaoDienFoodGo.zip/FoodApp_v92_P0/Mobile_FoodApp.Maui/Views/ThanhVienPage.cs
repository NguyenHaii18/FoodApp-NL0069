using FoodApp.Maui.Models;
using FoodApp.Maui.Services;
using Microsoft.Maui.Controls.Shapes;

namespace FoodApp.Maui.Views;

/// <summary>Khách hàng: hạng thành viên, tác động môi trường của các chuyến giao, và món gợi ý theo lịch sử đặt.</summary>
public sealed class ThanhVienPage : ContentPage
{
    private readonly VerticalStackLayout _nd = new() { Spacing = 12, Padding = new Thickness(16, 12, 16, 28) };

    public ThanhVienPage()
    {
        Title = "Thành viên & gợi ý";
        this.SetAppThemeColor(BackgroundColorProperty, Color.FromArgb("#FAF8FF"), Color.FromArgb("#1C1633"));
        Content = new ScrollView { Content = _nd };
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        try { Ve(); } catch (Exception ex) { CrashLog.Ghi("ThanhVienPage", ex); }
    }

    private static Border The()
    {
        var b = new Border { StrokeThickness = 1, Padding = new Thickness(14), StrokeShape = new RoundRectangle { CornerRadius = new CornerRadius(16) } };
        b.SetAppThemeColor(VisualElement.BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
        b.SetAppTheme<Brush>(Border.StrokeProperty, new SolidColorBrush(Color.FromArgb("#E4DAF7")), new SolidColorBrush(Color.FromArgb("#4D4180")));
        return b;
    }

    private static Label Chu(string t, double size = 13, bool dam = false, bool mo = false)
    {
        var l = new Label { Text = t, FontSize = size, LineBreakMode = LineBreakMode.WordWrap };
        if (dam) l.FontAttributes = FontAttributes.Bold;
        if (mo) l.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#6B6480"), Color.FromArgb("#CFC6EA"));
        else l.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#1F1537"), Color.FromArgb("#F8F5FF"));
        return l;
    }

    private void Ve()
    {
        _nd.Children.Clear();
        var email = Phien.Khach?.Email;
        if (string.IsNullOrEmpty(email))
        {
            _nd.Add(Chu("Hãy đăng nhập để xem hạng thành viên và gợi ý dành riêng cho bạn.", 13, mo: true));
            return;
        }

        // ---- Hạng thành viên
        var tv = NangCaoService.ThanhVien(email);
        var st = new VerticalStackLayout { Spacing = 6 };
        st.Add(Chu($"{tv.Icon} Hạng {tv.Ten}", 20, dam: true));
        st.Add(Chu($"{tv.Diem:N0} điểm · đã chi {tv.TongChi:N0}đ", 12.5, mo: true));
        st.Add(new ProgressBar { Progress = tv.TienDo, ProgressColor = Color.FromArgb("#8B5CF6"), HeightRequest = 8 });
        st.Add(Chu(tv.HangTiepTheo is null ? "Bạn đang ở hạng cao nhất 🎉" : $"Còn {tv.ConThieu:N0}đ nữa để lên hạng {tv.HangTiepTheo}", 12, mo: true));
        st.Add(Chu("🎁 " + tv.QuyenLoi, 12.5));
        st.Add(Chu("Điểm tính trên đơn đã hoàn thành (1.000đ = 1 điểm). Quyền lợi hiện chỉ để hiển thị, chưa tự trừ vào giá đơn.", 11, mo: true));
        var the1 = The(); the1.Content = st; _nd.Add(the1);

        // ---- Đổi điểm lấy voucher (cần máy chủ: máy chủ giữ sổ điểm đã đổi)
        var khungDoi = new VerticalStackLayout { Spacing = 8 };
        var theDoi = The(); theDoi.Content = khungDoi; _nd.Add(theDoi);
        _ = VeDoiDiemAsync(khungDoi);

        // ---- Môi trường
        var mt = NangCaoService.MoiTruong(email);
        var st2 = new VerticalStackLayout { Spacing = 4 };
        st2.Add(Chu("🌱 Tác động môi trường", 15, dam: true));
        st2.Add(Chu(mt.SoDon == 0 ? "Chưa có đơn hoàn thành để ước tính." : $"{mt.SoDon} đơn · khoảng {mt.TongKm:0.#} km giao hàng ≈ {mt.KgCo2:0.##} kg CO₂ (xe máy).", 12.5));
        if (mt.SoDon > 0) st2.Add(Chu($"Nếu giao bằng ô tô ước tính ≈ {mt.KgCo2NeuOto:0.##} kg CO₂.", 12, mo: true));
        st2.Add(Chu("💡 Đặt nhiều món cùng một quán trong một đơn giúp giảm số chuyến giao.", 12, mo: true));
        st2.Add(Chu($"Ước tính dùng hệ số {NangCaoService.HeSoXeMay} kg CO₂/km (xe máy) và {NangCaoService.HeSoOto} (ô tô); chỉ mang tính tham khảo.", 11, mo: true));
        var the2 = The(); the2.Content = st2; _nd.Add(the2);

        // ---- Gợi ý món
        _nd.Add(Chu("Gợi ý cho bạn", 15, dam: true));
        var goiY = NangCaoService.GoiYMon(email, 6);
        if (goiY.Count == 0) _nd.Add(Chu("Chưa có món để gợi ý.", 12.5, mo: true));
        foreach (var g in goiY)
        {
            var quan = MockData.DanhSachGianHang.FirstOrDefault(x => x.Id == g.Mon.GianHangId)?.TenGianHang ?? "";
            var hang = new Grid { ColumnSpacing = 12, ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            hang.Add(new Label { Text = g.Mon.HinhAnh, FontSize = 30, VerticalOptions = LayoutOptions.Center }, 0, 0);
            var giua = new VerticalStackLayout { Spacing = 1 };
            giua.Add(Chu(g.Mon.TenMon, 13.5, dam: true));
            giua.Add(Chu(quan, 11.5, mo: true));
            giua.Add(Chu(g.LyDo, 11, mo: true));
            hang.Add(giua, 1, 0);
            var gia = Chu($"{g.Mon.Gia:N0}đ", 13, dam: true); gia.VerticalOptions = LayoutOptions.Center;
            hang.Add(gia, 2, 0);
            var the = The(); the.Padding = new Thickness(12); the.Content = hang; _nd.Add(the);
        }
        _nd.Add(Chu("Gợi ý dựa trên quán/danh mục bạn đã đặt và điểm đánh giá quán (luật thống kê, không phải mô hình AI).", 11, mo: true));
    }
    private sealed class MucDoiDto { public int Diem { get; set; } public decimal SoTienGiam { get; set; } public decimal DonToiThieu { get; set; } }
    private sealed class VoucherDiemDto { public string MaCode { get; set; } = ""; public decimal SoTienGiam { get; set; } public decimal DonToiThieu { get; set; } public DateTime HetHan { get; set; } public bool DaDung { get; set; } }
    private sealed class DiemDto
    {
        public int TongDiem { get; set; } public int DaDoi { get; set; } public int ConLai { get; set; } public int HanNgay { get; set; }
        public List<MucDoiDto> MucDoi { get; set; } = new(); public List<VoucherDiemDto> Vouchers { get; set; } = new();
    }

    /// <summary>Thẻ "Đổi điểm lấy voucher": điểm còn lại do máy chủ tính (trừ điểm đã đổi), các mức đổi, và voucher đã đổi (chạm để sao chép mã).</summary>
    private async Task VeDoiDiemAsync(VerticalStackLayout khung)
    {
        try
        {
            khung.Children.Clear();
            khung.Add(Chu("🎟 Đổi điểm lấy voucher", 15, dam: true));
            if (!DuLieuService.DangOnline || string.IsNullOrEmpty(ApiClient.Token))
            {
                khung.Add(Chu("Cần kết nối máy chủ để đổi điểm (điểm đã đổi được ghi trên máy chủ).", 12, mo: true));
                return;
            }
            var r = await ApiClient.GetAsync<DiemDto>("api/mobile/khach-hang/diem");
            if (!r.ThanhCong || r.DuLieu is null) { khung.Add(Chu("Chưa tải được điểm thưởng: " + r.ThongDiep, 12, mo: true)); return; }
            var d = r.DuLieu;
            khung.Add(Chu($"Điểm còn lại: {d.ConLai:N0} (tích lũy {d.TongDiem:N0}, đã đổi {d.DaDoi:N0})", 12.5, dam: true));
            foreach (var m in d.MucDoi)
            {
                var muc = m;
                var hang = new Grid { ColumnSpacing = 10, ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
                var chu = new VerticalStackLayout { Spacing = 1 };
                chu.Add(Chu($"Giảm {muc.SoTienGiam:N0}đ", 13.5, dam: true));
                chu.Add(Chu($"{muc.Diem} điểm · đơn từ {muc.DonToiThieu:N0}đ · hạn {d.HanNgay} ngày", 11.5, mo: true));
                hang.Add(chu, 0, 0);
                var nut = new Button { Text = "Đổi", FontSize = 12.5, HeightRequest = 36, CornerRadius = 18, Padding = new Thickness(18, 0), BackgroundColor = Color.FromArgb("#6D28D9"), TextColor = Colors.White, IsEnabled = d.ConLai >= muc.Diem };
                nut.Clicked += async (_, _) =>
                {
                    if (!await DisplayAlert("Đổi điểm", $"Dùng {muc.Diem} điểm để đổi voucher giảm {muc.SoTienGiam:N0}đ?", "Đổi", "Hủy")) return;
                    nut.IsEnabled = false;
                    var kq = await ApiClient.PostAsync<VoucherDiemDto>("api/mobile/khach-hang/diem/doi", new { diem = muc.Diem });
                    if (!kq.ThanhCong || kq.DuLieu is null) { await DisplayAlert("Chưa đổi được", kq.ThongDiep, "OK"); nut.IsEnabled = true; return; }
                    try { await FoodApp.Maui.Services.ClipboardAnToan.SaoChepAsync(kq.DuLieu.MaCode); } catch { }
                    await DisplayAlert("Đổi thành công", $"Mã voucher: {kq.DuLieu.MaCode}\nGiảm {kq.DuLieu.SoTienGiam:N0}đ cho đơn từ {kq.DuLieu.DonToiThieu:N0}đ, hết hạn {kq.DuLieu.HetHan:dd/MM/yyyy}.\n(Đã sao chép mã — dán vào ô mã khuyến mãi khi thanh toán.)", "OK");
                    await VeDoiDiemAsync(khung);
                };
                hang.Add(nut, 1, 0);
                khung.Add(hang);
            }
            if (d.Vouchers.Count > 0)
            {
                khung.Add(Chu("Voucher đã đổi (chạm để sao chép mã)", 12.5, dam: true));
                foreach (var v in d.Vouchers.Take(10))
                {
                    var het = v.HetHan < DateTime.Now;
                    var dong = Chu($"{v.MaCode} · giảm {v.SoTienGiam:N0}đ · " + (v.DaDung ? "đã dùng" : het ? "hết hạn" : $"hạn {v.HetHan:dd/MM/yyyy}"), 12, mo: v.DaDung || het);
                    var tap = new TapGestureRecognizer();
                    var ma = v.MaCode;
                    tap.Tapped += async (_, _) => { try { await FoodApp.Maui.Services.ClipboardAnToan.SaoChepAsync(ma); await DisplayAlert("Đã sao chép", ma, "OK"); } catch { } };
                    dong.GestureRecognizers.Add(tap);
                    khung.Add(dong);
                }
            }
            khung.Add(Chu("Mỗi voucher chỉ dùng một lần, dùng được ở mọi quán, chỉ tài khoản của bạn dùng được.", 11, mo: true));
        }
        catch (Exception ex) { CrashLog.Ghi("ThanhVienPage.DoiDiem", ex); }
    }
}

/// <summary>Quản trị: dự báo nhu cầu theo giờ, gợi ý tài xế cho đơn đang chờ và gợi ý ghép đơn.</summary>
public sealed class AdminThongMinhPage : AdminKyThuatTrang
{
    protected override Quyen? QuyenCan => Quyen.XemThongKe;
    public AdminThongMinhPage() : base("Vận hành thông minh") { }

    protected override async Task DungAsync()
    {
        if (DuLieuService.DangOnline) { try { await DuLieuService.TaiDonToanHeThongAsync(); } catch (Exception ex) { CrashLog.Ghi("ThongMinh.Tai", ex); } }

        // ---- Dự báo nhu cầu
        var db = NangCaoService.DuBaoNhuCau();
        var dinh = db.OrderByDescending(x => x.DonTrungBinh).First();
        var bang = new VerticalStackLayout { Spacing = 3 };
        double max = Math.Max(1, db.Max(x => x.DonTrungBinh));
        foreach (var g in db.Where(x => x.Gio >= 6 && x.Gio <= 23))
        {
            var hang = new Grid { ColumnSpacing = 6, ColumnDefinitions = { new ColumnDefinition(34), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            hang.Add(AdminUi.Nhan($"{g.Gio:00}h", 11, mo: true), 0, 0);
            var bar = new BoxView { HeightRequest = 8, CornerRadius = 4, Color = Color.FromArgb(g.Gio == dinh.Gio ? AdminUi.Tim : "#C4B5FD"), HorizontalOptions = LayoutOptions.Start, WidthRequest = 4 };
            var khung = new Grid(); khung.Add(bar);
            khung.SizeChanged += (_, _) => bar.WidthRequest = Math.Max(4, khung.Width * g.DonTrungBinh / max);
            hang.Add(khung, 1, 0);
            hang.Add(AdminUi.Nhan(g.DonTrungBinh == 0 ? "—" : $"{g.DonTrungBinh:0.#} đơn · {g.TaiXeCan} xe", 11, mo: true), 2, 0);
            bang.Add(hang);
        }
        Nd.Add(KhoiTheo("📈 Dự báo nhu cầu theo giờ",
            AdminUi.Nhan(dinh.DonTrungBinh == 0 ? "Chưa đủ dữ liệu để dự báo." : $"Cao điểm quanh {dinh.Gio:00}h (~{dinh.DonTrungBinh:0.#} đơn/giờ) → nên có khoảng {dinh.TaiXeCan} tài xế trực.", 12.5, dam: true),
            bang,
            AdminUi.Nhan("Dự báo = trung bình số đơn theo giờ của các ngày đã có dữ liệu; giả định 1 tài xế ≈ 2 đơn/giờ. Chưa chia theo khu vực vì đơn chưa lưu tọa độ.", 11, mo: true)));

        // ---- Phân công tài xế
        var cho = NangCaoService.DonChoTaiXe();
        var goiYTx = NangCaoService.GoiYTaiXe(3);
        var khoiPc = new VerticalStackLayout { Spacing = 8 };
        if (cho.Count == 0) khoiPc.Add(AdminUi.Nhan("Không có đơn nào đang chờ tài xế 🎉", 12.5, mo: true));
        else
        {
            khoiPc.Add(AdminUi.Nhan($"{cho.Count} đơn đang chờ tài xế (cũ nhất: #{cho[0].Id} · {cho[0].TenGianHang}, {(int)(DateTime.Now - cho[0].NgayDat).TotalMinutes} phút).", 12.5, dam: true));
            if (goiYTx.Count == 0) khoiPc.Add(AdminUi.Nhan("⚠ Không có tài xế nào đang online và sẵn sàng.", 12, mo: true));
            int h = 1;
            foreach (var g in goiYTx)
                khoiPc.Add(AdminUi.Nhan($"{h++}. {g.TaiXe.HoTen} · ⭐ {g.TaiXe.DanhGia:0.0} · đang giữ {g.DonDangGiu} đơn", 12.5));
            khoiPc.Add(AdminUi.Nhan("Thứ tự ưu tiên: điểm đánh giá cao, ít đơn đang giữ. Quản trị viên vẫn là người bấm phân công.", 11, mo: true));
        }
        var nutDp = AdminUi.Nut("Mở điều phối tài xế", AdminUi.Tim, day: true);
        nutDp.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(AdminDispatchPage));
        khoiPc.Add(nutDp);
        Nd.Add(KhoiTheo("🧭 Gợi ý phân công tài xế", khoiPc));

        // ---- Ghép đơn
        var ghep = NangCaoService.GoiYGhepDon();
        var khoiGhep = new VerticalStackLayout { Spacing = 6 };
        if (ghep.Count == 0) khoiGhep.Add(AdminUi.Nhan("Hiện chưa có cặp đơn nào phù hợp để ghép.", 12.5, mo: true));
        foreach (var g in ghep.Take(8))
            khoiGhep.Add(AdminUi.Nhan($"#{g.A.Id} + #{g.B.Id} — {g.LyDo}", 12.5));
        khoiGhep.Add(AdminUi.Nhan("Chỉ là gợi ý theo quán và quãng đường; đơn chưa lưu tọa độ nên chưa đánh giá được độ lệch tuyến. Tối ưu lộ trình thực tế cần dịch vụ bản đồ (chưa tích hợp).", 11, mo: true));
        Nd.Add(KhoiTheo("📦 Gợi ý ghép đơn", khoiGhep));
    }
}
