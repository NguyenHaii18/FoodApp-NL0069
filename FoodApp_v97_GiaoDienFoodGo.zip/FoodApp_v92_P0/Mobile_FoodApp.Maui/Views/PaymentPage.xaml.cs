using FoodApp.Maui.Models;
using FoodApp.Maui.Services;
using System.Collections.ObjectModel;

namespace FoodApp.Maui.Views;

/// <summary>Chỉ các hình thức máy chủ đã hỗ trợ (MobileApiController.IsValidPayment). Chuyển khoản / ví điện tử thêm lại khi có cổng thật.</summary>
public enum HinhThucThanhToan { TienMat, VNPay }

[QueryProperty(nameof(GioHang), "GioHang")]
[QueryProperty(nameof(TenGianHang), "TenGianHang")]
[QueryProperty(nameof(GianHangId), "GianHangId")]
public partial class PaymentPage : ContentPage
{
    private string? _maYeuCauDat;   // token chống tạo đơn trùng cho giỏ hiện tại
    private string? _chuKyGio;
    public ObservableCollection<MucGioHang> GioHang { get; set; } = new();
    public string TenGianHang { get; set; } = "";
    public string GianHangId { get; set; } = "";

    // Mặc định cũ "ChuyenKhoan"/"ViDienTu" (đã bỏ) hoặc giá trị số lạ → quay về tiền mặt
    private HinhThucThanhToan _hinhThucChon =
        Enum.TryParse<HinhThucThanhToan>(Preferences.Default.Get("tt-mac-dinh", "TienMat"), out var ttmd) && Enum.IsDefined(ttmd) ? ttmd : HinhThucThanhToan.TienMat;
    private decimal _giamGia = 0;                 // giảm trên tiền món
    private decimal _giamShip = 0;                // giảm trên phí giao hàng
    private KhuyenMai? _kmDangDung;               // voucher đang áp dụng
    // Phí giao hàng tính theo khoảng cách quán → địa chỉ khách và khu vực (xem GiaoHangService)
    private KetQuaTuyen _tuyen = GiaoHangService.UocTinh(null, null);
    private decimal PhiGiaoHang => _tuyen.Phi;

    private readonly Services.TreTimKiem _tre = new();
    private void OnDiaChiChanged(object? sender, TextChangedEventArgs e) => _tre.Chay(TinhLaiPhi);   // tính phí sau khi ngừng gõ

    private void TinhLaiPhi()
    {
        var diaChiQuan = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == GianHangId)?.DiaChi;
        _tuyen = GiaoHangService.UocTinh(diaChiQuan, EntryDiaChi.Text);    // hiển thị tạm ngay (ước tính cục bộ)
        CapNhatTongTien();
        _ = XacMinhPhiAsync();                                              // rồi hỏi máy chủ phí theo tuyến thật
    }

    // v94: phí ước tính theo quận/huyện KHÔNG phải căn cứ thu tiền → hỏi máy chủ (quãng đường thật) và ghi rõ nguồn của con số đang hiển thị.
    private bool _dangXacMinh;
    private string _khoaXacMinh = "";

    private async Task XacMinhPhiAsync(bool boQuaNho = false)
    {
        if (!DuLieuService.DangOnline) return;
        var diaChiQuan = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == GianHangId)?.DiaChi ?? "";
        var diaChi = EntryDiaChi.Text?.Trim() ?? "";
        if (string.IsNullOrWhiteSpace(diaChiQuan) || diaChi.Length < 6) return;
        var khoa = diaChiQuan + "|" + diaChi;
        _khoaXacMinh = khoa; _dangXacMinh = true; CapNhatTongTien();
        try
        {
            var (v, _) = await PhiGiaoXacMinhService.LayAsync(diaChiQuan, diaChi, boQuaNho);
            if (_khoaXacMinh != khoa) return;                               // khách đã đổi địa chỉ trong lúc chờ
            if (v is not null)
            {
                _tuyen = GiaoHangService.DungKetQuaMayChu(_tuyen, v);
                _giamShip = Math.Min(_giamShip, PhiGiaoHang);
            }
        }
        catch (Exception ex) { CrashLog.Ghi("Payment.XacMinhPhi", ex); }
        finally { if (_khoaXacMinh == khoa) { _dangXacMinh = false; CapNhatTongTien(); } }
    }

    /// <summary>Ngay trước khi đặt: lấy phí chính thức mới nhất từ máy chủ; phí đổi thì khách phải đồng ý lại; phí chưa xác minh + VNPay thì cảnh báo.</summary>
    private async Task<bool> XacNhanPhiGiaoAsync()
    {
        if (!DuLieuService.DangOnline) return true;
        var truoc = PhiGiaoHang;
        await XacMinhPhiAsync(boQuaNho: true);
        if (PhiGiaoHang != truoc &&
            !await DisplayAlert("Phí giao hàng đã được cập nhật",
                $"Phí giao chính thức: {PhiGiaoHang:N0}đ (trước đó hiển thị {truoc:N0}đ).\nTổng thanh toán mới: {TongCong:N0}đ.", "Đồng ý đặt", "Xem lại"))
            return false;
        if (!_tuyen.DaXacMinh && _hinhThucChon == HinhThucThanhToan.VNPay)
            return await DisplayAlert("Phí giao chưa xác minh theo tuyến đường",
                "Hệ thống chưa đo được quãng đường thật nên phí giao đang là phí tạm tính. Nếu thanh toán trước bằng VNPay, bạn sẽ trả theo phí này.\n\nBạn có thể chọn Tiền mặt để trả đúng phí sau khi tài xế xác nhận quãng đường thực tế.",
                "Vẫn thanh toán VNPay", "Chọn lại");
        return true;
    }

    /// <summary>"Giao ngay" + 6 khung 30 phút, bắt đầu khoảng 1 tiếng sau.</summary>
    private readonly List<DateTime> _gioBatDau = new();

    private void NapKhungGio()
    {
        var ds = new List<string> { "Giao ngay" };
        var bd = DateTime.Now.AddHours(1);
        bd = new DateTime(bd.Year, bd.Month, bd.Day, bd.Hour, bd.Minute < 30 ? 30 : 0, 0).AddHours(bd.Minute < 30 ? 0 : 1);
        for (int i = 0; i < 6; i++)
        {
            var a = bd.AddMinutes(30 * i);
            _gioBatDau.Add(a);
            ds.Add($"{a:HH:mm} – {a.AddMinutes(30):HH:mm}");
        }
        PickerGioGiao.ItemsSource = ds;
        PickerGioGiao.SelectedIndex = 0;
    }

    private readonly (HinhThucThanhToan Loai, string Nhan, string Icon)[] _dsHinhThuc =
    {
        (HinhThucThanhToan.TienMat, "Tiền mặt khi nhận hàng", "💵"),
        (HinhThucThanhToan.VNPay, "VNPay", "💳"),
    };

    public PaymentPage()
    {
        InitializeComponent();
        EntryDiaChi.Text = Phien.Khach?.DiaChi ?? "";
        NapKhungGio();
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        DsChiTiet.ItemsSource = GioHang;
        LblPhuongThucGiao.Text = "Tài xế nhận món tại quán rồi giao đến địa chỉ của bạn. Phí giao tính theo khoảng cách quán → địa chỉ nhận.";
        VeDanhSachHinhThuc();
        TinhLaiPhi();
        CapNhatTongTien();
        _ = LamMoiChinhSachAsync();
    }

    /// <summary>v90: tải chính sách chung (phí dịch vụ…) rồi tính lại tổng tiền.</summary>
    private async Task LamMoiChinhSachAsync()
    {
        try { await ChinhSachService.LamMoiAsync(); CapNhatTongTien(); }
        catch (Exception ex) { CrashLog.Ghi("Payment.ChinhSach", ex); }
    }

    private void VeDanhSachHinhThuc()
    {
        DanhSachHinhThuc.Children.Clear();
        foreach (var ht in _dsHinhThuc)
        {
            var chon = ht.Loai == _hinhThucChon;
            var row = new Grid { Padding = new Thickness(12, 10) };
            row.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));
            row.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
            row.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));
            row.Add(new Label { Text = ht.Icon, FontSize = 18, VerticalOptions = LayoutOptions.Center }, 0, 0);
            var chu = new VerticalStackLayout { VerticalOptions = LayoutOptions.Center, Spacing = 1 };
            chu.Children.Add(new Label
            {
                Text = ht.Loai == HinhThucThanhToan.VNPay ? "Thanh toán online qua VNPay" : ht.Nhan,
                FontSize = 13.5,
                FontAttributes = chon ? FontAttributes.Bold : FontAttributes.None,
            });
            if (ht.Loai == HinhThucThanhToan.VNPay)
                chu.Children.Add(new Label { Text = "Thẻ ATM / QR / ví — mở trang VNPay sau khi đặt hàng", FontSize = 11.5, TextColor = (Color)Resources["TextGrey"] });
            row.Add(chu, 1, 0);
            row.Add(new Label
            {
                Text = chon ? "●" : "○",
                TextColor = chon ? (Color)Resources["Primary"] : (Color)Resources["BorderColor"],
                VerticalOptions = LayoutOptions.Center
            }, 2, 0);

            var tap = new TapGestureRecognizer();
            tap.Tapped += (s, e) => { _hinhThucChon = ht.Loai; VeDanhSachHinhThuc(); };
            row.GestureRecognizers.Add(tap);

            DanhSachHinhThuc.Children.Add(row);
        }
        CapNhatTongTien();      // nhãn nút đặt hàng đổi theo hình thức
    }

    // ----- Tăng/giảm số lượng ngay trong giỏ -----
    private async void OnTangSoLuongTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is not MucGioHang m) return;
        m.SoLuong = Math.Min(99, m.SoLuong + 1);
        await LamMoiGioAsync();
    }

    private async void OnBoMonTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is not MucGioHang m) return;
        if (!await DisplayAlert("Bỏ món", $"Bỏ {m.MonAn.TenMon} khỏi giỏ hàng?", "Bỏ", "Giữ lại")) return;
        GioHang.Remove(m);
        await LamMoiGioAsync();
    }

    private async void OnGhiChuMonTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is not MucGioHang m) return;
        var nd = await this.NhapAsync($"Ghi chú · {m.MonAn.TenMon}", "VD: ít cay, không hành, thêm đá...", "Lưu", "Hủy",
            initialValue: m.GhiChu, maxLength: 120);
        if (nd is null) return;          // bấm Hủy
        m.GhiChu = nd.Trim();
        await LamMoiGioAsync();
    }

    private async void OnGiamSoLuongTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is not MucGioHang m) return;
        if (m.SoLuong > 1) m.SoLuong--;
        else
        {
            if (!await DisplayAlert("Bỏ món", $"Bỏ {m.MonAn.TenMon} khỏi giỏ hàng?", "Bỏ", "Giữ lại")) return;
            GioHang.Remove(m);
        }
        await LamMoiGioAsync();
    }

    /// <summary>SoLuong không tự báo thay đổi nên gán lại nguồn để vẽ lại; kiểm tra lại voucher theo giỏ mới.</summary>
    private async Task LamMoiGioAsync()
    {
        DsChiTiet.ItemsSource = null;
        DsChiTiet.ItemsSource = GioHang;
        _ = GioHangService.LuuAsync();        // giỏ lưu bền theo tài khoản (máy + server)
        if (GioHang.Count == 0)
        {
            await DisplayAlert("Giỏ hàng trống", "Hãy chọn món từ thực đơn.", "OK");
            await Shell.Current.GoToAsync("..");
            return;
        }
        if (_kmDangDung is not null) DatVoucher(_kmDangDung);
        else CapNhatTongTien();
    }

    private decimal TamTinh => GioHang.Sum(x => x.ThanhTien);
    /// <summary>v90: phí dịch vụ theo chính sách (0 = miễn phí / chưa áp dụng).</summary>
    private decimal PhiDichVu => ChinhSachService.PhiDichVu;
    /// <summary>v90: đơn tối thiểu của quán đang đặt (0 = không yêu cầu).</summary>
    private decimal DonToiThieu => MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == GianHangId)?.DonToiThieu ?? 0;
    private decimal TongCong => Math.Max(0, TamTinh + PhiGiaoHang + PhiDichVu - _giamGia - _giamShip);

    private void CapNhatTongTien()
    {
        LblTamTinh.Text = $"{TamTinh:N0}đ";
        LblTongCong.Text = $"{TongCong:N0}đ";
        LblPhiDichVu.Text = PhiDichVu > 0 ? $"{PhiDichVu:N0}đ" : "Miễn phí";
        var thieuToiThieu = DonToiThieu - TamTinh;
        LblDonToiThieu.IsVisible = DonToiThieu > 0 && thieuToiThieu > 0;
        if (LblDonToiThieu.IsVisible) LblDonToiThieu.Text = $"⚠ Cần thêm {thieuToiThieu:N0}đ để đạt đơn tối thiểu {DonToiThieu:N0}đ của quán.";
        RowGiamGia.IsVisible = _giamGia + _giamShip > 0;
        if (_giamGia + _giamShip > 0) LblGiamGia.Text = $"-{_giamGia + _giamShip:N0}đ";
        var chiTietTuyen = _tuyen.DaXacDinh ? $" · ≈{_tuyen.Km:0.#} km · ~{_tuyen.Phut} phút" : " (chưa rõ khu vực)";
        // v94: ghi rõ con số đến từ đâu — phí theo tuyến thật (máy chủ) hay chỉ là ước tính
        var nguonPhi = _dangXacMinh ? " · ⏳ đang xác minh…"
            : _tuyen.DaXacMinh ? " · ✔ theo quãng đường thật"
            : DuLieuService.DangOnline ? " · ⚠ tạm tính" : " · ⚠ ước tính (ngoại tuyến)";
        chiTietTuyen += nguonPhi;
        LblPhuongThucGiao.Text = "Tài xế nhận món tại quán rồi giao đến địa chỉ của bạn. " + (_tuyen.DaXacMinh
            ? "Phí giao đã được máy chủ tính theo quãng đường thật."
            : "Phí giao hiện chỉ là TẠM TÍNH; phí chính thức do hệ thống xác nhận theo quãng đường thực tế khi bạn đặt đơn.");
        LblPhiGiao.Text = _giamShip > 0 ? $"{PhiGiaoHang - _giamShip:N0}đ (đã giảm {_giamShip:N0}đ){chiTietTuyen}" : $"{PhiGiaoHang:N0}đ{chiTietTuyen}";
        BtnXacNhanDatHang.Text = _hinhThucChon == HinhThucThanhToan.VNPay
            ? $"Đặt hàng & thanh toán VNPay • {TongCong:N0}đ"
            : $"Xác nhận đặt hàng • {TongCong:N0}đ";
    }

    private async void OnApDungKhuyenMaiClicked(object sender, EventArgs e)
    {
        var maCode = EntryMaKhuyenMai.Text?.Trim();
        if (string.IsNullOrEmpty(maCode)) return;

        var km = MockData.DanhSachKhuyenMai.FirstOrDefault(k => string.Equals(k.MaCode, maCode, StringComparison.OrdinalIgnoreCase));
        if (km is null)
        {
            DatVoucher(null);
            HienKetQuaVoucher(false, "Mã khuyến mãi không tồn tại");
            return;
        }
        await DatVoucherServerAsync(km);
    }

    /// <summary>Online: máy chủ quyết định voucher có dùng được không (cùng quy tắc lúc đặt đơn); lỗi mạng/offline thì dùng kiểm tra cục bộ.</summary>
    private async Task DatVoucherServerAsync(KhuyenMai km)
    {
        var sv = await KhuyenMaiService.KiemTraServerAsync(km.MaCode, GianHangId, GioHang, PhiGiaoHang);
        DatVoucher(km, sv);
    }

    private void HienKetQuaVoucher(bool ok, string nd)
    {
        LblKetQuaKhuyenMai.Text = (ok ? "✔ " : "✘ ") + nd;
        LblKetQuaKhuyenMai.TextColor = (Color)Resources[ok ? "Success" : "Danger"];
        LblKetQuaKhuyenMai.IsVisible = true;
    }

    /// <summary>Kiểm tra và áp dụng voucher vào đơn hiện tại (km = null: gỡ voucher).</summary>
    private void DatVoucher(KhuyenMai? km, KetQuaVoucher? kqServer = null)
    {
        _kmDangDung = null; _giamGia = 0; _giamShip = 0;
        if (km is not null)
        {
            var kq = kqServer ?? KhuyenMaiService.KiemTra(km, GianHangId, GioHang, PhiGiaoHang, Phien.Khach?.Email);
            HienKetQuaVoucher(kq.HopLe, kq.HopLe ? $"Áp dụng {km.MaCode}: {kq.ThongDiep}" : kq.ThongDiep);
            if (kq.HopLe) { _kmDangDung = km; _giamGia = kq.GiamDon; _giamShip = kq.GiamPhiShip; EntryMaKhuyenMai.Text = km.MaCode; }
        }
        else LblKetQuaKhuyenMai.IsVisible = false;
        CapNhatTongTien();
    }

    private async void OnChonUuDaiClicked(object sender, EventArgs e)
    {
        var ds = KhuyenMaiService.DanhSachUuDai(GianHangId, GioHang, PhiGiaoHang, Phien.Khach?.Email);
        if (ds.Count == 0) { await DisplayAlert("Ưu đãi", "Hiện chưa có ưu đãi nào cho gian hàng này.", "OK"); return; }

        var nhan = ds.Select(x => (x.Kq.HopLe ? "✔ " : "✘ ") + $"{x.Km.MaCode} · {x.Km.GiaTriGiamHienThi}" +
                                  (x.Kq.HopLe ? $" (-{x.Kq.TongGiam:N0}đ)" : $" — {x.Kq.ThongDiep}")).ToArray();
        var chon = await DisplayActionSheet("Chọn ưu đãi", "Đóng", _kmDangDung is null ? null : "Bỏ mã đang dùng", nhan);
        if (chon is null or "Đóng") return;
        if (chon == "Bỏ mã đang dùng") { EntryMaKhuyenMai.Text = ""; DatVoucher(null); return; }

        var i = Array.IndexOf(nhan, chon);
        if (i >= 0) await DatVoucherServerAsync(ds[i].Km);       // không dùng được thì hiện lý do ngay dưới ô nhập mã
    }

    // ---------------------------------------------------------------- v90: sửa tùy chọn món ngay trong giỏ
    /// <summary>Mở lại size / mức cay (chọn một) và topping (chọn nhiều) của món trong giỏ; trùng dòng khác thì gộp số lượng.</summary>
    private async void OnSuaTuyChonTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is not MucGioHang dong || dong.MonAn is null || dong.MonAn.TuyChon.Count == 0) return;
        var chon = dong.TuyChonDaChon.ToList();
        foreach (var nhom in dong.MonAn.TuyChon.GroupBy(t => t.Loai))
        {
            var tenNhom = TuyChonMon.NhanLoai(nhom.Key);
            var dsNhom = nhom.ToList();
            if (nhom.Key == TuyChonMon.Topping)
            {
                while (true)
                {
                    var nhanTop = dsNhom.Select(t => (chon.Any(c => c.Ten == t.Ten) ? "✔ " : "○ ") + t.HienThi).ToArray();
                    var kq = await DisplayActionSheet($"{tenNhom} (chạm để chọn / bỏ)", "Xong", null, nhanTop);
                    if (kq is null or "Xong") break;
                    var vt = Array.IndexOf(nhanTop, kq);
                    if (vt < 0) break;
                    var tuyChon = dsNhom[vt];
                    var daCo = chon.FirstOrDefault(c => c.Ten == tuyChon.Ten && c.Loai == tuyChon.Loai);
                    if (daCo is not null) chon.Remove(daCo); else chon.Add(tuyChon);
                }
            }
            else
            {
                var batBuoc = nhom.Key == TuyChonMon.Size;
                var nhanMot = dsNhom.Select(t => t.HienThi).ToList();
                const string macDinh = "Mặc định (không chọn)";
                var luaChon = (batBuoc ? nhanMot : nhanMot.Prepend(macDinh).ToList()).ToArray();
                var kq = await DisplayActionSheet(tenNhom + (batBuoc ? " (bắt buộc)" : ""), "Giữ nguyên", null, luaChon);
                if (kq is null or "Giữ nguyên") continue;
                chon.RemoveAll(c => c.Loai == nhom.Key);
                if (kq != macDinh)
                {
                    var vt = nhanMot.IndexOf(kq);
                    if (vt >= 0) chon.Add(dsNhom[vt]);
                }
            }
        }
        if (dong.MonAn.TuyChon.Any(t => t.Loai == TuyChonMon.Size) && !chon.Any(t => t.Loai == TuyChonMon.Size))
        {
            await DisplayAlert("Chưa chọn size", "Vui lòng chọn kích cỡ / khẩu phần cho món.", "OK");
            return;
        }
        GioHangService.DoiTuyChon(dong, chon);
        await LamMoiGioAsync();
    }

    // ---------------------------------------------------------------- v90: dùng điểm thưởng (voucher đã đổi)
    private sealed class VoucherDiemDto { public string MaCode { get; set; } = ""; public decimal SoTienGiam { get; set; } public decimal DonToiThieu { get; set; } public DateTime HetHan { get; set; } public bool DaDung { get; set; } }
    private sealed class DiemTomTatDto { public int ConLai { get; set; } public List<VoucherDiemDto> Vouchers { get; set; } = new(); }

    /// <summary>Liệt kê voucher khách đã đổi bằng điểm (còn hạn, chưa dùng) để áp vào đơn; có lối tắt sang trang đổi điểm.</summary>
    private async void OnDungDiemClicked(object? sender, EventArgs e)
    {
        if (!DuLieuService.DangOnline || string.IsNullOrEmpty(ApiClient.Token))
        {
            await DisplayAlert("Điểm thưởng", "Cần đăng nhập và kết nối máy chủ để dùng điểm thưởng (điểm và voucher đã đổi do máy chủ giữ).", "OK");
            return;
        }
        var r = await ApiClient.GetAsync<DiemTomTatDto>("api/mobile/khach-hang/diem");
        if (!r.ThanhCong || r.DuLieu is null) { await DisplayAlert("Điểm thưởng", "Chưa tải được điểm thưởng: " + r.ThongDiep, "OK"); return; }

        var dung = r.DuLieu.Vouchers.Where(x => !x.DaDung && x.HetHan > DateTime.Now).ToList();
        var nhanDoi = $"➕ Đổi điểm lấy voucher mới (còn {r.DuLieu.ConLai:N0} điểm)";
        var nhan = dung.Select(x => $"{x.MaCode} · giảm {x.SoTienGiam:N0}đ (đơn từ {x.DonToiThieu:N0}đ)").Append(nhanDoi).ToArray();
        var chon = await DisplayActionSheet($"Điểm thưởng: {r.DuLieu.ConLai:N0} điểm", "Đóng", null, nhan);
        if (chon is null or "Đóng") return;
        if (chon == nhanDoi) { await Shell.Current.GoToAsync(nameof(ThanhVienPage)); return; }

        var vt = Array.IndexOf(nhan, chon);
        if (vt < 0 || vt >= dung.Count) return;
        var voucher = dung[vt];
        var km = new KhuyenMai
        {
            Id = "diem-" + voucher.MaCode, MaCode = voucher.MaCode, TenChuongTrinh = "Voucher đổi điểm thưởng",
            LoaiGiam = LoaiGiamGia.SoTien, GiaTriGiam = voucher.SoTienGiam, GiaTriDonToiThieu = voucher.DonToiThieu,
            NgayBatDau = DateTime.Now.AddDays(-1), NgayKetThuc = voucher.HetHan,
        };
        EntryMaKhuyenMai.Text = voucher.MaCode;
        await DatVoucherServerAsync(km);       // máy chủ quyết định voucher dùng được hay không; lý do hiện dưới ô nhập mã
    }

    // ---------------------------------------------------------------- v90: kiểm tra giỏ trước khi đặt
    /// <summary>Làm mới giá/tình trạng món rồi hỏi khách nếu có thay đổi. Trả về true = được phép tiếp tục đặt.</summary>
    private async Task<bool> KiemTraGioTruocKhiDatAsync()
    {
        LoadingXacNhan.IsVisible = true; LoadingXacNhan.IsRunning = true; BtnXacNhanDatHang.IsEnabled = false;
        GioHangService.KetQuaKiemTraGio kiem;
        try { kiem = await GioHangService.KiemTraAsync(); }
        finally { LoadingXacNhan.IsVisible = false; LoadingXacNhan.IsRunning = false; BtnXacNhanDatHang.IsEnabled = true; }

        if (!kiem.CoVanDe) return true;

        if (kiem.DongKhongBan.Count > 0)
        {
            var bo = await DisplayAlert("Có món không đặt được", string.Join("\n", kiem.LyDoKhongBan) + "\n\nBỏ các món này khỏi giỏ?", "Bỏ món", "Xem lại giỏ");
            if (bo) foreach (var d in kiem.DongKhongBan) GioHang.Remove(d);
            await LamMoiGioAsync();
            if (bo && GioHang.Count > 0)
                await DisplayAlert("Đã cập nhật giỏ hàng", "Hãy kiểm tra lại tổng tiền rồi bấm đặt hàng.", "OK");
            return false;
        }

        // chỉ đổi giá: vẽ lại giá mới, hỏi khách có đồng ý không
        var dong = kiem.DoiGia.Select(x => $"{x.Dong.MonAn.TenMon}: {x.GiaCu:N0}đ → {x.GiaMoi:N0}đ" + (x.TuyChonDoi ? " (một số tùy chọn đã thay đổi)" : ""));
        await LamMoiGioAsync();
        var tiep = await DisplayAlert("Giá món đã thay đổi", string.Join("\n", dong) + $"\n\nTổng thanh toán mới: {TongCong:N0}đ. Tiếp tục đặt?", "Tiếp tục đặt", "Xem lại");
        if (!tiep) return false;
        GioHangService.ChotGia();
        return true;
    }

    /// <summary>Bản tóm tắt đơn để khách rà soát trước khi xác nhận.</summary>
    private string TomTatDonDeKiemTra()
    {
        var thoiGian = PickerGioGiao.SelectedIndex > 0 ? $"hẹn {PickerGioGiao.SelectedItem}" : "giao ngay";
        var diaChi = string.IsNullOrWhiteSpace(EntryDiaChi.Text) ? "(chưa nhập — dùng địa chỉ mặc định)" : EntryDiaChi.Text.Trim();
        var thanhToan = _dsHinhThuc.First(h => h.Loai == _hinhThucChon).Nhan;
        var ma = _kmDangDung is null ? "" : $"\n🎟 Mã {_kmDangDung.MaCode}: -{_giamGia + _giamShip:N0}đ";
        return $"{TenGianHang} · {GioHang.Sum(x => x.SoLuong)} món\n📍 {diaChi}\n🕒 {char.ToUpper(thoiGian[0])}{thoiGian[1..]}\n💳 {thanhToan}{ma}\n\nTổng thanh toán: {TongCong:N0}đ";
    }

    private async void OnChonSoDiaChiTapped(object? sender, TappedEventArgs e)
    {
        var ds = TaiKhoanService.LayDiaChi();
        if (ds.Count == 0) { await DisplayAlert("Sổ địa chỉ trống", "Thêm địa chỉ trong Tài khoản → Sổ địa chỉ.", "OK"); return; }
        var chon = await DisplayActionSheet("Chọn địa chỉ", "Đóng", null, ds.Select(d => $"{d.Nhan}: {d.DiaChi}").ToArray());
        if (chon is null or "Đóng") return;
        EntryDiaChi.Text = chon[(chon.IndexOf(": ", StringComparison.Ordinal) + 2)..];
    }

    private async void OnXacNhanDatHangClicked(object sender, EventArgs e)
    {
        if (Preferences.Default.Get("cd-xacnhandat", false) && GioHang.Count > 0 &&
            !await DisplayAlert("Kiểm tra & xác nhận đơn", TomTatDonDeKiemTra(), "Đặt hàng", "Xem lại"))
            return;

        // Gian hàng đóng cửa / ngoài giờ / tạm dừng nhận đơn tại thời điểm đặt → không cho tạo đơn.
        var ghDat = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == GianHangId);
        if (ghDat is not null && !ghDat.CoTheNhanDon)
        {
            await DisplayAlert("Không thể đặt hàng", ghDat.LyDoKhongNhanDon + ". Vui lòng quay lại sau hoặc chọn quán khác.", "OK");
            return;
        }

        // v90: giá / tình trạng món có thể đã đổi từ lúc thêm vào giỏ → kiểm tra lại, hỏi khách nếu có thay đổi
        if (GioHang.Count > 0 && !await KiemTraGioTruocKhiDatAsync()) return;

        // v90: điều kiện đặt tối thiểu của quán (tính trên tiền món, sau khi đã cập nhật giá mới)
        if (DonToiThieu > 0 && TamTinh < DonToiThieu)
        {
            var themMon = await DisplayAlert("Chưa đạt đơn tối thiểu",
                $"{TenGianHang} yêu cầu đơn tối thiểu {DonToiThieu:N0}đ. Giỏ của bạn còn thiếu {DonToiThieu - TamTinh:N0}đ.", "Chọn thêm món", "Đóng");
            if (themMon) await Shell.Current.GoToAsync("..");
            return;
        }

        // Kiểm tra lại voucher ngay lúc đặt hàng (có thể đã hết hạn/hết lượt/giỏ hàng đã đổi từ lúc áp dụng)
        if (_kmDangDung is not null)
        {
            var kq = KhuyenMaiService.KiemTra(_kmDangDung, GianHangId, GioHang, PhiGiaoHang, Phien.Khach?.Email);
            if (!kq.HopLe)
            {
                var lyDo = kq.ThongDiep;
                DatVoucher(null);
                await DisplayAlert("Mã khuyến mãi không còn hợp lệ", lyDo + "\nMã đã được gỡ khỏi đơn, vui lòng kiểm tra lại tổng tiền.", "OK");
                return;
            }
            _giamGia = kq.GiamDon; _giamShip = kq.GiamPhiShip;
            CapNhatTongTien();
        }

        if (_hinhThucChon == HinhThucThanhToan.VNPay && !DuLieuService.DangOnline)
        {
            await DisplayAlert("Chưa thanh toán VNPay được", "Cần kết nối máy chủ để thanh toán VNPay. Hãy kiểm tra mạng hoặc chọn tiền mặt.", "OK");
            return;
        }

        // v94: phí giao chính thức theo tuyến đường thật (máy chủ) — không đặt đơn dựa trên số ước tính nếu số thật đã khác
        if (!await XacNhanPhiGiaoAsync()) return;

        LoadingXacNhan.IsVisible = true;
        LoadingXacNhan.IsRunning = true;
        BtnXacNhanDatHang.IsEnabled = false;

        try
        {
            var tongDon = TongCong;     // chụp trước: giỏ sẽ được dọn sau khi đặt xong
            if (GioHang.Count == 0)
            {
                await DisplayAlert("Giỏ hàng trống", "Hãy chọn món trước khi đặt hàng.", "OK");
                return;
            }

            var don = new DonHang
            {
                Id = "DH" + DateTime.Now.ToString("yyMMddHHmmss"),
                GianHangId = GianHangId,
                KhachEmail = Phien.Khach?.Email ?? "",
                KhachTen = Phien.Khach?.HoTen ?? "",
                KhachSdt = Phien.Khach?.SoDienThoai ?? "",
                TenGianHang = TenGianHang,
                ChiTiet = GioHang.ToList(),
                TrangThai = TrangThaiDonHang.ChoXacNhan,
                NgayDat = DateTime.Now,
                DiaChiGiao = string.IsNullOrWhiteSpace(EntryDiaChi.Text) ? "Địa chỉ mặc định của khách" : EntryDiaChi.Text.Trim(),
                GioHenGiao = PickerGioGiao.SelectedIndex > 0 ? (string)PickerGioGiao.SelectedItem : "",
                HenGiaoLuc = PickerGioGiao.SelectedIndex > 0 ? _gioBatDau[PickerGioGiao.SelectedIndex - 1] : null,
                HinhThucThanhToan = _dsHinhThuc.First(h => h.Loai == _hinhThucChon).Nhan,
                TrangThaiThanhToan = _hinhThucChon == HinhThucThanhToan.VNPay ? "ChoThanhToan" : "",
                MaKhuyenMai = _kmDangDung?.MaCode ?? "",
                GiamGia = _giamGia + _giamShip,           // gồm cả phần giảm phí giao hàng
                PhiGiaoHang = PhiGiaoHang,
                PhiDichVu = PhiDichVu,
                DiaChiLayHang = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == GianHangId)?.DiaChi ?? "",
            };
            GiaoHangService.GanTuyenVaoDon(don, _tuyen);                       // khoảng cách, khu vực, phí theo biểu phí
            don.MaXacNhanGiao = Random.Shared.Next(1000, 10000).ToString();   // khách đọc mã này cho tài xế khi nhận hàng

            if (DuLieuService.DangOnline)
            {
                // Token chống tạo đơn trùng: giữ nguyên khi gửi lại cùng một giỏ (mất mạng/bấm lại), đổi khi giỏ/địa chỉ/thanh toán thay đổi
                var chuKy = string.Join("|", GianHangId, don.DiaChiGiao, _hinhThucChon, _kmDangDung?.MaCode,
                    string.Join(",", GioHang.Select(x => $"{x.MonAn.Id}:{x.SoLuong}:{x.ChuKyTuyChon}:{x.GhiChu}")));
                if (_maYeuCauDat is null || _chuKyGio != chuKy) { _maYeuCauDat = Guid.NewGuid().ToString("N"); _chuKyGio = chuKy; }
                var kq = await ApiClient.PostAsync<DatHangDto>("api/mobile/don-hang", new
                {
                    maYeuCauDat = _maYeuCauDat,
                    henGiaoLuc = don.HenGiaoLuc,     // v66: máy chủ lưu giờ hẹn (đơn theo lịch)
                    gianHangId = GianHangId,
                    diaChiGiao = don.DiaChiGiao,
                    hinhThucThanhToan = _hinhThucChon.ToString(),
                    maKhuyenMai = _kmDangDung?.MaCode,
                    ghiChu = GhiChuDonHang(),
                    chiTiet = GioHang.Select(x => new { monAnId = x.MonAn.Id, soLuong = x.SoLuong, tuyChonIds = x.TuyChonDaChon.Where(t => t.Id > 0).Select(t => t.Id).ToList(), ghiChu = x.GhiChu })
                });
                if (!kq.ThanhCong) { await DisplayAlert("Đặt hàng thất bại", kq.ThongDiep, "OK"); return; }
                if (!string.IsNullOrEmpty(kq.DuLieu?.Id)) don.Id = kq.DuLieu!.Id!;
                // Mã nhận hàng và tổng tiền phải là số liệu của MÁY CHỦ (tài xế nhập mã này, server kiểm tra)
                if (!string.IsNullOrEmpty(kq.DuLieu?.MaXacNhanGiao)) don.MaXacNhanGiao = kq.DuLieu!.MaXacNhanGiao!;
                // v94: phí giao / khoảng cách / thời gian cũng lấy theo MÁY CHỦ (con số thật sẽ thu), không giữ bản ước tính cục bộ
                if (kq.DuLieu is { PhiGiaoHang: { } phiMc })
                {
                    don.PhiGiaoHang = phiMc; don.PhiKhoangCach = phiMc; don.PhuPhiKhuVuc = 0;
                    if (kq.DuLieu.KhoangCachKm is > 0 and var kmMc) don.KhoangCachKm = kmMc;
                    if (kq.DuLieu.ThoiGianDuKienPhut is > 0 and var phutMc) don.ThoiGianDuKienPhut = phutMc;
                }
                if (kq.DuLieu?.TongTien is { } tongMc && tongMc != tongDon)
                    await DisplayAlert("Tổng tiền chính thức", $"Hệ thống tính tổng {tongMc:N0}đ (hiển thị trước đó {tongDon:N0}đ) theo phí giao và khuyến mãi mới nhất.", "OK");
                // VNPay: mở cổng thanh toán, rồi hỏi MÁY CHỦ kết quả (return/IPN ghi). Chưa trả → đơn ở trạng thái "chờ thanh toán"
                // và khách có nút "Thanh toán VNPay" trong tab Đơn hàng để thanh toán lại.
                if (_hinhThucChon == HinhThucThanhToan.VNPay)
                {
                    var daTra = await VnPayThanhToan.ThucHienAsync(this, don.Id, kq.DuLieu?.TongTien ?? tongDon, kq.DuLieu?.PaymentUrl);
                    don.TrangThaiThanhToan = daTra ? "DaThanhToan" : "ChoThanhToan";
                    if (!daTra)
                        await DisplayAlert("Đơn chưa thanh toán", $"Đơn #{don.Id} đã được tạo nhưng chưa thanh toán. Bạn có thể thanh toán lại trong mục Đơn hàng.", "Đã hiểu");
                }
                await DuLieuService.TaiDonHangKhachAsync();
            }
            else
            {
                await Task.Delay(300);
            }

            // Bug cũ: bấm "Xác nhận" chỉ chuyển tab mà không tạo đơn nào → tab Đơn hàng luôn trống.
            if (MockData.LichSuDonHang.All(d => d.Id != don.Id))
                MockData.LichSuDonHang.Insert(0, don);

            // Nối luồng: đơn khách đặt xuất hiện trong hàng đợi của gian hàng (cùng một đối tượng nên
            // khi quán xác nhận / bàn giao, khách thấy trạng thái đổi theo).
            if (MockData.DonHangCuaGianHang.All(d => d.Id != don.Id))
                MockData.DonHangCuaGianHang.Insert(0, don);
            if (!DuLieuService.DangOnline && _kmDangDung is not null)
                KhuyenMaiService.GhiNhanSuDung(_kmDangDung, Phien.Khach?.Email);     // tăng lượt dùng, ghi nhớ khách đã dùng
            DoiTacService.GuiThongBao(GianHangId, ThongBaoGianHang.DonMoi, "Có đơn hàng mới",
                $"Đơn #{don.Id} · {don.ChiTiet.Sum(x => x.SoLuong)} món · {don.TongTien:N0}đ. Hãy phản hồi trong {DonHang.PhutPhanHoiToiDa} phút.", don.Id);
            VendorLocalStore.Luu();

            // Ngoại tuyến: đơn chỉ nằm trên máy này — không được để khách tưởng gian hàng thật đã nhận đơn.
            if (!DuLieuService.DangOnline)
                await DisplayAlert("Đơn mới lưu trên máy", $"Đơn #{don.Id} mới được lưu trên máy này (chế độ ngoại tuyến). " +
                    "Đơn CHƯA được gửi tới gian hàng, chưa trừ tiền và chưa có tài xế. Hãy kết nối mạng và đặt lại để đơn được ghi nhận thật.", "Đã hiểu");

            // Đơn đã được tạo (máy chủ hoặc trên máy) → dọn giỏ lưu bền, kể cả khi khách bỏ dở bước thanh toán VNPay
            await GioHangService.XoaAsync();
            await Shell.Current.GoToAsync(nameof(DatHangThanhCongPage), new Dictionary<string, object> { { "DonId", don.Id } });
        }
        finally
        {
            LoadingXacNhan.IsVisible = false;
            LoadingXacNhan.IsRunning = false;
            BtnXacNhanDatHang.IsEnabled = true;
        }
    }

    /// <summary>Ghi chú gửi lên máy chủ: ghi chú chung cho quán + ghi chú riêng từng món (đơn chưa có cột ghi chú theo món).</summary>
    private string? GhiChuDonHang()
    {
        var ds = new List<string>();
        var nguoiNhan = EntryNguoiNhan.Text?.Trim();
        var sdtNhan = EntrySdtNhan.Text?.Trim();
        if (!string.IsNullOrEmpty(nguoiNhan) || !string.IsNullOrEmpty(sdtNhan))
            ds.Add($"Người nhận: {nguoiNhan}{(string.IsNullOrEmpty(sdtNhan) ? "" : " - " + sdtNhan)}");
        var huongDan = EntryHuongDan.Text?.Trim();
        if (!string.IsNullOrEmpty(huongDan)) ds.Add("Hướng dẫn giao: " + huongDan);
        var chung = EditorGhiChu.Text?.Trim();
        if (!string.IsNullOrEmpty(chung)) ds.Add(chung);
        ds.AddRange(GioHang.Where(x => x.CoGhiChu).Select(x => $"{x.MonAn.TenMon}: {x.GhiChu.Trim()}"));
        if (ds.Count == 0) return null;
        var kq = string.Join(" | ", ds);
        return kq.Length > 480 ? kq[..480] : kq;
    }

    private async void OnChonBanDoTapped(object? sender, TappedEventArgs e)
        => await BanDoPage.MoAsync(EntryDiaChi.Text ?? "", chonDiaChi: true, khiChon: dc => EntryDiaChi.Text = dc);
}
