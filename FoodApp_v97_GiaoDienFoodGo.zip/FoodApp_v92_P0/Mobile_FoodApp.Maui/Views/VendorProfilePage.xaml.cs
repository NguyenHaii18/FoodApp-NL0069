using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

public partial class VendorProfilePage : ContentPage
{
    public VendorProfilePage()
    {
        InitializeComponent();
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        NapHoSo();
    }

    private void NapTongQuan()
    {
        var gh = Models.MockData.GianHangHienTai;
        LblIconHub.Text = gh.HinhAnh;
        LblTenHub.Text = gh.TenGianHang;
        LblDiaChiHub.Text = "📍 " + gh.DiaChi;
        LblTrangThaiHub.Text = gh.DangMoCua ? "● Đang mở cửa" : "● Tạm đóng cửa";
        LblTrangThaiHub.TextColor = Color.FromArgb(gh.DangMoCua ? "#15803D" : "#6B7280");
        ChipHub.BackgroundColor = Color.FromArgb(gh.DangMoCua ? "#DCFCE7" : "#F3F4F6");
        var dg = Services.DoiTacService.DanhGiaCua(gh.Id);
        LblDiemHub.Text = dg.Count == 0 ? "–" : $"{dg.Average(d => d.SoSaoMonAn):0.0} ★";
        LblLuotHub.Text = dg.Count.ToString();
        LblMonHub.Text = Models.MockData.MonAnCuaGianHang(gh.Id).Count(m => m.ConHang && !m.TamNgungBan).ToString();
    }

    // "Thông tin cửa hàng" mở thành màn riêng (ẩn phần tổng quan), chia 4 tab để không phải kéo dài.
    private void OnBatTatThongTinTapped(object? sender, EventArgs e)
    {
        KhungTongQuan.IsVisible = false;
        KhungThongTinCuaHang.IsVisible = true;
        ChonTab(0);
    }

    private void OnQuayLaiClicked(object? sender, EventArgs e)
    {
        KhungThongTinCuaHang.IsVisible = false;
        KhungTongQuan.IsVisible = true;
        NapTongQuan();
    }

    private void OnChonTabTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is string p && int.TryParse(p, out var i)) ChonTab(i);
    }

    private void ChonTab(int i)
    {
        var tabs = new[] { Tab0, Tab1, Tab2, Tab3 };
        var chips = new[] { ChipTab0, ChipTab1, ChipTab2, ChipTab3 };
        for (int k = 0; k < tabs.Length; k++)
        {
            tabs[k].IsVisible = k == i;
            chips[k].BackgroundColor = Color.FromArgb(k == i ? "#5B3FD9" : "#EEEBFF");
            if (chips[k].Content is Label l) l.TextColor = Color.FromArgb(k == i ? "#FFFFFF" : "#4A2FB5");
        }
    }

    private async void OnMoTrangTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is string route) await Shell.Current.GoToAsync(route);
    }

    private async void OnDangXuatClicked(object? sender, EventArgs e)
    {
        try
        {
            if (!await DisplayAlert("Đăng xuất", "Bạn có chắc muốn đăng xuất khỏi gian hàng?", "Đăng xuất", "Hủy")) return;
            Models.MockData.GianHangHienTai = new Models.GianHang();
            Services.NhatKyService.Ghi("GianHang", Models.MockData.GianHangHienTai.Email, "Đăng xuất", Models.MockData.GianHangHienTai.TenGianHang, Services.NhatKyService.ThietBi());
            Services.Phien.DangXuat();
            await Shell.Current.GoToAsync("//dang-nhap");
        }
        catch (Exception ex) { await Services.DangXuatHelper.LoiAsync(ex); }
    }

    private void NapHoSo()
    {
        NapTongQuan();
        var gh = Models.MockData.GianHangHienTai;

        LblAnhHienTai.Text = gh.HinhAnh;
        HienAnh(gh);
        EntryHinhAnh.Text = gh.HinhAnh;
        HienAnhBia(gh);
        EntryTenGianHang.Text = gh.TenGianHang;
        EntryDiaChi.Text = gh.DiaChi;
        EntrySdt.Text = gh.SoDienThoai;
        EntryEmail.Text = gh.Email;
        EntryThoiGianGiao.Text = gh.ThoiGianGiaoPhut.ToString();
        EditorMoTa.Text = gh.MoTa;
        SwitchDangMoCua.IsToggled = gh.DangMoCua;
        SwitchDangNhanDon.IsToggled = gh.DangNhanDon;
        TimeMoCua.Time = TimeSpan.TryParse(gh.GioMoCua, out var mo) ? mo : TimeSpan.Zero;
        TimeDongCua.Time = TimeSpan.TryParse(gh.GioDongCua, out var dong) ? dong : new TimeSpan(23, 59, 0);

        EntryGpkd.Text = gh.SoGiayPhepKinhDoanh;
        EntryMst.Text = gh.MaSoThue;
        EntryCccd.Text = gh.CccdChuQuan;
        EntryAttp.Text = gh.SoGiayChungNhanAttp;
        HienGiayPhep(gh);

        LblThanhCong.IsVisible = false;
        LblLoi.IsVisible = false;
    }

    private void HienGiayPhep(Models.GianHang gh)
    {
        ImgGiayPhep.Source = gh.CoAnhGiayPhep ? ImageSource.FromFile(gh.AnhGiayPhepPath) : null;
        LblChuaCoGiayPhep.IsVisible = !gh.CoAnhGiayPhep;
    }

    private void HienAnhBia(Models.GianHang gh)
    {
        var url = gh.AnhBiaUrlDayDu;
        ImgAnhBia.Source = string.IsNullOrEmpty(url) ? null : ImageSource.FromUri(new Uri(url));
        LblChuaCoAnhBia.IsVisible = string.IsNullOrEmpty(url);
    }

    /// <summary>Tải ảnh bìa lên máy chủ (api/upload/gianhang) rồi lưu đường dẫn vào hồ sơ quán; cần kết nối.</summary>
    private async void OnTaiAnhBiaClicked(object sender, EventArgs e)
    {
        LblLoi.IsVisible = false;
        try
        {
            if (!DuLieuService.DangOnline) { HienLoi("Cần kết nối máy chủ để tải ảnh bìa."); return; }
            var gh = Models.MockData.GianHangHienTai;
            var path = await AnhService.ChonVaLuuAsync("bia_" + gh.Id, "Chọn ảnh bìa trang quán");
            if (path is null) return;
            var up = await ApiClient.PostFileAsync<UploadAnhDto>("api/upload/gianhang", path);
            if (!up.ThanhCong || string.IsNullOrWhiteSpace(up.DuLieu?.ImageUrl))
            { HienLoi(string.IsNullOrWhiteSpace(up.ThongDiep) ? "Không tải được ảnh bìa." : up.ThongDiep); return; }
            var url = up.DuLieu!.ImageUrl!;
            if (!await DuLieuService.GhiAsync("PUT", "api/mobile/gian-hang/anh-bia", new { url })) return;   // server chưa nhận: không đổi
            gh.AnhBia = url;
            VendorLocalStore.Luu();
            HienAnhBia(gh);
            LblThanhCong.IsVisible = true;
        }
        catch (Exception ex) { HienLoi("Không tải được ảnh bìa: " + ex.Message); }
    }

    private async void OnTaiGiayPhepClicked(object sender, EventArgs e)
    {
        try
        {
            var gh = Models.MockData.GianHangHienTai;
            var path = await AnhService.ChonVaLuuAsync("gp_" + gh.Id, "Chọn ảnh giấy phép kinh doanh");
            if (path is null) return;
            if (gh.CoAnhGiayPhep) { try { File.Delete(gh.AnhGiayPhepPath); } catch { } }
            gh.AnhGiayPhepPath = path;
            VendorLocalStore.Luu();
            NhatKyService.Ghi("GianHang", gh.Email, "Cập nhật ảnh giấy phép", gh.TenGianHang);
            HienGiayPhep(gh);
            LblThanhCong.IsVisible = true;
        }
        catch (Exception ex) { HienLoi("Không tải được ảnh: " + ex.Message); }
    }

    private async void OnLuuClicked(object sender, EventArgs e)
    {
        LblLoi.IsVisible = false;
        LblThanhCong.IsVisible = false;

        if (string.IsNullOrWhiteSpace(EntryTenGianHang.Text))
        {
            HienLoi("Vui lòng nhập tên gian hàng");
            return;
        }
        if (string.IsNullOrWhiteSpace(EntryDiaChi.Text))
        {
            HienLoi("Vui lòng nhập địa chỉ cửa hàng");
            return;
        }
        if (string.IsNullOrWhiteSpace(EntrySdt.Text))
        {
            HienLoi("Vui lòng nhập số điện thoại");
            return;
        }
        if (!int.TryParse(EntryThoiGianGiao.Text, out var thoiGianGiao) || thoiGianGiao <= 0)
        {
            HienLoi("Thời gian giao hàng không hợp lệ");
            return;
        }

        var gpkd = EntryGpkd.Text?.Trim() ?? "";
        var mst = new string((EntryMst.Text ?? "").Where(char.IsDigit).ToArray());
        var cccd = new string((EntryCccd.Text ?? "").Where(char.IsDigit).ToArray());
        if (gpkd.Length < 6) { HienLoi("Vui lòng nhập số giấy phép kinh doanh (ít nhất 6 ký tự)"); return; }
        if (mst.Length > 0 && mst.Length != 10 && mst.Length != 13) { HienLoi("Mã số thuế phải có 10 hoặc 13 chữ số"); return; }
        if (cccd.Length != 9 && cccd.Length != 12) { HienLoi("CCCD/CMND chủ quán phải có 9 hoặc 12 chữ số"); return; }

        LoadingIndicator.IsVisible = true;
        LoadingIndicator.IsRunning = true;
        BtnLuu.IsEnabled = false;

        try
        {
            var gh = Models.MockData.GianHangHienTai;
            gh.HinhAnh = string.IsNullOrWhiteSpace(EntryHinhAnh.Text) ? gh.HinhAnh : EntryHinhAnh.Text.Trim();
            gh.TenGianHang = EntryTenGianHang.Text.Trim();
            gh.DiaChi = EntryDiaChi.Text.Trim();
            gh.SoDienThoai = EntrySdt.Text.Trim();
            gh.ThoiGianGiaoPhut = thoiGianGiao;
            gh.MoTa = EditorMoTa.Text?.Trim() ?? "";
            gh.DangMoCua = SwitchDangMoCua.IsToggled;
            gh.DangNhanDon = SwitchDangNhanDon.IsToggled;
            gh.GioMoCua = TimeMoCua.Time.ToString(@"hh\:mm");
            gh.GioDongCua = TimeDongCua.Time.ToString(@"hh\:mm");
            var attp = EntryAttp.Text?.Trim() ?? "";
            bool giayToLoi = false;
            bool doiGiayTo = gh.SoGiayPhepKinhDoanh != gpkd || gh.MaSoThue != mst || gh.CccdChuQuan != cccd || gh.SoGiayChungNhanAttp != attp;
            gh.SoGiayPhepKinhDoanh = gpkd; gh.MaSoThue = mst; gh.CccdChuQuan = cccd; gh.SoGiayChungNhanAttp = attp;
            if (doiGiayTo)
            {
                NhatKyService.Ghi("GianHang", gh.Email, "Cập nhật giấy tờ pháp lý", gh.TenGianHang);
                // Web lưu GPKD + ATTP (CCCD / mã số thuế / ảnh giấy phép hiện chỉ lưu trên máy)
                if (await DuLieuService.GhiTrangThaiAsync("PUT", "api/mobile/gian-hang/giay-to", new { giayPhepKinhDoanh = gpkd, giayChungNhanAttp = attp }) == DuLieuService.KetQuaGhi.ThatBai)
                    giayToLoi = true;
            }
            VendorLocalStore.Luu();
            var kqGio = await DuLieuService.GhiTrangThaiAsync("PUT", $"api/mobile/gian-hang/{gh.Id}/gio-hoat-dong",
                new { gioMoCua = gh.GioMoCua, gioDongCua = gh.GioDongCua, dangNhanDon = gh.DangNhanDon, dangMoCua = gh.DangMoCua });

            LblAnhHienTai.Text = gh.HinhAnh;
            if (giayToLoi || kqGio == DuLieuService.KetQuaGhi.ThatBai) { LblThanhCong.IsVisible = false; return; }   // máy chủ đã báo lỗi
            LblThanhCong.Text = kqGio == DuLieuService.KetQuaGhi.DaDongBo
                ? "✔ Đã lưu thay đổi"
                : "✔ Đã lưu trên máy — chưa gửi lên máy chủ (ngoại tuyến)";
            LblThanhCong.IsVisible = true;
        }
        finally
        {
            LoadingIndicator.IsVisible = false;
            LoadingIndicator.IsRunning = false;
            BtnLuu.IsEnabled = true;
        }
    }

    private void HienAnh(Models.GianHang gh)
    {
        ImgAnhCuaHang.Source = gh.CoAnh ? ImageSource.FromFile(gh.AnhHienThi) : null;
        LblChuaCoAnh.IsVisible = !gh.CoAnh;
    }

    private async void OnTaiAnhClicked(object sender, EventArgs e)
    {
        try
        {
            var gh = Models.MockData.GianHangHienTai;
            var path = await AnhService.ChonVaLuuAsync(gh.Id);
            if (path is null) return;

            if (gh.CoAnh) { try { File.Delete(gh.AnhPath); } catch { } }   // xóa ảnh cũ
            gh.AnhPath = path;
            VendorLocalStore.Luu();
            HienAnh(gh);
            LblThanhCong.IsVisible = true;
        }
        catch (Exception ex)
        {
            HienLoi("Không tải được ảnh: " + ex.Message);
        }
    }

    private void HienLoi(string thongDiep)
    {
        LblLoi.Text = thongDiep;
        LblLoi.IsVisible = true;
    }

    private async void OnDoiMatKhauClicked(object sender, EventArgs e)
        => await Shell.Current.GoToAsync($"{nameof(DoiMatKhauPage)}?VaiTro=GianHang");
    /// <summary>Mở bản đồ để chọn / định vị địa chỉ cửa hàng; chọn xong địa chỉ được điền vào ô (máy chủ tự định vị toạ độ từ địa chỉ).</summary>
    private async void OnChonBanDoClicked(object sender, EventArgs e)
        => await BanDoPage.MoAsync(EntryDiaChi.Text ?? "", chonDiaChi: true, khiChon: dc => EntryDiaChi.Text = dc);
}
