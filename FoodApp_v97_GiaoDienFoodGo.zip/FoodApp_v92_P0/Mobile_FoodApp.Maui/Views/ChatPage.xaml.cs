using System.Collections.ObjectModel;
using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Một dòng tin nhắn đã tính sẵn màu và căn lề (bên phải = của tôi).</summary>
public class TinNhanHienThi
{
    public string NoiDung { get; set; } = "";
    public string Gio { get; set; } = "";
    public bool LaCuaToi { get; set; }
    public string TrangThai { get; set; } = "";            // v64: "⏳ Chưa gửi…" / "⚠ Không gửi được: …" (rỗng = đã gửi)
    public bool CoTrangThai => TrangThai.Length > 0;
    public LayoutOptions CanLe => LaCuaToi ? LayoutOptions.End : LayoutOptions.Start;
    public Color Nen { get; set; } = Colors.White;
    public Color Chu { get; set; } = Colors.Black;
    public Color ChuPhu { get; set; } = Colors.Gray;
}

[QueryProperty(nameof(DonHangId), "DonHangId")]
[QueryProperty(nameof(VaiTro), "VaiTro")]
[QueryProperty(nameof(TenDoiPhuong), "TenDoiPhuong")]
[QueryProperty(nameof(Sdt), "Sdt")]
public partial class ChatPage : ContentPage
{
    public string DonHangId { get; set; } = "";
    public string VaiTro { get; set; } = "KhachHang";        // vai trò của người đang dùng máy: KhachHang | TaiXe | GianHang (v66: chat 3 bên theo đơn)
    public string TenDoiPhuong { get; set; } = "";
    public string Sdt { get; set; } = "";

    private readonly ObservableCollection<TinNhanHienThi> _ds = new();
    private IDispatcherTimer? _timer;
    private string _dauDaVe = "";     // chữ ký danh sách (số tin + trạng thái gửi) để biết khi nào cần vẽ lại

    public ChatPage()
    {
        InitializeComponent();
        DsTinNhan.ItemsSource = _ds;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        bool laTaiXe = VaiTro == "TaiXe";
        bool laQuan = VaiTro == "GianHang";
        LblIcon.Text = laTaiXe || laQuan ? "👤" : (TenDoiPhuong.StartsWith("🏪") ? "🏪" : "🛵");
        LblTen.Text = string.IsNullOrWhiteSpace(TenDoiPhuong) ? (laTaiXe || laQuan ? "Khách hàng" : "Tài xế") : (TenDoiPhuong.StartsWith("🏪", StringComparison.Ordinal) ? TenDoiPhuong.Substring("🏪".Length) : TenDoiPhuong).TrimStart();   // bỏ biểu tượng 🏪 đứng đầu (emoji là 2 ký tự UTF-16 nên không dùng được trong '...')
        LblPhu.Text = $"Đơn #{DonHangId}";

        // Câu trả lời nhanh cho tài xế
        HangNhanh.Children.Clear();
        KhungNhanh.IsVisible = laTaiXe;
        if (laTaiXe)
            foreach (var cau in new[] { "Mình đang đến lấy hàng", "Mình sắp tới nơi", "Bạn có ở nhà không?", "Mình đã đến, bạn ra nhận giúp nhé" })
            {
                var nut = new Button { Text = cau, FontSize = 12, CornerRadius = 16, HeightRequest = 34, Padding = new Thickness(12, 0),
                                       BackgroundColor = (Color)Resources["PrimarySoft"], TextColor = (Color)Resources["Primary"] };
                nut.Clicked += async (_, _) => await GuiAsync(cau);
                HangNhanh.Children.Add(nut);
            }

        VeLai();
        _timer = Dispatcher.CreateTimer();
        _timer.Interval = TimeSpan.FromSeconds(2.5);
        _timer.Tick += async (_, _) =>
        {
            await ChatService.DongBoAsync(DonHangId);   // lấy tin mới từ server (nếu đang online)
            VeLai();
        };
        _timer.Start();
        await ChatService.DongBoAsync(DonHangId);
        VeLai();
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        _timer?.Stop();
        _timer = null;
    }

    private Color Mau(string k) => (Color)Resources[k];
    private static bool Toi => Application.Current?.RequestedTheme == AppTheme.Dark;

    private void VeLai()
    {
        var tin = ChatService.Lay(DonHangId);
        var dau = tin.Count + ":" + string.Concat(tin.Select(t => t.TrangThaiGui switch { "DangCho" => 'c', "Loi" => 'l', _ => 'g' }));
        if (dau == _dauDaVe) return;             // không có gì mới thì không vẽ lại
        _dauDaVe = dau;

        _ds.Clear();
        foreach (var t in tin)
        {
            bool cuaToi = t.NguoiGui == VaiTro;
            _ds.Add(new TinNhanHienThi
            {
                NoiDung = t.NoiDung,
                Gio = (cuaToi ? "" : NhanVaiTro(t.NguoiGui, t.TenNguoiGui) + " · ") + (t.ThoiGian.Date == DateTime.Today ? t.ThoiGian.ToString("HH:mm") : t.ThoiGian.ToString("dd/MM HH:mm")),
                LaCuaToi = cuaToi,
                TrangThai = !cuaToi ? "" : t.TrangThaiGui == "DangCho" ? "⏳ Chưa gửi — sẽ tự gửi khi có mạng" : t.TrangThaiGui == "Loi" ? "⚠ Không gửi được: " + t.LoiGui : "",
                Nen = cuaToi ? Mau("Primary") : (Toi ? Mau("CardColorDark") : Mau("PrimarySoft")),
                Chu = cuaToi ? Colors.White : (Toi ? Mau("TextOnDark") : Mau("TextDark")),
                ChuPhu = cuaToi ? Color.FromArgb("#CCFFFFFF") : (Toi ? Mau("TextGreyDark") : Mau("TextGrey")),
            });
        }
        if (_ds.Count > 0)
            DsTinNhan.ScrollTo(_ds.Count - 1, position: ScrollToPosition.End, animate: false);
    }

    private static string NhanVaiTro(string vaiTro, string ten) => vaiTro switch
    {
        "GianHang" => "🏪 " + (string.IsNullOrWhiteSpace(ten) ? "Quán" : ten),
        "TaiXe" => "🛵 " + (string.IsNullOrWhiteSpace(ten) ? "Tài xế" : ten),
        _ => "👤 " + (string.IsNullOrWhiteSpace(ten) ? "Khách" : ten),
    };

    private async Task GuiAsync(string noiDung)
    {
        if (string.IsNullOrWhiteSpace(noiDung)) return;
        var ten = VaiTro == "TaiXe" ? MockData.TaiXeHienTai.HoTen
            : VaiTro == "GianHang" ? (string.IsNullOrWhiteSpace(MockData.GianHangHienTai.TenGianHang) ? "Gian hàng" : MockData.GianHangHienTai.TenGianHang)
            : (Phien.Khach?.HoTen ?? "Khách hàng");
        await ChatService.GuiAsync(DonHangId, VaiTro, ten, noiDung);
        VeLai();
    }

    private async void OnGuiClicked(object? sender, EventArgs e)
    {
        var nd = EntryNoiDung.Text;
        EntryNoiDung.Text = "";
        await GuiAsync(nd ?? "");
        EntryNoiDung.Focus();
    }

    private async void OnGoiTapped(object? sender, EventArgs e) => await LienLac.GoiAsync(Sdt);

    /// <summary>Mở trang trò chuyện của một đơn hàng.</summary>
    public static Task MoAsync(string donId, string vaiTro, string tenDoiPhuong, string sdt) =>
        Shell.Current.GoToAsync(nameof(ChatPage), new Dictionary<string, object>
        {
            { "DonHangId", donId }, { "VaiTro", vaiTro }, { "TenDoiPhuong", tenDoiPhuong }, { "Sdt", sdt },
        });
}
