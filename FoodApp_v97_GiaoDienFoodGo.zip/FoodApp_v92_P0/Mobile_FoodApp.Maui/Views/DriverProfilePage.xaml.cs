using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

public partial class DriverProfilePage : ContentPage
{
    private static readonly string[] LoaiXe = { "Xe máy", "Xe tay ga", "Xe điện", "Ô tô" };

    // Khu vực chạy thường xuyên (TP.HCM): tài xế chọn nhiều quận; đơn ở quận đó được ưu tiên gửi cho họ.
    private static readonly string[] KhuVuc =
    {
        "Quận 1", "Quận 3", "Quận 4", "Quận 5", "Quận 6", "Quận 7", "Quận 8", "Quận 10", "Quận 11", "Quận 12",
        "Bình Thạnh", "Gò Vấp", "Phú Nhuận", "Tân Bình", "Tân Phú", "Bình Tân", "TP Thủ Đức",
        "Hóc Môn", "Củ Chi", "Nhà Bè", "Bình Chánh", "Cần Giờ",
    };
    private const int ToiDaKhuVuc = 10;
    private readonly HashSet<string> _kvChon = new(StringComparer.OrdinalIgnoreCase);
    private readonly List<string> _kvKhac = new();   // cụm quản trị nhập tay không nằm trong danh sách: giữ nguyên khi lưu

    private void DatKhuVuc(string? chuoi)
    {
        _kvChon.Clear(); _kvKhac.Clear();
        foreach (var tok in (chuoi ?? "").Split(new[] { ',', ';', '/', '|' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            var m = System.Text.RegularExpressions.Regex.Match(tok, @"^(?:quận|quan|q|district)\s*\.?\s*0?(\d{1,2})$", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
            var ten = m.Success ? "Quận " + m.Groups[1].Value : tok;
            var kv = KhuVuc.FirstOrDefault(x => string.Equals(x, ten, StringComparison.OrdinalIgnoreCase));
            if (kv != null) _kvChon.Add(kv); else if (!_kvKhac.Contains(tok, StringComparer.OrdinalIgnoreCase)) _kvKhac.Add(tok);
        }
        VeKhuVuc();
    }

    private string KhuVucChuoi() => string.Join(", ", KhuVuc.Where(_kvChon.Contains).Concat(_kvKhac));

    private void VeKhuVuc()
    {
        KvChips.Children.Clear();
        var chinh = DriverPalette.Get("Primary");
        var nhat = DriverPalette.Get("PrimarySoft");
        foreach (var kv in KhuVuc)
        {
            var bat = _kvChon.Contains(kv);
            var nut = new Button
            {
                Text = (bat ? "✓ " : "") + kv, FontSize = 12.5, HeightRequest = 34, Padding = new Thickness(12, 0), CornerRadius = 17,
                Margin = new Thickness(0, 0, 6, 6), BackgroundColor = bat ? chinh : nhat, TextColor = bat ? Colors.White : chinh,
            };
            nut.Clicked += (_, _) =>
            {
                if (!_kvChon.Remove(kv))
                {
                    if (_kvChon.Count >= ToiDaKhuVuc) { HienLoi($"Chọn tối đa {ToiDaKhuVuc} khu vực."); return; }
                    _kvChon.Add(kv);
                }
                LblLoi.IsVisible = false;
                VeKhuVuc();
            };
            KvChips.Children.Add(nut);
        }
        var ds = KhuVucChuoi();
        LblKhuVuc.Text = ds.Length == 0 ? "Chưa chọn — bạn sẽ nhận đơn ở mọi khu vực." : "Ưu tiên đơn ở: " + ds;
    }

    public DriverProfilePage()
    {
        InitializeComponent();
        PickerLoaiXe.ItemsSource = LoaiXe;
        BtnChup.IsVisible = MediaPicker.Default.IsCaptureSupported;   // máy không có camera thì ẩn nút chụp
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        var t = MockData.TaiXeHienTai;
        EntryHoTen.Text = t.HoTen;
        EntrySdt.Text = t.SoDienThoai;
        EntryBienSo.Text = t.BienSoXe;
        DatKhuVuc(t.KhuVucHoatDong);
        EntryNganHang.Text = t.NganHang; EntrySoTk.Text = t.SoTaiKhoan; EntryChuTk.Text = t.ChuTaiKhoan;   // v91
        CapNhatGiayToPhu();
        EntryEmoji.Text = t.Anh;
        PickerLoaiXe.SelectedItem = LoaiXe.Contains(t.LoaiXe) ? t.LoaiXe : LoaiXe[0];
        HienAnh();
        CapNhatHoatDong();
        await TaiTuMayChuAsync();
    }

    private void CapNhatHoatDong()
    {
        var t = MockData.TaiXeHienTai;
        LblTrangThaiHoatDong.Text = !t.DangOnline ? "⚫ Offline — không nhận đơn"
            : t.DangHoatDong ? "🟢 Online · Sẵn sàng nhận đơn" : "🟡 Online · Tạm không nhận đơn";
    }

    private async void OnMoTrangChuTapped(object? sender, EventArgs e)
    {
        var nav = Shell.Current.Navigation;
        if (nav.NavigationStack.Any(p => p is DriverHomePage))
        {
            while (nav.NavigationStack.Count > 1 && nav.NavigationStack[^1] is { } top && top is not DriverHomePage)
                await nav.PopAsync(false);
        }
        else await Shell.Current.GoToAsync(nameof(DriverHomePage));
    }

    /// <summary>Lấy trạng thái duyệt, lý do từ chối/yêu cầu bổ sung và giấy tờ từ máy chủ (khi có kết nối).</summary>
    private async Task TaiTuMayChuAsync()
    {
        if (!DuLieuService.DangOnline) return;
        var r = await ApiClient.GetAsync<HoSoMayChuDto>("api/mobile/tai-xe/ho-so");
        if (!r.ThanhCong || r.DuLieu is null) return;
        var h = r.DuLieu;
        EntryCccd.Text = h.SoCccd;
        EntryGplx.Text = h.SoGplx;
        if (h.KhuVucHoatDong != null) { DatKhuVuc(h.KhuVucHoatDong); MockData.TaiXeHienTai.KhuVucHoatDong = KhuVucChuoi(); }
        LblAnhGplx.Text = string.IsNullOrEmpty(h.AnhGplx) ? "Chưa có ảnh GPLX" : "✓ Đã có ảnh GPLX";
        var mucGiayTo = new[]
        {
            (!string.IsNullOrWhiteSpace(h.SoCccd), "Số CCCD"),
            (!string.IsNullOrWhiteSpace(h.SoGplx), "Số GPLX"),
            (!string.IsNullOrEmpty(h.AnhGplx), "Ảnh GPLX"),
            (!string.IsNullOrWhiteSpace(EntryBienSo.Text), "Biển số xe"),
        };
        LblGiayTo.Text = $"Hồ sơ giấy tờ: {mucGiayTo.Count(x => x.Item1)}/{mucGiayTo.Length} mục — " +
                         string.Join("  ", mucGiayTo.Select(x => (x.Item1 ? "✓ " : "✗ ") + x.Item2));

        var (nhan, mau) = h.TrangThaiDuyet switch
        {
            "TuChoi" => ("Bị từ chối", "Danger"),
            "ChoDuyet" => ("Chờ duyệt", "Warning"),
            _ => ("Đã được duyệt", "Success"),
        };
        LblTrangThaiDuyet.Text = nhan;
        LblTrangThaiDuyet.TextColor = DriverPalette.Get(mau);
        var ghi = new List<string>();
        if (h.TrangThaiDuyet == "TuChoi")
            ghi.Add("Lý do từ chối: " + (string.IsNullOrWhiteSpace(h.LyDoTuChoi) ? "hồ sơ không đạt yêu cầu" : h.LyDoTuChoi));
        if (!string.IsNullOrWhiteSpace(h.YeuCauBoSung)) ghi.Add("Quản trị yêu cầu bổ sung: " + h.YeuCauBoSung);
        if (h.TrangThaiDuyet != "DaDuyet") ghi.Add("Tài khoản chưa được duyệt sẽ không nhận được đơn.");
        LblLyDoDuyet.Text = string.Join("\n", ghi);
        LblLyDoDuyet.IsVisible = ghi.Count > 0;
        FrameTrangThai.IsVisible = true;
    }

    private async void OnAnhGplxClicked(object? sender, EventArgs e)
    {
        LblLoi.IsVisible = false;
        try
        {
            if (!DuLieuService.DangOnline) { HienLoi("Cần kết nối máy chủ để tải ảnh GPLX."); return; }
            var path = await AnhService.ChonVaLuuAsync("gplx_" + MockData.TaiXeHienTai.Id, "Chọn ảnh GPLX", chup: false);
            if (path is null) return;
            // GPLX là giấy tờ cá nhân: tải lên kho RIÊNG TƯ của máy chủ (không công khai), chỉ quản trị và chính bạn xem được.
            var up = await ApiClient.PostFileAsync<UploadAnhDto>("api/upload/giayto-taixe", path);
            if (!up.ThanhCong || string.IsNullOrWhiteSpace(up.DuLieu?.ImageUrl)) { HienLoi(string.IsNullOrWhiteSpace(up.ThongDiep) ? "Không tải được ảnh GPLX." : up.ThongDiep); return; }
            if (await DuLieuService.GhiAsync("PUT", "api/mobile/tai-xe/ho-so", new { anhGplx = up.DuLieu!.ImageUrl }))
            {
                LblAnhGplx.Text = "✓ Đã tải ảnh GPLX — quản trị sẽ xem lại";
                LblThanhCong.Text = "✓ Đã cập nhật ảnh GPLX";
                LblThanhCong.IsVisible = true;
            }
        }
        catch (PermissionException) { HienLoi("Ứng dụng chưa được cấp quyền ảnh. Hãy cấp quyền trong Cài đặt rồi thử lại."); }
        catch (Exception ex) { HienLoi("Không tải được ảnh: " + ex.Message); }
    }

    private void HienAnh()
    {
        var t = MockData.TaiXeHienTai;
        ImgAnh.Source = t.CoAnh ? ImageSource.FromFile(t.AnhPath) : null;
        ImgAnh.IsVisible = t.CoAnh;
        LblAnh.Text = t.Anh;
        LblAnh.IsVisible = !t.CoAnh;
        LblTenDau.Text = string.IsNullOrWhiteSpace(t.HoTen) ? "Tài xế" : t.HoTen;
        BtnXoaAnh.IsVisible = t.CoAnh;
    }

    private async void OnChonAnhClicked(object sender, EventArgs e) => await DatAnhAsync(chup: false);
    private async void OnChupAnhClicked(object sender, EventArgs e) => await DatAnhAsync(chup: true);

    private async Task DatAnhAsync(bool chup)
    {
        LblLoi.IsVisible = false;
        try
        {
            var t = MockData.TaiXeHienTai;
            var path = await AnhService.ChonVaLuuAsync("taixe_" + t.Id, "Chọn ảnh đại diện", chup);
            if (path is null) return;                                          // người dùng hủy

            if (t.CoAnh) { try { File.Delete(t.AnhPath); } catch { } }         // xóa ảnh cũ cho đỡ tốn bộ nhớ
            t.AnhPath = path;
            TaiXeStore.Luu();
            HienAnh();
            bool dongBoAnh = false;
            if (DuLieuService.DangOnline)                                      // đồng bộ ảnh đại diện lên máy chủ
            {
                var up = await ApiClient.PostFileAsync<UploadAnhDto>("api/upload/taixe", path);
                if (up.ThanhCong && !string.IsNullOrWhiteSpace(up.DuLieu?.ImageUrl))
                    dongBoAnh = await DuLieuService.GhiAsync("PUT", "api/mobile/tai-xe/ho-so", new { anhDaiDien = up.DuLieu!.ImageUrl });
            }
            LblThanhCong.Text = dongBoAnh ? "✓ Đã đổi ảnh đại diện" : "✓ Đã đổi ảnh trên máy — chưa gửi lên máy chủ";
            LblThanhCong.IsVisible = true;
        }
        catch (PermissionException)
        {
            HienLoi("Ứng dụng chưa được cấp quyền camera/ảnh. Hãy cấp quyền trong Cài đặt rồi thử lại.");
        }
        catch (Exception ex)
        {
            HienLoi("Không đặt được ảnh: " + ex.Message);
        }
    }

    private async void OnXoaAnhClicked(object sender, EventArgs e)
    {
        var t = MockData.TaiXeHienTai;
        if (!t.CoAnh) return;
        if (!await DisplayAlert("Xóa ảnh", "Xóa ảnh đại diện hiện tại?", "Xóa", "Hủy")) return;
        try { File.Delete(t.AnhPath); } catch { }
        t.AnhPath = "";
        TaiXeStore.Luu();
        HienAnh();
        LblThanhCong.Text = "✓ Đã xóa ảnh";
        LblThanhCong.IsVisible = true;
    }

    private async void OnLuuClicked(object sender, EventArgs e)
    {
        LblLoi.IsVisible = false;
        LblThanhCong.IsVisible = false;

        var ten = EntryHoTen.Text?.Trim() ?? "";
        var sdt = EntrySdt.Text?.Trim() ?? "";
        if (ten.Length < 2) { HienLoi("Vui lòng nhập họ tên"); return; }
        var soChu = sdt.Count(char.IsDigit);
        if (sdt.Length > 0 && (soChu < 9 || soChu > 11)) { HienLoi("Số điện thoại phải có 9–11 chữ số"); return; }

        var trung = TaiXeStore.TimTheoSdt(sdt);
        if (trung is not null && !ReferenceEquals(trung, MockData.TaiXeHienTai)) { HienLoi("Số điện thoại này đã thuộc về tài xế khác"); return; }

        var t = MockData.TaiXeHienTai;
        t.HoTen = ten;
        t.SoDienThoai = sdt;
        t.BienSoXe = EntryBienSo.Text?.Trim().ToUpperInvariant() ?? "";
        t.LoaiXe = PickerLoaiXe.SelectedItem as string ?? LoaiXe[0];
        t.KhuVucHoatDong = KhuVucChuoi();
        t.Anh = string.IsNullOrWhiteSpace(EntryEmoji.Text) ? "🛵" : EntryEmoji.Text.Trim();
        // v91: tài khoản ngân hàng nhận tiền — kiểm tra cơ bản rồi lưu trên máy
        var nh = EntryNganHang.Text?.Trim() ?? ""; var stk = new string((EntrySoTk.Text ?? "").Where(char.IsDigit).ToArray()); var ctk = EntryChuTk.Text?.Trim() ?? "";
        var coNhapNh = nh.Length > 0 || stk.Length > 0 || ctk.Length > 0;
        if (coNhapNh && (nh.Length < 2 || stk.Length < 6 || stk.Length > 20 || ctk.Length < 3))
        { HienLoi("Tài khoản ngân hàng: nhập đủ tên ngân hàng, số tài khoản (6–20 số) và tên chủ tài khoản."); return; }
        t.NganHang = nh; t.SoTaiKhoan = stk; t.ChuTaiKhoan = ctk.ToUpperInvariant();
        TaiXeStore.Luu();
        var kqGhi = await DuLieuService.GhiTrangThaiAsync("PUT", "api/mobile/tai-xe/ho-so",
            new { hoTen = t.HoTen, soDienThoai = t.SoDienThoai, bienSoXe = t.BienSoXe, loaiXe = t.LoaiXe,
                  soCccd = EntryCccd.Text?.Trim(), soGplx = EntryGplx.Text?.Trim(), khuVucHoatDong = t.KhuVucHoatDong });

        HienAnh();
        if (kqGhi == DuLieuService.KetQuaGhi.ThatBai) { LblThanhCong.IsVisible = false; return; }   // máy chủ đã báo lỗi, không hiện "đã lưu"
        LblThanhCong.Text = kqGhi == DuLieuService.KetQuaGhi.DaDongBo
            ? "✓ Đã lưu hồ sơ"
            : "✓ Đã lưu trên máy — chưa gửi lên máy chủ (ngoại tuyến)";
        LblThanhCong.IsVisible = true;
    }

    private async void OnDoiMatKhauClicked(object sender, EventArgs e)
        => await Shell.Current.GoToAsync($"{nameof(DoiMatKhauPage)}?VaiTro=TaiXe");


    private async void OnThongBaoClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverNotificationsPage));
    private async void OnDanhGiaClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverRatingPage));
    private async void OnHuongDanClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverHuongDanPage));
    private async void OnTrangThaiLamViecClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverTrangThaiPage));
    private async void OnThuongClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverThuongPage));
    private async void OnSuCoClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverSuCoPage));
    private async void OnThuNhapClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverEarningsPage));

    private async void OnDangXuatClicked(object sender, EventArgs e)
    {
        try
        {
            bool xacNhan = await DisplayAlert("Đăng xuất", "Bạn có chắc muốn đăng xuất?", "Đăng xuất", "Hủy");
            if (!xacNhan) return;

            ViTriTaiXeService.Dung();
            var tx = MockData.TaiXeHienTai;
            tx.DangOnline = false;
            TaiXeStore.Luu();
            NhatKyService.Ghi("TaiXe", tx.SoDienThoai, "Đăng xuất", chiTiet: NhatKyService.ThietBi());
            if (DuLieuService.DangOnline)      // báo Offline cho Web khi còn token
                await ApiClient.PutAsync<object>("api/mobile/tai-xe/trang-thai", new { trangThai = "NgoaiTuyen" });
            ApiClient.Token = null;
            await Shell.Current.GoToAsync("//dang-nhap");
        }
        catch (Exception ex) { await Services.DangXuatHelper.LoiAsync(ex); }
    }

    private void HienLoi(string t) { LblLoi.Text = t; LblLoi.IsVisible = true; }

    // ---------------- v91: giấy tờ bổ sung (ảnh lưu trên máy)
    private static string DuongDan(TaiXe t, string loai) => loai switch
    {
        "cccd-truoc" => t.AnhCccdTruocPath, "cccd-sau" => t.AnhCccdSauPath, "ca-vet" => t.AnhCaVetPath, _ => t.AnhBaoHiemPath,
    };

    private void CapNhatGiayToPhu()
    {
        var t = MockData.TaiXeHienTai;
        string Co(string loai, string ten) => File.Exists(DuongDan(t, loai)) ? $"✓ {ten}" : $"○ {ten}";
        LblGiayToPhu.Text = string.Join("   ", Co("cccd-truoc", "CCCD trước"), Co("cccd-sau", "CCCD sau"), Co("ca-vet", "Đăng ký xe"), Co("bao-hiem", "Bảo hiểm"));
    }

    private async void OnGiayToPhuClicked(object? sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: string loai }) return;
        LblLoi.IsVisible = false;
        try
        {
            var c = await DisplayActionSheet("Ảnh giấy tờ", "Hủy", null, "Chọn từ thư viện", "Chụp ảnh");
            if (c is null or "Hủy") return;
            var t = MockData.TaiXeHienTai;
            var path = await AnhService.ChonVaLuuAsync($"{loai}_{t.Id}", "Chọn ảnh giấy tờ", chup: c == "Chụp ảnh");
            if (path is null) return;
            switch (loai)
            {
                case "cccd-truoc": t.AnhCccdTruocPath = path; break;
                case "cccd-sau": t.AnhCccdSauPath = path; break;
                case "ca-vet": t.AnhCaVetPath = path; break;
                default: t.AnhBaoHiemPath = path; break;
            }
            TaiXeStore.Luu();
            CapNhatGiayToPhu();
            LblThanhCong.Text = "✓ Đã lưu ảnh giấy tờ trên máy";
            LblThanhCong.IsVisible = true;
        }
        catch (PermissionException) { HienLoi("Ứng dụng chưa được cấp quyền ảnh/camera. Hãy cấp quyền trong Cài đặt rồi thử lại."); }
    }
}

public sealed class UploadAnhDto { public string? ImageUrl { get; set; } }

public sealed class HoSoMayChuDto
{
    public string? HoTen { get; set; }
    public string? SoCccd { get; set; }
    public string? SoGplx { get; set; }
    public string? AnhGplx { get; set; }
    public string? KhuVucHoatDong { get; set; }
    public string TrangThaiDuyet { get; set; } = "DaDuyet";
    public string? LyDoTuChoi { get; set; }
    public string? YeuCauBoSung { get; set; }
}
