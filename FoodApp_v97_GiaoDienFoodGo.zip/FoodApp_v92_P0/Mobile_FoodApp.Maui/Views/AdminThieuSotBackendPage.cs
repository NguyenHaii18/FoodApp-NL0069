namespace FoodApp.Maui.Views;

/// <summary>
/// Phần IX — Thiếu sót về Database và kiến trúc Backend (ưu tiên P1 – hoàn thiện nền tảng), STT 94–105.
/// Mỗi mục có: hiện trạng ghi nhận, kết quả đối chiếu với mã nguồn Web/ + Database/ (chỉ ghi điều ĐÃ xác minh) và ô đánh dấu đã khắc phục.
/// Chạm một dòng để đánh dấu đã xử lý. Trạng thái đánh dấu chỉ LƯU TRÊN THIẾT BỊ NÀY (Preferences).
/// </summary>
public sealed class AdminThieuSotBackendPage : AdminKyThuatTrang
{
    // Mức rà soát mã nguồn: 0 = chưa có, 1 = có một phần, 2 = đã có, 3 = chưa xác minh được trong mã
    private sealed record Muc(int Stt, string ThieuSot, string HienTrang, int Muc_, string RaSoat);

    private static readonly Muc[] Dong =
    {
        new(94, "Migration", "Chưa thấy hệ thống EF Migration hoàn chỉnh", 0,
            "Dự án không dùng EF Migrations (Services/KiemTraSchema.cs nêu rõ). Nâng cấp CSDL đang dựa vào script Database/FoodService_NangCap.sql chạy lại được, không có lịch sử phiên bản schema."),
        new(95, "Tự cập nhật schema", "Backend dùng EnsureCreated() và kiểm tra schema bổ sung thủ công", 1,
            "Program.cs gọi EnsureCreated() (chỉ tạo CSDL MỚI) rồi KiemTraSchema đối chiếu mô hình EF với CSDL thật: chỉ cảnh báo thiếu bảng/cột, không tự nâng cấp. Có tùy chọn Database:DungKhiLechSchema để dừng khởi động khi lệch."),
        new(96, "Đồng bộ cấu trúc DB", "Phải chạy các script SQL theo đúng thứ tự", 1,
            "Bản v93 đã gộp còn: Database → NangCap → DuLieuMau (+ BaoMat_VoHieuHoa, NghiemThu_SaoLuu) kèm HUONG_DAN_CHAY_SQL.txt. Vẫn phải chạy tay, chưa có công cụ ghi nhận script nào đã chạy."),
        new(97, "Khóa ngoại và ràng buộc", "Cần kiểm tra tính toàn vẹn giữa các bảng", 1,
            "Database.sql có khoảng 67 khai báo khóa ngoại/REFERENCES, 49 CHECK và nhiều chỉ mục UNIQUE (UX_DonHang_MaYeuCauDat, UX_DeNghi_*, UX_TinNhan_MaClient…). Chưa có công cụ tự quét dòng mồ côi trên CSDL đang chạy."),
        new(98, "Index", "Cần rà soát index cho đơn hàng, giao dịch, vị trí", 1,
            "Đã thấy: DonHang (khách / gian hàng / tài xế / chờ tài xế), ChiTietDonHang, GiaoDichThanhToan(MaDonHang, ThoiGian), LichSuViTriTaiXe(MaTaiXe, ThoiGian). Chưa thấy chỉ mục riêng cho bảng ThanhToan(MaDonHang) trong script SQL; chưa kiểm bằng kế hoạch thực thi trên dữ liệu lớn."),
        new(99, "Lịch sử dữ liệu", "Cần kiểm tra việc lưu snapshot giá và chiết khấu tại thời điểm giao dịch", 1,
            "Đã lưu theo đơn: ChiTietDonHang.DonGia (giá + phụ thu tùy chọn), tên tùy chọn, DonHang.PhiGiaoHang, TienGiam, TyLeTaiXe. CHƯA lưu tỷ lệ chiết khấu/phí nền tảng theo đơn: báo cáo đối soát tính theo GianHang.TyLeChietKhau hiện tại nên đổi tỷ lệ sẽ làm lệch đơn cũ."),
        new(100, "Tính nguyên tử", "Cần kiểm tra transaction khi tạo đơn và thanh toán", 3,
            "Không thấy BeginTransaction nào trong Web/. Mỗi lần SaveChanges của EF là một giao dịch, nhưng các bước tách nhiều lần lưu (giữ lượt khuyến mãi → tạo đơn → tạo thanh toán) chưa được bọc chung — cần rà từng luồng."),
        new(101, "Idempotency", "Cần thống nhất chống tạo trùng đơn, giao dịch và hoàn tiền", 1,
            "Đã có: đặt đơn (MaYeuCauDat + chỉ mục unique, app gửi 1 GUID mỗi giỏ), kết quả VNPay (VnPayXuLy ghi idempotent), tin nhắn (MaClient), đề nghị giao đơn (UX_DeNghi_*). Hoàn tiền chưa xác minh được cơ chế chống trùng; mỗi luồng tự làm, chưa có cơ chế chung."),
        new(102, "Worker", "Tác vụ nền đang chạy cùng tiến trình Web", 0,
            "Đúng: 3 BackgroundService đăng ký trong Program.cs — PhanPhoiNen, TuDongPhanCongNen, ThanhToanDoiSoatNen. Web khởi động lại / mở nhiều bản sao thì tác vụ nền cũng dừng / chạy trùng."),
        new(103, "Hàng đợi bền vững", "Cần bảo đảm job không mất khi máy chủ khởi động lại", 1,
            "Trạng thái phân phối đơn lưu trong CSDL (đề nghị giao đơn có hạn, nhật ký điều phối) nên tiếp tục được sau khi khởi động lại. Chưa có hàng đợi/outbox chung cho thông báo, hoàn tiền, đồng bộ."),
        new(104, "Retry", "Cần xử lý thử lại có giới hạn và tránh xử lý sự kiện hai lần", 1,
            "Có theo từng tính năng: phân phối đơn thử vòng sau / số lần bỏ lỡ, ThanhToanDoiSoatNen hỏi lại VNPay mỗi 5 phút. Chưa có chính sách chung (số lần tối đa, giãn cách tăng dần, hàng chờ lỗi)."),
        new(105, "Giám sát lỗi", "Chưa xác minh đầy đủ log tập trung và cảnh báo vận hành", 1,
            "Có bảng NhatKyHeThong (mức Error), AuditLog, bộ lọc ghi thao tác quản trị, màn Giám sát hệ thống và CrashLog lưu trên thiết bị. Chưa thấy log tập trung ngoài CSDL, truy vết theo mã tương quan hay cảnh báo tự động tới người vận hành."),
    };

    public AdminThieuSotBackendPage() : base("Thiếu sót Database & Backend") { }

    private static bool Dat(int stt) { try { return Preferences.Default.Get($"thieusot-ix-{stt}", false); } catch { return false; } }
    private static void Dat(int stt, bool v) { try { Preferences.Default.Set($"thieusot-ix-{stt}", v); } catch { } }

    private static (string Bieu, string Nhan, string Mau) TheoMuc(int m) => m switch
    {
        0 => ("❌", "Chưa có", AdminUi.Do),
        1 => ("⚠️", "Có một phần", AdminUi.Cam),
        2 => ("✔", "Đã có", AdminUi.Xanh),
        _ => ("❔", "Chưa xác minh", AdminUi.Xam),
    };

    protected override Task DungAsync()
    {
        var soDat = Dong.Count(d => Dat(d.Stt));
        var mau = Color.FromArgb(soDat == Dong.Length ? AdminUi.Xanh : AdminUi.Tim);

        var dau = new VerticalStackLayout { Spacing = 4 };
        dau.Add(AdminUi.Nhan("IX. Thiếu sót về Database và kiến trúc Backend", 14, dam: true));
        dau.Add(AdminUi.Nhan("Ưu tiên P1 – Hoàn thiện nền tảng (STT 94–105)", 12, mo: true));
        var pt = AdminUi.Nhan($"{(int)Math.Round(100.0 * soDat / Dong.Length)}%", 28, dam: true); pt.TextColor = mau; dau.Add(pt);
        dau.Add(new ProgressBar { Progress = (double)soDat / Dong.Length, ProgressColor = mau });
        dau.Add(AdminUi.Nhan($"{soDat}/{Dong.Length} mục đã đánh dấu khắc phục · ❌ {Dong.Count(d => d.Muc_ == 0)} chưa có · ⚠️ {Dong.Count(d => d.Muc_ == 1)} có một phần · ❔ {Dong.Count(d => d.Muc_ == 3)} chưa xác minh", 11.5, mo: true));
        Nd.Add(KhoiTheo("", dau));

        Nd.Add(KhoiTheo("Lưu ý quan trọng",
            AdminUi.Nhan("EnsureCreated() không thay thế được hệ thống migration để nâng cấp cấu trúc một database đã tồn tại: nó chỉ tạo CSDL khi CHƯA có, không bổ sung bảng/cột/chỉ mục vào CSDL cũ. Hiện việc nâng cấp dựa vào script FoodService_NangCap.sql (chạy lại nhiều lần được, không xóa dữ liệu) — sao lưu trước khi chạy.", 12)));

        var ds = new VerticalStackLayout { Spacing = 2 };
        ds.Add(AdminUi.Nhan("Danh sách thiếu sót — chạm để đánh dấu đã khắc phục", 13, dam: true));
        foreach (var d in Dong)
        {
            var m = d;
            var xong = Dat(m.Stt);
            var (bieu, nhanMuc, mauMuc) = TheoMuc(m.Muc_);
            var dong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 10, Padding = new Thickness(0, 8) };
            dong.Add(new Label { Text = xong ? "✅" : "⚪", FontSize = 18, VerticalOptions = LayoutOptions.Start }, 0, 0);
            var tieuDe = AdminUi.Nhan($"{m.Stt} · {m.ThieuSot}", 13.5, dam: true, mo: xong);
            if (xong) tieuDe.TextDecorations = TextDecorations.Strikethrough;
            var cot = new VerticalStackLayout { Spacing = 2, VerticalOptions = LayoutOptions.Center, Children = { tieuDe } };
            cot.Add(AdminUi.Nhan("Hiện trạng: " + m.HienTrang, 11.5, mo: true));
            var raSoat = AdminUi.Nhan($"{bieu} {nhanMuc}: {m.RaSoat}", 10.5, mo: true);
            raSoat.TextColor = Color.FromArgb(mauMuc);
            cot.Add(raSoat);
            dong.Add(cot, 1, 0);
            var tap = new TapGestureRecognizer();
            tap.Tapped += async (_, _) => { Dat(m.Stt, !Dat(m.Stt)); Nd.Children.Clear(); await DungAsync(); };
            dong.GestureRecognizers.Add(tap);
            ds.Add(dong);
        }
        Nd.Add(KhoiTheo("", ds));

        Nd.Add(KhoiTheo("Cách đọc kết quả rà soát",
            AdminUi.Nhan("Dòng màu dưới mỗi mục là kết quả đối chiếu với mã nguồn Web/ và script Database/ (không phải kiểm thử trên máy chủ đang chạy). Mục ❔ nghĩa là chưa tìm thấy bằng chứng trong mã — cần đối chiếu từng luồng thực tế trước khi đánh dấu xong.", 11.5, mo: true)));

        var datLai = AdminUi.Nut("Đặt lại đánh dấu", AdminUi.Xam);
        datLai.Clicked += async (_, _) =>
        {
            if (!await DisplayAlert("Đặt lại?", $"Bỏ đánh dấu toàn bộ {Dong.Length} mục trên thiết bị này.", "Đặt lại", "Hủy")) return;
            foreach (var d in Dong) Dat(d.Stt, false);
            Nd.Children.Clear();
            await DungAsync();
        };
        Nd.Add(KhoiTheo("", datLai));
        return Task.CompletedTask;
    }
}
