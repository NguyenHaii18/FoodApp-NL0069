using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>v80 — Lịch sử đối soát theo tháng, món bán chạy, đơn hủy, giá trị đơn TB, xuất báo cáo CSV.</summary>
public sealed class VendorDoiSoatPage : ContentPage
{
    private readonly VerticalStackLayout _noiDung = new() { Padding = 16, Spacing = 14 };

    public VendorDoiSoatPage()
    {
        Title = "Đối soát & báo cáo";
        BackgroundColor = VendorPalette.Get("Background");
        Content = new ScrollView { Content = _noiDung };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        Ve();
        try { await DuLieuService.TaiDonHangGianHangAsync(MockData.GianHangHienTai.Id); } catch (Exception ex) { CrashLog.Ghi("DoiSoat.Nap", ex); }
        Ve();
    }

    private static Label Chu(string t, double size = 12.5, bool dam = false, string mau = "TextDark") =>
        new() { Text = t, FontSize = size, FontAttributes = dam ? FontAttributes.Bold : FontAttributes.None, TextColor = VendorPalette.Get(mau) };

    private static Border The(string tieuDe, IEnumerable<View> con)
    {
        var ds = new VerticalStackLayout { Spacing = 8 };
        ds.Children.Add(Chu(tieuDe, 15, true));
        foreach (var v in con) ds.Children.Add(v);
        return new Border
        {
            BackgroundColor = Colors.White, Padding = 14, Stroke = VendorPalette.Get("BorderColor"), StrokeThickness = 1,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = 14 }, Content = ds
        };
    }

    private static Grid Hang(string trai, string phai, bool dam = false)
    {
        var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        g.Children.Add(Chu(trai, 12.5, dam));
        var p = Chu(phai, 12.5, dam); Grid.SetColumn(p, 1); g.Children.Add(p);
        return g;
    }

    private void Ve()
    {
        _noiDung.Children.Clear();
        var gh = MockData.GianHangHienTai;
        var tu = DateTime.Today.AddDays(-29);
        var den = DateTime.Today.AddDays(1);
        var tatCa = MockData.DonHangCuaGianHang.Where(d => d.GianHangId == gh.Id && d.NgayDat >= tu && d.NgayDat < den).ToList();
        var xong = tatCa.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).ToList();
        var huy = tatCa.Count(d => d.TrangThai == TrangThaiDonHang.DaHuy);
        var tc = DoiTacService.TinhTaiChinh(gh, xong);
        var dangXuLy = MockData.DonHangCuaGianHang.Where(d => d.GianHangId == gh.Id &&
            d.TrangThai is TrangThaiDonHang.ChoXacNhan or TrangThaiDonHang.DangLam or TrangThaiDonHang.DangGiao).ToList();
        var duKien = DoiTacService.TinhTaiChinh(gh, xong).ThucNhan;
        var dangCho = dangXuLy.Sum(d => d.TongTien) * (1 - DoiTacService.TyLeChietKhau(gh));

        _noiDung.Children.Add(The("Tổng quan 30 ngày gần nhất", new View[]
        {
            Hang("Đơn đã nhận", tatCa.Count.ToString()),
            Hang("Đơn hoàn thành", xong.Count.ToString()),
            Hang("Đơn bị hủy / từ chối", huy.ToString()),
            Hang("Giá trị đơn trung bình", xong.Count == 0 ? "–" : $"{tc.DoanhThuMon / xong.Count:N0}đ"),
            Hang($"Phí nền tảng ({DoiTacService.TyLeChietKhau(gh):P0})", $"−{tc.PhiNenTang:N0}đ"),
            Hang("Giảm giá quán tài trợ", $"−{tc.GiamGiaQuanChiu:N0}đ"),
            Hang("Dự kiến được thanh toán", $"{duKien:N0}đ", true),
            Chu($"Chưa tính {dangXuLy.Count} đơn đang xử lý (ước tính thêm khoảng {dangCho:N0}đ nếu hoàn thành).", 11.5, false, "TextGrey"),
        }));

        var thang = VanHanhService.DoiSoatTheoThang(gh, 6);
        _noiDung.Children.Add(The("Lịch sử đối soát theo tháng", thang.Select(t =>
            (View)new VerticalStackLayout
            {
                Spacing = 1,
                Children =
                {
                    Hang($"Tháng {t.Thang} · {t.SoDon} đơn", $"{t.ThucNhan:N0}đ", true),
                    Chu($"Tiền món {t.DoanhThu:N0}đ − phí nền tảng {t.PhiNenTang:N0}đ", 11.5, false, "TextGrey"),
                }
            })));

        var ban = VanHanhService.MonBanChay(gh.Id, tu, den, 10);
        _noiDung.Children.Add(The("Món bán chạy (30 ngày)", ban.Count == 0
            ? new View[] { Chu("Chưa có đơn hoàn thành trong kỳ.", 12.5, false, "TextGrey") }
            : ban.Select((m, i) => (View)Hang($"{i + 1}. {m.TenMon}", $"{m.SoLuong} phần · {m.DoanhThu:N0}đ"))));

        var nut = (Button)new Button { Text = "📤 Xuất báo cáo CSV (30 ngày)", HeightRequest = 44, BackgroundColor = VendorPalette.Get("Primary"), TextColor = Colors.White, CornerRadius = 12 };
        nut.Clicked += async (_, _) =>
        {
            var kq = await VanHanhService.XuatCsvAsync(gh, tu, den);
            if (kq is null) await DisplayAlert("Không xuất được", "Không mở được hộp thoại chia sẻ tệp trên thiết bị này.", "OK");
        };
        _noiDung.Children.Add(nut);
    }
}
