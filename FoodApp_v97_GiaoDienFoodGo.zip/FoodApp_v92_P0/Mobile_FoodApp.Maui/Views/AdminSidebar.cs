namespace FoodApp.Maui.Views;

/// <summary>
/// Sidebar điều hướng riêng của phân hệ Quản trị viên: nền xanh navy, mục đang chọn tô tím, huy hiệu số đơn cần xử lý.
/// Điện thoại: mở dạng ngăn kéo (nút ☰). Màn rộng (máy tính bảng / cửa sổ ≥ 900): hiện cố định bên trái.
/// Sidebar chỉ phát sự kiện <see cref="Chon"/>; trang chủ quyết định điều hướng và kiểm quyền nhân viên.
/// </summary>
public class AdminSidebar : ContentView
{
    private static readonly (string Khoa, string Icon, string Nhan, bool ChiChuQuan)[] Muc =
    {
        ("home", "🏠", "Tổng quan", false),
        ("orders", "🧾", "Đơn hàng", false),
        ("dispatch", "🧭", "Điều phối", false),
        ("vendors", "🏬", "Gian hàng", false),
        ("drivers", "🛵", "Tài xế", false),
        ("customers", "👥", "Khách hàng", false),
        ("promo", "🎁", "Khuyến mãi", false),
        ("reports", "📊", "Báo cáo", false),
        ("staff", "🛡", "Phân quyền", true),
        ("settings", "⚙️", "Cấu hình", true),
        ("all", "🗂", "Tất cả chức năng", false),
    };

    public event Action<string>? Chon;
    private readonly VerticalStackLayout _ds = new() { Spacing = 4 };
    private readonly Label _ten = new() { TextColor = Colors.White, FontAttributes = FontAttributes.Bold, FontSize = 15, LineBreakMode = LineBreakMode.TailTruncation };
    private readonly Label _phu = new() { TextColor = Color.FromArgb("#AEB4D6"), FontSize = 11.5 };
    private string _chon = "home";
    private int _soDonCho;
    private bool _nhanVien;

    public AdminSidebar()
    {
        var dangXuat = Dong("↪", "Đăng xuất", false, 0, () => Chon?.Invoke("logout"));
        var dau = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 10, Padding = new Thickness(6, 6, 6, 18) };
        dau.Add(new Border
        {
            WidthRequest = 42, HeightRequest = 42, BackgroundColor = Color.FromArgb("#F97316"), StrokeThickness = 0,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(12) },
            Content = new Label { Text = "🛍️", FontSize = 22, TextColor = Colors.White, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center }
        }, 0);
        dau.Add(new VerticalStackLayout { VerticalOptions = LayoutOptions.Center, Children = { _ten, _phu } }, 1);
        dau.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(() => Chon?.Invoke("home")) });
        SemanticProperties.SetDescription(dau, "Về trang chủ");

        Content = new Border
        {
            BackgroundColor = Color.FromArgb("#14193A"), StrokeThickness = 0, Padding = new Thickness(14, 22, 14, 18),
            Content = new Grid
            {
                RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Star), new RowDefinition(GridLength.Auto) },
                Children = { dau, new ScrollView { Content = _ds }.Row(1), dangXuat.Row(2) }
            }
        };
        Ve();
    }

    public string MucChon { get => _chon; set { _chon = value; Ve(); } }

    /// <summary>Cập nhật tên quán, huy hiệu đơn cần xử lý và chế độ nhân viên (ẩn mục chỉ dành cho chủ quán).</summary>
    public void CapNhat(string tenQuan, int soDonCho, bool laNhanVien)
    {
        _ten.Text = string.IsNullOrWhiteSpace(tenQuan) ? "Quản trị" : tenQuan;
        _phu.Text = laNhanVien ? "Nhân viên" : "Quản trị viên";
        _soDonCho = soDonCho; _nhanVien = laNhanVien;
        Ve();
    }

    private void Ve()
    {
        _ds.Children.Clear();
        foreach (var (khoa, icon, nhan, chiChu) in Muc)
        {
            if (chiChu && _nhanVien) continue;
            _ds.Children.Add(Dong(icon, nhan, khoa == _chon, khoa == "orders" ? _soDonCho : 0, () => Chon?.Invoke(khoa)));
        }
    }

    private static View Dong(string icon, string nhan, bool chon, int huyHieu, Action khiChon)
    {
        var luoi = new Grid
        {
            ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
            ColumnSpacing = 12, Padding = new Thickness(12, 0), MinimumHeightRequest = 46
        };
        luoi.Add(new Label { Text = icon, FontSize = 18, TextColor = Colors.White, VerticalOptions = LayoutOptions.Center }, 0);
        luoi.Add(new Label { Text = nhan, FontSize = 14.5, FontAttributes = chon ? FontAttributes.Bold : FontAttributes.None, TextColor = chon ? Colors.White : Color.FromArgb("#D5D9F0"), VerticalOptions = LayoutOptions.Center }, 1);
        if (huyHieu > 0)
            luoi.Add(new Border
            {
                BackgroundColor = Color.FromArgb("#F97316"), StrokeThickness = 0, Padding = new Thickness(7, 1), VerticalOptions = LayoutOptions.Center,
                StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(10) },
                Content = new Label { Text = huyHieu > 99 ? "99+" : huyHieu.ToString(), TextColor = Color.FromArgb("#14193A"), FontSize = 11, FontAttributes = FontAttributes.Bold }
            }, 2);
        var vien = new Border
        {
            BackgroundColor = chon ? Color.FromArgb("#5B3FD9") : Colors.Transparent, StrokeThickness = 0,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(12) },
            Content = luoi
        };
        SemanticProperties.SetDescription(vien, huyHieu > 0 ? $"{nhan}, {huyHieu} đơn cần xử lý" : nhan);
        vien.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(khiChon) });
        return vien;
    }
}
