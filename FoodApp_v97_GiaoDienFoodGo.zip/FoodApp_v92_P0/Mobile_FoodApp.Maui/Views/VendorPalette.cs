namespace FoodApp.Maui.Views;

/// <summary>Màu của khu Gian hàng (trắng, navy, tím, cam) dùng trong code C#; khớp Resources/Styles/VendorTheme.xaml.</summary>
public static class VendorPalette
{
    public static Color Get(string key) => key switch
    {
        "Primary" => Color.FromArgb("#5B3FD9"),
        "PrimaryDark" => Color.FromArgb("#4A2FB5"),
        "PrimaryLight" => Color.FromArgb("#A99BF2"),
        "PrimarySoft" => Color.FromArgb("#EEEBFF"),
        "Accent" => Color.FromArgb("#F97316"),
        "Navy" => Color.FromArgb("#14193A"),
        "Orange" => Color.FromArgb("#F97316"),
        "Background" => Color.FromArgb("#F6F7FF"),
        "CardColor" => Colors.White,
        "TextDark" => Color.FromArgb("#1F2937"),
        "TextGrey" => Color.FromArgb("#6B7280"),
        "Danger" => Color.FromArgb("#DC2626"),
        "Success" => Color.FromArgb("#16A34A"),
        "Warning" => Color.FromArgb("#E99A22"),
        "BorderColor" => Color.FromArgb("#E3E6F5"),
        _ => (Color)Application.Current!.Resources[key],
    };
}
