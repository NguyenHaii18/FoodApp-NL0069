using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>v80 — Vận hành quán: đơn đang chuẩn bị, giới hạn giờ cao điểm, chuông/rung đơn mới, thông số riêng từng món.</summary>
public sealed class VendorVanHanhPage : ContentPage
{
    private readonly Label _lblCho = Chi(), _lblNau = Chi(), _lblSan = Chi();
    private readonly Label _lblTai = new() { FontSize = 12.5, FontAttributes = FontAttributes.Bold };
    private readonly Entry _entryToiDa = new() { Keyboard = Keyboard.Numeric, Placeholder = "0 = không giới hạn", BackgroundColor = Colors.White, MaxLength = 3 };
    private readonly Switch _swBao = new() { OnColor = VendorPalette.Get("Primary") };
    private readonly VerticalStackLayout _dsMon = new() { Spacing = 8 };

    public VendorVanHanhPage()
    {
        Title = "Vận hành quán";
        BackgroundColor = VendorPalette.Get("Background");

        var luuToiDa = new Button { Text = "Lưu giới hạn", Style = Application.Current?.Resources.TryGetValue("PrimaryButton", out var st) == true ? st as Style : null, HeightRequest = 42 };
        luuToiDa.Clicked += OnLuuToiDa;
        _swBao.Toggled += (_, e) => VanHanhService.BaoDonMoiBat = e.Value;

        Content = new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = 16, Spacing = 14,
                Children =
                {
                    The("Đơn đang xử lý", new Grid
                    {
                        ColumnDefinitions = { new ColumnDefinition(), new ColumnDefinition(), new ColumnDefinition() },
                        Children = { Cot(0, "Chờ xác nhận", _lblCho), Cot(1, "Đang nấu", _lblNau), Cot(2, "Chờ giao", _lblSan) }
                    }, _lblTai),
                    The("Giờ cao điểm",
                        Chu("Số đơn tối đa được chuẩn bị cùng lúc. Khi đang nấu đủ ngần ấy đơn, khách tạm thời không đặt thêm được cho đến khi có đơn xong. Đặt 0 nếu không muốn giới hạn."),
                        _entryToiDa, luuToiDa),
                    The("Báo đơn mới",
                        new Grid
                        {
                            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
                            Children = { Chu("Chuông + rung khi có đơn chờ xác nhận (kiểm tra mỗi 30 giây khi đang mở app)"), Dat(_swBao, 1) }
                        }),
                    The("Thời gian chuẩn bị & khung giờ bán của món",
                        Chu("Chạm vào món để đặt thời gian chuẩn bị riêng (phút), khung giờ bán (vd bữa sáng 06:00–10:00) và món ăn kèm."),
                        _dsMon),
                }
            }
        };
    }

    private static Label Chi() => new() { FontSize = 22, FontAttributes = FontAttributes.Bold, HorizontalTextAlignment = TextAlignment.Center, TextColor = VendorPalette.Get("Primary") };
    private static Label Chu(string t) => new() { Text = t, FontSize = 12.5, TextColor = VendorPalette.Get("TextGrey") };
    private static T Dat<T>(T v, int cot) where T : BindableObject { Grid.SetColumn(v, cot); return v; }

    private static View Cot(int cot, string nhan, Label so)
    {
        var s = new VerticalStackLayout { Spacing = 2, Children = { so, new Label { Text = nhan, FontSize = 11.5, HorizontalTextAlignment = TextAlignment.Center, TextColor = VendorPalette.Get("TextGrey") } } };
        Grid.SetColumn(s, cot);
        return s;
    }

    private static Border The(string tieuDe, params View[] noiDung)
    {
        var ds = new VerticalStackLayout { Spacing = 10 };
        ds.Children.Add(new Label { Text = tieuDe, FontAttributes = FontAttributes.Bold, FontSize = 15 });
        foreach (var v in noiDung) ds.Children.Add(v);
        return new Border
        {
            BackgroundColor = Colors.White, Padding = 14, Stroke = VendorPalette.Get("BorderColor"), StrokeThickness = 1,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = 14 }, Content = ds
        };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        _swBao.IsToggled = VanHanhService.BaoDonMoiBat;
        NapSoLieu();
        NapDanhSachMon();
        try
        {
            await DuLieuService.TaiDonHangGianHangAsync(MockData.GianHangHienTai.Id);
            await VanHanhService.TaiThongSoMonAsync();
        }
        catch (Exception ex) { CrashLog.Ghi("VanHanhPage.Nap", ex); }
        NapSoLieu();
        NapDanhSachMon();
        VanHanhService.BatDauTheoDoi(NapSoLieu);
    }

    protected override void OnDisappearing() { base.OnDisappearing(); VanHanhService.DungTheoDoi(); }

    private void NapSoLieu()
    {
        var sl = VanHanhService.DemDon(MockData.GianHangHienTai.Id);
        _lblCho.Text = sl.ChoXacNhan.ToString();
        _lblNau.Text = sl.DangNau.ToString();
        _lblSan.Text = sl.SanSangGiao.ToString();
        if (!_entryToiDa.IsFocused) _entryToiDa.Text = sl.ToiDaDonDong.ToString();
        _lblTai.Text = sl.ToiDaDonDong == 0 ? "Không giới hạn số đơn đồng thời"
            : sl.QuaTai ? $"⚠ Quá tải: đang nấu {sl.DangNau}/{sl.ToiDaDonDong} đơn — khách tạm không đặt thêm được"
            : $"Công suất: {sl.DangNau}/{sl.ToiDaDonDong} đơn đang nấu";
        _lblTai.TextColor = sl.QuaTai ? VendorPalette.Get("Danger") : VendorPalette.Get("TextGrey");
    }

    private async void OnLuuToiDa(object? sender, EventArgs e)
    {
        if (!int.TryParse(string.IsNullOrWhiteSpace(_entryToiDa.Text) ? "0" : _entryToiDa.Text, out var so) || so is < 0 or > 200)
        {
            await DisplayAlert("Chưa hợp lệ", "Nhập số từ 0 đến 200 (0 = không giới hạn).", "OK");
            return;
        }
        if (!await VanHanhService.DatToiDaDonDongAsync(so)) return;
        NapSoLieu();
        await DisplayAlert("Đã lưu", DuLieuService.ChuThichGhi(so == 0 ? "Đã bỏ giới hạn số đơn đồng thời." : $"Quán nhận tối đa {so} đơn đang chuẩn bị cùng lúc."), "OK");
    }

    private void NapDanhSachMon()
    {
        _dsMon.Children.Clear();
        foreach (var mon in MockData.MonAnCuaGianHang(MockData.GianHangHienTai.Id))
        {
            var phu = new List<string>();
            phu.Add(mon.ThoiGianChuanBiPhut is > 0 ? $"⏱ {mon.ThoiGianChuanBiPhut} phút" : "⏱ theo đơn");
            if (mon.CoKhungGioBan) phu.Add(mon.KhungGioBanText);
            if (!string.IsNullOrWhiteSpace(mon.MonAnKem)) phu.Add("🍟 có món kèm");
            var dong = new VerticalStackLayout
            {
                Spacing = 1, Padding = new Thickness(0, 4),
                Children =
                {
                    new Label { Text = mon.TenMon, FontAttributes = FontAttributes.Bold, FontSize = 13.5 },
                    new Label { Text = string.Join(" · ", phu), FontSize = 11.5, TextColor = VendorPalette.Get("TextGrey") }
                }
            };
            var cham = new TapGestureRecognizer();
            cham.Tapped += async (_, _) => await Shell.Current.GoToAsync(nameof(VendorMenuItemEditPage), new Dictionary<string, object> { { "MonAnId", mon.Id } });
            dong.GestureRecognizers.Add(cham);
            _dsMon.Children.Add(dong);
        }
        if (_dsMon.Children.Count == 0) _dsMon.Children.Add(Chu("Chưa có món nào."));
    }
}
