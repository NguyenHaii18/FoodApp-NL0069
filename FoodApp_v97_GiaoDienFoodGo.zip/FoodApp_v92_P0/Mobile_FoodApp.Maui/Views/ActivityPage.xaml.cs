using FoodApp.Maui.Models;

namespace FoodApp.Maui.Views;

/// <summary>Dòng thời gian: cập nhật trạng thái đơn của khách và mã giảm giá đang có (lấy từ dữ liệu thật của app).</summary>
public partial class ActivityPage : ContentPage
{
    public ActivityPage() { InitializeComponent(); }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        Ve();
        await Services.ThongBaoMayChuService.TaiAsync();   // thông báo thật từ SQL Server (thanh toán, hoàn tiền, khuyến mãi...)
        Ve();
    }

    private Color Mau(string k) => (Color)Resources[k];

    private string _loc = "";   // "" = tất cả | DonHang | KhuyenMai | HeThong

    private void VeThanhLoc()
    {
        ThanhLoc.Children.Clear();
        foreach (var (khoa, nhan) in new[] { ("", "Tất cả"), ("DonHang", "Đơn hàng"), ("KhuyenMai", "Khuyến mãi"), ("HeThong", "Hệ thống") })
        {
            var chon = khoa == _loc;
            var nut = new Button
            {
                Text = nhan, CornerRadius = 16, HeightRequest = 34, Padding = new Thickness(16, 0), FontSize = 12.5,
                BackgroundColor = chon ? Mau("Primary") : Mau("PrimarySoft"),
                TextColor = chon ? Colors.White : Mau("Primary"),
            };
            nut.Clicked += (_, _) => { _loc = khoa; VeThanhLoc(); Ve(); };
            ThanhLoc.Children.Add(nut);
        }
    }

    private static string NhomTheoLoai(string? loai)
        => (loai ?? "").Contains("khuyen", StringComparison.OrdinalIgnoreCase) || (loai ?? "").Contains("voucher", StringComparison.OrdinalIgnoreCase) ? "KhuyenMai"
         : (loai ?? "").Contains("don", StringComparison.OrdinalIgnoreCase) || (loai ?? "").Contains("thanh", StringComparison.OrdinalIgnoreCase) || (loai ?? "").Contains("hoan", StringComparison.OrdinalIgnoreCase) ? "DonHang"
         : "HeThong";

    private static string ThoiGian(DateTime t)
        => t.Date == DateTime.Today ? t.ToString("HH:mm")
         : t.Date == DateTime.Today.AddDays(-1) ? "Hôm qua"
         : t.ToString("dd/MM");

    private void Ve()
    {
        if (ThanhLoc.Children.Count == 0) VeThanhLoc();
        var muc = new List<(DateTime Luc, string Icon, string TieuDe, string MoTa, bool Noi, string Nhom, string DonId, string Loai)>();

        foreach (var d in MockData.LichSuDonHang.Where(OrderTrackingPage.DonCuaToi))
        {
            var (icon, td, mt) = d.TrangThai switch
            {
                TrangThaiDonHang.ChoXacNhan => ("⏳", $"Đơn hàng #{d.Id}", $"Đang chờ {d.TenGianHang} xác nhận đơn"),
                TrangThaiDonHang.DangLam => ("👨‍🍳", $"Đơn hàng #{d.Id}", $"{d.TenGianHang} đang làm món cho bạn"),
                TrangThaiDonHang.DangGiao => ("🛵", $"Đơn hàng #{d.Id}", "Tài xế đang giao đơn hàng của bạn"),
                TrangThaiDonHang.HoanThanh => ("✅", $"Đơn hàng #{d.Id}", $"Đã hoàn thành — đánh giá {d.TenGianHang} ở tab Đơn hàng"),
                _ => ("❌", $"Đơn hàng #{d.Id}", d.DaHoanTien ? "Đã hủy — đã hoàn tiền" : $"Đã hủy ({d.TenGianHang})"),
            };
            muc.Add((d.NgayDat, icon, td, mt, d.TrangThai is TrangThaiDonHang.ChoXacNhan or TrangThaiDonHang.DangLam or TrangThaiDonHang.DangGiao, "DonHang", d.Id, "DonHang"));
        }
        foreach (var k in MockData.DanhSachKhuyenMai.Where(k => k.DangHoatDong && k.ConHan && !k.ChuaBatDau && k.ConLuot))
            muc.Add((k.NgayBatDau, "🏷️", $"Mã giảm giá: {k.MaCode}", k.GiaTriGiamHienThi + " · " + k.PhamViHienThi, false, "KhuyenMai", "", "KhuyenMai"));

        foreach (var t in Services.ThongBaoMayChuService.DanhSach.Where(t => t.Loai != "DonHang"))   // thông báo đơn hàng đã có ở trên
            muc.Add((t.Ngay, Services.ThongBaoMayChuService.Icon(t.Loai), t.TieuDe, t.NoiDung, !t.DaDoc, NhomTheoLoai(t.Loai), t.MaThamChieu ?? "", t.Loai));

        var ds = muc.Where(m => _loc == "" || m.Nhom == _loc).OrderByDescending(x => x.Luc).ToList();
        DanhSach.Children.Clear();
        LblTrong.IsVisible = ds.Count == 0;
        foreach (var m in ds)
        {
            var bieuTuong = new Border
            {
                WidthRequest = 46, HeightRequest = 46, StrokeThickness = 0, VerticalOptions = LayoutOptions.Start,
                BackgroundColor = m.Noi ? Mau("PrimarySoft") : Color.FromArgb("#F1F4F3"),
                StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(23) },
                Content = new Label { Text = m.Icon, FontSize = 21, TextColor = Colors.Black, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center },
            };
            var cot = new VerticalStackLayout { Spacing = 2 };
            cot.Children.Add(new Label { Text = m.TieuDe, FontAttributes = FontAttributes.Bold, FontSize = 14, LineBreakMode = LineBreakMode.TailTruncation });
            cot.Children.Add(new Label { Text = m.MoTa, FontSize = 12, TextColor = Mau("TextGrey"), MaxLines = 2, LineBreakMode = LineBreakMode.TailTruncation });
            var gio = new VerticalStackLayout { Spacing = 6, HorizontalOptions = LayoutOptions.End };
            gio.Children.Add(new Label { Text = ThoiGian(m.Luc), FontSize = 11, TextColor = Mau("TextGrey"), HorizontalTextAlignment = TextAlignment.End });
            if (m.Noi) gio.Children.Add(new BoxView { WidthRequest = 8, HeightRequest = 8, CornerRadius = 4, Color = Mau("Primary"), HorizontalOptions = LayoutOptions.End });

            var hang = new Grid { ColumnSpacing = 12, Padding = new Thickness(0, 12), ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            hang.Add(bieuTuong, 0); hang.Add(cot, 1); hang.Add(gio, 2);
            var donId = m.DonId; var loai = m.Loai; var nhom = m.Nhom;
            hang.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(async () =>
                {
                    // Thông báo đơn hàng → mở đúng đơn; khuyến mãi → mở tab Ưu đãi
                    if (nhom == "DonHang" && !string.IsNullOrEmpty(donId) && MockData.LichSuDonHang.Any(x => x.Id == donId))
                    {
                        OrderTrackingPage.DonCanMo = donId;
                        await Shell.Current.GoToAsync("//chinh/don-hang");
                    }
                    else if (nhom == "KhuyenMai")
                        await Shell.Current.GoToAsync("//chinh/uu-dai");
                })
            });
            DanhSach.Children.Add(hang);
            DanhSach.Children.Add(new BoxView { HeightRequest = 1, Color = Mau("BorderColor"), Margin = new Thickness(58, 0, 0, 0) });
        }
    }
}
