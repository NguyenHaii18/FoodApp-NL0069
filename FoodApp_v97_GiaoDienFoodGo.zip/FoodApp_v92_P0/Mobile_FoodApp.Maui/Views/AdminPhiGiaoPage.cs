using System.Globalization;
using System.Text.Json;
using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// v83 — Quản trị chỉnh phí giao hàng và tỉ lệ chia phí giao giữa tài xế / ứng dụng (thay cho bảng tính).
/// Gồm: tổng quan phí ship, các mức phí chỉnh được, tỉ lệ tài xế/ứng dụng, tính thử một đơn.
/// Chỉ Admin tổng được lưu; tỉ lệ chia chỉ áp dụng cho đơn đặt sau khi đổi (đã chốt vào từng đơn lúc đặt).
/// </summary>
public sealed class AdminPhiGiaoPage : AdminKyThuatTrang
{
    private sealed record Truong(string Khoa, string Nhan, string Kieu, string GoiY);

    private static readonly Truong[] PhiGiao =
    {
        new("phiCoBan", "Phí cơ bản", "tien", "Phí cho số km đầu tiên"),
        new("kmCoBan", "Số km đầu tính phí cơ bản", "km", "Km đầu chỉ tính phí cơ bản"),
        new("phiMoiKm", "Phí mỗi km vượt", "tien", "Làm tròn lên từng km vượt"),
        new("phuPhiNgoaiThanh", "Phụ phí ngoại thành", "tien", "Cộng thêm khi giao ra vùng ngoại thành"),
        new("caoDiemPhanTram", "Phụ phí giờ cao điểm", "tyle", "Nhập 0.2 hoặc 20% (tính trên phí cơ bản + phí km vượt)"),
        new("khungCaoDiem", "Khung giờ cao điểm", "text", "Dạng HH:mm-HH:mm, nhiều khung cách nhau dấu ; (vd 10:30-13:00;17:00-20:00)"),
        new("muaPhanTram", "Phụ phí khi mưa lớn", "tyle", "Nhập 0.15 hoặc 15%"),
        new("dangMua", "Đang mưa lớn (bật tay)", "bat", "Bật = áp phụ phí mưa cho mọi đơn mới"),
        new("phiToiThieu", "Phí giao tối thiểu", "tien", "Phí không thấp hơn mức này"),
        new("phiToiDa", "Phí giao tối đa", "tien", "Phí không vượt mức này"),
        new("phiMacDinh", "Phí mặc định", "tien", "Dùng khi không xác định được khoảng cách"),
        new("lamTron", "Làm tròn phí lên bội số", "tien", "0 hoặc 1 = không làm tròn"),
    };

    private static readonly Truong TyLe = new("tyLeTaiXe", "Tỉ lệ tài xế nhận", "tyle", "Nhập 0.8 hoặc 80%: tài xế nhận 80% phí giao, ứng dụng giữ 20%");

    private int _ngay = 30;
    private bool _coQuyenSua;
    private JsonElement _cfg;
    private JsonElement _macDinh;
    private Entry? _oKm, _oMon, _oGio, _oUuDai;
    private Switch? _swMua, _swNgoai;
    private VerticalStackLayout _ketQua = new() { Spacing = 4 };

    protected override Quyen? QuyenCan => Quyen.XemThongKe;

    public AdminPhiGiaoPage() : base("Phí giao & chia tiền") { }

    private async Task LamMoiAsync()
    {
        Nd.Children.Clear();
        await DungAsync();
    }

    private static string Ty(decimal r) => $"{r * 100:0.##}%";

    private static string HienThi(string kieu, JsonElement e, string khoa) => kieu switch
    {
        "tien" => AdminUi.Tien(J.D(e, khoa)),
        "tyle" => Ty(J.D(e, khoa)),
        "km" => $"{J.D(e, khoa):0.##} km",
        "bat" => J.B(e, khoa) ? "Bật" : "Tắt",
        _ => J.S(e, khoa),
    };

    /// <summary>Giá trị JSON → chuỗi gửi lên máy chủ (số dùng dấu chấm, bật/tắt = 1/0).</summary>
    private static string Chuoi(JsonElement e, string khoa)
    {
        if (!J.Co(e, khoa, out var v)) return "";
        return v.ValueKind switch
        {
            JsonValueKind.True => "1",
            JsonValueKind.False => "0",
            JsonValueKind.Number => v.GetRawText(),
            JsonValueKind.String => v.GetString() ?? "",
            _ => "",
        };
    }

    protected override async Task DungAsync()
    {
        var r = await ApiClient.GetAsync<JsonElement>("api/mobile/admin/phi-giao");
        if (!r.ThanhCong)
        {
            Nd.Add(AdminUi.Nhan(r.MatKetNoi ? "Trang này cần kết nối máy chủ (online).\n" + r.ThongDiep : r.ThongDiep, 13, mo: true));
            return;
        }
        _coQuyenSua = J.B(r.DuLieu, "coQuyenSua");
        _cfg = J.Doi(r.DuLieu, "cauHinh");
        _macDinh = J.Doi(r.DuLieu, "macDinh");

        await VeThongKeAsync();
        VeChiaTien();
        VePhiGiao();
        VeTinhThu();

        if (_coQuyenSua)
        {
            var khoiPhuc = AdminUi.Nut("↩ Khôi phục mức mặc định (theo bảng tính)", AdminUi.Xam);
            khoiPhuc.Clicked += async (_, _) => await KhoiPhucAsync();
            Nd.Add(khoiPhuc);
        }
        Nd.Add(AdminUi.Nhan("Mức phí mới áp dụng ngay cho đơn đặt từ lúc lưu. Tỉ lệ tài xế/ứng dụng được chốt vào từng đơn lúc khách đặt nên đơn cũ giữ tỉ lệ cũ. Mọi thay đổi được lưu lịch sử người sửa (Cấu hình → Lịch sử thay đổi).", 11.5, mo: true));
    }

    // ------------------------------------------------------------------ tổng quan
    private async Task VeThongKeAsync()
    {
        var chip = new HorizontalStackLayout { Spacing = 8 };
        foreach (var n in new[] { 7, 30, 90 })
        {
            var so = n;
            var nut = AdminUi.Nut($"{n} ngày", AdminUi.Tim, day: so == _ngay);
            nut.Clicked += async (_, _) => { _ngay = so; await LamMoiAsync(); };
            chip.Add(nut);
        }
        Nd.Add(chip);

        var tk = await ApiClient.GetAsync<JsonElement>($"api/mobile/admin/phi-giao/thong-ke?ngay={_ngay}");
        if (!tk.ThanhCong)
        {
            Nd.Add(KhoiTheo("Tổng quan phí ship", AdminUi.Nhan(tk.ThongDiep, 12.5, mo: true)));
            return;
        }
        var d = tk.DuLieu;
        Nd.Add(KhoiTheo($"Tổng quan phí ship {_ngay} ngày (đơn đã giao)",
            DongTrai("Số đơn", J.L(d, "soDon").ToString("N0")),
            DongTrai("Tổng phí ship gốc", AdminUi.Tien(J.D(d, "tongPhiShipGoc"))),
            DongTrai("Tổng khách trả (cả tiền món)", AdminUi.Tien(J.D(d, "tongKhachTra"))),
            DongTrai("Tiền tài xế nhận", AdminUi.Tien(J.D(d, "tienTaiXe")), AdminUi.Xanh),
            DongTrai("Phần ứng dụng giữ lại", AdminUi.Tien(J.D(d, "tienUngDung")), AdminUi.Tim),
            DongTrai("Tổng giảm giá", AdminUi.Tien(J.D(d, "tongGiamGia"))),
            DongTrai("Phí ship trung bình / đơn", AdminUi.Tien(J.D(d, "phiShipTrungBinh")))));
    }

    // ------------------------------------------------------------------ chia tiền
    private void VeChiaTien()
    {
        var tx = J.D(_cfg, "tyLeTaiXe");
        var khung = KhoiTheo("Chia phí giao: tài xế / ứng dụng",
            DongTrai("Tài xế nhận", Ty(tx), AdminUi.Xanh),
            DongTrai("Ứng dụng giữ lại", Ty(1m - tx), AdminUi.Tim),
            AdminUi.Nhan("Ví dụ đơn phí ship 20.000đ: tài xế nhận " + AdminUi.Tien(Math.Round(20000m * tx, 0)) + ", ứng dụng giữ " + AdminUi.Tien(20000m - Math.Round(20000m * tx, 0)) + ".", 11.5, mo: true));
        khung.Content = ThemDongSua((VerticalStackLayout)khung.Content!, TyLe);
        Nd.Add(khung);
    }

    // ------------------------------------------------------------------ các mức phí
    private void VePhiGiao()
    {
        var st = new VerticalStackLayout { Spacing = 8 };
        foreach (var t in PhiGiao) st.Add(DongSua(t));
        Nd.Add(KhoiTheo("Mức phí giao hàng", st));
    }

    private VerticalStackLayout ThemDongSua(VerticalStackLayout st, Truong t)
    {
        st.Add(DongSua(t));
        return st;
    }

    private View DongSua(Truong t)
    {
        var the = AdminUi.The(10);
        var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 8 };
        var trai = new VerticalStackLayout { Spacing = 1 };
        trai.Add(AdminUi.Nhan(t.Nhan, 13, dam: true));
        trai.Add(AdminUi.Nhan(t.GoiY, 11, mo: true));
        g.Add(trai, 0, 0);
        var v = AdminUi.Nhan(HienThi(t.Kieu, _cfg, t.Khoa) + (_coQuyenSua ? "  ✎" : ""), 13, dam: true);
        v.TextColor = Color.FromArgb(AdminUi.Tim);
        v.VerticalOptions = LayoutOptions.Center;
        v.HorizontalTextAlignment = TextAlignment.End;
        g.Add(v, 1, 0);
        the.Content = g;
        var tap = new TapGestureRecognizer();
        tap.Tapped += async (_, _) => await SuaAsync(t);
        the.GestureRecognizers.Add(tap);
        return the;
    }

    private async Task SuaAsync(Truong t)
    {
        if (!_coQuyenSua)
        {
            await DisplayAlert("Chỉ xem", "Chỉ Admin tổng được đổi phí giao và tỉ lệ chia tiền.", "Đóng");
            return;
        }
        string? moi;
        if (t.Kieu == "bat")
        {
            var c = await DisplayActionSheet(t.Nhan, "Hủy", null, "Bật", "Tắt");
            if (c is null or "Hủy") return;
            moi = c == "Bật" ? "1" : "0";
        }
        else
        {
            var macDinh = Chuoi(_cfg, t.Khoa);
            moi = await AdminUi.Hoi(this, t.Nhan, t.GoiY, null, 1, macDinh, t.Kieu is "tien" or "km" ? Keyboard.Numeric : Keyboard.Text);   // tỉ lệ cho nhập 80% nên dùng bàn phím chữ
            if (moi == null) return;
        }
        var ok = await AdminUi.Put(this, "api/mobile/admin/phi-giao", new Dictionary<string, string> { [t.Khoa] = moi },
            "Sửa phí giao / chia tiền", $"{t.Nhan} = {moi}");
        if (ok) await LamMoiAsync();
    }

    private async Task KhoiPhucAsync()
    {
        if (!await DisplayAlert("Khôi phục mặc định?", "Đặt lại toàn bộ mức phí giao và tỉ lệ tài xế/ứng dụng về mức mặc định (12.000đ cho 2 km đầu, 4.000đ/km, +20% cao điểm, +15% mưa, tài xế 80%). Đơn đã đặt không đổi.", "Khôi phục", "Hủy")) return;
        var body = new Dictionary<string, string>();
        foreach (var t in PhiGiao.Append(TyLe))
        {
            var s = Chuoi(_macDinh, t.Khoa);
            if (s != "") body[t.Khoa] = s;
        }
        var ok = await AdminUi.Put(this, "api/mobile/admin/phi-giao", body, "Khôi phục phí giao mặc định", "Phí giao & chia tiền");
        if (ok) await LamMoiAsync();
    }

    // ------------------------------------------------------------------ tính thử
    private void VeTinhThu()
    {
        _ketQua = new VerticalStackLayout { Spacing = 4 };   // tạo mới mỗi lần vẽ lại (tránh dùng lại phần tử đã có cha)
        _oKm = new Entry { Placeholder = "Khoảng cách (km), vd 4.5", Keyboard = Keyboard.Numeric, FontSize = 13, Text = "3" };
        _oMon = new Entry { Placeholder = "Giá trị món (đ) — tùy chọn", Keyboard = Keyboard.Numeric, FontSize = 13, Text = "100000" };
        _oGio = new Entry { Placeholder = "Giờ giao HH:mm (để trống = bây giờ)", FontSize = 13 };
        _oUuDai = new Entry { Placeholder = "Ưu đãi trên phí ship (đ) — tùy chọn", Keyboard = Keyboard.Numeric, FontSize = 13 };
        _swMua = new Switch { IsToggled = J.B(_cfg, "dangMua") };
        _swNgoai = new Switch();

        View Cong(string nhan, Switch s)
        {
            var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            g.Add(AdminUi.Nhan(nhan, 13), 0, 0);
            g.Add(s, 1, 0);
            return g;
        }

        var tinh = AdminUi.Nut("Tính thử", AdminUi.Tim, day: true);
        tinh.Clicked += async (_, _) =>
        {
            tinh.IsEnabled = false;
            try { await TinhAsync(); }
            finally { tinh.IsEnabled = true; }
        };
        Nd.Add(KhoiTheo("Tính thử phí ship (dùng mức phí đang lưu)", _oKm, _oMon, _oGio, _oUuDai,
            Cong("Trời mưa lớn", _swMua), Cong("Giao ra ngoại thành", _swNgoai), tinh, _ketQua));
    }

    private static decimal So(string? s)
    {
        s = (s ?? "").Trim().Replace(".", "").Replace(" ", "").Replace(',', '.');
        return decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out var v) ? v : 0m;
    }

    private async Task TinhAsync()
    {
        var kmChuoi = (_oKm?.Text ?? "").Trim().Replace(',', '.');
        if (!double.TryParse(kmChuoi, NumberStyles.Number, CultureInfo.InvariantCulture, out var km) || km < 0)
        {
            await DisplayAlert("Thiếu khoảng cách", "Nhập khoảng cách giao hàng (km), ví dụ 4.5.", "Đóng");
            return;
        }
        var gio = (_oGio?.Text ?? "").Trim();
        var r = await ApiClient.PostAsync<JsonElement>("api/mobile/admin/phi-giao/tinh-thu", new
        {
            khoangCachKm = km,
            giaTriMon = So(_oMon?.Text),
            gio = gio == "" ? null : gio,
            mua = _swMua?.IsToggled ?? false,
            ngoaiThanh = _swNgoai?.IsToggled ?? false,
            uuDai = So(_oUuDai?.Text),
        });
        if (!r.ThanhCong)
        {
            await DisplayAlert("Không tính được", string.IsNullOrWhiteSpace(r.ThongDiep) ? "Lỗi không xác định." : r.ThongDiep, "Đóng");
            return;
        }
        var d = r.DuLieu;
        var c = J.Doi(d, "chiTiet");
        _ketQua.Children.Clear();
        _ketQua.Add(DongTrai("Phí cơ bản", AdminUi.Tien(J.D(c, "phiCoBan"))));
        _ketQua.Add(DongTrai("Phí km vượt", AdminUi.Tien(J.D(c, "phiVuotKm"))));
        _ketQua.Add(DongTrai("Phụ phí ngoại thành", AdminUi.Tien(J.D(c, "phuPhiNgoaiThanh"))));
        _ketQua.Add(DongTrai("Phụ phí giờ cao điểm" + (J.B(c, "caoDiem") ? $" (lúc {J.S(d, "gio")})" : ""), AdminUi.Tien(J.D(c, "phuPhiCaoDiem"))));
        _ketQua.Add(DongTrai("Phụ phí mưa lớn", AdminUi.Tien(J.D(c, "phuPhiMua"))));
        if (J.B(c, "chamToiThieu")) _ketQua.Add(AdminUi.Nhan("• Đã nâng lên phí tối thiểu.", 11.5, mo: true));
        if (J.B(c, "chamToiDa")) _ketQua.Add(AdminUi.Nhan("• Đã giới hạn ở phí tối đa.", 11.5, mo: true));
        _ketQua.Add(DongTrai("Phí ship gốc", AdminUi.Tien(J.D(d, "phiShipGoc")), AdminUi.Tim));
        _ketQua.Add(DongTrai("Ưu đãi trên phí ship", "-" + AdminUi.Tien(J.D(d, "uuDai"))));
        _ketQua.Add(DongTrai("Khách trả phí ship", AdminUi.Tien(J.D(d, "khachTraPhiShip"))));
        _ketQua.Add(DongTrai("Tổng khách trả (món + ship)", AdminUi.Tien(J.D(d, "tongKhachTra")), AdminUi.Tim));
        _ketQua.Add(DongTrai($"Tài xế nhận ({Ty(J.D(d, "tyLeTaiXe"))} phí gốc)", AdminUi.Tien(J.D(d, "tienTaiXe")), AdminUi.Xanh));
        var chenh = J.D(d, "chenhLechPhiShip");
        _ketQua.Add(DongTrai("Chênh lệch (ứng dụng giữ lại)", AdminUi.Tien(chenh), chenh < 0 ? AdminUi.Do : AdminUi.Tim));
    }
}
