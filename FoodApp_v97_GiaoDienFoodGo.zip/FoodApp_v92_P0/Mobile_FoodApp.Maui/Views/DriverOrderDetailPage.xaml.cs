using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Chi tiết một đơn của tài xế — GET api/mobile/tai-xe/don-hang/{id} (chỉ đơn thuộc chuyến của chính tài xế).</summary>
[QueryProperty(nameof(MaDon), "id")]
public partial class DriverOrderDetailPage : ContentPage
{
    private DonTaiXeChiTiet? _don;
    public string MaDon { get; set; } = "";

    public DriverOrderDetailPage() => InitializeComponent();

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (!int.TryParse(MaDon, out var id)) { Loi("Mã đơn không hợp lệ."); return; }
        var r = await ApiClient.GetAsync<DonTaiXeChiTiet>($"api/mobile/tai-xe/don-hang/{id}");
        if (!r.ThanhCong || r.DuLieu is null) { Loi(string.IsNullOrWhiteSpace(r.ThongDiep) ? "Không tải được chi tiết đơn." : r.ThongDiep); return; }
        _don = r.DuLieu;
        Ve(_don);
    }

    private void Loi(string msg) { LblLoi.Text = msg; LblLoi.IsVisible = true; }

    private void Ve(DonTaiXeChiTiet d)
    {
        LblLoi.IsVisible = false;
        LblTieuDe.Text = $"#{d.MaDonHang}";
        var nhan = d.TrangThaiGiao switch { "DaNhan" => "Chờ lấy hàng", "DangGiao" => "Đang giao", "GiaoThanhCong" => "Hoàn thành", "GiaoThatBai" => "Đã hủy", _ => d.TrangThaiGiao };
        LblTrangThai.Text = nhan;
        var item = new DonTaiXeItem { TrangThaiGiao = d.TrangThaiGiao };
        LblTrangThai.TextColor = Color.FromArgb(item.MauChuTrangThai);
        ChipTrangThai.BackgroundColor = Color.FromArgb(item.MauNenTrangThai);
        LblThoiGian.Text = d.NgayDat.ToString("HH:mm - dd/MM/yyyy") + (string.IsNullOrWhiteSpace(d.LyDoThatBai) ? "" : $"\n{d.LyDoThatBai}");

        LblQuan.Text = d.TenGianHang;
        LblDiaChiQuan.Text = d.DiaChiGianHang;
        BtnGoiQuan.IsVisible = !string.IsNullOrWhiteSpace(d.SdtGianHang);

        DsMon.Children.Clear();
        foreach (var m in d.ChiTiet)
        {
            var dong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            dong.Add(new Label { Text = $"{m.SoLuong} × {m.TenMon}", FontSize = 13.5 }, 0);
            dong.Add(new Label { Text = $"{m.ThanhTien:N0}đ", FontSize = 13.5 }, 1);
            DsMon.Children.Add(dong);
        }
        LblTongTien.Text = $"{d.TongTien:N0}đ";

        LblKhach.Text = d.TenKhach;
        LblSdtKhach.Text = d.SdtKhach;
        LblSdtKhach.IsVisible = d.HienSdtKhach && !string.IsNullOrWhiteSpace(d.SdtKhach);
        LblDiaChiGiao.Text = d.DiaChiGiaoHang;
        LblGhiChu.IsVisible = !string.IsNullOrWhiteSpace(d.GhiChu);
        LblGhiChu.Text = $"Ghi chú: {d.GhiChu}";
        BtnGoiKhach.IsVisible = d.HienSdtKhach && !string.IsNullOrWhiteSpace(d.SdtKhach);
        LblAnSdt.IsVisible = !d.HienSdtKhach;

        LblHinhThuc.Text = $"{d.HinhThucThanhToan} · {d.TrangThaiThanhToan}";
        LblCanThu.Text = d.LaCod
            ? (d.SoTienCanThu > 0 ? $"Cần thu hộ: {d.SoTienCanThu:N0}đ" : d.TienThuCOD is decimal tt ? $"Đã thu: {tt:N0}đ" : "COD — đơn đã kết thúc")
            : "Không cần thu tiền mặt";
        LblPhi.Text = $"Phí giao (thu nhập của bạn): {d.PhiGiaoHang:N0}đ";
        BtnDoiSoatCod.IsVisible = d.LaCod;     // đơn thu hộ: dẫn tới trang đối soát COD
        BtnHuyNhan.IsVisible = d.TrangThaiGiao == "DaNhan";   // v86: chỉ khi đã nhận nhưng chưa lấy hàng
    }

    /// <summary>Tài xế hủy nhận đơn (chỉ trước khi lấy hàng): lý do bắt buộc; đơn quay lại hệ thống tìm tài xế khác. Hủy nhiều lần sẽ bị tạm ngừng nhận đơn.</summary>
    private async void OnHuyNhanClicked(object? sender, EventArgs e)
    {
        if (_don is null) return;
        var ly = await DisplayActionSheet("Lý do hủy nhận đơn", "Quay lại", null, "Xe gặp sự cố", "Có việc đột xuất", "Quán quá xa / không kịp", "Quán đóng cửa hoặc không liên lạc được", "Lý do khác");
        if (string.IsNullOrEmpty(ly) || ly == "Quay lại") return;
        if (ly == "Lý do khác")
        {
            ly = await this.NhapAsync("Lý do hủy", "Nhập lý do (bắt buộc)", "Tiếp tục", "Hủy", maxLength: 150) ?? "";
            if (ly.Trim().Length < 3) return;
        }
        if (!await DisplayAlert("Hủy nhận đơn", $"Hủy nhận đơn #{_don.MaDonHang}? Việc hủy được ghi nhận; hủy nhiều lần bạn sẽ bị tạm ngừng nhận đơn.", "Hủy nhận", "Giữ đơn")) return;
        var kq = await ApiClient.PostAsync<System.Text.Json.JsonElement>($"api/mobile/tai-xe/don-hang/{_don.MaDonHang}/huy-nhan", new { lyDo = ly.Trim() });
        if (!kq.ThanhCong) { await DisplayAlert("Không hủy được", kq.ThongDiep, "Đóng"); return; }
        RealtimeService.YeuCauDongBo();
        await DisplayAlert("Đã hủy nhận đơn", "Đơn được chuyển cho tài xế khác.", "OK");
        await Shell.Current.GoToAsync("..");
    }

    private async void OnDoiSoatCodClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverCodPage));

    private async void OnGoiQuanClicked(object? sender, EventArgs e) => await LienLac.GoiAsync(_don?.SdtGianHang);
    private async void OnGoiKhachClicked(object? sender, EventArgs e) => await LienLac.GoiAsync(_don?.SdtKhach);
}
