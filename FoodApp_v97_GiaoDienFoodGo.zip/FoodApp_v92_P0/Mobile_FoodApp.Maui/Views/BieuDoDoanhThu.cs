using Microsoft.Maui.Graphics;

namespace FoodApp.Maui.Views;

/// <summary>Biểu đồ đường + vùng tô cho doanh thu theo thời gian (vẽ bằng Microsoft.Maui.Graphics, không cần thư viện ngoài).</summary>
public class BieuDoDoanhThu : GraphicsView
{
    private readonly Ve _ve = new();

    public BieuDoDoanhThu()
    {
        Drawable = _ve;
        HeightRequest = 200;
        SemanticProperties.SetDescription(this, "Biểu đồ doanh thu theo thời gian");
    }

    public void Dat(IReadOnlyList<string> nhan, IReadOnlyList<decimal> giaTri)
    {
        _ve.Nhan = nhan.ToArray();
        _ve.GiaTri = giaTri.Select(x => (double)x).ToArray();
        var tong = giaTri.Sum();
        SemanticProperties.SetDescription(this, $"Biểu đồ doanh thu, tổng {tong:N0} đồng trong {giaTri.Count} mốc");
        Invalidate();
    }

    private sealed class Ve : IDrawable
    {
        public string[] Nhan = Array.Empty<string>();
        public double[] GiaTri = Array.Empty<double>();
        private static readonly Color Tim = Color.FromArgb("#5B3FD9"), Luoi = Color.FromArgb("#E3E6F5"), Chu = Color.FromArgb("#6B7280"), Navy = Color.FromArgb("#14193A");

        private static string Tien(double v) => v >= 1_000_000 ? $"{v / 1_000_000:0.#}tr" : v >= 1_000 ? $"{v / 1_000:0.#}k" : $"{v:0}";

        private static double LamTron(double max)
        {
            if (max <= 0) return 1;
            var mu = Math.Pow(10, Math.Floor(Math.Log10(max)));
            foreach (var b in new[] { 1.0, 2, 2.5, 5, 10 }) if (b * mu >= max) return b * mu;
            return 10 * mu;
        }

        public void Draw(ICanvas c, RectF r)
        {
            const float trai = 42, phai = 12, tren = 12, duoi = 24;
            float rong = r.Width - trai - phai, cao = r.Height - tren - duoi;
            if (rong <= 0 || cao <= 0) return;
            var n = GiaTri.Length;
            var tran = LamTron(n == 0 ? 0 : GiaTri.Max());

            c.FontSize = 10; c.FontColor = Chu; c.StrokeSize = 1; c.StrokeColor = Luoi;
            for (int i = 0; i <= 4; i++)
            {
                float y = tren + cao * (1 - i / 4f);
                c.StrokeDashPattern = i == 0 ? null : new float[] { 3, 3 };
                c.DrawLine(trai, y, trai + rong, y);
                c.DrawString(Tien(tran * i / 4), 0, y - 7, trai - 6, 14, HorizontalAlignment.Right, VerticalAlignment.Center);
            }
            c.StrokeDashPattern = null;
            if (n == 0) { c.DrawString("Chưa có dữ liệu", trai, tren + cao / 2 - 8, rong, 16, HorizontalAlignment.Center, VerticalAlignment.Center); return; }

            PointF Diem(int i) => new(n == 1 ? trai + rong / 2 : trai + rong * i / (n - 1f), tren + cao * (float)(1 - GiaTri[i] / tran));

            var vung = new PathF(); vung.MoveTo(Diem(0).X, tren + cao);
            for (int i = 0; i < n; i++) vung.LineTo(Diem(i));
            vung.LineTo(Diem(n - 1).X, tren + cao); vung.Close();
            c.FillColor = Tim.WithAlpha(0.14f); c.FillPath(vung);

            var duong = new PathF(); duong.MoveTo(Diem(0));
            for (int i = 1; i < n; i++) duong.LineTo(Diem(i));
            c.StrokeColor = Tim; c.StrokeSize = 2.5f; c.StrokeLineJoin = LineJoin.Round; c.DrawPath(duong);

            if (n <= 14) { c.FillColor = Colors.White; foreach (var i in Enumerable.Range(0, n)) { var p = Diem(i); c.FillCircle(p, 4.5f); c.StrokeSize = 2; c.DrawCircle(p, 4.5f); } }

            var buoc = (int)Math.Ceiling(n / 7.0);
            c.FontColor = Chu; c.FontSize = 10;
            for (int i = 0; i < n; i += buoc)
                c.DrawString(i < Nhan.Length ? Nhan[i] : "", Diem(i).X - 24, tren + cao + 5, 48, 14, HorizontalAlignment.Center, VerticalAlignment.Center);

            var cuoi = Diem(n - 1); var chuNoi = Tien(GiaTri[n - 1]);
            float w = 12 + chuNoi.Length * 7, h = 22, x = Math.Clamp(cuoi.X - w / 2, 0, r.Width - w), y0 = Math.Max(0, cuoi.Y - h - 8);
            c.FillColor = Navy; c.FillRoundedRectangle(x, y0, w, h, 6);
            c.FontColor = Colors.White; c.FontSize = 11; c.DrawString(chuNoi, x, y0, w, h, HorizontalAlignment.Center, VerticalAlignment.Center);
        }
    }
}
