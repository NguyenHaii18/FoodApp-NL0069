using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// v91 — Trung tâm hỗ trợ của tài xế: gửi nhanh các loại báo cáo (mất mạng, lỗi GPS, tai nạn / sự cố xe, quán chưa chuẩn bị món,
/// khách không nghe máy, sai địa chỉ, thiếu / sai món...), chat với điều phối (qua đơn đang giao) và theo dõi tiến độ
/// các yêu cầu đã gửi. Ảnh chứng minh đính kèm ở màn "Báo sự cố" (DriverSuCoPage).
/// </summary>
public sealed class DriverHoTroPage : ContentPage
{
    private readonly VerticalStackLayout _nd = new() { Spacing = 10, Padding = new Thickness(16, 12, 16, 28) };
    private readonly VerticalStackLayout _tienDo = new() { Spacing = 6 };

    private static readonly (string Icon, string Ten, string Loai, string MoTa)[] Nhanh =
    {
        ("📶", "Mất mạng / không có kết nối", "MatMang", "Tôi bị mất mạng, không nhận / cập nhật được đơn."),
        ("📍", "Lỗi GPS / sai vị trí", "LoiGps", "GPS của tôi báo sai vị trí hoặc không định vị được."),
        ("🚑", "Tai nạn / sự cố phương tiện", "TaiNan", "Tôi gặp tai nạn hoặc xe hỏng trong lúc giao."),
        ("🍳", "Nhà hàng chưa chuẩn bị món", "QuanChuanBiCham", "Đã đến quán nhưng món chưa xong."),
        ("📵", "Khách không nghe máy", "KhachKhongLienLac", "Đã gọi khách nhiều lần nhưng không liên lạc được."),
        ("🧭", "Sai địa chỉ giao hàng", "SaiDiaChi", "Địa chỉ khách ghi không tìm thấy / không đúng."),
        ("🚪", "Khách không có mặt", "KhachKhongNhan", "Đến điểm giao nhưng khách không có mặt."),
        ("🥡", "Quán giao thiếu món", "ThieuMon", "Món nhận từ quán bị thiếu."),
        ("🔁", "Quán giao sai món", "SaiMon", "Món nhận từ quán không đúng với đơn."),
        ("⚖️", "Tranh chấp / khiếu nại", "TranhChapGiaoHang", "")
    };

    public DriverHoTroPage()
    {
        Title = "Hỗ trợ tài xế";
        BackgroundColor = DriverPalette.Get("Background");
        Content = new RefreshView { Command = new Command(async () => await TaiTienDoAsync()), Content = new ScrollView { Content = _nd } };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        _nd.Children.Clear();
        _nd.Add(new Label { Text = "Chọn tình huống để gửi nhanh cho điều phối. Bạn có thể kèm ảnh chứng minh ở bước tiếp theo.", FontSize = 12.5, TextColor = DriverPalette.Get("TextGrey") });

        foreach (var (icon, ten, loai, moTa) in Nhanh)
        {
            var l = loai; var m = moTa;
            var nut = new Button { Text = $"{icon}  {ten}", CornerRadius = 12, HeightRequest = 46, FontSize = 14, HorizontalOptions = LayoutOptions.Fill, BackgroundColor = DriverPalette.Get("PrimarySoft"), TextColor = DriverPalette.Get("Primary") };
            nut.Clicked += async (_, _) =>
            {
                var don = MockData.DonHangDangGiaoCuaTaiXe?.Id.ToString() ?? "";
                var q = $"{nameof(DriverSuCoPage)}?loai={l}&don={don}" + (m == "" ? "" : "&mota=" + Uri.EscapeDataString(m));
                await Shell.Current.GoToAsync(q);
            };
            _nd.Add(nut);
        }

        var chat = new Button { Text = "💬 Chat với điều phối (đơn đang giao)", CornerRadius = 12, HeightRequest = 46, BackgroundColor = DriverPalette.Get("Primary"), TextColor = Colors.White };
        chat.Clicked += async (_, _) =>
        {
            var d = MockData.DonHangDangGiaoCuaTaiXe;
            if (d is null) { await DisplayAlert("Chưa có đơn", "Chat với điều phối gắn với đơn đang giao. Khi chưa có đơn, hãy gửi yêu cầu hỗ trợ ở trên — điều phối sẽ phản hồi tại mục Tiến độ bên dưới.", "Đóng"); return; }
            await ChatPage.MoAsync(d.Id.ToString(), "TaiXe", "Điều phối", "");
        };
        _nd.Add(chat);
        _nd.Add(new Label { Text = "📋 Tiến độ yêu cầu hỗ trợ của tôi", FontAttributes = FontAttributes.Bold, FontSize = 15, Margin = new Thickness(0, 8, 0, 0) });
        _nd.Add(_tienDo);
        await TaiTienDoAsync();
    }

    private async Task TaiTienDoAsync()
    {
        _tienDo.Children.Clear();
        var r = await ApiClient.GetAsync<SuCoDanhSachDto>("api/mobile/tai-xe/su-co");
        if (!r.ThanhCong || r.DuLieu is null)
        {
            _tienDo.Add(new Label { Text = "Cần kết nối máy chủ để xem tiến độ.", FontSize = 12.5, TextColor = DriverPalette.Get("TextGrey") });
            return;
        }
        if (r.DuLieu.Items.Count == 0) _tienDo.Add(new Label { Text = "Bạn chưa gửi yêu cầu nào.", FontSize = 12.5, TextColor = DriverPalette.Get("TextGrey") });
        foreach (var x in r.DuLieu.Items.Take(15))
        {
            var ten = r.DuLieu.Loais.FirstOrDefault(l => l.Ma == x.Loai)?.Ten ?? x.Loai;
            var buoc = x.TrangThai == "DaXuLy" ? "✅ Đã xử lý" : x.TrangThai == "DangXuLy" ? "🛠 Đang xử lý" : "⏳ Đã gửi — chờ tiếp nhận";
            var st = new VerticalStackLayout { Spacing = 2 };
            st.Add(new Label { Text = ten + (x.MaDonHang is int m ? $" · đơn #{m}" : ""), FontAttributes = FontAttributes.Bold, FontSize = 13 });
            st.Add(new Label { Text = $"{buoc} · {x.NgayTao:dd/MM HH:mm}", FontSize = 12 });
            if (!string.IsNullOrWhiteSpace(x.PhanHoiQuanTri)) st.Add(new Label { Text = "Phản hồi: " + x.PhanHoiQuanTri, FontSize = 12.5, TextColor = DriverPalette.Get("Primary") });
            _tienDo.Add(new Border { Padding = 12, StrokeThickness = 1, Stroke = DriverPalette.Get("BorderColor"), StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(12) }, Content = st });
        }
    }
}
