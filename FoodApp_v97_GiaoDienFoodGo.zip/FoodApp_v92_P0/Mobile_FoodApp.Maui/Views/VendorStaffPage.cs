using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Chủ quán: quản lý nhân viên và phân quyền (Đơn hàng / Thực đơn / Khuyến mãi / Đánh giá / Tài chính).
/// Dữ liệu nằm trên máy chủ (bảng NhanVienGianHang) nên cần kết nối. Nhân viên đăng nhập ở "Cổng Đối Tác" → "Đăng nhập bằng tài khoản nhân viên".
/// </summary>
public sealed class VendorStaffPage : ContentPage
{
    private sealed class DsNhanVienDto { public List<NhanVienDto> NhanVien { get; set; } = new(); public int ToiDa { get; set; } = 20; }

    private readonly VerticalStackLayout _nd = VendorChiTietUi.Khung();
    private string Goc => $"api/mobile/gian-hang/{MockData.GianHangHienTai.Id}/nhan-vien";

    public VendorStaffPage()
    {
        Title = "Nhân viên & phân quyền";
        BackgroundColor = VendorPalette.Get("Background");
        Content = new ScrollView { Content = _nd };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await TaiAsync();
    }

    private async Task TaiAsync()
    {
        _nd.Children.Clear();
        if (NhanVienQuan.LaNhanVien)
        {
            _nd.Children.Add(VendorChiTietUi.Chu("Chỉ chủ quán mới quản lý được nhân viên.", true));
            return;
        }
        if (!DuLieuService.DangOnline || string.IsNullOrEmpty(ApiClient.Token))
        {
            _nd.Children.Add(VendorChiTietUi.The(VendorChiTietUi.Tieu("Cần kết nối máy chủ"),
                VendorChiTietUi.Chu("Tài khoản nhân viên được lưu trên máy chủ để nhân viên đăng nhập từ máy của họ.", true)));
            return;
        }

        var r = await ApiClient.GetAsync<DsNhanVienDto>(Goc);
        if (!r.ThanhCong || r.DuLieu is null)
        {
            _nd.Children.Add(VendorChiTietUi.Chu("Không tải được danh sách: " + r.ThongDiep, true));
            return;
        }
        var ds = r.DuLieu.NhanVien;

        _nd.Children.Add(VendorChiTietUi.Chu($"{ds.Count}/{r.DuLieu.ToiDa} nhân viên. Mỗi nhân viên chỉ thấy và làm được những mục bạn cấp quyền.", true));
        _nd.Children.Add(VendorChiTietUi.Nut("➕ Thêm nhân viên", true, () => FormAsync(null)));

        if (ds.Count == 0) _nd.Children.Add(VendorChiTietUi.Chu("Chưa có nhân viên nào.", true));
        foreach (var nv in ds)
        {
            var n = nv;
            var quyen = n.Quyen.Count == 0 ? "chưa có quyền" : string.Join(" · ", n.Quyen.Select(NhanVienQuan.Nhan));
            var the = VendorChiTietUi.The(
                VendorChiTietUi.Tieu($"{n.HoTen}" + (n.TrangThai ? "" : "  🔒 đã khóa")),
                VendorChiTietUi.Chu($"Tên đăng nhập: {n.TenDangNhap}", true),
                VendorChiTietUi.Chu("Quyền: " + quyen),
                VendorChiTietUi.Chu(n.LanDangNhapCuoi is { } l ? $"Đăng nhập gần nhất: {l:HH:mm dd/MM/yyyy}" : "Chưa đăng nhập lần nào", true));
            var tap = new TapGestureRecognizer();
            tap.Tapped += async (_, _) => await MenuAsync(n);
            the.GestureRecognizers.Add(tap);
            _nd.Children.Add(the);
        }
        _nd.Children.Add(VendorChiTietUi.Chu("Chạm vào một nhân viên để sửa quyền, đặt lại mật khẩu, khóa hoặc xóa.", true));
    }

    private async Task MenuAsync(NhanVienDto n)
    {
        var chon = await DisplayActionSheet(n.HoTen, "Đóng", null, "Sửa quyền / họ tên", "Đặt lại mật khẩu", n.TrangThai ? "Khóa tài khoản" : "Mở khóa", "Xóa nhân viên");
        switch (chon)
        {
            case "Sửa quyền / họ tên": await FormAsync(n); break;
            case "Đặt lại mật khẩu":
                var mk = await this.NhapAsync("Đặt lại mật khẩu", $"Mật khẩu mới cho {n.HoTen} (tối thiểu 6 ký tự):", "Lưu", "Hủy", maxLength: 50);
                if (mk is null) return;
                var r1 = await ApiClient.PutAsync<object>($"{Goc}/{n.MaNV}/mat-khau", new { matKhau = mk });
                await DisplayAlert(r1.ThanhCong ? "Đã đặt lại" : "Chưa đặt được", r1.ThanhCong ? "Hãy báo mật khẩu mới cho nhân viên." : r1.ThongDiep, "OK");
                break;
            case "Khóa tài khoản":
            case "Mở khóa":
                var r2 = await ApiClient.PutAsync<object>($"{Goc}/{n.MaNV}", new { trangThai = !n.TrangThai });
                if (!r2.ThanhCong) await DisplayAlert("Chưa cập nhật được", r2.ThongDiep, "OK");
                await TaiAsync();
                break;
            case "Xóa nhân viên":
                if (!await DisplayAlert("Xóa nhân viên", $"Xóa tài khoản của {n.HoTen}? Họ sẽ không đăng nhập được nữa.", "Xóa", "Hủy")) return;
                var r3 = await ApiClient.DeleteAsync<object>($"{Goc}/{n.MaNV}");
                if (!r3.ThanhCong) await DisplayAlert("Chưa xóa được", r3.ThongDiep, "OK");
                await TaiAsync();
                break;
        }
    }

    /// <summary>Biểu mẫu thêm mới (sua == null) hoặc sửa họ tên + quyền.</summary>
    private Task FormAsync(NhanVienDto? sua)
    {
        _nd.Children.Clear();
        var moi = sua is null;
        var tenDn = new Entry { Placeholder = "Tên đăng nhập (chữ thường, số, . _ ; 4–30 ký tự)", Text = sua?.TenDangNhap ?? "", IsEnabled = moi, Keyboard = Keyboard.Default };
        var hoTen = new Entry { Placeholder = "Họ tên nhân viên", Text = sua?.HoTen ?? "" };
        var matKhau = new Entry { Placeholder = "Mật khẩu (tối thiểu 6 ký tự)", IsPassword = true };
        var ckbs = new List<(string Ma, CheckBox Cb)>();

        var form = new List<View> { VendorChiTietUi.Tieu(moi ? "Thêm nhân viên" : "Sửa nhân viên"), hoTen, tenDn };
        if (moi) form.Add(matKhau);
        form.Add(VendorChiTietUi.Tieu("Quyền được cấp"));
        foreach (var (ma, ten, mota) in NhanVienQuan.TatCaQuyen)
        {
            var cb = new CheckBox { IsChecked = sua?.Quyen.Contains(ma) ?? ma == NhanVienQuan.DonHang, VerticalOptions = LayoutOptions.Start };
            ckbs.Add((ma, cb));
            var chu = new VerticalStackLayout { Spacing = 0 };
            chu.Children.Add(new Label { Text = ten, FontAttributes = FontAttributes.Bold, FontSize = 13.5, TextColor = Colors.Black });
            chu.Children.Add(VendorChiTietUi.Chu(mota, true));
            var dong = new HorizontalStackLayout { Spacing = 6 };
            dong.Children.Add(cb); dong.Children.Add(chu);
            var tap = new TapGestureRecognizer();
            tap.Tapped += (_, _) => cb.IsChecked = !cb.IsChecked;
            chu.GestureRecognizers.Add(tap);
            form.Add(dong);
        }
        form.Add(VendorChiTietUi.Chu("Hồ sơ quán, giấy tờ và quản lý nhân viên luôn chỉ dành cho chủ quán.", true));
        _nd.Children.Add(VendorChiTietUi.The(form.ToArray()));

        _nd.Children.Add(VendorChiTietUi.Nut(moi ? "Tạo nhân viên" : "Lưu thay đổi", true, async () =>
        {
            var quyen = ckbs.Where(x => x.Cb.IsChecked).Select(x => x.Ma).ToList();
            if (string.IsNullOrWhiteSpace(hoTen.Text)) { await DisplayAlert("Thiếu thông tin", "Vui lòng nhập họ tên.", "OK"); return; }
            if (quyen.Count == 0) { await DisplayAlert("Thiếu quyền", "Hãy chọn ít nhất một quyền.", "OK"); return; }
            ApiKetQua<object> kq;
            if (moi)
            {
                if (string.IsNullOrWhiteSpace(tenDn.Text)) { await DisplayAlert("Thiếu thông tin", "Vui lòng nhập tên đăng nhập.", "OK"); return; }
                kq = await ApiClient.PostAsync<object>(Goc, new { tenDangNhap = tenDn.Text.Trim(), hoTen = hoTen.Text.Trim(), matKhau = matKhau.Text ?? "", quyen });
            }
            else kq = await ApiClient.PutAsync<object>($"{Goc}/{sua!.MaNV}", new { hoTen = hoTen.Text.Trim(), quyen });
            if (!kq.ThanhCong) { await DisplayAlert("Chưa lưu được", kq.ThongDiep, "OK"); return; }
            await TaiAsync();
        }));
        _nd.Children.Add(VendorChiTietUi.Nut("Hủy", false, TaiAsync));
        return Task.CompletedTask;
    }
}
