using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

public partial class AdminLoginPage : ContentPage
{
    public AdminLoginPage()
    {
        InitializeComponent();
        GhiNhoDangNhap.Nap("quantri", EntryEmail, EntryMatKhau, ChkGhiNho);
    }

    private async void OnDangNhapClicked(object sender, EventArgs e)
    {
        LblLoi.IsVisible = false;

        if (string.IsNullOrWhiteSpace(EntryEmail.Text) || !EntryEmail.Text.Contains('@'))
        {
            HienLoi("Email không hợp lệ");
            return;
        }
        if (string.IsNullOrWhiteSpace(EntryMatKhau.Text))
        {
            HienLoi("Vui lòng nhập mật khẩu");
            return;
        }

        LoadingIndicator.IsVisible = true;
        LoadingIndicator.IsRunning = true;
        BtnDangNhap.IsEnabled = false;

        try
        {
            var email = EntryEmail.Text.Trim();
            QuanTriVien? dangNhap;
            if (DuLieuService.DangOnline)
            {
                var kq = await ApiClient.PostAsync<DangNhapQuanTriDto>("api/mobile/admin/dang-nhap", new { email, matKhau = EntryMatKhau.Text });
                if (!kq.ThanhCong)
                {
                    NhatKyService.Ghi("QuanTri", email, "Đăng nhập thất bại", chiTiet: kq.ThongDiep + " · " + NhatKyService.ThietBi(), thanhCong: false);
                    HienLoi(kq.ThongDiep);
                    return;
                }
                ApiClient.Token = kq.DuLieu?.Token;
                // Web có 3 cấp: SuperAdmin → Admin tổng, QuanLy → Quản lý, NhanVien → Nhân viên. Không nhận được vai trò thì lấy quyền thấp nhất.
                var vaiTro = (kq.DuLieu?.VaiTro ?? "").ToLowerInvariant() switch
                {
                    "superadmin" => VaiTroQuanTri.AdminTong,
                    "quanly" => VaiTroQuanTri.QuanLy,
                    _ => VaiTroQuanTri.NhanVienHoTro,
                };
                dangNhap = new QuanTriVien
                {
                    Id = "online", HoTen = kq.DuLieu?.HoTen ?? email, Email = email, VaiTro = vaiTro,
                    // Quyền chi tiết do Admin tổng cấp trên Web (Phân quyền quản trị) — app theo đúng danh sách server trả về.
                    QuyenServer = new HashSet<string>(kq.DuLieu?.Quyen ?? new List<string>(), StringComparer.OrdinalIgnoreCase),
                };
                await DuLieuService.TaiQuanTriAsync();
            }
            else
            {
                await Task.Delay(300);
                dangNhap = QuanTriStore.TimTheoEmail(email);
                if (dangNhap is null || !QuanTriStore.KiemTraMatKhau(dangNhap, EntryMatKhau.Text))
                {
                    NhatKyService.Ghi("QuanTri", email, "Đăng nhập thất bại", chiTiet: "Sai email hoặc mật khẩu · " + NhatKyService.ThietBi(), thanhCong: false);
                    HienLoi("Email hoặc mật khẩu không đúng");
                    return;
                }
                if (dangNhap.TaiKhoanBiKhoa)
                {
                    NhatKyService.Ghi("QuanTri:" + dangNhap.VaiTro, dangNhap.Email, "Đăng nhập thất bại", chiTiet: "Tài khoản bị khóa · " + NhatKyService.ThietBi(), thanhCong: false);
                    HienLoi("Tài khoản quản trị đang bị khóa. Hãy liên hệ Admin tổng.");
                    return;
                }
            }

            MockData.QuanTriVienHienTai = dangNhap;
            NhatKyService.GhiQuanTri("Đăng nhập", chiTiet: NhatKyService.ThietBi());
            GhiNhoDangNhap.Luu("quantri", EntryEmail.Text, EntryMatKhau.Text, ChkGhiNho.IsChecked);

            await Shell.Current.GoToAsync(nameof(AdminHomePage));
        }
        finally
        {
            LoadingIndicator.IsVisible = false;
            LoadingIndicator.IsRunning = false;
            BtnDangNhap.IsEnabled = true;
        }
    }

    private void HienLoi(string thongDiep)
    {
        LblLoi.Text = thongDiep;
        LblLoi.IsVisible = true;
    }

    private async void OnQuenMatKhauTapped(object sender, EventArgs e)
        => await DisplayAlert("Quên mật khẩu", "Vui lòng liên hệ Admin tổng để được cấp lại mật khẩu quản trị.", "Đóng");

    private async void OnQuayLaiTapped(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("..");
    }
}
