using FoodApp.Maui.Models;

namespace FoodApp.Maui.Views;

/// <summary>Kết quả đặt hàng: mã đơn, tóm tắt, lối vào Chi tiết đơn hàng.</summary>
[QueryProperty(nameof(DonId), "DonId")]
public partial class DatHangThanhCongPage : ContentPage
{
    public string DonId { get; set; } = "";
    public DatHangThanhCongPage() { InitializeComponent(); }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        LblMaDon.Text = $"Mã đơn: #{DonId}";
        var don = MockData.LichSuDonHang.FirstOrDefault(d => d.Id == DonId);
        LblTomTat.Text = don is null ? "" : $"{don.TenGianHang} · {don.TongThanhToan:N0}đ · {don.HinhThucHienThi}";
    }

    private async void OnXemChiTietClicked(object? s, EventArgs e)
    {
        OrderTrackingPage.DonCanMo = DonId;
        await Shell.Current.GoToAsync("//chinh/don-hang");
    }

    private async void OnVeTrangChuClicked(object? s, EventArgs e) => await Shell.Current.GoToAsync("//chinh/trang-chu");
}
