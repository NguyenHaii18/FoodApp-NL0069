using System.Text.Json;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

// =====================================================================================================================
// v47f — Quản trị: Banner trang chủ · Câu hỏi thường gặp · Khoản phải trả (quán / tài xế)
// API: api/mobile/admin/banner, /faq, /tai-chinh/phai-tra (AdminMobileNoiDungApiController). Ghi banner/FAQ cần quyền "ThongBao",
// đánh dấu đã trả tài xế cần quyền "ThanhToan" (server kiểm tra; app chỉ hiện lỗi server trả về).
// =====================================================================================================================

/// <summary>Quản lý banner trang chủ: xem, thêm (chọn ảnh + tiêu đề + liên kết + thứ tự), bật/tắt, xóa.</summary>
public sealed class AdminBannerPage : AdminListPage
{
    public AdminBannerPage() : base(Cfg()) { }

    private static string AnhDayDu(string? p)
    {
        if (string.IsNullOrWhiteSpace(p)) return "";
        if (Uri.TryCreate(p, UriKind.Absolute, out var u) && (u.Scheme == "http" || u.Scheme == "https")) return p;
        return AppSettings.BaseUrl.TrimEnd('/') + "/" + p.TrimStart('/');
    }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Banner trang chủ",
        Url = (_, _, _) => "api/mobile/admin/banner",
        TomTat = (_, _) => "Banner đang hiển thị ở trang chủ khách (web + app) theo thứ tự nhỏ → lớn, trong khoảng ngày đã đặt.",
        Dong = (_, d) => new AdminDong(J.S(d, "tieuDe"),
            new[]
            {
                $"Thứ tự: {J.L(d, "thuTu")}" + (J.Rong(d, "lienKet") ? "" : $" · 🔗 {J.S(d, "lienKet")}"),
                (J.Rong(d, "ngayBatDau") ? "Từ khi tạo" : "Từ " + J.Ngay(d, "ngayBatDau", "dd/MM/yyyy")) + " → " + (J.Rong(d, "ngayKetThuc") ? "không giới hạn" : J.Ngay(d, "ngayKetThuc", "dd/MM/yyyy")),
            },
            J.B(d, "dangHienThi") ? "Đang hiển thị" : (J.B(d, "trangThai") ? "Ngoài lịch" : "Đã tắt"),
            J.B(d, "dangHienThi") ? AdminUi.Xanh : AdminUi.Xam,
            "🖼", AnhDayDu(J.S(d, "hinhAnh"))),
        HanhDong = _ => new[]
        {
            new AdminHanhDong("Bật / tắt", AdminUi.Tim, null,
                async (p, d) => await AdminUi.Put(p, $"api/mobile/admin/banner/{J.S(d, "maBanner")}/bat-tat", null, "Bật/tắt banner", J.S(d, "tieuDe"))),
            new AdminHanhDong("Sửa", AdminUi.Cam, null, async (p, d) => await SuaAsync(p, d)),
            new AdminHanhDong("Xóa", AdminUi.Do, null, async (p, d) =>
            {
                if (!await p.DisplayAlert("Xóa banner", $"Xóa \"{J.S(d, "tieuDe")}\"?", "Xóa", "Hủy")) return;
                await AdminUi.Xoa(p, $"api/mobile/admin/banner/{J.S(d, "maBanner")}", "Xóa banner", J.S(d, "tieuDe"));
            }),
        },
        HanhDongChung = _ => new[]
        {
            new AdminHanhDong("➕ Thêm banner", AdminUi.Tim, null, async (p, _) => await ThemAsync(p)),
        },
    };

    /// <summary>Đọc ngày dd/MM/yyyy; để trống = không giới hạn. ok=false khi nhập sai định dạng.</summary>
    private static bool DocNgay(string? s, out DateTime? ngay)
    {
        ngay = null;
        if (string.IsNullOrWhiteSpace(s)) return true;
        if (DateTime.TryParseExact(s.Trim(), new[] { "dd/MM/yyyy", "d/M/yyyy" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out var v)) { ngay = v.Date; return true; }
        return false;
    }

    private static string NgayChu(JsonElement d, string k) => J.Rong(d, k) ? "" : J.Ngay(d, k, "dd/MM/yyyy");

    /// <summary>Sửa tiêu đề, liên kết, thứ tự và lịch hiển thị của banner (không đổi ảnh).</summary>
    private static async Task SuaAsync(AdminListPage p, JsonElement d)
    {
        var tieuDe = await AdminUi.Hoi(p, "Sửa banner (1/5)", "Tiêu đề (3–150 ký tự).", null, 3, J.S(d, "tieuDe")); if (tieuDe == null) return;
        var lienKet = await AdminUi.Hoi(p, "Sửa banner (2/5)", "Liên kết khi bấm (/ hoặc http(s)://). Để trống nếu không cần.", null, 0, J.S(d, "lienKet"), Keyboard.Url); if (lienKet == null) return;
        var ttStr = await AdminUi.Hoi(p, "Sửa banner (3/5)", "Thứ tự hiển thị (số nhỏ hiện trước).", null, 0, J.L(d, "thuTu").ToString(), Keyboard.Numeric); if (ttStr == null) return;
        var bd = await AdminUi.Hoi(p, "Sửa banner (4/5)", "Hiển thị từ ngày (dd/MM/yyyy). Để trống = ngay khi bật.", null, 0, NgayChu(d, "ngayBatDau")); if (bd == null) return;
        var kt = await AdminUi.Hoi(p, "Sửa banner (5/5)", "Hiển thị đến hết ngày (dd/MM/yyyy). Để trống = không giới hạn.", null, 0, NgayChu(d, "ngayKetThuc")); if (kt == null) return;
        if (!int.TryParse(ttStr, out var thuTu)) { await p.DisplayAlert("Sai thứ tự", "Thứ tự phải là số nguyên.", "Đóng"); return; }
        if (!DocNgay(bd, out var ngayBd) || !DocNgay(kt, out var ngayKt)) { await p.DisplayAlert("Sai ngày", "Nhập ngày theo dạng dd/MM/yyyy, ví dụ 25/12/2026.", "Đóng"); return; }
        await AdminUi.Put(p, $"api/mobile/admin/banner/{J.S(d, "maBanner")}",
            new { tieuDe, lienKet = lienKet == "" ? null : lienKet, thuTu, ngayBatDau = ngayBd, ngayKetThuc = ngayKt }, "Sửa banner", tieuDe);
    }

    private static async Task ThemAsync(AdminListPage p)
    {
        var tieuDe = await AdminUi.Hoi(p, "Banner mới (1/4)", "Tiêu đề banner (3–150 ký tự).", null, 3); if (tieuDe == null) return;
        var lienKet = await AdminUi.Hoi(p, "Banner mới (2/4)", "Liên kết khi bấm (bắt đầu bằng / hoặc http(s)://). Bỏ trống nếu không cần.", null, 0, "", Keyboard.Url); if (lienKet == null) return;
        var ttStr = await AdminUi.Hoi(p, "Banner mới (3/4)", "Thứ tự hiển thị (số nhỏ hiện trước, mặc định 0).", null, 0, "0", Keyboard.Numeric); if (ttStr == null) return;
        int.TryParse(ttStr, out var thuTu);
        var bd = await AdminUi.Hoi(p, "Banner mới (3b/4)", "Hiển thị từ ngày (dd/MM/yyyy). Để trống = ngay khi tạo.", null, 0, ""); if (bd == null) return;
        var kt = await AdminUi.Hoi(p, "Banner mới (3c/4)", "Hiển thị đến hết ngày (dd/MM/yyyy). Để trống = không giới hạn.", null, 0, ""); if (kt == null) return;
        if (!DocNgay(bd, out var ngayBd) || !DocNgay(kt, out var ngayKt)) { await p.DisplayAlert("Sai ngày", "Nhập ngày theo dạng dd/MM/yyyy, ví dụ 25/12/2026.", "Đóng"); return; }
        string? path;
        try { path = await AnhService.ChonVaLuuAsync("banner_" + DateTime.Now.Ticks, "Chọn ảnh banner", chup: false); }
        catch (Exception ex) { await p.DisplayAlert("Không chọn được ảnh", ex.Message, "Đóng"); return; }
        if (path is null) return;
        var up = await ApiClient.PostFileAsync<UploadAnhDto>("api/mobile/admin/banner/anh", path);
        if (!up.ThanhCong || string.IsNullOrWhiteSpace(up.DuLieu?.ImageUrl))
        { await p.DisplayAlert("Không tải được ảnh", string.IsNullOrWhiteSpace(up.ThongDiep) ? "Lỗi không xác định." : up.ThongDiep, "Đóng"); return; }
        await AdminUi.Post(p, "api/mobile/admin/banner",
            new { tieuDe, hinhAnh = up.DuLieu!.ImageUrl, lienKet = lienKet == "" ? null : lienKet, thuTu, ngayBatDau = ngayBd, ngayKetThuc = ngayKt }, "Tạo banner", tieuDe);
    }
}

/// <summary>Quản lý câu hỏi thường gặp hiển thị ở Trung tâm hỗ trợ của khách.</summary>
public sealed class AdminFaqPage : AdminListPage
{
    public AdminFaqPage() : base(Cfg()) { }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Câu hỏi thường gặp",
        Url = (_, _, _) => "api/mobile/admin/faq",
        TomTat = (_, d) => "Chưa có câu nào thì trang hỗ trợ của khách dùng bộ câu mặc định; thêm câu ở đây sẽ thay thế bộ mặc định.",
        Dong = (_, d) => new AdminDong(J.S(d, "cauHoi"), new[] { J.S(d, "traLoi"), $"Thứ tự: {J.L(d, "thuTu")}" },
            J.B(d, "trangThai") ? "Đang hiển thị" : "Đã ẩn", J.B(d, "trangThai") ? AdminUi.Xanh : AdminUi.Xam),
        HanhDong = _ => new[]
        {
            new AdminHanhDong("Sửa", AdminUi.Tim, null, async (p, d) =>
            {
                var q = await AdminUi.Hoi(p, "Sửa câu hỏi (1/3)", "Câu hỏi (5–300 ký tự).", null, 5, J.S(d, "cauHoi")); if (q == null) return;
                var a = await AdminUi.Hoi(p, "Sửa câu hỏi (2/3)", "Câu trả lời (5–2000 ký tự).", null, 5, J.S(d, "traLoi")); if (a == null) return;
                var tt = await AdminUi.Hoi(p, "Sửa câu hỏi (3/3)", "Thứ tự hiển thị.", null, 0, J.L(d, "thuTu").ToString(), Keyboard.Numeric); if (tt == null) return;
                int.TryParse(tt, out var thuTu);
                await AdminUi.Put(p, $"api/mobile/admin/faq/{J.S(d, "maCauHoi")}", new { cauHoi = q, traLoi = a, thuTu }, "Sửa câu hỏi thường gặp", q);
            }),
            new AdminHanhDong("Ẩn / hiện", AdminUi.Cam, null,
                async (p, d) => await AdminUi.Put(p, $"api/mobile/admin/faq/{J.S(d, "maCauHoi")}/bat-tat", null, "Ẩn/hiện câu hỏi thường gặp", J.S(d, "cauHoi"))),
            new AdminHanhDong("Xóa", AdminUi.Do, null, async (p, d) =>
            {
                if (!await p.DisplayAlert("Xóa câu hỏi", $"Xóa \"{J.S(d, "cauHoi")}\"?", "Xóa", "Hủy")) return;
                await AdminUi.Xoa(p, $"api/mobile/admin/faq/{J.S(d, "maCauHoi")}", "Xóa câu hỏi thường gặp", J.S(d, "cauHoi"));
            }),
        },
        HanhDongChung = _ => new[]
        {
            new AdminHanhDong("➕ Thêm câu hỏi", AdminUi.Tim, null, async (p, _) =>
            {
                var q = await AdminUi.Hoi(p, "Câu hỏi mới (1/3)", "Câu hỏi (5–300 ký tự).", null, 5); if (q == null) return;
                var a = await AdminUi.Hoi(p, "Câu hỏi mới (2/3)", "Câu trả lời (5–2000 ký tự).", null, 5); if (a == null) return;
                var tt = await AdminUi.Hoi(p, "Câu hỏi mới (3/3)", "Thứ tự hiển thị (số nhỏ hiện trước).", null, 0, "0", Keyboard.Numeric); if (tt == null) return;
                int.TryParse(tt, out var thuTu);
                await AdminUi.Post(p, "api/mobile/admin/faq", new { cauHoi = q, traLoi = a, thuTu }, "Thêm câu hỏi thường gặp", q);
            }),
        },
    };
}

/// <summary>Khoản phải trả: tab Gian hàng (tiền hàng − phí nền tảng, chưa trả) và tab Tài xế (phí giao chờ thanh toán). Bấm "Đã trả" để ghi nhận.</summary>
public sealed class AdminPayablesPage : AdminListPage
{
    public AdminPayablesPage() : base(Cfg()) { }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Khoản phải trả",
        Tab = new[] { "Gian hàng", "Tài xế" },
        Url = (_, _, _) => "api/mobile/admin/tai-chinh/phai-tra",
        LayDs = (tab, g) => J.Mang(g, tab == 0 ? "quan" : "taiXe"),
        TomTat = (tab, g) => tab == 0
            ? $"Chưa trả quán: {AdminUi.Tien(J.D(g, "tongPhaiTraQuan"))} · phí nền tảng giữ lại: {AdminUi.Tien(J.D(g, "tongPhiNenTang"))}\nĐã trả quán 30 ngày qua: {AdminUi.Tien(J.D(g, "daTraQuan30Ngay"))}"
            : $"Chưa trả tài xế: {AdminUi.Tien(J.D(g, "tongPhaiTraTaiXe"))} · đã trả 30 ngày qua: {AdminUi.Tien(J.D(g, "daTraTaiXe30Ngay"))}\nTài xế của quán do quán tự trả nên không có ở đây.",
        Dong = (tab, d) => tab == 0
            ? new AdminDong(J.S(d, "ten"), new[]
            {
                $"{J.L(d, "soDon")} đơn đã giao chưa trả · tiền hàng {AdminUi.Tien(J.D(d, "tienHang"))}",
                $"Phí nền tảng {J.D(d, "tyLe") * 100:0.#}%: −{AdminUi.Tien(J.D(d, "phiNenTang"))}",
            }, null, null, "🏬", null, "Phải trả", AdminUi.Tien(J.D(d, "phaiTra")))
            : new AdminDong(J.S(d, "ten"), new[] { $"{J.L(d, "soDon")} đơn chờ thanh toán thu nhập" }, null, null, "🛵", null, "Phải trả", AdminUi.Tien(J.D(d, "phaiTra"))),
        HanhDong = tab => new[]
        {
            new AdminHanhDong(tab == 0 ? "✔ Đã trả cho quán" : "✔ Đã trả cho tài xế", AdminUi.Xanh, null, async (p, d) =>
            {
                var ten = J.S(d, "ten");
                if (!await p.DisplayAlert("Xác nhận đã trả", $"Ghi nhận đã chuyển {AdminUi.Tien(J.D(d, "phaiTra"))} cho \"{ten}\"?\nThao tác được ghi vào nhật ký.", "Đã trả", "Hủy")) return;
                var url = tab == 0 ? $"api/mobile/admin/tai-chinh/gian-hang/{J.S(d, "maGianHang")}/da-tra" : $"api/mobile/admin/tai-chinh/tai-xe/{J.S(d, "maTaiXe")}/da-tra";
                await AdminUi.Put(p, url, null, tab == 0 ? "Đánh dấu đã trả tiền cho quán" : "Đánh dấu đã trả thu nhập tài xế", ten);
            }),
        },
    };
}

/// <summary>Tra cứu khách theo tên / SĐT / email / mã; bấm vào để xem lịch sử đơn; khóa / mở khóa tại chỗ.</summary>
public sealed class AdminCustomerSearchPage : AdminListPage
{
    public AdminCustomerSearchPage() : base(Cfg()) { }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Tra cứu khách hàng",
        GoiYTimKiem = "Tên, SĐT, email hoặc mã khách…",
        Url = (_, q, _) => $"api/mobile/admin/khach-hang/tim?q={AdminUi.Q(q)}",
        Dong = (_, d) => new AdminDong(J.S(d, "hoTen"), new[]
        {
            $"📞 {J.S(d, "sdt")}" + (J.Rong(d, "email") ? "" : $" · ✉ {J.S(d, "email")}"),
            $"{J.L(d, "soDon")} đơn ({J.L(d, "daGiao")} giao · {J.L(d, "daHuy")} hủy) · đã chi {AdminUi.Tien(J.D(d, "tongChi"))}",
            J.Rong(d, "lanCuoi") ? "Chưa có đơn" : $"Đơn gần nhất: {J.Ngay(d, "lanCuoi")}" + (J.L(d, "soKhieuNai") > 0 ? $" · 🚩 {J.L(d, "soKhieuNai")} khiếu nại" : ""),
        }, J.B(d, "biKhoa") ? "Đã khóa" : null, AdminUi.Do, AdminUi.ChuCai(J.S(d, "hoTen"))),
        Mo = async (_, d) => await AdminCustomerOrdersPage.MoAsync((int)J.L(d, "maKH"), J.S(d, "hoTen")),
        HanhDong = _ => new[]
        {
            new AdminHanhDong("📦 Lịch sử đơn", AdminUi.Tim, null, async (_, d) => await AdminCustomerOrdersPage.MoAsync((int)J.L(d, "maKH"), J.S(d, "hoTen"))),
            new AdminHanhDong("📝 Ghi chú", AdminUi.Xam, null, async (p, d) => await GhiChuKhachService.MoAsync(p, (int)J.L(d, "maKH"), J.S(d, "hoTen"))),
            new AdminHanhDong("🔒 Khóa", AdminUi.Do, d => !J.B(d, "biKhoa"), async (p, d) =>
            {
                if (!await p.DisplayAlert("Khóa tài khoản", $"Khóa \"{J.S(d, "hoTen")}\"? Khách sẽ không đăng nhập được cho đến khi mở lại.", "Khóa", "Hủy")) return;
                await AdminUi.Put(p, $"api/mobile/admin/tai-khoan/{J.S(d, "maTK")}/khoa", new { lyDo = "Khóa từ tra cứu khách hàng" }, "Khóa khách hàng", J.S(d, "hoTen"));
            }),
            new AdminHanhDong("🔓 Mở khóa", AdminUi.Xanh, d => J.B(d, "biKhoa"),
                async (p, d) => await AdminUi.Put(p, $"api/mobile/admin/tai-khoan/{J.S(d, "maTK")}/mo-khoa", null, "Mở khóa khách hàng", J.S(d, "hoTen"))),
        },
    };
}

/// <summary>Lịch sử đơn của một khách (dùng lại API tìm đơn với maKH). Bấm một đơn để xem chi tiết.</summary>
public sealed class AdminCustomerOrdersPage : AdminListPage
{
    private static int _maKH;
    private static string _ten = "";

    public static Task MoAsync(int maKH, string ten)
    {
        _maKH = maKH; _ten = ten;
        return Shell.Current.GoToAsync(nameof(AdminCustomerOrdersPage));
    }

    public AdminCustomerOrdersPage() : base(Cfg()) { }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Đơn của " + _ten,
        Loc = _ => new (string Nhan, string GiaTri)[]
        {
            ("Tất cả", ""), ("Đang xử lý", "trangThai=ChoXacNhan"), ("Đang giao", "trangThai=DangGiao"), ("Đã giao", "trangThai=DaGiao"), ("Đã hủy", "trangThai=DaHuy"),
        },
        Url = (_, _, loc) => $"api/mobile/admin/don-hang/tim?maKH={_maKH}" + (loc == "" ? "" : "&" + loc),
        Dong = (_, d) =>
        {
            var tt = AdminUi.TrangThai(J.S(d, "trangThai"));
            var dong = new List<string> { $"🏬 {J.S(d, "gianHang")}" };
            if (!J.Rong(d, "taiXe")) dong.Add($"🛵 {J.S(d, "taiXe")}");
            if (!J.Rong(d, "hinhThucTT")) dong.Add($"💳 {AdminUi.TrangThai(J.S(d, "hinhThucTT")).Nhan} · {AdminUi.TrangThai(J.S(d, "trangThaiTT")).Nhan}");
            return new AdminDong($"#{J.S(d, "maDonHang")}", dong.ToArray(), tt.Nhan, tt.Mau,
                Avatar: "📦", PhaiTren: J.Ngay(d, "ngayDat", "HH:mm · dd/MM"), PhaiDuoi: AdminUi.Tien(J.D(d, "tongTien")));
        },
        Mo = (_, d) => Shell.Current.GoToAsync($"{nameof(AdminOrderDetailPage)}?Id={J.S(d, "maDonHang")}"),
    };
}

/// <summary>Hồ sơ hợp đồng quán: ngày tham gia, hoa hồng, số đơn, GMV, hoa hồng đã thu, đánh giá. Admin tổng đặt hoa hồng riêng cho từng quán.</summary>
public sealed class AdminVendorContractPage : AdminListPage
{
    public AdminVendorContractPage() : base(Cfg()) { }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Hợp đồng & hoa hồng quán",
        GoiYTimKiem = "Tên quán hoặc SĐT…",
        Url = (_, q, _) => $"api/mobile/admin/gian-hang/hop-dong?q={AdminUi.Q(q)}",
        TomTat = (_, _) => "Hoa hồng = tỷ lệ phí nền tảng trên tiền hàng (không tính phí giao). Chỉ Admin tổng được đổi.",
        Dong = (_, d) => new AdminDong(J.S(d, "ten"), new[]
        {
            $"Tham gia {J.Ngay(d, "ngayDangKy", "dd/MM/yyyy")} · hoa hồng {J.D(d, "tyLe") * 100:0.#}% · giao: {(J.S(d, "cheDoGiao") == "Quan" ? "tài xế của quán" : "shipper nền tảng")}",
            $"{J.L(d, "soDon")} đơn ({J.L(d, "daGiao")} giao · {J.L(d, "daHuy")} hủy) · GMV {AdminUi.Tien(J.D(d, "gmv"))}",
            $"Hoa hồng đã thu: {AdminUi.Tien(J.D(d, "hoaHongDaThu"))}" + (J.L(d, "soDanhGia") > 0 ? $" · ⭐ {J.D(d, "saoTB"):0.0} ({J.L(d, "soDanhGia")})" : ""),
        }, null, null, "🏬"),
        HanhDong = _ => new[]
        {
            new AdminHanhDong("% Đặt hoa hồng", AdminUi.Tim, null, async (p, d) =>
            {
                if (!PhanQuyenService.Co(Quyen.QuanLyNhanVien)) { await p.DisplayAlert("Chỉ Admin tổng", "Chỉ Admin tổng được đặt hoa hồng.", "Đóng"); return; }
                var s = await AdminUi.Hoi(p, "Hoa hồng của " + J.S(d, "ten"), "Nhập phần trăm (0–100), áp dụng cho báo cáo từ nay.", null, 1, (J.D(d, "tyLe") * 100).ToString("0.##"), Keyboard.Numeric);
                if (s == null) return;
                if (!decimal.TryParse(s.Replace(',', '.'), System.Globalization.NumberStyles.Number, System.Globalization.CultureInfo.InvariantCulture, out var pt))
                { await p.DisplayAlert("Chưa hợp lệ", "Nhập một số, ví dụ 12.5", "Đóng"); return; }
                await AdminUi.Put(p, $"api/mobile/admin/gian-hang/{J.S(d, "maGianHang")}/hoa-hong", new { phanTram = pt }, "Đặt hoa hồng quán", J.S(d, "ten"));
            }),
        },
    };
}

// =====================================================================================================================
// v67 — Khiếu nại / phản hồi của khách: tiếp nhận, phân công, phân loại, yêu cầu bổ sung, trả lời, chuyển hoàn tiền
// =====================================================================================================================
public sealed class AdminKhieuNaiPage : AdminListPage
{
    public AdminKhieuNaiPage() : base(Cfg()) { }

    private const string Api = "api/mobile/admin/khieu-nai";
    private static string MaPh(JsonElement d) => J.S(d, "maPhanHoi");
    private static bool Cho(JsonElement d) => J.S(d, "trangThai") == "ChuaXuLy";

    private static readonly (string Ma, string Nhan)[] PhanLoai =
    {
        ("DonHang", "Đơn hàng"), ("MonAn", "Món ăn"), ("TaiXe", "Tài xế"), ("GianHang", "Gian hàng"), ("ThanhToan", "Thanh toán"), ("Khac", "Khác"),
    };

    private static string NhanPhanLoai(string ma) => PhanLoai.FirstOrDefault(x => x.Ma == ma).Nhan ?? "Chưa phân loại";

    private static string ChiTiet(JsonElement d)
    {
        var sb = new System.Text.StringBuilder();
        sb.AppendLine($"👤 {J.S(d, "tenKhach")}" + (J.Rong(d, "sdtKhach") ? "" : $" · {J.S(d, "sdtKhach")}"));
        if (!J.Rong(d, "maDonHang")) sb.AppendLine($"📦 Đơn #{J.S(d, "maDonHang")}");
        sb.AppendLine($"🕒 Gửi {J.Ngay(d, "ngayGui")}");
        sb.AppendLine($"🏷 {NhanPhanLoai(J.S(d, "phanLoai"))} · Phụ trách: {(J.Rong(d, "tenPhuTrach") ? "chưa ai" : J.S(d, "tenPhuTrach"))}");
        sb.AppendLine().AppendLine(J.S(d, "noiDung"));
        if (!J.Rong(d, "yeuCauBoSung")) sb.AppendLine().AppendLine("❓ Đã yêu cầu khách bổ sung: " + J.S(d, "yeuCauBoSung"));
        if (!J.Rong(d, "traLoi")) sb.AppendLine().AppendLine("✅ Trả lời: " + J.S(d, "traLoi"));
        return sb.ToString();
    }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Khiếu nại & phản hồi",
        Tab = new[] { "Chờ xử lý", "Của tôi", "Đã xử lý", "Tất cả" },
        GoiYTimKiem = "Tìm theo tiêu đề, nội dung, khách, SĐT, mã đơn…",
        Url = (tab, tuKhoa, _) => $"{Api}?tab={new[] { "cho", "cua-toi", "da-xu-ly", "tat-ca" }[Math.Clamp(tab, 0, 3)]}" + (string.IsNullOrWhiteSpace(tuKhoa) ? "" : "&q=" + AdminUi.Q(tuKhoa)),
        LayDs = (_, goc) => J.Mang(goc, "ds"),
        TomTat = (_, goc) => $"{J.L(goc, "soChoXuLy")} đang chờ xử lý · {J.L(goc, "soChuaPhanCong")} chưa có người phụ trách",
        Dong = (_, d) =>
        {
            var dong = new List<string>
            {
                $"👤 {J.S(d, "tenKhach")}" + (J.Rong(d, "maDonHang") ? "" : $" · 📦 đơn #{J.S(d, "maDonHang")}"),
                J.S(d, "noiDung").Length > 120 ? J.S(d, "noiDung")[..120] + "…" : J.S(d, "noiDung"),
                $"🏷 {NhanPhanLoai(J.S(d, "phanLoai"))} · 🙋 {(J.Rong(d, "tenPhuTrach") ? "chưa phân công" : J.S(d, "tenPhuTrach") + (J.B(d, "laCuaToi") ? " (bạn)" : ""))}",
            };
            if (Cho(d) && J.Co(d, "choGio", out var g) && g.ValueKind == JsonValueKind.Number) dong.Add($"⏳ Chờ {g.GetDouble():0.#} giờ");
            if (!J.Rong(d, "yeuCauBoSung") && Cho(d)) dong.Add("❓ Đang chờ khách bổ sung");
            var loai = J.S(d, "loai") == "KhieuNai" ? "Khiếu nại" : J.S(d, "loai") == "GopY" ? "Góp ý" : "Khác";
            return new AdminDong(J.S(d, "tieuDe"), dong.ToArray(), Cho(d) ? loai : "Đã xử lý", Cho(d) ? (loai == "Khiếu nại" ? AdminUi.Do : AdminUi.Cam) : AdminUi.Xanh);
        },
        Mo = async (p, d) => await p.DisplayAlert($"Phản hồi #{MaPh(d)} — {J.S(d, "tieuDe")}", ChiTiet(d), "Đóng"),
        HanhDong = _ => new[]
        {
            new AdminHanhDong("Nhận xử lý", AdminUi.Tim, d => Cho(d) && !J.B(d, "laCuaToi"), async (p, d) =>
                await AdminUi.Put(p, $"{Api}/{MaPh(d)}/nhan-xu-ly", null, "Nhận xử lý khiếu nại", $"#{MaPh(d)}")),
            new AdminHanhDong("Trả lời & đóng", AdminUi.Xanh, Cho, async (p, d) =>
            {
                var nd = await AdminUi.Hoi(p, $"Trả lời phản hồi #{MaPh(d)}", "Nội dung trả lời gửi tới khách (3–2000 ký tự).", null, 3);
                if (nd == null) return;
                await AdminUi.Put(p, $"{Api}/{MaPh(d)}/tra-loi", new { traLoi = nd }, "Trả lời khiếu nại", $"#{MaPh(d)}");
            }),
            new AdminHanhDong("Thêm…", AdminUi.Xam, Cho, async (p, d) =>
            {
                var quanLy = J.B(p.Goc, "laQuanLy");
                var lc = new List<string> { "Phân loại", "Yêu cầu khách bổ sung" };
                if (quanLy) { lc.Insert(0, "Phân công người xử lý"); if (!J.Rong(d, "maDonHang")) lc.Add("Chuyển sang hoàn tiền"); }
                var chon = await p.DisplayActionSheet($"Phản hồi #{MaPh(d)}", "Đóng", null, lc.ToArray());
                if (chon == "Phân công người xử lý")
                {
                    var nv = J.Mang(p.Goc, "nhanVien").ToList();
                    var ten = await p.DisplayActionSheet("Giao cho ai xử lý?", "Hủy", null, nv.Select(x => J.S(x, "hoTen")).ToArray());
                    var da = nv.FirstOrDefault(x => J.S(x, "hoTen") == ten);
                    if (da.ValueKind == JsonValueKind.Object)
                        await AdminUi.Put(p, $"{Api}/{MaPh(d)}/phan-cong", new { maTK = (int)J.L(da, "maTK") }, "Phân công xử lý khiếu nại", $"#{MaPh(d)} → {ten}");
                }
                else if (chon == "Phân loại")
                {
                    var nhan = await p.DisplayActionSheet("Phân loại", "Hủy", null, PhanLoai.Select(x => x.Nhan).ToArray());
                    var ma = PhanLoai.FirstOrDefault(x => x.Nhan == nhan).Ma;
                    if (ma != null) await AdminUi.Put(p, $"{Api}/{MaPh(d)}/phan-loai", new { phanLoai = ma }, "Phân loại khiếu nại", $"#{MaPh(d)} → {nhan}");
                }
                else if (chon == "Yêu cầu khách bổ sung")
                {
                    var nd = await AdminUi.Hoi(p, "Yêu cầu khách bổ sung", "Nội dung cần khách cung cấp thêm (3–500 ký tự).", null, 3);
                    if (nd != null) await AdminUi.Put(p, $"{Api}/{MaPh(d)}/bo-sung", new { yeuCau = nd }, "Yêu cầu khách bổ sung", $"#{MaPh(d)}");
                }
                else if (chon == "Chuyển sang hoàn tiền")
                {
                    var t = await AdminUi.Hoi(p, "Chuyển sang hoàn tiền", "Số tiền hoàn (để trống = hoàn toàn bộ đơn). Yêu cầu sẽ chờ duyệt ở mục Thanh toán & hoàn tiền.", null, 0, "", Keyboard.Numeric);
                    if (t == null) return;
                    decimal.TryParse(t.Replace(".", "").Replace(",", ""), out var so);
                    await AdminUi.Post(p, $"{Api}/{MaPh(d)}/chuyen-hoan-tien", new { soTien = so }, "Chuyển khiếu nại sang hoàn tiền", $"#{MaPh(d)}");
                }
            }),
        },
    };
}
