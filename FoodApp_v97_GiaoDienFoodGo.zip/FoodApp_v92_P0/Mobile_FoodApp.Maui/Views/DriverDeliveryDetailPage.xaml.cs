using System.Globalization;
using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

public partial class DriverDeliveryDetailPage : ContentPage
{
    private DonHang? _don;
    private IDispatcherTimer? _timerHuy;
    private readonly HashSet<long> _tbDaBao = new();

    public DriverDeliveryDetailPage()
    {
        InitializeComponent();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        _don = MockData.DonHangDangGiaoCuaTaiXe;

        if (_don is null)
        {
            // Không còn đơn đang giao (đã hoàn tất) -> quay lại trang chủ tài xế.
            await Shell.Current.GoToAsync("..");
            return;
        }

        if (_don.TrangThai == TrangThaiDonHang.DaHuy && !_don.GiaoThatBai)       // khách hủy trong lúc tài xế đang thực hiện
        {
            var huy = _don;
            Dispatcher.Dispatch(async () =>
            {
                await DisplayAlert("Khách đã hủy đơn", $"Đơn #{huy.Id} đã bị hủy. Nếu bạn đã lấy hàng, hãy liên hệ hỗ trợ.", "OK");
                MockData.DonHangDangGiaoCuaTaiXe = null;
                MockData.DonHangChoTaiXe.Remove(huy);
                await Shell.Current.GoToAsync("..");
            });
            return;
        }

        GiaoHangService.BoSungTuyenNeuThieu(_don);

        LblMaDon.Text = $"Đơn #{_don.Id}";
        LblGianHang.Text = _don.TenGianHang;
        LblDiaChiLay.Text = _don.DiaChiLayHang;
        LblDiaChiGiao.Text = _don.DiaChiGiao;
        DsMon.ItemsSource = _don.ChiTiet;

        LblKhachTen.Text = string.IsNullOrWhiteSpace(_don.KhachTen) ? (LayKhach()?.HoTen is { Length: > 0 } t ? t : "Khách hàng") : _don.KhachTen;
        LblKhachSdt.Text = string.IsNullOrWhiteSpace(LaySdtKhach()) ? "Khách chưa cung cấp số điện thoại" : LaySdtKhach();

        HienThiTuyenVaPhi();
        CapNhatThuHo();
        CapNhatTheoTrangThai();

        // Chia sẻ vị trí cho khách theo dõi: theo lựa chọn của tài xế (mặc định bật)
        SwChiaSeViTri.Toggled -= OnChiaSeViTriToggled;
        SwChiaSeViTri.IsToggled = ViTriTaiXeService.DuocPhepChiaSe;
        SwChiaSeViTri.Toggled += OnChiaSeViTriToggled;
        ViTriTaiXeService.DaCapNhat -= HienThiTrangThaiViTri;
        ViTriTaiXeService.DaCapNhat += HienThiTrangThaiViTri;
        if (ViTriTaiXeService.DuocPhepChiaSe) await ViTriTaiXeService.BatDauAsync(_don);
        HienThiTrangThaiViTri();

        // Mỗi 45 giây hỏi máy chủ: đơn đang giao bị hủy / thay đổi thì báo ngay cho tài xế
        _timerHuy ??= Dispatcher.CreateTimer();
        _timerHuy.Interval = TimeSpan.FromSeconds(45);
        _timerHuy.Tick -= OnKiemTraThayDoi;
        _timerHuy.Tick += OnKiemTraThayDoi;
        _timerHuy.Start();
    }

    /// <summary>Có thông báo mới từ máy chủ nhắc tới đơn đang giao (hủy, đổi địa chỉ...) → rung và hiện cho tài xế.</summary>
    private async void OnKiemTraThayDoi(object? sender, EventArgs e)
    {
        try
        {
            var don = _don;
            if (don is null || !DuLieuService.DangOnline) return;
            await ThongBaoMayChuService.TaiAsync();
            var tb = ThongBaoMayChuService.DanhSach.FirstOrDefault(t => !t.DaDoc && !_tbDaBao.Contains(t.Id)
                && (t.MaThamChieu == don.Id || (t.TieuDe + " " + t.NoiDung).Contains("#" + don.Id)));
            if (tb is null) return;
            _tbDaBao.Add(tb.Id);
            try { Vibration.Default.Vibrate(TimeSpan.FromMilliseconds(500)); } catch { }
            var laHuy = (tb.TieuDe + " " + tb.NoiDung).Contains("hủy", StringComparison.OrdinalIgnoreCase);
            await DisplayAlert((laHuy ? "⚠️ " : "🔔 ") + tb.TieuDe, tb.NoiDung, "OK");
            if (laHuy)
            {
                _timerHuy?.Stop();
                MockData.DonHangDangGiaoCuaTaiXe = null;
                MockData.DonHangChoTaiXe.Remove(don);
                ViTriTaiXeService.Dung();
                await Shell.Current.GoToAsync("..");
            }
        }
        catch (Exception ex) { CrashLog.Ghi("DriverDelivery.KiemTraThayDoi", ex); }
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        _timerHuy?.Stop();
        ViTriTaiXeService.DaCapNhat -= HienThiTrangThaiViTri;   // vẫn chia sẻ nền cho tới khi giao xong
    }

    private bool TienMat => _don is not null && _don.HinhThucThanhToan.Contains("mặt", StringComparison.OrdinalIgnoreCase);

    private void HienThiTuyenVaPhi()
    {
        if (_don is null) return;
        LblPhiGiao.Text = $"+{_don.PhiGiaoHang:N0}đ";
        LblKhoangCach.Text = _don.KhoangCachHienThi;
        LblThoiGian.Text = _don.ThoiGianDuKienPhut > 0 && _don.KhoangCachKm > 0 ? $"~{_don.ThoiGianDuKienPhut} phút" : "—";
        LblKhuVuc.Text = string.IsNullOrEmpty(_don.KhuVucGiao) ? "Chưa rõ"
            : (string.IsNullOrEmpty(_don.KhuVucLay) || _don.KhuVucLay == _don.KhuVucGiao ? _don.KhuVucGiao : $"{_don.KhuVucLay} → {_don.KhuVucGiao}");
        LblGhiChuUocTinh.Text = _don.PhiDaDieuChinh
            ? $"✏ Đã điều chỉnh theo khoảng cách thực tế {_don.KhoangCachThucTeKm:0.#} km."
            : _don.KhoangCachKm > 0
                ? "Ước tính theo khu vực trong địa chỉ, có thể lệch so với đường đi thực tế — dùng \"Chỉ đường\" để xem lộ trình."
                : "Chưa nhận ra khu vực từ địa chỉ nên chưa tính được khoảng cách. Hãy báo khoảng cách thực tế nếu xa hơn.";
        LblNhanPhiKm.Text = _don.KhoangCachKm > 0 ? $"Theo khoảng cách ({_don.KhoangCachHienThi})" : "Phí cơ bản";
        LblPhiKm.Text = $"{_don.PhiKhoangCach:N0}đ";
        RowPhuPhi.IsVisible = _don.PhuPhiKhuVuc > 0;
        LblNhanPhuPhi.Text = $"Phụ phí khu vực ({(string.IsNullOrEmpty(_don.KhuVucGiao) ? "ngoại thành" : _don.KhuVucGiao)})";
        LblPhuPhi.Text = $"+{_don.PhuPhiKhuVuc:N0}đ";
        LblPhiTong.Text = $"{_don.PhiGiaoHang:N0}đ";
        LblGhiChuPhi.IsVisible = true;
        LblGhiChuPhi.Text = $"{GiaoHangService.PhiCoBan:N0}đ cho {GiaoHangService.KmMienPhi:0} km đầu, +{GiaoHangService.PhiMoiKmThem:N0}đ mỗi km tiếp theo; ngoại thành +{GiaoHangService.PhuPhiNgoaiThanh:N0}đ; tối đa {GiaoHangService.PhiToiDa:N0}đ.";
    }

    private void CapNhatThuHo()
    {
        if (_don is null) return;
        LblIconThuHo.Text = TienMat ? "💵" : "✅";
        LblThuHoTieuDe.Text = TienMat ? "Thu tiền mặt từ khách" : $"Khách đã thanh toán ({_don.HinhThucThanhToan})";
        LblThuHoSoTien.Text = TienMat ? $"{_don.TongThanhToan:N0}đ" : "Không cần thu tiền";
    }

    private void HienThiTrangThaiViTri() => MainThread.BeginInvokeOnMainThread(() =>
        LblTrangThaiViTri.Text = ViTriTaiXeService.DuocPhepChiaSe ? ViTriTaiXeService.TrangThai : "Đang tắt — khách không thấy vị trí của bạn");

    private async void OnChiaSeViTriToggled(object? sender, ToggledEventArgs e)
    {
        ViTriTaiXeService.DuocPhepChiaSe = e.Value;
        if (!e.Value) { ViTriTaiXeService.Dung("Đang tắt — khách không thấy vị trí của bạn"); return; }
        if (_don is not null) await ViTriTaiXeService.BatDauAsync(_don);
        HienThiTrangThaiViTri();
    }

    private async void OnGoiQuanClicked(object? sender, EventArgs e)
    {
        if (_don is null) return;
        await GiaoHangService.GoiDienAsync(this, GiaoHangService.SdtQuan(_don), "Quán");
    }

    private async void OnDieuChinhPhiClicked(object? sender, EventArgs e)
    {
        if (_don is null) return;
        var nhap = await this.NhapAsync("Khoảng cách thực tế",
            $"Nhập số km thực tế quán → khách (hiện ước tính: {_don.KhoangCachHienThi}).\nPhí được tính lại theo biểu phí khoảng cách và khu vực.",
            "Tính lại", "Hủy", "VD: 4.5", 6, Keyboard.Numeric);
        if (string.IsNullOrWhiteSpace(nhap)) return;
        if (!double.TryParse(nhap.Trim().Replace(',', '.'), NumberStyles.Float, CultureInfo.InvariantCulture, out var km) || km < 0.3 || km > 60)
        {
            await DisplayAlert("Số km không hợp lệ", "Nhập khoảng cách từ 0,3 đến 60 km.", "Đóng");
            return;
        }
        km = Math.Round(km, 1);
        var (phiKm, phuPhi, tong) = GiaoHangService.TinhPhi(km, _don.NgoaiThanh);
        if (tong == _don.PhiGiaoHang) { await DisplayAlert("Phí không đổi", $"Với {km:0.#} km, phí vẫn là {tong:N0}đ.", "OK"); return; }
        if (!TienMat && tong > _don.PhiGiaoHang)
        {
            await DisplayAlert("Không thể tăng phí",
                $"Đơn đã thanh toán trước ({_don.HinhThucThanhToan}) nên không thu thêm của khách được.\nPhí tính lại: {tong:N0}đ (hiện {_don.PhiGiaoHang:N0}đ). Nếu cần hỗ trợ, báo cho quản trị viên.", "Đóng");
            return;
        }
        var ghiChu = TienMat && tong > _don.PhiGiaoHang ? $"\nKhách sẽ trả thêm {tong - _don.PhiGiaoHang:N0}đ khi nhận hàng."
            : (tong < _don.PhiGiaoHang ? $"\nKhách được giảm {_don.PhiGiaoHang - tong:N0}đ." : "");
        if (!await DisplayAlert("Điều chỉnh phí giao hàng",
                $"Khoảng cách {km:0.#} km → phí giao {tong:N0}đ (đang là {_don.PhiGiaoHang:N0}đ).{ghiChu}\nCập nhật?", "Cập nhật", "Hủy")) return;
        if (!await DuLieuService.GhiAsync("PUT", $"api/mobile/don-hang/{_don.Id}/phi-giao-hang", new { khoangCachKm = km, phiGiaoHang = tong })) return;
        var phut = GiaoHangService.UocTinhPhut(km);
        GiaoHangService.CapNhatMoiBanSao(_don.Id, d =>
        {
            d.KhoangCachKm = km; d.KhoangCachThucTeKm = km; d.ThoiGianDuKienPhut = phut;
            d.PhiKhoangCach = phiKm; d.PhuPhiKhuVuc = phuPhi; d.PhiGiaoHang = tong; d.PhiDaDieuChinh = true;
        });
        VendorLocalStore.Luu();
        HienThiTuyenVaPhi();
        CapNhatThuHo();
    }

    private static Color Res(string k) => DriverPalette.Get(k);
    private static Color MauCho => Color.FromArgb("#66FFFFFF");

    private void TonBuoc(Frame dot, Label lbl, bool xong, bool hienTai)
    {
        dot.BackgroundColor = xong ? Colors.White : (hienTai ? Color.FromArgb("#33FFFFFF") : Color.FromArgb("#1AFFFFFF"));
        dot.BorderColor = hienTai || xong ? Colors.White : Color.FromArgb("#55FFFFFF");
        lbl.TextColor = xong ? Res("Primary") : Colors.White;
        if (xong) lbl.Text = "✓";
    }

    private void CapNhatBuoc(int buoc)
    {
        // buoc 1 = đang đến quán lấy hàng, 2 = đang giao
        TonBuoc(Dot1, LblDot1, true, false);
        TonBuoc(Dot2, LblDot2, buoc >= 2, buoc == 1);
        TonBuoc(Dot3, LblDot3, false, buoc == 2);
        Line1.Color = buoc >= 1 ? Colors.White : MauCho;
        Line2.Color = buoc >= 2 ? Colors.White : MauCho;
        if (buoc < 2) LblDot2.Text = "2";
    }

    private async void OnSaoChepLayTapped(object? sender, EventArgs e)
    {
        if (_don is null) return;
        await FoodApp.Maui.Services.ClipboardAnToan.SaoChepAsync(_don.DiaChiLayHang);
        await DisplayAlert("Đã sao chép", "Địa chỉ lấy hàng đã được sao chép.", "OK");
    }

    private async void OnSaoChepGiaoTapped(object? sender, EventArgs e)
    {
        if (_don is null) return;
        await FoodApp.Maui.Services.ClipboardAnToan.SaoChepAsync(_don.DiaChiGiao);
        await DisplayAlert("Đã sao chép", "Địa chỉ giao hàng đã được sao chép.", "OK");
    }

    private void CapNhatTheoTrangThai()
    {
        if (_don is null) return;

        if (_don.TrangThai == TrangThaiDonHang.DangLam)
        {
            if (_don.BuocTaiXe == 0)
            {
                LblTrangThaiHienTai.Text = "📍 Đã nhận đơn — đang đến quán lấy hàng";
                BtnHanhDongChinh.Text = "Đã đến quán";
            }
            else
            {
                LblTrangThaiHienTai.Text = "🍳 Đang lấy hàng tại quán";
                BtnHanhDongChinh.Text = "Đã lấy hàng, bắt đầu giao";
            }
            CapNhatBuoc(1);
        }
        else
        {
            LblTrangThaiHienTai.Text = "🛵 Đang trên đường giao đến khách hàng";
            BtnHanhDongChinh.Text = "Đã giao thành công";
            CapNhatBuoc(2);
            CapNhatNutDenDiem(true);
        }
        if (_don.TrangThai != TrangThaiDonHang.DangGiao) CapNhatNutDenDiem(false);
        BtnGiaoThatBai.IsVisible = _don.TrangThai == TrangThaiDonHang.DangGiao;   // chỉ báo thất bại sau khi đã lấy hàng
    }

    private async void OnHanhDongChinhClicked(object sender, EventArgs e)
    {
        if (_don is null) return;

        if (_don.TrangThai == TrangThaiDonHang.DangLam)
        {
            if (_don.BuocTaiXe == 0)                         // đã nhận → đến quán, bắt đầu lấy hàng
            {
                // Server trước (PUT api/mobile/don-hang/{id}/den-quan); lỗi thì giữ nguyên bước hiện tại
                if (!await Services.DuLieuService.GhiAsync("PUT", $"api/mobile/don-hang/{_don.Id}/den-quan")) return;
                _don.BuocTaiXe = 1;
                Services.DonHangService.DongBo(_don);
                CapNhatTheoTrangThai();
                return;
            }

            if (!await DisplayAlert("Xác nhận lấy hàng", $"Bạn đã nhận đủ {_don.ChiTiet.Sum(x => x.SoLuong)} món từ {_don.TenGianHang}?", "Đã nhận đủ", "Chưa"))
                return;
            // Kiểm tra mã đơn trên túi/hóa đơn để tránh nhận nhầm đơn (server so khớp; sai mã thì không cho lấy hàng).
            var maDonNhap = await this.NhapAsync("Kiểm tra mã đơn", $"Nhập mã đơn in trên túi/hóa đơn (đơn #{_don.Id}):", "Xác nhận", "Hủy", $"VD: {_don.Id}", keyboard: Keyboard.Numeric);
            if (maDonNhap is null) return;
            var duoiMa = string.IsNullOrWhiteSpace(maDonNhap) ? "" : "?maDon=" + Uri.EscapeDataString(maDonNhap.Trim());
            // API trước: server sinh mã 4 số lúc lấy hàng và cho biết đơn có mã hay không (quyết định phải nhập mã hay chụp ảnh).
            var (layOk, layKq) = await Services.DuLieuService.GhiLayAsync<DaLayHangDto>("PUT", $"api/mobile/don-hang/{_don.Id}/da-lay-hang{duoiMa}");
            if (!layOk) return;
            if (layKq is not null) _don.CoMaXacNhan = layKq.CoMaXacNhan;
            _don.DaLayHang = true; _don.LayHangLuc = DateTime.Now;
            _don.TrangThai = TrangThaiDonHang.DangGiao;      // đã lấy hàng → khách thấy "Đang giao"
            Services.DonHangService.DongBo(_don);
            CapNhatTheoTrangThai();
            // Lấy món thành công → gợi ý mở bản đồ đến địa chỉ khách
            if (await DisplayAlert("Đã lấy hàng", "Mở bản đồ đến địa chỉ giao cho khách?", "Mở bản đồ", "Để sau"))
                await BanDoPage.MoAsync(_don.DiaChiGiao);
            return;
        }

        // Hoàn tất giao hàng: thu tiền mặt (nếu có) + mã 4 số của khách, rồi ảnh bằng chứng (có thể bỏ qua)
        if (TienMat && !await DisplayAlert("Thu tiền mặt", $"Bạn đã thu đủ {_don.TongThanhToan:N0}đ từ khách?", "Đã thu đủ", "Chưa thu"))
            return;
        // Online: server giữ mã và là nơi duy nhất kiểm tra (tài xế không nhận được mã). Offline demo: so với mã cục bộ.
        // Đơn có mã 4 số: nhập mã. Đơn KHÔNG có mã (đơn cũ): bắt buộc chụp ảnh bằng chứng và tải lên server trước khi hoàn thành.
        var online = Services.DuLieuService.DangOnline;
        var coMa = online ? _don.CoMaXacNhan : !string.IsNullOrEmpty(_don.MaXacNhanGiao);
        string? maNhap = null;
        if (coMa)
        {
            while (true)
            {
                var ma = await this.NhapAsync("Khách xác nhận đã nhận hàng",
                    "Nhập mã 4 số hiển thị trên đơn hàng của khách (Đơn hàng → đơn đang giao).", "Xác nhận", "Hủy", "____", 4, Keyboard.Numeric);
                if (ma is null) return;
                maNhap = ma.Trim();
                if (Services.DuLieuService.DangOnline || maNhap == _don.MaXacNhanGiao) break;
                await DisplayAlert("Mã không đúng", "Mã xác nhận không khớp. Nhờ khách kiểm tra lại mã trên đơn hàng.", "Nhập lại");
            }
        }

        var batBuocAnh = online && !coMa;      // không có mã → ảnh là bằng chứng duy nhất, server từ chối nếu thiếu
        var anh = batBuocAnh
            ? await DisplayActionSheet("Đơn không có mã xác nhận — cần ảnh bằng chứng giao hàng", "Hủy", null, "Chụp ảnh", "Chọn từ thư viện")
            : await DisplayActionSheet("Ảnh bằng chứng giao hàng (không bắt buộc)", "Hủy", null, "Chụp ảnh", "Chọn từ thư viện", "Bỏ qua");
        if (anh is null or "Hủy") return;
        if (anh != "Bỏ qua")
        {
            var path = await Services.AnhService.ChonVaLuuAsync("giao_" + _don.Id, "Ảnh giao hàng", chup: anh == "Chụp ảnh");
            if (path is null)
            {
                await DisplayAlert("Chưa có ảnh", batBuocAnh ? "Đơn này bắt buộc có ảnh bằng chứng. Hãy chụp hoặc chọn lại ảnh." : "Bạn chưa chọn ảnh. Chọn lại hoặc bấm \"Bỏ qua\".", "OK");
                return;
            }
            _don.AnhGiaoPath = path;
            // Tải lên server TRƯỚC khi hoàn thành. Ảnh bắt buộc mà tải lỗi → dừng để thử lại; ảnh tùy chọn lỗi → vẫn hoàn thành nhờ mã.
            if (!await Services.DuLieuService.TaiBangChungAsync(_don.Id, path, baoLoi: batBuocAnh) && batBuocAnh) return;
        }

        // Gọi server TRƯỚC khi đổi trạng thái cục bộ: sai mã / đơn bị khóa thì dừng lại (GhiAsync tự báo lỗi).
        var viTri = Services.ViTriTaiXeService.ViTriCuoi;
        if (!await Services.DuLieuService.GhiAsync("PUT", $"api/mobile/don-hang/{_don.Id}/hoan-thanh",
                new { maXacNhan = maNhap, viDo = viTri?.Lat, kinhDo = viTri?.Lng, phuCap = Services.ThuNhapService.PhuCapDon(_don) })) return;

        _don.TrangThai = TrangThaiDonHang.HoanThanh;
        _don.GiaoLuc = DateTime.Now;
        _don.PhuCap = Services.ThuNhapService.PhuCapDon(_don);

        MockData.DonHangChoTaiXe.Remove(_don);
        MockData.DonHangDaGiaoCuaTaiXe.Add(_don);
        MockData.DonHangDangGiaoCuaTaiXe = null;

        // Đồng bộ lại cho khách và quán: đơn đã giao xong.
        foreach (var d in MockData.LichSuDonHang.Where(x => x.Id == _don.Id)) d.TrangThai = TrangThaiDonHang.HoanThanh;
        foreach (var d in MockData.DonHangCuaGianHang.Where(x => x.Id == _don.Id)) d.TrangThai = TrangThaiDonHang.HoanThanh;
        Services.DonHangService.DongBo(_don);
        Services.ThuNhapService.CapNhatChiSo();            // thu nhập hôm nay tính lại từ lịch sử (gồm phụ cấp + thưởng)
        Services.TaiXeStore.Luu();
        ViTriTaiXeService.Dung();

        await DisplayAlert("Hoàn tất", DuLieuService.ChuThichGhi($"Đã giao đơn #{_don.Id} thành công. Bạn nhận được {_don.PhiGiaoHang + _don.PhuCap:N0}đ" +
                                       (_don.PhuCap > 0 ? $" (gồm phụ cấp đêm {_don.PhuCap:N0}đ)." : ".")), "OK");

        await Shell.Current.GoToAsync("..");
    }

    private static readonly (string Nhan, bool LoiKhach)[] DsLyDoThatBai =
    {
        ("Không liên lạc được với khách", true),
        ("Khách từ chối nhận hàng", true),
        ("Khách hẹn lại / không có nhà", true),
        ("Sai hoặc không tìm thấy địa chỉ", true),
        ("Sự cố xe / tai nạn trên đường", false),
        ("Món bị đổ / hư hỏng", false),
        ("Lý do khác", false),
    };

    /// <summary>Báo địa chỉ quán/khách sai hoặc GPS lệch: gửi sự cố loại "SaiDiaChi" kèm địa chỉ và toạ độ hiện tại của tài xế để quản trị đối chiếu.</summary>
    private async void OnBaoSaiViTriClicked(object? sender, EventArgs e)
    {
        if (_don is null) return;
        var chon = await DisplayActionSheet("Báo sai vị trí", "Hủy", null, "Địa chỉ quán sai", "Địa chỉ giao của khách sai", "Bản đồ / GPS định vị lệch");
        if (chon is null or "Hủy") return;
        var ghiChu = await this.NhapAsync("Mô tả thêm", "Địa chỉ đúng là gì / sai lệch thế nào? (không bắt buộc)", "Gửi", "Hủy", maxLength: 300);
        if (ghiChu is null) return;
        if (!Services.DuLieuService.DangOnline)
        {
            await DisplayAlert("Chưa gửi được", "Cần kết nối máy chủ để gửi báo cáo. Hãy thử lại khi có mạng.", "OK");
            return;
        }
        var vt = Services.ViTriTaiXeService.ViTriCuoi;
        var toaDo = vt is { } v ? $"{v.Lat.ToString("0.00000", CultureInfo.InvariantCulture)}, {v.Lng.ToString("0.00000", CultureInfo.InvariantCulture)}" : "chưa có";
        var moTa = $"{chon}. Địa chỉ quán: {_don.DiaChiLayHang}. Địa chỉ giao: {_don.DiaChiGiao}. GPS tài xế lúc báo: {toaDo}." +
                   (string.IsNullOrWhiteSpace(ghiChu) ? "" : " Ghi chú: " + ghiChu.Trim());
        if (int.TryParse(_don.Id, out var maDon))
        {
            var r = await Services.ApiClient.PostAsync<object>("api/mobile/tai-xe/su-co", new { loai = "SaiDiaChi", moTa, maDonHang = maDon });
            await DisplayAlert(r.ThanhCong ? "Đã gửi báo cáo" : "Chưa gửi được", r.ThanhCong ? "Quản trị sẽ kiểm tra lại địa chỉ/vị trí và phản hồi trong mục Báo sự cố." : r.ThongDiep, "OK");
        }
        else await DisplayAlert("Chưa gửi được", "Đơn này chưa được ghi nhận trên máy chủ.", "OK");
    }

    private async void OnBaoSuCoClicked(object? sender, EventArgs e)
    {
        if (_don is null) return;
        await Shell.Current.GoToAsync($"{nameof(DriverSuCoPage)}?don={_don.Id}");
    }

    private async void OnThatBaiClicked(object sender, EventArgs e)
    {
        if (_don is null) return;
        var chon = await DisplayActionSheet("Lý do giao không thành công", "Đóng", null, DsLyDoThatBai.Select(x => x.Nhan).ToArray());
        if (chon is null or "Đóng") return;
        var (nhan, loiKhach) = DsLyDoThatBai.First(x => x.Nhan == chon);
        if (nhan.StartsWith("Không liên lạc") && _don.SoLanGoiKhach == 0)
        {
            await DisplayAlert("Hãy gọi khách trước", "Bạn cần gọi khách ít nhất 1 lần trước khi báo không liên lạc được.", "Đóng");
            return;
        }
        var ly = nhan;
        if (nhan == "Lý do khác")
        {
            var tuNhap = await this.NhapAsync("Lý do khác", "Mô tả ngắn lý do giao không thành công.", "Gửi", "Hủy", "VD: khu vực bị ngập", 120);
            if (string.IsNullOrWhiteSpace(tuNhap)) return;
            ly = tuNhap.Trim();
        }
        var phi = loiKhach ? $"Bạn vẫn nhận phí giao {_don.PhiGiaoHang:N0}đ (lỗi do khách)." : "Bạn sẽ không nhận phí giao cho đơn này.";
        var tienTxt = TienMat ? "Đơn thanh toán tiền mặt: không thu tiền của khách." : "Đơn đã thanh toán trước: khách sẽ được hoàn tiền.";
        if (!await DisplayAlert("Xác nhận giao thất bại", $"Lý do: {ly}\n{phi}\n{tienTxt}\nĐơn sẽ bị hủy. Hãy mang món về trả quán hoặc liên hệ quán để xử lý.", "Xác nhận", "Hủy"))
            return;
        // Server quyết định phí/hoàn tiền theo lý do và tạo yêu cầu hoàn tiền; dừng nếu server từ chối.
        var viTriTb = Services.ViTriTaiXeService.ViTriCuoi;
        if (!await Services.DuLieuService.GhiAsync("PUT", $"api/mobile/don-hang/{_don.Id}/giao-that-bai", new { lyDo = ly.Trim(), tinhPhi = loiKhach, viDo = viTriTb?.Lat, kinhDo = viTriTb?.Lng })) return;
        _don.TinhPhiKhiThatBai = loiKhach;
        _don.GiaoThatBaiLuc = DateTime.Now;

        bool tienMat = _don.HinhThucThanhToan.Contains("mặt", StringComparison.OrdinalIgnoreCase);
        _don.LyDoThatBai = ly.Trim();
        _don.TrangThai = TrangThaiDonHang.DaHuy;
        _don.GiaoLuc = DateTime.Now;
        _don.DaHoanTien = !tienMat;
        _don.PhuCap = 0;

        MockData.DonHangChoTaiXe.Remove(_don);
        MockData.DonHangDaGiaoCuaTaiXe.Add(_don);
        MockData.DonHangDangGiaoCuaTaiXe = null;
        Services.DonHangService.DongBo(_don);
        Services.KhuyenMaiService.HoanSuDung(_don.MaKhuyenMai, _don.KhachEmail);     // trả lại lượt dùng voucher
        Services.ThuNhapService.CapNhatChiSo();
        Services.TaiXeStore.Luu();
        ViTriTaiXeService.Dung();

        await DisplayAlert("Đã ghi nhận", "Đơn đã được hủy và báo cho khách hàng." + (tienMat ? "" : " Khoản thanh toán trước sẽ được hoàn lại."), "OK");

        // Giao thất bại → (đã nhập lý do) → có thể gửi yêu cầu hỗ trợ cho đơn này
        var maDonHt = _don.Id;
        var loaiHoTro = chon switch
        {
            var s when s.StartsWith("Không liên lạc") => "KhachKhongLienLac",
            var s when s.StartsWith("Khách từ chối") => "KhachKhongNhan",
            var s when s.StartsWith("Sai hoặc") => "SaiDiaChi",
            var s when s.StartsWith("Sự cố xe") => "TaiNan",
            var s when s.StartsWith("Món bị") => "MonHuHong",
            _ => "TranhChapGiaoHang",
        };
        var guiHoTro = await DisplayAlert("Gửi yêu cầu hỗ trợ?", "Bạn có muốn gửi yêu cầu hỗ trợ cho đơn này (VD: khách khiếu nại, tranh chấp)?", "Gửi yêu cầu hỗ trợ", "Không");
        await Shell.Current.GoToAsync("..");
        if (guiHoTro)
        {
            // Mang theo lý do vừa nhập để tài xế không phải gõ lại mô tả sự cố
            var moTaHt = Uri.EscapeDataString($"Giao không thành công đơn #{maDonHt}: {ly}");
            await Shell.Current.GoToAsync($"{nameof(DriverSuCoPage)}?loai={loaiHoTro}&don={maDonHt}&mota={moTaHt}");
        }
    }

    // Đơn cũ chưa lưu SĐT thì tra theo email khách đặt đơn.
    private KhachHang? LayKhach() =>
        string.IsNullOrEmpty(_don?.KhachEmail) ? null
        : MockData.DanhSachKhachHang.FirstOrDefault(k => string.Equals(k.Email, _don.KhachEmail, StringComparison.OrdinalIgnoreCase));

    private string LaySdtKhach()
    {
        if (_don is null) return "";
        return !string.IsNullOrWhiteSpace(_don.KhachSdt) ? _don.KhachSdt.Trim() : (LayKhach()?.SoDienThoai ?? "").Trim();
    }

    private async void OnGoiKhachClicked(object sender, EventArgs e)
    {
        if (_don is null) return;
        GiaoHangService.CapNhatMoiBanSao(_don.Id, d => d.SoLanGoiKhach++);   // điều kiện "không liên lạc được"
        VendorLocalStore.Luu();
        await Services.LienLac.GoiAsync(LaySdtKhach());
    }

    private async void OnNhanTinClicked(object sender, EventArgs e)
    {
        if (_don is null) return;
        await ChatPage.MoAsync(_don.Id, "TaiXe", string.IsNullOrWhiteSpace(_don.KhachTen) ? "Khách hàng" : _don.KhachTen, LaySdtKhach());
    }

    private async void OnBanDoLayTapped(object? sender, EventArgs e)
    {
        if (_don is not null) await BanDoPage.MoAsync($"{_don.DiaChiLayHang}");
    }

    private async void OnBanDoGiaoTapped(object? sender, EventArgs e)
    {
        if (_don is not null) await BanDoPage.MoAsync(_don.DiaChiGiao);
    }

    /// <summary>Mở Google Maps chỉ đường từ quán tới địa chỉ khách (đang giao) hoặc tới quán (đang đi lấy hàng).</summary>
    private async void OnChiDuongClicked(object sender, EventArgs e)
    {
        if (_don is null) return;
        var den = _don.TrangThai == TrangThaiDonHang.DangGiao ? _don.DiaChiGiao : _don.DiaChiLayHang;
        if (await GiaoHangService.MoChiDuongAsync(den)) return;
        await FoodApp.Maui.Services.ClipboardAnToan.SaoChepAsync(den);
        await DisplayAlert("Không mở được bản đồ", "Đã sao chép địa chỉ để bạn dán vào ứng dụng bản đồ.", "OK");
    }

    /// <summary>v94: đường bị chặn / không tìm được tuyến → tính lại, mở Google Maps tìm đường khác hoặc nhắn khách báo trễ.</summary>
    private async void OnDuongBiChanClicked(object sender, EventArgs e)
    {
        if (_don is null) return;
        try { await Services.TuyenThayTheService.XuLyAsync(this, _don); }
        catch (Exception ex) { CrashLog.Ghi("DuongBiChan", ex); await DisplayAlert("Chưa xử lý được", "Hãy mở Google Maps để tự tìm đường khác.", "OK"); }
    }

    // ---------------- v91: xác nhận đã đến điểm giao (ghi giờ trên máy; máy chủ chưa có bước riêng này)
    private string KhoaDenDiem => "den-diem:" + _don?.Id;

    private void CapNhatNutDenDiem(bool hien)
    {
        BtnDenDiemGiao.IsVisible = hien && _don is not null;
        if (!hien || _don is null) return;
        var luc = Preferences.Default.Get(KhoaDenDiem, "");
        BtnDenDiemGiao.Text = DateTime.TryParse(luc, null, System.Globalization.DateTimeStyles.RoundtripKind, out var d)
            ? $"✓ Đã đến điểm giao lúc {d:HH:mm}" : "📍 Tôi đã đến điểm giao";
        BtnDenDiemGiao.IsEnabled = luc.Length == 0;
    }

    private async void OnDenDiemGiaoClicked(object? sender, EventArgs e)
    {
        if (_don is null) return;
        Preferences.Default.Set(KhoaDenDiem, DateTime.Now.ToString("o"));
        NhatKyService.Ghi("TaiXe", MockData.TaiXeHienTai.SoDienThoai, $"Đã đến điểm giao đơn #{_don.Id}");
        CapNhatNutDenDiem(true);
        if (await DisplayAlert("Đã ghi nhận", "Hãy gọi hoặc nhắn khách nhận hàng. Không liên lạc được thì dùng “Giao không thành công”.", "Gọi khách", "Đóng"))
            OnGoiKhachClicked(sender ?? this, EventArgs.Empty);
    }
}
