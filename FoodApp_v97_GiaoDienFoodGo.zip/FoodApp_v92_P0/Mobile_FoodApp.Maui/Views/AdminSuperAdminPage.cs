using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Phần IX — Super Admin: quản trị toàn nền tảng (dành cho trường hợp cung cấp FoodApp cho nhiều doanh nghiệp).
/// Hiện FoodApp chạy một doanh nghiệp (chưa tách dữ liệu theo doanh nghiệp), nên trang này gồm:
///  • Gói dịch vụ, thanh toán dịch vụ, giới hạn sử dụng: số liệu dùng tính từ dữ liệu app; hạn mức/phí lưu ở CauHinhHeThong trên máy chủ (nhóm "nen-tang").
///  • Lối tắt tới các phân hệ đã có: cấu hình, phân quyền, giám sát, bảo mật, nhật ký, sao lưu.
///  • Quản lý nhiều doanh nghiệp: CHƯA có (cần tách dữ liệu theo doanh nghiệp ở backend/SQL) — ghi rõ trên trang.
/// </summary>
public sealed class AdminSuperAdminPage : AdminKyThuatTrang
{
    public AdminSuperAdminPage() : base("Super Admin – toàn nền tảng") { }

    // Cấu hình lưu trên MÁY CHỦ (bảng CauHinhHeThong, nhóm "nen-tang"); ngoại tuyến thì đọc/ghi bản nhớ trên thiết bị.
    private static readonly Dictionary<string, string> Khoa = new()
    {
        ["goi"] = "NenTang.Goi", ["phi"] = "NenTang.PhiThang", ["han"] = "NenTang.NgayThanhToan",
        ["gh-nguoi"] = "GioiHan.NguoiDung", ["gh-don"] = "GioiHan.DonThang", ["gh-mb"] = "GioiHan.DungLuongMB",
    };
    private readonly Dictionary<string, string> _cfg = new();
    private bool _tuMayChu;

    private static string DocLocal(string k, string mau) { try { return Preferences.Default.Get("superadmin-" + k, mau); } catch { return mau; } }
    private static void GhiLocal(string k, string v) { try { Preferences.Default.Set("superadmin-" + k, v); } catch { } }

    private async Task NapCauHinhAsync()
    {
        _cfg.Clear(); _tuMayChu = false;
        foreach (var k in Khoa.Keys) _cfg[k] = DocLocal(k, "");
        if (!DuLieuService.DangOnline) return;
        try
        {
            var r = await ApiClient.GetAsync<System.Text.Json.JsonElement>("api/mobile/admin/cau-hinh");
            if (!r.ThanhCong || r.DuLieu.ValueKind != System.Text.Json.JsonValueKind.Object) return;
            foreach (var nhom in J.Mang(r.DuLieu, "nhom"))
                foreach (var m in J.Mang(nhom, "muc"))
                {
                    var khoa = J.S(m, "khoa");
                    var k = Khoa.FirstOrDefault(x => x.Value == khoa).Key;
                    if (k is null) continue;
                    _cfg[k] = J.S(m, "giaTri"); GhiLocal(k, _cfg[k]);
                    _tuMayChu = true;
                }
        }
        catch (Exception ex) { CrashLog.Ghi("SuperAdmin.Nap", ex); }
    }

    private string Doc(string k, string mau) => _cfg.TryGetValue(k, out var v) && !string.IsNullOrWhiteSpace(v) ? v : mau;
    private long So(string k, long mau) => long.TryParse(Doc(k, mau.ToString()), out var n) && n >= 0 ? n : mau;

    /// <summary>Lưu một giá trị: online → PUT lên máy chủ (báo lỗi nếu bị từ chối); ngoại tuyến → chỉ lưu trên máy.</summary>
    private async Task<bool> GhiAsync(string k, string v)
    {
        if (DuLieuService.DangOnline)
        {
            var r = await ApiClient.PutAsync<object>("api/mobile/admin/cau-hinh", new { khoa = Khoa[k], giaTri = v });
            if (!r.ThanhCong) { await DisplayAlert("Không lưu được", r.ThongDiep, "Đóng"); return false; }
        }
        _cfg[k] = v; GhiLocal(k, v);
        return true;
    }

    private async Task LamMoiAsync() { Nd.Children.Clear(); await DungAsync(); }

    private static long DungLuongByte()
    {
        try
        {
            var dir = new DirectoryInfo(FileSystem.AppDataDirectory);
            return dir.Exists ? dir.EnumerateFiles("*", SearchOption.AllDirectories).Sum(f => f.Length) : 0;
        }
        catch { return 0; }
    }

    protected override async Task DungAsync()
    {
        await NapCauHinhAsync();
        var tatCa = MockData.TatCaDonHangHeThong.ToList();
        var dauThang = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
        var nguoiDung = MockData.DanhSachKhachHang.Count + MockData.DanhSachTaiXe.Count + MockData.DanhSachGianHang.Count + MockData.DanhSachQuanTri.Count;
        var donThang = tatCa.Count(d => d.NgayDat >= dauThang);
        var mb = DungLuongByte() / 1048576.0;

        // 1. Doanh nghiệp
        Nd.Add(KhoiTheo("Quản lý doanh nghiệp",
            DongTrai("Chế độ hiện tại", "Một doanh nghiệp"),
            DongTrai("Tạo / sửa / khóa doanh nghiệp", "Chưa có", "#B45309"),
            AdminUi.Nhan("Muốn bán FoodApp cho nhiều doanh nghiệp cần thêm mã doanh nghiệp (TenantId) vào các bảng SQL và lọc mọi truy vấn theo mã đó ở backend. Đây là thay đổi lớn, chưa làm; nếu chỉ một doanh nghiệp dùng thì chưa cần.", 11.5, mo: true)));

        // 2. Gói dịch vụ + thanh toán dịch vụ
        var goi = AdminUi.Nhan($"Gói: {Doc("goi", "Chưa đặt")}", 13.5, dam: true);
        var phi = AdminUi.Nhan($"Phí sử dụng phần mềm: {So("phi", 0):N0}đ / tháng", 13);
        var han = AdminUi.Nhan($"Ngày thanh toán hằng tháng: {(So("han", 0) is 0 ? "chưa đặt" : "ngày " + So("han", 0))}", 13);
        var sua = AdminUi.Nut("Chỉnh gói và phí", AdminUi.Xam);
        sua.Clicked += async (_, _) =>
        {
            var g = await this.NhapAsync("Gói dịch vụ", "Tên gói đang dùng", "Lưu", "Hủy", initialValue: Doc("goi", ""), maxLength: 40);
            if (g is null) return;
            var p = await this.NhapAsync("Phí sử dụng phần mềm", "Số tiền mỗi tháng (đ)", "Lưu", "Hủy", initialValue: So("phi", 0).ToString(), keyboard: Keyboard.Numeric);
            if (p is null) return;
            var h = await this.NhapAsync("Thanh toán dịch vụ", "Ngày thanh toán mỗi tháng (1–28, 0 = chưa đặt)", "Lưu", "Hủy", initialValue: So("han", 0).ToString(), keyboard: Keyboard.Numeric);
            if (h is null) return;
            if (!string.IsNullOrWhiteSpace(g) && !await GhiAsync("goi", g.Trim())) return;
            if (long.TryParse(p, out var pn) && !await GhiAsync("phi", Math.Max(0, pn).ToString())) return;
            if (long.TryParse(h, out var hn) && !await GhiAsync("han", Math.Clamp(hn, 0, 28).ToString())) return;
            await LamMoiAsync();
        };
        Nd.Add(KhoiTheo("Gói dịch vụ & thanh toán dịch vụ", goi, phi, han, sua,
            AdminUi.Nhan(_tuMayChu ? "Đã lưu trên máy chủ, mọi thiết bị quản trị thấy cùng số liệu (chỉ Admin tổng được sửa). Chưa có hệ thống tự tính và thu phí phần mềm." : "Đang ngoại tuyến: số liệu lưu tạm trên thiết bị này, chưa đồng bộ máy chủ.", 11, mo: true)));

        // 3. Giới hạn sử dụng
        Nd.Add(KhoiTheo("Giới hạn sử dụng",
            MucGioiHan("Người dùng (khách, tài xế, gian hàng, quản trị)", nguoiDung, "gh-nguoi", 1000, ""),
            MucGioiHan("Đơn hàng trong tháng", donThang, "gh-don", 5000, ""),
            MucGioiHan("Dung lượng dữ liệu trên thiết bị", (long)mb, "gh-mb", 5120, " MB"),
            AdminUi.Nhan("Số đang dùng tính từ dữ liệu app. Hạn mức mặc định là số mẫu — chạm vào từng dòng để đặt theo gói thật (lưu lên máy chủ). Dung lượng chỉ tính phần ảnh/dữ liệu lưu trên máy này, chưa phải dung lượng máy chủ.", 11, mo: true)));

        // 4. Lối tắt tới phân hệ đã có
        var loi = new VerticalStackLayout { Spacing = 2 };
        void Them(string icon, string ten, string moTa, Func<Task> di)
        {
            var d = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 10, Padding = new Thickness(0, 8) };
            d.Add(new Label { Text = icon, FontSize = 20, VerticalOptions = LayoutOptions.Center }, 0, 0);
            d.Add(new VerticalStackLayout { Spacing = 1, Children = { AdminUi.Nhan(ten, 13.5, dam: true), AdminUi.Nhan(moTa, 11, mo: true) } }, 1, 0);
            d.Add(new Label { Text = "›", FontSize = 20, VerticalOptions = LayoutOptions.Center }, 2, 0);
            d.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => { try { await di(); } catch (Exception ex) { CrashLog.Ghi("SuperAdmin -> " + ten, ex); } }) });
            loi.Add(d);
        }
        Them("🧩", "Quản lý nền tảng", "Cấu hình hệ thống dùng chung", () => Shell.Current.GoToAsync(nameof(AdminConfigPage)));
        Them("🛡", "Quản lý Admin", "Cấp quyền quản trị", () => Shell.Current.GoToAsync(DuLieuService.DangOnline ? nameof(AdminStaffOnlinePage) : nameof(AdminStaffPage)));
        Them("📡", "Giám sát hệ thống", "API, server, database", () => Shell.Current.GoToAsync(nameof(AdminGiamSatPage)));
        Them("🔐", "Bảo mật", "Phát hiện truy cập bất thường", () => Shell.Current.GoToAsync(nameof(AdminBaoMatPage)));
        Them("🧾", "Nhật ký", "Theo dõi hoạt động toàn nền tảng", () => Shell.Current.GoToAsync(nameof(AdminAuditLogPage)));
        Them("💾", "Sao lưu", "Bản sao lưu và khôi phục", () => Shell.Current.GoToAsync(nameof(AdminSaoLuuPage)));
        Nd.Add(KhoiTheo("Các phân hệ đã có", loi));
    }

    private View MucGioiHan(string ten, long dang, string khoa, long macDinh, string donVi)
    {
        var gh = Math.Max(1, So(khoa, macDinh));
        var tiLe = (double)dang / gh;
        var mau = tiLe >= 1 ? AdminUi.Do : tiLe >= 0.8 ? "#B45309" : AdminUi.Xanh;
        var st = new VerticalStackLayout { Spacing = 3, Padding = new Thickness(0, 4) };
        var d = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        d.Add(AdminUi.Nhan(ten, 12.5), 0, 0);
        var so = AdminUi.Nhan($"{dang:N0}/{gh:N0}{donVi}", 12.5, dam: true); so.TextColor = Color.FromArgb(mau);
        d.Add(so, 1, 0);
        st.Add(d);
        st.Add(new ProgressBar { Progress = Math.Min(1, tiLe), ProgressColor = Color.FromArgb(mau) });
        if (tiLe >= 0.8) st.Add(AdminUi.Nhan(tiLe >= 1 ? "⚠ Đã chạm giới hạn" : "⚠ Sắp chạm giới hạn (từ 80%)", 11, mo: true));
        st.GestureRecognizers.Add(new TapGestureRecognizer
        {
            Command = new Command(async () =>
            {
                var v = await this.NhapAsync("Đặt giới hạn", ten, "Lưu", "Hủy", initialValue: gh.ToString(), keyboard: Keyboard.Numeric);
                if (v is not null && long.TryParse(v, out var n) && n > 0 && await GhiAsync(khoa, n.ToString())) await LamMoiAsync();
            })
        });
        return st;
    }
}
