using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

internal static class VendorChiTietUi
{
    public static VerticalStackLayout Khung() => new() { Spacing = 10, Padding = new Thickness(16, 12, 16, 28) };

    public static Border The(params View[] con)
    {
        var st = new VerticalStackLayout { Spacing = 6 };
        foreach (var c in con) st.Children.Add(c);
        return new Border
        {
            Padding = 14, StrokeThickness = 1, Stroke = VendorPalette.Get("BorderColor"), BackgroundColor = Colors.White,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(14) }, Content = st,
        };
    }

    public static Label Tieu(string t) => new() { Text = t, FontAttributes = FontAttributes.Bold, FontSize = 15, TextColor = Colors.Black };
    public static Label Chu(string t, bool xam = false) => new() { Text = t, FontSize = 13, TextColor = xam ? VendorPalette.Get("TextGrey") : Colors.Black };

    public static View Dong(string trai, string phai, bool dam = false)
    {
        var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 8 };
        g.Add(new Label { Text = trai, FontSize = 13, TextColor = dam ? Colors.Black : VendorPalette.Get("TextGrey"), FontAttributes = dam ? FontAttributes.Bold : FontAttributes.None }, 0);
        g.Add(new Label { Text = phai, FontSize = 13, FontAttributes = dam ? FontAttributes.Bold : FontAttributes.None, TextColor = Colors.Black, HorizontalTextAlignment = TextAlignment.End }, 1);
        return g;
    }

    public static Button Nut(string t, bool day, Func<Task> viec)
    {
        var n = new Button
        {
            Text = t, FontSize = 13, HeightRequest = 42, CornerRadius = 12, FontAttributes = FontAttributes.Bold,
            BackgroundColor = day ? VendorPalette.Get("Primary") : Colors.Transparent,
            TextColor = day ? Colors.White : VendorPalette.Get("Primary"),
            BorderColor = VendorPalette.Get("Primary"), BorderWidth = 1,
        };
        n.Clicked += async (_, _) => await viec();
        return n;
    }
}

/// <summary>Chi tiết đơn của gian hàng: món, ghi chú, khách, địa chỉ, thanh toán, giao hàng → Xác nhận / Từ chối / Bàn giao.</summary>
[QueryProperty(nameof(Don), "Don")]
public sealed class VendorOrderDetailPage : ContentPage
{
    public DonHang? Don { get; set; }
    private readonly VerticalStackLayout _nd = VendorChiTietUi.Khung();

    public VendorOrderDetailPage()
    {
        Title = "Chi tiết đơn";
        BackgroundColor = VendorPalette.Get("Background");
        Content = new ScrollView { Content = _nd };
    }

    protected override void OnAppearing() { base.OnAppearing(); Ve(); }

    private void Ve()
    {
        _nd.Children.Clear();
        var d = Don;
        if (d is null) { _nd.Children.Add(VendorChiTietUi.Chu("Không tìm thấy đơn.", true)); return; }

        _nd.Children.Add(VendorChiTietUi.The(
            VendorChiTietUi.Tieu($"Đơn #{d.Id}"),
            VendorChiTietUi.Dong("Trạng thái", d.NhanHienThi, true),
            VendorChiTietUi.Dong("Đặt lúc", d.NgayDat.ToString("HH:mm dd/MM/yyyy")),
            VendorChiTietUi.Dong("Khách", string.IsNullOrWhiteSpace(d.KhachTen) ? "—" : d.KhachTen),
            VendorChiTietUi.Dong("Thanh toán", d.HinhThucHienThi)));

        var mon = new List<View> { VendorChiTietUi.Tieu("Món đã đặt") };
        foreach (var c in d.ChiTiet)
        {
            mon.Add(VendorChiTietUi.Dong($"{c.SoLuong} × {c.MonAn.TenMon}", $"{c.ThanhTien:N0}đ"));
            if (c.CoGhiChu) mon.Add(VendorChiTietUi.Chu(c.GhiChuHienThi, true));
        }
        mon.Add(VendorChiTietUi.Dong("Tạm tính", $"{d.TongTien:N0}đ", true));
        if (d.GiamGia > 0) mon.Add(VendorChiTietUi.Dong("Giảm giá", $"-{d.GiamGia:N0}đ"));
        _nd.Children.Add(VendorChiTietUi.The(mon.ToArray()));

        var giao = new List<View> { VendorChiTietUi.Tieu("Giao hàng"), VendorChiTietUi.Chu("📍 " + (string.IsNullOrWhiteSpace(d.DiaChiGiao) ? "—" : d.DiaChiGiao)) };
        if (d.KhoangCachKm > 0) giao.Add(VendorChiTietUi.Dong("Khoảng cách", d.KhoangCachHienThi));
        if (!string.IsNullOrWhiteSpace(d.TaiXeTen)) giao.Add(VendorChiTietUi.Dong("Tài xế", d.TaiXeTen));
        if (!string.IsNullOrEmpty(d.TrangThaiTaiXeText)) giao.Add(VendorChiTietUi.Chu(d.TrangThaiTaiXeText, true));
        if (d.TrangThai == TrangThaiDonHang.DaHuy && !string.IsNullOrWhiteSpace(d.LyDoTuChoi)) giao.Add(VendorChiTietUi.Chu(d.LyDoTuChoiText));
        _nd.Children.Add(VendorChiTietUi.The(giao.ToArray()));

        if (d.TrangThai == TrangThaiDonHang.ChoXacNhan)
        {
            _nd.Children.Add(VendorChiTietUi.Nut("Xác nhận đơn", true, async () =>
            {
                var phut = await DoiTacService.ChonThoiGianChuanBiAsync(d);
                if (phut is null) return;
                if (await DoiTacService.XacNhanDonAsync(d, phut)) Ve();
            }));
            _nd.Children.Add(VendorChiTietUi.Nut("Từ chối đơn", false, async () => { if (await DoiTacService.TuChoiDonAsync(this, d)) Ve(); }));
        }
        else if (d.CoTheBanGiao)
            _nd.Children.Add(VendorChiTietUi.Nut("Đã chuẩn bị xong — sẵn sàng giao", true, async () => { if (await DoiTacService.BanGiaoTaiXeAsync(d)) Ve(); }));
        else if (d.CoTheXacNhanBanGiao)
            _nd.Children.Add(VendorChiTietUi.Nut("🤝 Đã bàn giao món cho tài xế", true, async () =>
            {
                if (await DoiTacService.XacNhanBanGiaoAsync(d)) Ve();
            }));
    }
}

/// <summary>Chi tiết một đánh giá của khách + phản hồi công khai của quán.</summary>
[QueryProperty(nameof(DanhGia), "DanhGia")]
public sealed class VendorReviewDetailPage : ContentPage
{
    public DanhGiaGianHang? DanhGia { get; set; }
    private readonly VerticalStackLayout _nd = VendorChiTietUi.Khung();

    public VendorReviewDetailPage()
    {
        Title = "Chi tiết đánh giá";
        BackgroundColor = VendorPalette.Get("Background");
        Content = new ScrollView { Content = _nd };
    }

    protected override void OnAppearing() { base.OnAppearing(); Ve(); }

    private void Ve()
    {
        _nd.Children.Clear();
        var dg = DanhGia;
        if (dg is null) { _nd.Children.Add(VendorChiTietUi.Chu("Không tìm thấy đánh giá.", true)); return; }

        var noi = new List<View>
        {
            VendorChiTietUi.Tieu(dg.TieuDeText),
            VendorChiTietUi.Chu(dg.NgayText, true),
            new Label { Text = dg.SaoText, FontSize = 22, TextColor = VendorPalette.Get("Accent") },
        };
        if (dg.SoSaoGiaoHang > 0) noi.Add(VendorChiTietUi.Chu(dg.SaoGiaoHangText, true));
        if (dg.CoThe) noi.Add(VendorChiTietUi.Chu("🏷 " + dg.TheText));
        noi.Add(VendorChiTietUi.Chu(dg.CoNoiDung ? dg.NoiDung : "(Khách không viết nhận xét)", !dg.CoNoiDung));
        if (dg.CoAnh)
        {
            var luoi = new FlexLayout { Wrap = Microsoft.Maui.Layouts.FlexWrap.Wrap };
            foreach (var url in dg.AnhHienThi)
                luoi.Children.Add(new Image { Source = url, WidthRequest = 104, HeightRequest = 104, Aspect = Aspect.AspectFill, Margin = new Thickness(0, 0, 8, 8) });
            noi.Add(luoi);
        }
        _nd.Children.Add(VendorChiTietUi.The(noi.ToArray()));

        if (dg.CoPhanHoi)
            _nd.Children.Add(VendorChiTietUi.The(VendorChiTietUi.Tieu("Phản hồi của quán"), VendorChiTietUi.Chu(dg.PhanHoi),
                VendorChiTietUi.Chu(dg.PhanHoiLuc is { } l ? l.ToString("HH:mm dd/MM/yyyy") : "", true)));

        _nd.Children.Add(VendorChiTietUi.Nut(dg.CoPhanHoi ? "Sửa phản hồi" : "Phản hồi khách hàng", true, async () =>
        {
            var nd = await this.NhapAsync("Phản hồi đánh giá", $"Phản hồi sẽ hiển thị công khai cho {dg.KhachTen}.", "Gửi", "Hủy",
                placeholder: "Cảm ơn bạn đã ủng hộ quán!", maxLength: 300, initialValue: dg.PhanHoi);
            if (nd is null) return;
            if (dg.TuMayChu)
            {
                if (string.IsNullOrWhiteSpace(nd)) { await DisplayAlert("Chưa gửi được", "Nội dung phản hồi không được để trống.", "OK"); return; }
                var loi = await DoiTacService.PhanHoiMayChuAsync(dg, nd.Trim());
                if (loi != null) { await DisplayAlert("Chưa gửi được phản hồi", loi, "OK"); return; }
            }
            dg.PhanHoi = nd.Trim();
            dg.PhanHoiLuc = dg.CoPhanHoi ? DateTime.Now : null;
            if (!dg.TuMayChu) VendorLocalStore.Luu();
            Ve();
        }));
        _nd.Children.Add(VendorChiTietUi.Nut("Xem đơn hàng liên quan", false, async () =>
        {
            var don = MockData.DonHangCuaGianHang.FirstOrDefault(x => x.Id == dg.DonHangId);
            if (don is null) { await DisplayAlert("Không có dữ liệu", "Không tìm thấy đơn này trên máy.", "Đóng"); return; }
            await Shell.Current.GoToAsync(nameof(VendorOrderDetailPage), new Dictionary<string, object> { { "Don", don } });
        }));
    }
}

/// <summary>Chi tiết giao dịch (một đơn hoàn thành): doanh thu món, giảm giá quán chịu, phí nền tảng, thực nhận, các món.</summary>
[QueryProperty(nameof(Dong), "Dong")]
public sealed class VendorTransactionDetailPage : ContentPage
{
    public DongDonTaiChinh? Dong { get; set; }
    private readonly VerticalStackLayout _nd = VendorChiTietUi.Khung();

    public VendorTransactionDetailPage()
    {
        Title = "Chi tiết giao dịch";
        BackgroundColor = VendorPalette.Get("Background");
        Content = new ScrollView { Content = _nd };
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        _nd.Children.Clear();
        var g = Dong;
        if (g is null) { _nd.Children.Add(VendorChiTietUi.Chu("Không tìm thấy giao dịch.", true)); return; }

        _nd.Children.Add(VendorChiTietUi.The(
            VendorChiTietUi.Tieu(g.TieuDe),
            VendorChiTietUi.Chu(g.NgayText, true),
            VendorChiTietUi.Dong("Doanh thu món", $"{g.DoanhThuMon:N0}đ"),
            VendorChiTietUi.Dong("Giảm giá quán chịu", g.GiamGiaQuanChiu > 0 ? $"−{g.GiamGiaQuanChiu:N0}đ" : "0đ"),
            VendorChiTietUi.Dong("Phí nền tảng", $"−{g.PhiNenTang:N0}đ"),
            VendorChiTietUi.Dong("Thực nhận", g.ThucNhanText, true)));

        var don = MockData.DonHangCuaGianHang.FirstOrDefault(x => x.Id == g.DonHangId);
        if (don is not null)
        {
            var mon = new List<View> { VendorChiTietUi.Tieu("Các món trong đơn") };
            foreach (var c in don.ChiTiet) mon.Add(VendorChiTietUi.Dong($"{c.SoLuong} × {c.MonAn.TenMon}", $"{c.ThanhTien:N0}đ"));
            mon.Add(VendorChiTietUi.Dong("Thanh toán của khách", don.HinhThucHienThi));
            _nd.Children.Add(VendorChiTietUi.The(mon.ToArray()));
            _nd.Children.Add(VendorChiTietUi.Nut("Xem chi tiết đơn", false, async () =>
                await Shell.Current.GoToAsync(nameof(VendorOrderDetailPage), new Dictionary<string, object> { { "Don", don } })));
        }
    }
}
