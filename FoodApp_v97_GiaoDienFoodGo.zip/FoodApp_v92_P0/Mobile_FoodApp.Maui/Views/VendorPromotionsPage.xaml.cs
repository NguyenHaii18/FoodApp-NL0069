using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

public partial class VendorPromotionsPage : ContentPage
{
    public VendorPromotionsPage()
    {
        InitializeComponent();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        NapDanhSach();
        await TaiTuMayChuAsync();
    }

    /// <summary>Online: lấy đủ mã của gian hàng từ máy chủ (kể cả mã đã tắt/hết hạn) rồi vẽ lại.</summary>
    private async Task TaiTuMayChuAsync()
    {
        var loi = await KhuyenMaiQuanLyService.TaiAsync(admin: false);
        NapDanhSach();
        if (loi is not null) await DisplayAlert("Không tải được khuyến mãi", loi, "Đóng");
    }

    private void NapDanhSach()
    {
        var danhSach = MockData.DanhSachKhuyenMai
            .Where(k => k.GianHangId == MockData.GianHangHienTai.Id)
            .OrderByDescending(k => k.NgayBatDau)
            .ToList();

        DsKhuyenMai.ItemsSource = danhSach;
        LblRong.IsVisible = danhSach.Count == 0;
    }

    private async void OnBatTatToggled(object? sender, ToggledEventArgs e)
    {
        if (sender is not Switch { BindingContext: KhuyenMai km }) return;
        if (km.DangHoatDong == e.Value) return;   // vẽ lại danh sách cũng gây Toggled: bỏ qua khi không đổi

        if (KhuyenMaiQuanLyService.Online)
        {
            var loi = await KhuyenMaiQuanLyService.BatTatAsync(km, e.Value, admin: false);
            if (loi is not null)
            {
                await DisplayAlert("Không đổi được trạng thái", loi, "Đóng");
                NapDanhSach();   // trả công tắc về trạng thái thật
                return;
            }
        }
        km.DangHoatDong = e.Value;
        Services.VendorLocalStore.Luu();
    }

    private async void OnThemClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(VendorPromotionEditPage));
    }

    private async void OnSuaClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: KhuyenMai km }) return;

        await Shell.Current.GoToAsync(nameof(VendorPromotionEditPage), new Dictionary<string, object>
        {
            { "KhuyenMaiId", km.Id }
        });
    }

    private async void OnXoaClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: KhuyenMai km }) return;

        bool xacNhan = await DisplayAlert("Xóa khuyến mãi", $"Xóa mã \"{km.MaCode}\"? Khách hàng sẽ không thể áp dụng mã này nữa.", "Xóa", "Hủy");
        if (!xacNhan) return;

        if (KhuyenMaiQuanLyService.Online)
        {
            var loi = await KhuyenMaiQuanLyService.XoaAsync(km, admin: false);
            if (loi is not null) { await DisplayAlert("Không xóa được", loi, "Đóng"); return; }
        }
        MockData.DanhSachKhuyenMai.Remove(km);
        Services.VendorLocalStore.Luu();

        NapDanhSach();
    }

    private async void OnRefreshing(object? sender, EventArgs e)
    {
        await TaiTuMayChuAsync();
        RefreshDsKm.IsRefreshing = false;
    }
}
