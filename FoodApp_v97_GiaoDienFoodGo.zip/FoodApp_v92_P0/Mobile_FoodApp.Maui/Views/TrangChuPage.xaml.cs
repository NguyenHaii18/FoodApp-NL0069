using FoodApp.Maui.Models;

namespace FoodApp.Maui.Views;

public partial class TrangChuPage : ContentPage
{
    private bool _dangKhoiTao = true;
    private string _danhMucMon = "";          // lọc theo MonAn.DanhMuc (Picker)
    private readonly string[] _nhanGia = { "Mọi mức giá", "Dưới 30.000đ", "30.000 – 60.000đ", "60.000 – 100.000đ", "Trên 100.000đ" };
    private readonly string[] _nhanSao = { "Mọi đánh giá", "Từ 3★ trở lên", "Từ 4★ trở lên", "Từ 4,5★ trở lên" };
    private readonly string[] _nhanKm = { "Mọi khoảng cách", "Trong 2 km", "Trong 5 km", "Trong 10 km" };
    private readonly string[] _nhanThoiGian = { "Mọi thời gian giao", "Trong 20 phút", "Trong 30 phút", "Trong 45 phút", "Trong 60 phút" };
    private readonly string[] _nhanSapXep = { "Mặc định (đang mở, bán chạy)", "Gần nhất", "Đánh giá cao", "Giá thấp → cao", "Giá cao → thấp", "Phổ biến (bán chạy)", "Giao nhanh nhất" };

    public TrangChuPage()
    {
        InitializeComponent();
        CustomerNavBar.Gan(this, "home");
        VeTrangChu.Gan(LogoFoodApp);
        NapLuoiDanhMuc("✨ Tất cả");
        PkGia.ItemsSource = _nhanGia; PkGia.SelectedIndex = 0;
        PkSao.ItemsSource = _nhanSao; PkSao.SelectedIndex = 0;
        PkKhoangCach.ItemsSource = _nhanKm; PkKhoangCach.SelectedIndex = 0;
        PkThoiGian.ItemsSource = _nhanThoiGian; PkThoiGian.SelectedIndex = 0;
        PkSapXep.ItemsSource = _nhanSapXep; PkSapXep.SelectedIndex = 0;
        NapDanhMucMon();
        _dangKhoiTao = false;
    }

    private string _loai = "";
    private readonly Dictionary<string, string> _danhMuc = new()
    {
        ["✨ Tất cả"] = "", ["🍚 Cơm"] = "com", ["🍗 Gà rán"] = "ga", ["🍜 Bún/Phở"] = "bun", ["🧋 Trà sữa"] = "tra",
        ["🍕 Pizza"] = "pizza", ["🥖 Bánh mì"] = "banh", ["🍣 Món Nhật"] = "nhat", ["☕ Cà phê"] = "cafe", ["🍧 Chè"] = "che",
    };

    /// <summary>Nạp danh sách danh mục món (Cơm sườn, Trà sữa, Topping...) vào Picker, giữ lựa chọn hiện tại.</summary>
    private void NapDanhMucMon()
    {
        var ds = new List<string> { "Mọi danh mục món" };
        ds.AddRange(Services.TimKiemService.DanhMucMon());
        var cu = _danhMucMon;
        var truoc = _dangKhoiTao;
        _dangKhoiTao = true;
        PkDanhMuc.ItemsSource = ds;
        var i = cu.Length == 0 ? 0 : ds.FindIndex(x => string.Equals(x, cu, StringComparison.OrdinalIgnoreCase));
        PkDanhMuc.SelectedIndex = i < 0 ? 0 : i;
        if (i < 0) _danhMucMon = "";
        _dangKhoiTao = truoc;
    }

    private static readonly string[] _nenDanhMuc = { "#F3EEFF", "#FFF1D6", "#DFF2FF", "#FFE4E4", "#EFE6FF", "#E3F6D8", "#FFE9D9", "#E8EEF2", "#FDE8F3", "#FFF6C9" };

    /// <summary>Nạp lưới danh mục tròn (biểu tượng + tên), viền xanh ở mục đang chọn.</summary>
    private void NapLuoiDanhMuc(string dangChon)
    {
        int i = 0;
        DsDanhMuc.ItemsSource = _danhMuc.Keys.Select(k =>
        {
            var p = k.Split(' ', 2);
            return new DanhMucItem(k, p[0], p.Length > 1 ? p[1] : p[0], _nenDanhMuc[i++ % _nenDanhMuc.Length], k == dangChon ? 2.5 : 0);
        }).ToList();
    }

    private void OnDanhMucTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is string nhan && _danhMuc.TryGetValue(nhan, out var loai))
        {
            _loai = loai;
            NapLuoiDanhMuc(nhan);
            LocDanhSach();
        }
    }

    /// <summary>Nạp banner quảng cáo do quản trị tạo. Lỗi mạng/không có banner thì giữ banner mặc định.</summary>
    private async Task NapBannerAsync()
    {
        try
        {
            var goc = Services.AppSettings.BaseUrl.TrimEnd('/');
            string Url(string a) => a.StartsWith("http", StringComparison.OrdinalIgnoreCase) ? a : goc + (a.StartsWith('/') ? "" : "/") + a;
            var ds = new List<BannerQc>();

            var r = await Services.ApiClient.GetAsync<List<BannerApiDto>>("api/mobile/banner");
            if (r.ThanhCong && r.DuLieu is not null)
                ds.AddRange(r.DuLieu.Where(b => !string.IsNullOrWhiteSpace(b.HinhAnh))
                    .Select(b => new BannerQc(b.Id, b.TieuDe ?? "", Url(b.HinhAnh!), b.LienKet ?? "")));

            // Chiến dịch quảng cáo của gian hàng đang chạy (chạm vào mở thực đơn quán và ghi nhận lượt tương tác).
            var qc = await Services.ApiClient.GetAsync<List<ChienDichApiDto>>("api/mobile/chien-dich");
            if (qc.ThanhCong && qc.DuLieu is not null)
                ds.AddRange(qc.DuLieu.Where(c => !string.IsNullOrWhiteSpace(c.HinhAnh))
                    .Select(c => new BannerQc(-c.MaChienDich, "📣 " + c.TieuDe, Url(c.HinhAnh!), $"chiendich:{c.MaChienDich}:{c.MaGianHang}")));

            DsBannerQc.ItemsSource = ds;
            DsBannerQc.IsVisible = ds.Count > 0;
        }
        catch (Exception ex) { Services.CrashLog.Ghi("NapBanner", ex); }
    }

    private async Task MoChienDichAsync(string lienKet)
    {
        var p = lienKet.Split(':');
        if (p.Length < 3) return;
        _ = Services.ApiClient.PostAsync<object>($"api/mobile/chien-dich/{p[1]}/tuong-tac", null);
        var gh = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == p[2]);
        if (gh is null) { await DisplayAlert("Quảng cáo", "Không tìm thấy gian hàng này.", "Đóng"); return; }
        await Shell.Current.GoToAsync(nameof(MenuCartPage), new Dictionary<string, object> { { "GianHang", gh } });
    }

    private sealed class ThongBaoTrangChuDto { public string NoiDung { get; set; } = ""; public string LienKet { get; set; } = ""; }
    private string _lienKetThongBao = "";

    /// <summary>v67: dòng thông báo trang chủ do quản trị đặt. Lỗi mạng/để trống thì ẩn.</summary>
    private async Task NapThongBaoTrangChuAsync()
    {
        try
        {
            var r = await Services.ApiClient.GetAsync<ThongBaoTrangChuDto>("api/mobile/trang-chu/thong-bao");
            var nd = r.ThanhCong ? (r.DuLieu?.NoiDung ?? "").Trim() : "";
            _lienKetThongBao = r.ThanhCong ? (r.DuLieu?.LienKet ?? "").Trim() : "";
            LblThongBaoTrangChu.Text = "📢 " + nd;
            KhungThongBaoTrangChu.IsVisible = nd.Length > 0;
        }
        catch (Exception ex) { Services.CrashLog.Ghi("NapThongBaoTrangChu", ex); }
    }

    private async void OnThongBaoTrangChuTapped(object? sender, TappedEventArgs e)
    {
        var lk = _lienKetThongBao;
        if (lk.Length == 0) return;
        var url = lk.StartsWith("http", StringComparison.OrdinalIgnoreCase) ? lk : Services.AppSettings.BaseUrl.TrimEnd('/') + lk;
        try { await Launcher.OpenAsync(url); } catch { /* thiết bị không mở được liên kết */ }
    }

    private async void OnBannerQcTapped(object? sender, TappedEventArgs e)
    {
        var lk = e.Parameter as string ?? "";
        if (lk.StartsWith("chiendich:")) { await MoChienDichAsync(lk); return; }
        if (lk.Length == 0) { await Shell.Current.GoToAsync("//chinh/uu-dai"); return; }
        var url = lk.StartsWith("http", StringComparison.OrdinalIgnoreCase) ? lk : Services.AppSettings.BaseUrl.TrimEnd('/') + lk;
        try { await Launcher.OpenAsync(url); } catch { /* thiết bị không mở được liên kết */ }
    }

    private async void OnDatNgayBannerTapped(object? sender, TappedEventArgs e) => await Shell.Current.GoToAsync("//chinh/uu-dai");

    private void OnXemNgayUuDaiTapped(object? sender, TappedEventArgs e)
    {
        if (DsUuDai.ItemsSource is System.Collections.IEnumerable ds)
            foreach (var km in ds.OfType<KhuyenMai>()) { OnUuDaiTapped(sender, new TappedEventArgs(km)); return; }
    }

    private void OnDanhMucClicked(object? sender, EventArgs e)
    {
        if (sender is Button { CommandParameter: string nhan } && _danhMuc.TryGetValue(nhan, out var loai))
        {
            _loai = loai;
            LocDanhSach();
        }
    }

    private async void OnGoiYTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is not MonAn mon) return;
        var gh = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == mon.GianHangId);
        if (gh is null) return;
        await Shell.Current.GoToAsync(nameof(MenuCartPage), new Dictionary<string, object> { { "GianHang", gh } });
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        HienDiaChi();
        _ = NapBannerAsync();
        _ = NapThongBaoTrangChuAsync();
        NapUuDaiVaTin();
        await Services.DuLieuService.TaiDanhMucAsync();
        NapDanhMucMon();
        NapLichSuVaPhoBien();
        LocDanhSach();
        NapTrangChuThem();
        _ = NapDanhRiengAsync();
    }

    /// <summary>
    /// v55 — "Dành riêng cho bạn": gợi ý cá nhân hóa tính ở máy chủ (GET api/mobile/khach/goi-y-mon: sở thích + người đặt giống bạn + khung giờ + giá + đánh giá).
    /// Offline hoặc lỗi máy chủ → dùng gợi ý theo lịch sử đặt trên máy (NangCaoService.GoiYMon). Chỉ hiện cho khách đã đăng nhập.
    /// </summary>
    private async Task NapDanhRiengAsync()
    {
        try
        {
            var ds = new List<GoiYMonVm>();
            var ghiChu = "";
            if (Services.DuLieuService.DangOnline && !string.IsNullOrEmpty(Services.ApiClient.Token))
            {
                var r = await Services.ApiClient.GetAsync<GoiYMonDto>("api/mobile/khach/goi-y-mon?top=8");
                if (r.ThanhCong && r.DuLieu is { Ds.Count: > 0 } d)
                {
                    foreach (var x in d.Ds)
                    {
                        var mon = MockData.DanhSachMonAn.FirstOrDefault(m => m.Id == x.MaMonAn.ToString());
                        if (mon is not null) ds.Add(new GoiYMonVm(mon, x.LyDo));
                    }
                    ghiChu = $"Gợi ý theo sở thích của bạn và bữa {d.NhomGio}. Mô hình thống kê, không phải đoán chắc.";
                }
            }
            if (ds.Count == 0 && Services.Phien.Khach?.Email is { Length: > 0 } email)
            {
                ds = Services.NangCaoService.GoiYMon(email, 8).Select(g => new GoiYMonVm(g.Mon, g.LyDo)).ToList();
                if (ds.Count > 0) ghiChu = "Gợi ý theo lịch sử đặt trên máy này.";
            }
            DsDanhRieng.ItemsSource = ds;
            DsDanhRieng.IsVisible = LblDanhRieng.IsVisible = ds.Count > 0;
            LblDanhRiengGhiChu.Text = ghiChu;
            LblDanhRiengGhiChu.IsVisible = ds.Count > 0;
        }
        catch (Exception ex) { Services.CrashLog.Ghi("TrangChu.DanhRieng", ex); }
    }

    private async void OnDanhRiengTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is not MonAn mon) return;
        var gh = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == mon.GianHangId);
        if (gh is null) return;
        await Shell.Current.GoToAsync(nameof(MenuCartPage), new Dictionary<string, object> { { "GianHang", gh } });
    }

    /// <summary>Hiện địa chỉ của khách đang đăng nhập (nhập lúc tạo tài khoản).</summary>
    /// <summary>Nạp ưu đãi đang dùng được, tin mới và số chấm đỏ ở chuông.</summary>
    private void NapUuDaiVaTin()
    {
        var km = MockData.DanhSachKhuyenMai
            .Where(k => k.DangHoatDong && k.ConHan && !k.ChuaBatDau && k.ConLuot)
            .OrderByDescending(k => k.ApDungToanHeThong).Take(6).ToList();
        var hienKm = Preferences.Default.Get("cd-km", true);   // Cài đặt → Khuyến mãi & tin mới
        DsUuDai.ItemsSource = km;
        DsUuDai.IsVisible = TieuDeUuDai.IsVisible = hienKm && km.Count > 0;

        TinTucData.LamMoi();
        var tin = TinTucData.DanhSach.OrderByDescending(t => t.Ghim).ThenByDescending(t => t.Ngay).Take(5).ToList();
        DsTinMoi.ItemsSource = tin;
        DsTinMoi.IsVisible = TieuDeTin.IsVisible = hienKm && tin.Count > 0;
        var n = TinTucData.SoChuaXem + Services.ThongBaoMayChuService.ChuaDoc;
        LblChuong.Text = n > 0 ? $"🔔 {n}" : "🔔";
        _ = CapNhatChuongAsync();
    }

    private async Task CapNhatChuongAsync()
    {
        // Tin do quản trị soạn: tải từ máy chủ rồi vẽ lại danh sách "Tin mới" trên trang chủ
        await TinTucData.TaiTuMayChuAsync();
        var hienTin = Preferences.Default.Get("cd-km", true);
        var tinMoi = TinTucData.DanhSach.OrderByDescending(t => t.Ghim).ThenByDescending(t => t.Ngay).Take(5).ToList();
        DsTinMoi.ItemsSource = tinMoi;
        DsTinMoi.IsVisible = TieuDeTin.IsVisible = hienTin && tinMoi.Count > 0;

        await Services.ThongBaoMayChuService.TaiAsync();
        var n = TinTucData.SoChuaXem + Services.ThongBaoMayChuService.ChuaDoc;
        LblChuong.Text = n > 0 ? $"🔔 {n}" : "🔔";
    }

    private async void OnUuDaiTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is not KhuyenMai km) return;
        bool daSao = await FoodApp.Maui.Services.ClipboardAnToan.SaoChepAsync(km.MaCode);
        var chiTiet = $"{km.GiaTriGiamHienThi}\n{km.PhamViHienThi}\nĐơn tối thiểu {km.GiaTriDonToiThieu:N0}đ · HSD {km.NgayKetThuc:dd/MM/yyyy}\n\n";
        await DisplayAlert(daSao ? "Đã sao chép mã " + km.MaCode : "Mã " + km.MaCode,
            chiTiet + (daSao ? "Dán mã vào ô khuyến mãi khi thanh toán." : "Không sao chép tự động được. Hãy nhập mã này thủ công khi thanh toán."), "OK");
    }

    private async void OnTinTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is TinTuc t) await DisplayAlert($"{t.Icon} {t.TieuDe}", t.NoiDung, "Đóng");
    }

    private async void OnXemTatCaTinTapped(object? sender, TappedEventArgs e) => await Shell.Current.GoToAsync(nameof(TinTucPage));
    private async void OnChuongTapped(object? sender, TappedEventArgs e) => await Shell.Current.GoToAsync(nameof(ActivityPage));   // chuông = Thông báo (đơn hàng, khuyến mãi, hệ thống); Tin tức mở từ mục "Tin mới"

    private void HienDiaChi()
    {
        var dc = Services.Phien.Khach?.DiaChi;
        LblDiaChi.Text = string.IsNullOrWhiteSpace(dc) ? "Thêm địa chỉ giao hàng" : dc;
    }

    /// <summary>
    /// v75 — Chọn địa chỉ giao hàng ngay ở Trang chủ: chọn từ sổ địa chỉ, dùng vị trí hiện tại (GPS → địa chỉ) hoặc nhập địa chỉ khác.
    /// Địa chỉ chọn trở thành địa chỉ mặc định (đồng bộ lên máy chủ khi đang online) và khoảng cách quán được tính lại.
    /// </summary>
    private async void OnDiaChiTapped(object? sender, TappedEventArgs e)
    {
        var k = Services.Phien.Khach;
        if (k is null) return;
        var so = Services.TaiKhoanService.LayDiaChi();
        var nhan = new List<string>();
        foreach (var d in so) nhan.Add($"{(d.MacDinh ? "✔ " : "")}{d.Nhan}: {d.DiaChi}");
        const string GPS = "📍 Dùng vị trí hiện tại";
        const string KHAC = "✏️ Nhập địa chỉ khác";
        nhan.Add(GPS); nhan.Add(KHAC);
        var chon = await DisplayActionSheet("Giao đến đâu?", "Hủy", null, nhan.ToArray());
        if (string.IsNullOrEmpty(chon) || chon == "Hủy") return;

        string? diaChi = null;
        if (chon == KHAC)
        {
            diaChi = await this.NhapAsync("Địa chỉ giao hàng", "Nhập địa chỉ nhận món (số nhà, đường, quận...):", "Lưu", "Hủy", initialValue: k.DiaChi);
        }
        else if (chon == GPS)
        {
            diaChi = await LayDiaChiTuViTriAsync();
            if (diaChi is null) return;
        }
        else
        {
            var i = nhan.IndexOf(chon);
            if (i >= 0 && i < so.Count) diaChi = so[i].DiaChi;
        }
        if (string.IsNullOrWhiteSpace(diaChi)) return;
        diaChi = diaChi.Trim();

        if (Services.DuLieuService.DangOnline && !await Services.DuLieuService.GhiAsync("PUT", "api/mobile/khach-hang/ho-so",
                new { hoTen = k.HoTen, sdt = k.SoDienThoai ?? "", diaChi, email = k.Email })) return;
        k.DiaChi = diaChi;
        var dung = so.FirstOrDefault(d => string.Equals(d.DiaChi, diaChi, StringComparison.OrdinalIgnoreCase));
        foreach (var d in so) d.MacDinh = false;
        if (dung is null) so.Add(new Services.DiaChiLuu { Nhan = so.Count == 0 ? "Nhà" : "Khác", DiaChi = diaChi, MacDinh = true }); else dung.MacDinh = true;
        Services.TaiKhoanService.LuuDiaChi(so);
        Services.VendorLocalStore.Luu();
        HienDiaChi();
        LocDanhSach();      // tính lại khoảng cách quán theo địa chỉ mới
        NapTrangChuThem();
    }

    private async Task<string?> LayDiaChiTuViTriAsync()
    {
        try
        {
            var vt = await Geolocation.Default.GetLocationAsync(new GeolocationRequest(GeolocationAccuracy.Medium, TimeSpan.FromSeconds(10)));
            if (vt is null) { await DisplayAlert("Không lấy được vị trí", "Hãy bật định vị rồi thử lại, hoặc nhập địa chỉ thủ công.", "OK"); return null; }
            var pm = (await Geocoding.Default.GetPlacemarksAsync(vt.Latitude, vt.Longitude))?.FirstOrDefault();
            var phan = new[] { pm?.SubThoroughfare, pm?.Thoroughfare, pm?.SubLocality, pm?.SubAdminArea ?? pm?.Locality, pm?.AdminArea }
                .Where(x => !string.IsNullOrWhiteSpace(x)).ToList();
            var goiY = phan.Count > 0 ? string.Join(", ", phan) : $"{vt.Latitude:0.0000}, {vt.Longitude:0.0000}";
            // cho khách kiểm tra / bổ sung số nhà trước khi lưu
            return await this.NhapAsync("Xác nhận địa chỉ", "Vị trí của bạn (bổ sung số nhà, tầng nếu cần):", "Lưu", "Hủy", initialValue: goiY);
        }
        catch (Exception ex)
        {
            Services.CrashLog.Ghi("TrangChu.ViTri", ex);
            await DisplayAlert("Không lấy được vị trí", "Chưa cấp quyền vị trí hoặc thiết bị không hỗ trợ. Hãy nhập địa chỉ thủ công.", "OK");
            return null;
        }
    }

    // ------------------------------------------------------------------ v75: mục bổ sung ở Trang chủ
    /// <summary>Nạp "Đặt lại đơn gần đây", "Món bán chạy", "Quán được đề xuất".</summary>
    private void NapTrangChuThem()
    {
        try
        {
            var email = Services.Phien.Khach?.Email;

            var don = Services.TrangChuService.DonGanDay(email, 5)
                .Select(d => new DonGanDayVm(d,
                    string.Join(", ", d.ChiTiet.Take(3).Select(c => $"{c.SoLuong}× {c.MonAn?.TenMon}")) + (d.ChiTiet.Count > 3 ? $" +{d.ChiTiet.Count - 3} món" : ""),
                    d.NgayDat.ToString("dd/MM HH:mm") + $" · {d.TongThanhToan:N0}đ")).ToList();
            DsDatLai.ItemsSource = don;
            DsDatLai.IsVisible = LblDatLai.IsVisible = don.Count > 0;

            var ban = Services.TrangChuService.MonBanChay(8).Select(x => new GoiYMonVm(x.Mon, $"🔥 Đã bán {x.DaBan} phần")).ToList();
            DsBanChay.ItemsSource = ban;
            DsBanChay.IsVisible = LblBanChay.IsVisible = ban.Count > 0;

            var dx = Services.TrangChuService.QuanDeXuat(email, 6).Select(x => new QuanDeXuatVm(x.Q, x.LyDo)).ToList();
            DsDeXuat.ItemsSource = dx;
            DsDeXuat.IsVisible = LblDeXuat.IsVisible = dx.Count > 0;
        }
        catch (Exception ex) { Services.CrashLog.Ghi("TrangChu.Them", ex); }
    }

    private async void OnDeXuatTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is not GianHang gh) return;
        await Shell.Current.GoToAsync(nameof(MenuCartPage), new Dictionary<string, object> { { "GianHang", gh } });
    }

    private async void OnDatLaiTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is not DonHang don) return;
        var gh = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == don.GianHangId);
        if (gh is null) return;
        if (Services.GioHangService.CoMonQuanKhac(gh.Id) &&
            !await DisplayAlert("Đổi quán?", "Giỏ hàng đang có món của quán khác. Đặt lại sẽ thay giỏ hàng hiện tại. Tiếp tục?", "Tiếp tục", "Hủy")) return;
        var (them, bo) = Services.TrangChuService.DatLai(don);
        if (them == 0) { await DisplayAlert("Không đặt lại được", "Các món của đơn này hiện đã hết hoặc ngừng bán. Hãy chọn món khác trong quán.", "OK"); }
        else
        {
            await Services.GioHangService.LuuAsync();
            if (bo > 0) await DisplayAlert("Đã thêm vào giỏ", $"Đã thêm {them} món. {bo} món đã hết/ngừng bán nên được bỏ qua.", "OK");
        }
        await Shell.Current.GoToAsync(nameof(MenuCartPage), new Dictionary<string, object> { { "GianHang", gh } });
    }

    private void OnChipDangMoClicked(object? sender, EventArgs e) => SwDangMo.IsToggled = !SwDangMo.IsToggled;

    // v90: lọc quán đang khuyến mãi / mới tham gia
    private bool _chiKhuyenMai, _chiQuanMoi;
    private void OnChipKhuyenMaiClicked(object? sender, EventArgs e) { _chiKhuyenMai = !_chiKhuyenMai; LocDanhSach(); }
    private void OnChipQuanMoiClicked(object? sender, EventArgs e) { _chiQuanMoi = !_chiQuanMoi; LocDanhSach(); }

    private void OnChipSapXepClicked(object? sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: string tham } || !int.TryParse(tham, out var idx)) return;
        PkSapXep.SelectedIndex = PkSapXep.SelectedIndex == idx ? 0 : idx;
    }

    private void CapNhatChip()
    {
        void Dat(Button b, bool bat)
        {
            b.BackgroundColor = bat ? Color.FromArgb("#7C3AED") : Color.FromArgb("#EDE9FE");
            b.TextColor = bat ? Colors.White : Color.FromArgb("#5B21B6");
        }
        Dat(ChipDangMo, SwDangMo.IsToggled);
        Dat(ChipGan, PkSapXep.SelectedIndex == 1);
        Dat(ChipSao, PkSapXep.SelectedIndex == 2);
        Dat(ChipKhuyenMai, _chiKhuyenMai);
        Dat(ChipQuanMoi, _chiQuanMoi);
    }

    // ------------------------------------------------------------------ tìm kiếm / lọc / sắp xếp
    /// <summary>🎤 Nói "đặt hai phở bò" → mở món kèm số lượng; nói tên quán/món bình thường → điền vào ô tìm kiếm.</summary>
    private async void OnGiongNoiTapped(object? sender, TappedEventArgs e)
    {
        try
        {
            await DisplayAlert("Nghe giọng nói", "Bấm OK rồi nói, ví dụ: \"đặt hai phở bò\" hoặc \"bún chả\".", "OK");
            var cau = await Services.GiongNoiService.NgheAsync();
            if (string.IsNullOrWhiteSpace(cau)) { await DisplayAlert("Không nghe được", "Hãy kiểm tra quyền micro và thử lại.", "Đóng"); return; }

            var dat = cau.Contains("đặt", StringComparison.OrdinalIgnoreCase) || cau.Contains("mua", StringComparison.OrdinalIgnoreCase) || cau.Contains("cho tôi", StringComparison.OrdinalIgnoreCase);
            var khop = Services.GiongNoiService.PhanTichDatMon(cau, MockData.DanhSachMonAn);
            if (dat && khop is { } k)
            {
                var gh = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == k.Mon.GianHangId);
                await Shell.Current.GoToAsync(nameof(MonAnChiTietPage), new Dictionary<string, object> { { "Mon", k.Mon }, { "GianHang", gh! }, { "SoLuong", k.SoLuong } });
                return;
            }
            EntryTimKiem.Text = cau;
        }
        catch (Exception ex)
        {
            await DisplayAlert("Giọng nói chưa dùng được", ex.Message, "Đóng");
        }
    }

    private readonly Services.TreTimKiem _treLoc = new();
    private void OnTimKiemChanged(object sender, TextChangedEventArgs e) => _treLoc.Chay(LocDanhSach);   // lọc sau khi ngừng gõ (không phá bộ gõ tiếng Việt)

    /// <summary>Nhấn Enter / nút tìm: lưu từ khóa vào lịch sử tìm kiếm.</summary>
    private void OnTimKiemCompleted(object? sender, EventArgs e)
    {
        Services.TimKiemService.ThemLichSu(EntryTimKiem.Text);
        NapLichSuVaPhoBien();
    }

    private void OnLocTextChanged(object sender, TextChangedEventArgs e) { if (!_dangKhoiTao) _treLoc.Chay(LocDanhSach); }
    private void OnLocToggled(object sender, ToggledEventArgs e) { if (!_dangKhoiTao) LocDanhSach(); }

    private void OnLocPickerChanged(object? sender, EventArgs e)
    {
        if (_dangKhoiTao) return;
        if (ReferenceEquals(sender, PkDanhMuc)) _danhMucMon = PkDanhMuc.SelectedIndex <= 0 ? "" : (PkDanhMuc.SelectedItem as string ?? "");
        LocDanhSach();
    }

    private void OnMoLocTapped(object? sender, TappedEventArgs e) => KhungLoc.IsVisible = !KhungLoc.IsVisible;

    private void OnXoaLocTapped(object? sender, TappedEventArgs e) => XoaLoc();
    private void OnXoaLocClicked(object? sender, EventArgs e) => XoaLoc();

    private void XoaLoc()
    {
        _dangKhoiTao = true;
        EntryTimKiem.Text = ""; EntryKhuVuc.Text = ""; SwDangMo.IsToggled = false; _chiKhuyenMai = false; _chiQuanMoi = false;
        PkGia.SelectedIndex = 0; PkSao.SelectedIndex = 0; PkKhoangCach.SelectedIndex = 0; PkThoiGian.SelectedIndex = 0; PkSapXep.SelectedIndex = 0;
        _danhMucMon = ""; _loai = ""; NapLuoiDanhMuc("✨ Tất cả");
        PkDanhMuc.SelectedIndex = 0;
        _dangKhoiTao = false;
        LocDanhSach();
    }

    private void OnGoiYTuKhoaClicked(object? sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: string tu }) return;
        EntryTimKiem.Text = tu;                 // TextChanged tự lọc lại
        Services.TimKiemService.ThemLichSu(tu);
        NapLichSuVaPhoBien();
    }

    private void OnXoaMotLichSuClicked(object? sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: string tu }) return;
        Services.TimKiemService.XoaMotLichSu(tu);
        NapLichSuVaPhoBien();
    }

    private void OnXoaLichSuTapped(object? sender, TappedEventArgs e)
    {
        Services.TimKiemService.XoaLichSu();
        NapLichSuVaPhoBien();
    }

    private void NapLichSuVaPhoBien()
    {
        var ls = Services.TimKiemService.LichSu();
        DsLichSu.ItemsSource = ls;
        KhungLichSu.IsVisible = ls.Count > 0;
        var pb = Services.TimKiemService.MonPhoBien(8);
        DsPhoBien.ItemsSource = pb;
        KhungPhoBien.IsVisible = pb.Count > 0;
    }

    private Services.BoLocTimKiem TaoBoLoc()
    {
        var loc = new Services.BoLocTimKiem
        {
            TuKhoa = EntryTimKiem.Text ?? "",
            LoaiMon = _loai,
            DanhMuc = _danhMucMon,
            KhuVuc = EntryKhuVuc.Text ?? "",
            ChiDangMo = SwDangMo.IsToggled,
            ChiKhuyenMai = _chiKhuyenMai,
            ChiQuanMoi = _chiQuanMoi,
        };
        switch (PkGia.SelectedIndex)
        {
            case 1: loc.GiaDen = 30000; break;
            case 2: loc.GiaTu = 30000; loc.GiaDen = 60000; break;
            case 3: loc.GiaTu = 60000; loc.GiaDen = 100000; break;
            case 4: loc.GiaTu = 100000; break;
        }
        loc.SaoTu = PkSao.SelectedIndex switch { 1 => 3, 2 => 4, 3 => 4.5, _ => 0 };
        loc.KmToiDa = PkKhoangCach.SelectedIndex switch { 1 => 2, 2 => 5, 3 => 10, _ => (double?)null };
        loc.PhutToiDa = PkThoiGian.SelectedIndex switch { 1 => 20, 2 => 30, 3 => 45, 4 => 60, _ => (int?)null };
        loc.SapXep = PkSapXep.SelectedIndex switch { 1 => "gan", 2 => "sao", 3 => "giaThap", 4 => "giaCao", 5 => "banChay", 6 => "giaoNhanh", _ => "" };
        return loc;
    }

    /// <summary>Tìm theo tên quán / tên món / từ khóa / danh mục / khu vực; lọc mở cửa, giá, sao, khoảng cách; sắp xếp.</summary>
    private void LocDanhSach()
    {
        if (_dangKhoiTao) return;
        var loc = TaoBoLoc();
        var quan = Services.TimKiemService.Tim(loc);
        BindableLayout.SetItemsSource(LayoutQuanNgang, quan);
        var soHang = quan.Count > 2 ? 2 : 1;
        var cao = soHang * 160 + 4;                      // mỗi ô 150 + khoảng cách 10
        LayoutQuanNgang.HeightRequest = cao;
        DsQuanNgang.HeightRequest = cao;
        DsQuanNgang.IsVisible = quan.Count > 0;

        // Gợi ý món: các món khớp tiêu chí trong những quán còn lại
        var mon = Services.TimKiemService.MonKhop(loc, quan);
        DsGoiY.ItemsSource = mon;
        DsGoiY.IsVisible = LblGoiYTieuDe.IsVisible = mon.Count > 0;
        LblGoiYTieuDe.Text = string.IsNullOrWhiteSpace(loc.TuKhoa) ? "🍽️ Món gợi ý" : $"🍽️ Món khớp “{loc.TuKhoa.Trim()}”";

        var coLoc = loc.CoLoc;
        KhungKhamPha.IsVisible = !coLoc;
        KhungTrangChuThem.IsVisible = !coLoc;
        CapNhatChip();
        LblXoaLoc.IsVisible = coLoc;
        LblKetQua.Text = coLoc ? $"🏪 {quan.Count} quán phù hợp" : "🏪 Quán gần bạn";
        var ganGapKm = loc.KmToiDa is not null || loc.SapXep == "gan";
        LblGhiChuKhoangCach.IsVisible = !Services.TimKiemService.CoDiaChiKhach;
        LblNutLoc.Text = (coLoc || loc.SapXep.Length > 0) ? "⚙ Bộ lọc & sắp xếp (đang áp dụng)" : "⚙ Bộ lọc & sắp xếp";

        // Thông báo khi không có kết quả
        KhungKhongKetQua.IsVisible = quan.Count == 0;
        if (quan.Count == 0)
        {
            var tu = (loc.TuKhoa ?? "").Trim();
            if (MockData.DanhSachGianHang.All(g => !Services.TimKiemService.QuanHienThi(g)))
            {
                LblKhongKetQua.Text = "Chưa có quán nào";
                LblKhongKetQuaPhu.Text = "Các quán đối tác đã được duyệt sẽ hiện ở đây.";
            }
            else
            {
                LblKhongKetQua.Text = tu.Length > 0 ? $"Không tìm thấy kết quả cho “{tu}”" : "Không có quán nào phù hợp với bộ lọc";
                LblKhongKetQuaPhu.Text = ganGapKm && !Services.TimKiemService.CoDiaChiKhach
                    ? "Bạn chưa có địa chỉ giao hàng nên chưa tính được khoảng cách. Hãy thêm địa chỉ ở đầu trang hoặc bỏ lọc khoảng cách."
                    : "Hãy kiểm tra chính tả, thử từ khóa ngắn hơn, đổi/bỏ bộ lọc hoặc chọn một món phổ biến bên dưới.";
            }
        }
    }

    private async void OnGianHangTapped(object? sender, EventArgs e)
    {
        // Mẫu ô quán dùng Border (không còn Frame) nên lấy quán từ tham số của thao tác chạm.
        var gh = (e as TappedEventArgs)?.Parameter as GianHang
                 ?? ((sender as BindableObject)?.BindingContext as Services.QuanKetQua)?.Gh;
        if (gh is null) return;
        await Shell.Current.GoToAsync(nameof(MenuCartPage), new Dictionary<string, object>
        {
            { "GianHang", gh }
        });
    }

    private async void OnTaiKhoanTapped(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("//chinh/tai-khoan");
    }

    private async void OnBanDoTapped(object? sender, TappedEventArgs e)
    {
        try { await BanDoPage.MoAsync(EntryTimKiem.Text ?? ""); }
        catch (Exception ex)
        {
            Services.CrashLog.Ghi("TrangChu.OnBanDoTapped", ex);
            try { await DisplayAlert("Không mở được bản đồ", "Đã có lỗi khi mở bản đồ. Chi tiết được ghi vào nhật ký lỗi của ứng dụng.", "OK"); } catch { }
        }
    }
}

public class ChienDichApiDto
{
    public int MaChienDich { get; set; }
    public int MaGianHang { get; set; }
    public string TieuDe { get; set; } = "";
    public string? NoiDung { get; set; }
    public string? HinhAnh { get; set; }
    public string? LoaiViTri { get; set; }
    public string? TenGianHang { get; set; }
}

public record BannerQc(int Id, string TieuDe, string AnhUrl, string LienKet);

public class BannerApiDto
{
    public int Id { get; set; }
    public string? TieuDe { get; set; }
    public string? HinhAnh { get; set; }
    public string? LienKet { get; set; }
}

public record DanhMucItem(string Khoa, string Icon, string Ten, string Nen, double Vien);

/// <summary>Một món trong mục "Dành riêng cho bạn" kèm lý do gợi ý.</summary>
public sealed record GoiYMonVm(MonAn Mon, string LyDo);

public sealed class GoiYMonItemDto { public int MaMonAn { get; set; } public string LyDo { get; set; } = ""; }
public sealed class GoiYMonDto { public string NhomGio { get; set; } = ""; public List<GoiYMonItemDto> Ds { get; set; } = new(); }
public sealed record DonGanDayVm(DonHang Don, string Tom, string Ngay);
public sealed record QuanDeXuatVm(Services.QuanKetQua Q, string LyDo);
