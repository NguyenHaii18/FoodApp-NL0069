namespace FoodApp.Maui.Views;

/// <summary>
/// Bấm vào logo FoodApp ở bất kỳ khu nào (khách / đối tác / tài xế / quản trị) sẽ về đúng trang chủ của khu đó.
/// Khu được nhận biết theo trang đang mở (Vendor* / Driver* / Admin*), còn lại là khách.
/// </summary>
public static class VeTrangChu
{
    public static async Task DiAsync()
    {
        try
        {
            var shell = Shell.Current;
            if (shell is null) return;
            var ten = shell.CurrentPage?.GetType().Name ?? "";
            if (ten.StartsWith("Vendor")) await VeTrangAsync<VendorHomePage>(shell);
            else if (ten.StartsWith("Driver")) await VeTrangAsync<DriverHomePage>(shell);
            else if (ten.StartsWith("Admin") && ten != "AdminLoginPage") await VeTrangAsync<AdminHomePage>(shell);
            else
            {
                var nav = shell.Navigation;
                while (nav.NavigationStack.Count > 1) await nav.PopAsync(false);
                await shell.GoToAsync("//chinh/trang-chu");
            }
        }
        catch (Exception ex) { Services.CrashLog.Ghi("VeTrangChu", ex); }
    }

    private static async Task VeTrangAsync<T>(Shell shell) where T : Page
    {
        var nav = shell.Navigation;
        if (shell.CurrentPage is T) return;
        if (nav.NavigationStack.Any(p => p is T))
            while (nav.NavigationStack.Count > 1 && nav.NavigationStack[^1] is { } top && top is not T) await nav.PopAsync(false);
        else
            await shell.GoToAsync(typeof(T).Name);
    }

    /// <summary>Gắn thao tác "bấm vào về trang chủ" cho một phần tử logo.</summary>
    public static T Gan<T>(T logo) where T : View
    {
        logo.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => await DiAsync()) });
        SemanticProperties.SetDescription(logo, "Về trang chủ");
        return logo;
    }
}
