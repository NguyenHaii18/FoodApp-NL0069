using FoodApp.Maui.Models;
using FoodApp.Maui.Services;
using Microsoft.Maui.Dispatching;

namespace FoodApp.Maui.Views;

public partial class VendorOrdersPage : ContentPage
{
    // null = "Tất cả"
    private readonly (string Nhan, TrangThaiDonHang? TrangThai)[] _boLoc =
    {
        ("Tất cả", null),
        ("Chờ xác nhận", TrangThaiDonHang.ChoXacNhan),
        ("Đang chuẩn bị", TrangThaiDonHang.DangLam),
        ("Đang giao", TrangThaiDonHang.DangGiao),
        ("Hoàn thành", TrangThaiDonHang.HoanThanh),
        ("Đã hủy", TrangThaiDonHang.DaHuy),
    };

    private TrangThaiDonHang? _dangLoc;
    private readonly List<Button> _nutBoLoc = new();

    public VendorOrdersPage()
    {
        InitializeComponent();
        DungBoLoc();
    }

    private IDispatcherTimer? _boDem;

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        NapDanhSach();
        await Services.DuLieuService.TaiDonHangGianHangAsync(MockData.GianHangHienTai.Id);
        NapDanhSach();

        // Cập nhật đếm ngược 5 phút phản hồi và tự hủy đơn quá hạn (NV04).
        _boDem ??= Dispatcher.CreateTimer();
        _boDem.Interval = TimeSpan.FromSeconds(30);
        _boDem.Tick -= OnBoDemTick;
        _boDem.Tick += OnBoDemTick;
        _boDem.Start();

        // Thời gian thực: đơn mới / đơn đổi trạng thái -> tải lại từ API ngay
        RealtimeService.CoThayDoi -= OnRealtime;
        RealtimeService.CoThayDoi += OnRealtime;
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        _boDem?.Stop();
        RealtimeService.CoThayDoi -= OnRealtime;
    }

    private bool _dangTaiRt;

    private async void OnRealtime(RealtimeSuKien e)
    {
        if (_dangTaiRt || !Services.DuLieuService.DangOnline) return;
        _dangTaiRt = true;
        try
        {
            await Services.DuLieuService.TaiDonHangGianHangAsync(MockData.GianHangHienTai.Id);
            NapDanhSach();
            if (e.Loai == "OrderCreated")
                try { Vibration.Default.Vibrate(TimeSpan.FromMilliseconds(500)); } catch { /* máy không hỗ trợ rung */ }
        }
        catch { /* mất mạng: bộ đếm giờ sẽ thử lại */ }
        finally { _dangTaiRt = false; }
    }

    private void OnBoDemTick(object? sender, EventArgs e) => NapDanhSach();

    private void DungBoLoc()
    {
        foreach (var (nhan, trangThai) in _boLoc)
        {
            var nut = new Button
            {
                Text = nhan,
                CornerRadius = 16,
                HeightRequest = 34,
                Padding = new Thickness(14, 0),
                FontSize = 12,
                BackgroundColor = trangThai is null ? VendorPalette.Get("Primary") : Colors.White,
                TextColor = trangThai is null ? Colors.White : VendorPalette.Get("TextGrey"),
                BorderColor = VendorPalette.Get("BorderColor"),
                BorderWidth = 1,
            };
            nut.Clicked += (_, _) => LocTheoTrangThai(trangThai, nut);
            _nutBoLoc.Add(nut);
            KhungBoLoc.Children.Add(nut);
        }
    }

    private void LocTheoTrangThai(TrangThaiDonHang? trangThai, Button nutDuocChon)
    {
        _dangLoc = trangThai;

        foreach (var nut in _nutBoLoc)
        {
            bool laDuocChon = nut == nutDuocChon;
            nut.BackgroundColor = laDuocChon ? VendorPalette.Get("Primary") : Colors.White;
            nut.TextColor = laDuocChon ? Colors.White : VendorPalette.Get("TextGrey");
        }

        NapDanhSach();
    }

    private void NapDanhSach()
    {
        // TODO: thay bằng GET /api/gian-hang/don-hang?trangThai=... khi có API thật.
        if (DoiTacService.HuyDonQuaHan(MockData.GianHangHienTai.Id) > 0)
            _ = DisplayAlert("Đơn tự hủy", "Có đơn quá 5 phút chưa phản hồi đã bị hệ thống tự hủy và hoàn tiền cho khách.", "OK");
        var danhSach = MockData.DonHangCuaGianHang
            .Where(d => d.GianHangId == MockData.GianHangHienTai.Id)
            .Where(d => _dangLoc is null || d.TrangThai == _dangLoc)
            .OrderByDescending(d => d.NgayDat)
            .ToList();

        DsDonHang.ItemsSource = danhSach;
        LblRong.IsVisible = danhSach.Count == 0;
    }

    private async void OnChiTietDonTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is DonHang don)
            await Shell.Current.GoToAsync(nameof(VendorOrderDetailPage), new Dictionary<string, object> { { "Don", don } });
    }

    private async void OnNhanTinClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: DonHang don }) return;
        await ChatPage.MoAsync(don.Id, "GianHang", string.IsNullOrWhiteSpace(don.KhachTen) ? "Khách hàng" : don.KhachTen, don.KhachSdt);
    }

    private async void OnXacNhanClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: DonHang don }) return;

        var chuanBiPhut = await DoiTacService.ChonThoiGianChuanBiAsync(don);
        if (chuanBiPhut is null) return;
        if (!await DoiTacService.XacNhanDonAsync(don, chuanBiPhut)) return;

        NapDanhSach();
        await DisplayAlert("Đã xác nhận", $"Đơn #{don.Id} đã được xác nhận, hãy bắt đầu chuẩn bị món.", "OK");
    }

    private async void OnTuChoiClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: DonHang don }) return;

        if (await DoiTacService.TuChoiDonAsync(this, don)) NapDanhSach();
    }

    /// <summary>Hủy đơn đã xác nhận (trước khi tài xế lấy hàng): bắt buộc lý do; đơn đã trả online tự tạo yêu cầu hoàn tiền.</summary>
    private async void OnHuyDonClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: DonHang don }) return;
        if (await DoiTacService.HuyDonDangLamAsync(this, don))
        {
            NapDanhSach();
            await DisplayAlert("Đã hủy đơn", $"Đơn #{don.Id} đã hủy; khách được thông báo" + (don.DaHoanTien ? " và yêu cầu hoàn tiền (nếu đã thanh toán online) đang chờ Quản trị duyệt." : "."), "OK");
        }
    }

    private async void OnHuyHoanTienClicked(object sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(VendorCancelRefundPage));

    private async void OnSanSangGiaoClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: DonHang don }) return;
        if (don.TrangThai != TrangThaiDonHang.DangLam || don.SanSangGiao) return;

        if (!await DoiTacService.BanGiaoTaiXeAsync(don)) return;     // lỗi: GhiAsync đã báo, giữ nguyên trạng thái

        NapDanhSach();
        await DisplayAlert("Đã sẵn sàng", $"Đơn #{don.Id} đã sẵn sàng, đang chờ tài xế đến lấy.", "OK");
    }

    private async void OnBatDauChuanBiClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: DonHang don }) return;
        if (!await DoiTacService.BatDauChuanBiAsync(don)) return;
        NapDanhSach();
    }

    private async void OnXacNhanBanGiaoClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: DonHang don }) return;
        if (!await DisplayAlert("Bàn giao món", $"Xác nhận đã trao món của đơn #{don.Id} cho tài xế?", "Đã trao", "Chưa")) return;
        if (!await DoiTacService.XacNhanBanGiaoAsync(don)) return;
        NapDanhSach();
        await DisplayAlert("Đã bàn giao", "Tài xế được thông báo; chờ tài xế bấm \"Đã lấy hàng\".", "OK");
    }

    // ---- v31: chọn người giao — tài xế của quán hay shipper ngoài ----
    private async void OnChonNguoiGiaoClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: DonHang don }) return;
        if (!DuLieuService.DangOnline) { await DisplayAlert("Cần kết nối", "Chọn người giao cần kết nối máy chủ.", "OK"); return; }
        var ds = await DoiTacService.TaiTaiXeQuanAsync();
        var dsTx = ds?.TaiXe.Where(t => t.HoatDong).ToList() ?? new List<TaiXeQuanDto>();
        var nhan = new List<string> { "🛵 Shipper ngoài (nền tảng)" };
        nhan.AddRange(dsTx.Select(t => $"🏠 {t.HoTen}{(t.DangGiao ? " (đang bận)" : "")}"));
        var chon = await DisplayActionSheet($"Người giao đơn #{don.Id}", "Đóng", null, nhan.ToArray());
        var i = nhan.IndexOf(chon);
        if (i < 0) return;
        if (!await DoiTacService.ChonNguoiGiaoAsync(don, i == 0 ? "Ngoai" : "Quan", i == 0 ? null : dsTx[i - 1].Id)) return;
        await DuLieuService.TaiDonHangGianHangAsync(MockData.GianHangHienTai.Id);
        NapDanhSach();
    }

    private async void OnQuanLyNguoiGiaoClicked(object sender, EventArgs e)
    {
        if (!DuLieuService.DangOnline) { await DisplayAlert("Cần kết nối", "Cần kết nối máy chủ để quản lý tài xế của quán.", "OK"); return; }
        var ds = await DoiTacService.TaiTaiXeQuanAsync();
        if (ds is null) return;
        var macDinh = ds.CheDoGiao == "Quan" ? "Tài xế của quán" : "Shipper ngoài";
        var chon = await DisplayActionSheet($"Cách giao mặc định hiện tại: {macDinh}", "Đóng", null,
            "Đặt mặc định: Shipper ngoài", "Đặt mặc định: Tài xế của quán", "➕ Thêm tài xế của quán",
            ds.TaiXe.Count == 0 ? "(Quán chưa có tài xế riêng)" : "👥 Danh sách tài xế của quán");
        switch (chon)
        {
            case "Đặt mặc định: Shipper ngoài": await DoiTacService.DatCheDoGiaoAsync("Ngoai"); break;
            case "Đặt mặc định: Tài xế của quán": await DoiTacService.DatCheDoGiaoAsync("Quan"); break;
            case "➕ Thêm tài xế của quán": await ThemTaiXeQuanAsync(); break;
            case "👥 Danh sách tài xế của quán":
                var nhan = ds.TaiXe.Select(t => $"{t.HoTen} · {t.Sdt} · {(!t.HoatDong ? "🔒 đã khóa" : t.DangGiao ? "đang giao" : "sẵn sàng")}").ToArray();
                var c = await DisplayActionSheet("Chạm để khóa / mở khóa", "Đóng", null, nhan);
                var i = Array.IndexOf(nhan, c);
                if (i >= 0) await DoiTacService.DatHoatDongTaiXeQuanAsync(ds.TaiXe[i].Id, !ds.TaiXe[i].HoatDong);
                break;
        }
    }

    private async Task ThemTaiXeQuanAsync()
    {
        var hoTen = await this.NhapAsync("Thêm tài xế của quán", "Họ tên tài xế:"); if (string.IsNullOrWhiteSpace(hoTen)) return;
        var sdt = await this.NhapAsync("Thêm tài xế của quán", "Số điện thoại:", keyboard: Keyboard.Telephone); if (string.IsNullOrWhiteSpace(sdt)) return;
        var tenDn = await this.NhapAsync("Thêm tài xế của quán", "Tên đăng nhập (để tài xế vào app tài xế):"); if (string.IsNullOrWhiteSpace(tenDn)) return;
        var matKhau = await this.NhapAsync("Thêm tài xế của quán", "Mật khẩu (tối thiểu 6 ký tự):"); if (string.IsNullOrWhiteSpace(matKhau)) return;
        await DoiTacService.ThemTaiXeQuanAsync(tenDn, matKhau, hoTen, sdt);
    }

    private void OnRefreshing(object? sender, EventArgs e)
    {
        NapDanhSach();
        RefreshDsDon.IsRefreshing = false;
    }
}
