using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Xem nhật ký thao tác — chỉ Admin tổng. Nhật ký chỉ đọc: không có nút xóa để bảo đảm tính đối soát.</summary>
public partial class AdminAuditLogPage : ContentPage
{
    private enum Loc { TatCa, QuanTri, DangNhap, BiTuChoi }
    private Loc _loc = Loc.TatCa;
    private int _ngay = 7;                    // khoảng thời gian lấy từ máy chủ: 1 | 7 | 30 | 0 (tất cả)
    private List<NhatKyThaoTac> _dangHien = new();

    public AdminAuditLogPage()
    {
        InitializeComponent();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (!await PhanQuyenService.KiemTraAsync(this, Quyen.XemNhatKy))
        {
            await Shell.Current.GoToAsync("..");
            return;
        }
        // Online: đọc nhật ký từ Web; offline: nhật ký trên máy.
        if (ToolbarItems.Count == 0)
            ToolbarItems.Add(new ToolbarItem { Text = "Xuất CSV", Command = new Command(async () => await NhatKyService.XuatCsvAsync(this, _dangHien)) });
        await TaiLaiAsync();
    }

    private List<NhatKyThaoTac>? _tuServer;

    private async Task TaiLaiAsync()
    {
        _tuServer = await NhatKyService.TaiTuServerAsync(_ngay);
        NapDanhSach();
    }

    private void VeThanhNgay()
    {
        ThanhNgay.Children.Clear();
        foreach (var (nhan, ngay) in new[] { ("Hôm nay", 1), ("7 ngày", 7), ("30 ngày", 30), ("Tất cả", 0) })
        {
            var chon = ngay == _ngay;
            var nut = new Button
            {
                Text = nhan, CornerRadius = 18, HeightRequest = 32, Padding = new Thickness(12, 0), FontSize = 12,
                BackgroundColor = chon ? Mau("Primary") : Mau("PrimarySoft"),
                TextColor = chon ? Colors.White : Mau("Primary"),
            };
            nut.Clicked += async (_, _) => { _ngay = ngay; await TaiLaiAsync(); };
            ThanhNgay.Children.Add(nut);
        }
    }

    private async void OnChonDong(object? sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection.FirstOrDefault() is not NhatKyThaoTac x) return;
        DsNhatKy.SelectedItem = null;
        await DisplayAlert(x.HanhDong.Length > 60 ? x.HanhDong[..60] + "…" : x.HanhDong,
            $"Thời gian: {x.ThoiGianHienThi}\nNgười thực hiện: {x.NguoiThucHien}\nĐối tượng: {(string.IsNullOrEmpty(x.DoiTuong) ? "—" : x.DoiTuong)}\nKết quả: {(x.ThanhCong ? "Thành công" : "Thất bại / bị từ chối")}\n\n{x.ChiTiet}", "Đóng");
    }

    private static Color Mau(string k) => (Color)Application.Current!.Resources[k];

    private void VeThanhLoc()
    {
        ThanhLoc.Children.Clear();
        foreach (var (nhan, loc) in new[]
        {
            ("Tất cả", Loc.TatCa), ("Thao tác quản trị", Loc.QuanTri), ("Đăng nhập / đăng xuất", Loc.DangNhap), ("Bị từ chối / thất bại", Loc.BiTuChoi),
        })
        {
            var chon = loc == _loc;
            var nut = new Button
            {
                Text = nhan, CornerRadius = 18, HeightRequest = 36, Padding = new Thickness(14, 0), FontSize = 12.5,
                BackgroundColor = chon ? Mau("Primary") : Mau("PrimarySoft"),
                TextColor = chon ? Colors.White : Mau("Primary"),
            };
            nut.Clicked += (_, _) => { _loc = loc; NapDanhSach(); };
            ThanhLoc.Children.Add(nut);
        }
    }

    private readonly Services.TreTimKiem _tre = new();
    private void OnTimChanged(object? sender, TextChangedEventArgs e) => _tre.Chay(NapDanhSach);   // chờ ngừng gõ rồi mới lọc (không phá bộ gõ tiếng Việt)

    private void NapDanhSach()
    {
        VeThanhLoc();
        VeThanhNgay();
        var tuKhoa = (EntryTim.Text ?? "").Trim().ToLowerInvariant();
        IEnumerable<NhatKyThaoTac> ds = _tuServer ?? NhatKyService.TatCa();

        ds = _loc switch
        {
            Loc.QuanTri => ds.Where(x => (x.VaiTro.StartsWith("QuanTri") || x.VaiTro.Contains("QuanTri")) && !x.HanhDong.StartsWith("Đăng")),
            Loc.DangNhap => ds.Where(x => x.HanhDong.StartsWith("Đăng nhập") || x.HanhDong.StartsWith("Đăng xuất")),
            Loc.BiTuChoi => ds.Where(x => !x.ThanhCong),
            _ => ds,
        };
        if (tuKhoa.Length > 0)
            ds = ds.Where(x => (x.TaiKhoan + " " + x.HanhDong + " " + x.DoiTuong + " " + x.ChiTiet).ToLowerInvariant().Contains(tuKhoa));

        var list = ds.Take(500).ToList();
        _dangHien = list;
        DsNhatKy.ItemsSource = list;
        LblSo.Text = $"{list.Count} dòng" + (_tuServer is null ? " (nhật ký trên máy này)" : _ngay == 0 ? " (tối đa 500 dòng mới nhất từ máy chủ)" : $" trong {(_ngay == 1 ? "hôm nay" : _ngay + " ngày gần nhất")} (tối đa 500)") + " · chạm một dòng để xem chi tiết";
    }
}
