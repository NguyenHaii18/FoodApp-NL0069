using System.Text.Json;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Ghi chú nội bộ của CSKH về khách hàng. Lưu TRÊN THIẾT BỊ (Preferences) — chưa đồng bộ lên máy chủ nên chỉ nhân viên dùng máy này thấy.</summary>
public static class GhiChuKhachService
{
    public sealed record GhiChu(DateTime Luc, string NoiDung);
    private const string ChiMuc = "cskh_ghichu_chimuc";
    private static string Khoa(int maKH) => "cskh_ghichu_" + maKH;

    public static List<GhiChu> Doc(int maKH)
    {
        try { return JsonSerializer.Deserialize<List<GhiChu>>(Preferences.Default.Get(Khoa(maKH), "[]")) ?? new(); }
        catch { return new(); }
    }

    public static void Them(int maKH, string ten, string noiDung)
    {
        try
        {
            var ds = Doc(maKH);
            ds.Insert(0, new GhiChu(DateTime.Now, noiDung.Trim()));
            Preferences.Default.Set(Khoa(maKH), JsonSerializer.Serialize(ds.Take(50).ToList()));
            var cm = DocChiMuc(); cm[maKH.ToString()] = ten;
            Preferences.Default.Set(ChiMuc, JsonSerializer.Serialize(cm));
        }
        catch { /* bộ nhớ thiết bị lỗi thì bỏ qua, không làm hỏng màn hình */ }
    }

    public static Dictionary<string, string> DocChiMuc()
    {
        try { return JsonSerializer.Deserialize<Dictionary<string, string>>(Preferences.Default.Get(ChiMuc, "{}")) ?? new(); }
        catch { return new(); }
    }

    /// <summary>Xem + thêm ghi chú nội bộ của một khách.</summary>
    public static async Task MoAsync(Page p, int maKH, string ten)
    {
        while (true)
        {
            var ds = Doc(maKH);
            var tom = ds.Count == 0 ? "Chưa có ghi chú." : string.Join("\n\n", ds.Take(8).Select(g => $"{g.Luc:dd/MM/yyyy HH:mm}\n{g.NoiDung}"));
            var chon = await p.DisplayActionSheet($"Ghi chú nội bộ — {ten}\n{tom}", "Đóng", null, "➕ Thêm ghi chú");
            if (chon != "➕ Thêm ghi chú") return;
            var nd = await p.NhapAsync("Ghi chú nội bộ", "Khách sẽ không thấy ghi chú này.", "Lưu", "Hủy", "VD: khách hay đổi địa chỉ, ưu tiên gọi trước 18h", 300);
            if (string.IsNullOrWhiteSpace(nd)) continue;
            Them(maKH, ten, nd);
            NhatKyService.GhiQuanTri("CSKH thêm ghi chú nội bộ", $"{ten} (#{maKH})");
        }
    }
}

/// <summary>
/// v91 — Màn làm việc của Chăm sóc khách hàng (CSKH): tra cứu khách, ghi chú nội bộ, và 8 nhóm yêu cầu hỗ trợ
/// (đơn hàng, thanh toán, giao hàng, nhà hàng, tài xế, voucher, tài khoản, hoàn tiền) — mỗi nhóm mở đúng màn xử lý sẵn có.
/// </summary>
public sealed class AdminCskhPage : AdminKyThuatTrang
{
    protected override Quyen? QuyenCan => Quyen.XuLyVanDe;
    public AdminCskhPage() : base("Chăm sóc khách hàng") { }

    private static View Muc(string icon, string ten, string moTa, string route)
    {
        var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 10 };
        g.Add(new Label { Text = icon, FontSize = 22, VerticalOptions = LayoutOptions.Center }, 0, 0);
        var st = new VerticalStackLayout { Spacing = 1 };
        st.Add(AdminUi.Nhan(ten, 13.5, dam: true)); st.Add(AdminUi.Nhan(moTa, 11.5, mo: true));
        g.Add(st, 1, 0);
        var the = AdminUi.The(12); the.Content = g;
        the.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => await Shell.Current.GoToAsync(route)) });
        return the;
    }

    protected override Task DungAsync()
    {
        var tra = AdminUi.Nut("🔎 Tra cứu khách hàng (hồ sơ · lịch sử đơn · khiếu nại · trạng thái tài khoản · ghi chú)", AdminUi.Tim, day: true);
        tra.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(AdminCustomerSearchPage));
        Nd.Add(KhoiTheo("Thông tin khách hàng", tra,
            AdminUi.Nhan("Trong kết quả tra cứu: 📦 Lịch sử đơn · 📝 Ghi chú nội bộ · 🔒 Khóa / 🔓 Mở khóa. Lịch sử hỗ trợ xem ở Khiếu nại của khách.", 11.5, mo: true)));

        Nd.Add(AdminUi.Nhan("Yêu cầu hỗ trợ theo nhóm", 14, dam: true));
        Nd.Add(Muc("📦", "Đơn hàng", "Tra cứu, kiểm tra và xử lý đơn", nameof(AdminOrdersPage)));
        Nd.Add(Muc("💳", "Thanh toán", "Tra cứu giao dịch, kiểm tra thanh toán", nameof(AdminPaymentsPage)));
        Nd.Add(Muc("🚚", "Giao hàng", "Xử lý giao chậm, giao thất bại (sự cố tài xế / điều phối)", nameof(AdminDriverIssuesPage)));
        Nd.Add(Muc("🍽", "Nhà hàng", "Xử lý thiếu món, sai món (khiếu nại của khách)", nameof(AdminKhieuNaiPage)));
        Nd.Add(Muc("🛵", "Tài xế", "Xử lý phản ánh về tài xế", nameof(AdminKhieuNaiPage)));
        Nd.Add(Muc("🎟", "Voucher", "Kiểm tra mã giảm giá", nameof(AdminPromotionsPage)));
        Nd.Add(Muc("🔑", "Tài khoản", "Hỗ trợ đăng nhập, xác minh, khóa / mở khóa", nameof(AdminAccountsPage)));
        Nd.Add(Muc("↩️", "Hoàn tiền", "Tiếp nhận và chuyển duyệt (trong Khiếu nại → chuyển hoàn tiền)", nameof(AdminKhieuNaiPage)));

        var cm = GhiChuKhachService.DocChiMuc();
        var ds = new VerticalStackLayout { Spacing = 4 };
        if (cm.Count == 0) ds.Add(AdminUi.Nhan("Chưa có ghi chú nào trên thiết bị này.", 12.5, mo: true));
        foreach (var kv in cm.Take(15))
        {
            if (!int.TryParse(kv.Key, out var ma)) continue;
            var n = GhiChuKhachService.Doc(ma);
            if (n.Count == 0) continue;
            ds.Add(DongTrai($"{kv.Value} (#{ma})", $"{n.Count} ghi chú · {n[0].Luc:dd/MM}"));
            ds.Add(AdminUi.Nhan("   " + n[0].NoiDung, 11.5, mo: true));
        }
        Nd.Add(KhoiTheo("Ghi chú nội bộ gần đây (lưu trên thiết bị này)", ds));
        return Task.CompletedTask;
    }
}
