using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// v47f — Câu hỏi thường gặp cho khách. Lấy từ GET api/mobile/faq (do quản trị biên tập ở mục "Câu hỏi thường gặp");
/// chưa có câu nào hoặc không kết nối được máy chủ thì dùng bộ câu mặc định (giống trang hỗ trợ trên web).
/// </summary>
public sealed class FaqPage : ContentPage
{
    private sealed class FaqDto { public string CauHoi { get; set; } = ""; public string TraLoi { get; set; } = ""; }

    private static readonly (string Q, string A)[] MacDinh =
    {
        ("Làm sao để đặt món?", "Chọn quán → chọn món (size/topping, ghi chú) → vào giỏ hàng → chọn địa chỉ, phương thức thanh toán, mã khuyến mãi → Đặt hàng."),
        ("Tôi có thể đặt món từ nhiều quán trong một đơn không?", "Chưa. Mỗi đơn chỉ gồm món của một gian hàng; ứng dụng sẽ báo nếu giỏ đang có món của quán khác."),
        ("Khi nào được hủy đơn?", "Bạn tự hủy được khi đơn còn ở trạng thái Chờ xác nhận. Sau khi quán xác nhận, vui lòng liên hệ quán hoặc hỗ trợ."),
        ("Phí giao hàng tính thế nào?", "Theo khoảng cách từ quán đến địa chỉ giao. Phí hiển thị trước khi bạn xác nhận đặt hàng."),
        ("Thanh toán online thất bại thì sao?", "Đơn giữ ở trạng thái chờ thanh toán; bạn có thể chọn lại hình thức khác hoặc liên hệ hỗ trợ kèm mã đơn."),
        ("Khi nào được hoàn tiền?", "Đơn đã thanh toán online mà bị hủy sẽ chuyển sang trạng thái Đã hoàn tiền; xem lại trong chi tiết đơn."),
    };

    private readonly VerticalStackLayout _ds = new() { Spacing = 8, Padding = new Thickness(16, 12, 16, 28) };
    private readonly Label _tt = new() { FontSize = 12, TextColor = Colors.Gray };

    public FaqPage()
    {
        Title = "Câu hỏi thường gặp";
        this.SetAppThemeColor(BackgroundColorProperty, Color.FromArgb("#FAF8FF"), Color.FromArgb("#1C1633"));
        _ds.Add(_tt);
        Content = new ScrollView { Content = _ds };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        var ds = MacDinh.ToList();
        _tt.Text = "";
        try
        {
            var r = await ApiClient.GetAsync<List<FaqDto>>("api/mobile/faq");
            if (r.ThanhCong && r.DuLieu is { Count: > 0 } l) ds = l.Select(x => (x.CauHoi, x.TraLoi)).ToList();
            else if (!r.ThanhCong) _tt.Text = "Đang hiển thị bộ câu mặc định (chưa kết nối được máy chủ).";
        }
        catch (Exception ex) { CrashLog.Ghi("FaqPage", ex); }

        while (_ds.Children.Count > 1) _ds.Children.RemoveAt(1);
        foreach (var (q, a) in ds) _ds.Add(Dung(q, a));
    }

    private static View Dung(string q, string a)
    {
        var dap = new Label { Text = a, FontSize = 13, IsVisible = false, Margin = new Thickness(0, 6, 0, 0) };
        dap.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#4B4563"), Color.FromArgb("#CFC7E6"));
        var mui = new Label { Text = "＋", FontSize = 18, TextColor = Color.FromArgb("#6D28D9"), VerticalOptions = LayoutOptions.Start };
        var cau = new Label { Text = q, FontSize = 14, FontAttributes = FontAttributes.Bold };
        cau.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#1F1537"), Color.FromArgb("#F8F5FF"));
        var dau = new Grid { ColumnSpacing = 8, ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        dau.Add(cau, 0, 0);
        dau.Add(mui, 1, 0);
        var st = new VerticalStackLayout { Spacing = 0 };
        st.Add(dau);
        st.Add(dap);
        var the = new Border { Padding = 14, StrokeThickness = 1, Content = st, StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(14) } };
        the.SetAppThemeColor(Border.BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
        the.SetAppThemeColor(Border.StrokeProperty, Color.FromArgb("#E4DAF7"), Color.FromArgb("#4D4180"));
        var tap = new TapGestureRecognizer();
        tap.Tapped += (_, _) => { dap.IsVisible = !dap.IsVisible; mui.Text = dap.IsVisible ? "－" : "＋"; };
        the.GestureRecognizers.Add(tap);
        return the;
    }
}
