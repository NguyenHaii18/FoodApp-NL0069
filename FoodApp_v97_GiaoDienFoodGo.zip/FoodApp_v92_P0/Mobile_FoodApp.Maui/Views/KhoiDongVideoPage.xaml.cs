using CommunityToolkit.Maui.Core.Primitives;

namespace FoodApp.Maui.Views;

/// <summary>
/// Video intro hiện ĐẦU TIÊN mỗi lần mở app. Kết thúc video, bấm "Bỏ qua", lỗi phát video hoặc quá 12 giây
/// đều tự chuyển sang trang đăng nhập — video không bao giờ chặn người dùng.
/// </summary>
public partial class KhoiDongVideoPage : ContentPage
{
    private bool _daChuyen;

    // Windows không đóng gói (WinUI unpackaged): MediaElement của CommunityToolkit lỗi "No such interface supported"
    // (DisplayRequest) làm app sập khi khởi động -> trên Windows bỏ qua video, chuyển thẳng sang đăng nhập.
    private readonly bool _coVideo = DeviceInfo.Platform != DevicePlatform.WinUI;

    public KhoiDongVideoPage()
    {
        InitializeComponent();
        if (_coVideo)
            Video.Source = CommunityToolkit.Maui.Views.MediaSource.FromResource("intro.mp4");
        else if (Content is Grid g)
            g.Children.Remove(Video);   // không tạo handler MediaElement trên Windows
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await Task.Delay(TimeSpan.FromSeconds(_coVideo ? 12 : 1));      // chốt chặn
        await VaoAppAsync();
    }

    private async void Video_MediaEnded(object? sender, EventArgs e) => await VaoAppAsync();

    private async void Video_MediaFailed(object? sender, MediaFailedEventArgs e) => await VaoAppAsync();

    private async void BoQua_Clicked(object? sender, EventArgs e) => await VaoAppAsync();

    private async Task VaoAppAsync()
    {
        if (_daChuyen) return;
        _daChuyen = true;
        try { Video.Stop(); } catch { /* bỏ qua */ }
        await MainThread.InvokeOnMainThreadAsync(async () => await Shell.Current.GoToAsync("//dang-nhap"));
    }

    protected override bool OnBackButtonPressed() => true;
}
