namespace FoodApp.Maui.Views;

/// <summary>
/// Checklist chức năng theo đối tượng (53 chức năng / 6 nhóm): % hoàn thành, tiến độ từng nhóm, chạm một dòng để đánh dấu đã kiểm tra.
/// Trạng thái chỉ LƯU TRÊN THIẾT BỊ NÀY (Preferences), không đồng bộ lên máy chủ.
/// </summary>
public sealed class AdminChecklistChucNangPage : AdminKyThuatTrang
{
    private static readonly (string Nhom, string[] Muc)[] Nhoms =
    {
        ("Khách hàng", new[] { "Tài khoản và hồ sơ", "Địa chỉ giao hàng", "Tìm kiếm nhà hàng", "Danh mục và thực đơn", "Giỏ hàng", "Đặt hàng", "Thanh toán", "Theo dõi đơn hàng", "Đánh giá và voucher", "Hỗ trợ khách hàng" }),
        ("Nhà hàng", new[] { "Hồ sơ và xét duyệt", "Chi nhánh và giờ hoạt động", "Danh mục và món ăn", "Quản lý giá và tồn kho", "Tiếp nhận và xử lý đơn", "Quản lý bếp", "Nhân viên và phân quyền", "Doanh thu và đối soát", "Khuyến mãi" }),
        ("Tài xế", new[] { "Đăng ký và xét duyệt", "Hồ sơ và phương tiện", "Online / Offline", "GPS và kết nối mạng", "Nhận và từ chối đơn", "Chỉ đường và lấy món", "Giao hàng và OTP", "Xử lý sự cố", "Thu nhập và thưởng" }),
        ("Điều phối", new[] { "Bản đồ tài xế", "Danh sách đơn cần phân", "Tự động tìm tài xế", "Phân công thủ công", "Đổi tài xế", "Xử lý đơn trễ và thất bại", "Báo cáo hiệu suất" }),
        ("CSKH và Kế toán", new[] { "Tra cứu khách và đơn", "Chat và phiếu hỗ trợ", "Quản lý khiếu nại", "Yêu cầu hoàn tiền", "Quản lý giao dịch", "Tính hoa hồng", "Đối soát tài xế và nhà hàng", "Báo cáo tài chính" }),
        ("Admin và Backend", new[] { "Dashboard tổng quan", "Quản lý tài khoản và quyền", "Quản lý nhà hàng", "Quản lý tài xế", "Quản lý đơn hàng", "Cấu hình phí và khuyến mãi", "Thông báo tự động", "API và database", "Nhật ký và bảo mật", "Backup và monitoring" }),
    };

    private static int Tong => Nhoms.Sum(n => n.Muc.Length);

    public AdminChecklistChucNangPage() : base("Checklist chức năng") { }

    private static string Khoa(int g, int i) => $"chucnang-{g}-{i}";
    private static bool Dat(int g, int i) { try { return Preferences.Default.Get(Khoa(g, i), false); } catch { return false; } }
    private static void Dat(int g, int i, bool v) { try { Preferences.Default.Set(Khoa(g, i), v); } catch { } }

    protected override Task DungAsync()
    {
        var soDat = 0;
        for (var g = 0; g < Nhoms.Length; g++) for (var i = 0; i < Nhoms[g].Muc.Length; i++) if (Dat(g, i)) soDat++;
        var tong = Tong;
        var phanTram = (int)Math.Round(100.0 * soDat / tong);
        var mau = Color.FromArgb(soDat == tong ? AdminUi.Xanh : AdminUi.Tim);

        var dau = new VerticalStackLayout { Spacing = 4 };
        dau.Add(AdminUi.Nhan("Checklist chức năng theo đối tượng", 14, dam: true));
        var pt = AdminUi.Nhan($"{phanTram}%", 28, dam: true); pt.TextColor = mau; dau.Add(pt);
        dau.Add(AdminUi.Nhan("Tỷ lệ chức năng đã kiểm tra hoàn thành", 12, mo: true));
        dau.Add(new ProgressBar { Progress = (double)soDat / tong, ProgressColor = mau });
        dau.Add(AdminUi.Nhan($"{soDat}/{tong}", 14, dam: true));
        Nd.Add(KhoiTheo("", dau));

        for (var k = 0; k < Nhoms.Length; k++)
        {
            var g = k;
            var (nhom, muc) = Nhoms[g];
            var datNhom = Enumerable.Range(0, muc.Length).Count(i => Dat(g, i));
            var ds = new VerticalStackLayout { Spacing = 2 };
            var tieuDe = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            tieuDe.Add(AdminUi.Nhan(nhom, 15, dam: true), 0, 0);
            tieuDe.Add(AdminUi.Nhan($"{datNhom}/{muc.Length} chức năng", 12, mo: true), 1, 0);
            ds.Add(tieuDe);
            ds.Add(new ProgressBar { Progress = (double)datNhom / muc.Length, ProgressColor = Color.FromArgb(datNhom == muc.Length ? AdminUi.Xanh : AdminUi.Tim) });
            for (var j = 0; j < muc.Length; j++)
            {
                var i = j;
                var xong = Dat(g, i);
                var dong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 10, Padding = new Thickness(0, 8) };
                dong.Add(new Label { Text = xong ? "✅" : "⚪", FontSize = 18, VerticalOptions = LayoutOptions.Center }, 0, 0);
                var chu = AdminUi.Nhan(muc[i], 13.5, mo: xong);
                chu.VerticalOptions = LayoutOptions.Center;
                if (xong) chu.TextDecorations = TextDecorations.Strikethrough;
                dong.Add(chu, 1, 0);
                var tap = new TapGestureRecognizer();
                tap.Tapped += async (_, _) => { Dat(g, i, !Dat(g, i)); Nd.Children.Clear(); await DungAsync(); };
                dong.GestureRecognizers.Add(tap);
                ds.Add(dong);
            }
            Nd.Add(KhoiTheo("", ds));
        }

        var datLai = AdminUi.Nut("Đặt lại checklist", AdminUi.Xam);
        datLai.Clicked += async (_, _) =>
        {
            if (!await DisplayAlert("Đặt lại checklist?", $"Bỏ đánh dấu toàn bộ {Tong} chức năng trên thiết bị này.", "Đặt lại", "Hủy")) return;
            for (var g = 0; g < Nhoms.Length; g++) for (var i = 0; i < Nhoms[g].Muc.Length; i++) Dat(g, i, false);
            Nd.Children.Clear();
            await DungAsync();
        };
        Nd.Add(KhoiTheo("", datLai));
        return Task.CompletedTask;
    }
}
