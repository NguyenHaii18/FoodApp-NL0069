using FoodApp.Maui.Models;

namespace FoodApp.Maui.Views;

/// <summary>Dòng hiển thị một gian hàng trong màn quản trị.</summary>
public class GianHangQuanTriVm
{
    public GianHang Gh { get; init; } = null!;
    public string Ten => Gh.TenGianHang;
    public ImageSource? Anh => Gh.CoAnh ? ImageSource.FromFile(Gh.AnhHienThi)
        : !string.IsNullOrEmpty(Gh.AnhBiaUrlDayDu) ? ImageSource.FromUri(new Uri(Gh.AnhBiaUrlDayDu)) : null;
    public bool CoAnh => Anh is not null;
    public bool CoEmoji => !CoAnh;
    public string Emoji => string.IsNullOrWhiteSpace(Gh.HinhAnh) ? "🍽️" : Gh.HinhAnh;
    public string SaoText
    {
        get
        {
            var (sao, so) = Services.TimKiemService.DiemQuan(Gh);
            if (so > 0) return $"⭐ {sao:0.0} ({so})";
            return Gh.DanhGia > 0 ? $"⭐ {Gh.DanhGia:0.0}" : "⭐ Mới";
        }
    }
    public string PhuText => string.IsNullOrWhiteSpace(Gh.DiaChi) ? $"Tham gia {Gh.NgayDangKy:dd/MM/yyyy}" : Gh.DiaChi;
    public string DoanhThuText => AdminUi.Tien(MockData.DoanhThuUocTinh(Gh.Id));
    public string TrangThaiText => Gh.TaiKhoanBiKhoa ? "Đã khóa" : Gh.DangMoCua ? "Hoạt động" : "Tạm đóng";
    public Color MauTT => Color.FromArgb(Gh.TaiKhoanBiKhoa ? "#DC2626" : Gh.DangMoCua ? "#15803D" : "#B45309");
    public Color NenTT => Color.FromArgb(Gh.TaiKhoanBiKhoa ? "#FEE2E2" : Gh.DangMoCua ? "#DCFCE7" : "#FEF3C7");
    public string NutText => Gh.TaiKhoanBiKhoa ? "🔓 Mở khóa" : "🔒 Khóa";
    public Color MauNut => Color.FromArgb(Gh.TaiKhoanBiKhoa ? "#16A34A" : "#DC2626");
}

public partial class AdminVendorListPage : ContentPage
{
    private readonly Entry _o;
    private string _tuKhoa = "";

    public AdminVendorListPage()
    {
        InitializeComponent();
        var (khung, o) = AdminUi.OTimKiem("Tìm gian hàng…");
        _o = o;
        KhungTim.StrokeThickness = 0;
        KhungTim.BackgroundColor = Colors.Transparent;
        KhungTim.Content = khung;
        var tre = new Services.TreTimKiem();
        _o.TextChanged += (_, e) => { _tuKhoa = e.NewTextValue ?? ""; tre.Chay(NapDanhSach); };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (!await Services.PhanQuyenService.KiemTraAsync(this, Services.Quyen.XemTaiKhoan)) { await Shell.Current.GoToAsync(".."); return; }
        NapDanhSach();
    }

    private void NapDanhSach()
    {
        // TODO: thay bằng GET /api/quan-tri/gian-hang khi có API thật.
        var danhSach = MockData.DanhSachGianHang
            .Where(g => g.TrangThaiDangKy == TrangThaiDangKyGianHang.DaDuyet)
            .OrderByDescending(g => g.NgayDangKy)
            .ToList();

        var k = Services.TimKiemService.BoDau(_tuKhoa);
        if (k.Length > 0)
            danhSach = danhSach.Where(g => Services.TimKiemService.BoDau(g.TenGianHang + " " + g.DiaChi + " " + g.Email).Contains(k)).ToList();

        DsGianHang.ItemsSource = danhSach.Select(g => new GianHangQuanTriVm { Gh = g }).ToList();
    }

    private async void OnKhoaMoClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: GianHang gh }) return;
        if (!await Services.PhanQuyenService.KiemTraAsync(this, Services.Quyen.KhoaMoTaiKhoan)) return;

        if (gh.TaiKhoanBiKhoa)
        {
            gh.TaiKhoanBiKhoa = false;
            Services.VendorLocalStore.Luu();
            if (!await Services.DuLieuService.GhiHoanTacAsync("PUT", $"api/mobile/admin/gian-hang/{gh.Id}/mo-khoa", null,
                    () => { gh.TaiKhoanBiKhoa = true; Services.VendorLocalStore.Luu(); }))
            { NapDanhSach(); return; }
            Services.NhatKyService.GhiQuanTri("Mở khóa gian hàng", gh.TenGianHang, gh.Email);
            NapDanhSach();
            await DisplayAlert("Đã mở khóa", Services.DuLieuService.ChuThichGhi($"Tài khoản gian hàng \"{gh.TenGianHang}\" đã được kích hoạt lại."), "OK");
            return;
        }

        bool xacNhan = await DisplayAlert(
            "Khóa tài khoản gian hàng",
            $"Khóa tài khoản \"{gh.TenGianHang}\"? Gian hàng sẽ không thể đăng nhập hoặc nhận đơn mới cho đến khi được mở lại.",
            "Khóa", "Hủy");
        if (!xacNhan) return;

        gh.TaiKhoanBiKhoa = true;
        Services.VendorLocalStore.Luu();
        if (!await Services.DuLieuService.GhiHoanTacAsync("PUT", $"api/mobile/admin/gian-hang/{gh.Id}/khoa", null,
                () => { gh.TaiKhoanBiKhoa = false; Services.VendorLocalStore.Luu(); }))
        { NapDanhSach(); return; }
        Services.NhatKyService.GhiQuanTri("Khóa gian hàng", gh.TenGianHang, gh.Email);

        NapDanhSach();
        if (Services.DuLieuService.LanGhiCuoi == Services.DuLieuService.KetQuaGhi.LuuTrenMay)
            await DisplayAlert("Đã khóa (chỉ trên máy)", Services.DuLieuService.CanhBaoNgoaiTuyen, "OK");
    }

    private void OnRefreshing(object? sender, EventArgs e)
    {
        NapDanhSach();
        RefreshDsGianHang.IsRefreshing = false;
    }
}
