namespace FoodApp.Maui.Views;

/// <summary>Màu của khu Tài xế (xanh ngọc) dùng trong code C#; khớp Resources/Styles/DriverTheme.xaml.</summary>
public static class DriverPalette
{
    public static Color Get(string key) => key switch
    {
        "Primary" => Color.FromArgb("#6D28D9"),
        "PrimaryDark" => Color.FromArgb("#5B21B6"),
        "PrimaryLight" => Color.FromArgb("#A78BFA"),
        "PrimarySoft" => Color.FromArgb("#F3EEFF"),
        "Accent" => Color.FromArgb("#8B5CF6"),
        "Background" => Color.FromArgb("#FAF8FF"),
        "CardColor" => Colors.White,
        "TextDark" => Color.FromArgb("#1F1537"),
        "TextGrey" => Color.FromArgb("#6B6480"),
        "Danger" => Color.FromArgb("#DC2626"),
        "Success" => Color.FromArgb("#16A34A"),
        "Warning" => Color.FromArgb("#E99A22"),
        "Gold" => Color.FromArgb("#F5A524"),
        "GoldSoft" => Color.FromArgb("#FFF3D6"),
        "BorderColor" => Color.FromArgb("#E4DAF7"),
        _ => (Color)Application.Current!.Resources[key],
    };
}
