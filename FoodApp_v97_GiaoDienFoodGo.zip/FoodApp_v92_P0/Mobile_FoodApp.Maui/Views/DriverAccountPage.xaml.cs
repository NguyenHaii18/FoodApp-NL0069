using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Tab "Tài khoản" của tài xế: hồ sơ tóm tắt + thông tin cá nhân, giấy tờ &amp; xe, ví, đánh giá, lịch sử, hỗ trợ, cài đặt, đăng xuất.</summary>
public partial class DriverAccountPage : ContentPage
{
    public DriverAccountPage() => InitializeComponent();

    protected override void OnAppearing()
    {
        base.OnAppearing();
        ThuNhapService.CapNhatChiSo();
        var t = MockData.TaiXeHienTai;
        ImgAnh.Source = t.CoAnh ? ImageSource.FromFile(t.AnhPath) : null;
        ImgAnh.IsVisible = t.CoAnh;
        LblAnh.Text = t.Anh;
        LblAnh.IsVisible = !t.CoAnh;
        LblTen.Text = string.IsNullOrWhiteSpace(t.HoTen) ? "Tài xế" : t.HoTen;
        LblSdt.Text = string.IsNullOrWhiteSpace(t.SoDienThoai) ? "Chưa có số điện thoại" : t.SoDienThoai;
        LblXacThuc.Text = t.TaiKhoanBiKhoa ? "Đang bị khóa" : t.DaDuyet ? "✔ Tài xế chính thức" : t.TrangThaiNhan;
        LblDiem.Text = t.DanhGia > 0 ? $"★ {t.DanhGia:0.0}" : "★ Mới";
        VeMuc();
    }

    private void VeMuc()
    {
        DsMuc.Children.Clear();
        var muc = new (string Icon, string Nhan, Func<Task> Mo)[]
        {
            ("👤", "Thông tin cá nhân", () => Shell.Current.GoToAsync(nameof(DriverProfilePage))),
            ("🪪", "Giấy tờ & xe", () => Shell.Current.GoToAsync(nameof(DriverProfilePage))),
            ("👛", "Ví tài khoản", () => Shell.Current.GoToAsync(nameof(DriverWalletPage))),
            ("📊", "Hiệu suất của tôi", () => Shell.Current.GoToAsync(nameof(DriverPerformancePage))),
            ("🎁", "Chương trình thưởng", () => Shell.Current.GoToAsync(nameof(DriverThuongPage))),
            ("📈", "Tỷ lệ & vi phạm", () => Shell.Current.GoToAsync(nameof(DriverThuongTyLePage))),
            ("🆘", "Trung tâm hỗ trợ", () => Shell.Current.GoToAsync(nameof(DriverHoTroPage))),
            ("📍", "Khu vực có nhu cầu giao hàng", () => Shell.Current.GoToAsync(nameof(DriverNhuCauPage))),
            ("💬", "Gửi phản hồi / khiếu nại", () => Shell.Current.GoToAsync($"{nameof(DriverSuCoPage)}?loai=Khac")),
            ("⭐", "Đánh giá của khách", () => Shell.Current.GoToAsync(nameof(DriverRatingPage))),
            ("🕘", "Lịch sử hoạt động", () => Shell.Current.GoToAsync(nameof(DriverMyOrdersPage))),
            ("🔔", "Thông báo", () => Shell.Current.GoToAsync(nameof(DriverNotificationsPage))),
            ("🚨", "Báo sự cố & hỗ trợ", () => Shell.Current.GoToAsync(nameof(DriverSuCoPage))),
            ("📖", "Hướng dẫn & quy định giao hàng", () => Shell.Current.GoToAsync(nameof(DriverHuongDanPage))),
            ("⚙️", "Cài đặt", () => Shell.Current.GoToAsync(nameof(DriverSettingsPage))),
        };
        for (int i = 0; i < muc.Length; i++)
        {
            var (icon, nhan, mo) = muc[i];
            var o = new Grid { Padding = new Thickness(14, 13), ColumnSpacing = 12, BackgroundColor = Colors.Transparent };
            o.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));
            o.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
            o.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));
            o.Add(new Label { Text = icon, FontSize = 19, WidthRequest = 26, TextColor = Colors.Black, VerticalOptions = LayoutOptions.Center }, 0);
            o.Add(new Label { Text = nhan, FontSize = 14.5, VerticalOptions = LayoutOptions.Center }, 1);
            o.Add(new Label { Text = "›", FontSize = 20, TextColor = DriverPalette.Get("TextGrey"), VerticalOptions = LayoutOptions.Center }, 2);
            o.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => await mo()) });
            DsMuc.Children.Add(o);
            if (i < muc.Length - 1)
                DsMuc.Children.Add(new BoxView { HeightRequest = 1, Margin = new Thickness(52, 0, 10, 0), Color = DriverPalette.Get("BorderColor") });
        }
    }

    private async void OnThongTinTapped(object? sender, TappedEventArgs e) => await Shell.Current.GoToAsync(nameof(DriverProfilePage));

    private async void OnDangXuatClicked(object? sender, EventArgs e)
    {
        try
        {
            if (!await DisplayAlert("Đăng xuất", "Bạn có chắc muốn đăng xuất?", "Đăng xuất", "Hủy")) return;
            ViTriTaiXeService.Dung();
            var tx = MockData.TaiXeHienTai;
            tx.DangOnline = false;
            TaiXeStore.Luu();
            NhatKyService.Ghi("TaiXe", tx.SoDienThoai, "Đăng xuất", chiTiet: NhatKyService.ThietBi());
            if (DuLieuService.DangOnline)
                await ApiClient.PutAsync<object>("api/mobile/tai-xe/trang-thai", new { trangThai = "NgoaiTuyen" });
            ApiClient.Token = null;
            await Shell.Current.GoToAsync("//dang-nhap");
        }
        catch (Exception ex) { await Services.DangXuatHelper.LoiAsync(ex); }
    }
}
