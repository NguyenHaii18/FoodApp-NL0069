namespace FoodApp.Maui.Views;

/// <summary>
/// v88 — Checklist nghiệm thu (18 mục): tiến độ X/18 + thanh tiến độ, chạm một dòng để đánh dấu đã đạt, nút "Đặt lại checklist".
/// Trạng thái chỉ LƯU TRÊN THIẾT BỊ NÀY (Preferences), không đồng bộ lên máy chủ — mỗi quản trị tự đánh dấu khi nghiệm thu.
/// </summary>
public sealed class AdminNghiemThuPage : AdminKyThuatTrang
{
    private static readonly string[] Muc =
    {
        "Khách hàng đăng ký, đăng nhập và quản lý hồ sơ được",
        "Khách hàng tìm nhà hàng và xem thực đơn được",
        "Khách hàng đặt món và thanh toán được",
        "Nhà hàng nhận và xử lý đơn theo đúng quy trình",
        "Tài xế đăng ký và được quản trị viên xét duyệt",
        "Tài xế bật nhận đơn và nhận đơn được",
        "Backend phân đơn và chống trùng tài xế",
        "Khách hàng theo dõi được trạng thái và vị trí giao hàng",
        "Đơn hàng có đầy đủ lịch sử trạng thái",
        "Có quy trình hủy đơn và hoàn tiền",
        "Quản trị viên quản lý được khách hàng, nhà hàng và tài xế",
        "Có phân quyền theo vai trò",
        "Có báo cáo doanh thu và đối soát",
        "Có nhật ký quản trị và sao lưu dữ liệu",
        "Đã kiểm thử API, bảo mật và khả năng chịu tải",
        "Đã triển khai staging và production",
        "Có tài liệu cài đặt và hướng dẫn sử dụng",
        "Có quy trình hỗ trợ khách hàng và xử lý sự cố",
    };

    public AdminNghiemThuPage() : base("Checklist nghiệm thu") { }

    private static bool Dat(int i)
    {
        try { return Preferences.Default.Get($"nghiemthu-{i}", false); } catch { return false; }
    }

    private static void Dat(int i, bool v) { try { Preferences.Default.Set($"nghiemthu-{i}", v); } catch { } }

    protected override Task DungAsync()
    {
        var soDat = Enumerable.Range(0, Muc.Length).Count(Dat);

        var dau = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        dau.Add(AdminUi.Nhan("Tiến độ checklist nghiệm thu", 14, dam: true), 0, 0);
        var so = AdminUi.Nhan($"{soDat}/{Muc.Length}", 16, dam: true);
        so.TextColor = Color.FromArgb(soDat == Muc.Length ? AdminUi.Xanh : AdminUi.Tim);
        dau.Add(so, 1, 0);

        var thanh = new ProgressBar { Progress = (double)soDat / Muc.Length, ProgressColor = Color.FromArgb(soDat == Muc.Length ? AdminUi.Xanh : AdminUi.Tim) };

        var ds = new VerticalStackLayout { Spacing = 6 };
        for (var k = 0; k < Muc.Length; k++)
        {
            var i = k;
            var xong = Dat(i);
            var dong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 10, Padding = new Thickness(0, 6) };
            dong.Add(new Label { Text = xong ? "✅" : "⚪", FontSize = 18, VerticalOptions = LayoutOptions.Center }, 0, 0);
            var chu = AdminUi.Nhan(Muc[i], 13.5, mo: xong);
            chu.VerticalOptions = LayoutOptions.Center;
            if (xong) chu.TextDecorations = TextDecorations.Strikethrough;
            dong.Add(chu, 1, 0);
            var tap = new TapGestureRecognizer();
            tap.Tapped += async (_, _) =>
            {
                Dat(i, !Dat(i));
                Nd.Children.Clear();
                await DungAsync();
            };
            dong.GestureRecognizers.Add(tap);
            ds.Add(dong);
        }

        var datLai = AdminUi.Nut("Đặt lại checklist", AdminUi.Xam);
        datLai.Clicked += async (_, _) =>
        {
            if (!await DisplayAlert("Đặt lại checklist?", "Bỏ đánh dấu toàn bộ 18 mục trên thiết bị này.", "Đặt lại", "Hủy")) return;
            for (var i = 0; i < Muc.Length; i++) Dat(i, false);
            Nd.Children.Clear();
            await DungAsync();
        };

        Nd.Add(KhoiTheo("", dau, thanh, ds, AdminUi.Nhan(soDat == Muc.Length ? "🎉 Đã đạt đủ checklist — sẵn sàng nghiệm thu." : "Chạm vào từng dòng để đánh dấu mục đã đạt. Trạng thái lưu trên thiết bị này.", 11.5, mo: true), datLai));
        return Task.CompletedTask;
    }
}
