using System.Globalization;
using System.Text.Json;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

// Các trang quản trị bổ sung (v38). Mỗi trang chỉ khai báo cấu hình cho AdminListPage; dữ liệu và quyền do máy chủ quyết định
// (api/mobile/admin/*), nên Nhân viên hỗ trợ chỉ xem, Quản lý thao tác theo quyền chi tiết, Admin tổng toàn quyền.

// =====================================================================================================================
// ĐƠN HÀNG — xem, lọc, điều tra
// =====================================================================================================================
public sealed class AdminOrdersPage : AdminListPage
{
    public AdminOrdersPage() : base(Cfg()) { }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Quản lý đơn hàng",
        Tab = new[] { "Tất cả", "Đang xử lý", "Đang giao", "Đã giao" },
        NavMuc = "quanly",
        GoiYTimKiem = "Tìm kiếm đơn hàng…",
        // Bộ lọc chi tiết (đơn trễ, giao thất bại, khiếu nại…) chỉ ở tab "Tất cả"; ba tab còn lại lọc theo trạng thái
        Loc = tab => tab != 0 ? Array.Empty<(string Nhan, string GiaTri)>() : new (string Nhan, string GiaTri)[]
        {
            ("Tất cả", ""), ("Chờ xác nhận", "trangThai=ChoXacNhan"), ("Đã xác nhận", "trangThai=DaXacNhan"),
            ("Đang giao", "trangThai=DangGiao"), ("Đã giao", "trangThai=DaGiao"), ("Đã hủy", "trangThai=DaHuy"),
            ("⏰ Đơn trễ", "bo=tre"), ("Giao thất bại", "bo=that-bai"), ("Có khiếu nại", "bo=khieu-nai"),
        },
        LocTheoTab = (tab, d) => tab switch
        {
            1 => J.S(d, "trangThai") is "ChoXacNhan" or "DaXacNhan",
            2 => J.S(d, "trangThai") == "DangGiao",
            3 => J.S(d, "trangThai") == "DaGiao",
            _ => true,
        },
        Url = (_, q, loc) => $"api/mobile/admin/don-hang/tim?q={AdminUi.Q(q)}" + (loc == "" ? "" : "&" + loc),
        Dong = (_, d) =>
        {
            var tt = AdminUi.TrangThai(J.S(d, "trangThai"));
            var khach = J.S(d, "khach");
            var dong = new List<string> { string.IsNullOrWhiteSpace(khach) ? "Khách hàng" : khach };
            var phu = new List<string>();
            if (!J.Rong(d, "gianHang")) phu.Add($"🏬 {J.S(d, "gianHang")}");
            if (!J.Rong(d, "taiXe")) phu.Add($"🛵 {J.S(d, "taiXe")}");
            if (phu.Count > 0) dong.Add(string.Join("   ", phu));
            if (!J.Rong(d, "hinhThucTT")) dong.Add($"💳 {AdminUi.TrangThai(J.S(d, "hinhThucTT")).Nhan} · {AdminUi.TrangThai(J.S(d, "trangThaiTT")).Nhan}");
            if (J.B(d, "tre")) dong.Add("⏰ Đơn đang trễ so với thời gian dự kiến");
            return new AdminDong($"#{J.S(d, "maDonHang")}", dong.ToArray(), tt.Nhan, tt.Mau,
                Avatar: AdminUi.ChuCai(khach), PhaiTren: J.Ngay(d, "ngayDat", "HH:mm · dd/MM"), PhaiDuoi: AdminUi.Tien(J.D(d, "tongTien")));
        },
        Mo = (_, d) => Shell.Current.GoToAsync($"{nameof(AdminOrderDetailPage)}?Id={J.S(d, "maDonHang")}"),
    };
}

// =====================================================================================================================
// THANH TOÁN + HOÀN TIỀN
// =====================================================================================================================
public sealed class AdminPaymentsPage : AdminListPage
{
    public AdminPaymentsPage() : base(Cfg()) { }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Thanh toán & hoàn tiền",
        Tab = new[] { "Giao dịch", "Hoàn tiền" },
        GoiYTimKiem = "Mã đơn, mã giao dịch, tên khách…",
        Loc = tab => tab == 0
            ? new (string Nhan, string GiaTri)[]
            {
                ("Tất cả", ""), ("Chưa đối soát", "chuaDoiSoat=true"), ("VNPay", "hinhThuc=VNPay"), ("Chuyển khoản", "hinhThuc=ChuyenKhoan"),
                ("Tiền mặt (COD)", "hinhThuc=TienMat"), ("Chờ thanh toán", "trangThai=ChoThanhToan"), ("Đã hoàn tiền", "trangThai=DaHoanTien"),
            }
            : new (string Nhan, string GiaTri)[] { ("Tất cả", ""), ("Chờ duyệt", "trangThai=ChoDuyet"), ("Đã duyệt", "trangThai=DaDuyet"), ("Từ chối", "trangThai=TuChoi") },
        Url = (tab, q, loc) => tab == 0
            ? $"api/mobile/admin/thanh-toan?q={AdminUi.Q(q)}" + (loc == "" ? "" : "&" + loc)
            : "api/mobile/admin/hoan-tien" + (loc == "" ? "" : "?" + loc),
        LayDs = (_, root) => J.Mang(root, "ds"),
        TomTat = (tab, root) => tab == 0
            ? $"COD chưa đối soát: {J.L(J.Doi(root, "tomTat"), "codSo")} đơn · {AdminUi.Tien(J.D(J.Doi(root, "tomTat"), "codTien"))}" +
              (J.L(J.Doi(root, "tomTat"), "choThanhToanLau") > 0 ? $"\n⚠️ {J.L(J.Doi(root, "tomTat"), "choThanhToanLau")} giao dịch online chờ thanh toán quá 1 giờ" : "")
            : $"Quản lý duyệt hoàn tiền tới {AdminUi.Tien(J.D(root, "nguong"))}; vượt ngưỡng cần Admin tổng. Đơn tiền mặt không hoàn qua hệ thống.",
        Dong = (tab, d) =>
        {
            if (tab == 0)
            {
                var tt = AdminUi.TrangThai(J.S(d, "trangThai"));
                var dong = new List<string>
                {
                    $"👤 {J.S(d, "khach")} · {J.S(d, "gianHang")}",
                    $"💳 {AdminUi.TrangThai(J.S(d, "hinhThuc")).Nhan}   💰 {AdminUi.Tien(J.D(d, "tongTien"))}   🕒 {J.Ngay(d, "ngayDat")}",
                    $"Đơn: {AdminUi.TrangThai(J.S(d, "trangThaiDon")).Nhan}   ·   " + (J.B(d, "daDoiSoat") ? "✅ Đã đối soát" : "⏳ Chưa đối soát"),
                };
                if (!J.Rong(d, "maGiaoDich")) dong.Add($"Mã GD: {J.S(d, "maGiaoDich")}");
                if (!J.Rong(d, "maGiaoDichHoan")) dong.Add($"Mã GD hoàn: {J.S(d, "maGiaoDichHoan")}");
                return new AdminDong($"Đơn #{J.S(d, "maDonHang")}", dong.ToArray(), tt.Nhan, tt.Mau);
            }
            var ht = AdminUi.TrangThai(J.S(d, "trangThai"));
            var l = new List<string>
            {
                $"💰 Hoàn {AdminUi.Tien(J.D(d, "soTien"))} / tổng đơn {AdminUi.Tien(J.D(d, "tongDon"))}",
                $"👤 {J.S(d, "khach")} · {AdminUi.TrangThai(J.S(d, "hinhThucTT")).Nhan} ({AdminUi.TrangThai(J.S(d, "trangThaiTT")).Nhan})",
                $"Lý do: {J.S(d, "lyDo")}",
                $"Nguồn: {J.S(d, "nguon")} · tạo {J.Ngay(d, "ngayTao")}",
            };
            if (!J.Rong(d, "ketQua")) l.Add($"Kết quả: {J.S(d, "ketQua")}");
            return new AdminDong($"Yêu cầu #{J.S(d, "maYeuCau")} · đơn #{J.S(d, "maDonHang")}", l.ToArray(), ht.Nhan, ht.Mau);
        },
        HanhDong = tab => tab == 0
            ? new[]
            {
                new AdminHanhDong("Đối soát", AdminUi.Tim,
                    d => !J.B(d, "daDoiSoat") && (J.S(d, "trangThai") == "DaThanhToan" || (J.S(d, "hinhThuc") == "TienMat" && J.S(d, "trangThaiDon") == "DaGiao")),
                    async (p, d) => await AdminUi.Put(p, $"api/mobile/admin/thanh-toan/{J.S(d, "maThanhToan")}/doi-soat", null, "Đối soát giao dịch", $"Đơn #{J.S(d, "maDonHang")}")),
                new AdminHanhDong("Xác nhận đã nhận tiền", AdminUi.Xanh,
                    d => J.S(d, "hinhThuc") == "ChuyenKhoan" && J.S(d, "trangThai") != "DaThanhToan",
                    async (p, d) =>
                    {
                        var ma = await AdminUi.Hoi(p, "Xác nhận chuyển khoản", $"Nhập mã giao dịch ngân hàng của đơn #{J.S(d, "maDonHang")} (có thể bỏ trống).");
                        if (ma == null) return;
                        await AdminUi.Put(p, $"api/mobile/admin/thanh-toan/{J.S(d, "maThanhToan")}/xac-nhan-chuyen-khoan", new { maGiaoDich = ma }, "Xác nhận chuyển khoản", $"Đơn #{J.S(d, "maDonHang")}");
                    }),
            }
            : new[]
            {
                new AdminHanhDong("Duyệt hoàn tiền", AdminUi.Xanh, d => J.S(d, "trangThai") == "ChoDuyet", DuyetHoan),
                new AdminHanhDong("Từ chối", AdminUi.Do, d => J.S(d, "trangThai") == "ChoDuyet", async (p, d) =>
                {
                    var ly = await AdminUi.Hoi(p, "Từ chối hoàn tiền", "Nhập lý do từ chối (khách sẽ nhận được thông báo).", null, 5);
                    if (ly == null) return;
                    await AdminUi.Put(p, $"api/mobile/admin/hoan-tien/{J.S(d, "maYeuCau")}/tu-choi", new { ketQua = ly }, "Từ chối hoàn tiền", $"Đơn #{J.S(d, "maDonHang")}");
                }),
            },
        HanhDongChung = tab => tab == 0
            ? new[]
            {
                new AdminHanhDong("✔ Đối soát tất cả", AdminUi.Tim, null, async (p, _) =>
                {
                    if (!await p.DisplayAlert("Đối soát tất cả", "Đánh dấu đã đối soát cho mọi giao dịch đã thanh toán và COD đã giao chưa đối soát?", "Đối soát", "Hủy")) return;
                    await AdminUi.Put(p, "api/mobile/admin/thanh-toan/doi-soat-tat-ca", null, "Đối soát tất cả giao dịch");
                }),
            }
            : new[] { new AdminHanhDong("＋ Tạo yêu cầu hoàn tiền", AdminUi.Tim, null, TaoHoan) },
    };

    private static async Task DuyetHoan(AdminListPage p, JsonElement d)
    {
        var maDon = J.S(d, "maDonHang");
        if (!await p.DisplayAlert("Duyệt hoàn tiền", $"Hoàn {AdminUi.Tien(J.D(d, "soTien"))} cho đơn #{maDon}? Đơn VNPay sẽ hoàn qua cổng; cổng khác cần mã hoàn thủ công.", "Tiếp tục", "Hủy")) return;
        var vnpay = J.S(d, "hinhThucTT") == "VNPay";
        var ma = await AdminUi.Hoi(p, "Mã giao dịch hoàn",
            vnpay ? "Chỉ nhập nếu bạn đã hoàn thủ công trên cổng VNPay. Bỏ trống để hệ thống hoàn tự động." : "Nhập mã giao dịch hoàn (bắt buộc với cổng thanh toán này).",
            null, vnpay ? 0 : 3);
        if (ma == null) return;
        await AdminUi.Put(p, $"api/mobile/admin/hoan-tien/{J.S(d, "maYeuCau")}/duyet", new { ketQua = "", maHoanThuCong = ma == "" ? null : ma }, "Duyệt hoàn tiền", $"Đơn #{maDon}");
    }

    private static async Task TaoHoan(AdminListPage p, JsonElement _)
    {
        var ma = await AdminUi.Hoi(p, "Tạo yêu cầu hoàn tiền", "Mã đơn hàng (chỉ đơn đã thanh toán online).", "VD: 1024", 1, "", Keyboard.Numeric);
        if (ma == null || !int.TryParse(ma.TrimStart('#'), out var maDon)) { if (ma != null) await p.DisplayAlert("Chưa hợp lệ", "Mã đơn phải là số.", "Đóng"); return; }
        var tien = await AdminUi.Hoi(p, "Số tiền hoàn", "Bỏ trống để hoàn toàn bộ giá trị đơn.", null, 0, "", Keyboard.Numeric);
        if (tien == null) return;
        decimal? soTien = null;
        if (tien != "")
        {
            if (!decimal.TryParse(tien.Replace(".", "").Replace(",", ""), NumberStyles.None, CultureInfo.InvariantCulture, out var t) || t <= 0) { await p.DisplayAlert("Chưa hợp lệ", "Số tiền không đúng.", "Đóng"); return; }
            soTien = t;
        }
        var ly = await AdminUi.Hoi(p, "Lý do hoàn tiền", "Ghi rõ lý do (tối thiểu 5 ký tự).", null, 5);
        if (ly == null) return;
        await AdminUi.Post(p, "api/mobile/admin/hoan-tien", new { maDonHang = maDon, soTien, lyDo = ly }, "Tạo yêu cầu hoàn tiền", $"Đơn #{maDon}");
    }
}

// =====================================================================================================================
// DANH MỤC + MÓN ĂN (kiểm soát vi phạm)
// =====================================================================================================================
public sealed class AdminCatalogPage : AdminListPage
{
    public AdminCatalogPage() : base(Cfg()) { }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Danh mục & món ăn",
        Tab = new[] { "Danh mục", "Món ăn" },
        GoiYTimKiem = "Tên danh mục, món, gian hàng…",
        Loc = _ => new (string Nhan, string GiaTri)[] { ("Tất cả", ""), ("Đã ẩn / vi phạm", "daAn=true") },
        Url = (tab, q, loc) => $"api/mobile/admin/{(tab == 0 ? "danh-muc" : "mon-an")}?q={AdminUi.Q(q)}" + (loc == "" ? "" : "&" + loc),
        Dong = (tab, d) =>
        {
            if (tab == 0)
            {
                var an = J.B(d, "daAn");
                return new AdminDong(J.S(d, "tenDanhMuc"), new[] { $"🏬 {J.S(d, "tenGianHang")}", $"🍽 {J.L(d, "soMon")} món" }, an ? "Đã ẩn" : "Đang hiện", an ? AdminUi.Do : AdminUi.Xanh);
            }
            var tt = AdminUi.TrangThai(J.S(d, "tinhTrang"));
            var dong = new List<string> { $"🏬 {J.S(d, "tenGianHang")} · {J.S(d, "tenDanhMuc")}", $"💰 {AdminUi.Tien(J.D(d, "gia"))}" };
            if (!J.Rong(d, "moTa")) dong.Add(J.S(d, "moTa"));
            if (!J.Rong(d, "lyDoAn")) dong.Add($"🚫 Lý do ẩn: {J.S(d, "lyDoAn")}");
            return new AdminDong(J.S(d, "tenMon"), dong.ToArray(), tt.Nhan, tt.Mau);
        },
        HanhDong = tab => tab == 0
            ? new[]
            {
                new AdminHanhDong("Đổi tên", AdminUi.Tim, null, async (p, d) =>
                {
                    var ten = await AdminUi.Hoi(p, "Đổi tên danh mục", "Tên mới (2–100 ký tự).", null, 2, J.S(d, "tenDanhMuc"));
                    if (ten == null) return;
                    var ly = await AdminUi.Hoi(p, "Lý do đổi tên", "Bắt buộc, gian hàng sẽ nhận thông báo (tối thiểu 5 ký tự).", null, 5);
                    if (ly == null) return;
                    await AdminUi.Put(p, $"api/mobile/admin/danh-muc/{J.S(d, "maDanhMuc")}/doi-ten", new { tenMoi = ten, lyDo = ly }, "Đổi tên danh mục", ten);
                }),
                new AdminHanhDong("Ẩn", AdminUi.Cam, d => !J.B(d, "daAn"), async (p, d) =>
                {
                    var ly = await AdminUi.Hoi(p, "Ẩn danh mục", "Nhập lý do ẩn (gian hàng sẽ nhận thông báo).", null, 3);
                    if (ly == null) return;
                    await AdminUi.Put(p, $"api/mobile/admin/danh-muc/{J.S(d, "maDanhMuc")}/an", new { lyDo = ly }, "Ẩn danh mục", J.S(d, "tenDanhMuc"));
                }),
                new AdminHanhDong("Hiện lại", AdminUi.Xanh, d => J.B(d, "daAn"),
                    async (p, d) => await AdminUi.Put(p, $"api/mobile/admin/danh-muc/{J.S(d, "maDanhMuc")}/hien", null, "Hiện danh mục", J.S(d, "tenDanhMuc"))),
                new AdminHanhDong("Xóa", AdminUi.Do, d => J.L(d, "soMon") == 0, async (p, d) =>
                {
                    var ly = await AdminUi.Hoi(p, "Xóa danh mục", "Chỉ xóa được danh mục trống. Nhập lý do xóa.", null, 3);
                    if (ly == null) return;
                    await AdminUi.Xoa(p, $"api/mobile/admin/danh-muc/{J.S(d, "maDanhMuc")}?lyDo={AdminUi.Q(ly)}", "Xóa danh mục", J.S(d, "tenDanhMuc"));
                }),
            }
            : new[]
            {
                new AdminHanhDong("Ẩn món vi phạm", AdminUi.Do, d => J.Rong(d, "lyDoAn"), async (p, d) =>
                {
                    var ly = await AdminUi.Hoi(p, "Ẩn món", $"Lý do ẩn món \"{J.S(d, "tenMon")}\" (gian hàng sẽ nhận thông báo).", null, 3);
                    if (ly == null) return;
                    await AdminUi.Put(p, $"api/mobile/admin/mon-an/{J.S(d, "maMonAn")}/an", new { lyDo = ly }, "Ẩn món ăn", J.S(d, "tenMon"));
                }),
                new AdminHanhDong("Hiện lại", AdminUi.Xanh, d => !J.Rong(d, "lyDoAn"),
                    async (p, d) => await AdminUi.Put(p, $"api/mobile/admin/mon-an/{J.S(d, "maMonAn")}/hien", null, "Hiện món ăn", J.S(d, "tenMon"))),
            },
    };
}

// =====================================================================================================================
// ĐÁNH GIÁ — kiểm duyệt
// =====================================================================================================================
public sealed class AdminReviewsPage : AdminListPage
{
    public AdminReviewsPage() : base(Cfg()) { }

    private static string AnhDayDu(string p)
    {
        if (string.IsNullOrWhiteSpace(p)) return "";
        if (Uri.TryCreate(p, UriKind.Absolute, out var u) && (u.Scheme == "http" || u.Scheme == "https")) return p;
        return FoodApp.Maui.Services.AppSettings.BaseUrl.TrimEnd('/') + "/" + p.TrimStart('/');
    }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Kiểm duyệt đánh giá",
        Tab = new[] { "Bị báo cáo", "Tất cả" },
        Loc = tab => tab == 0
            ? Array.Empty<(string Nhan, string GiaTri)>()
            : new (string Nhan, string GiaTri)[] { ("Mọi số sao", ""), ("5 ⭐", "sao=5"), ("4 ⭐", "sao=4"), ("3 ⭐", "sao=3"), ("2 ⭐", "sao=2"), ("1 ⭐", "sao=1") },
        Url = (tab, _, loc) => $"api/mobile/admin/danh-gia?tab={(tab == 0 ? "bao-cao" : "tat-ca")}" + (loc == "" ? "" : "&" + loc),
        Dong = (tab, d) =>
        {
            var dong = new List<string> { $"🏬 {J.S(d, "tenGianHang")}" + (J.Rong(d, "tenKhach") ? "" : $" · 👤 {J.S(d, "tenKhach")}"), string.IsNullOrWhiteSpace(J.S(d, "noiDung")) ? "(không có nội dung)" : $"“{J.S(d, "noiDung")}”" };
            if (tab == 0) dong.Add($"🚩 {J.L(d, "soBaoCao")} báo cáo · lý do: {J.S(d, "lyDoBaoCao")}");
            if (J.B(d, "daAn")) dong.Add($"🙈 Đã ẩn: {J.S(d, "lyDoAn")}");
            var anh = J.S(d, "anhDanhGia").Split('|', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Take(3).Select(AnhDayDu).Where(x => x != "").ToArray();
            if (anh.Length > 0) dong.Add($"📷 {anh.Length} ảnh đính kèm");
            return new AdminDong($"{new string('⭐', (int)Math.Clamp(J.L(d, "soSao"), 0, 5))}  ({J.L(d, "soSao")}/5)", dong.ToArray(),
                J.B(d, "daAn") ? "Đã ẩn" : null, AdminUi.Do, Anh: anh);
        },
        HanhDong = tab => tab == 0
            ? new[]
            {
                new AdminHanhDong("Ẩn đánh giá", AdminUi.Do, null, async (p, d) =>
                {
                    var ly = await AdminUi.Hoi(p, "Ẩn đánh giá vi phạm", "Nhập lý do ẩn (đóng toàn bộ báo cáo của đánh giá này).", null, 3);
                    if (ly == null) return;
                    await AdminUi.Put(p, $"api/mobile/admin/danh-gia/{J.S(d, "maDanhGia")}/an", new { lyDo = ly }, "Ẩn đánh giá", $"#{J.S(d, "maDanhGia")}");
                }),
                new AdminHanhDong("Giữ lại (bác báo cáo)", AdminUi.Xanh, null, async (p, d) =>
                {
                    var ly = await AdminUi.Hoi(p, "Bác báo cáo", "Ghi chú (có thể bỏ trống).");
                    if (ly == null) return;
                    await AdminUi.Put(p, $"api/mobile/admin/danh-gia/bao-cao/{J.S(d, "maBaoCao")}/giu", new { lyDo = ly }, "Bác báo cáo đánh giá", $"#{J.S(d, "maDanhGia")}");
                }),
            }
            : new[]
            {
                new AdminHanhDong("Ẩn", AdminUi.Do, d => !J.B(d, "daAn"), async (p, d) =>
                {
                    var ly = await AdminUi.Hoi(p, "Ẩn đánh giá", "Nhập lý do ẩn.", null, 3);
                    if (ly == null) return;
                    await AdminUi.Put(p, $"api/mobile/admin/danh-gia/{J.S(d, "maDanhGia")}/an", new { lyDo = ly }, "Ẩn đánh giá", $"#{J.S(d, "maDanhGia")}");
                }),
                new AdminHanhDong("Hiện lại", AdminUi.Xanh, d => J.B(d, "daAn"),
                    async (p, d) => await AdminUi.Put(p, $"api/mobile/admin/danh-gia/{J.S(d, "maDanhGia")}/hien", null, "Hiện đánh giá", $"#{J.S(d, "maDanhGia")}")),
            },
    };
}

// =====================================================================================================================
// ĐIỀU PHỐI TÀI XẾ
// =====================================================================================================================
public sealed class AdminDispatchPage : AdminListPage
{
    private readonly ToolbarItem _nutTuDong = new() { Text = "🤖 Tự động" };

    public AdminDispatchPage() : base(Cfg())
    {
        ToolbarItems.Add(new ToolbarItem { Text = "⚡ Tự phân công", Command = new Command(async () => await TuPhanCongAsync()) });
        _nutTuDong.Command = new Command(async () => await MenuTuDongAsync());
        ToolbarItems.Add(_nutTuDong);
        ToolbarItems.Add(new ToolbarItem { Text = "🧠 Phân phối", Command = new Command(async () => await MenuPhanPhoiAsync()) });   // v86: bộ máy đề nghị có thời hạn
        Appearing += async (_, _) => await CapNhatNutTuDongAsync();
    }

    private async Task CapNhatNutTuDongAsync()
    {
        if (!Services.DuLieuService.DangOnline) return;
        var r = await Services.TuDongMayChuService.XemAsync();
        if (r.ThanhCong && r.DuLieu is not null) _nutTuDong.Text = r.DuLieu.Bat ? "🤖 Tự động: BẬT" : "🤖 Tự động: tắt";
    }

    /// <summary>Tự động phân công chạy NỀN trên máy chủ (24/7, không cần mở app): bật/tắt, xem trạng thái, chạy ngay.</summary>
    private async Task MenuTuDongAsync()
    {
        if (!Services.DuLieuService.DangOnline) { await DisplayAlert("Cần kết nối", "Tự động phân công chạy trên máy chủ nên cần kết nối.", "Đóng"); return; }
        var xem = await Services.TuDongMayChuService.XemAsync();
        if (!xem.ThanhCong || xem.DuLieu is null) { await DisplayAlert("Không đọc được trạng thái", xem.ThongDiep, "Đóng"); return; }
        var t = xem.DuLieu;
        var chon = await DisplayActionSheet("Tự động phân công (máy chủ)\n" + Services.TuDongMayChuService.Tom(t), "Đóng", null,
            t.Bat ? "Tắt tự động" : "Bật tự động", "Chạy ngay một lượt");
        if (chon == "Bật tự động" || chon == "Tắt tự động")
        {
            bool bat = chon == "Bật tự động";
            if (bat && !await DisplayAlert("Bật tự động phân công",
                    "Máy chủ sẽ tự giao các đơn quán đã báo sẵn sàng cho tài xế Sẵn sàng (ưu tiên đúng khu vực, ít đơn nhất), liên tục 24/7, KHÔNG hỏi xác nhận. Mỗi lần giao đều ghi lý do + lịch sử như phân công tay.", "Bật", "Hủy")) return;
            var r = await Services.TuDongMayChuService.DatAsync(bat);
            await DisplayAlert(r.Ok ? "Đã cập nhật" : "Không đổi được", r.ThongDiep, "OK");
        }
        else if (chon == "Chạy ngay một lượt")
        {
            var r = await Services.TuDongMayChuService.ChayNgayAsync();
            await DisplayAlert(r.Ok ? "Kết quả" : "Không chạy được", r.ThongDiep, "OK");
            await TaiAsync();
        }
        await CapNhatNutTuDongAsync();
    }

    /// <summary>
    /// Phân công hàng loạt: mỗi đơn đã sẵn sàng (và không phải quán tự giao) → tài xế "Sẵn sàng" ít đơn nhất, ưu tiên người có khu vực hoạt động trùng quận giao hàng.
    /// Hiện bản xem trước để quản trị viên xác nhận một lần rồi gọi API phân công từng đơn (ghi nhật ký như phân công tay).
    /// </summary>
    private async Task TuPhanCongAsync() => await TuPhanCongCoreAsync(false);

    private async Task TuPhanCongCoreAsync(bool khongHoi)
    {
        if (!khongHoi && !await Services.PhanQuyenService.KiemTraAsync(this, Services.Quyen.XuLyVanDe)) return;
        await TaiAsync();
        var donCho = J.Mang(Goc, "canGiao").Where(d => J.B(d, "sanSangGiao") && !J.B(d, "quanTuGiao")).ToList();
        var taiXe = J.Mang(Goc, "taiXes").Where(t => J.S(t, "trangThai") == "SanSang").ToList();
        if (donCho.Count == 0) { if (!khongHoi) await DisplayAlert("Không có đơn", "Chưa có đơn nào đã sẵn sàng giao và cần tài xế.", "Đóng"); return; }
        if (taiXe.Count == 0) { if (!khongHoi) await DisplayAlert("Không có tài xế", "Không có tài xế ở trạng thái Sẵn sàng.", "Đóng"); return; }

        var tai = taiXe.ToDictionary(t => (int)J.L(t, "maTaiXe"), t => (int)J.L(t, "soDonDangGiao"));
        var ke = new List<(JsonElement Don, JsonElement Tx, string Ma)>();
        foreach (var don in donCho)
        {
            var kv = Services.TimKiemService.BoDau(Services.GiaoHangService.TenKhuVuc(J.S(don, "diaChiGiaoHang")));
            JsonElement tot = taiXe[0]; var diem = int.MaxValue;
            foreach (var t in taiXe)
            {
                var ma = (int)J.L(t, "maTaiXe");
                var khuVuc = Services.TimKiemService.BoDau(J.S(t, "khuVucHoatDong"));
                var trung = kv.Length > 0 && khuVuc.Contains(kv);
                var d = tai[ma] * 10 + (trung ? 0 : 5);
                if (d < diem) { diem = d; tot = t; }
            }
            tai[(int)J.L(tot, "maTaiXe")]++;
            ke.Add((don, tot, J.S(don, "maDonHang")));
        }

        var xem = string.Join("\n", ke.Select(k => $"#{k.Ma} → {J.S(k.Tx, "hoTen")}"));
        if (!khongHoi && !await DisplayAlert("Tự phân công", $"Sẽ phân công {ke.Count} đơn:\n{xem}\n\nXác nhận?", "Phân công", "Hủy")) return;
        var ok = 0;
        foreach (var k in ke)
            if (await AdminUi.Put(this, $"api/mobile/admin/dieu-phoi/{k.Ma}/phan-cong",
                    new { maTaiXe = (int)J.L(k.Tx, "maTaiXe"), lyDo = khongHoi ? "Tự động phân công (không cần xác nhận)" : "Tự phân công theo tải & khu vực" },
                    "Tự phân công tài xế", $"Đơn #{k.Ma} → {J.S(k.Tx, "hoTen")}", baoThanhCong: false)) ok++;
        if (!khongHoi) await DisplayAlert("Kết quả", $"Đã phân công {ok}/{ke.Count} đơn.", "OK");
        await TaiAsync();
    }

    private static readonly string[] Khoa = { "canGiao", "dangGiao", "taiXes", "log" };

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Điều phối tài xế",
        Tab = new[] { "Cần giao", "Đang giao", "Tài xế", "Nhật ký" },
        Url = (_, _, _) => "api/mobile/admin/dieu-phoi",
        LayDs = (tab, root) => J.Mang(root, Khoa[tab]),
        TomTat = (tab, root) => tab switch
        {
            0 => GhiNhoDeNghi(root) + $"{J.Mang(root, "canGiao").Count()} đơn quán đã xác nhận đang chờ BẠN phân công tài xế." + (J.B(root, "quanTriDieuPhoi") ? " (Tài xế không tự nhận đơn.)" : " (Chế độ hàng chờ chung: tài xế có thể tự nhận.)"),
            1 => $"{J.Mang(root, "dangGiao").Count()} đơn đang có tài xế phụ trách.",
            2 => $"{J.Mang(root, "taiXes").Count()} tài xế đã duyệt và đang hoạt động (ưu tiên người sẵn sàng).",
            _ => "20 thao tác điều phối gần nhất.",
        },
        Dong = (tab, d) =>
        {
            if (tab <= 1)
            {
                var tt = AdminUi.TrangThai(J.S(d, "trangThai"));
                var dong = new List<string> { $"📍 {J.S(d, "diaChiGiaoHang")}", $"💰 {AdminUi.Tien(J.D(d, "tongTien"))}   🕒 {J.Ngay(d, "ngayDat")}" };
                if (tab == 0)
                {
                    if (J.B(d, "canPhanCongTay")) dong.Insert(0, "⚠ Không có tài xế nào nhận — BẠN hãy phân công tay");
                    dong.Add(J.B(d, "sanSangGiao") ? "✅ Quán đã báo món sẵn sàng — cần tài xế ngay" : "👨‍🍳 Quán đang chuẩn bị món");
                    if (J.B(d, "quanTuGiao")) dong.Add("🏬 Quán chọn tự giao bằng tài xế của quán");
                    if (_deNghi.TryGetValue(J.S(d, "maDonHang"), out var dn)) dong.Add(dn);
                }
                if (!J.Rong(d, "taiXe")) dong.Add($"🛵 {J.S(d, "taiXe")}");
                return new AdminDong($"#{J.S(d, "maDonHang")} · {J.S(d, "gianHang")}", dong.ToArray(), tab == 0 ? (J.B(d, "sanSangGiao") ? "Sẵn sàng" : "Đang chuẩn bị") : tt.Nhan, tab == 0 ? (J.B(d, "sanSangGiao") ? AdminUi.Do : AdminUi.Cam) : tt.Mau);
            }
            if (tab == 2)
            {
                var tt = AdminUi.TrangThai(J.S(d, "trangThai"));
                return new AdminDong(J.S(d, "hoTen"),
                    new[] { $"📞 {J.S(d, "sdt")}", $"🏍 {J.S(d, "phuongTien")} · {J.S(d, "bienSo")}", $"🗺 {(J.Rong(d, "khuVucHoatDong") ? "Chưa khai báo khu vực" : J.S(d, "khuVucHoatDong"))}", $"📦 Đang phụ trách {J.L(d, "soDonDangGiao")} đơn" },
                    tt.Nhan, tt.Mau);
            }
            var h = AdminUi.TrangThai(J.S(d, "hanhDong"));
            return new AdminDong($"#{J.S(d, "maDonHang")} · {h.Nhan}", new[] { $"Lý do: {J.S(d, "lyDo")}", $"🕒 {J.Ngay(d, "thoiGian")}" });
        },
        HanhDong = tab => tab switch
        {
            0 => new[]
            {
                new AdminHanhDong("🔍 Phân tích tài xế", AdminUi.Xanh, d => !J.B(d, "quanTuGiao"), PhanTichDon),
                new AdminHanhDong("Phân công tài xế", AdminUi.Tim, null, ChonTaiXe),
                new AdminHanhDong("🔄 Tìm lại", AdminUi.Cam, d => !J.B(d, "quanTuGiao"), async (p, d) =>
                    await AdminUi.Put(p, $"api/mobile/admin/dieu-phoi/{J.S(d, "maDonHang")}/tim-lai", null, "Tìm lại tài xế cho đơn", $"Đơn #{J.S(d, "maDonHang")}")),
                new AdminHanhDong("🤖 Gợi ý nhanh", AdminUi.Xam, d => !J.B(d, "quanTuGiao"), TuDongMotDon),
            },
            1 => new[]
            {
                new AdminHanhDong("Đổi tài xế", AdminUi.Tim, null, ChonTaiXe),
                new AdminHanhDong("Gỡ tài xế", AdminUi.Do, null, async (p, d) =>
                {
                    var ly = await AdminUi.Hoi(p, "Gỡ tài xế", "Lý do gỡ (đơn sẽ quay lại danh sách chờ nhận).", null, 3);
                    if (ly == null) return;
                    await AdminUi.Put(p, $"api/mobile/admin/dieu-phoi/{J.S(d, "maDonHang")}/go-tai-xe", new { lyDo = ly }, "Gỡ tài xế khỏi đơn", $"Đơn #{J.S(d, "maDonHang")}");
                }),
            },
            _ => Array.Empty<AdminHanhDong>(),
        },
    };

    // ---- v86: phân phối tự động (đề nghị có thời hạn) ----
    private static readonly Dictionary<string, string> _deNghi = new();

    /// <summary>Ghi nhớ đề nghị đang chờ theo đơn (để hiện trong từng thẻ) và trả dòng tóm tắt trạng thái bộ máy.</summary>
    private static string GhiNhoDeNghi(JsonElement root)
    {
        _deNghi.Clear();
        foreach (var o in J.Mang(root, "deNghi"))
        {
            var giay = Math.Max(0, (int)((DateTime.TryParse(J.S(o, "hetHanLuc"), out var h) ? h : DateTime.Now) - DateTime.Now).TotalSeconds);
            _deNghi[J.S(o, "maDonHang")] = $"🔔 Đang đề nghị cho {J.S(o, "taiXe")} · còn ~{giay}s · vòng {J.S(o, "vong")}" + (J.Rong(o, "kmDenQuan") ? "" : $" · cách quán {J.D(o, "kmDenQuan"):0.#} km");
        }
        var pp = J.Doi(root, "phanPhoi");
        if (pp.ValueKind != JsonValueKind.Object) return "";
        return (J.B(pp, "tuDong") ? "🧠 Phân phối tự động: BẬT. " : "🧠 Phân phối tự động: tắt (phân công tay). ") + $"Đang chờ phản hồi: {_deNghi.Count} đề nghị.\n";
    }

    /// <summary>Bảng phân tích: tài xế nào đủ điều kiện (khoảng cách, thời gian tới quán, điểm) và ai bị loại cùng lý do.</summary>
    private static async Task PhanTichDon(AdminListPage p, JsonElement don)
    {
        var ma = J.S(don, "maDonHang");
        var r = await ApiClient.GetAsync<JsonElement>($"api/mobile/admin/dieu-phoi/{ma}/phan-tich");
        if (!r.ThanhCong) { await p.DisplayAlert("Không phân tích được", r.ThongDiep, "Đóng"); return; }
        var ds = J.Mang(r.DuLieu, "ungVien").ToList();
        if (ds.Count == 0) { await p.DisplayAlert($"Đơn #{ma}", "Chưa có tài xế nào đã duyệt.", "Đóng"); return; }
        string Dong(JsonElement t)
        {
            var km = J.Rong(t, "km") ? "—" : $"{J.D(t, "km"):0.#} km" + (J.B(t, "kmUocTinh") ? "~" : "");
            var dau = J.B(t, "coThe") ? "✔" : "✖";
            var thong = J.B(t, "coThe") ? $"{km} · ~{J.L(t, "phutDenQuan")} phút · điểm {J.D(t, "diem"):0.00}" : $"{km} · {AdminUi.TrangThai(J.S(t, "trangThai")).Nhan}";
            return $"{dau} {J.S(t, "hoTen")} ({J.S(t, "phuongTien")}) — {thong}\n    {J.S(t, "lyDo")}";
        }
        var tong = $"{ds.Count(t => J.B(t, "coThe"))}/{ds.Count} tài xế đủ điều kiện\n\n";
        var de = J.Mang(r.DuLieu, "deNghi").Take(4).Select(o => $"• {J.Ngay(o, "taoLuc", "HH:mm:ss")} tài xế #{J.S(o, "maTaiXe")}: {J.S(o, "trangThai")}{(J.Rong(o, "lyDoPhanHoi") ? "" : " (" + J.S(o, "lyDoPhanHoi") + ")")}").ToList();
        await p.DisplayAlert($"Phân tích đơn #{ma}", tong + string.Join("\n", ds.Take(12).Select(Dong)) + (de.Count > 0 ? "\n\nĐề nghị gần đây:\n" + string.Join("\n", de) : ""), "Đóng");
    }

    /// <summary>Trạng thái bộ máy phân phối + bật/tắt (chỉ Admin tổng đổi được cấu hình).</summary>
    private async Task MenuPhanPhoiAsync()
    {
        var pp = J.Doi(Goc, "phanPhoi");
        var bat = pp.ValueKind == JsonValueKind.Object && J.B(pp, "tuDong");
        var tomTat = pp.ValueKind != JsonValueKind.Object ? "Chưa có dữ liệu (kéo để làm mới)." :
            $"{(bat ? "BẬT" : "TẮT")} · lần chạy cuối {(J.Rong(pp, "lanChayCuoi") ? "—" : J.Ngay(pp, "lanChayCuoi", "HH:mm:ss"))}\n{J.S(pp, "ketQua")}\nTổng đề nghị đã tạo: {J.L(pp, "tongDeNghi")}";
        var chon = await DisplayActionSheet("Phân phối đơn tự động\n" + tomTat, "Đóng", null, bat ? "Tắt phân phối tự động" : "Bật phân phối tự động");
        if (chon is null or "Đóng") return;
        if (await AdminUi.Put(this, "api/mobile/admin/cau-hinh", new { khoa = "PhanPhoi.TuDong", giaTri = chon.StartsWith("Bật") ? "1" : "0" }, "Đổi cấu hình phân phối đơn", chon)) await TaiAsync();
    }

    /// <summary>Xem xếp hạng tài xế do máy chủ chấm điểm cho một đơn, xác nhận để giao cho người điểm cao nhất.</summary>
    private static async Task TuDongMotDon(AdminListPage p, JsonElement don)
    {
        var maDon = J.S(don, "maDonHang");
        var r = await ApiClient.GetAsync<JsonElement>($"api/mobile/admin/dieu-phoi/{maDon}/goi-y");
        if (!r.ThanhCong) { await p.DisplayAlert("Không lấy được gợi ý", r.ThongDiep, "Đóng"); return; }
        var ds = J.Mang(r.DuLieu, "ds").Take(3).ToList();
        if (ds.Count == 0) { await p.DisplayAlert("Chưa có tài xế phù hợp", "Không có tài xế đang rảnh (hoặc đang giữ ít đơn cùng quán) và chưa từ chối đơn này. Hãy chọn thủ công hoặc chờ tài xế online.", "Đóng"); return; }
        var chu = string.Join("\n\n", ds.Select((t, i) => $"{i + 1}. {J.S(t, "hoTen")}  (điểm {J.D(t, "diem"):0.00})\n   {J.S(t, "lyDo")}"));
        if (!await p.DisplayAlert($"Gợi ý cho đơn #{maDon}", chu + $"\n\nGiao cho {J.S(ds[0], "hoTen")}?", "Giao", "Hủy")) return;
        await AdminUi.Put(p, $"api/mobile/admin/dieu-phoi/{maDon}/tu-dong", null, "Tự động chọn tài xế", $"Đơn #{maDon} → {J.S(ds[0], "hoTen")}");
    }

    private static async Task ChonTaiXe(AdminListPage p, JsonElement don)
    {
        var maDon = J.S(don, "maDonHang");
        var tx = J.Mang(p.Goc, "taiXes").ToList();
        if (tx.Count == 0) { await p.DisplayAlert("Chưa có tài xế", "Không có tài xế nào đã duyệt và đang hoạt động.", "Đóng"); return; }
        var nhan = tx.Select((t, i) => $"{i + 1}. {J.S(t, "hoTen")} · {AdminUi.TrangThai(J.S(t, "trangThai")).Nhan} · {J.L(t, "soDonDangGiao")} đơn").ToArray();
        var chon = await p.DisplayActionSheet($"Chọn tài xế cho đơn #{maDon}", "Hủy", null, nhan);
        var idx = Array.IndexOf(nhan, chon);
        if (idx < 0) return;
        var ly = await AdminUi.Hoi(p, "Lý do phân công", "Ghi rõ lý do (tối thiểu 3 ký tự).", null, 3, "Điều phối thủ công");
        if (ly == null) return;
        await AdminUi.Put(p, $"api/mobile/admin/dieu-phoi/{maDon}/phan-cong", new { maTaiXe = (int)J.L(tx[idx], "maTaiXe"), lyDo = ly }, "Phân công tài xế", $"Đơn #{maDon} → {J.S(tx[idx], "hoTen")}");
    }
}

// =====================================================================================================================
// TÀI XẾ — danh sách, chỉnh sửa, duyệt, khóa
// =====================================================================================================================
public sealed class AdminDriverListPage : AdminListPage
{
    public AdminDriverListPage() : base(Cfg()) { }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Quản lý tài xế",
        GoiYTimKiem = "Tên, SĐT, biển số…",
        TimTrenMay = true,
        Loc = _ => new (string Nhan, string GiaTri)[]
        {
            ("Tất cả", ""), ("Chờ duyệt", "ChoDuyet"), ("Đã duyệt", "DaDuyet"), ("Bị từ chối", "TuChoi"), ("Đang bị khóa", "khoa"), ("Đang hoạt động", "hoatdong"),
        },
        Url = (_, _, _) => "api/mobile/admin/tai-xe",
        LocMay = (_, d, loc) => loc switch
        {
            "khoa" => J.B(d, "taiKhoanBiKhoa"),
            "hoatdong" => J.B(d, "dangHoatDong") && !J.B(d, "taiKhoanBiKhoa") && J.S(d, "trangThaiDangKy") == "DaDuyet",
            _ => J.S(d, "trangThaiDangKy") == loc,
        },
        Dong = (_, d) =>
        {
            var khoa = J.B(d, "taiKhoanBiKhoa");
            var tt = khoa ? ("🔒 Đã khóa", AdminUi.Do) : AdminUi.TrangThai(J.S(d, "trangThaiDangKy"));
            var dong = new List<string>
            {
                $"📞 {J.S(d, "soDienThoai")}", $"🏍 {J.S(d, "loaiXe")} · {(J.Rong(d, "bienSoXe") ? "chưa có biển số" : J.S(d, "bienSoXe"))}",
                $"📅 Đăng ký {J.Ngay(d, "ngayDangKy", "dd/MM/yyyy")}",
            };
            if (!J.Rong(d, "lyDoTuChoi") && J.S(d, "trangThaiDangKy") == "TuChoi") dong.Add($"Lý do từ chối: {J.S(d, "lyDoTuChoi")}");
            return new AdminDong(J.S(d, "hoTen"), dong.ToArray(), tt.Item1, tt.Item2);
        },
        Mo = ChiTiet,
        HanhDong = _ => new[]
        {
            new AdminHanhDong("Xem chi tiết", AdminUi.Tim, null, ChiTiet),
            new AdminHanhDong("Sửa thông tin", AdminUi.Tim, null, Sua),
            new AdminHanhDong("Duyệt", AdminUi.Xanh, d => J.S(d, "trangThaiDangKy") == "ChoDuyet",
                async (p, d) => await AdminUi.Put(p, $"api/mobile/admin/tai-xe/{J.S(d, "id")}/duyet", null, "Duyệt tài xế", J.S(d, "hoTen"))),
            new AdminHanhDong("Từ chối", AdminUi.Do, d => J.S(d, "trangThaiDangKy") == "ChoDuyet", async (p, d) =>
            {
                var ly = await AdminUi.Hoi(p, "Từ chối hồ sơ", "Lý do từ chối (tài xế sẽ nhận thông báo).", null, 3);
                if (ly == null) return;
                await AdminUi.Put(p, $"api/mobile/admin/tai-xe/{J.S(d, "id")}/tu-choi", new { lyDo = ly }, "Từ chối tài xế", J.S(d, "hoTen"));
            }),
            new AdminHanhDong("Khóa", AdminUi.Do, d => !J.B(d, "taiKhoanBiKhoa") && J.S(d, "trangThaiDangKy") == "DaDuyet", async (p, d) =>
            {
                if (!await p.DisplayAlert("Khóa tài xế", $"Khóa tài khoản \"{J.S(d, "hoTen")}\"? Tài xế sẽ không nhận được đơn và không đăng nhập được.", "Khóa", "Hủy")) return;
                await AdminUi.Put(p, $"api/mobile/admin/tai-xe/{J.S(d, "id")}/khoa", null, "Khóa tài xế", J.S(d, "hoTen"));
            }),
            new AdminHanhDong("Mở khóa", AdminUi.Xanh, d => J.B(d, "taiKhoanBiKhoa"),
                async (p, d) => await AdminUi.Put(p, $"api/mobile/admin/tai-xe/{J.S(d, "id")}/mo-khoa", null, "Mở khóa tài xế", J.S(d, "hoTen"))),
        },
    };

    private static async Task ChiTiet(AdminListPage p, JsonElement d)
    {
        var r = await ApiClient.GetAsync<JsonElement>($"api/mobile/admin/tai-xe/{J.S(d, "id")}");
        if (!r.ThanhCong) { await p.DisplayAlert("Không tải được", r.ThongDiep, "Đóng"); return; }
        var t = r.DuLieu;
        var sao = J.Rong(t, "saoTrungBinh") ? "chưa có đánh giá" : $"{J.S(t, "saoTrungBinh")} ⭐";
        var noiDung =
            $"📞 {J.S(t, "sdt")}\n🏍 {J.S(t, "phuongTien")} · {J.S(t, "bienSo")}\n🗺 {(J.Rong(t, "khuVucHoatDong") ? "Chưa khai báo khu vực" : J.S(t, "khuVucHoatDong"))}\n" +
            $"🪪 CCCD: {J.S(t, "soCCCD")}   GPLX: {J.S(t, "soGPLX")}\n\n" +
            $"Tổng chuyến: {J.L(t, "tongChuyen")}   ·   Đã giao: {J.L(t, "daGiao")}\nGiao thất bại: {J.L(t, "thatBai")}   ·   Đang giao: {J.L(t, "dangGiao")}\n" +
            $"Đánh giá trung bình: {sao}\nCOD chưa nộp: {AdminUi.Tien(J.D(t, "codChuaNop"))}";
        await p.DisplayAlert(J.S(t, "hoTen"), noiDung, "Đóng");
    }

    private static async Task Sua(AdminListPage p, JsonElement d)
    {
        var id = J.S(d, "id");
        var r = await ApiClient.GetAsync<JsonElement>($"api/mobile/admin/tai-xe/{id}");
        if (!r.ThanhCong) { await p.DisplayAlert("Không tải được", r.ThongDiep, "Đóng"); return; }
        var t = r.DuLieu;
        var ten = await AdminUi.Hoi(p, "Sửa tài xế (1/5)", "Họ tên", null, 2, J.S(t, "hoTen")); if (ten == null) return;
        var sdt = await AdminUi.Hoi(p, "Sửa tài xế (2/5)", "Số điện thoại (9–11 số)", null, 9, J.S(t, "sdt"), Keyboard.Telephone); if (sdt == null) return;
        var pt = await AdminUi.Hoi(p, "Sửa tài xế (3/5)", "Phương tiện", null, 0, J.S(t, "phuongTien")); if (pt == null) return;
        var bien = await AdminUi.Hoi(p, "Sửa tài xế (4/5)", "Biển số xe", null, 0, J.S(t, "bienSo")); if (bien == null) return;
        var kv = await AdminUi.Hoi(p, "Sửa tài xế (5/5)", "Khu vực hoạt động", null, 0, J.S(t, "khuVucHoatDong")); if (kv == null) return;
        await AdminUi.Put(p, $"api/mobile/admin/tai-xe/{id}", new { hoTen = ten, sdt, phuongTien = pt, bienSo = bien, khuVuc = kv }, "Sửa thông tin tài xế", ten);
    }
}

// =====================================================================================================================
// TÀI KHOẢN — toàn bộ vai trò
// =====================================================================================================================
public sealed class AdminAccountsPage : AdminListPage
{
    public AdminAccountsPage() : base(Cfg()) { }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Quản lý tài khoản",
        GoiYTimKiem = "Tên đăng nhập, họ tên, SĐT…",
        Loc = _ => new (string Nhan, string GiaTri)[]
        {
            ("Tất cả vai trò", ""), ("Khách hàng", "vaiTro=KhachHang"), ("Gian hàng", "vaiTro=GianHang"), ("Tài xế", "vaiTro=TaiXe"),
            ("Quản trị", "vaiTro=QuanTri"), ("Đang bị khóa", "biKhoa=true"),
        },
        Url = (_, q, loc) => $"api/mobile/admin/tai-khoan?q={AdminUi.Q(q)}" + (loc == "" ? "" : "&" + loc),
        Dong = (_, d) =>
        {
            var vt = AdminUi.TrangThai(J.S(d, "vaiTro"));
            var khoa = J.B(d, "biKhoa");
            var dong = new List<string>
            {
                $"👤 {J.S(d, "moTa")}",
                $"Vai trò: {vt.Nhan}   ·   Tạo {J.Ngay(d, "ngayTao", "dd/MM/yyyy")}",
                J.Rong(d, "lanDangNhapCuoi") ? "Chưa đăng nhập lần nào" : $"Đăng nhập cuối: {J.Ngay(d, "lanDangNhapCuoi")}",
            };
            if (J.B(d, "biKhoaTam")) dong.Add($"⚠️ Đang bị khóa tạm do nhập sai mật khẩu {J.L(d, "soLanDangNhapSai")} lần");
            return new AdminDong(J.S(d, "tenDangNhap"), dong.ToArray(), khoa ? "🔒 Đã khóa" : vt.Nhan, khoa ? AdminUi.Do : vt.Mau);
        },
        HanhDong = _ => new[]
        {
            new AdminHanhDong("Khóa", AdminUi.Do, d => !J.B(d, "biKhoa"), async (p, d) =>
            {
                if (!await p.DisplayAlert("Khóa tài khoản", $"Khóa \"{J.S(d, "tenDangNhap")}\"? Người dùng sẽ không đăng nhập được cho tới khi được mở lại.", "Khóa", "Hủy")) return;
                await AdminUi.Put(p, $"api/mobile/admin/tai-khoan/{J.S(d, "maTK")}/khoa", null, "Khóa tài khoản", J.S(d, "tenDangNhap"));
            }),
            new AdminHanhDong("Mở khóa", AdminUi.Xanh, d => J.B(d, "biKhoa") || J.B(d, "biKhoaTam"),
                async (p, d) => await AdminUi.Put(p, $"api/mobile/admin/tai-khoan/{J.S(d, "maTK")}/mo-khoa", null, "Mở khóa tài khoản", J.S(d, "tenDangNhap"))),
        },
    };
}

// =====================================================================================================================
// CẤU HÌNH hệ thống (phí giao, phí nền tảng, hủy/hoàn tiền, thời gian xử lý, quy định…)
// =====================================================================================================================
public sealed class AdminConfigPage : AdminListPage
{
    public AdminConfigPage() : base(Cfg()) { }

    private static string HienThi(JsonElement m)
    {
        var k = J.S(m, "kieu"); var v = J.S(m, "giaTri"); var dv = J.S(m, "donVi");
        switch (k)
        {
            case "Bat": return v == "1" ? "Bật" : "Tắt";
            case "Tien": return decimal.TryParse(v, NumberStyles.Any, CultureInfo.InvariantCulture, out var t) ? AdminUi.Tien(t) : v;
            case "TyLe": return decimal.TryParse(v, NumberStyles.Any, CultureInfo.InvariantCulture, out var r) ? $"{r * 100:0.##}%" : v;
            case "VanBan": return v.Length > 140 ? v[..140] + "…" : v;
            default: return dv != "" ? $"{v} {dv}" : v;
        }
    }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Cấu hình hệ thống",
        Url = (_, _, _) => "api/mobile/admin/cau-hinh",
        LayDs = (_, root) => J.Mang(root, "nhom").SelectMany(n => J.Mang(n, "muc")),
        TomTat = (_, _) => PhanQuyenService.Co(Quyen.QuanLyNhanVien)
            ? "Giá trị thay đổi có hiệu lực ngay với đơn mới. Mọi thay đổi được lưu lịch sử người sửa."
            : "Bạn chỉ có quyền xem. Chỉ Admin tổng được sửa cấu hình.",
        Dong = (_, d) =>
        {
            var dong = new List<string> { $"Giá trị hiện tại: {HienThi(d)}", J.S(d, "moTa") };
            if (!J.Rong(d, "ngaySua")) dong.Add($"Sửa lần cuối: {J.Ngay(d, "ngaySua")}");
            return new AdminDong($"{J.S(d, "icon")} {J.S(d, "nhan")}", dong.ToArray(), J.S(d, "nhom"), AdminUi.Tim);
        },
        Mo = (p, d) => Sua(p, d),
        HanhDong = tab => new[] { new AdminHanhDong("Sửa giá trị", AdminUi.Tim, x => PhanQuyenService.Co(Quyen.QuanLyNhanVien), Sua) },
        HanhDongChung = tab => new[]
        {
            new AdminHanhDong("📜 Lịch sử thay đổi", AdminUi.Xam, null, async (p, _) =>
            {
                var r = await ApiClient.GetAsync<JsonElement>("api/mobile/admin/cau-hinh/lich-su");
                if (!r.ThanhCong) { await p.DisplayAlert("Không tải được", r.ThongDiep, "Đóng"); return; }
                var ds = r.DuLieu.ValueKind == JsonValueKind.Array ? r.DuLieu.EnumerateArray().Take(15).ToList() : new List<JsonElement>();
                var chu = ds.Count == 0 ? "Chưa có thay đổi nào." : string.Join("\n\n", ds.Select(x =>
                    $"{J.Ngay(x, "thoiGian")} · {J.S(x, "nguoiSua")}\n{J.S(x, "khoa")}: {Cat(J.S(x, "giaTriCu"))} → {Cat(J.S(x, "giaTriMoi"))}"));
                await p.DisplayAlert("15 thay đổi gần nhất", chu, "Đóng");
            }),
        },
    };

    private static string Cat(string s) => s.Length > 40 ? s[..40] + "…" : s;

    private static async Task Sua(AdminListPage p, JsonElement d)
    {
        if (!PhanQuyenService.Co(Quyen.QuanLyNhanVien)) { await p.DisplayAlert("Chỉ xem", "Chỉ Admin tổng được sửa cấu hình hệ thống.", "Đóng"); return; }
        var khoa = J.S(d, "khoa"); var nhan = J.S(d, "nhan"); var kieu = J.S(d, "kieu");
        string? moi;
        if (kieu == "Bat")
        {
            var c = await p.DisplayActionSheet(nhan, "Hủy", null, "Bật", "Tắt");
            if (c is null or "Hủy") return;
            moi = c == "Bật" ? "1" : "0";
        }
        else
        {
            var goiY = kieu switch { "Tien" => "Số tiền (đồng)", "TyLe" => "0.15 hoặc 15%", "Km" => "Số km", "Phut" => "Số phút", "SoNguyen" => "Số nguyên", _ => "Nội dung" };
            moi = await AdminUi.Hoi(p, nhan, $"{J.S(d, "moTa")}\n({goiY})", null, 1, J.S(d, "giaTri"),
                kieu is "Tien" or "SoNguyen" or "Phut" or "Km" or "TyLe" ? Keyboard.Numeric : Keyboard.Text);
            if (moi == null) return;
        }
        await AdminUi.Put(p, "api/mobile/admin/cau-hinh", new { khoa, giaTri = moi }, "Sửa cấu hình hệ thống", $"{nhan} = {moi}");
    }
}

// =====================================================================================================================
// PHÂN QUYỀN quản trị (online) — Admin tổng / Quản lý / Nhân viên hỗ trợ
// =====================================================================================================================
public sealed class AdminStaffOnlinePage : AdminListPage
{
    public AdminStaffOnlinePage() : base(Cfg()) { }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Phân quyền quản trị",
        GoiYTimKiem = "Tìm theo tên, tài khoản…",
        TimTrenMay = true,
        Url = (_, _, _) => "api/mobile/admin/nhan-vien",
        LayDs = (_, root) => J.Mang(root, "ds"),
        TomTat = (_, _) => "Admin tổng: toàn quyền. Quản lý: vận hành theo quyền chi tiết. Nhân viên hỗ trợ: chỉ xem và xử lý khiếu nại/sự cố, trừ khi được cấp thêm quyền.",
        Dong = (p, d) =>
        {
            var cap = AdminUi.TrangThai(J.S(d, "capQuyen"));
            var khoa = J.B(d, "biKhoa");
            var quyen = J.Mang(d, "quyen").Select(x => TenQuyen(x.GetString() ?? "")).ToList();
            var dong = new List<string>
            {
                $"📞 {(J.Rong(d, "sdt") ? "—" : J.S(d, "sdt"))}   ✉️ {(J.Rong(d, "email") ? "—" : J.S(d, "email"))}",
                J.S(d, "capQuyen") == "SuperAdmin" ? "Quyền: toàn bộ chức năng" : "Quyền chức năng: " + (quyen.Count == 0 ? "chỉ xem + xử lý khiếu nại" : string.Join(", ", quyen)) + (J.B(d, "tuyChinh") ? "  (đã tùy chỉnh)" : ""),
            };
            return new AdminDong($"{J.S(d, "hoTen")} ({J.S(d, "tenDangNhap")})", dong.ToArray(), khoa ? "🔒 Đã khóa" : cap.Nhan, khoa ? AdminUi.Do : cap.Mau);
        },
        HanhDong = _ => new[]
        {
            new AdminHanhDong("Quyền chi tiết", AdminUi.Tim, d => J.S(d, "capQuyen") != "SuperAdmin", DoiQuyen),
            new AdminHanhDong("Đổi cấp", AdminUi.Tim, null, DoiCap),
            new AdminHanhDong("Khóa", AdminUi.Do, d => !J.B(d, "biKhoa") && J.S(d, "capQuyen") != "SuperAdmin", async (p, d) =>
            {
                if (!await p.DisplayAlert("Khóa tài khoản", $"Khóa \"{J.S(d, "hoTen")}\"?", "Khóa", "Hủy")) return;
                await AdminUi.Put(p, $"api/mobile/admin/tai-khoan/{J.S(d, "maTK")}/khoa", null, "Khóa tài khoản quản trị", J.S(d, "tenDangNhap"));
            }),
            new AdminHanhDong("Mở khóa", AdminUi.Xanh, d => J.B(d, "biKhoa"),
                async (p, d) => await AdminUi.Put(p, $"api/mobile/admin/tai-khoan/{J.S(d, "maTK")}/mo-khoa", null, "Mở khóa tài khoản quản trị", J.S(d, "tenDangNhap"))),
        },
        HanhDongChung = _ => new[] { new AdminHanhDong("＋ Thêm tài khoản quản trị", AdminUi.Tim, null, Them) },
    };

    private static string TenQuyen(string khoa) => khoa switch
    {
        "DonHang" => "Đơn hàng & điều phối", "ThanhToan" => "Giao dịch & đối soát", "HoanTien" => "Duyệt hoàn tiền",
        "DanhGia" => "Kiểm duyệt đánh giá", "ThongBao" => "Thông báo & món ăn", _ => khoa,
    };

    private static async Task DoiQuyen(AdminListPage p, JsonElement d)
    {
        var tatCa = J.Mang(p.Goc, "quyenTatCa").Select(x => (Khoa: J.S(x, "khoa"), Ten: J.S(x, "ten"))).ToList();
        var chon = J.Mang(d, "quyen").Select(x => x.GetString() ?? "").ToHashSet();
        const string luu = "💾 Lưu thay đổi", macDinh = "↩️ Đặt về mặc định theo cấp";
        while (true)
        {
            var nhan = tatCa.Select(t => (chon.Contains(t.Khoa) ? "✅ " : "⬜ ") + t.Ten).ToList();
            var c = await p.DisplayActionSheet($"Quyền của {J.S(d, "hoTen")} (chạm để bật/tắt)", "Hủy", null, nhan.Concat(new[] { luu, macDinh }).ToArray());
            if (c is null or "Hủy") return;
            var maTK = J.S(d, "maTK");
            if (c == luu) { await AdminUi.Put(p, $"api/mobile/admin/nhan-vien/{maTK}/quyen", new { quyen = chon.ToArray(), macDinh = false }, "Cập nhật quyền chi tiết", J.S(d, "tenDangNhap")); return; }
            if (c == macDinh) { await AdminUi.Put(p, $"api/mobile/admin/nhan-vien/{maTK}/quyen", new { quyen = Array.Empty<string>(), macDinh = true }, "Đặt quyền mặc định", J.S(d, "tenDangNhap")); return; }
            var i = nhan.IndexOf(c);
            if (i >= 0 && !chon.Remove(tatCa[i].Khoa)) chon.Add(tatCa[i].Khoa);
        }
    }

    private static async Task<string?> ChonCap(AdminListPage p, string tieuDe)
    {
        var c = await p.DisplayActionSheet(tieuDe, "Hủy", null, "Quản lý vận hành", "Nhân viên hỗ trợ", "Admin tổng");
        return c switch { "Quản lý vận hành" => "QuanLy", "Nhân viên hỗ trợ" => "NhanVien", "Admin tổng" => "SuperAdmin", _ => null };
    }

    private static async Task DoiCap(AdminListPage p, JsonElement d)
    {
        var cap = await ChonCap(p, $"Cấp quyền mới cho {J.S(d, "hoTen")}");
        if (cap == null) return;
        if (cap == "SuperAdmin" && !await p.DisplayAlert("Nâng lên Admin tổng", "Admin tổng có toàn quyền (cấu hình, tài khoản, nhật ký). Chắc chắn nâng cấp?", "Nâng cấp", "Hủy")) return;
        await AdminUi.Put(p, $"api/mobile/admin/nhan-vien/{J.S(d, "maTK")}/cap", new { capQuyen = cap }, "Đổi cấp quyền quản trị", J.S(d, "tenDangNhap"));
    }

    private static async Task Them(AdminListPage p, JsonElement _)
    {
        var ten = await AdminUi.Hoi(p, "Tài khoản mới (1/5)", "Tên đăng nhập (≥ 3 ký tự)", null, 3); if (ten == null) return;
        var hoTen = await AdminUi.Hoi(p, "Tài khoản mới (2/5)", "Họ tên", null, 2); if (hoTen == null) return;
        var sdt = await AdminUi.Hoi(p, "Tài khoản mới (3/5)", "Số điện thoại (có thể bỏ trống)", null, 0, "", Keyboard.Telephone); if (sdt == null) return;
        var email = await AdminUi.Hoi(p, "Tài khoản mới (4/5)", "Email (có thể bỏ trống)", null, 0, "", Keyboard.Email); if (email == null) return;
        var mk = await AdminUi.Hoi(p, "Tài khoản mới (5/5)", "Mật khẩu tạm (≥ 6 ký tự). Hãy yêu cầu đổi sau lần đăng nhập đầu.", null, 6); if (mk == null) return;
        var cap = await ChonCap(p, "Chọn cấp quyền"); if (cap == null) return;
        await AdminUi.Post(p, "api/mobile/admin/nhan-vien", new { tenDangNhap = ten, hoTen, sdt, email, capQuyen = cap, matKhau = mk }, "Tạo tài khoản quản trị", ten);
    }
}
