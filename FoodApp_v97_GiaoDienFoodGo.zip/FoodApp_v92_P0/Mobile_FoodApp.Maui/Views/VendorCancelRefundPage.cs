using System.Text.Json;
using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Gian hàng: xử lý YÊU CẦU HỦY của khách (đồng ý / từ chối kèm lý do) và theo dõi HOÀN TIỀN của các đơn của quán.
/// Quy định: chỉ đồng ý hủy khi đơn chưa giao cho tài xế; đơn đã thanh toán online tự tạo yêu cầu hoàn tiền chờ Quản trị duyệt
/// (hoàn trên ngưỡng cần Admin tổng); từ chối thì Quản trị xem xét và quyết định cuối cùng.
/// </summary>
public sealed class VendorCancelRefundPage : AdminListPage
{
    public VendorCancelRefundPage() : base(Cfg()) { }

    private static string Quan() => MockData.GianHangHienTai.Id;

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Hủy & hoàn tiền",
        Tab = new[] { "Yêu cầu hủy", "Hoàn tiền" },
        Url = (tab, _, _) => tab == 0 ? $"api/mobile/gian-hang/{Quan()}/yeu-cau-huy" : $"api/mobile/gian-hang/{Quan()}/hoan-tien",
        TomTat = (tab, _) => tab == 0
            ? "Khách gửi yêu cầu khi đơn đã được quán nhận. Chỉ đồng ý hủy được khi đơn chưa giao cho tài xế; đơn đã trả online sẽ tự tạo yêu cầu hoàn tiền chờ Quản trị duyệt."
            : "Gian hàng chỉ xem. Quản trị duyệt hoàn tiền theo quy định (khoản trên ngưỡng cần Admin tổng duyệt).",
        Dong = (tab, d) =>
        {
            if (tab == 0)
            {
                var tt = J.S(d, "trangThai");
                var (nhan, mau) = tt switch
                {
                    "DaXuLy" => ("Đã xử lý", AdminUi.Xanh),
                    "DaTuChoi" => ("Đã từ chối · chờ Quản trị", AdminUi.Xam),
                    _ => ("Chờ xử lý", AdminUi.Cam),
                };
                var dong = new List<string>
                {
                    J.S(d, "noiDung"),
                    $"👤 {J.S(d, "khach")}   💰 {AdminUi.Tien(J.D(d, "tongTien"))}   💳 {AdminUi.TrangThai(J.S(d, "hinhThucTT")).Nhan} ({AdminUi.TrangThai(J.S(d, "trangThaiTT")).Nhan})",
                    $"Đơn hiện: {AdminUi.TrangThai(J.S(d, "trangThaiDon")).Nhan}   🕒 {J.Ngay(d, "ngayGui")}",
                };
                if (tt == "ChoXuLy" && !J.B(d, "coTheDongY")) dong.Add("⚠️ Đơn đã giao cho tài xế/đã kết thúc: quán không tự hủy được, Quản trị sẽ xử lý.");
                if (!J.Rong(d, "traLoi")) dong.Add($"↳ {J.S(d, "traLoi")}");
                return new AdminDong($"Đơn #{J.S(d, "maDonHang")}", dong.ToArray(), nhan, mau);
            }
            var ht = AdminUi.TrangThai(J.S(d, "trangThai"));
            var l = new List<string>
            {
                $"Lý do: {J.S(d, "lyDo")}",
                $"Nguồn: {J.S(d, "nguon")}   🕒 {J.Ngay(d, "ngayTao")}",
            };
            if (!J.Rong(d, "ketQua")) l.Add($"Kết quả: {J.S(d, "ketQua")}");
            return new AdminDong($"Đơn #{J.S(d, "maDonHang")} · hoàn {AdminUi.Tien(J.D(d, "soTien"))}", l.ToArray(), ht.Nhan, ht.Mau);
        },
        HanhDong = tab => tab != 0 ? Array.Empty<AdminHanhDong>() : new[]
        {
            new AdminHanhDong("Đồng ý hủy đơn", AdminUi.Do, d => J.B(d, "coTheDongY"), async (p, d) =>
            {
                var ma = J.S(d, "maDonHang");
                if (!await p.DisplayAlert("Đồng ý hủy đơn", $"Hủy đơn #{ma}? Khách được thông báo; đơn đã thanh toán online sẽ tạo yêu cầu hoàn {AdminUi.Tien(J.D(d, "tongTien"))} chờ Quản trị duyệt.", "Hủy đơn", "Để sau")) return;
                await AdminUi.Put(p, $"api/mobile/gian-hang/{Quan()}/yeu-cau-huy/{J.S(d, "maPhanHoi")}/dong-y", null);
                _ = DuLieuService.TaiDonHangGianHangAsync(Quan());
            }),
            new AdminHanhDong("Từ chối", AdminUi.Xam, d => J.S(d, "trangThai") == "ChoXuLy", async (p, d) =>
            {
                var ly = await AdminUi.Hoi(p, "Từ chối hủy đơn", "Nhập lý do (khách sẽ nhìn thấy, Quản trị xem xét lại).", null, 5);
                if (ly == null) return;
                await AdminUi.Put(p, $"api/mobile/gian-hang/{Quan()}/yeu-cau-huy/{J.S(d, "maPhanHoi")}/tu-choi", new { lyDo = ly });
            }),
        },
    };
}
