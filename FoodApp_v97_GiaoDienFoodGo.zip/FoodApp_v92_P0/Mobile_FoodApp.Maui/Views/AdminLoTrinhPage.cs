using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// v87 — Lộ trình triển khai theo 12 giai đoạn + đội ngũ thực hiện (Project Manager, BA, UI/UX, Backend, Mobile, Web, QA, DevOps, Vận hành).
/// Quản trị chạm vào từng giai đoạn để đánh dấu tiến độ, chạm vào từng vai trò để ghi người phụ trách.
/// Tiến độ và tên người phụ trách chỉ LƯU TRÊN THIẾT BỊ NÀY (Preferences), không đồng bộ lên máy chủ.
/// </summary>
public sealed class AdminLoTrinhPage : AdminKyThuatTrang
{
    private sealed record GiaiDoan(int So, string Ten, string CongViec, string BanGiao, string TrongApp);
    private sealed record VaiTro(string Ten, string TrachNhiem);
    private sealed record UuTien(int So, string Ten, string MoTa, string Nhan, string? Route);

    private static readonly string[] TrangThai = { "Chưa bắt đầu", "Đang làm", "Hoàn thành" };

    private static readonly GiaiDoan[] CacGiaiDoan =
    {
        new(1, "Khảo sát", "Xác định mô hình kinh doanh, người dùng", "Tài liệu yêu cầu", "Docs/ (tài liệu yêu cầu, README)"),
        new(2, "Phân tích", "Use Case, BPMN, quy trình đơn hàng", "Tài liệu nghiệp vụ", "Quản trị → Quy trình hoạt động"),
        new(3, "Thiết kế", "ERD, kiến trúc API, UI/UX", "Bộ thiết kế hệ thống", "Database/ (ERD qua script), Docs/"),
        new(4, "Backend", "Tài khoản, nhà hàng, đơn hàng, tài xế", "Backend API", "Web/FoodServiceApp.Web (api/mobile/*)"),
        new(5, "Customer", "Đặt món, thanh toán, theo dõi", "Ứng dụng khách hàng", "App khách: đặt món, thanh toán, theo dõi đơn"),
        new(6, "Restaurant", "Thực đơn, xác nhận và xử lý đơn", "Ứng dụng nhà hàng", "App đối tác (quán): thực đơn, xử lý đơn, vận hành"),
        new(7, "Driver", "Nhận đơn, GPS, giao hàng", "Ứng dụng tài xế", "App tài xế: nhận đơn, lộ trình, giao hàng"),
        new(8, "Admin", "Quản trị và báo cáo", "Website quản trị", "App quản trị + trang web quản trị"),
        new(9, "Tích hợp", "Bản đồ, thanh toán, thông báo", "Hệ thống kết nối", "Goong Maps, VNPay, SignalR thời gian thực"),
        new(10, "Kiểm thử", "Test nghiệp vụ, bảo mật và tải", "Báo cáo kiểm thử", "Tools/NghiemThu_*.ps1, Quản trị → Bảo mật & quyền riêng tư"),
        new(11, "Triển khai", "Máy chủ, tên miền, backup", "Phiên bản production", "Docs/TRIEN_KHAI.md, deploy/, Quản trị → Sao lưu & phục hồi"),
        new(12, "Vận hành", "Giám sát, hỗ trợ, cải tiến", "Quy trình vận hành", "Quản trị → Giám sát hệ thống, Hỗ trợ khách hàng"),
    };

    /// <summary>Thứ tự ưu tiên phát triển cho FoodApp (Route = trang quản trị liên quan, chạm để mở).</summary>
    private static readonly UuTien[] CacUuTien =
    {
        new(1, "Nền tảng Backend và Database", "Hoàn thiện tài khoản, quyền hạn, nhà hàng, món ăn, đơn hàng, tài xế và thanh toán.", "Nền tảng bắt buộc", null),
        new(2, "Luồng đặt hàng và xử lý đơn", "Đảm bảo đơn từ khách hàng đến nhà hàng, sau đó đến tài xế và cập nhật ngược lại.", "Ưu tiên cao nhất", nameof(AdminQuyTrinhPage)),
        new(3, "Hệ thống điều phối tài xế", "Tìm tài xế, gửi lời mời, nhận đơn, xử lý timeout, định vị và theo dõi hành trình.", "Ưu tiên cao nhất", nameof(AdminThongMinhPage)),
        new(4, "Thanh toán và đối soát", "COD, thanh toán online, hoàn tiền, phí giao hàng, hoa hồng và thu nhập.", "", nameof(AdminPayablesPage)),
        new(5, "Quản trị và báo cáo", "Quản lý mọi bộ phận, theo dõi đơn hàng, doanh thu, chi phí và hiệu quả vận hành.", "", nameof(AdminReportsPage)),
        new(6, "Kiểm thử và triển khai", "Chạy thử toàn bộ quy trình trên môi trường staging, xử lý lỗi rồi mới đưa vào hoạt động.", "", nameof(AdminNghiemThuPage)),
    };

    private static readonly VaiTro[] CacVaiTro =

    {
        new("Project Manager", "Quản lý tiến độ và phạm vi"),
        new("Business Analyst", "Phân tích nghiệp vụ"),
        new("UI/UX Designer", "Thiết kế giao diện"),
        new("Backend Developer", "API, SQL và nghiệp vụ"),
        new("Mobile Developer", "App khách hàng và tài xế"),
        new("Web Developer", "Admin và nhà hàng"),
        new("QA/Tester", "Kiểm thử chức năng và hệ thống"),
        new("DevOps", "Máy chủ, triển khai, giám sát"),
        new("Business Operations", "Quy trình giao hàng và hỗ trợ"),
    };

    public AdminLoTrinhPage() : base("Lộ trình & đội ngũ") { }

    private static int Dem(int so)
    {
        try { return Math.Clamp(Preferences.Default.Get($"lotrinh-gd-{so}", 0), 0, 2); } catch { return 0; }
    }

    private static string Nguoi(string vaiTro)
    {
        try { return Preferences.Default.Get($"lotrinh-vt-{vaiTro}", ""); } catch { return ""; }
    }

    private static void Luu(string khoa, int v) { try { Preferences.Default.Set(khoa, v); } catch { } }
    private static void Luu(string khoa, string v) { try { Preferences.Default.Set(khoa, v); } catch { } }

    protected override Task DungAsync()
    {
        var xong = CacGiaiDoan.Count(g => Dem(g.So) == 2);
        var dang = CacGiaiDoan.Count(g => Dem(g.So) == 1);
        Nd.Add(KhoiTheo("Tiến độ dự án",
            DongTrai("Hoàn thành", $"{xong}/{CacGiaiDoan.Length} giai đoạn", AdminUi.Xanh),
            DongTrai("Đang làm", $"{dang} giai đoạn", AdminUi.Tim),
            DongTrai("Tỉ lệ", $"{xong * 100 / CacGiaiDoan.Length}%"),
            AdminUi.Nhan("Không nên phát triển toàn bộ hệ thống cùng lúc: chia giai đoạn để kiểm soát chất lượng và ngân sách. Chạm vào một giai đoạn để đổi trạng thái (lưu trên thiết bị này).", 11.5, mo: true)));

        var uu = new VerticalStackLayout { Spacing = 8 };
        foreach (var u in CacUuTien)
        {
            var it = u;
            var the = AdminUi.The(10);
            var st = new VerticalStackLayout { Spacing = 2 };
            var dau = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 8 };
            dau.Add(AdminUi.Nhan($"{it.So}. {it.Ten}", 13, dam: true), 0, 0);
            if (it.Nhan != "")
            {
                var nhan = AdminUi.Nhan(it.Nhan, 11.5, dam: true);
                nhan.TextColor = Color.FromArgb(it.Nhan.StartsWith("Ưu tiên") ? AdminUi.Do : AdminUi.Tim);
                dau.Add(nhan, 1, 0);
            }
            st.Add(dau);
            st.Add(AdminUi.Nhan(it.MoTa, 12, mo: true));
            if (it.Route != null) st.Add(AdminUi.Nhan("Chạm để mở trang liên quan ›", 11, mo: true));
            the.Content = st;
            if (it.Route != null)
            {
                var tap = new TapGestureRecognizer();
                tap.Tapped += async (_, _) => { try { await Shell.Current.GoToAsync(it.Route); } catch (Exception ex) { CrashLog.Ghi(nameof(AdminLoTrinhPage), ex); } };
                the.GestureRecognizers.Add(tap);
            }
            uu.Add(the);
        }
        Nd.Add(KhoiTheo("Thứ tự ưu tiên phát triển cho FoodApp", uu));

        foreach (var g in CacGiaiDoan)
        {
            var gd = g;
            var tt = Dem(gd.So);
            var the = AdminUi.The(12);
            var st = new VerticalStackLayout { Spacing = 2 };
            var dau = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 8 };
            dau.Add(AdminUi.Nhan($"{gd.So}. {gd.Ten}", 13.5, dam: true), 0, 0);
            var nhan = AdminUi.Nhan(tt == 2 ? "✅ Hoàn thành" : tt == 1 ? "🔧 Đang làm" : "⏳ Chưa bắt đầu", 12, dam: true);
            nhan.TextColor = Color.FromArgb(tt == 2 ? AdminUi.Xanh : tt == 1 ? AdminUi.Tim : AdminUi.Xam);
            dau.Add(nhan, 1, 0);
            st.Add(dau);
            st.Add(AdminUi.Nhan("Công việc: " + gd.CongViec, 12, mo: true));
            st.Add(AdminUi.Nhan("Bàn giao: " + gd.BanGiao, 12, mo: true));
            st.Add(AdminUi.Nhan("Trong hệ thống: " + gd.TrongApp, 11.5, mo: true));
            the.Content = st;
            var tap = new TapGestureRecognizer();
            tap.Tapped += async (_, _) =>
            {
                var c = await DisplayActionSheet($"Giai đoạn {gd.So}: {gd.Ten}", "Hủy", null, TrangThai);
                if (c is null or "Hủy") return;
                Luu($"lotrinh-gd-{gd.So}", Array.IndexOf(TrangThai, c));
                Nd.Children.Clear();
                await DungAsync();
            };
            the.GestureRecognizers.Add(tap);
            Nd.Add(the);
        }

        var vt = new VerticalStackLayout { Spacing = 8 };
        foreach (var v in CacVaiTro)
        {
            var vai = v;
            var the = AdminUi.The(10);
            var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 8 };
            var trai = new VerticalStackLayout { Spacing = 1 };
            trai.Add(AdminUi.Nhan(vai.Ten, 13, dam: true));
            trai.Add(AdminUi.Nhan(vai.TrachNhiem, 11.5, mo: true));
            g.Add(trai, 0, 0);
            var ten = Nguoi(vai.Ten);
            var phai = AdminUi.Nhan(string.IsNullOrWhiteSpace(ten) ? "Chưa phân công  ✎" : ten + "  ✎", 12.5, dam: true);
            phai.TextColor = Color.FromArgb(string.IsNullOrWhiteSpace(ten) ? AdminUi.Do : AdminUi.Tim);
            phai.VerticalOptions = LayoutOptions.Center;
            phai.HorizontalTextAlignment = TextAlignment.End;
            g.Add(phai, 1, 0);
            the.Content = g;
            var tap = new TapGestureRecognizer();
            tap.Tapped += async (_, _) =>
            {
                var moi = await AdminUi.Hoi(this, vai.Ten, "Người chịu trách nhiệm (để trống = chưa phân công)", null, 0, Nguoi(vai.Ten));
                if (moi == null) return;
                Luu($"lotrinh-vt-{vai.Ten}", moi.Trim());
                Nd.Children.Clear();
                await DungAsync();
            };
            the.GestureRecognizers.Add(tap);
            vt.Add(the);
        }
        Nd.Add(KhoiTheo("Đội ngũ thực hiện", vt,
            AdminUi.Nhan("Một nhóm nhỏ có thể kiêm nhiều vai trò, nhưng cần có người chịu trách nhiệm rõ ràng cho từng phần.", 11.5, mo: true)));
        return Task.CompletedTask;
    }
}
