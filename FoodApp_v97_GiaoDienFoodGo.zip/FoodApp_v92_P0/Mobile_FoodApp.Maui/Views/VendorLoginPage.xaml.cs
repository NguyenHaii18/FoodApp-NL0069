using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

public partial class VendorLoginPage : ContentPage
{
    private bool _laNhanVien;

    public VendorLoginPage()
    {
        InitializeComponent();
        GhiNhoDangNhap.Nap("gianhang", EntryEmail, EntryMatKhau, ChkGhiNho);
    }

    private void OnDoiCheDoTapped(object? sender, EventArgs e)
    {
        _laNhanVien = !_laNhanVien;
        EntryEmail.Text = ""; EntryMatKhau.Text = "";
        GhiNhoDangNhap.Nap(_laNhanVien ? "nhanvien" : "gianhang", EntryEmail, EntryMatKhau, ChkGhiNho);
        EntryEmail.Placeholder = _laNhanVien ? "Tên đăng nhập nhân viên (chủ quán cấp)" : "Email đăng ký gian hàng";
        EntryEmail.Keyboard = _laNhanVien ? Keyboard.Default : Keyboard.Email;
        LblCheDo.Text = _laNhanVien ? "← Quay lại đăng nhập chủ quán" : "Bạn là nhân viên cửa hàng? Đăng nhập bằng tài khoản nhân viên";
        BtnDangNhap.Text = _laNhanVien ? "Đăng nhập nhân viên" : "Đăng nhập";
        LblLoi.IsVisible = false;
    }

    private async void OnDangNhapClicked(object sender, EventArgs e)
    {
        LblLoi.IsVisible = false;

        if (_laNhanVien)
        {
            if (string.IsNullOrWhiteSpace(EntryEmail.Text)) { HienLoi("Vui lòng nhập tên đăng nhập nhân viên"); return; }
            if (!DuLieuService.DangOnline) { HienLoi("Tài khoản nhân viên chỉ đăng nhập được khi kết nối máy chủ"); return; }
        }
        else if (string.IsNullOrWhiteSpace(EntryEmail.Text) || !EntryEmail.Text.Contains('@'))
        {
            HienLoi("Email không hợp lệ");
            return;
        }
        if (string.IsNullOrWhiteSpace(EntryMatKhau.Text))
        {
            HienLoi("Vui lòng nhập mật khẩu");
            return;
        }

        LoadingIndicator.IsVisible = true;
        LoadingIndicator.IsRunning = true;
        BtnDangNhap.IsEnabled = false;

        try
        {
            GianHang? gianHang;
            if (DuLieuService.DangOnline)
            {
                var kq = _laNhanVien
                    ? await ApiClient.PostAsync<DangNhapGianHangDto>("api/mobile/gian-hang/nhan-vien/dang-nhap",
                        new { tenDangNhap = EntryEmail.Text.Trim(), matKhau = EntryMatKhau.Text })
                    : await ApiClient.PostAsync<DangNhapGianHangDto>("api/mobile/gian-hang/dang-nhap",
                        new { email = EntryEmail.Text.Trim(), matKhau = EntryMatKhau.Text });
                if (!kq.ThanhCong || kq.DuLieu?.GianHang is null) { HienLoi(kq.ThongDiep); return; }
                ApiClient.Token = kq.DuLieu.Token;
                NhanVienQuan.DatLai();
                if (_laNhanVien && kq.DuLieu.NhanVien is not null) NhanVienQuan.DangNhap(kq.DuLieu.NhanVien);
                gianHang = kq.DuLieu.GianHang;
                var cu = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == gianHang.Id);
                if (cu is not null) MockData.DanhSachGianHang.Remove(cu);
                MockData.DanhSachGianHang.Add(gianHang);
                if (NhanVienQuan.Co(NhanVienQuan.DonHang)) await DuLieuService.TaiDonHangGianHangAsync(gianHang.Id);
            }
            else
            {
                await Task.Delay(300);
                gianHang = MockData.DanhSachGianHang.FirstOrDefault(g =>
                    string.Equals(g.Email, EntryEmail.Text.Trim(), StringComparison.OrdinalIgnoreCase) &&
                    g.MatKhau == EntryMatKhau.Text);
            }

            if (gianHang is null)
            {
                NhatKyService.Ghi("GianHang", EntryEmail.Text.Trim(), "Đăng nhập thất bại", chiTiet: "Sai email hoặc mật khẩu · " + NhatKyService.ThietBi(), thanhCong: false);
                HienLoi("Email hoặc mật khẩu không đúng");
                return;
            }

            if (gianHang.TrangThaiDangKy == TrangThaiDangKyGianHang.ChoDuyet)
            {
                HienLoi("Hồ sơ gian hàng của bạn đang chờ quản trị viên duyệt");
                return;
            }
            if (gianHang.TrangThaiDangKy == TrangThaiDangKyGianHang.TuChoi)
            {
                HienLoi("Hồ sơ gian hàng đã bị từ chối" + (string.IsNullOrWhiteSpace(gianHang.LyDoTuChoi) ? "" : $": {gianHang.LyDoTuChoi}") + ". Vui lòng liên hệ quản trị viên");
                return;
            }
            if (gianHang.TaiKhoanBiKhoa)
            {
                NhatKyService.Ghi("GianHang", gianHang.Email, "Đăng nhập thất bại", chiTiet: "Tài khoản bị khóa · " + NhatKyService.ThietBi(), thanhCong: false);
                HienLoi("Tài khoản gian hàng đang bị khóa. Vui lòng liên hệ quản trị viên");
                return;
            }

            NhatKyService.Ghi("GianHang", gianHang.Email, NhanVienQuan.LaNhanVien ? $"Nhân viên {NhanVienQuan.HoTen} đăng nhập" : "Đăng nhập", gianHang.TenGianHang, NhatKyService.ThietBi());
            MockData.GianHangHienTai = gianHang;
            GhiNhoDangNhap.Luu(_laNhanVien ? "nhanvien" : "gianhang", EntryEmail.Text, EntryMatKhau.Text, ChkGhiNho.IsChecked);
            await Shell.Current.GoToAsync(nameof(VendorHomePage));
        }
        finally
        {
            LoadingIndicator.IsVisible = false;
            LoadingIndicator.IsRunning = false;
            BtnDangNhap.IsEnabled = true;
        }
    }

    private void HienLoi(string thongDiep)
    {
        LblLoi.Text = thongDiep;
        LblLoi.IsVisible = true;
    }

    private async void OnQuenMatKhauTapped(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(QuenMatKhauPage), new Dictionary<string, object> { { "VaiTro", "GianHang" } });
    }

    private async void OnDangKyTapped(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(VendorRegisterPage));
    }

    private async void OnQuayLaiTapped(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("..");
    }
}
