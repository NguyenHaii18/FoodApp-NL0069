using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>"Đơn hàng" của tài xế — dữ liệu thật từ GET api/mobile/tai-xe/don-hang?tab=nhan|dang-giao|hoan-thanh|that-bai.
/// Bộ lọc "Tất cả" gộp 4 nhóm theo ngày đặt mới nhất.</summary>
public partial class DriverMyOrdersPage : ContentPage
{
    private static readonly (string Khoa, string Nhan)[] Loc =
    {
        ("tat-ca", "Tất cả"), ("nhan", "Chờ lấy hàng"), ("dang-giao", "Đang giao"), ("hoan-thanh", "Hoàn thành"), ("that-bai", "Đã hủy"),
    };
    private string _tab = "tat-ca";
    private bool _locNgay, _dangDatNgay;

    public DriverMyOrdersPage()
    {
        InitializeComponent();
        DatLaiNgay();
    }

    private void DatLaiNgay()
    {
        _dangDatNgay = true;
        DpTu.Date = DateTime.Today.AddDays(-7);
        DpDen.Date = DateTime.Today;
        _dangDatNgay = false;
    }

    private async void OnNgayChanged(object? sender, DateChangedEventArgs e)
    {
        if (_dangDatNgay) return;
        _locNgay = true;
        await TaiAsync();
    }

    private async void OnXoaLocClicked(object? sender, EventArgs e)
    {
        _locNgay = false;
        DatLaiNgay();
        await TaiAsync();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await TaiAsync();
    }

    private void VeThanhLoc()
    {
        ThanhLoc.Children.Clear();
        foreach (var (khoa, nhan) in Loc)
        {
            var chon = khoa == _tab;
            var nut = new Button
            {
                Text = nhan, CornerRadius = 17, HeightRequest = 34, Padding = new Thickness(16, 0), FontSize = 12.5, BorderWidth = 0,
                BackgroundColor = chon ? DriverPalette.Get("Primary") : DriverPalette.Get("PrimarySoft"),
                TextColor = chon ? Colors.White : DriverPalette.Get("Primary"),
                FontAttributes = chon ? FontAttributes.Bold : FontAttributes.None,
            };
            nut.Clicked += async (_, _) => { _tab = khoa; await TaiAsync(); };
            ThanhLoc.Children.Add(nut);
        }
        var lo = new Button
        {
            Text = "🧭 Gợi ý lộ trình", CornerRadius = 17, HeightRequest = 34, Padding = new Thickness(16, 0), FontSize = 12.5,
            BackgroundColor = Colors.Transparent, BorderColor = DriverPalette.Get("Primary"), BorderWidth = 1, TextColor = DriverPalette.Get("Primary"),
        };
        lo.Clicked += async (_, _) => await GoiYLoTrinhAsync();
        ThanhLoc.Children.Add(lo);
    }

    /// <summary>Tài xế đang giữ nhiều đơn: sắp thứ tự lấy/giao theo điểm gần nhất (ước tính theo quận/huyện).</summary>
    private async Task GoiYLoTrinhAsync()
    {
        if (!DuLieuService.DangOnline) { await DisplayAlert("Cần kết nối", "Cần kết nối máy chủ để lấy các đơn đang giữ.", "Đóng"); return; }
        var cacDon = new List<DonTaiXeItem>();
        foreach (var nhom in new[] { "nhan", "dang-giao" })
        {
            var r = await ApiClient.GetAsync<List<DonTaiXeItem>>($"api/mobile/tai-xe/don-hang?tab={nhom}");
            if (r.ThanhCong && r.DuLieu is not null) cacDon.AddRange(r.DuLieu);
        }
        if (cacDon.Count < 2) { await DisplayAlert("Chưa cần lộ trình", "Bạn đang giữ ít hơn 2 đơn nên không cần sắp thứ tự.", "Đóng"); return; }

        // 1) Ưu tiên đường THẬT (máy chủ + Goong); 2) không được thì dùng bản ước tính theo quận/huyện bên dưới
        var (that, lyDoLoi) = await LoTrinhThatService.ToiUuAsync(cacDon);
        if (that is not null)
        {
            var kt = new System.Text.StringBuilder();
            for (var i = 0; i < that.Buoc.Count; i++)
            {
                var b = that.Buoc[i];
                kt.AppendLine($"{i + 1}. {(b.Loai == "lay" ? "🏪 Lấy" : "📍 Giao")} đơn #{b.MaDon}\n    {b.DiaChi}" + (b.Km > 0 ? $"  (~{b.Km:0.#} km · {b.Phut} phút)" : ""));
            }
            kt.AppendLine($"\nTổng ≈ {that.TongKm:0.#} km, ~{that.TongPhut} phút di chuyển (đường thật, xe máy).");
            if (that.HeSoKetXe > 1.0001) kt.AppendLine($"Đã tính kẹt xe ×{that.HeSoKetXe:0.##} (không kẹt ~{that.TongPhutKhongKetXe} phút).");
            if (that.KmThuTuGoc is double goc && goc > that.TongKm + 0.05) kt.AppendLine($"Tiết kiệm ≈ {goc - that.TongKm:0.#} km so với thứ tự mặc định.");
            kt.AppendLine("Nguồn: " + that.Nguon + ". Kẹt xe là ước tính theo khung giờ, không phải dữ liệu thời gian thực.");
            var chon = await DisplayAlert("Lộ trình tối ưu (đường thật)", kt.ToString(), "Xem bản đồ", "Đóng");
            if (chon && that.Diem.Count > 0) { LoTrinhBanDoPage.DuLieu = that; await Shell.Current.GoToAsync(nameof(LoTrinhBanDoPage)); }
            return;
        }

        (double, double)? vt = ViTriTaiXeService.ViTriCuoi is { } v ? (v.Lat, v.Lng) : null;
        var (buoc, tongKm, khong) = GiaoHangService.SapXepLoTrinh(cacDon, vt is { } a ? (a.Item1, a.Item2) : null);
        if (buoc.Count == 0) { await DisplayAlert("Không sắp được", "Không nhận ra khu vực từ địa chỉ các đơn.", "Đóng"); return; }
        var sb = new System.Text.StringBuilder();
        for (var i = 0; i < buoc.Count; i++)
            sb.AppendLine($"{i + 1}. {(buoc[i].LaLayHang ? "🏪" : "📍")} {buoc[i].Nhan}\n    {buoc[i].DiaChi}" + (buoc[i].KmTuBuocTruoc > 0 ? $"  (~{buoc[i].KmTuBuocTruoc:0.#} km)" : ""));
        sb.AppendLine($"\nTổng ước tính ~{tongKm:0.#} km.");
        if (khong.Count > 0) sb.AppendLine($"Chưa sắp được đơn: {string.Join(", ", khong.Select(x => "#" + x))} (không nhận ra khu vực).");
        sb.AppendLine("Khoảng cách ước tính theo tâm quận/huyện, chỉ để tham khảo." + (string.IsNullOrEmpty(lyDoLoi) ? "" : $"\n(Chưa dùng được đường thật: {lyDoLoi})"));
        await DisplayAlert("Lộ trình gợi ý", sb.ToString(), "Đóng");
    }

    private async Task TaiAsync()
    {
        VeThanhLoc();
        DsDon.ItemsSource = null;
        LblTrong.IsVisible = false;
        if (!DuLieuService.DangOnline)
        {
            LblTrong.Text = "Đang ở chế độ ngoại tuyến — đăng nhập khi có mạng để xem danh sách đơn từ máy chủ.";
            LblTrong.IsVisible = true;
            return;
        }

        var ds = new List<DonTaiXeItem>();
        var cacNhom = _tab == "tat-ca" ? new[] { "nhan", "dang-giao", "hoan-thanh", "that-bai" } : new[] { _tab };
        string? loi = null;
        foreach (var nhom in cacNhom)
        {
            var r = await ApiClient.GetAsync<List<DonTaiXeItem>>($"api/mobile/tai-xe/don-hang?tab={nhom}");
            if (!r.ThanhCong || r.DuLieu is null) { loi = string.IsNullOrWhiteSpace(r.ThongDiep) ? "Không tải được danh sách đơn." : r.ThongDiep; continue; }
            ds.AddRange(r.DuLieu);
        }
        if (ds.Count == 0 && loi is not null)
        {
            LblTrong.Text = loi;
            LblTrong.IsVisible = true;
            return;
        }

        if (_locNgay) ds = ds.Where(d => d.NgayDat.Date >= DpTu.Date && d.NgayDat.Date <= DpDen.Date).ToList();
        DsDon.ItemsSource = ds.OrderByDescending(d => d.NgayDat).ToList();
        LblTrong.Text = _locNgay ? "Không có đơn nào trong khoảng ngày đã chọn." : _tab switch
        {
            "tat-ca" => "Bạn chưa có đơn nào. Về Trang chủ để nhận đơn mới.",
            "nhan" => "Bạn chưa nhận đơn nào đang chờ lấy hàng.",
            "dang-giao" => "Không có đơn nào đang giao.",
            "hoan-thanh" => "Chưa có đơn hoàn thành.",
            _ => "Không có đơn thất bại hoặc bị hủy."
        };
        LblTrong.IsVisible = ds.Count == 0;
    }

    private async void OnRefreshing(object? sender, EventArgs e)
    {
        await TaiAsync();
        LamMoi.IsRefreshing = false;
    }

    private async void OnDonTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is int ma) await Shell.Current.GoToAsync($"{nameof(DriverOrderDetailPage)}?id={ma}");
    }
}
