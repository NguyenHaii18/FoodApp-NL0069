using System.Globalization;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// v94 — Kiểm thử bản đồ & phí giao (quản trị). Gọi MÁY CHỦ THẬT để đo những thứ không thể kiểm bằng mắt:
/// khóa Goong còn placeholder không (mục 49), geocoding địa chỉ thật (50), quãng đường/ETA thật so với ước tính (51–52),
/// phí giao ước tính cục bộ so với phí máy chủ (53), đường không tìm được (54) và hướng dẫn kiểm thử đồng bộ vị trí 2 thiết bị (55).
/// Chỉ ĐỌC/đo, không sửa dữ liệu. Cần đăng nhập quản trị và máy chủ đang chạy.
/// </summary>
public sealed class AdminKiemTraBanDoPage : AdminKyThuatTrang
{
    public AdminKiemTraBanDoPage() : base("Kiểm thử bản đồ & phí giao") { }

    private static readonly string[] DiaChiMau =
    {
        "Chợ Bến Thành, Lê Lợi, Quận 1",
        "Nhà thờ Đức Bà, 01 Công xã Paris, Quận 1",
        "Bệnh viện Chợ Rẫy, 201B Nguyễn Chí Thanh, Quận 5",
        "Trường Đại học Công Thương TP.HCM, 140 Lê Trọng Tấn, Tân Phú",
        "Sân bay Tân Sơn Nhất, Trường Sơn, Tân Bình",
        "Landmark 81, 720A Điện Biên Phủ, Bình Thạnh",
        "Crescent Mall, 101 Tôn Dật Tiên, Quận 7",
        "Công viên Gia Định, Hoàng Minh Giám, Phú Nhuận",
        "Đầm Sen, 3 Hòa Bình, Quận 11",
        "Khu du lịch Suối Tiên, Xa lộ Hà Nội, Thủ Đức",
    };

    /// <summary>Địa chỉ cố ý sai: kiểm thử nhánh "không tìm được" (đạt khi hệ thống báo không tìm thấy, không đoán bừa).</summary>
    private const string DiaChiSai = "999 Đường Không Có Thật Xyz, Quận 1";

    private static readonly (int Lay, int Giao)[] CapMau = { (0, 1), (3, 4), (6, 5), (8, 2), (9, 7), (0, 9) };

    private static string Ngan(string s) => s.Split(',')[0].Trim();
    private static string Co(double v) => v.ToString("0.0000", CultureInfo.InvariantCulture);

    protected override async Task DungAsync()
    {
        Nd.Add(AdminUi.Nhan("Màn hình này gọi máy chủ thật để đo độ chính xác của bản đồ và phí giao. Nguyên tắc: phí ước tính theo quận/huyện chỉ để hiển thị tạm, " +
            "KHÔNG dùng làm căn cứ thu tiền — phí chính thức luôn do máy chủ tính theo quãng đường thật.", 12, mo: true));

        // ------------------------------------------------ 49: khóa Goong
        var r = await GoongKhoaService.XemAsync();
        if (!r.ThanhCong || r.DuLieu is null)
            Nd.Add(KhoiTheo("1) Khóa Goong", DongKiemTra(false, "Không đọc được trạng thái khóa",
                r.MaHttp == 403 ? "Chỉ Admin tổng được xem trạng thái khóa bản đồ." : r.ThongDiep, canhBao: true)));
        else
        {
            var t = r.DuLieu;
            var thuKhoa = AdminUi.Nut("Thử khóa đang dùng (gọi Goong thật)", AdminUi.Xanh);
            thuKhoa.Clicked += async (_, _) =>
            {
                thuKhoa.IsEnabled = false;
                try { var (ok, tb) = await GoongKhoaService.KiemTraAsync(); await DisplayAlert(ok ? "Khóa hoạt động" : "Chưa dùng được", tb, "Đóng"); }
                finally { thuKhoa.IsEnabled = true; }
            };
            var moTrang = AdminUi.Nut("Nhập / đổi khóa", AdminUi.Tim);
            moTrang.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(AdminGoongPage));
            Nd.Add(KhoiTheo("1) Khóa Goong",
                DongKiemTra(t.DaCauHinh, t.DaCauHinh ? "Đã có khóa Goong hợp lệ" : "Khóa Goong còn là placeholder / chưa nhập",
                    t.DaCauHinh ? $"Khóa: {t.KhoaDaAn} · nguồn: {t.Nguon}"
                                : "Chưa có khóa thì không có geocoding Goong, đường thật và phí theo tuyến: máy chủ dùng phí mặc định, app dùng bản ước tính."),
                thuKhoa, moTrang));
        }

        // ------------------------------------------------ 50: geocoding
        var kqGeo = new VerticalStackLayout { Spacing = 6 };
        var tienDoGeo = AdminUi.Nhan("", 11.5, mo: true);
        var oTuy = new Entry { Placeholder = "Thêm địa chỉ thật của bạn để thử (tùy chọn)", FontSize = 13, ClearButtonVisibility = ClearButtonVisibility.WhileEditing };
        var chayGeo = AdminUi.Nut("Chạy kiểm thử geocoding (11 địa chỉ)", AdminUi.Tim, day: true);
        chayGeo.Clicked += async (_, _) =>
        {
            chayGeo.IsEnabled = false; kqGeo.Children.Clear();
            try
            {
                var ds = DiaChiMau.Append(DiaChiSai).ToList();
                if (!string.IsNullOrWhiteSpace(oTuy.Text)) ds.Add(oTuy.Text.Trim());
                int dat = 0, tong = 0;
                foreach (var dc in ds)
                {
                    tienDoGeo.Text = $"Đang thử {++tong}/{ds.Count}: {Ngan(dc)}…";
                    var g = await DiaChiToaDoService.TimAsync(dc, chiGoong: true);
                    var o = await DiaChiToaDoService.TimAsync(dc, chiOsm: true);
                    var laSai = dc == DiaChiSai;
                    string mo; bool ok, canh = false;
                    if (laSai)
                    {
                        ok = !g.TimThay && !o.TimThay;
                        mo = ok ? "Đúng: cả hai nguồn đều báo không tìm thấy (không đoán bừa)."
                                : $"Sai: địa chỉ không có thật nhưng vẫn ra tọa độ ({(g.TimThay ? "Goong " + Co(g.Lat) + "," + Co(g.Lng) : "OSM " + Co(o.Lat) + "," + Co(o.Lng))}) — cần xác nhận lại địa chỉ với khách.";
                    }
                    else if (g.TimThay && o.TimThay)
                    {
                        var lech = GiaoHangService.KmChimBay(g.Lat, g.Lng, o.Lat, o.Lng);
                        ok = lech < 1.0; canh = !ok;
                        mo = $"Goong {Co(g.Lat)},{Co(g.Lng)} · OSM {Co(o.Lat)},{Co(o.Lng)} · lệch {lech:0.00} km" + (ok ? "" : " (> 1 km: nên kiểm tra tay)");
                    }
                    else if (g.TimThay) { ok = true; mo = $"Goong {Co(g.Lat)},{Co(g.Lng)} · OSM không tìm thấy ({o.LyDo})"; }
                    else if (o.TimThay) { ok = false; canh = true; mo = $"Goong KHÔNG tìm thấy ({g.LyDo}) · OSM {Co(o.Lat)},{Co(o.Lng)} — phí/đường thật sẽ không chạy cho địa chỉ này"; }
                    else { ok = false; mo = $"Cả hai không tìm thấy. Goong: {g.LyDo} · OSM: {o.LyDo}"; }
                    if (ok) dat++;
                    kqGeo.Children.Add(DongKiemTra(ok, laSai ? "Địa chỉ cố ý sai" : Ngan(dc), mo, canh));
                }
                tienDoGeo.Text = $"Xong: {dat}/{tong} đạt. Địa chỉ nào ❌/⚠️ thì khách nhập kiểu đó sẽ khó tính phí chính xác — nên yêu cầu chọn địa chỉ trên bản đồ.";
            }
            catch (Exception ex) { CrashLog.Ghi("KiemTraBanDo.Geocode", ex); tienDoGeo.Text = "Lỗi: " + ex.Message; }
            finally { chayGeo.IsEnabled = true; }
        };
        Nd.Add(KhoiTheo("2) Tìm địa chỉ (geocoding) với địa chỉ thật", oTuy, chayGeo, tienDoGeo, kqGeo));

        // ------------------------------------------------ 51–54: quãng đường, ETA, phí, đường thay thế
        var kqTuyen = new VerticalStackLayout { Spacing = 6 };
        var tienDoTuyen = AdminUi.Nhan("", 11.5, mo: true);
        var chayTuyen = AdminUi.Nut("Đo quãng đường, ETA và so phí (6 tuyến)", AdminUi.Tim, day: true);
        chayTuyen.Clicked += async (_, _) =>
        {
            chayTuyen.IsEnabled = false; kqTuyen.Children.Clear();
            try
            {
                PhiGiaoXacMinhService.XoaNho(); DuongDiService.XoaCache();
                var tiLe = new List<double>(); int soThat = 0, tong = 0;
                foreach (var (iLay, iGiao) in CapMau)
                {
                    var lay = DiaChiMau[iLay]; var giao = DiaChiMau[iGiao];
                    tienDoTuyen.Text = $"Đang đo {++tong}/{CapMau.Length}: {Ngan(lay)} → {Ngan(giao)}…";
                    var uoc = GiaoHangService.UocTinh(lay, giao);
                    var (v, lyDoPhi) = await PhiGiaoXacMinhService.LayAsync(lay, giao, true);
                    var a = await DiaChiToaDoService.TimAsync(lay, chiGoong: true);
                    var b = await DiaChiToaDoService.TimAsync(giao, chiGoong: true);
                    KqDuongDi? d = a.TimThay && b.TimThay ? await DuongDiService.LayChiTietAsync(a.Lat, a.Lng, b.Lat, b.Lng, true) : null;

                    var dong = new List<string>
                    {
                        uoc.DaXacDinh ? $"Ước tính cục bộ: {uoc.Km:0.#} km · ~{uoc.Phut} ph · {uoc.Phi:N0}đ" : $"Ước tính cục bộ: không nhận ra khu vực · {uoc.Phi:N0}đ (phí cơ bản)",
                    };
                    bool dat = false, canh = false;
                    if (v is null) dong.Add("Máy chủ: " + lyDoPhi);
                    else if (!v.DaXacMinh) { dong.Add($"Máy chủ: CHƯA đo được tuyến thật → phí mặc định {v.PhiGiaoHang:N0}đ ({v.GhiChu})"); canh = true; }
                    else
                    {
                        soThat++; dat = true;
                        dong.Add($"Máy chủ (tuyến thật): {v.KhoangCachKm:0.#} km · ~{v.ThoiGianDuKienPhut} ph · {v.PhiGiaoHang:N0}đ");
                        if (uoc.DaXacDinh && uoc.Km > 0)
                        {
                            var tl = v.KhoangCachKm / uoc.Km; tiLe.Add(tl);
                            var chenh = v.PhiGiaoHang - uoc.Phi;
                            dong.Add($"Khoảng cách thật/ước tính = {tl:0.00}× · phí chênh {(chenh >= 0 ? "+" : "")}{chenh:N0}đ");
                            if (Math.Abs(chenh) >= 10000) { canh = true; dat = false; dong.Add("→ Chênh ≥ 10.000đ: phí ước tính không đủ tin cậy để thu tiền."); }
                        }
                    }
                    if (d is null) dong.Add("Đường đi: không lấy được tọa độ hai đầu nên chưa thử.");
                    else if (d.CoDuongThat) dong.Add($"Đường đi thật: {d.Duong!.Km:0.#} km · ~{d.Duong.Phut} ph ({d.Duong.KhungGio.ToLowerInvariant()} ×{d.Duong.HeSoKetXe:0.##}) — ETA chỉ theo giờ, chưa phải kẹt xe trực tiếp");
                    else { dong.Add($"Đường đi: KHÔNG có tuyến thật ({d.ThongDiep}) → app sẽ hiện đường thẳng ~{d.KmUocTinh:0.#} km kèm cảnh báo"); canh = true; dat = false; }
                    kqTuyen.Children.Add(DongKiemTra(dat, $"{Ngan(lay)} → {Ngan(giao)}", string.Join("\n", dong), canh));
                }
                var tom = $"Xong: {soThat}/{tong} tuyến đo được bằng tuyến đường thật.";
                if (tiLe.Count >= 3)
                {
                    var tb = tiLe.Average();
                    var heSo = GiaoHangService.HeSoDuongBo * tb;
                    tom += $"\nTrung bình khoảng cách thật = {tb:0.00}× ước tính. " + (Math.Abs(tb - 1) <= 0.15
                        ? "Ước tính khá sát (±15%), nhưng vẫn không dùng làm căn cứ thu."
                        : $"Ước tính lệch đáng kể; nếu muốn bản ước tính sát hơn có thể đổi GiaoHangService.HeSoDuongBo từ {GiaoHangService.HeSoDuongBo:0.00} lên khoảng {heSo:0.00}.");
                }
                else if (soThat == 0) tom += "\nChưa có tuyến nào đo được: kiểm tra khóa Goong (mục 1) và mạng của máy chủ.";
                tienDoTuyen.Text = tom;
            }
            catch (Exception ex) { CrashLog.Ghi("KiemTraBanDo.Tuyen", ex); tienDoTuyen.Text = "Lỗi: " + ex.Message; }
            finally { chayTuyen.IsEnabled = true; }
        };
        Nd.Add(KhoiTheo("3) Quãng đường, ETA, phí giao và đường không tìm được", 
            AdminUi.Nhan("Với mỗi tuyến: so ước tính cục bộ (tâm quận × 1,25) với phí do máy chủ tính theo quãng đường thật và với đường đi Goong. " +
                         "Tuyến nào Goong không tìm được đường sẽ hiện ⚠️ — đúng tình huống đường bị chặn / ngoài vùng mà app phải xử lý.", 11.5, mo: true),
            chayTuyen, tienDoTuyen, kqTuyen));

        // ------------------------------------------------ 55: đồng bộ vị trí
        var vt = ViTriTaiXeService.ViTriCuoi;
        Nd.Add(KhoiTheo("4) Theo dõi hành trình (đồng bộ vị trí tài xế ↔ bản đồ khách)",
            DongKiemTra(vt is not null, vt is { } p ? $"Máy này có GPS: {Co(p.Lat)}, {Co(p.Lng)}" : "Máy này chưa có vị trí GPS",
                vt is null ? "Đăng nhập tài xế trên máy này và bật \"📡 Chia sẻ vị trí\" để thử." : "Có thể dùng máy này làm máy tài xế khi kiểm thử.", canhBao: vt is null),
            AdminUi.Nhan("Kiểm thử bằng 2 thiết bị thật (không mô phỏng được):\n" +
                "1. Máy A: khách đặt 1 đơn gần chỗ bạn đang đứng; máy B: tài xế nhận đơn, bật Chia sẻ vị trí.\n" +
                "2. Máy A mở Đơn hàng → 🗺 Theo dõi trên bản đồ. Điểm 🛵 phải trùng vị trí máy B (sai số GPS ~10–30 m).\n" +
                "3. Đi bộ/đi xe ~200 m: điểm 🛵 phải di chuyển, dòng \"Vị trí tài xế cập nhật … giây trước\" luôn dưới ~30 giây, " +
                "và có ít nhất 2–4 lần thay đổi trong 1 phút.\n" +
                "4. Tắt GPS/mạng của máy B ~2 phút: máy A phải báo \"⚠ Mất tín hiệu GPS của tài xế\", bật lại thì tự khỏi.\n" +
                "5. Đưa máy B vào hẻm/đường cụt hoặc đổi địa chỉ giao sang nơi Goong không có đường: máy A phải hiện cảnh báo \"Không tìm được tuyến đường\" + nút Tìm lại / Mở Google Maps.", 11.5, mo: true)));

        Nd.Add(AdminUi.Nhan("Kết quả đo chỉ đúng tại thời điểm chạy (giao thông, dữ liệu Goong, khóa API thay đổi). Hãy chạy lại trước buổi nghiệm thu/demo.", 11, mo: true));
    }
}
