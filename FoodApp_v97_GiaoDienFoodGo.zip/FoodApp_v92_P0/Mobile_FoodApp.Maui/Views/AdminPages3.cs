using System.Text.Json;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

// =====================================================================================================================
// SỰ CỐ TÀI XẾ — tài xế báo (kể cả sai lệch thu nhập / COD); quản trị chuyển "đang xử lý" hoặc đóng kèm kết quả
// =====================================================================================================================
public sealed class AdminDriverIssuesPage : AdminListPage
{
    public AdminDriverIssuesPage() : base(Cfg()) { }

    private static (string nhan, string mau) TT(string ma) => ma switch
    {
        "ChoXuLy" => ("Chờ xử lý", AdminUi.Cam), "DangXuLy" => ("Đang xử lý", AdminUi.Tim), "DaXuLy" => ("Đã xử lý", AdminUi.Xanh), _ => (ma, AdminUi.Xam)
    };

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Sự cố tài xế",
        Tab = new[] { "Chờ xử lý", "Đang xử lý", "Đã xử lý", "Tất cả" },
        Url = (tab, _, _) => "api/mobile/admin/su-co-tai-xe" + (tab switch { 0 => "?trangThai=ChoXuLy", 1 => "?trangThai=DangXuLy", 2 => "?trangThai=DaXuLy", _ => "" }),
        Dong = (_, d) =>
        {
            var (nhan, mau) = TT(J.S(d, "trangThai"));
            var dong = new List<string>
            {
                $"🛵 {J.S(d, "taiXe", "(tài xế)")}" + (J.Rong(d, "maDonHang") ? "" : $" · đơn #{J.S(d, "maDonHang")}"),
                J.S(d, "moTa"),
                $"🕒 {J.Ngay(d, "ngayTao")}",
            };
            if (!J.Rong(d, "phanHoiQuanTri")) dong.Add($"💬 Phản hồi: {J.S(d, "phanHoiQuanTri")}");
            return new AdminDong($"Sự cố #{J.S(d, "maSuCo")} · {J.S(d, "loai")}", dong.ToArray(), nhan, mau);
        },
        HanhDong = _ => new[]
        {
            new AdminHanhDong("Đang xử lý", AdminUi.Tim, d => J.S(d, "trangThai") == "ChoXuLy", async (p, d) =>
            {
                var ghiChu = await AdminUi.Hoi(p, "Chuyển sang đang xử lý", "Ghi chú gửi tài xế (có thể bỏ trống).", null, 0);
                if (ghiChu == null) return;
                await AdminUi.Put(p, $"api/mobile/admin/su-co-tai-xe/{J.S(d, "maSuCo")}/xu-ly", new { trangThai = "DangXuLy", phanHoi = ghiChu }, "Chuyển sự cố tài xế sang đang xử lý", $"#{J.S(d, "maSuCo")}");
            }),
            new AdminHanhDong("Đóng sự cố", AdminUi.Xanh, d => J.S(d, "trangThai") != "DaXuLy", async (p, d) =>
            {
                var ketQua = await AdminUi.Hoi(p, "Kết quả giải quyết", "Bắt buộc nhập kết quả / lý do giải quyết (tài xế sẽ nhận thông báo).", null, 3, J.S(d, "phanHoiQuanTri"));
                if (ketQua == null) return;
                await AdminUi.Put(p, $"api/mobile/admin/su-co-tai-xe/{J.S(d, "maSuCo")}/xu-ly", new { trangThai = "DaXuLy", phanHoi = ketQua }, "Đóng sự cố tài xế", $"#{J.S(d, "maSuCo")}");
            }),
        },
    };
}

// =====================================================================================================================
// GỬI THÔNG BÁO HỆ THỐNG — toàn hệ thống, theo vai trò, hoặc theo nhóm tên đăng nhập; xem 20 thông báo gần nhất
// =====================================================================================================================
public sealed class AdminNotifyPage : AdminListPage
{
    public AdminNotifyPage() : base(Cfg()) { }

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Gửi thông báo",
        Url = (_, _, _) => "api/mobile/admin/thong-bao/gan-day",
        Dong = (_, d) => new AdminDong(J.S(d, "tieuDe"), new[] { J.S(d, "noiDung"), $"🕒 {J.Ngay(d, "ngay")} · đã gửi {J.L(d, "soNguoi")} tài khoản" }),
        HanhDongChung = _ => new[]
        {
            new AdminHanhDong("✉ Soạn thông báo mới", AdminUi.Tim, null, async (p, _) => await SoanAsync(p)),
        },
    };

    // Nhóm người nhận: (mã gửi lên máy chủ, nhãn hiển thị). Nhóm hành vi do máy chủ tính từ dữ liệu thật (đơn hàng, ngày tạo tài khoản, trạng thái).
    private static readonly (string Ma, string Nhan)[] NhomKhach =
    {
        ("KhachHang", "Mọi khách hàng"), ("KhachMoi30", "Khách mới (30 ngày)"), ("KhachDatGanDay30", "Khách đã đặt trong 30 ngày"),
        ("KhachLauChuaDat60", "Khách lâu chưa đặt (≥ 60 ngày)"), ("KhachChuaTungDat", "Khách chưa từng đặt"), ("KhachThanThiet5", "Khách thân thiết (≥ 5 đơn)"),
    };
    private static readonly (string Ma, string Nhan)[] NhomQuan = { ("GianHang", "Mọi gian hàng"), ("QuanDangMo", "Quán đang mở cửa"), ("QuanKhongDon30", "Quán không có đơn 30 ngày") };
    private static readonly (string Ma, string Nhan)[] NhomTaiXe = { ("TaiXe", "Mọi tài xế"), ("TaiXeSanSang", "Tài xế đang sẵn sàng"), ("TaiXeDangGiao", "Tài xế đang giao đơn") };

    private static async Task<(string Ma, string Nhan)?> ChonNhomAsync(AdminListPage p, string tieuDe, (string Ma, string Nhan)[] ds)
    {
        var chon = await p.DisplayActionSheet(tieuDe, "Hủy", null, ds.Select(x => x.Nhan).ToArray());
        if (chon is null or "Hủy") return null;
        return ds.First(x => x.Nhan == chon);
    }

    private static async Task SoanAsync(AdminListPage p)
    {
        var chon = await p.DisplayActionSheet("Gửi tới", "Hủy", null, "Tất cả tài khoản", "Khách hàng…", "Gian hàng…", "Tài xế…", "Danh sách tên đăng nhập");
        if (chon is null or "Hủy") return;
        string doiTuong, nhan;
        string? ds = null;
        switch (chon)
        {
            case "Tất cả tài khoản": doiTuong = "TatCa"; nhan = chon; break;
            case "Khách hàng…": { var g = await ChonNhomAsync(p, "Nhóm khách hàng", NhomKhach); if (g == null) return; (doiTuong, nhan) = g.Value; break; }
            case "Gian hàng…": { var g = await ChonNhomAsync(p, "Nhóm gian hàng", NhomQuan); if (g == null) return; (doiTuong, nhan) = g.Value; break; }
            case "Tài xế…": { var g = await ChonNhomAsync(p, "Nhóm tài xế", NhomTaiXe); if (g == null) return; (doiTuong, nhan) = g.Value; break; }
            default:
                doiTuong = "Nhom"; nhan = "Danh sách tên đăng nhập";
                ds = await AdminUi.Hoi(p, "Nhóm tài khoản", "Nhập các tên đăng nhập, cách nhau bằng dấu phẩy hoặc xuống dòng (tối đa 500).", null, 1);
                if (ds == null) return;
                break;
        }

        // Xem trước số người nhận để không gửi nhầm nhóm (máy chủ tính theo dữ liệu hiện tại).
        // Máy chủ CŨ chưa có API xem trước: các nhóm cũ (tất cả / theo vai trò / danh sách tên) vẫn gửi được như trước, chỉ không hiện số người;
        // các nhóm theo hành vi cần máy chủ mới nên được chặn kèm hướng dẫn.
        var nhomCu = new[] { "TatCa", "KhachHang", "GianHang", "TaiXe", "Nhom" };
        var xt = await ApiClient.PostAsync<System.Text.Json.JsonElement>("api/mobile/admin/thong-bao/xem-truoc", new { doiTuong, dsTaiKhoan = ds });
        var so = -1;
        var mau = "";
        if (xt.ThanhCong)
        {
            so = (int)J.L(xt.DuLieu, "soNguoi");
            if (so == 0) { await p.DisplayAlert("Nhóm trống", $"Hiện không có tài khoản nào thuộc nhóm \"{nhan}\".", "Đóng"); return; }
            mau = string.Join(", ", J.Mang(xt.DuLieu, "mau").Select(x => x.GetString() ?? ""));
        }
        else if (!nhomCu.Contains(doiTuong))
        {
            await p.DisplayAlert("Chưa dùng được nhóm này", $"Máy chủ chưa hỗ trợ nhóm theo hành vi hoặc không xem trước được: {xt.ThongDiep}\nHãy cập nhật máy chủ (API admin/thong-bao/xem-truoc).", "Đóng");
            return;
        }

        var tieuDe = await AdminUi.Hoi(p, "Tiêu đề", "Tiêu đề thông báo (tối thiểu 3 ký tự).", null, 3);
        if (tieuDe == null) return;
        var noiDung = await AdminUi.Hoi(p, "Nội dung", "Nội dung thông báo (tối thiểu 3 ký tự).", null, 3);
        if (noiDung == null) return;
        var dich = so >= 0 ? $"{so} tài khoản — {nhan}" + (mau == "" ? "" : $"\n(vd: {mau}…)") : $"nhóm \"{nhan}\" (không xem trước được số người nhận)";
        if (!await p.DisplayAlert("Xác nhận gửi", $"Gửi \"{tieuDe}\" tới {dich}\nThông báo không thu hồi được.", "Gửi", "Hủy")) return;
        await AdminUi.Post(p, "api/mobile/admin/thong-bao", new { doiTuong, dsTaiKhoan = ds, tieuDe, noiDung }, "Gửi thông báo hệ thống", so >= 0 ? $"{tieuDe} → {nhan} ({so})" : $"{tieuDe} → {nhan}");
    }
}
