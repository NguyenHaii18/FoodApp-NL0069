using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Hiệu suất tài xế: số đơn, tỷ lệ giao thành công, đánh giá trung bình, thời gian giao trung bình — theo 7 ngày / 30 ngày / tất cả.</summary>
public sealed class DriverPerformancePage : ContentPage
{
    private int _ngay = 7;     // 0 = tất cả
    private readonly HorizontalStackLayout _loc = new() { Spacing = 8, Padding = new Thickness(16, 10, 16, 0) };
    private readonly VerticalStackLayout _nd = new() { Spacing = 10, Padding = new Thickness(16, 10, 16, 28) };

    public DriverPerformancePage()
    {
        Title = "Hiệu suất của tôi";
        BackgroundColor = DriverPalette.Get("Background");
        Content = new ScrollView { Content = new VerticalStackLayout { Children = { _loc, _nd } } };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await DuLieuService.TaiDonDaGiaoTaiXeAsync();
        var thatBaiServer = new HashSet<string>();
        if (DuLieuService.DangOnline)
        {
            var r = await ApiClient.GetAsync<List<DonTaiXeItem>>("api/mobile/tai-xe/don-hang?tab=that-bai");
            if (r.ThanhCong && r.DuLieu is not null)
                foreach (var d in r.DuLieu) if (d.NgayDat >= Moc()) thatBaiServer.Add(d.MaDonHang.ToString());
        }
        Ve(thatBaiServer);
    }

    private DateTime Moc() => _ngay == 0 ? DateTime.MinValue : DateTime.Today.AddDays(-(_ngay - 1));

    private void VeLoc()
    {
        _loc.Children.Clear();
        foreach (var (n, nhan) in new[] { (7, "7 ngày"), (30, "30 ngày"), (0, "Tất cả") })
        {
            var chon = n == _ngay;
            var nut = new Button
            {
                Text = nhan, CornerRadius = 17, HeightRequest = 34, Padding = new Thickness(16, 0), FontSize = 12.5,
                BackgroundColor = chon ? DriverPalette.Get("Primary") : DriverPalette.Get("PrimarySoft"),
                TextColor = chon ? Colors.White : DriverPalette.Get("Primary"),
            };
            nut.Clicked += async (_, _) => { _ngay = n; OnAppearing(); await Task.CompletedTask; };
            _loc.Children.Add(nut);
        }
    }

    private static Border The(string nhan, string giaTri, string ghiChu = "")
    {
        var st = new VerticalStackLayout { Spacing = 2 };
        st.Children.Add(new Label { Text = nhan, FontSize = 12, TextColor = DriverPalette.Get("TextGrey") });
        st.Children.Add(new Label { Text = giaTri, FontSize = 22, FontAttributes = FontAttributes.Bold, TextColor = DriverPalette.Get("Primary") });
        if (ghiChu != "") st.Children.Add(new Label { Text = ghiChu, FontSize = 11.5, TextColor = DriverPalette.Get("TextGrey") });
        return new Border
        {
            Padding = 14, StrokeThickness = 1, Stroke = DriverPalette.Get("BorderColor"),
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(14) }, Content = st,
        };
    }

    private void Ve(HashSet<string> thatBaiServer)
    {
        VeLoc();
        _nd.Children.Clear();
        var moc = Moc();
        var ds = MockData.DonHangDaGiaoCuaTaiXe.Where(d => (d.GiaoLuc ?? d.NgayDat) >= moc).ToList();
        var thanhCong = ds.Where(d => !d.GiaoThatBai).ToList();
        var thatBai = ds.Where(d => d.GiaoThatBai).Select(d => d.Id).Concat(thatBaiServer).Distinct().Count();
        var tong = thanhCong.Count + thatBai;

        var tyLe = tong == 0 ? "—" : $"{100.0 * thanhCong.Count / tong:0.#}%";
        var diem = thanhCong.Where(d => d.DiemTaiXe > 0).Select(d => (double)d.DiemTaiXe).ToList();
        var thoiGian = thanhCong
            .Where(d => d.GiaoLuc is not null && (d.LayHangLuc ?? d.NgayDat) < d.GiaoLuc)
            .Select(d => (d.GiaoLuc!.Value - (d.LayHangLuc ?? d.NgayDat)).TotalMinutes)
            .Where(m => m is > 0 and < 240).ToList();

        var luoi = new Grid { ColumnSpacing = 10, RowSpacing = 10, ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) } };
        luoi.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        luoi.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        luoi.Add(The("Số đơn đã giao", thanhCong.Count.ToString(), $"{thatBai} đơn không thành công"), 0, 0);
        luoi.Add(The("Tỷ lệ giao thành công", tyLe, tong == 0 ? "Chưa có đơn trong kỳ" : $"{thanhCong.Count}/{tong} đơn"), 1, 0);
        luoi.Add(The("Đánh giá trung bình", diem.Count == 0 ? "—" : $"{diem.Average():0.0} ★", diem.Count == 0 ? "Chưa có đánh giá" : $"{diem.Count} lượt"), 0, 1);
        luoi.Add(The("Thời gian giao TB", thoiGian.Count == 0 ? "—" : $"{thoiGian.Average():0} phút", "Từ lúc lấy hàng đến lúc giao xong"), 1, 1);
        luoi.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        luoi.Add(The("Số đơn đã nhận", tong.ToString(), "Gồm đơn giao thành công và không thành công"), 0, 2);
        luoi.Add(The("Số đơn hoàn thành", thanhCong.Count.ToString(), tong == 0 ? "" : $"{100.0 * thanhCong.Count / tong:0.#}% số đơn đã nhận"), 1, 2);
        luoi.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        luoi.Add(The("Tỷ lệ hủy / không thành công", tong == 0 ? "—" : $"{100.0 * thatBai / tong:0.#}%", tong == 0 ? "Chưa có đơn trong kỳ" : $"{thatBai}/{tong} đơn đã nhận"), 0, 3);
        luoi.Add(The("Tỷ lệ hoàn thành", tyLe, tong == 0 ? "" : "Giao thành công / đơn đã nhận"), 1, 3);
        _nd.Children.Add(luoi);

        // ---- Cảnh báo / lưu ý (tính từ số liệu của chính tài xế; cảnh báo chính thức của quản trị nằm ở mục Thông báo)
        var canhBao = new List<string>();
        if (tong >= 5 && 100.0 * thanhCong.Count / tong < 80) canhBao.Add($"Tỷ lệ giao thành công {tyLe} thấp hơn mức khuyến nghị 80%.");
        if (thatBai >= 3) canhBao.Add($"Có {thatBai} đơn giao không thành công trong kỳ này — hãy xem lại lý do ở Lịch sử.");
        if (diem.Count >= 3 && diem.Average() < 4.0) canhBao.Add($"Điểm đánh giá trung bình {diem.Average():0.0}★ thấp hơn 4.0★.");
        if (thoiGian.Count >= 3 && thoiGian.Average() > 45) canhBao.Add($"Thời gian giao trung bình {thoiGian.Average():0} phút khá dài.");
        _nd.Children.Add(new Label { Text = "⚠️ Cảnh báo & lưu ý", FontAttributes = FontAttributes.Bold, FontSize = 15 });
        _nd.Children.Add(new Label
        {
            Text = canhBao.Count == 0 ? "✅ Không có cảnh báo nào trong kỳ này. Cảnh báo / vi phạm do quản trị gửi sẽ hiện ở mục Thông báo." : string.Join("\n", canhBao.Select(x => "• " + x)),
            FontSize = 12.5, TextColor = canhBao.Count == 0 ? Colors.SeaGreen : Colors.DarkOrange,
        });

        // ---- Lịch sử hoạt động gần đây
        _nd.Children.Add(new Label { Text = "🕘 Hoạt động gần đây", FontAttributes = FontAttributes.Bold, FontSize = 15, Margin = new Thickness(0, 6, 0, 0) });
        var gan = ds.OrderByDescending(d => d.GiaoLuc ?? d.NgayDat).Take(10).ToList();
        if (gan.Count == 0) _nd.Children.Add(new Label { Text = "Chưa có hoạt động trong kỳ này.", FontSize = 12.5, TextColor = DriverPalette.Get("TextGrey") });
        foreach (var d in gan)
            _nd.Children.Add(new Label
            {
                Text = $"{(d.GiaoLuc ?? d.NgayDat):dd/MM HH:mm} · Đơn #{d.Id} · {d.TenGianHang} · " + (d.GiaoThatBai ? "❌ không thành công" : $"✅ +{d.PhiGiaoHang + d.PhuCap:N0}đ"),
                FontSize = 12.5,
            });

        var khieuNai = new Button { Text = "💬 Gửi phản hồi / khiếu nại", CornerRadius = 12, HeightRequest = 44, Margin = new Thickness(0, 8, 0, 0), BackgroundColor = DriverPalette.Get("PrimarySoft"), TextColor = DriverPalette.Get("Primary") };
        khieuNai.Clicked += async (_, _) => await Shell.Current.GoToAsync($"{nameof(DriverSuCoPage)}?loai=Khac");
        _nd.Children.Add(khieuNai);

        _nd.Children.Add(new Label
        {
            Text = "Số liệu tính từ các đơn trong kỳ đã chọn. Điểm toàn thời gian: " +
                   (MockData.TaiXeHienTai.DanhGia > 0 ? $"{MockData.TaiXeHienTai.DanhGia:0.0} ★." : "chưa có."),
            FontSize = 11.5, TextColor = DriverPalette.Get("TextGrey"),
        });
    }
}
