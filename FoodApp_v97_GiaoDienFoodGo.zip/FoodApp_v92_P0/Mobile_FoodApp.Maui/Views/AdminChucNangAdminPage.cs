namespace FoodApp.Maui.Views;

/// <summary>
/// Checklist chức năng Admin (mục 8–11: Khuyến mãi, Nội dung ứng dụng, Báo cáo, Cấu hình) và Super Admin (Phần IX).
/// Chạm một dòng để đánh dấu; tiêu đề nhóm có thể chạm để thu gọn / mở rộng. Trạng thái chỉ LƯU TRÊN THIẾT BỊ NÀY (Preferences).
/// </summary>
public sealed class AdminChucNangAdminPage : AdminKyThuatTrang
{
    private static readonly (string Nhom, string[] Muc)[] Nhoms =
    {
        ("1. Dashboard tổng quan", new[] { "Tổng khách hàng", "Tổng nhà hàng", "Tổng chi nhánh", "Tổng tài xế", "Tổng đơn hàng", "Đơn mới", "Đơn đang xử lý", "Đơn đang giao", "Đơn hoàn thành", "Đơn bị hủy", "Doanh thu trong ngày", "Doanh thu trong tháng", "Chi phí giao hàng", "Tổng tiền cần thanh toán", "Tỷ lệ giao thành công", "Tỷ lệ giao trễ", "Số lượng tài xế trực tuyến", "Số lượng nhà hàng đang hoạt động", "Biểu đồ doanh thu", "Biểu đồ đơn hàng", "Biểu đồ tăng trưởng khách hàng" }),
        ("2. Quản lý tài khoản và phân quyền", new[] { "Danh sách người dùng", "Tạo tài khoản", "Chỉnh sửa tài khoản", "Khóa tài khoản", "Mở khóa tài khoản", "Đặt lại mật khẩu theo quy trình an toàn", "Quản lý vai trò", "Quản lý quyền", "Phân quyền theo module", "Phân quyền theo thao tác xem / thêm / sửa / xóa / duyệt", "Phân quyền theo chi nhánh", "Theo dõi lịch sử đăng nhập", "Theo dõi lịch sử hoạt động" }),
        ("3. Quản lý khách hàng", new[] { "Xem danh sách khách hàng", "Tìm kiếm khách hàng", "Lọc khách theo trạng thái", "Xem thông tin khách hàng", "Xem lịch sử đơn hàng", "Xem lịch sử thanh toán", "Xem lịch sử khiếu nại", "Khóa tài khoản vi phạm", "Xử lý yêu cầu xóa tài khoản", "Quản lý khách hàng thân thiết", "Xuất Excel" }),
        ("4. Quản lý nhà hàng", new[] { "Danh sách nhà hàng", "Thêm nhà hàng", "Sửa thông tin nhà hàng", "Xóa hoặc ngừng hoạt động theo chính sách", "Duyệt đăng ký nhà hàng", "Từ chối hồ sơ", "Yêu cầu bổ sung giấy tờ", "Quản lý hợp đồng", "Quản lý giấy phép", "Quản lý tài khoản ngân hàng", "Quản lý chi nhánh", "Theo dõi trạng thái hoạt động", "Tạm ngưng nhà hàng", "Quản lý danh mục món ăn", "Kiểm duyệt thực đơn", "Theo dõi đánh giá", "Theo dõi hiệu suất kinh doanh", "Quản lý tỷ lệ hoa hồng" }),
        ("5. Quản lý tài xế", new[] { "Danh sách tài xế", "Duyệt hồ sơ tài xế", "Xác minh giấy tờ", "Phê duyệt hoặc từ chối", "Yêu cầu bổ sung hồ sơ", "Quản lý phương tiện", "Quản lý khu vực làm việc", "Quản lý trạng thái hoạt động", "Khóa tài khoản", "Mở khóa tài khoản", "Xem lịch sử giao hàng", "Xem hiệu suất tài xế", "Xem lịch sử vi phạm", "Quản lý chương trình thưởng", "Quản lý thu nhập", "Quản lý đối soát tài xế" }),
        ("6. Quản lý đơn hàng", new[] { "Xem tất cả đơn hàng", "Tìm kiếm theo mã đơn", "Lọc theo thời gian", "Lọc theo nhà hàng", "Lọc theo khách hàng", "Lọc theo tài xế", "Lọc theo trạng thái", "Xem chi tiết đơn", "Theo dõi lịch sử trạng thái", "Theo dõi giao dịch thanh toán", "Hủy đơn theo quyền", "Phân công tài xế", "Đổi tài xế", "Xử lý đơn giao thất bại", "Xử lý đơn có khiếu nại", "Điều chỉnh nghiệp vụ có kiểm soát", "Xuất danh sách đơn hàng" }),
        ("7. Quản lý phí và chính sách kinh doanh", new[] { "Phí giao hàng cơ bản", "Phí theo khoảng cách", "Phí theo khu vực", "Phí theo khung giờ", "Phụ phí thời tiết nếu áp dụng", "Phụ phí giờ cao điểm", "Phí dịch vụ", "Hoa hồng nhà hàng", "Phí nền tảng", "Phí tối thiểu", "Giá trị đơn hàng tối thiểu", "Chính sách miễn phí giao hàng", "Chính sách hoàn tiền", "Chính sách hủy đơn" }),
        ("8. Quản lý khuyến mãi", new[] { "Tạo chương trình khuyến mãi", "Sửa chương trình", "Xóa hoặc dừng chương trình", "Tạo mã voucher", "Giảm theo phần trăm", "Giảm theo số tiền", "Miễn phí giao hàng", "Giảm cho khách hàng mới", "Giảm cho khách hàng cũ", "Giảm theo nhà hàng", "Giảm theo khu vực", "Giảm theo thời gian", "Giới hạn số lượt dùng", "Giới hạn ngân sách", "Theo dõi hiệu quả chiến dịch" }),
        ("9. Quản lý nội dung ứng dụng", new[] { "Banner trang chủ", "Banner khuyến mãi", "Danh mục món ăn", "Danh mục nhà hàng", "Nhà hàng nổi bật", "Món ăn nổi bật", "Nội dung thông báo", "Tin tức", "Chính sách sử dụng", "Điều khoản dịch vụ", "Câu hỏi thường gặp", "Trang liên hệ", "Nội dung hướng dẫn người dùng" }),
        ("10. Báo cáo và thống kê", new[] { "Báo cáo đơn hàng", "Báo cáo doanh thu", "Báo cáo chi phí", "Báo cáo hoa hồng", "Báo cáo nhà hàng", "Báo cáo tài xế", "Báo cáo khách hàng", "Báo cáo thanh toán", "Báo cáo hoàn tiền", "Báo cáo khiếu nại", "Báo cáo hiệu suất giao hàng", "Báo cáo tăng trưởng", "Báo cáo theo khu vực", "Xuất Excel / PDF" }),
        ("11. Cấu hình hệ thống", new[] { "Cấu hình tên ứng dụng", "Logo ứng dụng", "Màu sắc thương hiệu", "Thông tin doanh nghiệp", "Thông tin liên hệ", "Cấu hình email", "Cấu hình SMS/OTP", "Cấu hình thông báo đẩy", "Cấu hình bản đồ", "Cấu hình cổng thanh toán", "Cấu hình phí mặc định", "Cấu hình thời gian chờ nhận đơn", "Cấu hình bán kính tìm tài xế", "Cấu hình thời gian cập nhật GPS", "Cấu hình bảo mật", "Cấu hình sao lưu dữ liệu" }),
        ("Super Admin – toàn nền tảng (tùy chọn)", new[] { "Quản lý doanh nghiệp: tạo, sửa, khóa", "Quản lý nền tảng: cấu hình hệ thống dùng chung", "Quản lý Admin: cấp quyền quản trị doanh nghiệp", "Gói dịch vụ: quản lý gói sử dụng nền tảng", "Thanh toán dịch vụ: phí sử dụng phần mềm", "Giới hạn sử dụng: người dùng, đơn hàng, dung lượng", "Giám sát hệ thống: API, server, database", "Bảo mật: phát hiện truy cập bất thường", "Nhật ký: theo dõi hoạt động toàn nền tảng", "Sao lưu: quản lý bản sao lưu và khôi phục" }),
    };

    public AdminChucNangAdminPage() : base("Chức năng Admin & Super Admin") { }

    private static bool Dat(int g, int i) { try { return Preferences.Default.Get($"admincn-{g}-{i}", false); } catch { return false; } }
    private static void Dat(int g, int i, bool v) { try { Preferences.Default.Set($"admincn-{g}-{i}", v); } catch { } }
    private static bool Mo(int g) { try { return Preferences.Default.Get($"admincn-mo-{g}", true); } catch { return true; } }
    private static void Mo(int g, bool v) { try { Preferences.Default.Set($"admincn-mo-{g}", v); } catch { } }

    protected override Task DungAsync()
    {
        var tong = Nhoms.Sum(n => n.Muc.Length);
        var soDat = 0;
        for (var g = 0; g < Nhoms.Length; g++) for (var i = 0; i < Nhoms[g].Muc.Length; i++) if (Dat(g, i)) soDat++;
        var mau = Color.FromArgb(soDat == tong ? AdminUi.Xanh : AdminUi.Tim);

        var dau = new VerticalStackLayout { Spacing = 4 };
        dau.Add(AdminUi.Nhan("Chức năng quản trị đã kiểm tra", 14, dam: true));
        var pt = AdminUi.Nhan($"{(int)Math.Round(100.0 * soDat / tong)}%", 28, dam: true); pt.TextColor = mau; dau.Add(pt);
        dau.Add(new ProgressBar { Progress = (double)soDat / tong, ProgressColor = mau });
        dau.Add(AdminUi.Nhan($"{soDat}/{tong} chức năng · Super Admin chỉ cần khi cung cấp FoodApp cho nhiều doanh nghiệp / đơn vị vận hành.", 11.5, mo: true));
        dau.Add(AdminUi.Nhan("Lưu ý mục 7: mọi quy tắc tính phí phải có thời điểm bắt đầu áp dụng và lịch sử thay đổi, để không tính sai những đơn đã tạo trước đó.", 11.5, mo: true));
        Nd.Add(KhoiTheo("", dau));

        for (var k = 0; k < Nhoms.Length; k++)
        {
            var g = k;
            var (nhom, muc) = Nhoms[g];
            var datNhom = Enumerable.Range(0, muc.Length).Count(i => Dat(g, i));
            var mo = Mo(g);
            var ds = new VerticalStackLayout { Spacing = 2 };
            var td = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            td.Add(AdminUi.Nhan($"{(mo ? "▾" : "▸")} {nhom}", 15, dam: true), 0, 0);
            td.Add(AdminUi.Nhan($"{datNhom}/{muc.Length}", 13, dam: true), 1, 0);
            var tapTd = new TapGestureRecognizer();
            tapTd.Tapped += async (_, _) => { Mo(g, !Mo(g)); Nd.Children.Clear(); await DungAsync(); };
            td.GestureRecognizers.Add(tapTd);
            ds.Add(td);
            ds.Add(new ProgressBar { Progress = (double)datNhom / muc.Length, ProgressColor = Color.FromArgb(datNhom == muc.Length ? AdminUi.Xanh : AdminUi.Tim) });
            if (mo)
                for (var j = 0; j < muc.Length; j++)
                {
                    var i = j;
                    var xong = Dat(g, i);
                    var dong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 10, Padding = new Thickness(0, 8) };
                    dong.Add(new Label { Text = xong ? "✅" : "⚪", FontSize = 18, VerticalOptions = LayoutOptions.Center }, 0, 0);
                    var chu = AdminUi.Nhan(muc[i], 13.5, mo: xong);
                    chu.VerticalOptions = LayoutOptions.Center;
                    if (xong) chu.TextDecorations = TextDecorations.Strikethrough;
                    dong.Add(chu, 1, 0);
                    var tap = new TapGestureRecognizer();
                    tap.Tapped += async (_, _) => { Dat(g, i, !Dat(g, i)); Nd.Children.Clear(); await DungAsync(); };
                    dong.GestureRecognizers.Add(tap);
                    ds.Add(dong);
                }
            Nd.Add(KhoiTheo("", ds));
        }

        var datLai = AdminUi.Nut("Đặt lại đánh dấu", AdminUi.Xam);
        datLai.Clicked += async (_, _) =>
        {
            if (!await DisplayAlert("Đặt lại?", $"Bỏ đánh dấu toàn bộ {tong} chức năng trên thiết bị này.", "Đặt lại", "Hủy")) return;
            for (var g = 0; g < Nhoms.Length; g++) for (var i = 0; i < Nhoms[g].Muc.Length; i++) Dat(g, i, false);
            Nd.Children.Clear();
            await DungAsync();
        };
        Nd.Add(KhoiTheo("", datLai));
        return Task.CompletedTask;
    }
}
