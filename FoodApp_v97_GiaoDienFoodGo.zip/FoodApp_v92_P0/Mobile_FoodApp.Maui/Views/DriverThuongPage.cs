using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>v91: chương trình thưởng của tài xế — điều kiện từng mốc, tiến độ hôm nay / tuần này, số tiền đã đạt; lối tắt hiệu suất & khiếu nại.</summary>
public sealed class DriverThuongPage : ContentPage
{
    private readonly VerticalStackLayout _nd = new() { Padding = new Thickness(16), Spacing = 12 };

    public DriverThuongPage()
    {
        Title = "Chương trình thưởng";
        BackgroundColor = DriverPalette.Get("Background");
        Content = new ScrollView { Content = _nd };
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        Ve();
    }

    private static View Khung(string tieuDe, string moTa, (int SoDon, decimal Thuong)[] bac, int daGiao)
    {
        var st = new VerticalStackLayout { Spacing = 8 };
        st.Children.Add(new Label { Text = tieuDe, FontAttributes = FontAttributes.Bold, FontSize = 15 });
        st.Children.Add(new Label { Text = moTa, FontSize = 12, TextColor = DriverPalette.Get("TextGrey") });
        var max = bac.Max(b => b.SoDon);
        st.Children.Add(new ProgressBar { Progress = Math.Min(1.0, daGiao / (double)max), ProgressColor = DriverPalette.Get("Primary") });
        st.Children.Add(new Label { Text = $"Đã giao thành công: {daGiao} đơn", FontSize = 13, FontAttributes = FontAttributes.Bold });
        foreach (var b in bac)
        {
            var dat = daGiao >= b.SoDon;
            st.Children.Add(new Label
            {
                Text = dat ? $"✅ Đạt {b.SoDon} đơn → +{b.Thuong:N0}đ"
                           : $"⬜ {b.SoDon} đơn → +{b.Thuong:N0}đ · còn {b.SoDon - daGiao} đơn",
                FontSize = 13,
            });
        }
        var nhan = bac.Where(b => daGiao >= b.SoDon).Select(b => b.Thuong).DefaultIfEmpty(0).Max();
        st.Children.Add(new Label { Text = nhan > 0 ? $"Thưởng đã đạt: +{nhan:N0}đ" : "Chưa đạt mốc nào", FontSize = 13, FontAttributes = FontAttributes.Bold, TextColor = DriverPalette.Get("Primary") });
        return new Border
        {
            Padding = new Thickness(14), BackgroundColor = Colors.White, Stroke = DriverPalette.Get("BorderColor"), StrokeThickness = 1, Content = st,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(16) },
        };
    }

    private void Ve()
    {
        _nd.Children.Clear();
        _nd.Children.Add(new Label { Text = ThuNhapService.TienDoThuongNgay(), FontSize = 13.5, FontAttributes = FontAttributes.Bold, TextColor = DriverPalette.Get("Primary") });
        _nd.Children.Add(Khung("🎯 Thưởng ngày", "Điều kiện: số đơn GIAO THÀNH CÔNG trong ngày (đơn thất bại/hủy không tính). Nhận mốc cao nhất đã đạt.", ThuNhapService.BacNgay, ThuNhapService.SoDonNgay(DateTime.Today)));
        _nd.Children.Add(Khung("📅 Thưởng tuần", "Điều kiện: số đơn giao thành công từ thứ Hai đến Chủ nhật. Cộng vào thu nhập tuần.", ThuNhapService.BacTuan, ThuNhapService.SoDonTuan(DateTime.Today)));
        _nd.Children.Add(new Border
        {
            Padding = new Thickness(14), BackgroundColor = Colors.White, Stroke = DriverPalette.Get("BorderColor"), StrokeThickness = 1,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(16) },
            Content = new VerticalStackLayout
            {
                Spacing = 4,
                Children =
                {
                    new Label { Text = "🌙 Phụ cấp giờ đêm", FontAttributes = FontAttributes.Bold, FontSize = 15 },
                    new Label { Text = "+3.000đ cho mỗi đơn giao xong trong khung 21:00 – 06:00.", FontSize = 12.5, TextColor = DriverPalette.Get("TextGrey") },
                }
            }
        });

        var hs = new Button { Text = "📈 Xem hiệu suất & lịch sử vi phạm", CornerRadius = 12, HeightRequest = 44, BackgroundColor = Colors.Transparent, TextColor = DriverPalette.Get("Primary"), BorderColor = DriverPalette.Get("Primary"), BorderWidth = 1 };
        hs.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(DriverPerformancePage));
        var kn = new Button { Text = "💬 Khiếu nại thưởng / thu nhập", CornerRadius = 12, HeightRequest = 44, BackgroundColor = Colors.Transparent, TextColor = DriverPalette.Get("Primary"), BorderColor = DriverPalette.Get("Primary"), BorderWidth = 1 };
        kn.Clicked += async (_, _) => await Shell.Current.GoToAsync($"{nameof(DriverSuCoPage)}?loai=SaiLechThuNhap");
        _nd.Children.Add(hs); _nd.Children.Add(kn);
        _nd.Children.Add(new Label { Text = "Các mốc thưởng là chính sách hiện hành trên app; số tiền thực nhận do hệ thống đối soát xác nhận.", FontSize = 11.5, TextColor = DriverPalette.Get("TextGrey") });
    }
}
