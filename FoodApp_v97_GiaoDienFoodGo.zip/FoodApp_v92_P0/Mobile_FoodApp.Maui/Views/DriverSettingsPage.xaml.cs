using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Cài đặt của tài xế. Mọi công tắc đều có tác dụng thật: thông báo đơn (ẩn/hiện trong Thông báo), chế độ tối (ThemeService), chia sẻ vị trí (ViTriTaiXeService).</summary>
public partial class DriverSettingsPage : ContentPage
{
    public const string KhoaThongBaoDon = "tx-nhan-thong-bao-don";
    public static bool NhanThongBaoDon => Preferences.Default.Get(KhoaThongBaoDon, true);

    public DriverSettingsPage() => InitializeComponent();

    protected override void OnAppearing()
    {
        base.OnAppearing();
        SwThongBaoDon.IsToggled = NhanThongBaoDon;
        SwCheDoToi.IsToggled = ThemeService.Hien == "dark" || (ThemeService.Hien == "auto" && Application.Current?.RequestedTheme == AppTheme.Dark);
        SwViTri.IsToggled = ViTriTaiXeService.DuocPhepChiaSe;
        _ = CapNhatQuyenViTriAsync();
    }

    private async Task CapNhatQuyenViTriAsync()
    {
        try
        {
            var q = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();
            LblQuyenViTri.Text = q == PermissionStatus.Granted ? "Đã cấp quyền vị trí"
                : q == PermissionStatus.Denied ? "Chưa được cấp — khách không theo dõi được bạn. Bấm Mở cài đặt để cấp quyền"
                : "Chưa cấp quyền — sẽ được hỏi khi bắt đầu giao đơn";
        }
        catch (Exception) { LblQuyenViTri.Text = "Thiết bị không hỗ trợ định vị"; }
    }

    private void OnMoCaiDatQuyenClicked(object? sender, EventArgs e)
    {
        try { AppInfo.Current.ShowSettingsUI(); }
        catch (Exception) { }
    }

    private void OnThongBaoDonToggled(object? sender, ToggledEventArgs e) => Preferences.Default.Set(KhoaThongBaoDon, e.Value);
    private void OnCheDoToiToggled(object? sender, ToggledEventArgs e) => ThemeService.Dat(e.Value ? "dark" : "light");

    private void OnViTriToggled(object? sender, ToggledEventArgs e)
    {
        ViTriTaiXeService.DuocPhepChiaSe = e.Value;
        if (!e.Value) ViTriTaiXeService.Dung("Đã tắt chia sẻ vị trí");
    }

    private async void OnDoiMatKhauTapped(object? sender, TappedEventArgs e) => await Shell.Current.GoToAsync($"{nameof(DoiMatKhauPage)}?VaiTro=TaiXe");

    private async void OnChinhSachTapped(object? sender, TappedEventArgs e)
    {
        try { await Launcher.Default.OpenAsync(AppSettings.BaseUrl.TrimEnd('/') + "/ChinhSach"); }
        catch { await DisplayAlert("Không mở được", "Không mở được trang chính sách. Hãy kiểm tra kết nối mạng.", "Đóng"); }
    }

    private async void OnTroGiupTapped(object? sender, TappedEventArgs e)
        => await DisplayAlert("Trợ giúp", "• Nhận đơn: bật Online + Sẵn sàng ở Trang chủ.\n• Lấy hàng: chỉ bấm \"Đã lấy hàng\" khi quán báo sẵn sàng.\n• Giao xong: nhập mã xác nhận của khách.\n• Cần hỗ trợ: Tài khoản → Hỗ trợ.", "Đóng");
}
