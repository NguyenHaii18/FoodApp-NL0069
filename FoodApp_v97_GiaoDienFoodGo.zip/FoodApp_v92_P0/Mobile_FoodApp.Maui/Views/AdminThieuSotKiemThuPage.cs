namespace FoodApp.Maui.Views;

/// <summary>
/// Phần X — Thiếu sót về kiểm thử, đóng gói và triển khai (chưa đủ điều kiện nghiệm thu thực tế), STT 106–124.
/// Mỗi mục có: hiện trạng ghi nhận, kết quả đối chiếu với mã nguồn Web/ + Database/ (chỉ ghi điều ĐÃ xác minh) và ô đánh dấu đã khắc phục.
/// Chạm một dòng để đánh dấu đã xử lý. Trạng thái đánh dấu chỉ LƯU TRÊN THIẾT BỊ NÀY (Preferences).
/// </summary>
public sealed class AdminThieuSotKiemThuPage : AdminKyThuatTrang
{
    // Mức rà soát mã nguồn: 0 = chưa có, 1 = có một phần, 2 = đã có, 3 = chưa xác minh được trong mã
    private sealed record Muc(int Stt, string ThieuSot, string HienTrang, int Muc_, string RaSoat);

    private static readonly Muc[] Dong =
    {
        new(106, "Build MAUI", "Chưa xác nhận build thành công", 3,
            "Nhiều CHANGELOG ghi rõ chưa build vì nơi soạn không có .NET SDK. csproj nhắm net8.0-windows10.0.19041.0 (Windows) hoặc net8.0-android. Chưa có nhật ký build thành công đính kèm."),
        new(107, "Build Backend", "Chưa xác nhận build thành công", 3,
            "Cùng tình trạng: chưa có nhật ký dotnet build / publish của Web. Cần chạy dotnet build trước khi nghiệm thu."),
        new(108, "Unit Test", "Chưa thấy project test riêng hoàn chỉnh", 0,
            "Không có project *.Tests nào và không tìm thấy thuộc tính [Fact] / [Test] / [TestMethod] trong mã nguồn."),
        new(109, "Integration Test", "Chưa có kết quả chạy kiểm thử đầy đủ", 0,
            "Không có project kiểm thử tích hợp (WebApplicationFactory + CSDL thử). Hiện chỉ có script nghiệm thu chạy qua API thật."),
        new(110, "API Test", "Có script nghiệm thu nhưng chưa chứng minh toàn bộ API đạt", 1,
            "Tools/NghiemThu_E2E.ps1 gồm khoảng 27 bước PASS/FAIL, có vài ca lỗi (nhận đơn trùng, mã xác nhận sai, đánh giá trùng) nhưng chỉ một luồng COD. Chưa lưu kết quả chạy; chưa phủ hết API (Docs/API_CHUAN.md)."),
        new(111, "UI Test", "Chưa có kết quả kiểm thử giao diện tự động đầy đủ", 0,
            "Không thấy khung kiểm thử giao diện tự động (Appium / MAUI UITest) hay kịch bản tương ứng."),
        new(112, "Test thanh toán", "Chưa xác nhận callback, giao dịch lỗi, hoàn tiền", 1,
            "Mã đã xử lý: VnPayXuLy ghi kết quả idempotent (return/IPN), ThanhToanDoiSoatNen hỏi lại cổng, đơn hủy tự tạo yêu cầu hoàn tiền. Nhưng script nghiệm thu chỉ chạy COD — chưa có kiểm thử callback, giao dịch lỗi hay hoàn tiền."),
        new(113, "Test phân đơn", "Chưa kiểm thử tải và tranh chấp nhận đơn", 1,
            "Có chốt chặn trong CSDL (chỉ mục UNIQUE UX_DeNghi_Don_Cho, UX_PhanCong_DangGiu…) và script có ca \"nhận lần 2 bị từ chối\". Chưa có kiểm thử nhiều tài xế bấm nhận cùng lúc hoặc tải nhiều đơn."),
        new(114, "Test GPS nền", "Chưa kiểm thử trên nhiều thiết bị và khi khóa màn hình", 0,
            "AndroidManifest chỉ khai báo ACCESS_FINE/COARSE_LOCATION; không thấy ACCESS_BACKGROUND_LOCATION, FOREGROUND_SERVICE hay Service chạy nền. Nhiều khả năng app ngừng gửi vị trí khi bị đưa xuống nền / khóa màn hình — cần thử trên máy thật."),
        new(115, "Test bảo mật", "Chưa có báo cáo pentest hoặc kiểm thử bảo mật đầy đủ", 1,
            "Có Docs/CAU_HINH_BAO_MAT.md và CAU_HINH_PRODUCTION_P0.md (10 mục P0 đã xử lý trong mã: chặn cấu hình mẫu khi chạy thật, tắt HTTP rõ, kiểm tra chữ ký file tải lên…). Không có báo cáo pentest hay kiểm thử bảo mật độc lập."),
        new(116, "Test hiệu năng", "Chưa có báo cáo tải nhiều người dùng", 0,
            "Không thấy kịch bản tải (k6 / JMeter / NBomber) hay báo cáo kết quả."),
        new(117, "Test khôi phục DB", "Có script backup nhưng chưa xác nhận phục hồi thật", 1,
            "Database/FoodService_NghiemThu_SaoLuu.sql (full / differential / log, RESTORE VERIFYONLY, mẫu RESTORE) và deploy/sao-luu.sh (cron 02:00, giữ 14 ngày). Tài liệu dặn thử phục hồi vào Staging định kỳ nhưng chưa có bằng chứng đã làm."),
        new(118, "CI/CD", "Chưa tìm thấy pipeline tự động hoàn chỉnh", 0,
            "Không có .github/workflows, Jenkinsfile hay azure-pipelines. Chỉ có deploy/Dockerfile và docker-compose.yml để đóng gói thủ công."),
        new(119, "Staging", "Chưa có bằng chứng triển khai và nghiệm thu staging", 1,
            "Có appsettings.Staging.json, BaseUrlStaging và hướng dẫn Docs/TRIEN_KHAI.md; tài liệu ghi rõ file mẫu deploy/ chưa chạy thử trên máy chủ thật. Chưa có biên bản nghiệm thu staging."),
        new(120, "Production", "Chưa có bằng chứng hệ thống chạy production", 0,
            "Có cơ chế chặn khởi động khi cấu hình mẫu / tài khoản sa / khóa demo còn trong Production, nhưng không có bằng chứng triển khai thật."),
        new(121, "Phát hành Android", "Chưa xác minh APK/AAB Release đã ký", 1,
            "net8.0-android, ApplicationId com.doancuoiki.foodserviceapp. csproj chưa cấu hình ký (không có AndroidKeyStore / định dạng AAB); Docs/TRIEN_KHAI.md chỉ dặn dùng keystore riêng. Chưa có file APK/AAB Release."),
        new(122, "Phát hành iOS", "Chưa xác minh bản build và ký ứng dụng iOS", 0,
            "csproj chỉ có TargetFrameworks windows và android; không có thư mục Platforms/iOS. Chưa thể build iOS — cần thêm net8.0-ios, Info.plist (quyền vị trí, camera), máy Mac và tài khoản Apple Developer."),
        new(123, "Monitoring", "Chưa xác minh hệ thống giám sát và cảnh báo production", 1,
            "Có endpoint /health (kiểm tra app + SQL Server), deploy/giam-sat.sh (cron 5 phút, báo webhook Telegram/Slack), màn Giám sát hệ thống. Chưa có bằng chứng đã chạy trên production; chưa có APM hay cảnh báo theo ngưỡng lỗi."),
        new(124, "Quy trình sự cố", "Cần hoàn thiện kế hoạch khôi phục và xử lý khi máy chủ gặp lỗi", 1,
            "Có hướng dẫn sao lưu / phục hồi (Database/QUY_TRINH_CSDL.md, sao-luu.sh) và giám sát. Chưa có tài liệu quy trình sự cố: phân vai, mục tiêu khôi phục (RTO/RPO), checklist khi máy chủ sập, thông báo người dùng, hậu kiểm."),
    };

    public AdminThieuSotKiemThuPage() : base("Thiếu sót kiểm thử & triển khai") { }

    private static bool Dat(int stt) { try { return Preferences.Default.Get($"thieusot-x-{stt}", false); } catch { return false; } }
    private static void Dat(int stt, bool v) { try { Preferences.Default.Set($"thieusot-x-{stt}", v); } catch { } }

    private static (string Bieu, string Nhan, string Mau) TheoMuc(int m) => m switch
    {
        0 => ("❌", "Chưa có", AdminUi.Do),
        1 => ("⚠️", "Có một phần", AdminUi.Cam),
        2 => ("✔", "Đã có", AdminUi.Xanh),
        _ => ("❔", "Chưa xác minh", AdminUi.Xam),
    };

    protected override Task DungAsync()
    {
        var soDat = Dong.Count(d => Dat(d.Stt));
        var mau = Color.FromArgb(soDat == Dong.Length ? AdminUi.Xanh : AdminUi.Tim);

        var dau = new VerticalStackLayout { Spacing = 4 };
        dau.Add(AdminUi.Nhan("X. Thiếu sót về kiểm thử, đóng gói và triển khai", 14, dam: true));
        dau.Add(AdminUi.Nhan("Chưa đủ điều kiện nghiệm thu thực tế (STT 106–124)", 12, mo: true));
        var pt = AdminUi.Nhan($"{(int)Math.Round(100.0 * soDat / Dong.Length)}%", 28, dam: true); pt.TextColor = mau; dau.Add(pt);
        dau.Add(new ProgressBar { Progress = (double)soDat / Dong.Length, ProgressColor = mau });
        dau.Add(AdminUi.Nhan($"{soDat}/{Dong.Length} mục đã đánh dấu khắc phục · ❌ {Dong.Count(d => d.Muc_ == 0)} chưa có · ⚠️ {Dong.Count(d => d.Muc_ == 1)} có một phần · ❔ {Dong.Count(d => d.Muc_ == 3)} chưa xác minh", 11.5, mo: true));
        Nd.Add(KhoiTheo("", dau));

        Nd.Add(KhoiTheo("Lưu ý về script nghiệm thu",
            AdminUi.Nhan("Tools/NghiemThu_E2E.ps1 chạy một luồng COD: khách đặt → nhà hàng xử lý → tài xế giao → hoàn thành → đánh giá, kèm vài ca từ chối. Luồng này chưa thay thế kiểm thử các tình huống lỗi của hệ thống (thanh toán online, hủy/hoàn tiền, tranh chấp nhận đơn, mất mạng, GPS nền…).", 12)));

        var ds = new VerticalStackLayout { Spacing = 2 };
        ds.Add(AdminUi.Nhan("Danh sách thiếu sót — chạm để đánh dấu đã khắc phục", 13, dam: true));
        foreach (var d in Dong)
        {
            var m = d;
            var xong = Dat(m.Stt);
            var (bieu, nhanMuc, mauMuc) = TheoMuc(m.Muc_);
            var dong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 10, Padding = new Thickness(0, 8) };
            dong.Add(new Label { Text = xong ? "✅" : "⚪", FontSize = 18, VerticalOptions = LayoutOptions.Start }, 0, 0);
            var tieuDe = AdminUi.Nhan($"{m.Stt} · {m.ThieuSot}", 13.5, dam: true, mo: xong);
            if (xong) tieuDe.TextDecorations = TextDecorations.Strikethrough;
            var cot = new VerticalStackLayout { Spacing = 2, VerticalOptions = LayoutOptions.Center, Children = { tieuDe } };
            cot.Add(AdminUi.Nhan("Hiện trạng: " + m.HienTrang, 11.5, mo: true));
            var raSoat = AdminUi.Nhan($"{bieu} {nhanMuc}: {m.RaSoat}", 10.5, mo: true);
            raSoat.TextColor = Color.FromArgb(mauMuc);
            cot.Add(raSoat);
            dong.Add(cot, 1, 0);
            var tap = new TapGestureRecognizer();
            tap.Tapped += async (_, _) => { Dat(m.Stt, !Dat(m.Stt)); Nd.Children.Clear(); await DungAsync(); };
            dong.GestureRecognizers.Add(tap);
            ds.Add(dong);
        }
        Nd.Add(KhoiTheo("", ds));

        Nd.Add(KhoiTheo("Cách đọc kết quả rà soát",
            AdminUi.Nhan("Dòng màu dưới mỗi mục là kết quả đối chiếu với mã nguồn, thư mục Tools/ deploy/ Docs/ và file csproj (không phải kiểm thử trên máy chủ đang chạy). Mục ❔ là việc chỉ xác nhận được bằng cách chạy thật (build, chạy test) — cần có nhật ký/biên bản trước khi đánh dấu xong.", 11.5, mo: true)));

        var datLai = AdminUi.Nut("Đặt lại đánh dấu", AdminUi.Xam);
        datLai.Clicked += async (_, _) =>
        {
            if (!await DisplayAlert("Đặt lại?", $"Bỏ đánh dấu toàn bộ {Dong.Length} mục trên thiết bị này.", "Đặt lại", "Hủy")) return;
            foreach (var d in Dong) Dat(d.Stt, false);
            Nd.Children.Clear();
            await DungAsync();
        };
        Nd.Add(KhoiTheo("", datLai));
        return Task.CompletedTask;
    }
}
