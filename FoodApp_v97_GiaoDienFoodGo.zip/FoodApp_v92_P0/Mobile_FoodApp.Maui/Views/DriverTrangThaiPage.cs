using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// v91: màn "Trạng thái làm việc" của tài xế — kiểm tra Internet / quyền vị trí / GPS / kết nối máy chủ / quyền chạy nền,
/// xem thời gian hoạt động hôm nay, nghỉ giải lao (tự bật nhận đơn lại), khu vực hoạt động và lối tắt tới vùng nhu cầu cao.
/// </summary>
public sealed class DriverTrangThaiPage : ContentPage
{
    private readonly VerticalStackLayout _nd = new() { Padding = new Thickness(16), Spacing = 12 };
    private bool _dangVe;

    public DriverTrangThaiPage()
    {
        Title = "Trạng thái làm việc";
        BackgroundColor = DriverPalette.Get("Background");
        var lamMoi = new RefreshView { Content = new ScrollView { Content = _nd } };
        lamMoi.Refreshing += async (_, _) => { await VeAsync(); lamMoi.IsRefreshing = false; };
        Content = lamMoi;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        DriverCaLamViecService.ThayDoi += OnNghiDoi;
        await DriverCaLamViecService.KhoiPhucAsync();
        await VeAsync();
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        DriverCaLamViecService.ThayDoi -= OnNghiDoi;
    }

    private void OnNghiDoi() => MainThread.BeginInvokeOnMainThread(async () => await VeAsync());

    private static Border The(string tieuDe, params View[] noiDung)
    {
        var st = new VerticalStackLayout { Spacing = 6 };
        st.Children.Add(new Label { Text = tieuDe, FontAttributes = FontAttributes.Bold, FontSize = 15 });
        foreach (var v in noiDung) st.Children.Add(v);
        return new Border
        {
            Padding = new Thickness(14), BackgroundColor = Colors.White, Stroke = DriverPalette.Get("BorderColor"), StrokeThickness = 1, Content = st,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(16) },
        };
    }

    private static Label Dong(bool ok, string text) => new() { Text = (ok ? "✅ " : "⚠ ") + text, FontSize = 13 };
    private static Label Chu(string text, double co = 12.5) => new() { Text = text, FontSize = co, TextColor = DriverPalette.Get("TextGrey") };

    private static Button Nut(string text, Func<Task> viec, bool chinh = false)
    {
        var b = new Button { Text = text, CornerRadius = 12, HeightRequest = 42, FontSize = 13 };
        if (chinh) { b.BackgroundColor = DriverPalette.Get("Primary"); b.TextColor = Colors.White; }
        else { b.BackgroundColor = Colors.Transparent; b.TextColor = DriverPalette.Get("Primary"); b.BorderColor = DriverPalette.Get("Primary"); b.BorderWidth = 1; }
        b.Clicked += async (_, _) => await viec();
        return b;
    }

    private async Task VeAsync()
    {
        if (_dangVe) return;
        _dangVe = true;
        try
        {
            var tt = await DriverCanhBaoService.DoTinhTrangAsync();
            var t = MockData.TaiXeHienTai;
            _nd.Children.Clear();

            _nd.Children.Add(new Label
            {
                Text = t?.TrangThaiLamViec ?? "⚪ Offline", FontAttributes = FontAttributes.Bold, FontSize = 16,
                TextColor = DriverPalette.Get("Primary"),
            });

            // --- kết nối & thiết bị
            var ket = new List<View>
            {
                Dong(tt.CoMang, tt.CoMang ? "Internet: đang kết nối" : "Internet: MẤT KẾT NỐI — không nhận được đơn mới"),
                Dong(tt.QuyenViTri, tt.QuyenViTri ? "Quyền vị trí: đã cấp" : "Quyền vị trí: chưa cấp"),
                Dong(tt.GpsHoatDong, tt.GpsHoatDong ? "GPS: đang hoạt động" : "GPS: không lấy được vị trí — hãy bật Vị trí của thiết bị"),
                Dong(DuLieuService.DangOnline, DuLieuService.DangOnline
                    ? "Máy chủ: đã kết nối · " + DriverPresenceService.TrangThai
                    : "Máy chủ: chưa kết nối (đang dùng dữ liệu trên máy)"),
            };
            if (!tt.QuyenViTri || !tt.GpsHoatDong)
                ket.Add(Nut("📍 Mở cài đặt vị trí", () => { AppInfo.ShowSettingsUI(); return Task.CompletedTask; }));
            _nd.Children.Add(The("📡 Kết nối & thiết bị", ket.ToArray()));

            // --- chạy nền
            var nen = new List<View>();
            switch (tt.ChayNenOk)
            {
                case true: nen.Add(Dong(true, "Ứng dụng được phép chạy nền ổn định")); break;
                case false:
                    nen.Add(Dong(false, "Hệ thống có thể tắt app khi khóa màn hình → dễ lỡ đơn mới"));
                    nen.Add(Nut("🔋 Cho phép chạy nền", () =>
                    {
                        if (!DriverCanhBaoService.MoCaiDatChayNen()) AppInfo.ShowSettingsUI();
                        return Task.CompletedTask;
                    }, chinh: true));
                    break;
                default: nen.Add(Chu("Thiết bị này không yêu cầu cấp quyền chạy nền riêng.")); break;
            }
            _nd.Children.Add(The("🔋 Quyền chạy nền", nen.ToArray()));

            // --- hôm nay
            _nd.Children.Add(The("⏱ Hôm nay",
                new Label { Text = "Thời gian hoạt động: " + DriverCaLamViecService.HoatDongHomNayText(), FontSize = 13.5, FontAttributes = FontAttributes.Bold },
                Chu($"Đơn giao thành công hôm nay: {ThuNhapService.SoDonNgay(DateTime.Today)}"),
                Chu("Tính từ lúc bạn bật Online; cộng dồn nhiều lần bật/tắt trong ngày.")));

            // --- nghỉ giải lao
            var nghi = new List<View>();
            if (DriverCaLamViecService.NghiDen is { } den)
            {
                nghi.Add(new Label { Text = $"☕ Đang nghỉ đến {den:HH:mm} (còn {Math.Max(1, (int)Math.Ceiling((den - DateTime.Now).TotalMinutes))} phút)", FontSize = 13.5, FontAttributes = FontAttributes.Bold });
                nghi.Add(Chu("Hết giờ, hệ thống tự bật nhận đơn lại."));
                nghi.Add(Nut("▶ Tiếp tục nhận đơn ngay", async () => { await DriverCaLamViecService.KetThucNghiAsync(); }, chinh: true));
            }
            else if (t is null || !t.DangOnline) nghi.Add(Chu("Bật Online trước khi đặt giờ nghỉ."));
            else if (MockData.DonHangDangGiaoCuaTaiXe is not null) nghi.Add(Chu("Bạn đang giao đơn — hoàn thành đơn rồi mới nghỉ được."));
            else
            {
                nghi.Add(Chu("Tạm không nhận đơn mới trong một khoảng thời gian, vẫn giữ trạng thái Online."));
                nghi.Add(Nut("☕ Nghỉ giải lao…", async () =>
                {
                    var c = await DisplayActionSheet("Nghỉ bao lâu?", "Hủy", null, "15 phút", "30 phút", "60 phút");
                    if (c is null or "Hủy") return;
                    var phut = int.Parse(c.Split(' ')[0]);
                    if (!await DriverCaLamViecService.BatDauNghiAsync(phut))
                        await DisplayAlert("Chưa nghỉ được", "Hãy bật Online và hoàn thành đơn đang giao trước.", "OK");
                }, chinh: true));
            }
            _nd.Children.Add(The("☕ Nghỉ giải lao", nghi.ToArray()));

            // --- khu vực
            var cs = ChinhSachService.HienTai;
            var kv = GiaoHangService.DanhSachKhuVuc().ToList();
            _nd.Children.Add(The("🗺 Khu vực hoạt động",
                Chu($"Bán kính giao tối đa theo chính sách: {(cs.BanKinhKm > 0 ? cs.BanKinhKm.ToString("0.#") : "15")} km quanh quán."),
                Chu(kv.Count > 0 ? "Khu vực hệ thống hỗ trợ tính phí: " + string.Join(", ", kv.Take(14)) + (kv.Count > 14 ? $" … (+{kv.Count - 14})" : "") : "Hệ thống nhận đơn trong khu vực quán đã đăng ký."),
                Chu("Đơn ngoài phạm vi sẽ không được phân cho bạn."),
                Nut("🔥 Xem vùng có nhu cầu giao hàng cao", async () => await Shell.Current.GoToAsync(nameof(DriverNhuCauPage)))));
        }
        catch (Exception ex) { CrashLog.Ghi("DriverTrangThai.Ve", ex); }
        finally { _dangVe = false; }
    }
}
