using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Trang chủ Quản trị viên (bố cục dashboard): sidebar navy (ngăn kéo trên điện thoại, cố định khi màn rộng ≥ 900),
/// 4 chỉ số, biểu đồ doanh thu 7 ngày / 30 ngày / 3 tháng, đơn hàng mới, việc cần xử lý, top gian hàng, thao tác nhanh, trạng thái hệ thống.
/// </summary>
public partial class AdminHomePage : ContentPage
{
    private const double NguongManRong = 900;
    private int _kyBieuDo = 7;
    private bool _daNoiSidebar;

    public AdminHomePage()
    {
        InitializeComponent();
        try { DungLoiTat(); } catch (Exception ex) { CrashLog.Ghi("AdminHome.LoiTat", ex); }
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        NoiSidebar();
        NapTongQuan();
        NapDonVaTop();
        NapBieuDo();
        _ = NapCanXuLyAsync();
    }

    // ───────── Sidebar ─────────
    private void NoiSidebar()
    {
        if (_daNoiSidebar) return;
        _daNoiSidebar = true;
        SidebarCoDinh.Chon += async khoa => await DieuHuongAsync(khoa);
        SidebarNganKeo.Chon += async khoa => { LopNganKeo.IsVisible = false; await DieuHuongAsync(khoa); };
        SidebarCoDinh.MucChon = SidebarNganKeo.MucChon = "home";
    }

    private void CapNhatSidebar(int soDon)
    {
        var ten = MockData.QuanTriVienHienTai.HoTen;
        SidebarCoDinh.CapNhat(ten, soDon, false);
        SidebarNganKeo.CapNhat(ten, soDon, false);
    }

    private async Task DieuHuongAsync(string khoa)
    {
        try
        {
            switch (khoa)
            {
                case "orders": await Shell.Current.GoToAsync(nameof(AdminOrdersPage)); break;
                case "dispatch": await Shell.Current.GoToAsync(nameof(AdminDispatchPage)); break;
                case "vendors": await Shell.Current.GoToAsync(nameof(AdminVendorListPage)); break;
                case "drivers": await Shell.Current.GoToAsync(nameof(AdminDriverListPage)); break;
                case "customers": await Shell.Current.GoToAsync(nameof(AdminCustomerListPage)); break;
                case "promo": await Shell.Current.GoToAsync(nameof(AdminPromotionsPage)); break;
                case "reports": await Shell.Current.GoToAsync(nameof(AdminReportsPage)); break;
                case "staff": OnNhanVienTapped(this, EventArgs.Empty); break;
                case "settings": await Shell.Current.GoToAsync(nameof(AdminConfigPage)); break;
                case "all": await Shell.Current.GoToAsync(nameof(AdminHubPage)); break;
                case "logout": OnDangXuatClicked(this, EventArgs.Empty); break;
            }
        }
        catch (Exception ex) { CrashLog.Ghi("AdminHome.Sidebar -> " + khoa, ex); }
    }

    private void OnTrangDoiKichThuoc(object? sender, EventArgs e)
    {
        var rong = Width >= NguongManRong;
        SidebarCoDinh.IsVisible = rong;
        NavDuoi.IsVisible = !rong;
        NutMoSidebar.IsVisible = !rong;
        if (rong) LopNganKeo.IsVisible = false;
    }

    private void OnMoSidebarTapped(object? sender, EventArgs e) => LopNganKeo.IsVisible = true;
    private void OnDongSidebarTapped(object? sender, EventArgs e) => LopNganKeo.IsVisible = false;

    // ───────── Thao tác nhanh (ô màu) ─────────
    private void DungLoiTat()
    {
        var muc = new (string Icon, string Ten, string Route, string Nen)[]
        {
            ("📦", "Đơn hàng", nameof(AdminOrdersPage), "#EAF1FF"),
            ("🧭", "Điều phối", nameof(AdminDispatchPage), "#E8F8F0"),
            ("✅", "Duyệt quán", nameof(AdminVendorApprovalPage), "#FFF1E2"),
            ("📣", "Khiếu nại", nameof(AdminIssuesPage), "#EEEBFF"),
            ("👥", "Khách hàng", nameof(AdminCustomerListPage), "#EEEBFF"),
            ("🏬", "Gian hàng", nameof(AdminVendorListPage), "#FFF1E2"),
            ("📥", "Xuất Excel", nameof(AdminXuatExcelPage), "#EAF1FF"),
            ("🗂", "Tất cả", nameof(AdminHubPage), "#E8F8F0"),
        };
        const int cot = 4;
        for (var c = 0; c < cot; c++) LuoiLoiTat.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
        for (var i = 0; i < muc.Length; i++)
        {
            if (i % cot == 0) LuoiLoiTat.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
            var (icon, ten, route, nen) = muc[i];
            var st = new VerticalStackLayout { Spacing = 4, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center };
            st.Add(new Label { Text = icon, FontSize = 24, HorizontalOptions = LayoutOptions.Center, TextColor = Colors.Black });
            st.Add(new Label { Text = ten, FontSize = 11.5, FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb("#14193A"), HorizontalTextAlignment = TextAlignment.Center, LineBreakMode = LineBreakMode.TailTruncation });
            var the = new Border
            {
                BackgroundColor = Color.FromArgb(nen), StrokeThickness = 0, Padding = new Thickness(4, 12), HeightRequest = 78,
                StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(16) }, Content = st
            };
            the.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(async () =>
                {
                    try { await Shell.Current.GoToAsync(route); }
                    catch (Exception ex) { CrashLog.Ghi("AdminHome.LoiTat -> " + route, ex); }
                })
            });
            LuoiLoiTat.Add(the, i % cot, i / cot);
        }
    }

    // ───────── Biểu đồ doanh thu ─────────
    private void OnChonKyBieuDo(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is string p && int.TryParse(p, out var ky)) { _kyBieuDo = ky; NapBieuDo(); }
    }

    private void NapBieuDo()
    {
        var xong = MockData.TatCaDonHangHeThong.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).ToList();
        var homNay = DateTime.Now.Date;
        var nhan = new List<string>(); var gt = new List<decimal>();
        if (_kyBieuDo <= 30)
            for (var i = _kyBieuDo - 1; i >= 0; i--)
            {
                var ngay = homNay.AddDays(-i);
                nhan.Add(ngay.ToString("dd/MM"));
                gt.Add(xong.Where(d => d.NgayDat.Date == ngay).Sum(d => d.TongTien));
            }
        else
            for (var t = 12; t >= 0; t--)   // 13 tuần ≈ 3 tháng
            {
                var den = homNay.AddDays(-7 * t); var tu = den.AddDays(-6);
                nhan.Add(den.ToString("dd/MM"));
                gt.Add(xong.Where(d => d.NgayDat.Date >= tu && d.NgayDat.Date <= den).Sum(d => d.TongTien));
            }
        BieuDo.Dat(nhan, gt);
        LblTongKyBieuDo.Text = $"Tổng {(_kyBieuDo == 90 ? "3 tháng" : _kyBieuDo + " ngày")}: {gt.Sum():N0}đ" + (_kyBieuDo == 90 ? " (theo tuần)" : "");
        ToChip(Chip7, _kyBieuDo == 7); ToChip(Chip30, _kyBieuDo == 30); ToChip(Chip90, _kyBieuDo == 90);
    }

    private static void ToChip(Border chip, bool chon)
    {
        chip.BackgroundColor = Color.FromArgb(chon ? "#5B3FD9" : "#EEEBFF");
        if (chip.Content is Label l) l.TextColor = Color.FromArgb(chon ? "#FFFFFF" : "#4A2FB5");
    }

    // ───────── Điều hướng nhanh ─────────
    private async void OnXemDonHangTapped(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(AdminOrdersPage));
    private async void OnXemBaoCaoTapped(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(AdminReportsPage));
    private async void OnTaiXeTapped(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(AdminDriverListPage));
    private async void OnKhachHangTapped(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(AdminCustomerListPage));
    private async void OnDanhSachGianHangTapped(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(AdminVendorListPage));
    private async void OnGiamSatClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(AdminGiamSatPage));
    private async void OnCauHinhClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(AdminConfigPage));
    private async void OnVanDeTapped(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(AdminIssuesPage));

    /// <summary>"Đơn hàng gần đây" (5 đơn mới nhất) và "Top gian hàng" (theo doanh thu đơn hoàn thành).</summary>
    private void NapDonVaTop()
    {
        try
        {
            var tatCa = MockData.TatCaDonHangHeThong.ToList();

            DsDonGanDay.Children.Clear();
            foreach (var d in tatCa.OrderByDescending(x => x.NgayDat).Take(5))
            {
                var (mauNen, mauChu) = d.TrangThai switch
                {
                    TrangThaiDonHang.HoanThanh => ("#DCFCE7", "#15803D"),
                    TrangThaiDonHang.DaHuy => ("#FEE2E2", "#DC2626"),
                    TrangThaiDonHang.DangGiao => ("#DBEAFE", "#1D4ED8"),
                    _ => ("#FEF3C7", "#B45309"),
                };
                var chip = new Border
                {
                    StrokeThickness = 0, Padding = new Thickness(8, 2), BackgroundColor = Color.FromArgb(mauNen),
                    StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(10) },
                    HorizontalOptions = LayoutOptions.Start,
                    Content = new Label { Text = d.NhanHienThi, FontSize = 10.5, FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb(mauChu) },
                };
                var trai = new VerticalStackLayout { Spacing = 2 };
                trai.Add(new Label { Text = $"{d.KhachTen} · {d.TenGianHang}", FontSize = 13, FontAttributes = FontAttributes.Bold, LineBreakMode = LineBreakMode.TailTruncation });
                trai.Add(new Label { Text = d.NgayDat.ToString("HH:mm · dd/MM"), FontSize = 11, TextColor = Colors.Gray });
                trai.Add(chip);
                var dong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 8 };
                dong.Add(trai, 0, 0);
                dong.Add(new Label { Text = AdminUi.Tien(d.TongThanhToan), FontSize = 13, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center, TextColor = Color.FromArgb(AdminUi.Tim) }, 1, 0);
                DsDonGanDay.Add(dong);
            }
            if (DsDonGanDay.Children.Count == 0)
                DsDonGanDay.Add(new Label { Text = "Chưa có đơn hàng nào.", FontSize = 12.5, TextColor = Colors.Gray });

            DsTopGianHang.Children.Clear();
            var top = tatCa.GroupBy(x => x.GianHangId)
                .Select(g => new
                {
                    Id = g.Key,
                    Ten = g.First().TenGianHang,
                    SoDon = g.Count(),
                    DoanhThu = g.Where(x => x.TrangThai == TrangThaiDonHang.HoanThanh).Sum(x => x.TongThanhToan),
                })
                .OrderByDescending(x => x.DoanhThu).ThenByDescending(x => x.SoDon)
                .Take(5).ToList();
            int hang = 1;
            foreach (var t in top)
            {
                var huy = new Border
                {
                    WidthRequest = 28, HeightRequest = 28, StrokeThickness = 0, BackgroundColor = Color.FromArgb(hang <= 3 ? "#8B5CF6" : "#C4B5FD"),
                    StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(14) },
                    Content = new Label { Text = hang.ToString(), FontSize = 12, FontAttributes = FontAttributes.Bold, TextColor = Colors.White, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center },
                };
                var giua = new VerticalStackLayout { Spacing = 1, VerticalOptions = LayoutOptions.Center };
                giua.Add(new Label { Text = t.Ten, FontSize = 13, FontAttributes = FontAttributes.Bold, LineBreakMode = LineBreakMode.TailTruncation });
                giua.Add(new Label { Text = $"{t.SoDon} đơn", FontSize = 11, TextColor = Colors.Gray });
                var dong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 10 };
                dong.Add(huy, 0, 0);
                dong.Add(giua, 1, 0);
                dong.Add(new Label { Text = AdminUi.Tien(t.DoanhThu), FontSize = 13, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center, TextColor = Color.FromArgb(AdminUi.Tim) }, 2, 0);
                DsTopGianHang.Add(dong);
                hang++;
            }
            if (top.Count == 0)
                DsTopGianHang.Add(new Label { Text = "Chưa có dữ liệu gian hàng.", FontSize = 12.5, TextColor = Colors.Gray });
        }
        catch (Exception ex) { CrashLog.Ghi("AdminHomeDonVaTop", ex); }
    }

    private async void OnTatCaChucNangClicked(object sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(AdminHubPage));

    /// <summary>Danh sách việc cần xử lý (online: từ API; ngoại tuyến: tính từ dữ liệu cục bộ).</summary>
    private async Task NapCanXuLyAsync()
    {
        try
        {
            var viec = await AdminViecService.LayAsync();
            DsCanXuLy.Children.Clear();
            foreach (var v in viec.Take(5)) DsCanXuLy.Add(AdminViecService.DungDong(v));
            LblKhongViec.IsVisible = viec.Count == 0;
            LblSoThongBao.Text = viec.Count > 9 ? "9+" : viec.Count.ToString();
            HuyHieuChuong.IsVisible = viec.Count > 0;
        }
        catch (Exception ex) { CrashLog.Ghi("AdminHomeCanXuLy", ex); LblKhongViec.IsVisible = true; }
    }

    private async void OnXemThongBaoTapped(object? sender, EventArgs e)
    {
        try { await Shell.Current.GoToAsync(nameof(AdminNotificationsPage)); }
        catch (Exception ex) { CrashLog.Ghi("AdminHome -> Thông báo", ex); }
    }

    private void NapTongQuan()
    {
        var admin = MockData.QuanTriVienHienTai;
        var now = DateTime.Now;
        LblChaoAdmin.Text = $"Xin chào, {admin.HoTen}";
        LblVaiTro.Text = $"🔐 Vai trò: {admin.VaiTro.Nhan()}";
        LblAvatar.Text = LayChuCai(admin.HoTen);
        var thu = now.DayOfWeek == DayOfWeek.Sunday ? "Chủ nhật" : $"Thứ {(int)now.DayOfWeek + 1}";
        LblNgayGio.Text = $"{thu}, {now:dd/MM/yyyy} • {now:HH:mm}";

        var tatCa = MockData.TatCaDonHangHeThong.ToList();
        var homNay = tatCa.Where(d => d.NgayDat.Date == now.Date && d.TrangThai != TrangThaiDonHang.DaHuy).ToList();
        var homQua = tatCa.Count(d => d.NgayDat.Date == now.Date.AddDays(-1) && d.TrangThai != TrangThaiDonHang.DaHuy);
        LblDonTrongNgay.Text = homNay.Count.ToString();
        TrangTri(LblSubDon, homNay.Count - homQua, "so với hôm qua", phanTram: false);

        var dtNay = homNay.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).Sum(d => d.TongTien);
        var dtQua = tatCa.Where(d => d.NgayDat.Date == now.Date.AddDays(-1) && d.TrangThai == TrangThaiDonHang.HoanThanh).Sum(d => d.TongTien);
        LblDoanhThuHomNay.Text = $"{dtNay:N0}đ";
        TrangTri(LblSubDoanhThu, dtQua == 0 ? (dtNay > 0 ? 100 : 0) : (double)((dtNay - dtQua) / dtQua * 100), "so với hôm qua", phanTram: true);

        var choXn = tatCa.Count(d => d.TrangThai == TrangThaiDonHang.ChoXacNhan);
        var dangLam = tatCa.Count(d => d.TrangThai == TrangThaiDonHang.DangLam);
        LblDangXuLy.Text = (choXn + dangLam).ToString();
        LblSubXuLy.Text = $"{choXn} chờ xác nhận · {dangLam} đang chuẩn bị";
        LblDangGiao.Text = tatCa.Count(d => d.TrangThai == TrangThaiDonHang.DangGiao).ToString();
        LblSoDonMoi.Text = choXn.ToString();
        HuyHieuDonMoi.IsVisible = choXn > 0;
        CapNhatSidebar(choXn);

        var gianHangDaDuyet = MockData.DanhSachGianHang.Where(g => g.TrangThaiDangKy == TrangThaiDangKyGianHang.DaDuyet).ToList();
        var soChoDuyet = MockData.DanhSachGianHang.Count(g => g.TrangThaiDangKy == TrangThaiDangKyGianHang.ChoDuyet);
        LblTongGianHang.Text = gianHangDaDuyet.Count.ToString();
        LblTongKhachHang.Text = MockData.DanhSachKhachHang.Count.ToString();
        LblTongTaiXe.Text = MockData.DanhSachTaiXe.Count.ToString();
        LblTaiXeOnline.Text = MockData.DanhSachTaiXe.Count(t => t.DangOnline).ToString();

        var online = DuLieuService.DangOnline;
        LblTrangThaiMayChu.Text = online ? "● Đang kết nối máy chủ" : "● Ngoại tuyến (dữ liệu trên máy)";
        LblTrangThaiMayChu.TextColor = Color.FromArgb(online ? "#15803D" : "#B45309");
        ChipMayChu.BackgroundColor = Color.FromArgb(online ? "#DCFCE7" : "#FEF3C7");
        LblSubGianHang.Text = soChoDuyet > 0 ? $"🏬 {soChoDuyet} gian hàng đang chờ duyệt" : "🏬 Không có gian hàng chờ duyệt";
        var soTaiXe = MockData.DanhSachTaiXe.Count(t => t.ChoDuyet);
        LblSoTaiXeChoDuyet.Text = soTaiXe > 0 ? $"🛵 {soTaiXe} tài xế đang chờ duyệt" : "🛵 Không có tài xế chờ duyệt";
    }

    private static string LayChuCai(string ten)
    {
        var p = (ten ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (p.Length == 0) return "AD";
        return p.Length == 1 ? p[0][..1].ToUpper() : (p[0][..1] + p[^1][..1]).ToUpper();
    }

    /// <summary>Dòng xu hướng: ▲ xanh khi tăng, ▼ đỏ khi giảm, "–" khi không đổi.</summary>
    private static void TrangTri(Label lbl, double giaTri, string moc, bool phanTram)
    {
        var abs = Math.Abs(giaTri);
        var so = phanTram ? $"{abs:0.#}%" : $"{(int)abs}";
        if (Math.Abs(giaTri) < 0.0001) { lbl.Text = $"– Không đổi {moc}"; lbl.TextColor = Color.FromArgb("#6B7280"); }
        else if (giaTri > 0) { lbl.Text = $"▲ {so} {moc}"; lbl.TextColor = Color.FromArgb("#16A34A"); }
        else { lbl.Text = $"▼ {so} {moc}"; lbl.TextColor = Color.FromArgb("#DC2626"); }
    }

    private void OnRefreshing(object? sender, EventArgs e)
    {
        NapTongQuan();
        NapDonVaTop();
        NapBieuDo();
        _ = NapCanXuLyAsync();
        RefreshTrangChu.IsRefreshing = false;
    }

    private async void OnNhanVienTapped(object sender, EventArgs e)
    {
        if (await PhanQuyenService.KiemTraAsync(this, Quyen.QuanLyNhanVien))
            await Shell.Current.GoToAsync(DuLieuService.DangOnline ? nameof(AdminStaffOnlinePage) : nameof(AdminStaffPage));
    }

    private async void OnNhatKyTapped(object sender, EventArgs e)
    {
        if (await PhanQuyenService.KiemTraAsync(this, Quyen.XemNhatKy)) await Shell.Current.GoToAsync(nameof(AdminAuditLogPage));
    }

    private async void OnDuyetTaiXeTapped(object sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(AdminDriverApprovalPage));
    private async void OnBanDoTapped(object sender, EventArgs e) => await BanDoPage.MoAsync();
    private async void OnDuyetGianHangTapped(object sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(AdminVendorApprovalPage));
    private async void OnKhuyenMaiTapped(object sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(AdminPromotionsPage));
    private async void OnThongKeTapped(object sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(AdminStatisticsPage));

    private async void OnDangXuatClicked(object sender, EventArgs e)
    {
        try
        {
            bool xacNhan = await DisplayAlert("Đăng xuất", "Bạn có chắc muốn đăng xuất khỏi cổng quản trị?", "Đăng xuất", "Hủy");
            if (!xacNhan) return;

            NhatKyService.GhiQuanTri("Đăng xuất", chiTiet: NhatKyService.ThietBi());
            Services.Phien.DangXuat();
            await Shell.Current.GoToAsync("//dang-nhap");
        }
        catch (Exception ex) { await Services.DangXuatHelper.LoiAsync(ex); }
    }

    private async void OnDoiMatKhauClicked(object sender, EventArgs e)
        => await Shell.Current.GoToAsync($"{nameof(DoiMatKhauPage)}?VaiTro=QuanTri");
}
