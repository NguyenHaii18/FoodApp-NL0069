using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Tài xế báo sự cố / sai lệch thu nhập, COD và theo dõi trạng thái xử lý.
/// GET/POST api/mobile/tai-xe/su-co. Mở kèm ?loai=... (chọn sẵn loại) và ?don=... (mã đơn).
/// </summary>
[QueryProperty(nameof(Loai), "loai")]
[QueryProperty(nameof(MaDon), "don")]
[QueryProperty(nameof(MoTa), "mota")]
public partial class DriverSuCoPage : ContentPage
{
    public string Loai { get; set; } = "";
    public string MaDon { get; set; } = "";
    public string MoTa { get; set; } = "";      // mô tả điền sẵn (VD: lý do giao thất bại)

    private List<SuCoLoaiDto> _loais = new();
    private bool _dangGui;

    public DriverSuCoPage() => InitializeComponent();

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (!string.IsNullOrWhiteSpace(MaDon) && string.IsNullOrWhiteSpace(EntryMaDon.Text)) EntryMaDon.Text = MaDon;
        if (!string.IsNullOrWhiteSpace(MoTa) && string.IsNullOrWhiteSpace(EdtMoTa.Text))
            EdtMoTa.Text = MoTa.Contains('%') ? Uri.UnescapeDataString(MoTa) : MoTa;
        await TaiAsync();
    }

    private async Task TaiAsync()
    {
        LblLoi.IsVisible = false;
        var r = await ApiClient.GetAsync<SuCoDanhSachDto>("api/mobile/tai-xe/su-co");
        if (!r.ThanhCong || r.DuLieu is null)
        {
            HienLoi(r.MatKetNoi || string.IsNullOrWhiteSpace(r.ThongDiep)
                ? "Cần kết nối máy chủ để gửi và xem báo cáo sự cố." : r.ThongDiep);
            return;
        }

        if (_loais.Count == 0)
        {
            _loais = r.DuLieu.Loais;
            // v91: loại sự cố bổ sung (máy chủ chưa có) — gửi bằng loại gần nhất + tiền tố ở mô tả
            foreach (var (ma, ten) in LoaiBoSung)
                if (!_loais.Any(l => l.Ma == ma)) _loais.Add(new SuCoLoaiDto { Ma = ma, Ten = ten });
            PickerLoai.ItemsSource = _loais.Select(l => l.Ten).ToList();
            var i = _loais.FindIndex(l => l.Ma == Loai);
            PickerLoai.SelectedIndex = i >= 0 ? i : -1;
        }
        Ve(r.DuLieu.Items);
    }

    private void Ve(List<SuCoItemDto> ds)
    {
        DsSuCo.Children.Clear();
        LblTrong.IsVisible = ds.Count == 0;
        foreach (var x in ds)
        {
            var ten = _loais.FirstOrDefault(l => l.Ma == x.Loai)?.Ten ?? x.Loai;
            var mau = x.TrangThai == "DaXuLy" ? "Success" : x.TrangThai == "DangXuLy" ? "Warning" : "TextGrey";
            var cot = new VerticalStackLayout { Spacing = 3 };
            cot.Children.Add(new Label { Text = ten + (x.MaDonHang is int m ? $" · đơn #{m}" : ""), FontAttributes = FontAttributes.Bold, FontSize = 13.5 });
            cot.Children.Add(new Label { Text = x.MoTa, FontSize = 12.5 });
            cot.Children.Add(new Label { Text = $"{NhanTrangThai(x.TrangThai)} · gửi {x.NgayTao:dd/MM HH:mm}", FontSize = 12, TextColor = DriverPalette.Get(mau) });
            if (!string.IsNullOrWhiteSpace(x.PhanHoiQuanTri))
                cot.Children.Add(new Label { Text = "Phản hồi từ quản trị: " + x.PhanHoiQuanTri, FontSize = 12.5, TextColor = DriverPalette.Get("Primary") });
            DsSuCo.Children.Add(new Frame
            {
                Padding = 12, CornerRadius = 12, HasShadow = false,
                BackgroundColor = DriverPalette.Get("CardColor"), BorderColor = DriverPalette.Get("BorderColor"),
                Content = cot
            });
        }
    }

    private static string NhanTrangThai(string t) => t switch
    {
        "DaXuLy" => "Đã xử lý",
        "DangXuLy" => "Đang xử lý",
        _ => "Chờ xử lý",
    };

    private static readonly (string Ma, string Ten)[] LoaiBoSung =
    {
        ("MatMang", "📶 Mất mạng / không có Internet"),
        ("LoiGps", "📍 Lỗi GPS / định vị sai"),
        ("KhachKhongCoMat", "🚪 Khách không có mặt tại điểm giao"),
        ("SuCoPhuongTien", "🔧 Sự cố phương tiện (hỏng xe, hết xăng…)"),
    };
    private static readonly Dictionary<string, (string Ma, string TienTo)> AnhXa = new()
    {
        ["MatMang"] = ("Khac", "[Mất mạng] "),
        ["LoiGps"] = ("Khac", "[Lỗi GPS] "),
        ["KhachKhongCoMat"] = ("KhachKhongNhan", "[Khách không có mặt] "),
        ["SuCoPhuongTien"] = ("Khac", "[Sự cố phương tiện] "),
    };
    private string? _anhUrl;

    /// <summary>Chọn/chụp 1 ảnh chứng minh, tải lên máy chủ; địa chỉ ảnh gửi kèm báo cáo (máy chủ nhận 1 ảnh mỗi báo cáo).</summary>
    private async void OnChonAnhClicked(object? sender, EventArgs e)
    {
        LblLoi.IsVisible = false;
        try
        {
            if (!DuLieuService.DangOnline) { HienLoi("Cần kết nối máy chủ để tải ảnh."); return; }
            var c = await DisplayActionSheet("Ảnh chứng minh", "Hủy", _anhUrl is null ? null : "Bỏ ảnh đã chọn", "Chọn từ thư viện", "Chụp ảnh");
            if (c is null or "Hủy") return;
            if (c == "Bỏ ảnh đã chọn") { _anhUrl = null; LblAnh.IsVisible = false; return; }
            var path = await AnhService.ChonVaLuuAsync("suco_" + DateTime.Now.ToString("HHmmss"), "Chọn ảnh", chup: c == "Chụp ảnh");
            if (path is null) return;
            var up = await ApiClient.PostFileAsync<UploadAnhDto>("api/upload/taixe", path);
            if (!up.ThanhCong || string.IsNullOrWhiteSpace(up.DuLieu?.ImageUrl)) { HienLoi(string.IsNullOrWhiteSpace(up.ThongDiep) ? "Không tải được ảnh." : up.ThongDiep); return; }
            _anhUrl = up.DuLieu!.ImageUrl;
            LblAnh.Text = "✓ Đã đính kèm 1 ảnh"; LblAnh.IsVisible = true;
        }
        catch (PermissionException) { HienLoi("Ứng dụng chưa được cấp quyền ảnh/camera."); }
    }

    /// <summary>Gọi / email điều phối (số liên hệ do máy chủ cấu hình).</summary>
    private async void OnLienHeDieuPhoiClicked(object? sender, EventArgs e)
    {
        await ChinhSachService.LamMoiAsync();
        var cs = ChinhSachService.HienTai;
        var ds = new List<string>();
        if (!string.IsNullOrWhiteSpace(cs.HotlineCskh)) ds.Add("📞 Gọi " + cs.HotlineCskh);
        if (!string.IsNullOrWhiteSpace(cs.EmailCskh)) ds.Add("✉ Gửi email " + cs.EmailCskh);
        if (ds.Count == 0) { await DisplayAlert("Điều phối", "Chưa có số liên hệ điều phối. Hãy gửi báo cáo ở trên, quản trị sẽ phản hồi tại đây.", "OK"); return; }
        var c = await DisplayActionSheet("Liên hệ điều phối", "Đóng", null, ds.ToArray());
        if (c is null or "Đóng") return;
        if (c.StartsWith("📞")) await LienLac.GoiAsync(cs.HotlineCskh);
        else { try { await Launcher.Default.OpenAsync("mailto:" + cs.EmailCskh); } catch { await FoodApp.Maui.Services.ClipboardAnToan.SaoChepAsync(cs.EmailCskh); } }
    }

    private async void OnGuiClicked(object? sender, EventArgs e)
    {
        if (_dangGui) return;
        LblLoi.IsVisible = false;
        LblThanhCong.IsVisible = false;

        if (PickerLoai.SelectedIndex < 0 || PickerLoai.SelectedIndex >= _loais.Count) { HienLoi("Vui lòng chọn loại sự cố."); return; }
        var moTa = EdtMoTa.Text?.Trim() ?? "";
        if (moTa.Length < 5) { HienLoi("Vui lòng mô tả sự cố (ít nhất 5 ký tự)."); return; }
        int? maDon = null;
        if (!string.IsNullOrWhiteSpace(EntryMaDon.Text))
        {
            if (!int.TryParse(EntryMaDon.Text.Trim(), out var d)) { HienLoi("Mã đơn không hợp lệ."); return; }
            maDon = d;
        }

        _dangGui = true; BtnGui.IsEnabled = false;
        try
        {
            var r = await ApiClient.PostAsync<object>("api/mobile/tai-xe/su-co",
                new
                {
                    loai = AnhXa.TryGetValue(_loais[PickerLoai.SelectedIndex].Ma, out var xa) ? xa.Ma : _loais[PickerLoai.SelectedIndex].Ma,
                    moTa = (AnhXa.TryGetValue(_loais[PickerLoai.SelectedIndex].Ma, out var xa2) ? xa2.TienTo : "") + moTa,
                    maDonHang = maDon,
                    anhMinhChung = _anhUrl,
                });
            if (!r.ThanhCong) { HienLoi(string.IsNullOrWhiteSpace(r.ThongDiep) ? "Không gửi được báo cáo." : r.ThongDiep); return; }

            EdtMoTa.Text = ""; _anhUrl = null; LblAnh.IsVisible = false;
            LblThanhCong.Text = "✓ Đã gửi báo cáo. Quản trị sẽ xử lý và phản hồi tại đây.";
            LblThanhCong.IsVisible = true;
            await TaiAsync();
        }
        finally { _dangGui = false; BtnGui.IsEnabled = true; }
    }

    private async void OnBackTapped(object? sender, EventArgs e) => await Shell.Current.GoToAsync("..");
    private void HienLoi(string t) { LblLoi.Text = t; LblLoi.IsVisible = true; }
}

public sealed class SuCoLoaiDto { public string Ma { get; set; } = ""; public string Ten { get; set; } = ""; }

public sealed class SuCoItemDto
{
    public int Id { get; set; }
    public string Loai { get; set; } = "";
    public string MoTa { get; set; } = "";
    public int? MaDonHang { get; set; }
    public string TrangThai { get; set; } = "ChoXuLy";
    public string? PhanHoiQuanTri { get; set; }
    public DateTime NgayTao { get; set; }
    public DateTime? NgayXuLy { get; set; }
}

public sealed class SuCoDanhSachDto
{
    public List<SuCoLoaiDto> Loais { get; set; } = new();
    public List<SuCoItemDto> Items { get; set; } = new();
}
