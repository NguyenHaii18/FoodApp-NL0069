using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Chi tiết thu nhập &amp; thanh toán của tài xế (dữ liệu thật từ GET api/mobile/tai-xe/thu-nhap):
/// tổng theo ngày/tuần/tháng, thu nhập từng chuyến, thưởng/phụ cấp, điều chỉnh/khấu trừ, tiền mặt thu từ khách,
/// lịch thanh toán và gửi yêu cầu khi có sai lệch.
/// </summary>
public partial class DriverThuNhapChiTietPage : ContentPage
{
    private static readonly (string Ma, string Ten)[] Ky = { ("ngay", "Ngày"), ("tuan", "Tuần"), ("thang", "Tháng") };
    private string _ky = "tuan";

    public DriverThuNhapChiTietPage()
    {
        InitializeComponent();
        DungChonKy();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await TaiAsync();
    }

    private async void OnRefreshing(object? sender, EventArgs e)
    {
        await TaiAsync();
        LamMoi.IsRefreshing = false;
    }

    private void DungChonKy()
    {
        ChonKy.Children.Clear();
        foreach (var (ma, ten) in Ky)
        {
            var m = ma;
            var chon = m == _ky;
            var b = new Button { Text = ten, FontSize = 13, HeightRequest = 36, CornerRadius = 18, Padding = new Thickness(18, 0) };
            if (chon) { b.BackgroundColor = DriverPalette.Get("Primary"); b.TextColor = Colors.White; }
            else
            {
                b.SetAppThemeColor(Button.BackgroundColorProperty, DriverPalette.Get("PrimarySoft"), Color.FromArgb("#2F2447"));
                b.SetAppThemeColor(Button.TextColorProperty, DriverPalette.Get("Primary"), Color.FromArgb("#C4B5FD"));
            }
            b.Clicked += async (_, _) => { _ky = m; DungChonKy(); await TaiAsync(); };
            ChonKy.Children.Add(b);
        }
    }

    // ---------- giao diện dùng chung ----------
    private static Label Chu(string text, double size = 13.5, bool dam = false, bool xam = false)
    {
        var l = new Label { Text = text, FontSize = size, FontAttributes = dam ? FontAttributes.Bold : FontAttributes.None };
        if (xam) l.SetAppThemeColor(Label.TextColorProperty, DriverPalette.Get("TextGrey"), Color.FromArgb("#A7A0BD"));
        return l;
    }

    private static Frame The(View noiDung)
    {
        var f = new Frame { Content = noiDung, Padding = new Thickness(14, 12), CornerRadius = 14, HasShadow = false };
        f.SetAppThemeColor(VisualElement.BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
        f.SetAppThemeColor(Microsoft.Maui.Controls.Frame.BorderColorProperty, DriverPalette.Get("BorderColor"), Color.FromArgb("#4D4180"));
        return f;
    }

    private static string Tien(decimal x, bool dau = false) => (dau && x > 0 ? "+" : "") + $"{x:N0}đ";

    private static Color MauTien(decimal x) => x < 0 ? DriverPalette.Get("Danger") : DriverPalette.Get("Primary");

    private static View Dong(string nhan, string giaTri, Color? mau = null, bool dam = false)
    {
        var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 10 };
        var a = Chu(nhan, 13, false, true);
        var b = Chu(giaTri, 13.5, dam);
        b.HorizontalTextAlignment = TextAlignment.End;
        if (mau is not null) b.TextColor = mau;
        g.Add(a, 0); g.Add(b, 1);
        return g;
    }

    private static Label TieuDe(string text)
    {
        var l = Chu(text, 15.5, true);
        l.Margin = new Thickness(0, 6, 0, 0);
        return l;
    }

    private static string TenLoai(string loai) => loai switch
    {
        "PhiGiao" => "Phí giao",
        "PhiGiaoThatBai" => "Phí giao (giao thất bại do khách)",
        "Thuong" => "Thưởng",
        "PhuCap" => "Phụ cấp",
        "Phat" => "Khấu trừ / phạt",
        "DieuChinh" => "Điều chỉnh",
        _ => loai,
    };

    private static string TenTrangThai(string tt) => tt == "DaThanhToan" ? "Đã thanh toán" : "Chờ thanh toán";

    private void Xoa()
    {
        while (Noi.Children.Count > 1) Noi.Children.RemoveAt(1);   // giữ lại nhãn lỗi
    }

    // ---------- tải & vẽ ----------
    private async Task TaiAsync()
    {
        LblLoi.IsVisible = false;
        if (string.IsNullOrEmpty(ApiClient.Token))
        {
            LblLoi.Text = "Cần đăng nhập tài xế với máy chủ để xem thu nhập thật.";
            LblLoi.IsVisible = true; Xoa(); return;
        }
        var r = await ApiClient.GetAsync<TnRes>($"api/mobile/tai-xe/thu-nhap?ky={_ky}");
        if (!r.ThanhCong || r.DuLieu is null)
        {
            LblLoi.Text = r.MatKetNoi || string.IsNullOrWhiteSpace(r.ThongDiep) ? "Cần kết nối máy chủ để xem thu nhập." : r.ThongDiep;
            LblLoi.IsVisible = true; Xoa(); return;
        }
        Ve(r.DuLieu);
    }

    private void Ve(TnRes d)
    {
        Xoa();
        var tenKy = Ky.First(k => k.Ma == _ky).Ten.ToLowerInvariant();

        // 1. Tổng quan
        var tq = new VerticalStackLayout { Spacing = 5 };
        tq.Children.Add(Chu($"Thu nhập {tenKy} này", 12.5, false, true));
        var lon = Chu(Tien(d.Tong.ThuNhap), 28, true); lon.TextColor = DriverPalette.Get("Primary");
        tq.Children.Add(lon);
        tq.Children.Add(Chu($"{d.Tong.SoChuyen} chuyến · {d.TuNgay:dd/MM} – {d.DenNgay:dd/MM/yyyy}", 12, false, true));
        tq.Children.Add(new BoxView { HeightRequest = 1, Margin = new Thickness(0, 4), Color = Color.FromArgb("#9CA3AF"), Opacity = 0.35 });
        tq.Children.Add(Dong("Phí giao hàng", Tien(d.Tong.PhiGiao)));
        tq.Children.Add(Dong("Thưởng", Tien(d.Tong.Thuong, true), MauTien(d.Tong.Thuong)));
        tq.Children.Add(Dong("Phụ cấp", Tien(d.Tong.PhuCap, true), MauTien(d.Tong.PhuCap)));
        tq.Children.Add(Dong("Điều chỉnh (cộng)", Tien(d.Tong.DieuChinhCong, true), MauTien(d.Tong.DieuChinhCong)));
        tq.Children.Add(Dong("Khấu trừ / điều chỉnh (trừ)", Tien(d.Tong.KhauTru), MauTien(d.Tong.KhauTru)));
        Noi.Children.Add(The(tq));

        var ba = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 8 };
        void O(int cot, string nhan, TnNhanh x)
        {
            var v = new VerticalStackLayout { Spacing = 2, HorizontalOptions = LayoutOptions.Center };
            v.Children.Add(Chu(nhan, 11.5, false, true));
            v.Children.Add(Chu(Tien(x.ThuNhap), 13.5, true));
            v.Children.Add(Chu($"{x.SoChuyen} chuyến", 11, false, true));
            ba.Add(v, cot, 0);
        }
        O(0, "Hôm nay", d.HomNay); O(1, "Tuần này", d.TuanNay); O(2, "Tháng này", d.ThangNay);
        Noi.Children.Add(The(ba));

        // 2. Tiền mặt thu từ khách
        var tm = new VerticalStackLayout { Spacing = 5 };
        tm.Children.Add(Chu("💵 Tiền mặt thu từ khách", 15, true));
        tm.Children.Add(Dong("Đã thu (30 ngày)", Tien(d.TienMat.DaThu30Ngay)));
        tm.Children.Add(Dong("Đang cầm (đơn đang giao, chưa thu)", Tien(d.TienMat.DangCam)));
        tm.Children.Add(Dong($"Cần nộp lại cho nền tảng ({d.TienMat.SoDonChuaNop} đơn)", Tien(d.TienMat.CanNop), DriverPalette.Get("Primary"), true));
        var nutCod = new Button { Text = "Đối soát COD ›", FontSize = 13, HeightRequest = 38, CornerRadius = 19, HorizontalOptions = LayoutOptions.Start, Padding = new Thickness(16, 0), Margin = new Thickness(0, 4, 0, 0) };
        nutCod.SetAppThemeColor(Button.BackgroundColorProperty, DriverPalette.Get("PrimarySoft"), Color.FromArgb("#2F2447"));
        nutCod.SetAppThemeColor(Button.TextColorProperty, DriverPalette.Get("Primary"), Color.FromArgb("#C4B5FD"));
        nutCod.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(DriverCodPage));
        tm.Children.Add(nutCod);
        Noi.Children.Add(The(tm));

        // 3. Lịch thanh toán
        var tt = new VerticalStackLayout { Spacing = 5 };
        tt.Children.Add(Chu("🗓 Lịch thanh toán", 15, true));
        tt.Children.Add(Dong("Chu kỳ", d.ThanhToan.ChuKy));
        var homNay = DateTime.Today;
        var ngay = d.ThanhToan.NgayThanhToanTiepTheo.Date;
        tt.Children.Add(Dong("Lần thanh toán tới", ngay == homNay ? "Hôm nay" : $"{ngay:dd/MM/yyyy} (còn {(ngay - homNay).Days} ngày)", null, true));
        tt.Children.Add(Dong("Chờ nền tảng thanh toán (30 ngày)", Tien(d.ThanhToan.ChoNenTangTra), DriverPalette.Get("Warning")));
        tt.Children.Add(Dong("Đã được thanh toán (30 ngày)", Tien(d.ThanhToan.DaDuocTra)));
        tt.Children.Add(Chu(d.ThanhToan.GhiChu, 11.5, false, true));
        Noi.Children.Add(The(tt));

        // 4. Thu nhập từng chuyến
        Noi.Children.Add(TieuDe($"🧾 Thu nhập từng chuyến ({d.Chuyen.Count})"));
        if (d.Chuyen.Count == 0) Noi.Children.Add(The(Chu("Chưa có chuyến nào trong kỳ này.", 13, false, true)));
        foreach (var c in d.Chuyen)
        {
            var cot = new VerticalStackLayout { Spacing = 1 };
            cot.Children.Add(Chu(c.MaDon is int m ? $"Đơn #{m} · {TenLoai(c.Loai)}" : TenLoai(c.Loai), 13.5, true));
            cot.Children.Add(Chu($"{c.ThoiGian:dd/MM HH:mm} · {TenTrangThai(c.TrangThai)}" + (c.CodThu is decimal cod and > 0 ? $" · thu hộ {cod:N0}đ" : ""), 11.5, false, true));
            if (!string.IsNullOrWhiteSpace(c.GhiChu)) cot.Children.Add(Chu(c.GhiChu!, 11.5, false, true));
            Noi.Children.Add(DongTheTapDuoc(cot, Tien(c.SoTien, true), MauTien(c.SoTien), c.MaDon, true));
        }

        // 5. Thưởng, phụ cấp, điều chỉnh/khấu trừ
        Noi.Children.Add(TieuDe($"🎁 Thưởng, phụ cấp, điều chỉnh & khấu trừ ({d.DieuChinh.Count})"));
        if (d.DieuChinh.Count == 0) Noi.Children.Add(The(Chu("Không có khoản nào trong kỳ này.", 13, false, true)));
        foreach (var c in d.DieuChinh)
        {
            var cot = new VerticalStackLayout { Spacing = 1 };
            cot.Children.Add(Chu(TenLoai(c.Loai) + (c.MaDon is int m ? $" · đơn #{m}" : ""), 13.5, true));
            cot.Children.Add(Chu($"{c.ThoiGian:dd/MM/yyyy} · {TenTrangThai(c.TrangThai)}", 11.5, false, true));
            if (!string.IsNullOrWhiteSpace(c.LyDo)) cot.Children.Add(Chu(c.LyDo!, 12, false, true));
            Noi.Children.Add(DongTheTapDuoc(cot, Tien(c.SoTien, true), MauTien(c.SoTien), c.MaDon, false));
        }

        // 6. Gửi yêu cầu khi có sai lệch
        var nut = new Button { Text = "⚠ Gửi yêu cầu khi có sai lệch thu nhập", FontSize = 13.5, HeightRequest = 46, CornerRadius = 23, Margin = new Thickness(0, 8, 0, 0) };
        nut.SetAppThemeColor(Button.BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
        nut.TextColor = DriverPalette.Get("Danger"); nut.BorderColor = DriverPalette.Get("Danger"); nut.BorderWidth = 1;
        nut.Clicked += async (_, _) => await Shell.Current.GoToAsync($"{nameof(DriverSuCoPage)}?loai=SaiLechThuNhap");
        Noi.Children.Add(nut);
    }

    /// <summary>Thẻ một khoản thu nhập; chạm để xem chi tiết đơn hoặc báo sai lệch cho khoản này.</summary>
    private Frame DongTheTapDuoc(View trai, string soTien, Color mau, int? maDon, bool laChuyen)
    {
        var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 10 };
        g.Add(trai, 0);
        var t = Chu(soTien, 14.5, true); t.TextColor = mau; t.VerticalOptions = LayoutOptions.Center;
        g.Add(t, 1);
        var khung = The(g);
        khung.GestureRecognizers.Add(new TapGestureRecognizer
        {
            Command = new Command(async () =>
            {
                var lua = new List<string>();
                if (maDon is not null) lua.Add("Xem chi tiết đơn");
                lua.Add("Báo sai lệch khoản này");
                var chon = await DisplayActionSheet(laChuyen ? "Chuyến giao" : "Khoản điều chỉnh", "Đóng", null, lua.ToArray());
                if (chon == "Xem chi tiết đơn" && maDon is int m) await Shell.Current.GoToAsync($"{nameof(DriverOrderDetailPage)}?id={m}");
                else if (chon == "Báo sai lệch khoản này")
                    await Shell.Current.GoToAsync($"{nameof(DriverSuCoPage)}?loai=SaiLechThuNhap" + (maDon is int d ? $"&don={d}" : ""));
            }),
        });
        return khung;
    }
}

// ---- DTO khớp JSON của GET api/mobile/tai-xe/thu-nhap ----
public class TnNhanh { public decimal ThuNhap { get; set; } public int SoChuyen { get; set; } }
public class TnTong
{
    public decimal ThuNhap { get; set; } public int SoChuyen { get; set; } public decimal PhiGiao { get; set; }
    public decimal Thuong { get; set; } public decimal PhuCap { get; set; } public decimal DieuChinhCong { get; set; } public decimal KhauTru { get; set; }
}
public class TnTienMat { public decimal DaThu30Ngay { get; set; } public decimal DangCam { get; set; } public decimal CanNop { get; set; } public int SoDonChuaNop { get; set; } }
public class TnThanhToan
{
    public decimal ChoNenTangTra { get; set; } public decimal DaDuocTra { get; set; } public string ChuKy { get; set; } = "";
    public DateTime NgayThanhToanTiepTheo { get; set; } public string GhiChu { get; set; } = "";
}
public class TnChuyen { public int? MaDon { get; set; } public DateTime ThoiGian { get; set; } public decimal SoTien { get; set; } public string Loai { get; set; } = ""; public string? GhiChu { get; set; } public string TrangThai { get; set; } = ""; public decimal? CodThu { get; set; } }
public class TnDieuChinh { public int? Id { get; set; } public int? MaDon { get; set; } public DateTime ThoiGian { get; set; } public decimal SoTien { get; set; } public string Loai { get; set; } = ""; public string? LyDo { get; set; } public string TrangThai { get; set; } = ""; }
public class TnRes
{
    public string Ky { get; set; } = ""; public DateTime TuNgay { get; set; } public DateTime DenNgay { get; set; }
    public TnNhanh HomNay { get; set; } = new(); public TnNhanh TuanNay { get; set; } = new(); public TnNhanh ThangNay { get; set; } = new();
    public TnTong Tong { get; set; } = new(); public TnTienMat TienMat { get; set; } = new(); public TnThanhToan ThanhToan { get; set; } = new();
    public List<TnChuyen> Chuyen { get; set; } = new(); public List<TnDieuChinh> DieuChinh { get; set; } = new();
}
