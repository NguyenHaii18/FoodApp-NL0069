namespace FoodApp.Maui.Views;

/// <summary>
/// Checklist chức năng ứng dụng tài xế (mục 4–8: giao hàng, đơn đang giao, thu nhập, thưởng và đánh giá, hỗ trợ).
/// Chạm một dòng để đánh dấu; tiêu đề nhóm có thể chạm để thu gọn / mở rộng. Trạng thái chỉ LƯU TRÊN THIẾT BỊ NÀY (Preferences).
/// </summary>
public sealed class AdminChucNangTaiXePage : AdminKyThuatTrang
{
    private static readonly (string Nhom, string[] Muc)[] Nhoms =
    {
        ("4. Giao hàng: lấy món và giao khách", new[] { "Xem đường đi đến nhà hàng", "Mở chỉ đường bằng bản đồ", "Xác nhận đã đến nhà hàng", "Xác nhận lấy món", "Xác minh mã nhận hàng nếu có", "Chụp ảnh bằng chứng lấy hàng khi cần", "Xem địa chỉ khách", "Chỉ đường đến khách", "Gọi điện cho khách", "Nhắn tin cho khách", "Cập nhật vị trí hành trình", "Báo giao hàng gặp sự cố", "Xác nhận đã đến điểm giao", "Xác nhận giao hàng", "Nhập OTP giao hàng", "Chụp ảnh bằng chứng giao hàng nếu quy trình yêu cầu", "Ghi nhận giao hàng thất bại", "Báo khách không liên lạc được", "Báo khách không có mặt", "Báo nhà hàng giao thiếu hoặc sai món" }),
        ("5. Quản lý đơn đang giao", new[] { "Xem danh sách đơn đang giao", "Xem chi tiết từng đơn", "Xem trạng thái đơn", "Xem thời gian còn lại", "Xem lộ trình", "Xem khoảng cách còn lại", "Cập nhật tiến độ", "Xử lý đơn bị hủy", "Báo sự cố", "Liên hệ điều phối viên", "Xem hướng dẫn xử lý đơn thất bại" }),
        ("6. Quản lý thu nhập", new[] { "Xem tổng thu nhập hôm nay", "Xem thu nhập theo tuần", "Xem thu nhập theo tháng", "Xem tiền giao từng đơn", "Xem thưởng", "Xem phụ cấp", "Xem khoản điều chỉnh", "Xem lịch sử thanh toán", "Xem số dư phải nhận", "Xem trạng thái đối soát", "Xem lịch sử rút tiền nếu có", "Xuất báo cáo thu nhập" }),
        ("7. Thưởng và đánh giá tài xế", new[] { "Xem chương trình thưởng", "Xem điều kiện đạt thưởng", "Theo dõi tiến độ thưởng", "Xem đánh giá từ khách hàng", "Xem tỷ lệ nhận đơn", "Xem tỷ lệ hoàn thành", "Xem tỷ lệ hủy", "Xem thời gian giao trung bình", "Xem lịch sử vi phạm", "Gửi yêu cầu khiếu nại" }),
        ("8. Hỗ trợ tài xế", new[] { "Gửi yêu cầu hỗ trợ", "Chat với điều phối", "Báo mất mạng", "Báo lỗi GPS", "Báo tai nạn hoặc sự cố phương tiện", "Báo nhà hàng chưa chuẩn bị món", "Báo khách không nghe máy", "Báo sai địa chỉ", "Gửi hình ảnh chứng minh", "Theo dõi tiến độ hỗ trợ" }),
    };

    public AdminChucNangTaiXePage() : base("Chức năng tài xế") { }

    private static bool Dat(int g, int i) { try { return Preferences.Default.Get($"taixecn-{g}-{i}", false); } catch { return false; } }
    private static void Dat(int g, int i, bool v) { try { Preferences.Default.Set($"taixecn-{g}-{i}", v); } catch { } }
    private static bool Mo(int g) { try { return Preferences.Default.Get($"taixecn-mo-{g}", true); } catch { return true; } }
    private static void Mo(int g, bool v) { try { Preferences.Default.Set($"taixecn-mo-{g}", v); } catch { } }

    protected override Task DungAsync()
    {
        var tong = Nhoms.Sum(n => n.Muc.Length);
        var soDat = 0;
        for (var g = 0; g < Nhoms.Length; g++) for (var i = 0; i < Nhoms[g].Muc.Length; i++) if (Dat(g, i)) soDat++;
        var mau = Color.FromArgb(soDat == tong ? AdminUi.Xanh : AdminUi.Tim);

        var dau = new VerticalStackLayout { Spacing = 4 };
        dau.Add(AdminUi.Nhan("Chức năng tài xế đã kiểm tra", 14, dam: true));
        var pt = AdminUi.Nhan($"{(int)Math.Round(100.0 * soDat / tong)}%", 28, dam: true); pt.TextColor = mau; dau.Add(pt);
        dau.Add(new ProgressBar { Progress = (double)soDat / tong, ProgressColor = mau });
        dau.Add(AdminUi.Nhan($"{soDat}/{tong} chức năng · đánh dấu sau khi thử trên app tài xế.", 11.5, mo: true));
        Nd.Add(KhoiTheo("", dau));

        for (var k = 0; k < Nhoms.Length; k++)
        {
            var g = k;
            var (nhom, muc) = Nhoms[g];
            var datNhom = Enumerable.Range(0, muc.Length).Count(i => Dat(g, i));
            var mo = Mo(g);
            var ds = new VerticalStackLayout { Spacing = 2 };
            var td = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            td.Add(AdminUi.Nhan($"{(mo ? "▾" : "▸")} {nhom}", 15, dam: true), 0, 0);
            td.Add(AdminUi.Nhan($"{datNhom}/{muc.Length}", 13, dam: true), 1, 0);
            var tapTd = new TapGestureRecognizer();
            tapTd.Tapped += async (_, _) => { Mo(g, !Mo(g)); Nd.Children.Clear(); await DungAsync(); };
            td.GestureRecognizers.Add(tapTd);
            ds.Add(td);
            ds.Add(new ProgressBar { Progress = (double)datNhom / muc.Length, ProgressColor = Color.FromArgb(datNhom == muc.Length ? AdminUi.Xanh : AdminUi.Tim) });
            if (mo)
                for (var j = 0; j < muc.Length; j++)
                {
                    var i = j;
                    var xong = Dat(g, i);
                    var dong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 10, Padding = new Thickness(0, 8) };
                    dong.Add(new Label { Text = xong ? "✅" : "⚪", FontSize = 18, VerticalOptions = LayoutOptions.Center }, 0, 0);
                    var chu = AdminUi.Nhan(muc[i], 13.5, mo: xong);
                    chu.VerticalOptions = LayoutOptions.Center;
                    if (xong) chu.TextDecorations = TextDecorations.Strikethrough;
                    dong.Add(chu, 1, 0);
                    var tap = new TapGestureRecognizer();
                    tap.Tapped += async (_, _) => { Dat(g, i, !Dat(g, i)); Nd.Children.Clear(); await DungAsync(); };
                    dong.GestureRecognizers.Add(tap);
                    ds.Add(dong);
                }
            Nd.Add(KhoiTheo("", ds));
        }

        var datLai = AdminUi.Nut("Đặt lại đánh dấu", AdminUi.Xam);
        datLai.Clicked += async (_, _) =>
        {
            if (!await DisplayAlert("Đặt lại?", $"Bỏ đánh dấu toàn bộ {tong} chức năng trên thiết bị này.", "Đặt lại", "Hủy")) return;
            for (var g = 0; g < Nhoms.Length; g++) for (var i = 0; i < Nhoms[g].Muc.Length; i++) Dat(g, i, false);
            Nd.Children.Clear();
            await DungAsync();
        };
        Nd.Add(KhoiTheo("", datLai));
        return Task.CompletedTask;
    }
}
