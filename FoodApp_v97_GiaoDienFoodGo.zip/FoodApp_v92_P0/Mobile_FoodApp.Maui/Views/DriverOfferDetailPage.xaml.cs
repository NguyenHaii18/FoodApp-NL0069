using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Chi tiết một đơn đang chờ tài xế nhận (từ danh sách "Đơn hàng sẵn sàng nhận" ở trang chủ): địa chỉ lấy/giao, phí giao,
/// tiền thu hộ, món. Từ đây: mở bản đồ đến quán, Nhận đơn hoặc Từ chối. Nhận/từ chối được thực hiện bởi trang chủ
/// (cùng một luồng xử lý với nút trên danh sách) thông qua <see cref="DriverHomePage.HanhDongCho"/>.
/// </summary>
[QueryProperty(nameof(MaDon), "id")]
public partial class DriverOfferDetailPage : ContentPage
{
    private DonHang? _don;
    public string MaDon { get; set; } = "";

    public DriverOfferDetailPage() => InitializeComponent();

    protected override void OnAppearing()
    {
        base.OnAppearing();
        _don = MockData.DonHangChoTaiXe.FirstOrDefault(d => d.Id == MaDon);
        if (_don is null)
        {
            LblLoi.Text = "Đơn không còn trong danh sách chờ nhận (có thể đã có tài xế khác nhận hoặc khách đã hủy).";
            LblLoi.IsVisible = true;
            Khung.IsVisible = false;
            ThanhNut.IsVisible = false;
            return;
        }
        LblLoi.IsVisible = false; Khung.IsVisible = true; ThanhNut.IsVisible = true;
        Ve(_don);
    }

    private void Ve(DonHang d)
    {
        LblMaDon.Text = $"Đơn #{d.Id}";
        LblPhi.Text = $"+{d.PhiGiaoHang:N0}đ";
        LblHenGio.IsVisible = d.LaDonHenGio; LblHenGio.Text = d.NhanHenGio;
        LblHan.IsVisible = d.CoHanPhanHoiTaiXe; LblHan.Text = d.NhanHanPhanHoi;
        LblQuan.Text = d.TenGianHang;
        LblDiaChiQuan.Text = d.DiaChiLayHang;
        LblDiaChiGiao.Text = d.DiaChiGiao;
        LblKcTg.IsVisible = d.CoKhoangCach; LblKcTg.Text = d.NhanKhoangCachThoiGian;
        LblHinhThuc.Text = $"Hình thức: {d.HinhThucThanhToan}";
        var tienMat = d.HinhThucThanhToan.Contains("mặt", StringComparison.OrdinalIgnoreCase);
        LblThu.Text = tienMat ? $"Cần thu hộ khách: {d.TongThanhToan:N0}đ" : "Đã thanh toán trước, không thu tiền";

        DsMon.Children.Clear();
        foreach (var m in d.ChiTiet)
        {
            var dong = new VerticalStackLayout { Spacing = 0 };
            dong.Children.Add(new Label { Text = $"{m.SoLuong} × {m.MonAn.TenMon}", FontSize = 13.5 });
            if (m.CoGhiChu) dong.Children.Add(new Label { Text = m.GhiChuHienThi, FontSize = 12, TextColor = DriverPalette.Get("TextGrey") });
            DsMon.Children.Add(dong);
        }
    }

    private async void OnBanDoQuanClicked(object? sender, EventArgs e)
    {
        if (_don is not null) await BanDoPage.MoAsync(_don.DiaChiLayHang);
    }

    private async void OnNhanClicked(object? sender, EventArgs e)
    {
        if (_don is null) return;
        DriverHomePage.HanhDongCho = ("nhan", _don.Id);
        await Shell.Current.GoToAsync("..");
    }

    private async void OnTuChoiClicked(object? sender, EventArgs e)
    {
        if (_don is null) return;
        DriverHomePage.HanhDongCho = ("tuchoi", _don.Id);
        await Shell.Current.GoToAsync("..");
    }
}
