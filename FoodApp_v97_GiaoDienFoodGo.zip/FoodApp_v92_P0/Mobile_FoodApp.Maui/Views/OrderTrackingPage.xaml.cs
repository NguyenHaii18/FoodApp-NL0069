using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Tab "Đơn hàng" của khách: lọc theo trạng thái, xem chi tiết từng đơn (món, phí giao, giảm giá,
/// thanh toán, địa chỉ), thanh tiến trình cho đơn đang xử lý, hủy đơn, đánh giá, đặt lại.
/// </summary>
public partial class OrderTrackingPage : ContentPage
{
    private enum Loc { TatCa, DangXuLy, HoanThanh, DaHuy }

    /// <summary>Đơn cần mở sẵn chi tiết khi vào tab (từ trang đặt hàng thành công, thông báo, lịch sử).</summary>
    public static string? DonCanMo { get; set; }

    private Loc _loc = Loc.TatCa;
    private readonly HashSet<string> _moRong = new();   // các đơn đang mở chi tiết

    public OrderTrackingPage()
    {
        InitializeComponent();
        CustomerNavBar.Gan(this, "orders");
        _tk = Resources;
        VeThanhLoc();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (!string.IsNullOrEmpty(DonCanMo)) { _moRong.Add(DonCanMo); _loc = Loc.TatCa; DonCanMo = null; VeThanhLoc(); }
        VeDanhSach();
        await DuLieuService.TaiDonHangKhachAsync();
        VeDanhSach();

        // Tự cập nhật trạng thái đơn / vị trí tài xế khi còn đơn đang xử lý (không cần kéo làm mới)
        _boDem ??= Dispatcher.CreateTimer();
        _boDem.Interval = TimeSpan.FromSeconds(15);
        _boDem.Tick -= OnBoDemTick;
        _boDem.Tick += OnBoDemTick;
        _boDem.Start();

        // Thời gian thực: có tín hiệu từ máy chủ thì gọi lại API ngay (bộ đếm 15 giây ở trên là phương án dự phòng)
        RealtimeService.CoThayDoi -= OnRealtime;
        RealtimeService.CoThayDoi += OnRealtime;
    }

    private IDispatcherTimer? _boDem;
    private bool _dangTai;
    private bool _taiLai;

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        _boDem?.Stop();
        RealtimeService.CoThayDoi -= OnRealtime;
    }

    private async void OnRealtime(RealtimeSuKien e)
    {
        if (!DuLieuService.DangOnline) return;
        _taiLai = true;
        if (_dangTai) return;                       // đang tải: vòng lặp bên dưới sẽ tải lại thêm một lần
        _dangTai = true;
        try
        {
            while (_taiLai) { _taiLai = false; await DuLieuService.TaiDonHangKhachAsync(); VeDanhSach(); }
        }
        catch { /* mất mạng: giữ nguyên danh sách, bộ đếm giờ sẽ thử lại */ }
        finally { _dangTai = false; }
    }

    private async void OnBoDemTick(object? sender, EventArgs e)
    {
        if (_dangTai || !DuLieuService.DangOnline) return;
        if (!MockData.LichSuDonHang.Any(d => DonCuaToi(d) && d.TrangThai is not (TrangThaiDonHang.HoanThanh or TrangThaiDonHang.DaHuy))) return;
        _dangTai = true;
        try { await DuLieuService.TaiDonHangKhachAsync(); VeDanhSach(); }
        catch { /* mất mạng: giữ nguyên danh sách, lần sau thử lại */ }
        finally { _dangTai = false; }
    }

    private async void OnKeoLamMoi(object? sender, EventArgs e)
    {
        await DuLieuService.TaiDonHangKhachAsync();
        VeDanhSach();
        LamMoi.IsRefreshing = false;
    }

    private static bool Toi => Application.Current?.RequestedTheme == AppTheme.Dark;

    /// <summary>Màu theo chủ đề: chế độ tối dùng bản tối của chữ phụ, đường kẻ và nền chip (tránh nền sáng/chữ mờ trên nền tối).</summary>
    private static ResourceDictionary? _tk;

    private static Color Mau(string khoa)
    {
        var tk = _tk ?? Application.Current!.Resources;
        if (Toi)
        {
            var khoaToi = khoa switch { "TextGrey" => "TextGreyDark", "BorderColor" => "BorderColorDark", "PrimarySoft" => "BorderColorDark", _ => khoa };
            if (tk.TryGetValue(khoaToi, out var v) && v is Color mt) return mt;
        }
        return (Color)tk[khoa];
    }

    /// <summary>Màu chữ nhấn (xanh): sáng hơn trong chế độ tối để đủ tương phản.</summary>
    private static Color MauChuNhan() => Toi ? Mau("PrimaryLight") : Mau("Primary");

    /// <summary>Đơn của khách đang đăng nhập (đơn cũ không ghi email thì coi là của mọi người).</summary>
    public static bool DonCuaToi(DonHang d) =>
        string.IsNullOrEmpty(d.KhachEmail) || string.Equals(d.KhachEmail, Phien.Khach?.Email, StringComparison.OrdinalIgnoreCase);

    private static bool DangXuLy(DonHang d) =>
        d.TrangThai is TrangThaiDonHang.ChoXacNhan or TrangThaiDonHang.DangLam or TrangThaiDonHang.DangGiao;

    // ---------- Thanh lọc ----------
    private void VeThanhLoc()
    {
        ThanhLoc.Children.Clear();
        (Loc, string)[] ds = { (Loc.TatCa, "Tất cả"), (Loc.DangXuLy, "Đang xử lý"), (Loc.HoanThanh, "Hoàn thành"), (Loc.DaHuy, "Đã hủy") };
        foreach (var (loc, nhan) in ds)
        {
            var chon = loc == _loc;
            var nut = new Button
            {
                Text = nhan, CornerRadius = 18, HeightRequest = 36, Padding = new Thickness(16, 0), FontSize = 13,
                BackgroundColor = chon ? Mau("Primary") : Mau("PrimarySoft"),
                TextColor = chon ? Colors.White : MauChuNhan(),
            };
            nut.Clicked += (_, _) => { _loc = loc; VeThanhLoc(); VeDanhSach(); };
            ThanhLoc.Children.Add(nut);
        }
    }

    /// <summary>v90: 9 trạng thái chi tiết khách theo dõi (chờ xác nhận → chuẩn bị → tìm/đã có tài xế → lấy món → giao → xong/hủy).</summary>
    public static string ChiTietTrangThai(DonHang d)
    {
        var coTx = !string.IsNullOrEmpty(d.TaiXeId);
        return d.TrangThai switch
        {
            TrangThaiDonHang.ChoXacNhan => "Chờ nhà hàng xác nhận",
            TrangThaiDonHang.DangLam when !d.SanSangGiao && !coTx => "Nhà hàng đang chuẩn bị món",
            TrangThaiDonHang.DangLam when !coTx => "Món đã xong · đang tìm tài xế",
            TrangThaiDonHang.DangLam when d.DaLayHang => "Tài xế đã lấy món",
            TrangThaiDonHang.DangLam when d.BuocTaiXe >= 1 => "Tài xế đã đến nhà hàng, đang nhận món",
            TrangThaiDonHang.DangLam => "Đã có tài xế · đang đến nhà hàng",
            TrangThaiDonHang.DangGiao => "Tài xế đang giao hàng",
            TrangThaiDonHang.HoanThanh => "Giao hàng thành công",
            _ => "Đơn hàng bị hủy",
        };
    }

    private static readonly Dictionary<string, string> _trangThaiDaBiet = new();

    /// <summary>v90: đơn đổi trạng thái so với lần tải trước → báo nhanh trên màn hình (lần đầu thấy đơn thì chỉ ghi nhớ).</summary>
    private static void BaoDonDoiTrangThai(IEnumerable<DonHang> ds)
    {
        foreach (var d in ds)
        {
            var moi = ChiTietTrangThai(d);
            if (_trangThaiDaBiet.TryGetValue(d.Id, out var cu) && cu != moi)
            {
                try { _ = CommunityToolkit.Maui.Alerts.Toast.Make($"Đơn #{d.Id}: {moi}", CommunityToolkit.Maui.Core.ToastDuration.Long).Show(); }
                catch (Exception ex) { CrashLog.Ghi("OrderTracking.Toast", ex); }
            }
            _trangThaiDaBiet[d.Id] = moi;
        }
    }

    // ---------- Danh sách ----------
    private void VeDanhSach()
    {
        BaoDonDoiTrangThai(MockData.LichSuDonHang.Where(DonCuaToi).ToList());
        var tatCa = MockData.LichSuDonHang.Where(DonCuaToi).OrderByDescending(d => d.NgayDat).ToList();
        var ds = tatCa.Where(d => _loc switch
        {
            Loc.DangXuLy => DangXuLy(d),
            Loc.HoanThanh => d.TrangThai == TrangThaiDonHang.HoanThanh,
            Loc.DaHuy => d.TrangThai == TrangThaiDonHang.DaHuy,
            _ => true,
        }).ToList();

        // đơn đang xử lý luôn nằm trên cùng
        ds = ds.OrderByDescending(DangXuLy).ThenByDescending(d => d.NgayDat).ToList();

        DanhSach.Children.Clear();
        LblTrong.IsVisible = ds.Count == 0;
        DanhSach.Children.Add(LblTrong);
        foreach (var don in ds) DanhSach.Children.Add(VeThe(don));
    }

    private View VeThe(DonHang don)
    {
        var dangXuLy = DangXuLy(don);
        var mo = _moRong.Contains(don.Id) || dangXuLy;

        var (mauNen, mauChu) = don.TrangThai switch
        {
            TrangThaiDonHang.HoanThanh => (Color.FromArgb("#DCFCE7"), Color.FromArgb("#15803D")),
            TrangThaiDonHang.DaHuy => (Color.FromArgb("#FEE2E2"), Color.FromArgb("#B91C1C")),
            TrangThaiDonHang.ChoXacNhan => (Color.FromArgb("#FEF3C7"), Color.FromArgb("#B45309")),
            _ => (Mau("PrimarySoft"), Mau("Primary")),
        };

        var thanTrong = new VerticalStackLayout { Spacing = 8 };

        // Hàng đầu: ảnh món + mã đơn / tên quán / tổng tiền + nhãn trạng thái / thời gian
        var dau = new Grid
        {
            ColumnSpacing = 12,
            ColumnDefinitions = { new ColumnDefinition(new GridLength(58)), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
        };
        var emoji = don.ChiTiet.FirstOrDefault()?.MonAn?.HinhAnh;
        dau.Add(new Frame
        {
            WidthRequest = 58, HeightRequest = 58, CornerRadius = 14, Padding = 0, HasShadow = false,
            BackgroundColor = Mau("PrimarySoft"), BorderColor = Colors.Transparent, VerticalOptions = LayoutOptions.Start,
            Content = new Label { Text = string.IsNullOrWhiteSpace(emoji) ? "🍽️" : emoji, FontSize = 28, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center },
        }, 0);
        var tieuDe = new VerticalStackLayout { Spacing = 2, VerticalOptions = LayoutOptions.Center };
        tieuDe.Children.Add(new Label { Text = $"#{don.Id}", FontSize = 11, TextColor = Mau("TextGrey") });
        tieuDe.Children.Add(new Label { Text = don.TenGianHang, FontAttributes = FontAttributes.Bold, FontSize = 14.5, LineBreakMode = LineBreakMode.TailTruncation });
        tieuDe.Children.Add(new Label { Text = $"{don.TongThanhToan:N0}đ", FontAttributes = FontAttributes.Bold, FontSize = 13.5 });
        dau.Add(tieuDe, 1);
        var phai = new VerticalStackLayout { Spacing = 8, VerticalOptions = LayoutOptions.Start, HorizontalOptions = LayoutOptions.End };
        phai.Children.Add(new Frame
        {
            BackgroundColor = mauNen, CornerRadius = 10, Padding = new Thickness(10, 3), HasShadow = false,
            BorderColor = Colors.Transparent, HorizontalOptions = LayoutOptions.End,
            Content = new Label { Text = don.NhanHienThi, FontSize = 11, FontAttributes = FontAttributes.Bold, TextColor = mauChu },
        });
        phai.Children.Add(new Label
        {
            Text = don.NgayDat.Date == DateTime.Today ? $"Hôm nay, {don.NgayDat:HH:mm}"
                 : don.NgayDat.Date == DateTime.Today.AddDays(-1) ? $"Hôm qua, {don.NgayDat:HH:mm}"
                 : $"{don.NgayDat:dd/MM, HH:mm}",
            FontSize = 11, TextColor = Mau("TextGrey"), HorizontalTextAlignment = TextAlignment.End,
        });
        dau.Add(phai, 2);
        thanTrong.Children.Add(dau);

        if (don.LaDonHenGio)
            thanTrong.Children.Add(new Label { Text = don.NhanHenGio, FontSize = 12, FontAttributes = FontAttributes.Bold, TextColor = MauChuNhan() });

        thanTrong.Children.Add(new Label { Text = "📌 " + ChiTietTrangThai(don), FontSize = 12.5, FontAttributes = FontAttributes.Bold,
            TextColor = don.TrangThai == TrangThaiDonHang.DaHuy ? Mau("Danger") : MauChuNhan() });
        if (dangXuLy) thanTrong.Children.Add(VeTienTrinh(don));
        if (dangXuLy && !string.IsNullOrEmpty(don.TaiXeId)) thanTrong.Children.Add(VeTaiXe(don));
        if (dangXuLy && don.ConChat)
        {
            var tenQuan = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == don.GianHangId)?.TenGianHang ?? "Quán";
            var nutQuan = new Button { Text = "🏪 Nhắn quán", FontSize = 12.5, CornerRadius = 18, HeightRequest = 36, Padding = new Thickness(12, 0),
                                       BackgroundColor = Mau("PrimarySoft"), TextColor = Mau("Primary"), HorizontalOptions = LayoutOptions.Start };
            nutQuan.Clicked += async (_, _) => await ChatPage.MoAsync(don.Id, "KhachHang", "🏪 " + tenQuan, "");
            thanTrong.Children.Add(nutQuan);
        }

        // Tóm tắt món
        var tomTat = string.Join(", ", don.ChiTiet.Select(c => $"{c.SoLuong}× {c.MonAn.TenMon}"));
        thanTrong.Children.Add(new Label { Text = tomTat, FontSize = 12.5, TextColor = Mau("TextGrey"), MaxLines = mo ? 0 : 2, LineBreakMode = LineBreakMode.TailTruncation });

        // Chi tiết
        if (mo)
        {
            thanTrong.Children.Add(new BoxView { HeightRequest = 1, Color = Mau("BorderColor") });
            foreach (var c in don.ChiTiet)
                thanTrong.Children.Add(Dong($"{c.SoLuong} × {c.MonAn.TenMon}" + (string.IsNullOrWhiteSpace(c.TuyChonHienThi) ? "" : $" ({c.TuyChonHienThi})"), $"{c.ThanhTien:N0}đ"));
            thanTrong.Children.Add(Dong("Tạm tính", $"{don.TongTien:N0}đ", xam: true));
            thanTrong.Children.Add(Dong("Phí giao hàng", $"{don.PhiGiaoHang:N0}đ", xam: true));
            if (don.GiamGia > 0)
                thanTrong.Children.Add(Dong(string.IsNullOrEmpty(don.MaKhuyenMai) ? "Giảm giá" : $"Giảm giá ({don.MaKhuyenMai})", $"-{don.GiamGia:N0}đ", xam: true));
            thanTrong.Children.Add(Dong("Thanh toán", don.HinhThucHienThi, xam: true));
            thanTrong.Children.Add(Dong("Giao đến", string.IsNullOrWhiteSpace(don.DiaChiGiao) ? "—" : don.DiaChiGiao, xam: true));
            if (!string.IsNullOrEmpty(don.DiaChiLayHang))
                thanTrong.Children.Add(Dong("Lấy hàng tại", don.DiaChiLayHang, xam: true));
            if (don.KhoangCachKm > 0)
                thanTrong.Children.Add(Dong("Khoảng cách", $"{don.KhoangCachHienThi}" + (don.ThoiGianDuKienPhut > 0 ? $" · ~{don.ThoiGianDuKienPhut} phút" : ""), xam: true));
            if (don.ThoiGianChuanBiPhut is > 0 && don.TrangThai == TrangThaiDonHang.DangLam && !don.SanSangGiao)
                thanTrong.Children.Add(Dong("Quán chuẩn bị", $"khoảng {don.ThoiGianChuanBiPhut} phút", xam: true));
            if (don.PhiDaDieuChinh)
                thanTrong.Children.Add(new Label { Text = $"✏ Phí giao đã điều chỉnh theo khoảng cách thực tế ({don.KhoangCachThucTeKm:0.#} km).", FontSize = 11.5, TextColor = Mau("TextGrey") });
            if (don.GiaoThatBai)
                thanTrong.Children.Add(new Label { Text = $"⚠ Giao thất bại: {don.LyDoThatBai}", FontSize = 12, FontAttributes = FontAttributes.Bold, TextColor = Mau("Danger") });
            if (don.DaHoanTien)
                thanTrong.Children.Add(new Label { Text = "✅ Đã hoàn tiền", FontSize = 12, TextColor = Mau("Success"), FontAttributes = FontAttributes.Bold });
        }

        // Tổng
        thanTrong.Children.Add(new BoxView { HeightRequest = 1, Color = Mau("BorderColor") });
        var tong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        var nutXem = new Label { Text = mo && !dangXuLy ? "Thu gọn ▲" : (dangXuLy ? "" : "Chi tiết ▼"), FontSize = 12.5, TextColor = MauChuNhan(), VerticalOptions = LayoutOptions.Center };
        if (!dangXuLy)
            nutXem.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => { if (!_moRong.Add(don.Id)) _moRong.Remove(don.Id); VeDanhSach(); })
            });
        tong.Add(nutXem, 0);
        tong.Add(new Label { Text = $"Tổng: {don.TongThanhToan:N0}đ", FontAttributes = FontAttributes.Bold, FontSize = 14, TextColor = MauChuNhan() }, 1);
        thanTrong.Children.Add(tong);

        // Nút hành động
        var hang = new HorizontalStackLayout { Spacing = 8 };
        if (don.TrangThai == TrangThaiDonHang.ChoXacNhan)
            hang.Children.Add(TaoNut("Hủy đơn", true, () => HuyAsync(don)));
        else if (don.TrangThai == TrangThaiDonHang.DangLam || don.TrangThai == TrangThaiDonHang.DangGiao)
            hang.Children.Add(TaoNut("Yêu cầu hủy / hoàn tiền", true, () => HuyAsync(don)));
        if (don.TrangThai == TrangThaiDonHang.HoanThanh)
        {
            if (don.KhachXacNhanLuc is null && !_daBaoChuaNhan.Contains(don.Id))
            {
                hang.Children.Add(TaoNut("✅ Đã nhận hàng", false, () => XacNhanNhanAsync(don)));
                hang.Children.Add(TaoNut("❗ Chưa nhận được", true, () => BaoChuaNhanAsync(don)));
            }
            hang.Children.Add(TaoNut("⭐ Đánh giá", false, () => DanhGiaAsync(don)));
        }
        if (don.CanThanhToanLai)
            hang.Children.Add(TaoNut("💳 Thanh toán VNPay", false, () => ThanhToanLaiAsync(don)));
        if (don.TrangThai != TrangThaiDonHang.ChoXacNhan && int.TryParse(don.Id, out _))
            hang.Children.Add(TaoNut("🆘 Hỗ trợ", true, () => Shell.Current.GoToAsync($"{nameof(HoTroPage)}?DonHangId={don.Id}")));
        if (!dangXuLy)
            hang.Children.Add(TaoNut("🔁 Đặt lại", false, () => DatLaiAsync(don)));
        if (don.TrangThai == TrangThaiDonHang.HoanThanh && don.KhachXacNhanLuc is { } xn)
            thanTrong.Children.Add(new Label { Text = $"✔ Bạn đã xác nhận nhận hàng lúc {xn:HH:mm dd/MM}", FontSize = 12, TextColor = Mau("Success") });
        else if (don.TrangThai == TrangThaiDonHang.HoanThanh && _daBaoChuaNhan.Contains(don.Id))
            thanTrong.Children.Add(new Label { Text = "❗ Bạn đã báo chưa nhận được hàng — Quản trị đang kiểm tra bằng chứng giao hàng.", FontSize = 12, TextColor = Mau("Danger") });
        if (hang.Children.Count > 0) thanTrong.Children.Add(hang);

        var the = new Frame
        {
            Style = (Style)Resources["CardFrame"],
            Content = thanTrong,
        };
        if (!dangXuLy)
            the.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(() => { if (!_moRong.Add(don.Id)) _moRong.Remove(don.Id); VeDanhSach(); })
            });
        return the;
    }

    /// <summary>Đơn VNPay chưa trả (đóng trang VNPay giữa chừng / giao dịch lỗi): xin link mới và chạy lại luồng thanh toán.</summary>
    private async Task ThanhToanLaiAsync(DonHang don)
    {
        var xong = await VnPayThanhToan.ThucHienAsync(this, don.Id, don.TongThanhToan);
        if (xong) don.TrangThaiThanhToan = "DaThanhToan";
        await DuLieuService.TaiDonHangKhachAsync();
        VeDanhSach();
    }

    private static View Dong(string trai, string phai, bool xam = false)
    {
        var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(new GridLength(2, GridUnitType.Star)) }, ColumnSpacing = 8 };
        g.Add(new Label { Text = trai, FontSize = 12.5, TextColor = xam ? Mau("TextGrey") : null }, 0);
        g.Add(new Label { Text = phai, FontSize = 12.5, HorizontalTextAlignment = TextAlignment.End }, 1);
        return g;
    }

    private static Button TaoNut(string chu, bool vien, Func<Task> hanhDong)
    {
        var nut = new Button
        {
            Text = chu, FontSize = 12.5, CornerRadius = 18, HeightRequest = 36, Padding = new Thickness(14, 0),
            BackgroundColor = vien ? Colors.Transparent : Mau("Primary"),
            TextColor = vien ? Mau("Danger") : Colors.White,
            BorderColor = vien ? Mau("Danger") : Colors.Transparent, BorderWidth = vien ? 1 : 0,
        };
        nut.Clicked += async (_, _) => await hanhDong();
        return nut;
    }

    private static int BuocTheoDoi(DonHang don) => don.TrangThai switch
    {
        TrangThaiDonHang.ChoXacNhan => 0,
        TrangThaiDonHang.DangLam => string.IsNullOrEmpty(don.TaiXeId) ? 1 : 2,
        TrangThaiDonHang.DangGiao => 3,
        TrangThaiDonHang.HoanThanh => 4,
        _ => 0,
    };

    /// <summary>5 bước: Chờ xác nhận → Đang chuẩn bị → Tài xế nhận → Đang giao → Hoàn thành.</summary>
    private static View VeTienTrinh(DonHang don)
    {
        var buoc = BuocTheoDoi(don);
        string[] nhan = { "Chờ xác nhận", "Chuẩn bị", "Tài xế nhận", "Đang giao", "Hoàn thành" };
        var g = new Grid { ColumnSpacing = 4, RowSpacing = 4, Margin = new Thickness(0, 4) };
        g.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        g.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        g.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        for (int i = 0; i < nhan.Length; i++)
        {
            g.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
            g.Add(new BoxView { HeightRequest = 6, CornerRadius = 3, Color = i <= buoc ? Mau("Primary") : Mau("BorderColor") }, i, 0);
            g.Add(new Label
            {
                Text = nhan[i], FontSize = 10, HorizontalTextAlignment = TextAlignment.Center,
                TextColor = i <= buoc ? MauChuNhan() : Mau("TextGrey"),
                FontAttributes = i == buoc ? FontAttributes.Bold : FontAttributes.None,
            }, i, 1);
        }
        if (don.DangChoTaiXe)
        {
            var goiY = new Label { Text = "🍳 Món đã xong, đang chờ tài xế nhận đơn", FontSize = 12, TextColor = MauChuNhan(), HorizontalTextAlignment = TextAlignment.Center };
            g.Add(goiY, 0, 2);
            Grid.SetColumnSpan(goiY, nhan.Length);
        }
        return g;
    }

    /// <summary>Thẻ tài xế đã nhận đơn: nhắn tin và gọi điện.</summary>
    private static View VeTaiXe(DonHang don)
    {
        var ten = string.IsNullOrWhiteSpace(don.TaiXeTen) ? "Tài xế" : don.TaiXeTen;
        var chu = new VerticalStackLayout { Spacing = 0, VerticalOptions = LayoutOptions.Center };
        chu.Children.Add(new Label { Text = $"🛵 {ten}", FontAttributes = FontAttributes.Bold, FontSize = 13.5, LineBreakMode = LineBreakMode.TailTruncation });
        chu.Children.Add(new Label { Text = "Tài xế giao hàng của bạn", FontSize = 11.5, TextColor = Mau("TextGrey") });

        Button Nut(string t, Func<Task> viec)
        {
            var n = new Button { Text = t, FontSize = 12.5, CornerRadius = 18, HeightRequest = 36, Padding = new Thickness(12, 0),
                                 BackgroundColor = Mau("Primary"), TextColor = Colors.White };
            n.Clicked += async (_, _) => await viec();
            return n;
        }

        var hang = new Grid { ColumnSpacing = 8, ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Auto) } };
        hang.Add(chu, 0);
        hang.Add(Nut("💬", () => ChatPage.MoAsync(don.Id, "KhachHang", ten, don.TaiXeSdt)), 1);
        hang.Add(Nut("📞", () => FoodApp.Maui.Services.LienLac.GoiAsync(don.TaiXeSdt)), 2);

        var st = new VerticalStackLayout { Spacing = 6 };
        st.Children.Add(hang);
        if (don.QuanBanGiaoLuc is { } banGiao && don.TrangThai == TrangThaiDonHang.DangLam)
            st.Children.Add(new Label { Text = $"🤝 Quán đã bàn giao món cho tài xế lúc {banGiao:HH:mm}", FontSize = 11.5, TextColor = Mau("TextGrey") });
        if (don.TrangThai == TrangThaiDonHang.DangGiao || don.TrangThai == TrangThaiDonHang.DangLam)
        {
            string eta = "";
            if (don.TrangThai == TrangThaiDonHang.DangGiao && GiaoHangService.ConLaiDenKhach(don) is { } cl)
                eta = $"Còn khoảng {cl.Km:0.#} km · ~{cl.Phut} phút (ước tính)\n";
            else if (don.ThoiGianDuKienPhut > 0 && don.KhoangCachKm > 0)
                eta = $"Quãng đường giao ~{don.KhoangCachHienThi} · ~{don.ThoiGianDuKienPhut} phút (ước tính)\n";
            // Server đặt viTriCu = true khi quá 90 giây không nhận được vị trí mới → báo "mất tín hiệu" (offline: tự tính theo giờ cập nhật).
            var matTinHieu = don.ViTriCapNhatLuc is { } moc && (don.ViTriCu || DateTime.Now - moc > TimeSpan.FromSeconds(90));
            var vt = don.ViTriCapNhatLuc is { } luc
                ? (matTinHieu
                    ? $"⚠ Mất tín hiệu GPS của tài xế — vị trí cuối lúc {luc:HH:mm:ss}. Vị trí trên bản đồ có thể không còn chính xác, bạn có thể gọi hoặc nhắn tài xế."
                    : $"📍 Vị trí cập nhật {luc:HH:mm:ss}")
                : "📍 Tài xế chưa chia sẻ vị trí";
            st.Children.Add(new Label { Text = eta + vt, FontSize = 11.5, TextColor = matTinHieu ? Mau("Danger") : Mau("TextGrey"),
                                        FontAttributes = matTinHieu ? FontAttributes.Bold : FontAttributes.None });
            st.Children.Add(Nut("🗺 Theo dõi trên bản đồ", async () =>
            {
                try { await TheoDoiBanDoPage.MoAsync(don); }   // bản đồ trong app: quán, địa chỉ nhận, tài xế (tự cập nhật)
                catch (Exception)
                {
                    if (don.TaiXeLat is { } lat && don.TaiXeLng is { } lng && await GiaoHangService.MoViTriAsync(lat, lng)) return;
                    await Application.Current!.MainPage!.DisplayAlert("Không mở được bản đồ", "Hãy kiểm tra kết nối Internet.", "OK");
                }
            }));
        }
        if (!string.IsNullOrEmpty(don.MaXacNhanGiao) && don.TrangThai == TrangThaiDonHang.DangGiao)
            st.Children.Add(new Label { Text = $"🔐 Mã nhận hàng: {don.MaXacNhanGiao}   (đọc mã này cho tài xế khi nhận món)", FontAttributes = FontAttributes.Bold, FontSize = 12.5 });

        return new Frame { BackgroundColor = Mau("PrimarySoft"), CornerRadius = 14, Padding = new Thickness(12, 8), HasShadow = false, BorderColor = Colors.Transparent, Content = st };
    }

    // ---------- Hành động ----------
    private static readonly HashSet<string> _daBaoChuaNhan = new();   // đơn khách đã báo "chưa nhận được" (server chặn gửi trùng)

    /// <summary>Khách bấm "Đã nhận hàng": PUT api/mobile/don-hang/{id}/xac-nhan-nhan.</summary>
    private async Task XacNhanNhanAsync(DonHang don)
    {
        if (!await DuLieuService.GhiAsync("PUT", $"api/mobile/don-hang/{don.Id}/xac-nhan-nhan")) return;
        don.KhachXacNhanLuc = DateTime.Now;
        VeDanhSach();
        await DisplayAlert("Cảm ơn bạn", DuLieuService.ChuThichGhi("Đã ghi nhận bạn nhận được hàng. Bạn có thể đánh giá đơn này."), "OK");
    }

    /// <summary>Khách báo "Chưa nhận được hàng": POST api/mobile/don-hang/{id}/chua-nhan → tạo khiếu nại cho Quản trị kiểm tra bằng chứng giao hàng.</summary>
    private async Task BaoChuaNhanAsync(DonHang don)
    {
        if (!await DisplayAlert("Chưa nhận được hàng",
                $"Đơn #{don.Id} đang ghi nhận là đã giao. Gửi khiếu nại để Quản trị kiểm tra ảnh/mã xác nhận giao hàng và liên hệ bạn?", "Gửi khiếu nại", "Đóng")) return;
        if (!await DuLieuService.GhiAsync("POST", $"api/mobile/don-hang/{don.Id}/chua-nhan")) return;
        _daBaoChuaNhan.Add(don.Id);
        if (!DuLieuService.DangOnline)      // offline demo: ghi vào danh sách vấn đề cục bộ như luồng hủy/hoàn tiền
            MockData.DanhSachVanDe.Insert(0, new VanDeHeThong
            {
                Id = "vd" + DateTime.Now.ToString("yyMMddHHmmss"),
                TieuDe = $"Chưa nhận được hàng đơn #{don.Id}",
                MoTa = $"Khách báo chưa nhận được hàng dù đơn đã giao tại {don.TenGianHang}.",
                NguonGoc = Phien.Khach?.HoTen is { Length: > 0 } ten ? ten : "Khách hàng",
                NgayBaoCao = DateTime.Now,
                TrangThai = TrangThaiVanDe.MoiPhatSinh,
            });
        VeDanhSach();
        await DisplayAlert(DuLieuService.LanGhiCuoi == DuLieuService.KetQuaGhi.DaDongBo ? "Đã gửi" : "Mới lưu trên máy",
            DuLieuService.LanGhiCuoi == DuLieuService.KetQuaGhi.DaDongBo
                ? "Quản trị sẽ kiểm tra bằng chứng giao hàng và phản hồi bạn."
                : "Khiếu nại mới được lưu trên máy này, CHƯA gửi tới quản trị vì đang ngoại tuyến.", "OK");
    }
    private async Task DanhGiaAsync(DonHang don) =>
        await Shell.Current.GoToAsync(nameof(ReviewPage), new Dictionary<string, object> { { "DonHang", don } });

    /// <summary>Đặt lại: mở menu quán để chọn món (quán còn hoạt động).</summary>
    private async Task DatLaiAsync(DonHang don)
    {
        var gh = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == don.GianHangId);
        if (gh is null || gh.TaiKhoanBiKhoa)
        {
            await DisplayAlert("Không thể đặt lại", "Quán này hiện không còn hoạt động.", "OK");
            return;
        }
        var tt = ThongTinQuan.Tao(gh);
        if (!tt.CoTheDat)
        {
            await DisplayAlert("Quán chưa nhận đơn", tt.LyDoKhongDat, "OK");
            return;
        }
        if (GioHangService.Gio.Count > 0 &&
            !await DisplayAlert("Thay giỏ hàng", $"Giỏ hàng đang có món. Thay bằng các món của đơn #{don.Id} ({gh.TenGianHang})?", "Thay giỏ", "Giữ giỏ cũ")) return;

        // Đặt lại: đưa đúng món/số lượng/ghi chú của đơn cũ vào giỏ (bỏ món đã ngừng bán) rồi mở giỏ hàng
        GioHangService.LamTrong();
        var soMon = 0; var boQua = new List<string>();
        foreach (var c in don.ChiTiet)
        {
            var mon = MockData.DanhSachMonAn.FirstOrDefault(m => m.Id == c.MonAn.Id);
            if (mon is null || !mon.ConHang || mon.TamNgungBan) { boQua.Add(c.MonAn.TenMon); continue; }
            GioHangService.Them(mon, c.SoLuong, c.GhiChu ?? "", GioHangService.TuyChonTuTen(mon, GioHangService.TachTuyChon(c.TuyChonHienThi)));
            soMon += c.SoLuong;
        }
        if (soMon == 0)
        {
            await DisplayAlert("Không thể đặt lại", "Các món trong đơn này hiện đã ngừng bán hoặc hết hàng.", "OK");
            return;
        }
        await GioHangService.LuuAsync();
        if (boQua.Count > 0)
            await DisplayAlert("Một số món không còn bán", "Đã bỏ qua: " + string.Join(", ", boQua) + ".", "Đã hiểu");
        await Shell.Current.GoToAsync(nameof(PaymentPage), new Dictionary<string, object>
        {
            { "GioHang", GioHangService.Gio }, { "TenGianHang", gh.TenGianHang }, { "GianHangId", gh.Id },
        });
    }

    /// <summary>
    /// Chờ xác nhận: hủy ngay và hoàn tiền tự động.
    /// Đang chuẩn bị/đang giao: gửi yêu cầu để quản trị viên xử lý (hiện ở trang Vấn đề hệ thống).
    /// </summary>
    private async Task HuyAsync(DonHang don)
    {
        if (don.TrangThai == TrangThaiDonHang.ChoXacNhan)
        {
            if (!await DisplayAlert("Hủy đơn", $"Hủy đơn #{don.Id}? Tiền sẽ được hoàn lại theo hình thức bạn đã thanh toán.", "Hủy đơn", "Giữ đơn")) return;
            if (!await DuLieuService.GhiAsync("PUT", $"api/mobile/don-hang/{don.Id}/huy")) return;
            don.TrangThai = TrangThaiDonHang.DaHuy;
            Services.KhuyenMaiService.HoanSuDung(don.MaKhuyenMai, don.KhachEmail);   // trả lại lượt dùng voucher
            don.DaHoanTien = true;
            if (string.IsNullOrWhiteSpace(don.LyDoTuChoi)) don.LyDoTuChoi = "Khách hàng hủy đơn";
            DoiTacService.GuiThongBao(don.GianHangId, ThongBaoGianHang.HuyDon, "Khách đã hủy đơn",
                $"Đơn #{don.Id} đã bị khách hàng hủy trước khi quán xác nhận.", don.Id);
            VendorLocalStore.Luu();
            VeDanhSach();
            await DisplayAlert("Đã hủy", DuLieuService.LanGhiCuoi == DuLieuService.KetQuaGhi.DaDongBo
                ? "Đơn đã hủy và được hoàn tiền."
                : DuLieuService.ChuThichGhi("Đơn đã hủy trên máy này (chưa có hoàn tiền thật)."), "OK");
            return;
        }

        if (!await DisplayAlert("Yêu cầu hủy / hoàn tiền",
                "Gian hàng đã nhận đơn. Gửi yêu cầu để quản trị viên xem xét và hoàn tiền theo quy định?", "Gửi yêu cầu", "Đóng")) return;

        var vanDe = new VanDeHeThong
        {
            Id = "vd" + DateTime.Now.ToString("yyMMddHHmmss"),
            TieuDe = $"Yêu cầu hủy/hoàn tiền đơn #{don.Id}",
            MoTa = $"Khách yêu cầu hủy đơn đang ở trạng thái \"{don.TrangThai.Nhan()}\" tại {don.TenGianHang}.",
            NguonGoc = Phien.Khach?.HoTen is { Length: > 0 } ten ? ten : "Khách hàng",
            NgayBaoCao = DateTime.Now,
            TrangThai = TrangThaiVanDe.MoiPhatSinh,
        };
        if (!await DuLieuService.GhiAsync("POST", "api/mobile/van-de",
                new { donHangId = don.Id, tieuDe = vanDe.TieuDe, moTa = vanDe.MoTa })) return;
        MockData.DanhSachVanDe.Insert(0, vanDe);
        await DisplayAlert(DuLieuService.LanGhiCuoi == DuLieuService.KetQuaGhi.DaDongBo ? "Đã gửi" : "Mới lưu trên máy",
            DuLieuService.LanGhiCuoi == DuLieuService.KetQuaGhi.DaDongBo
                ? "Yêu cầu đã được gửi tới quản trị viên."
                : "Yêu cầu mới được lưu trên máy này, CHƯA gửi tới quản trị viên vì đang ngoại tuyến.", "OK");
    }
}
