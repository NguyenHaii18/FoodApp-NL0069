namespace FoodApp.Maui.Views;

/// <summary>
/// Ô chọn NGÀY + GIỜ + PHÚT dùng cho khuyến mãi. Thay cặp DatePicker/TimePicker gốc vì TimePicker trên Windows
/// bỏ qua định dạng 24 giờ (hiện AM/PM, bị cắt chữ) và khó chọn nhanh.
///  - Ngày: DatePicker (dd/MM/yyyy), chiếm hết phần ngang còn lại.
///  - Giờ (00–23) và Phút (00–59): hai danh sách chọn, luôn theo 24 giờ.
/// Đọc/ghi qua <see cref="GiaTri"/>; sự kiện <see cref="DoiGiaTri"/> bắn khi người dùng đổi một trong ba phần.
/// </summary>
public class ChonNgayGio : ContentView
{
    private readonly DatePicker _ngay = new() { Format = "dd/MM/yyyy", MinimumDate = new DateTime(2020, 1, 1), MaximumDate = new DateTime(2100, 12, 31), VerticalOptions = LayoutOptions.Center };
    private readonly Picker _gio = new() { Title = "Giờ", WidthRequest = 76, VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Center };
    private readonly Picker _phut = new() { Title = "Phút", WidthRequest = 76, VerticalOptions = LayoutOptions.Center, HorizontalTextAlignment = TextAlignment.Center };
    private bool _dangDat;

    public event EventHandler? DoiGiaTri;

    public ChonNgayGio()
    {
        _gio.ItemsSource = Enumerable.Range(0, 24).Select(i => i.ToString("00")).ToList();
        _phut.ItemsSource = Enumerable.Range(0, 60).Select(i => i.ToString("00")).ToList();
        _gio.SelectedIndex = 0; _phut.SelectedIndex = 0;

        var luoi = new Grid
        {
            ColumnSpacing = 6,
            ColumnDefinitions =
            {
                new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto),
                new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Auto),
            },
        };
        luoi.Add(_ngay, 0);
        luoi.Add(_gio, 1);
        luoi.Add(new Label { Text = ":", FontSize = 18, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center }, 2);
        luoi.Add(_phut, 3);
        Content = luoi;

        _ngay.DateSelected += (_, _) => PhatSuKien();
        _gio.SelectedIndexChanged += (_, _) => PhatSuKien();
        _phut.SelectedIndexChanged += (_, _) => PhatSuKien();
    }

    private void PhatSuKien() { if (!_dangDat) DoiGiaTri?.Invoke(this, EventArgs.Empty); }

    /// <summary>Thời điểm đã chọn (giây = 0).</summary>
    public DateTime GiaTri
    {
        get
        {
            var d = _ngay.Date;
            return d.Date.AddHours(Math.Max(0, _gio.SelectedIndex)).AddMinutes(Math.Max(0, _phut.SelectedIndex));
        }
        set
        {
            _dangDat = true;
            try
            {
                var v = value < _ngay.MinimumDate ? _ngay.MinimumDate : value > _ngay.MaximumDate ? _ngay.MaximumDate : value;
                _ngay.Date = v.Date; _gio.SelectedIndex = v.Hour; _phut.SelectedIndex = v.Minute;
            }
            finally { _dangDat = false; }
        }
    }
}
