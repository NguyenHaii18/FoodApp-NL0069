using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// v91 — Tài xế: tỷ lệ hoàn thành / hủy / giao thành công, thời gian giao trung bình,
/// lịch sử cảnh báo - vi phạm (từ thông báo của quản trị) và gửi khiếu nại. Mốc thưởng lấy từ ThuNhapService (cùng mốc tính thu nhập).
/// </summary>
public sealed class DriverThuongTyLePage : ContentPage
{
    private readonly VerticalStackLayout _nd = new() { Spacing = 10, Padding = new Thickness(16, 12, 16, 28) };

    public DriverThuongTyLePage()
    {
        Title = "Tỷ lệ & vi phạm";
        BackgroundColor = DriverPalette.Get("Background");
        Content = new ScrollView { Content = _nd };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        try
        {
            await DuLieuService.TaiDonDaGiaoTaiXeAsync();
            await ThongBaoMayChuService.TaiAsync();
            ThuNhapService.CapNhatChiSo();
            Ve();
        }
        catch (Exception ex) { CrashLog.Ghi(nameof(DriverThuongTyLePage), ex); _nd.Children.Clear(); _nd.Add(new Label { Text = "Không tải được: " + ex.Message }); }
    }

    private static Border Khoi(string tieuDe, params View[] nd)
    {
        var st = new VerticalStackLayout { Spacing = 6 };
        st.Add(new Label { Text = tieuDe, FontAttributes = FontAttributes.Bold, FontSize = 15 });
        foreach (var v in nd) st.Add(v);
        return new Border
        {
            Padding = 14, StrokeThickness = 1, Stroke = DriverPalette.Get("BorderColor"),
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(14) }, Content = st,
        };
    }

    private static View Dong(string nhan, string giaTri, Color? mau = null)
    {
        var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 8 };
        g.Add(new Label { Text = nhan, FontSize = 13, TextColor = DriverPalette.Get("TextGrey") }, 0, 0);
        g.Add(new Label { Text = giaTri, FontSize = 13, FontAttributes = FontAttributes.Bold, HorizontalTextAlignment = TextAlignment.End, TextColor = mau ?? DriverPalette.Get("TextDark") }, 1, 0);
        return g;
    }

    private static View TienDo(string ten, int dat, (int SoDon, decimal Thuong)[] bac)
    {
        var st = new VerticalStackLayout { Spacing = 4 };
        var tiep = bac.FirstOrDefault(b => dat < b.SoDon);
        st.Add(new Label { Text = ten, FontAttributes = FontAttributes.Bold, FontSize = 13.5 });
        foreach (var b in bac)
            st.Add(new Label
            {
                Text = $"{(dat >= b.SoDon ? "✅" : "⬜")} Đạt {b.SoDon} đơn thành công → thưởng +{b.Thuong:N0}đ",
                FontSize = 12.5, TextColor = dat >= b.SoDon ? Colors.SeaGreen : DriverPalette.Get("TextGrey"),
            });
        var dich = tiep.SoDon == 0 ? bac[^1].SoDon : tiep.SoDon;
        st.Add(new ProgressBar { Progress = Math.Min(1.0, dat / (double)dich), ProgressColor = DriverPalette.Get("Primary") });
        st.Add(new Label
        {
            Text = tiep.SoDon == 0 ? $"Đã đạt {dat} đơn — mốc cao nhất 🎉" : $"Đã giao {dat}/{tiep.SoDon} đơn · còn {tiep.SoDon - dat} đơn để nhận +{tiep.Thuong:N0}đ",
            FontSize = 12, TextColor = DriverPalette.Get("TextGrey"),
        });
        return st;
    }

    private void Ve()
    {
        _nd.Children.Clear();
        var homNay = DateTime.Today;
        var xemThuong = new Button { Text = "🎁 Chương trình thưởng (mốc & tiến độ)", CornerRadius = 12, HeightRequest = 44, BackgroundColor = DriverPalette.Get("Primary"), TextColor = Colors.White };
        xemThuong.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(DriverThuongPage));
        _nd.Add(xemThuong);

        // Tỷ lệ — 30 ngày gần nhất
        var moc = homNay.AddDays(-29);
        var ds = MockData.DonHangDaGiaoCuaTaiXe.Where(d => (d.GiaoLuc ?? d.NgayDat) >= moc).ToList();
        var ok = ds.Where(d => !d.GiaoThatBai).ToList();
        var tong = ds.Count;
        string pt(int a) => tong == 0 ? "—" : $"{100.0 * a / tong:0.#}%";
        var phut = ok.Where(d => d.GiaoLuc is not null && (d.LayHangLuc ?? d.NgayDat) < d.GiaoLuc)
            .Select(d => (d.GiaoLuc!.Value - (d.LayHangLuc ?? d.NgayDat)).TotalMinutes).Where(m => m is > 0 and < 240).ToList();
        var diem = ok.Where(d => d.DiemTaiXe > 0).Select(d => (double)d.DiemTaiXe).ToList();
        _nd.Add(Khoi("📊 Tỷ lệ 30 ngày gần nhất",
            Dong("Số đơn đã nhận", tong.ToString()),
            Dong("Tỷ lệ hoàn thành", pt(ok.Count), tong > 0 && 100.0 * ok.Count / tong < 80 ? Colors.DarkOrange : Colors.SeaGreen),
            Dong("Tỷ lệ hủy / thất bại", pt(tong - ok.Count), tong - ok.Count > 0 ? (Color?)Colors.DarkOrange : null),
            Dong("Tỷ lệ nhận đơn", "Chưa có", null),
            Dong("Thời gian giao trung bình", phut.Count == 0 ? "—" : $"{phut.Average():0} phút"),
            Dong("Đánh giá của khách", diem.Count == 0 ? "Chưa có" : $"{diem.Average():0.0} ★ ({diem.Count} lượt)"),
            new Label { Text = "Tỷ lệ nhận đơn cần số lần được mời nhận đơn mà máy chủ chưa gửi về app nên chưa tính được ở bản này.", FontSize = 11.5, TextColor = DriverPalette.Get("TextGrey") }));

        var xemDanhGia = new Button { Text = "⭐ Xem đánh giá từ khách", CornerRadius = 12, HeightRequest = 42, BackgroundColor = DriverPalette.Get("PrimarySoft"), TextColor = DriverPalette.Get("Primary") };
        xemDanhGia.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(DriverRatingPage));
        _nd.Add(xemDanhGia);

        // Lịch sử vi phạm / cảnh báo
        var vp = ThongBaoMayChuService.DanhSach
            .Where(t => Chua(t.TieuDe, "cảnh báo", "vi phạm", "khóa", "phạt", "tạm ngưng") || Chua(t.NoiDung, "vi phạm", "cảnh báo", "phạt"))
            .OrderByDescending(t => t.Ngay).Take(20).ToList();
        var dsVp = new VerticalStackLayout { Spacing = 6 };
        if (vp.Count == 0) dsVp.Add(new Label { Text = "✅ Bạn chưa có cảnh báo hay vi phạm nào.", FontSize = 12.5, TextColor = Colors.SeaGreen });
        foreach (var t in vp)
            dsVp.Add(new Label { Text = $"⚠️ {t.Ngay:dd/MM/yyyy} · {t.TieuDe}\n{t.NoiDung}", FontSize = 12.5 });
        _nd.Add(Khoi("🚫 Lịch sử cảnh báo / vi phạm", dsVp));

        var kn = new Button { Text = "💬 Gửi khiếu nại / phản hồi", CornerRadius = 12, HeightRequest = 44, BackgroundColor = DriverPalette.Get("Primary"), TextColor = Colors.White };
        kn.Clicked += async (_, _) => await Shell.Current.GoToAsync($"{nameof(DriverSuCoPage)}?loai=Khac");
        _nd.Add(kn);
    }

    private static bool Chua(string? s, params string[] k) => !string.IsNullOrEmpty(s) && k.Any(x => s.Contains(x, StringComparison.OrdinalIgnoreCase));
}
