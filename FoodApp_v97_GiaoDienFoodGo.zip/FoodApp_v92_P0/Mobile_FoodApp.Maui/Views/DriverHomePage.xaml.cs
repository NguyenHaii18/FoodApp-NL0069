using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

public partial class DriverHomePage : ContentPage
{
    public DriverHomePage()
    {
        InitializeComponent();
    }

    private IDispatcherTimer? _timer;
    private static readonly HashSet<string> _daBaoDon = new();     // đơn chờ nhận đã báo cho tài xế (không báo lặp)
    private static bool _daKhoiTaoBao;
    private static int _chuaDocCu = -1;

    protected override void OnAppearing()
    {
        base.OnAppearing();
        TaiLai();
        _ = XuLyHanhDongChoAsync();      // nhận/từ chối đơn được chọn ở trang chi tiết (nếu có)
        _ = DongBoOnlineAsync();
        DriverPresenceService.CapNhat(MockData.TaiXeHienTai.DangOnline);     // v86: báo "còn kết nối" + nhận đề nghị đơn khi đang Online

        // Làm mới mỗi 60 giây: cập nhật đếm ngược hạn phản hồi và đơn mới (đơn quá hạn được server điều phối lại)
        _timer ??= Dispatcher.CreateTimer();
        _timer.Interval = TimeSpan.FromSeconds(60);
        _timer.Tick -= OnTimerTick;
        _timer.Tick += OnTimerTick;
        _timer.Start();

        // Thời gian thực: lời mời nhận đơn / đơn đổi hoặc bị hủy -> đồng bộ lại từ API ngay (bộ đếm 60 giây là dự phòng)
        RealtimeService.CoThayDoi -= OnRealtime;
        RealtimeService.CoThayDoi += OnRealtime;
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        _timer?.Stop();
        RealtimeService.CoThayDoi -= OnRealtime;
    }

    private void OnRealtime(RealtimeSuKien e)
    {
        if (!DuLieuService.DangOnline) return;
        if (MockData.DonHangDangGiaoCuaTaiXe is not null || !MockData.TaiXeHienTai.NhanDuocDon) _ = BaoThayDoiAsync();
        else _ = DongBoOnlineAsync();
    }

    private async void OnTimerTick(object? sender, EventArgs e)
    {
        if (MockData.DonHangDangGiaoCuaTaiXe is not null || !MockData.TaiXeHienTai.NhanDuocDon)
        {
            await BaoThayDoiAsync();       // đang giao hoặc tạm nghỉ vẫn báo đơn đổi / bị hủy
            return;
        }
        await DongBoOnlineAsync();
    }

    /// <summary>Online: kéo đơn chờ nhận từ API rồi vẽ lại danh sách. Offline: không làm gì.</summary>
    private async Task DongBoOnlineAsync()
    {
        await DuLieuService.TaiDonChoTaiXeAsync();
        NapDanhSachDonChoNhan();
        await CapNhatSoDonCuaToiAsync();
        await BaoThayDoiAsync();
    }

    private static void Rung()
    {
        try { Vibration.Default.Vibrate(TimeSpan.FromMilliseconds(500)); } catch { /* máy không hỗ trợ / chưa cấp quyền: bỏ qua */ }
    }

    /// <summary>Báo cho tài xế: có đơn mới được phân công / chờ nhận, hoặc có thông báo mới (đơn đổi, đơn bị hủy). Lần đầu chỉ ghi nhớ, không báo.</summary>
    private async Task BaoThayDoiAsync()
    {
        try
        {
            var dsDon = (DsDonChoNhan.ItemsSource as IEnumerable<DonHang>)?.ToList() ?? new List<DonHang>();
            var moi = dsDon.Where(d => _daBaoDon.Add(d.Id)).ToList();
            var baoDon = _daKhoiTaoBao && moi.Count > 0;
            _daKhoiTaoBao = true;

            await ThongBaoMayChuService.TaiAsync();
            var coTbMoi = _chuaDocCu >= 0 && ThongBaoMayChuService.ChuaDoc > _chuaDocCu;
            _chuaDocCu = ThongBaoMayChuService.ChuaDoc;

            if (baoDon)
            {
                Rung();
                var d0 = moi[0];
                await DisplayAlert("🔔 Có đơn mới", moi.Count == 1
                    ? $"Đơn #{d0.Id} · {d0.TenGianHang}\n{(d0.CoKhoangCach ? d0.NhanKhoangCachThoiGian : $"Công +{d0.PhiGiaoHang:N0}đ")}\nNhận hoặc từ chối trong thời hạn quy định."
                    : $"Có {moi.Count} đơn mới đang chờ bạn nhận.", "Xem");
            }
            else if (coTbMoi)
            {
                Rung();
                var tb = ThongBaoMayChuService.DanhSach.FirstOrDefault(t => !t.DaDoc);
                if (tb is not null) await DisplayAlert("🔔 " + tb.TieuDe, tb.NoiDung, "OK");
            }
            var soTb = DriverNotificationsPage.Dem();
            LblSoThongBao.Text = soTb > 99 ? "99+" : soTb.ToString();
            ChipThongBao.IsVisible = soTb > 0;
        }
        catch (Exception ex) { CrashLog.Ghi("DriverHome.BaoThayDoi", ex); }
    }

    private void TaiLai()
    {
        ThuNhapService.CapNhatChiSo();      // thu nhập hôm nay + điểm đánh giá tính lại từ lịch sử
        var soTb = DriverNotificationsPage.Dem();
        LblSoThongBao.Text = soTb > 99 ? "99+" : soTb.ToString();
        ChipThongBao.IsVisible = soTb > 0;
        LblThuongNong.Text = ThuNhapService.TienDoThuongNgay();
        NapHoSo();
        CapNhatDonDangGiao();
        NapDanhSachDonChoNhan();
        NapLichSu();
    }

    private void NapHoSo()
    {
        var taiXe = MockData.TaiXeHienTai;

        // Ảnh đại diện: ưu tiên ảnh người dùng chọn, không có thì dùng biểu tượng
        ImgAnhTaiXe.Source = taiXe.CoAnh ? ImageSource.FromFile(taiXe.AnhPath) : null;
        ImgAnhTaiXe.IsVisible = taiXe.CoAnh;
        LblAnhTaiXe.Text = taiXe.Anh;
        LblAnhTaiXe.IsVisible = !taiXe.CoAnh;

        LblTenTaiXe.Text = string.IsNullOrWhiteSpace(taiXe.HoTen) ? "Tài xế" : taiXe.HoTen;
        LblBienSo.Text = string.IsNullOrWhiteSpace(taiXe.BienSoXe)
            ? "Chưa có biển số — bấm Hồ sơ để cập nhật"
            : $"{taiXe.LoaiXe} · {taiXe.BienSoXe}";
        LblThuNhapHomNay.Text = $"{taiXe.TongThuNhapHomNay:N0}đ";
        LblSoDonHomNay.Text = taiXe.SoDonHomNay.ToString();
        LblDanhGia.Text = taiXe.DanhGia > 0 ? taiXe.DanhGia.ToString("0.0") : "Mới";

        SwitchOnline.Toggled -= OnSwitchOnlineToggled;
        SwitchHoatDong.Toggled -= OnSwitchHoatDongToggled;
        SwitchOnline.IsToggled = taiXe.DangOnline;
        SwitchHoatDong.IsToggled = taiXe.DangHoatDong;
        SwitchHoatDong.IsEnabled = taiXe.DangOnline;      // offline thì không có "sẵn sàng"
        SwitchOnline.Toggled += OnSwitchOnlineToggled;
        SwitchHoatDong.Toggled += OnSwitchHoatDongToggled;
        LblTrangThaiHoatDong.Text = taiXe.TrangThaiLamViec;
    }

    /// <summary>Đồng bộ trạng thái lên Web: SanSang = online và sẵn sàng; TamNghi = online nhưng tạm không nhận đơn; NgoaiTuyen = offline.</summary>
    private async Task GuiTrangThaiAsync()
    {
        var t = MockData.TaiXeHienTai;
        TaiXeStore.Luu();
        LblTrangThaiHoatDong.Text = t.TrangThaiLamViec;
        SwitchHoatDong.IsEnabled = t.DangOnline;
        DriverPresenceService.CapNhat(t.DangOnline);
        NapDanhSachDonChoNhan();
        if (DuLieuService.DangOnline)
            await DuLieuService.GhiAsync("PUT", "api/mobile/tai-xe/trang-thai", new { trangThai = t.NhanDuocDon ? "SanSang" : t.DangOnline ? "TamNghi" : "NgoaiTuyen" });
    }

    /// <summary>Trước khi vào Online: cảnh báo nếu mất mạng hoặc chưa cấp quyền vị trí / GPS tắt (không chặn, chỉ nhắc).</summary>
    private async Task KiemTraMangVaGpsAsync()
    {
        var van = new List<string>();
        try { if (Connectivity.Current.NetworkAccess != NetworkAccess.Internet) van.Add("• Điện thoại đang không có Internet — bạn sẽ không nhận được đơn mới."); } catch { }
        try
        {
            var q = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();
            if (q != PermissionStatus.Granted) q = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
            if (q != PermissionStatus.Granted) van.Add("• Chưa cấp quyền vị trí — khách và hệ thống không thấy vị trí của bạn.");
            else
            {
                var vt = await Geolocation.Default.GetLastKnownLocationAsync();
                if (vt is null) { try { vt = await Geolocation.Default.GetLocationAsync(new GeolocationRequest(GeolocationAccuracy.Medium, TimeSpan.FromSeconds(6))); } catch { } }
                if (vt is null) van.Add("• Chưa lấy được GPS — hãy bật Vị trí (GPS) của thiết bị.");
            }
        }
        catch { van.Add("• Không kiểm tra được quyền vị trí / GPS trên thiết bị này."); }
        if (van.Count > 0) await DisplayAlert("Kiểm tra trước khi nhận đơn", string.Join("\n", van), "Đã hiểu");
    }

    private async void OnSwitchOnlineToggled(object? sender, ToggledEventArgs e)
    {
        var t = MockData.TaiXeHienTai;
        if (!e.Value && MockData.DonHangDangGiaoCuaTaiXe is not null)
        {
            await DisplayAlert("Đang giao đơn", "Bạn đang có đơn chưa hoàn tất. Hãy giao xong rồi mới chuyển sang Offline.", "Đóng");
            SwitchOnline.Toggled -= OnSwitchOnlineToggled; SwitchOnline.IsToggled = true; SwitchOnline.Toggled += OnSwitchOnlineToggled;
            return;
        }
        if (e.Value) await KiemTraMangVaGpsAsync();
        t.DangOnline = e.Value;
        NhatKyService.Ghi("TaiXe", t.SoDienThoai, e.Value ? "Chuyển Online" : "Chuyển Offline");
        await GuiTrangThaiAsync();
    }

    private async void OnSwitchHoatDongToggled(object? sender, ToggledEventArgs e)
    {
        MockData.TaiXeHienTai.DangHoatDong = e.Value;
        NhatKyService.Ghi("TaiXe", MockData.TaiXeHienTai.SoDienThoai, e.Value ? "Sẵn sàng nhận đơn" : "Tạm không nhận đơn");
        await GuiTrangThaiAsync();
    }

    private void CapNhatDonDangGiao()
    {
        var don = MockData.DonHangDangGiaoCuaTaiXe;
        if (don is null)
        {
            KhungDonDangGiao.IsVisible = false;
            return;
        }

        KhungDonDangGiao.IsVisible = true;
        LblMaDonDangGiao.Text = $"#{don.Id}";
        LblGianHangDangGiao.Text = don.TenGianHang;
        LblDiaChiGiaoDangGiao.Text = don.TrangThai == TrangThaiDonHang.DangGiao
            ? $"🏁 Đang giao đến: {don.DiaChiGiao}"
            : $"🍳 Đến lấy hàng tại: {don.DiaChiLayHang}";
    }

    private void NapDanhSachDonChoNhan()
    {
        // TODO: thay bằng GET /api/tai-xe/don-cho-nhan khi có API thật.
        var dangHoatDong = MockData.TaiXeHienTai.NhanDuocDon;   // phải online VÀ sẵn sàng
        var daNhanDon = MockData.DonHangDangGiaoCuaTaiXe is not null;

        var ds = (dangHoatDong && !daNhanDon)
            ? MockData.DonHangChoTaiXe
                // đơn hẹn giờ chỉ hiện cho tài xế trong vòng 30 phút trước giờ giao
                .Where(d => d.TaiXeId is null && !_daTuChoi.Contains(d.Id) && !KhachDaHuy(d) && d.SanSangGiao && d.TrangThai == TrangThaiDonHang.DangLam && (!d.LaDonHenGio || d.HenGiaoLuc is null || d.HenGiaoLuc <= DateTime.Now.AddMinutes(30)))
                .ToList()
            : new List<DonHang>();
        DsDonChoNhan.ItemsSource = ds;

        ChipSoDon.IsVisible = ds.Count > 0;
        LblSoDonCho.Text = $"{ds.Count} đơn";

        // trạng thái rỗng, có lời nhắn rõ ràng cho từng trường hợp
        string? thongDiep = null; string icon = "😴";
        if (!dangHoatDong) { thongDiep = "Bật \"Nhận đơn giao hàng\" để xem đơn gần bạn."; icon = "😴"; }
        else if (daNhanDon) { thongDiep = "Hoàn thành đơn đang giao để nhận đơn tiếp theo."; icon = "🛵"; }
        else if (ds.Count == 0) { thongDiep = "Chưa có đơn. Đơn do Quản trị phân công cho bạn — bạn sẽ nhận thông báo khi được giao đơn. Kéo xuống để làm mới."; icon = "🔍"; }

        KhungTrong.IsVisible = thongDiep is not null;
        LblIconTrong.Text = icon;
        LblTatCa.Text = thongDiep ?? "";
    }

    private void NapLichSu()
    {
        var gan = MockData.DonHangDaGiaoCuaTaiXe.Reverse().Take(5).ToList();
        DsDaGiao.ItemsSource = gan;
        KhungLichSu.IsVisible = gan.Count > 0;
    }

    // ----- Từ chối đơn / lối tắt sang các trang mới -----
    private static readonly HashSet<string> _daTuChoi = new();

    private static bool KhachDaHuy(DonHang d) =>
        MockData.LichSuDonHang.Any(x => x.Id == d.Id && x.TrangThai == TrangThaiDonHang.DaHuy);

    /// <summary>Hành động chờ xử lý do trang "Chi tiết đơn có thể nhận" đặt ("nhan" | "tuchoi", mã đơn); trang chủ thực hiện khi hiện lại.</summary>
    public static (string Loai, string DonId)? HanhDongCho { get; set; }

    private async void OnDonChoNhanTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is string id) await Shell.Current.GoToAsync($"{nameof(DriverOfferDetailPage)}?id={Uri.EscapeDataString(id)}");
    }

    private async Task XuLyHanhDongChoAsync()
    {
        if (HanhDongCho is not { } hd) return;
        HanhDongCho = null;
        var don = MockData.DonHangChoTaiXe.FirstOrDefault(d => d.Id == hd.DonId);
        if (don is null) { await DisplayAlert("Đơn không còn", "Đơn này đã có tài xế khác nhận hoặc đã bị hủy.", "Đóng"); return; }
        if (hd.Loai == "nhan") await NhanDonAsync(don); else await TuChoiDonAsync(don);
    }

    private async void OnTuChoiClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: DonHang don }) return;
        await TuChoiDonAsync(don);
    }

    private async Task TuChoiDonAsync(DonHang don)
    {
        var chon = await DisplayActionSheet($"Từ chối đơn #{don.Id}?", "Hủy", null,
            "Quá xa", "Đang bận / sắp nghỉ", "Không phù hợp phương tiện", "Lý do khác");
        if (chon is null or "Hủy") return;
        var lyDo = chon;
        if (chon == "Lý do khác")
        {
            lyDo = await this.NhapAsync("Lý do từ chối", "Nhập lý do (có thể để trống):", "Gửi", "Hủy", maxLength: 300) ?? "";
            if (string.IsNullOrWhiteSpace(lyDo)) lyDo = "Lý do khác";
        }
        // Báo lên máy chủ: đơn vẫn ở hàng đợi cho tài xế khác, chỉ ẩn với bạn (server ghi nhận vào TaiXeTuChoiDon).
        // Offline: GhiAsync trả true -> chỉ ẩn cục bộ. Lỗi: GhiAsync đã báo người dùng -> giữ nguyên đơn trong danh sách.
        if (!await DuLieuService.GhiAsync("PUT", $"api/mobile/tai-xe/don-hang/{don.Id}/tu-choi", new { lyDo })) return;
        _daTuChoi.Add(don.Id);
        NapDanhSachDonChoNhan();
    }

    private async void OnDonCuaToiClicked(object sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverMyOrdersPage));

    /// <summary>Hiện số đơn đã nhận/đang giao trên nút "Đơn của tôi" (GET api/mobile/tai-xe/don-hang).</summary>
    private async Task CapNhatSoDonCuaToiAsync()
    {
        LblNhanDonHang.Text = "Đơn hàng";
        if (!DuLieuService.DangOnline) return;
        var nhan = await ApiClient.GetAsync<List<DonTaiXeItem>>("api/mobile/tai-xe/don-hang?tab=nhan");
        var giao = await ApiClient.GetAsync<List<DonTaiXeItem>>("api/mobile/tai-xe/don-hang?tab=dang-giao");
        var n = (nhan.DuLieu?.Count ?? 0) + (giao.DuLieu?.Count ?? 0);
        if (n > 0) LblNhanDonHang.Text = $"Đơn hàng ({n})";
    }

    /// <summary>Nút "Nhận đơn mới": làm mới đơn chờ nhận từ máy chủ (đơn chỉ hiện khi đang Online + Sẵn sàng).</summary>
    private async void OnNhanDonMoiClicked(object sender, EventArgs e)
    {
        var t = MockData.TaiXeHienTai;
        if (!t.DangOnline) { await DisplayAlert("Đang Offline", "Bật \"Trực tuyến (Online)\" ở đầu trang để nhận đơn.", "Đóng"); return; }
        if (!t.DangHoatDong) { await DisplayAlert("Tạm không nhận đơn", "Bật \"Sẵn sàng nhận đơn\" để xem đơn gần bạn.", "Đóng"); return; }
        await DongBoOnlineAsync();
        if (DsDonChoNhan.ItemsSource is System.Collections.ICollection { Count: 0 })
            await DisplayAlert("Chưa có đơn", "Hiện chưa có đơn nào sẵn sàng giao. Kéo xuống để làm mới sau ít phút.", "Đóng");
    }

    private async void OnBanDoClicked(object sender, EventArgs e)
        => await Shell.Current.GoToAsync(MockData.DonHangDangGiaoCuaTaiXe is not null ? nameof(DriverDeliveryDetailPage) : nameof(BanDoPage));

    private async void OnViClicked(object sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverWalletPage));

    private async void OnThuNhapClicked(object sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverEarningsPage));
    private async void OnDanhGiaClicked(object sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverRatingPage));
    private async void OnThongBaoClicked(object sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverNotificationsPage));

    private async void OnHoSoTapped(object sender, EventArgs e)
        => await Shell.Current.GoToAsync(nameof(DriverProfilePage));

    private async void OnNhanDonClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: DonHang don }) return;
        await NhanDonAsync(don);
    }

    private async Task NhanDonAsync(DonHang don)
    {

        if (MockData.DonHangDangGiaoCuaTaiXe is not null)
        {
            await DisplayAlert("Không thể nhận đơn", "Bạn cần hoàn thành đơn đang giao trước.", "Đóng");
            return;
        }

        bool xacNhan = await DisplayAlert(
            "Nhận đơn giao hàng",
            $"Nhận đơn #{don.Id} từ {don.TenGianHang}?\nPhí giao: {don.PhiGiaoHang:N0}đ\nThu khách ({don.HinhThucThanhToan}): {don.TongThanhToan:N0}đ",
            "Nhận đơn", "Để sau");
        if (!xacNhan) return;

        // Gọi server TRƯỚC: nếu server từ chối (đơn đã có tài xế khác, hết hiệu lực...) thì KHÔNG đổi giao diện.
        // Endpoint đúng của API: PUT api/mobile/tai-xe/don-hang/{id}/nhan (tài xế lấy từ JWT, không cần body).
        if (!await DuLieuService.GhiAsync("PUT", $"api/mobile/tai-xe/don-hang/{don.Id}/nhan"))
        {
            await DongBoOnlineAsync();      // làm mới danh sách: đơn có thể đã bị tài xế khác nhận
            NapDanhSachDonChoNhan();
            return;
        }

        var taiXe = MockData.TaiXeHienTai;
        don.TaiXeId = taiXe.Id;
        don.TaiXeTen = taiXe.HoTen;          // khách thấy tên + gọi/nhắn được cho tài xế
        don.TaiXeSdt = taiXe.SoDienThoai;
        don.TaiXeBienSo = taiXe.BienSoXe;
        MockData.DonHangDangGiaoCuaTaiXe = don;
        DonHangService.DongBo(don);

        CapNhatDonDangGiao();
        NapDanhSachDonChoNhan();

        await Shell.Current.GoToAsync(nameof(DriverDeliveryDetailPage));
    }

    private async void OnNhanTinKhachClicked(object sender, EventArgs e)
    {
        var don = MockData.DonHangDangGiaoCuaTaiXe;
        if (don is null) return;
        await ChatPage.MoAsync(don.Id, "TaiXe", string.IsNullOrWhiteSpace(don.KhachTen) ? "Khách hàng" : don.KhachTen, don.KhachSdt);
    }

    private async void OnXemDonDangGiaoClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(DriverDeliveryDetailPage));
    }

    private async void OnRefreshing(object? sender, EventArgs e)
    {
        TaiLai();
        await DongBoOnlineAsync();
        RefreshDanhSach.IsRefreshing = false;
    }

    private async void OnDangXuatClicked(object sender, EventArgs e)
    {
        try
        {
            bool xacNhan = await DisplayAlert("Đăng xuất", "Bạn có chắc muốn đăng xuất?", "Đăng xuất", "Hủy");
            if (!xacNhan) return;

            ViTriTaiXeService.Dung();
            var tx = MockData.TaiXeHienTai;
            tx.DangOnline = false;
            TaiXeStore.Luu();
            NhatKyService.Ghi("TaiXe", tx.SoDienThoai, "Đăng xuất", chiTiet: NhatKyService.ThietBi());
            if (DuLieuService.DangOnline)      // báo Offline cho Web khi còn token
                await ApiClient.PutAsync<object>("api/mobile/tai-xe/trang-thai", new { trangThai = "NgoaiTuyen" });
            ApiClient.Token = null;
            await Shell.Current.GoToAsync("//dang-nhap");
        }
        catch (Exception ex) { await Services.DangXuatHelper.LoiAsync(ex); }
    }
}
