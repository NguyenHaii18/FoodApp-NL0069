using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Hỗ trợ khách hàng: báo thiếu món, giao sai, giao trễ, chất lượng món, yêu cầu hoàn tiền, khiếu nại, góp ý (kèm tối đa 3 ảnh),
/// xem trạng thái / câu trả lời của quản trị và bổ sung thông tin khi được yêu cầu. Cần đăng nhập và kết nối máy chủ.
/// API: api/mobile/khach-hang/ho-tro (HoTroKhachApiController).
/// </summary>
[QueryProperty(nameof(DonHangId), "DonHangId")]
[QueryProperty(nameof(Loai), "Loai")]
public sealed class HoTroPage : ContentPage
{
    public string? DonHangId { get; set; }
    /// <summary>v90: mã loại chọn sẵn (vd ChatLuong, GiaoTre) khi mở từ màn đánh giá.</summary>
    public string? Loai { get; set; }

    private sealed class HoTroDto
    {
        public int Id { get; set; }
        public int? MaDonHang { get; set; }
        public string Loai { get; set; } = "";
        public string TieuDe { get; set; } = "";
        public string NoiDung { get; set; } = "";
        public string TrangThai { get; set; } = "";
        public string TraLoi { get; set; } = "";
        public string YeuCauBoSung { get; set; } = "";
        public DateTime NgayGui { get; set; }
    }

    private static readonly (string Ma, string Nhan, bool CanDon)[] CacLoai =
    {
        ("ThieuMon", "📦 Thiếu món", true),
        ("GiaoSai", "🔀 Giao sai món", true),
        ("GiaoTre", "⏰ Giao trễ", true),
        ("ChatLuong", "🍽 Chất lượng món", true),
        ("NhaHangHuy", "🏬 Nhà hàng hủy đơn", true),
        ("HoanTien", "💸 Yêu cầu hoàn tiền", true),
        ("MatHang", "🕵 Báo mất hàng", true),
        ("ThanhToanLoi", "💳 Báo thanh toán lỗi", true),
        ("KhieuNai", "📣 Khiếu nại khác", false),
        ("GopY", "💡 Góp ý", false),
    };

    // Máy chủ chưa có hai loại này: gửi bằng loại gần nhất + tiền tố ở nội dung để quản trị phân biệt.
    private static readonly Dictionary<string, (string Ma, string TienTo)> AnhXa = new()
    {
        ["MatHang"] = ("ThieuMon", "[Mất hàng] "),
        ["ThanhToanLoi"] = ("HoanTien", "[Thanh toán lỗi] "),
    };

    private readonly VerticalStackLayout _ds = new() { Spacing = 10 };
    private readonly Label _trangThai = new() { FontSize = 12.5, TextColor = Colors.Gray };
    private bool _dangGui;

    public HoTroPage()
    {
        Title = "Hỗ trợ";
        var nutGui = new Button { Text = "➕ Gửi yêu cầu hỗ trợ", FontAttributes = FontAttributes.Bold, CornerRadius = 12, BackgroundColor = Color.FromArgb("#6D28D9"), TextColor = Colors.White };
        nutGui.Clicked += async (_, _) => await GuiMoiAsync();
        var nutLienHe = new Button { Text = "📞 Liên hệ nhân viên CSKH", CornerRadius = 12, BackgroundColor = Colors.Transparent, TextColor = Color.FromArgb("#6D28D9"), BorderColor = Color.FromArgb("#6D28D9"), BorderWidth = 1 };
        nutLienHe.Clicked += async (_, _) => await LienHeCskhAsync();
        var lamMoi = new RefreshView { Content = new ScrollView { Content = new VerticalStackLayout { Padding = new Thickness(16), Spacing = 12, Children =
        {
            new Label { Text = "Cần giúp đỡ?", FontSize = 20, FontAttributes = FontAttributes.Bold },
            new Label { Text = "Báo thiếu món, giao sai, giao trễ, yêu cầu hoàn tiền hoặc gửi khiếu nại. Bộ phận hỗ trợ sẽ trả lời tại đây.", FontSize = 12.5, TextColor = Colors.Gray },
            nutGui, nutLienHe, _trangThai, _ds,
        } } } };
        lamMoi.Refreshing += async (_, _) => { await TaiAsync(); lamMoi.IsRefreshing = false; };
        Content = lamMoi;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await TaiAsync();
        // Mở từ một đơn (nút "Hỗ trợ" ở Hoạt động) → vào luôn luồng gửi cho đơn đó
        if (!string.IsNullOrEmpty(DonHangId) && int.TryParse(DonHangId, out var ma))
        {
            DonHangId = null;
            await GuiMoiAsync(ma);
        }
    }

    private async Task TaiAsync()
    {
        _ds.Children.Clear();
        if (Phien.Khach is null) { _trangThai.Text = "Hãy đăng nhập để gửi và xem yêu cầu hỗ trợ."; return; }
        _trangThai.Text = "Đang tải…";
        var r = await ApiClient.GetAsync<List<HoTroDto>>("api/mobile/khach-hang/ho-tro");
        if (!r.ThanhCong) { _trangThai.Text = r.MatKetNoi ? "Cần kết nối máy chủ để xem yêu cầu hỗ trợ.\n" + r.ThongDiep : r.ThongDiep; return; }
        var ds = r.DuLieu ?? new List<HoTroDto>();
        _trangThai.Text = ds.Count == 0 ? "Bạn chưa gửi yêu cầu nào." : $"{ds.Count} yêu cầu gần nhất";
        foreach (var x in ds) _ds.Children.Add(Ve(x));
    }

    private View Ve(HoTroDto x)
    {
        var xong = x.TrangThai == "DaXuLy";
        var st = new VerticalStackLayout { Spacing = 4 };
        st.Children.Add(new Label { Text = x.TieuDe, FontAttributes = FontAttributes.Bold, FontSize = 14 });
        st.Children.Add(new Label { Text = (xong ? "✅ Đã xử lý" : "⏳ Đang chờ xử lý") + " · " + x.NgayGui.ToString("dd/MM/yyyy HH:mm"), FontSize = 11.5, TextColor = xong ? Colors.SeaGreen : Colors.DarkOrange });
        st.Children.Add(new Label { Text = x.NoiDung, FontSize = 12.5, LineBreakMode = LineBreakMode.WordWrap });
        if (!string.IsNullOrWhiteSpace(x.TraLoi))
            st.Children.Add(new Label { Text = "💬 Phản hồi: " + x.TraLoi, FontSize = 12.5, TextColor = Colors.SeaGreen, FontAttributes = FontAttributes.Bold });
        if (!string.IsNullOrWhiteSpace(x.YeuCauBoSung))
            st.Children.Add(new Label { Text = "❓ Cần bổ sung: " + x.YeuCauBoSung, FontSize = 12.5, TextColor = Colors.DarkOrange, FontAttributes = FontAttributes.Bold });
        if (!xong)
        {
            var bs = new Button { Text = "✍ Bổ sung thông tin", FontSize = 12, HeightRequest = 36, CornerRadius = 10, HorizontalOptions = LayoutOptions.Start };
            var id = x.Id;
            bs.Clicked += async (_, _) => await BoSungAsync(id);
            st.Children.Add(bs);
        }
        return new Frame { Content = st, Padding = new Thickness(12), CornerRadius = 12, HasShadow = false, BorderColor = Color.FromArgb("#E5E7EB") };
    }

    private async Task BoSungAsync(int id)
    {
        var nd = await this.NhapAsync("Bổ sung thông tin", "Nội dung bổ sung:", "Gửi", "Hủy", maxLength: 400, keyboard: Keyboard.Text);
        if (string.IsNullOrWhiteSpace(nd)) return;
        var r = await ApiClient.PostAsync<object>($"api/mobile/khach-hang/ho-tro/{id}/bo-sung", new { noiDung = nd.Trim() });
        await DisplayAlert(r.ThanhCong ? "Đã gửi" : "Không gửi được", r.ThanhCong ? "Đã gửi bổ sung cho bộ phận hỗ trợ." : r.ThongDiep, "OK");
        if (r.ThanhCong) await TaiAsync();
    }

    /// <summary>Gọi / email nhân viên CSKH (số liên hệ do máy chủ cấu hình); luôn có lối tắt gửi yêu cầu để theo dõi tại app.</summary>
    private async Task LienHeCskhAsync()
    {
        await ChinhSachService.LamMoiAsync();
        var cs = ChinhSachService.HienTai;
        var lc = new List<string>();
        if (!string.IsNullOrWhiteSpace(cs.HotlineCskh)) lc.Add("📞 Gọi " + cs.HotlineCskh);
        if (!string.IsNullOrWhiteSpace(cs.EmailCskh)) lc.Add("✉ Gửi email " + cs.EmailCskh);
        lc.Add("➕ Gửi yêu cầu hỗ trợ trong app");
        var c = await DisplayActionSheet("Liên hệ CSKH", "Đóng", null, lc.ToArray());
        if (c is null or "Đóng") return;
        if (c.StartsWith("📞")) await LienLac.GoiAsync(cs.HotlineCskh);
        else if (c.StartsWith("✉")) { try { await Launcher.Default.OpenAsync("mailto:" + cs.EmailCskh); } catch { await FoodApp.Maui.Services.ClipboardAnToan.SaoChepAsync(cs.EmailCskh); await DisplayAlert("Email", "Đã sao chép " + cs.EmailCskh, "OK"); } }
        else await GuiMoiAsync();
    }

    private async Task GuiMoiAsync(int? maDonCoSan = null)
    {
        if (_dangGui) return;
        if (Phien.Khach is null) { await DisplayAlert("Cần đăng nhập", "Hãy đăng nhập để gửi yêu cầu hỗ trợ.", "OK"); return; }
        _dangGui = true;
        try
        {
            var sanLoai = Loai; Loai = null;
            var loai = CacLoai.FirstOrDefault(l => sanLoai != null && l.Ma == sanLoai);
            if (loai.Ma is null)
            {
                var chon = await DisplayActionSheet("Bạn gặp vấn đề gì?", "Hủy", null, CacLoai.Select(l => l.Nhan).ToArray());
                loai = CacLoai.FirstOrDefault(l => l.Nhan == chon);
            }
            if (loai.Ma is null) return;

            int? maDon = maDonCoSan;
            if (maDon is null)
            {
                var don = MockData.LichSuDonHang.Where(d => OrderTrackingPage.DonCuaToi(d) && int.TryParse(d.Id, out _))
                    .OrderByDescending(d => d.NgayDat).Take(12).ToList();
                if (don.Count > 0)
                {
                    var nhan = don.Select(d => $"#{d.Id} · {d.TenGianHang} · {d.NgayDat:dd/MM HH:mm}").ToList();
                    var ds = loai.CanDon ? nhan.ToArray() : nhan.Append("Không gắn với đơn nào").ToArray();
                    var c = await DisplayActionSheet(loai.CanDon ? "Chọn đơn liên quan" : "Gắn với đơn (tùy chọn)", "Hủy", null, ds);
                    if (c is null or "Hủy") return;
                    var i = nhan.IndexOf(c);
                    if (i >= 0) maDon = int.Parse(don[i].Id);
                }
                else if (loai.CanDon) { await DisplayAlert("Chưa có đơn", "Bạn chưa có đơn hàng nào để báo vấn đề.", "OK"); return; }
            }

            var nd = await this.NhapAsync(loai.Nhan.Substring(loai.Nhan.IndexOf(' ') + 1), "Mô tả chi tiết (ví dụ: món nào thiếu, giao sai thế nào…):", "Tiếp", "Hủy", maxLength: 400, keyboard: Keyboard.Text);
            if (string.IsNullOrWhiteSpace(nd)) return;

            var anh = new List<string>();
            while (anh.Count < 3)
            {
                var them = await DisplayActionSheet(anh.Count == 0 ? "Đính kèm ảnh minh chứng?" : $"Đã có {anh.Count} ảnh. Thêm nữa?", "Gửi luôn", null, "Chọn từ thư viện", "Chụp ảnh");
                if (them is null or "Gửi luôn") break;
                var path = await AnhService.ChonVaLuuAsync("ht_" + DateTime.Now.ToString("HHmmss"), "Chọn ảnh", chup: them == "Chụp ảnh");
                if (path is null) continue;
                var up = await ApiClient.PostFileAsync<UploadAnhDto>("api/upload/danhgia", path);
                if (!up.ThanhCong || string.IsNullOrWhiteSpace(up.DuLieu?.ImageUrl)) { await DisplayAlert("Không tải được ảnh", up.ThongDiep, "OK"); continue; }
                anh.Add(up.DuLieu!.ImageUrl!);
            }

            var r = await ApiClient.PostAsync<object>("api/mobile/khach-hang/ho-tro", new
            {
                loaiVanDe = AnhXa.TryGetValue(loai.Ma, out var xa) ? xa.Ma : loai.Ma,
                maDonHang = maDon,
                noiDung = (AnhXa.TryGetValue(loai.Ma, out var xa2) ? xa2.TienTo : "") + nd.Trim(),
                anh,
            });
            await DisplayAlert(r.ThanhCong ? "Đã gửi" : "Không gửi được", r.ThanhCong ? "Đã gửi tới bộ phận hỗ trợ. Chúng tôi sẽ phản hồi sớm." : r.ThongDiep, "OK");
            if (r.ThanhCong) await TaiAsync();
        }
        finally { _dangGui = false; }
    }
}
