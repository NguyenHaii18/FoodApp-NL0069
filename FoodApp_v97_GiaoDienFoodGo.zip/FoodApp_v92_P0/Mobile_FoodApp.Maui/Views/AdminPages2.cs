﻿using System.Text.Json;
using Microsoft.Maui.ApplicationModel.Communication;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

// =====================================================================================================================
// CHI TIẾT ĐƠN — điều tra toàn bộ vòng đời đơn: món, thanh toán, giao hàng, dòng thời gian, hoàn tiền, khiếu nại, đánh giá
// =====================================================================================================================
[QueryProperty(nameof(Id), "Id")]
public sealed class AdminOrderDetailPage : ContentPage
{
    public new string Id { get; set; } = "";

    private readonly VerticalStackLayout _nd = new() { Spacing = 10, Padding = new Thickness(16, 10, 16, 28) };
    private readonly RefreshView _lamMoi = new() { RefreshColor = Color.FromArgb(AdminUi.Tim) };

    public AdminOrderDetailPage()
    {
        Title = "Chi tiết đơn";
        AdminUi.NenTrang(this);
        _lamMoi.Content = new ScrollView { Content = _nd };
        _lamMoi.Refreshing += async (_, _) => await TaiAsync();
        Content = _lamMoi;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await TaiAsync();
    }

    private static Border Muc(string tieuDe, IEnumerable<string> dong)
    {
        var st = new VerticalStackLayout { Spacing = 4 };
        st.Add(AdminUi.Nhan(tieuDe, 13.5, dam: true));
        foreach (var d in dong.Where(x => !string.IsNullOrWhiteSpace(x))) st.Add(AdminUi.Nhan(d, 12, mo: true));
        var the = AdminUi.The();
        the.Content = st;
        return the;
    }

    private async Task Goi(string? sdt)
    {
        if (string.IsNullOrWhiteSpace(sdt)) return;
        try { PhoneDialer.Default.Open(sdt); } catch { await DisplayAlert("Không gọi được", "Thiết bị không hỗ trợ cuộc gọi.", "Đóng"); }
    }

    private async Task TaiAsync()
    {
        try
        {
            _nd.Children.Clear();
            var r = await ApiClient.GetAsync<JsonElement>($"api/mobile/admin/don-hang/{Id}/chi-tiet");
            if (!r.ThanhCong) { _nd.Add(AdminUi.Nhan(r.ThongDiep, 13, mo: true)); return; }
            var root = r.DuLieu;
            var don = J.Doi(root, "don");
            var tt = AdminUi.TrangThai(J.S(don, "trangThai"));

            // --- đầu trang
            var dau = AdminUi.The();
            var st = new VerticalStackLayout { Spacing = 5 };
            var hang = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            hang.Add(AdminUi.Nhan($"Đơn #{J.S(don, "maDonHang")}", 17, dam: true), 0, 0);
            hang.Add(AdminUi.Chip(tt.Nhan, tt.Mau), 1, 0);
            st.Add(hang);
            st.Add(AdminUi.Nhan($"🕒 {J.Ngay(don, "ngayDat")}", 12, mo: true));
            st.Add(AdminUi.Nhan($"📍 {J.S(don, "diaChiGiaoHang")}" + (J.D(don, "khoangCachKm") > 0 ? $" ({J.D(don, "khoangCachKm"):0.#} km)" : ""), 12, mo: true));
            if (!J.Rong(don, "ghiChu")) st.Add(AdminUi.Nhan($"📝 Ghi chú: {J.S(don, "ghiChu")}", 12, mo: true));
            if (!J.Rong(don, "lyDoTuChoi")) st.Add(AdminUi.Nhan($"🚫 Lý do hủy/từ chối: {J.S(don, "lyDoTuChoi")}", 12, mo: true));
            dau.Content = st;
            _nd.Add(dau);

            // --- các bên liên quan (chạm để gọi)
            var ben = new FlexLayout { Wrap = Microsoft.Maui.Layouts.FlexWrap.Wrap };
            void NutGoi(string nhan, string ten, string sdt)
            {
                if (string.IsNullOrWhiteSpace(ten)) return;
                var n = AdminUi.Nut($"{nhan}: {ten}", AdminUi.Tim);
                n.Margin = new Thickness(0, 0, 8, 6);
                n.Clicked += async (_, _) => await Goi(sdt);
                ben.Add(n);
            }
            NutGoi("📞 Khách", J.S(don, "khach"), J.S(don, "sdtKhach"));
            NutGoi("📞 Quán", J.S(don, "gianHang"), J.S(don, "sdtGianHang"));
            NutGoi("📞 Tài xế", J.S(don, "taiXe"), J.S(don, "sdtTaiXe"));
            _nd.Add(ben);

            // --- món + tiền
            var dongMon = J.Mang(root, "mon").Select(m =>
                $"• {J.L(m, "soLuong")} × {J.S(m, "ten")}  —  {AdminUi.Tien(J.D(m, "donGia") * J.L(m, "soLuong"))}" +
                (J.Rong(m, "tuyChon") ? "" : $"\n   {J.S(m, "tuyChon")}") + (J.Rong(m, "ghiChu") ? "" : $"\n   📝 {J.S(m, "ghiChu")}")).ToList();
            dongMon.Add($"Phí giao: {AdminUi.Tien(J.D(don, "phiGiaoHang"))}" + (J.D(don, "tienGiam") > 0 ? $"   ·   Giảm: -{AdminUi.Tien(J.D(don, "tienGiam"))}" + (J.Rong(don, "khuyenMai") ? "" : $" ({J.S(don, "khuyenMai")})") : ""));
            dongMon.Add($"TỔNG: {AdminUi.Tien(J.D(don, "tongTien"))}");
            _nd.Add(Muc("🍽 Món & chi phí", dongMon));

            // --- thanh toán
            var t = J.Doi(root, "thanhToan");
            if (t.ValueKind == JsonValueKind.Object)
                _nd.Add(Muc("💳 Thanh toán", new[]
                {
                    $"{AdminUi.TrangThai(J.S(t, "hinhThuc")).Nhan} · {AdminUi.TrangThai(J.S(t, "trangThai")).Nhan} · " + (J.B(t, "daDoiSoat") ? "đã đối soát" : "chưa đối soát"),
                    J.Rong(t, "maGiaoDich") ? "" : $"Mã giao dịch: {J.S(t, "maGiaoDich")}",
                    J.Rong(t, "ngayThanhToan") ? "" : $"Thanh toán lúc: {J.Ngay(t, "ngayThanhToan")}",
                    J.Rong(t, "maGiaoDichHoan") ? "" : $"Hoàn tiền: {J.S(t, "maGiaoDichHoan")} ({J.Ngay(t, "ngayHoan")}) {J.S(t, "ketQuaHoan")}",
                }));

            // --- giao hàng
            var g = J.Doi(root, "giaoHang");
            if (g.ValueKind == JsonValueKind.Object)
                _nd.Add(Muc("🛵 Giao hàng", new[]
                {
                    $"Trạng thái: {J.S(g, "trangThai")}",
                    J.Rong(g, "thoiGianNhan") ? "" : $"Nhận đơn: {J.Ngay(g, "thoiGianNhan")}",
                    J.Rong(g, "thoiGianDenQuan") ? "" : $"Đến quán: {J.Ngay(g, "thoiGianDenQuan")}",
                    J.Rong(g, "thoiGianLayHang") ? "" : $"Lấy hàng: {J.Ngay(g, "thoiGianLayHang")}",
                    J.Rong(g, "thoiGianGiao") ? "" : $"Giao xong: {J.Ngay(g, "thoiGianGiao")}",
                    J.Rong(g, "lyDoThatBai") ? "" : $"⚠️ Giao thất bại: {J.S(g, "lyDoThatBai")} (lỗi do: {J.S(g, "nguoiGayLoi")})",
                    J.D(g, "tienThuCOD") > 0 ? $"Tiền COD đã thu: {AdminUi.Tien(J.D(g, "tienThuCOD"))}" : "",
                    J.B(g, "coAnhBangChung") ? "📷 Có ảnh bằng chứng giao hàng" : "",
                }));

            // --- dòng thời gian
            var ls = J.Mang(root, "lichSu").Select(l => $"{J.Ngay(l, "thoiGian", "dd/MM HH:mm")}  {AdminUi.TrangThai(J.S(l, "tuTrangThai")).Nhan} → {AdminUi.TrangThai(J.S(l, "denTrangThai")).Nhan}" + (J.Rong(l, "lyDo") ? "" : $"\n   {J.S(l, "lyDo")}")).ToList();
            if (ls.Count > 0) _nd.Add(Muc("⏱ Dòng thời gian trạng thái", ls));

            var dp = J.Mang(root, "dieuPhoi").Select(l => $"{J.Ngay(l, "thoiGian", "dd/MM HH:mm")}  {AdminUi.TrangThai(J.S(l, "hanhDong")).Nhan} — {J.S(l, "lyDo")}").ToList();
            if (dp.Count > 0) _nd.Add(Muc("🧭 Nhật ký điều phối", dp));

            var ht = J.Mang(root, "hoanTien").Select(y => $"#{J.S(y, "maYeuCau")} · {AdminUi.Tien(J.D(y, "soTien"))} · {AdminUi.TrangThai(J.S(y, "trangThai")).Nhan}\n   {J.S(y, "lyDo")}" + (J.Rong(y, "ketQua") ? "" : $"\n   → {J.S(y, "ketQua")}")).ToList();
            if (ht.Count > 0) _nd.Add(Muc("↩️ Yêu cầu hoàn tiền", ht));

            var ph = J.Mang(root, "phanHoi").Select(x => $"[{J.S(x, "loai")}] {J.S(x, "tieuDe")} — {J.S(x, "trangThai")}\n   {J.S(x, "noiDung")}" + (J.Rong(x, "traLoi") ? "" : $"\n   ↳ Phản hồi: {J.S(x, "traLoi")}")).ToList();
            if (ph.Count > 0) _nd.Add(Muc("📣 Khiếu nại / phản hồi", ph));

            var dg = J.Mang(root, "danhGia").Select(x => $"{J.L(x, "soSao")}⭐ quán · {(J.Rong(x, "soSaoGiaoHang") ? "—" : J.S(x, "soSaoGiaoHang") + "⭐ giao hàng")}" + (J.B(x, "daAn") ? " · (đã ẩn)" : "") + (J.Rong(x, "noiDung") ? "" : $"\n   “{J.S(x, "noiDung")}”")).ToList();
            if (dg.Count > 0) _nd.Add(Muc("⭐ Đánh giá", dg));

            // --- can thiệp
            var hd = new FlexLayout { Wrap = Microsoft.Maui.Layouts.FlexWrap.Wrap, Margin = new Thickness(0, 4, 0, 0) };
            var maDon = J.S(don, "maDonHang");
            if (!J.B(don, "laDonCuoi"))
            {
                var huy = AdminUi.Nut("Hủy đơn (can thiệp)", AdminUi.Do, day: true);
                huy.Margin = new Thickness(0, 0, 8, 6);
                huy.Clicked += async (_, _) =>
                {
                    var ly = await AdminUi.Hoi(this, "Hủy đơn #" + maDon, "Lý do can thiệp (≥ 5 ký tự). Khách và quán sẽ được thông báo; đơn đã thanh toán online tự tạo yêu cầu hoàn tiền.", null, 5);
                    if (ly == null) return;
                    if (await AdminUi.Put(this, $"api/mobile/admin/don-hang/{maDon}/huy", new { lyDo = ly }, "Hủy đơn hàng", $"Đơn #{maDon}")) await TaiAsync();
                };
                hd.Add(huy);
            }
            if (J.S(don, "trangThai") == "DangGiao" && J.L(don, "soLanSaiMa") > 0)
            {
                var mo = AdminUi.Nut($"Mở khóa mã giao ({J.L(don, "soLanSaiMa")} lần sai)", AdminUi.Cam);
                mo.Margin = new Thickness(0, 0, 8, 6);
                mo.Clicked += async (_, _) => { if (await AdminUi.Put(this, $"api/mobile/admin/don-hang/{maDon}/mo-khoa-ma", null, "Mở khóa mã giao hàng", $"Đơn #{maDon}")) await TaiAsync(); };
                hd.Add(mo);
            }
            if (t.ValueKind == JsonValueKind.Object && J.S(t, "trangThai") == "DaThanhToan" && J.S(t, "hinhThuc") != "TienMat")
            {
                var hoan = AdminUi.Nut("Tạo yêu cầu hoàn tiền", AdminUi.Tim);
                hoan.Margin = new Thickness(0, 0, 8, 6);
                hoan.Clicked += async (_, _) =>
                {
                    var ly = await AdminUi.Hoi(this, "Hoàn tiền toàn bộ", $"Hoàn {AdminUi.Tien(J.D(don, "tongTien"))} cho đơn #{maDon}. Nhập lý do (≥ 5 ký tự).", null, 5);
                    if (ly == null) return;
                    await AdminUi.Post(this, "api/mobile/admin/hoan-tien", new { maDonHang = int.Parse(maDon), lyDo = ly }, "Tạo yêu cầu hoàn tiền", $"Đơn #{maDon}");
                    await TaiAsync();
                };
                hd.Add(hoan);
            }
            if (hd.Children.Count > 0) _nd.Add(hd);
        }
        catch (Exception ex)
        {
            CrashLog.Ghi("AdminOrderDetail", ex);
            _nd.Add(AdminUi.Nhan("Có lỗi khi hiển thị đơn: " + ex.Message, 13, mo: true));
        }
        finally { _lamMoi.IsRefreshing = false; }
    }
}

// =====================================================================================================================
// BÁO CÁO & THỐNG KÊ — doanh thu theo kỳ, top quán/món/khu vực, thanh toán, tài xế
// =====================================================================================================================
public sealed class AdminReportsPage : ContentPage
{
    private string _ky = "Ngay";
    private readonly VerticalStackLayout _nd = new() { Spacing = 10, Padding = new Thickness(16, 6, 16, 28) };
    private readonly HorizontalStackLayout _kyBar = new() { Spacing = 8 };
    private readonly RefreshView _lamMoi = new() { RefreshColor = Color.FromArgb(AdminUi.Tim) };

    public AdminReportsPage()
    {
        Title = "Báo cáo & thống kê";
        AdminUi.NenTrang(this);
        foreach (var (ma, nhan) in new[] { ("Ngay", "30 ngày"), ("Thang", "12 tháng"), ("Nam", "5 năm") })
        {
            var m = ma;
            var nut = AdminUi.Nut(nhan, AdminUi.Tim, day: m == _ky);
            nut.Clicked += async (_, _) => { _ky = m; DatLai(); await TaiAsync(); };
            _kyBar.Add(nut);
        }
        _lamMoi.Content = new ScrollView { Content = _nd };
        _lamMoi.Refreshing += async (_, _) => await TaiAsync();
        var goc = new Grid { RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Star) } };
        goc.Add(new VerticalStackLayout { Padding = new Thickness(16, 8, 16, 0), Children = { _kyBar } }, 0, 0);
        goc.Add(_lamMoi, 0, 1);
        Content = goc;
    }

    private void DatLai()
    {
        var ds = new[] { "Ngay", "Thang", "Nam" };
        for (var i = 0; i < _kyBar.Children.Count; i++)
            if (_kyBar.Children[i] is Button b)
            {
                var dung = ds[i] == _ky;
                b.BackgroundColor = dung ? Color.FromArgb(AdminUi.Tim) : Colors.Transparent;
                b.TextColor = dung ? Colors.White : Color.FromArgb(AdminUi.Tim);
            }
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (ToolbarItems.Count == 0)
            ToolbarItems.Add(new ToolbarItem { Text = "Xuất báo cáo", Command = new Command(async () => await BaoCaoXuatService.XuatAsync(this)) });
        await TaiAsync();
    }

    private static Border Kpi(string nhan, string giaTri, string mau)
    {
        var the = AdminUi.The(10);
        var st = new VerticalStackLayout { Spacing = 2 };
        st.Add(AdminUi.Nhan(nhan, 11, mo: true));
        var v = AdminUi.Nhan(giaTri, 16, dam: true);
        v.TextColor = Color.FromArgb(mau);
        st.Add(v);
        the.Content = st;
        return the;
    }

    /// <summary>Danh sách thanh ngang: nhãn, giá trị, thanh tỉ lệ so với giá trị lớn nhất.</summary>
    private static Border BieuDo(string tieuDe, IReadOnlyList<(string Nhan, double Gia, string Chu)> ds, string mau)
    {
        var st = new VerticalStackLayout { Spacing = 6 };
        st.Add(AdminUi.Nhan(tieuDe, 13.5, dam: true));
        if (ds.Count == 0) st.Add(AdminUi.Nhan("Chưa có dữ liệu trong kỳ này.", 12, mo: true));
        var max = ds.Count == 0 ? 1 : Math.Max(1, ds.Max(x => x.Gia));
        foreach (var x in ds)
        {
            var hang = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            hang.Add(AdminUi.Nhan(x.Nhan, 12), 0, 0);
            hang.Add(AdminUi.Nhan(x.Chu, 12, dam: true), 1, 0);
            st.Add(hang);
            st.Add(new ProgressBar { Progress = Math.Clamp(x.Gia / max, 0, 1), ProgressColor = Color.FromArgb(mau), HeightRequest = 6 });
        }
        var the = AdminUi.The();
        the.Content = st;
        return the;
    }

    private async Task TaiAsync()
    {
        try
        {
            _nd.Children.Clear();
            var r = await ApiClient.GetAsync<JsonElement>($"api/mobile/admin/bao-cao?ky={_ky}");
            if (!r.ThanhCong)
            {
                _nd.Add(AdminUi.Nhan(r.MatKetNoi ? "Báo cáo cần kết nối máy chủ (online).\n" + r.ThongDiep : r.ThongDiep, 13, mo: true));
                return;
            }
            var d = r.DuLieu;
            var luoi = new Grid { ColumnSpacing = 10, RowSpacing = 10, ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) } };
            var kpi = new[]
            {
                Kpi("GMV (giá trị đơn đã giao)", AdminUi.Tien(J.D(d, "tongDoanhThu")), AdminUi.Tim),
                Kpi("Đơn hoàn thành", J.L(d, "tongDonHoanThanh").ToString("N0"), AdminUi.Xanh),
                Kpi("Doanh thu nền tảng (hoa hồng)", AdminUi.Tien(J.D(d, "phiNenTang")), AdminUi.Tim),
                Kpi("Đơn hủy", $"{J.L(d, "tongDonHuy")} ({J.D(d, "tyLeHuy"):0.#}%)", AdminUi.Do),
                Kpi("Thời gian giao TB", J.Co(d, "thoiGianGiaoTrungBinhPhut", out var tg) && tg.ValueKind == JsonValueKind.Number ? $"{tg.GetDouble():0.#} phút" : "—", AdminUi.Cam),
                Kpi("Khách mới", J.L(d, "khachMoi").ToString("N0"), "#8B5CF6"),
                Kpi("Quán / tài xế mới", $"{J.L(d, "quanMoi")} / {J.L(d, "taiXeMoi")}", AdminUi.Cam),
            };
            for (var i = 0; i < kpi.Length; i++) luoi.Add(kpi[i], i % 2, i / 2);
            for (var i = 0; i <= kpi.Length / 2; i++) luoi.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
            _nd.Add(luoi);

            _nd.Add(BieuDo("Doanh thu theo kỳ", J.Mang(d, "theoKy").Select(x => (J.S(x, "nhan"), (double)J.D(x, "doanhThu"), $"{AdminUi.Tien(J.D(x, "doanhThu"))} · {J.L(x, "soDon")} đơn")).ToList(), AdminUi.Tim));
            _nd.Add(BieuDo("🏆 Top gian hàng theo doanh thu", J.Mang(d, "topGianHang").Select(x => (J.S(x, "ten"), (double)J.D(x, "doanhThu"), $"{AdminUi.Tien(J.D(x, "doanhThu"))} · {J.L(x, "soDon")} đơn")).ToList(), AdminUi.Xanh));
            _nd.Add(BieuDo("🍜 Top món bán chạy", J.Mang(d, "topMon").Select(x => (J.S(x, "ten"), (double)J.L(x, "soLuong"), $"{J.L(x, "soLuong")} phần")).ToList(), AdminUi.Cam));
            _nd.Add(BieuDo("📍 Khu vực nhiều đơn", J.Mang(d, "khuVuc").Select(x => (J.S(x, "ten"), (double)J.L(x, "soDon"), $"{J.L(x, "soDon")} đơn")).ToList(), "#8B5CF6"));
            _nd.Add(BieuDo("💳 Theo hình thức thanh toán", J.Mang(d, "theoThanhToan").Select(x => (AdminUi.TrangThai(J.S(x, "hinhThuc")).Nhan, (double)J.D(x, "tien"), $"{AdminUi.Tien(J.D(x, "tien"))} · {J.L(x, "soDon")} đơn")).ToList(), AdminUi.Tim));
            _nd.Add(BieuDo("🛵 Top tài xế", J.Mang(d, "topTaiXe").Select(x => (J.S(x, "ten"), (double)J.L(x, "soDon"), $"{J.L(x, "soDon")} đơn · phí giao {AdminUi.Tien(J.D(x, "thuNhap"))}")).ToList(), AdminUi.Xanh));
        }
        catch (Exception ex)
        {
            CrashLog.Ghi("AdminReports", ex);
            _nd.Add(AdminUi.Nhan("Có lỗi khi hiển thị báo cáo: " + ex.Message, 13, mo: true));
        }
        finally { _lamMoi.IsRefreshing = false; }
    }
}

// =====================================================================================================================
// TẤT CẢ CHỨC NĂNG (v81 thiết kế lại) — lối tắt lớn + ô tìm + lọc theo nhóm + lưới ô vuông, kèm số việc chờ xử lý
// =====================================================================================================================
public sealed class AdminHubPage : ContentPage
{
    private sealed record Muc(string Icon, string Ten, string MoTa, string Route, string? KhoaDem = null);

    private static readonly (string Nhom, Muc[] Muc)[] Cay =
    {
        ("Vận hành", new[]
        {
            new Muc("🏠", "Dashboard", "Đơn, người dùng, nhà hàng, tài xế, doanh thu và việc cần xử lý (số liệu máy chủ)", nameof(AdminDashboardPage)),
            new Muc("📦", "Đơn hàng", "Xem, lọc, điều tra, hủy can thiệp", nameof(AdminOrdersPage), "donDangXuLy"),
            new Muc("📡", "Bảng điều phối", "Số đơn trong ngày, tài xế trực tuyến / bận / rảnh, đơn nguy cơ trễ, khu vực thiếu tài xế, báo cáo Excel", nameof(AdminDieuPhoiTongQuanPage), "donChuaCoTaiXe"),
            new Muc("🧭", "Điều phối tài xế", "Phân công / đổi / gỡ tài xế", nameof(AdminDispatchPage), "donChuaCoTaiXe"),
            new Muc("🎧", "Chăm sóc khách hàng", "Tra cứu khách, ghi chú nội bộ, 8 nhóm yêu cầu hỗ trợ", nameof(AdminCskhPage), "khieuNaiCho"),
            new Muc("📣", "Khiếu nại & sự cố", "Tiếp nhận và xử lý khiếu nại", nameof(AdminIssuesPage), "khieuNaiCho"),
            new Muc("📨", "Khiếu nại của khách", "Tiếp nhận, phân công người xử lý, phân loại, trả lời, chuyển hoàn tiền", nameof(AdminKhieuNaiPage), "khieuNaiCho"),
            new Muc("🛵", "Sự cố tài xế", "Tài xế báo sự cố, sai lệch thu nhập / COD", nameof(AdminDriverIssuesPage)),
            new Muc("🚨", "Trung tâm vận hành", "Cảnh báo hệ thống, SLA, gian lận, lợi nhuận, đánh giá nghi vấn", nameof(AdminVanHanhPage)),
        }),
        ("Người dùng & đối tác", new[]
        {
            new Muc("🔑", "Tài khoản", "Toàn bộ tài khoản, khóa / mở khóa", nameof(AdminAccountsPage)),
            new Muc("👥", "Khách hàng", "Xem, sửa thông tin, khóa / mở khóa", nameof(AdminCustomerListPage)),
            new Muc("🔎", "Tra cứu khách & lịch sử đơn", "Tìm theo tên / SĐT / mã, xem đơn, khiếu nại", nameof(AdminCustomerSearchPage)),
            new Muc("🏬", "Gian hàng", "Danh sách, khóa, mở lại", nameof(AdminVendorListPage)),
            new Muc("📑", "Hợp đồng & hoa hồng quán", "Ngày tham gia, hoa hồng, GMV, đặt tỷ lệ riêng", nameof(AdminVendorContractPage)),
            new Muc("✅", "Duyệt gian hàng", "Duyệt / từ chối hồ sơ quán", nameof(AdminVendorApprovalPage), "gianHangChoDuyet"),
            new Muc("🛵", "Tài xế", "Thông tin, sửa, khóa / mở", nameof(AdminDriverListPage)),
            new Muc("📝", "Duyệt tài xế", "Duyệt / từ chối hồ sơ tài xế", nameof(AdminDriverApprovalPage), "taiXeChoDuyet"),
        }),
        ("Nội dung", new[]
        {
            new Muc("🗂", "Danh mục & món ăn", "Kiểm soát món / danh mục vi phạm", nameof(AdminCatalogPage)),
            new Muc("⭐", "Đánh giá", "Kiểm duyệt đánh giá bị báo cáo", nameof(AdminReviewsPage), "baoCaoDanhGiaCho"),
            new Muc("🖼", "Banner trang chủ", "Thêm / sửa / hẹn lịch / bật tắt / xóa banner quảng bá", nameof(AdminBannerPage)),
            new Muc("📢", "Thông báo trang chủ", "Dòng chữ nổi bật ở đầu trang chủ khách", nameof(AdminThongBaoTrangChuPage)),
            new Muc("📰", "Tin tức & ưu đãi", "Soạn tin hiện ở mục Tin mới của khách, hẹn đăng, ghim", nameof(AdminTinTucPage)),
            new Muc("❓", "Câu hỏi thường gặp", "Biên tập FAQ ở Trung tâm hỗ trợ", nameof(AdminFaqPage)),
        }),
        ("Tài chính", new[]
        {
            new Muc("💳", "Thanh toán & hoàn tiền", "Giao dịch, đối soát, duyệt hoàn tiền", nameof(AdminPaymentsPage), "hoanTienCho"),
            new Muc("🚚", "Phí giao & chia tiền", "Chỉnh phí giao (km, cao điểm, mưa) và tỉ lệ tài xế / ứng dụng", nameof(AdminPhiGiaoPage)),
            new Muc("🧾", "Khoản phải trả", "Phải trả quán (sau phí nền tảng) và tài xế", nameof(AdminPayablesPage)),
            new Muc("🎁", "Khuyến mãi & voucher", "Khuyến mãi / mã giảm giá toàn hệ thống", nameof(AdminPromotionsPage)),
        }),
        ("Phân tích", new[]
        {
            new Muc("📥", "Báo cáo & xuất Excel", "Xuất Excel doanh thu, tài khoản khách hàng, tài khoản quán", nameof(AdminXuatExcelPage)),
            new Muc("📊", "Báo cáo & thống kê", "Doanh thu, top quán / món / khu vực", nameof(AdminReportsPage)),
            new Muc("📈", "Báo cáo kinh doanh nâng cao", "So kỳ trước, giá trị đơn TB, giờ cao điểm, khách quay lại, danh mục, lý do hủy", nameof(AdminBaoCaoNangCaoPage)),
            new Muc("📈", "Thống kê nhanh", "Tổng hợp theo dữ liệu đã đồng bộ", nameof(AdminStatisticsPage)),
        }),
        ("Hệ thống", new[]
        {
            new Muc("⚙️", "Cấu hình", "Phí giao, phí nền tảng, hoàn tiền, quy định", nameof(AdminConfigPage)),
            new Muc("📢", "Gửi thông báo", "Thông báo toàn hệ thống hoặc theo nhóm", nameof(AdminNotifyPage)),
            new Muc("🛡", "Phân quyền", "Admin tổng / Quản lý / Nhân viên hỗ trợ", "staff"),
            new Muc("🧾", "Nhật ký hệ thống", "Theo dõi thao tác người dùng / admin", nameof(AdminAuditLogPage)),
            new Muc("🧠", "Vận hành thông minh", "Dự báo nhu cầu, gợi ý tài xế, gợi ý ghép đơn", nameof(AdminThongMinhPage)),
            new Muc("🔄", "Quy trình hoạt động", "Khách → Backend → Quán → Tài xế → Hoàn thành, số đơn từng bước", nameof(AdminQuyTrinhPage)),
            new Muc("📡", "Giám sát hệ thống", "Lỗi API, lỗi thanh toán, thời gian phản hồi, bất thường đơn", nameof(AdminGiamSatPage)),
            new Muc("🔐", "Bảo mật & quyền riêng tư", "HTTPS, phân quyền, mật khẩu, định vị, nhật ký nhạy cảm", nameof(AdminBaoMatPage)),
            new Muc("🗺", "Khóa bản đồ Goong", "Nhập khóa để bật lộ trình đường thật (chỉ Admin tổng)", nameof(AdminGoongPage)),
            new Muc("🧪", "Kiểm thử bản đồ & phí giao", "Geocoding địa chỉ thật, quãng đường/ETA, so phí ước tính với phí máy chủ, kiểm thử đồng bộ vị trí", nameof(AdminKiemTraBanDoPage)),
            new Muc("☑️", "Checklist nghiệm thu", "18 mục nghiệm thu: đánh dấu đã đạt, xem tiến độ, đặt lại", nameof(AdminNghiemThuPage)),
            new Muc("📋", "Checklist chức năng", "53 chức năng theo 6 nhóm đối tượng: % hoàn thành, tiến độ từng nhóm", nameof(AdminChecklistChucNangPage)),
            new Muc("🎯", "Thứ tự ưu tiên xây dựng", "3 cấp độ: MVP, hoàn thiện vận hành, quy mô doanh nghiệp (27 hạng mục)", nameof(AdminCapDoPage)),
            new Muc("🧩", "Module Backend dùng chung", "25 module + 17 chức năng hệ thống tự động, kèm yêu cầu retry / log / chống trùng", nameof(AdminModuleBackendPage)),
            new Muc("🗄", "Thiếu sót Database & Backend", "Phần IX: 12 hạng mục P1 (migration, schema, index, transaction, idempotency, worker, retry, log) kèm kết quả rà soát mã nguồn", nameof(AdminThieuSotBackendPage)),
            new Muc("🧪", "Thiếu sót kiểm thử & triển khai", "Phần X: 19 hạng mục (build, test, CI/CD, staging, production, phát hành Android/iOS, monitoring) kèm kết quả rà soát", nameof(AdminThieuSotKiemThuPage)),
            new Muc("🛠", "Chức năng Admin & Super Admin", "Dashboard, tài khoản, khách, nhà hàng, tài xế, đơn, phí, khuyến mãi, nội dung, báo cáo, cấu hình + Super Admin (178 chức năng)", nameof(AdminChucNangAdminPage)),
            new Muc("🛵", "Chức năng tài xế", "63 chức năng: giao hàng, đơn đang giao, thu nhập, thưởng, hỗ trợ — đánh dấu tiến độ", nameof(AdminChucNangTaiXePage)),
            new Muc("👑", "Super Admin – toàn nền tảng", "Gói dịch vụ, giới hạn sử dụng, thanh toán dịch vụ + lối tắt giám sát / bảo mật / nhật ký / sao lưu", nameof(AdminSuperAdminPage)),
            new Muc("🗓", "Lộ trình & đội ngũ", "12 giai đoạn triển khai, tiến độ và người phụ trách từng vai trò", nameof(AdminLoTrinhPage)),
            new Muc("💾", "Sao lưu & phục hồi", "Sao lưu định kỳ, kiểm tra và khôi phục dữ liệu", nameof(AdminSaoLuuPage)),
        }),
    };

    /// <summary>Lối tắt cho việc làm hằng ngày (hiện ở đầu trang, luôn thấy không cần cuộn).</summary>
    private static readonly Muc[] LoiTat =
    {
        new("📦", "Đơn hàng", "", nameof(AdminOrdersPage), "donDangXuLy"),
        new("🧭", "Điều phối", "", nameof(AdminDispatchPage), "donChuaCoTaiXe"),
        new("📣", "Khiếu nại", "", nameof(AdminIssuesPage), "khieuNaiCho"),
        new("✅", "Duyệt quán", "", nameof(AdminVendorApprovalPage), "gianHangChoDuyet"),
        new("👥", "Khách hàng", "", nameof(AdminCustomerListPage)),
        new("🏬", "Gian hàng", "", nameof(AdminVendorListPage)),
        new("📥", "Xuất Excel", "", nameof(AdminXuatExcelPage)),
        new("💳", "Thanh toán", "", nameof(AdminPaymentsPage), "hoanTienCho"),
    };

    private readonly Dictionary<string, long> _soDem = new();
    private readonly List<(Label L, string Khoa)> _demLoiTat = new();
    private readonly List<(Label L, string Khoa)> _demDanhSach = new();
    private readonly Label _tomTat = AdminUi.Nhan("", 12.5, dam: true);
    private readonly VerticalStackLayout _nd = new() { Spacing = 12, Padding = new Thickness(16, 12, 16, 28) };
    private readonly VerticalStackLayout _danhSach = new() { Spacing = 10 };
    private readonly HorizontalStackLayout _chip = new() { Spacing = 8 };
    private readonly Entry _tim;
    private string _nhom = "";       // "" = tất cả
    private string _tuKhoa = "";
    private int _cot = 2;

    public AdminHubPage()
    {
        Title = "Quản lý";
        Shell.SetNavBarIsVisible(this, false);
        AdminUi.NenTrang(this);
        var (khung, o) = AdminUi.OTimKiem("Tìm chức năng… (vd: khách, quán, doanh thu, excel)");
        _tim = o;
        var tre = new Services.TreTimKiem();
        _tim.TextChanged += (_, e) => { _tuKhoa = e.NewTextValue ?? ""; tre.Chay(VeDanhSach); };

        _nd.Add(_tomTat);
        _nd.Add(khung);
        _nd.Add(AdminUi.Nhan("LỐI TẮT", 11.5, dam: true, mo: true));
        _loiTatKhung = new Grid { ColumnSpacing = 10, RowSpacing = 10 };
        _nd.Add(_loiTatKhung);
        _nd.Add(new ScrollView { Orientation = ScrollOrientation.Horizontal, Content = _chip });
        _nd.Add(_danhSach);

        var cuon = new ScrollView { Content = _nd };
        Content = AdminUi.KhungTrang("quanly", AdminUi.ThanhTieuDe("Quản lý", "Tất cả chức năng quản trị"), cuon);
        SizeChanged += (_, _) =>
        {
            var c = Width > 1100 ? 4 : Width > 760 ? 3 : 2;
            if (c != _cot) { _cot = c; VeTatCa(); }
        };
        VeTatCa();
    }

    private readonly Grid _loiTatKhung;

    private void VeTatCa()
    {
        try { VeLoiTat(); VeChip(); VeDanhSach(); }
        catch (Exception ex) { CrashLog.Ghi("AdminHub.Ve", ex); }
    }

    private void VeLoiTat()
    {
        _loiTatKhung.Children.Clear();
        _loiTatKhung.ColumnDefinitions.Clear();
        _loiTatKhung.RowDefinitions.Clear();
        _demLoiTat.Clear();
        const int cot = 4;   // lối tắt luôn 4 cột: icon lớn, nhãn ngắn
        for (var c = 0; c < cot; c++) _loiTatKhung.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
        for (var i = 0; i < LoiTat.Length; i++)
        {
            if (i % cot == 0) _loiTatKhung.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
            _loiTatKhung.Add(DungLoiTat(LoiTat[i]), i % cot, i / cot);
        }
    }

    private View DungLoiTat(Muc m)
    {
        var the = AdminUi.The(6);
        var st = new VerticalStackLayout { Spacing = 3, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center };
        var bieuTuong = new Grid { HorizontalOptions = LayoutOptions.Center };
        bieuTuong.Add(new Label { Text = m.Icon, FontSize = 26, HorizontalOptions = LayoutOptions.Center });
        if (m.KhoaDem != null) bieuTuong.Add(TaoNhanDem(m.KhoaDem, goc: true));
        st.Add(bieuTuong);
        var ten = AdminUi.Nhan(m.Ten, 11.5, dam: true);
        ten.HorizontalTextAlignment = TextAlignment.Center;
        ten.LineBreakMode = LineBreakMode.TailTruncation;
        st.Add(ten);
        the.Content = st;
        the.HeightRequest = 78;
        GanMo(the, m);
        return the;
    }

    private Label TaoNhanDem(string khoa, bool goc)
    {
        var l = new Label
        {
            FontSize = 10, FontAttributes = FontAttributes.Bold, TextColor = Colors.White, BackgroundColor = Color.FromArgb(AdminUi.Do),
            Padding = new Thickness(5, 1), IsVisible = false, VerticalOptions = goc ? LayoutOptions.Start : LayoutOptions.Center,
            HorizontalOptions = goc ? LayoutOptions.End : LayoutOptions.End, Margin = goc ? new Thickness(0, -4, -14, 0) : new Thickness(0),
        };
        (goc ? _demLoiTat : _demDanhSach).Add((l, khoa));
        if (_soDem.TryGetValue(khoa, out var n) && n > 0) { l.Text = n > 99 ? "99+" : n.ToString(); l.IsVisible = true; }
        return l;
    }

    private void VeChip()
    {
        _chip.Children.Clear();
        var ten = new List<string> { "Tất cả" };
        ten.AddRange(Cay.Select(c => c.Nhom));
        foreach (var t in ten)
        {
            var nhom = t == "Tất cả" ? "" : t;
            var nut = AdminUi.NutTab(t, _nhom == nhom);
            nut.Clicked += (_, _) => { _nhom = nhom; VeChip(); VeDanhSach(); };
            _chip.Add(nut);
        }
    }

    private void VeDanhSach()
    {
        _danhSach.Children.Clear();
        _demDanhSach.Clear();
        var tk = (_tuKhoa ?? "").Trim();
        var coTim = tk.Length > 0;
        var thay = false;
        foreach (var (nhom, ds) in Cay)
        {
            if (!coTim && _nhom != "" && nhom != _nhom) continue;
            var khop = ds.Where(m => !coTim || (m.Ten + " " + m.MoTa + " " + nhom).Contains(tk, StringComparison.OrdinalIgnoreCase)).ToList();
            if (khop.Count == 0) continue;
            thay = true;
            _danhSach.Add(AdminUi.Nhan(nhom.ToUpperInvariant() + $"  ({khop.Count})", 11.5, dam: true, mo: true));
            var luoi = new Grid { ColumnSpacing = 10, RowSpacing = 10 };
            for (var c = 0; c < _cot; c++) luoi.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
            for (var i = 0; i < khop.Count; i++)
            {
                if (i % _cot == 0) luoi.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
                luoi.Add(DungO(khop[i]), i % _cot, i / _cot);
            }
            _danhSach.Add(luoi);
        }
        if (!thay) _danhSach.Add(AdminUi.Nhan("Không có chức năng nào khớp \"" + tk + "\".", 12.5, mo: true));
    }

    private View DungO(Muc m)
    {
        var the = AdminUi.The(10);
        the.MinimumHeightRequest = 92;
        var st = new VerticalStackLayout { Spacing = 3 };
        var dau = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        dau.Add(new Label { Text = m.Icon, FontSize = 24 }, 0, 0);
        if (m.KhoaDem != null) dau.Add(TaoNhanDem(m.KhoaDem, goc: false), 1, 0);
        st.Add(dau);
        st.Add(AdminUi.Nhan(m.Ten, 13.5, dam: true));
        var mt = AdminUi.Nhan(m.MoTa, 11, mo: true);
        mt.MaxLines = 2; mt.LineBreakMode = LineBreakMode.TailTruncation;
        st.Add(mt);
        the.Content = st;
        GanMo(the, m);
        return the;
    }

    private void GanMo(View v, Muc m)
    {
        var tap = new TapGestureRecognizer();
        tap.Tapped += async (_, _) =>
        {
            try
            {
                var route = m.Route == "staff" ? (DuLieuService.DangOnline ? nameof(AdminStaffOnlinePage) : nameof(AdminStaffPage)) : m.Route;
                if (m.Route == "staff" && !await PhanQuyenService.KiemTraAsync(this, Quyen.QuanLyNhanVien)) return;
                await Shell.Current.GoToAsync(route);
            }
            catch (Exception ex) { CrashLog.Ghi("AdminHub -> " + m.Route, ex); }
        };
        v.GestureRecognizers.Add(tap);
    }

    private void CapNhatDem()
    {
        foreach (var (l, khoa) in _demLoiTat.Concat(_demDanhSach))
        {
            var n = _soDem.TryGetValue(khoa, out var v) ? v : 0;
            l.Text = n > 99 ? "99+" : n.ToString();
            l.IsVisible = n > 0;
        }
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        try
        {
            var r = await ApiClient.GetAsync<JsonElement>("api/mobile/admin/tong-quan");
            if (!r.ThanhCong) { _tomTat.Text = "Đang ở chế độ ngoại tuyến — số việc chờ xử lý chỉ hiện khi online."; return; }
            var d = r.DuLieu;
            foreach (var khoa in Cay.SelectMany(c => c.Muc).Concat(LoiTat).Select(m => m.KhoaDem).Where(k => k != null).Distinct())
                _soDem[khoa!] = J.L(d, khoa!);
            CapNhatDem();
            _tomTat.Text = $"Hôm nay: {J.L(d, "donHomNay")} đơn · doanh thu {AdminUi.Tien(J.D(d, "doanhThuHomNay"))}. COD chưa đối soát: {J.L(d, "codChuaDoiSoat")} đơn.";
        }
        catch (Exception ex) { CrashLog.Ghi("AdminHub", ex); }
    }
}
