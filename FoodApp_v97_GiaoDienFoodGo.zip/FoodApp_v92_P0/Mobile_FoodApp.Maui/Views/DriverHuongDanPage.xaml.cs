namespace FoodApp.Maui.Views;

/// <summary>Hướng dẫn và quy định giao hàng cho tài xế (nội dung cố định, khớp trang web TaiXe/HuongDan).</summary>
public partial class DriverHuongDanPage : ContentPage
{
    public DriverHuongDanPage()
    {
        InitializeComponent();
        LblHanPhanHoi.Text = "• Đơn chờ nhận có hạn phản hồi (mặc định 5 phút, quản trị có thể chỉnh). Quá hạn mà chưa ai nhận, đơn được điều phối lại và báo Quản trị. Hạn hiện trên thẻ đơn.";
    }

    private async void OnBackTapped(object? sender, EventArgs e) => await Shell.Current.GoToAsync("..");
}
