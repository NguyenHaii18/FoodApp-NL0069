using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Danh sách quán đã thả tim (thả tim ở trang menu của quán). Chạm để mở quán, chạm ♥ để bỏ.</summary>
public partial class YeuThichPage : ContentPage
{
    public YeuThichPage() { InitializeComponent(); }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        Ve();
        await TaiKhoanService.DongBoYeuThichAsync();     // v64: kéo yêu thích từ máy chủ (đổi máy vẫn còn)
        Ve();
    }

    private Color Mau(string k) => (Color)Resources[k];

    private void Ve()
    {
        DanhSach.Children.Clear();
        var ids = TaiKhoanService.LayYeuThich();
        var quan = MockData.DanhSachGianHang.Where(g => ids.Contains(g.Id)).ToList();
        var idMon = TaiKhoanService.LayYeuThichMon();
        var mon = MockData.DanhSachMonAn.Where(m => idMon.Contains(m.Id)).ToList();
        if (quan.Count == 0 && mon.Count == 0)
        {
            DanhSach.Children.Add(new Label { Text = "Chưa có quán hoặc món yêu thích.\nMở quán/món và chạm ♡ để lưu lại.", HorizontalTextAlignment = TextAlignment.Center,
                Style = (Style)Resources["SubtitleLabel"], HorizontalOptions = LayoutOptions.Center, Margin = new Thickness(0, 40) });
            return;
        }

        foreach (var g in quan)
        {
            var thong = new VerticalStackLayout { Spacing = 2, VerticalOptions = LayoutOptions.Center };
            thong.Children.Add(new Label { Text = g.TenGianHang, FontAttributes = FontAttributes.Bold, FontSize = 14.5 });
            thong.Children.Add(new Label { Text = g.DiaChi, FontSize = 12, TextColor = Mau("TextGrey") });
            thong.Children.Add(new Label { Text = $"⭐ {g.DanhGia}   ⏱ {g.ThoiGianGiaoPhut} phút", FontSize = 12, TextColor = Mau("TextGrey") });
            if (g.CoKhuyenMai) thong.Children.Add(new Label { Text = g.NhanKhuyenMai, FontSize = 11.5, FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb("#B45309") });

            var tim = new Label { Text = "♥", FontSize = 24, TextColor = Mau("Danger"), VerticalOptions = LayoutOptions.Center };
            var id = g.Id;
            tim.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(() => { TaiKhoanService.DaoYeuThich(id); Ve(); }) });

            var luoi = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 12 };
            luoi.Add(new Label { Text = g.HinhAnh, FontSize = 32, VerticalOptions = LayoutOptions.Center }, 0);
            luoi.Add(thong, 1);
            luoi.Add(tim, 2);

            var the = new Frame { Style = (Style)Resources["CardFrame"], Content = luoi };
            var gh = g;
            the.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(async () => await Shell.Current.GoToAsync(nameof(MenuCartPage), new Dictionary<string, object> { { "GianHang", gh } }))
            });
            DanhSach.Children.Add(the);
        }

        if (mon.Count > 0)
        {
            DanhSach.Children.Add(new Label { Text = "🍽️ Món yêu thích", FontAttributes = FontAttributes.Bold, FontSize = 15, Margin = new Thickness(0, 12, 0, 2) });
            foreach (var m in mon)
            {
                var gh = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == m.GianHangId);
                var thong = new VerticalStackLayout { Spacing = 2, VerticalOptions = LayoutOptions.Center };
                thong.Children.Add(new Label { Text = m.TenMon, FontAttributes = FontAttributes.Bold, FontSize = 14.5 });
                thong.Children.Add(new Label { Text = $"{m.Gia:N0}đ" + (gh is null ? "" : $" · {gh.TenGianHang}"), FontSize = 12, TextColor = Mau("TextGrey") });
                if (!m.ConHang || m.TamNgungBan) thong.Children.Add(new Label { Text = m.TinhTrangText, FontSize = 11.5, TextColor = Mau("Danger") });
                var tim = new Label { Text = "♥", FontSize = 24, TextColor = Mau("Danger"), VerticalOptions = LayoutOptions.Center };
                var id = m.Id;
                tim.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(() => { TaiKhoanService.DaoYeuThichMon(id); Ve(); }) });
                var luoi = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 12 };
                luoi.Add(new Label { Text = m.HinhAnh, FontSize = 30, VerticalOptions = LayoutOptions.Center }, 0);
                luoi.Add(thong, 1);
                luoi.Add(tim, 2);
                var the = new Frame { Style = (Style)Resources["CardFrame"], Content = luoi };
                var monMo = m; var ghMo = gh;
                the.GestureRecognizers.Add(new TapGestureRecognizer
                {
                    Command = new Command(async () => await Shell.Current.GoToAsync(nameof(MonAnChiTietPage),
                        new Dictionary<string, object> { { "Mon", monMo }, { "GianHang", ghMo! } }))
                });
                DanhSach.Children.Add(the);
            }
        }
    }
}
