using System.Text.Json;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Một dòng hiển thị: tiêu đề, các dòng phụ và nhãn trạng thái (chip) bên phải.
/// Khi có <paramref name="Avatar"/>/<paramref name="AnhUrl"/>/<paramref name="PhaiTren"/> thì vẽ dạng hàng gọn:
/// ảnh đại diện bên trái, thông tin ở giữa, giờ + số tiền (PhaiTren/PhaiDuoi) bên phải.
/// </summary>
public sealed record AdminDong(string TieuDe, string[] Dong, string? Nhan = null, string? MauNhan = null,
    string? Avatar = null, string? AnhUrl = null, string? PhaiTren = null, string? PhaiDuoi = null,
    string[]? Anh = null);   // v64: dải ảnh nhỏ dưới thẻ (địa chỉ đầy đủ), chạm để mở ảnh lớn

/// <summary>Nút thao tác dưới mỗi dòng (hoặc nút chung phía trên danh sách khi dùng ở HanhDongChung).</summary>
public sealed record AdminHanhDong(string Nhan, string Mau, Func<JsonElement, bool>? Hien, Func<AdminListPage, JsonElement, Task> Chay);

/// <summary>Cấu hình một trang danh sách: nguồn dữ liệu (API), cách hiển thị từng dòng, bộ lọc, thao tác.</summary>
public sealed class AdminListCauHinh
{
    public string TieuDe { get; init; } = "";
    /// <summary>Tên các tab (để trống nếu không có tab).</summary>
    public string[] Tab { get; init; } = Array.Empty<string>();
    /// <summary>Chữ gợi ý ô tìm kiếm (để trống = ẩn ô tìm kiếm).</summary>
    public string GoiYTimKiem { get; init; } = "";
    /// <summary>true = API không hỗ trợ tìm kiếm, lọc theo chữ ngay trên máy.</summary>
    public bool TimTrenMay { get; init; }
    /// <summary>Bộ lọc theo tab: (nhãn, giá trị). Giá trị được truyền cho <see cref="Url"/> (thường là một đoạn query).</summary>
    public Func<int, (string Nhan, string GiaTri)[]> Loc { get; init; } = _ => Array.Empty<(string Nhan, string GiaTri)>();
    /// <summary>(tab, từ khóa, giá trị lọc) → địa chỉ API.</summary>
    public Func<int, string, string, string> Url { get; init; } = (_, _, _) => "";
    /// <summary>Lấy danh sách dòng từ JSON gốc (mặc định: JSON là mảng).</summary>
    public Func<int, JsonElement, IEnumerable<JsonElement>>? LayDs { get; init; }
    public Func<int, JsonElement, AdminDong> Dong { get; init; } = (_, _) => new AdminDong("", Array.Empty<string>());
    public Func<int, AdminHanhDong[]> HanhDong { get; init; } = _ => Array.Empty<AdminHanhDong>();
    public Func<int, AdminHanhDong[]> HanhDongChung { get; init; } = _ => Array.Empty<AdminHanhDong>();
    /// <summary>Dòng tóm tắt hiện phía trên danh sách (vd tổng COD chưa đối soát).</summary>
    public Func<int, JsonElement, string?>? TomTat { get; init; }
    /// <summary>Bấm vào thẻ.</summary>
    public Func<AdminListPage, JsonElement, Task>? Mo { get; init; }
    /// <summary>Lọc trên máy: (tab, dòng, giá trị lọc) → có giữ lại không.</summary>
    public Func<int, JsonElement, string, bool>? LocMay { get; init; }
    /// <summary>Lọc trên máy theo TAB đang chọn (vd tab "Đang xử lý" gồm nhiều trạng thái mà API chỉ lọc được một).</summary>
    public Func<int, JsonElement, bool>? LocTheoTab { get; init; }
    /// <summary>Mục của thanh tab dưới cần tô sáng (home | manage | issues | profile). Trống = không hiện thanh tab dưới.</summary>
    public string NavMuc { get; init; } = "";
}

/// <summary>
/// Trang danh sách quản trị dựng hoàn toàn bằng mã: tab + tìm kiếm + bộ lọc + kéo để làm mới + nút thao tác dưới mỗi thẻ.
/// Dữ liệu lấy từ <c>api/mobile/admin/*</c> (cần đang online); mỗi trang cụ thể chỉ khai báo <see cref="AdminListCauHinh"/>.
/// </summary>
public class AdminListPage : ContentPage
{
    private readonly AdminListCauHinh _c;
    private int _tab;
    private string _tuKhoa = "";
    private string _loc = "";
    private bool _dangTai, _dangDatLoc;
    private string _urlCuoi = "";
    private (string Nhan, string GiaTri)[] _dsLoc = Array.Empty<(string Nhan, string GiaTri)>();

    private readonly HorizontalStackLayout _tabBar = new() { Spacing = 8 };
    private readonly Entry _tim;
    private readonly Picker _pLoc = new() { Title = "Lọc" };
    private readonly FlexLayout _chung = new() { Wrap = Microsoft.Maui.Layouts.FlexWrap.Wrap };
    private readonly Label _tomTat = AdminUi.Nhan("", 12.5, dam: true);
    private readonly VerticalStackLayout _ds = new() { Spacing = 10 };
    private readonly ActivityIndicator _dang = new() { IsRunning = false, IsVisible = false, Color = Color.FromArgb(AdminUi.Tim), HeightRequest = 28 };
    private readonly RefreshView _lamMoi = new() { RefreshColor = Color.FromArgb(AdminUi.Tim) };

    /// <summary>JSON gốc của lần tải gần nhất (để thao tác của dòng dùng dữ liệu kèm theo, vd danh sách tài xế khi điều phối).</summary>
    public JsonElement Goc { get; private set; }
    public int TabHienTai => _tab;

    public AdminListPage(AdminListCauHinh c)
    {
        _c = c;
        Title = c.TieuDe;
        AdminUi.NenTrang(this);
        var (khungTim, oTim) = AdminUi.OTimKiem(c.GoiYTimKiem == "" ? "Tìm kiếm…" : c.GoiYTimKiem);
        _tim = oTim;

        var dau = new VerticalStackLayout { Spacing = 4, Padding = new Thickness(16, 8, 16, 0) };
        if (c.Tab.Length > 1)
        {
            for (var i = 0; i < c.Tab.Length; i++)
            {
                var idx = i;
                var nut = AdminUi.NutTab(c.Tab[i], i == 0);
                nut.Clicked += async (_, _) => { _tab = idx; _tuKhoa = ""; _tim.Text = ""; DatLaiTab(); DatBoLoc(); await TaiAsync(); };
                _tabBar.Add(nut);
            }
            dau.Add(new ScrollView { Orientation = ScrollOrientation.Horizontal, HorizontalScrollBarVisibility = ScrollBarVisibility.Never, Content = _tabBar });
        }

        if (c.GoiYTimKiem != "")
        {
            _tim.Completed += async (_, _) => { _tuKhoa = _tim.Text?.Trim() ?? ""; await TaiAsync(); };
            _tim.TextChanged += async (_, e) =>
            {
                if (string.IsNullOrEmpty(e.NewTextValue) && _tuKhoa != "") { _tuKhoa = ""; await TaiAsync(); }
                else if (c.TimTrenMay) { _tuKhoa = e.NewTextValue?.Trim() ?? ""; await TaiAsync(false); }
            };
            dau.Add(khungTim);
        }

        _pLoc.SelectedIndexChanged += async (_, _) =>
        {
            if (_dangDatLoc || _pLoc.SelectedIndex < 0 || _pLoc.SelectedIndex >= _dsLoc.Length) return;
            _loc = _dsLoc[_pLoc.SelectedIndex].GiaTri;
            await TaiAsync();
        };
        dau.Add(_pLoc);
        DatBoLoc();

        var noiDung = new VerticalStackLayout { Spacing = 10, Padding = new Thickness(16, 4, 16, 28) };
        noiDung.Add(_chung);
        noiDung.Add(_tomTat);
        noiDung.Add(_dang);
        noiDung.Add(_ds);

        _lamMoi.Content = new ScrollView { Content = noiDung };
        _lamMoi.Refreshing += async (_, _) => await TaiAsync();

        var goc = new Grid { RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Star), new RowDefinition(GridLength.Auto) } };
        goc.Add(dau, 0, 0);
        goc.Add(_lamMoi, 0, 1);
        if (c.NavMuc != "") goc.Add(new AdminNavBar { Muc = c.NavMuc }, 0, 2);
        Content = goc;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await TaiAsync();
    }

    private void DatLaiTab()
    {
        for (var i = 0; i < _tabBar.Children.Count; i++)
            if (_tabBar.Children[i] is Button b)
            {
                var dung = i == _tab;
                b.BackgroundColor = AdminUi.MauTab(dung);
                b.TextColor = AdminUi.MauChuTab(dung);
            }
    }

    private void DatBoLoc()
    {
        _dsLoc = _c.Loc(_tab);
        _dangDatLoc = true;
        _pLoc.ItemsSource = _dsLoc.Select(x => x.Nhan).ToList();
        _pLoc.IsVisible = _dsLoc.Length > 0;
        _pLoc.SelectedIndex = _dsLoc.Length > 0 ? 0 : -1;
        _loc = _dsLoc.Length > 0 ? _dsLoc[0].GiaTri : "";
        _dangDatLoc = false;
    }

    private void HienThongBao(string noiDung)
    {
        _ds.Add(AdminUi.Nhan(noiDung, 13, mo: true));
        var thu = AdminUi.Nut("Thử lại", AdminUi.Tim);
        thu.HorizontalOptions = LayoutOptions.Start;
        thu.Clicked += async (_, _) => await TaiAsync();
        _ds.Add(thu);
    }

    public async Task TaiAsync(bool lamMoi = true)
    {
        if (_dangTai) return;
        _dangTai = true;
        try
        {
            _dang.IsVisible = _dang.IsRunning = true;
            var url = _c.Url(_tab, _tuKhoa, _loc);
            _ds.Children.Clear();
            _chung.Children.Clear();
            _tomTat.Text = "";
            if (!lamMoi && _c.TimTrenMay && _urlCuoi == url && Goc.ValueKind != JsonValueKind.Undefined)
            {
                // chỉ lọc lại chữ đang gõ trên dữ liệu đã tải, không gọi lại máy chủ
            }
            else
            {
                var r = await ApiClient.GetAsync<JsonElement>(url);
                if (!r.ThanhCong)
                {
                    HienThongBao(r.MatKetNoi
                        ? "Không kết nối được máy chủ. Chức năng này cần ứng dụng đang kết nối (online) với máy chủ.\n" + r.ThongDiep
                        : r.ThongDiep);
                    return;
                }
                Goc = r.DuLieu;
                _urlCuoi = url;
            }

            var tomTat = _c.TomTat?.Invoke(_tab, Goc);
            _tomTat.IsVisible = !string.IsNullOrEmpty(tomTat);
            _tomTat.Text = tomTat ?? "";

            foreach (var h in _c.HanhDongChung(_tab))
            {
                var nut = AdminUi.Nut(h.Nhan, h.Mau, day: true);
                nut.Margin = new Thickness(0, 0, 8, 6);
                var hh = h;
                nut.Clicked += async (_, _) => { await hh.Chay(this, default); await TaiAsync(); };
                _chung.Add(nut);
            }

            IEnumerable<JsonElement> nguon = _c.LayDs != null
                ? _c.LayDs(_tab, Goc)
                : (Goc.ValueKind == JsonValueKind.Array ? Goc.EnumerateArray() : Enumerable.Empty<JsonElement>());
            var rows = nguon.ToList();
            if (_c.LocTheoTab != null) rows = rows.Where(x => _c.LocTheoTab(_tab, x)).ToList();
            if (_c.LocMay != null && _loc != "") rows = rows.Where(x => _c.LocMay(_tab, x, _loc)).ToList();

            var hienThi = rows.Select(x => (Row: x, Dong: _c.Dong(_tab, x))).ToList();
            if (_c.TimTrenMay && _tuKhoa != "")
                hienThi = hienThi.Where(x => (x.Dong.TieuDe + " " + string.Join(" ", x.Dong.Dong)).Contains(_tuKhoa, StringComparison.OrdinalIgnoreCase)).ToList();

            if (hienThi.Count == 0) { _ds.Add(AdminUi.Nhan("Không có dữ liệu phù hợp.", 13, mo: true)); return; }
            _ds.Add(AdminUi.Nhan($"{hienThi.Count} mục", 11.5, mo: true));
            foreach (var (row, d) in hienThi) _ds.Add(DungThe(row, d));
        }
        finally
        {
            _dang.IsVisible = _dang.IsRunning = false;
            _lamMoi.IsRefreshing = false;
            _dangTai = false;
        }
    }

    private View DungThe(JsonElement row, AdminDong d)
    {
        var the = AdminUi.The();
        var st = new VerticalStackLayout { Spacing = 4 };

        if (d.Avatar != null || d.AnhUrl != null || d.PhaiTren != null)
        {
            // Hàng gọn: [ảnh] tiêu đề / dòng phụ / chip      giờ / số tiền
            var luoi = new Grid
            {
                ColumnSpacing = 12,
                ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
            };
            luoi.Add(AdminUi.AnhDaiDien(d.Avatar, d.AnhUrl), 0, 0);
            var giua = new VerticalStackLayout { Spacing = 2, VerticalOptions = LayoutOptions.Center };
            giua.Add(AdminUi.Nhan(d.TieuDe, 14.5, dam: true));
            foreach (var s in d.Dong.Where(x => !string.IsNullOrWhiteSpace(x))) giua.Add(AdminUi.Nhan(s, 11.5, mo: true));
            if (!string.IsNullOrEmpty(d.Nhan))
            {
                var chip = AdminUi.Chip(d.Nhan!, d.MauNhan ?? AdminUi.Tim);
                chip.HorizontalOptions = LayoutOptions.Start;
                chip.Margin = new Thickness(0, 3, 0, 0);
                giua.Add(chip);
            }
            luoi.Add(giua, 1, 0);
            var phai = new VerticalStackLayout { Spacing = 4, VerticalOptions = LayoutOptions.Start, HorizontalOptions = LayoutOptions.End };
            if (!string.IsNullOrEmpty(d.PhaiTren))
            {
                var t = AdminUi.Nhan(d.PhaiTren!, 10.5, mo: true);
                t.HorizontalTextAlignment = TextAlignment.End;
                phai.Add(t);
            }
            if (!string.IsNullOrEmpty(d.PhaiDuoi))
            {
                var t = AdminUi.Nhan(d.PhaiDuoi!, 13.5, dam: true);
                t.HorizontalTextAlignment = TextAlignment.End;
                phai.Add(t);
            }
            luoi.Add(phai, 2, 0);
            st.Add(luoi);
        }
        else
        {
            var dau = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 8 };
            dau.Add(AdminUi.Nhan(d.TieuDe, 14.5, dam: true), 0, 0);
            if (!string.IsNullOrEmpty(d.Nhan)) dau.Add(AdminUi.Chip(d.Nhan!, d.MauNhan ?? AdminUi.Tim), 1, 0);
            st.Add(dau);

            foreach (var s in d.Dong.Where(x => !string.IsNullOrWhiteSpace(x))) st.Add(AdminUi.Nhan(s, 12, mo: true));
        }

        if (d.Anh is { Length: > 0 })
        {
            var daiAnh = new HorizontalStackLayout { Spacing = 8, Margin = new Thickness(0, 6, 0, 0) };
            foreach (var linkAnh in d.Anh.Where(x => !string.IsNullOrWhiteSpace(x)).Take(3))
            {
                var duongDan = linkAnh;
                if (!Uri.TryCreate(duongDan, UriKind.Absolute, out var uriAnh)) continue;
                var khungAnh = new Border
                {
                    WidthRequest = 72, HeightRequest = 72, StrokeThickness = 0, BackgroundColor = Color.FromArgb("#EDE4FF"),
                    StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(10) },
                    Content = new Image { Source = ImageSource.FromUri(uriAnh), Aspect = Aspect.AspectFill },
                };
                var chamAnh = new TapGestureRecognizer();
                chamAnh.Tapped += async (_, _) => { try { await Launcher.Default.OpenAsync(duongDan); } catch { } };
                khungAnh.GestureRecognizers.Add(chamAnh);
                daiAnh.Add(khungAnh);
            }
            st.Add(daiAnh);
        }

        var hd = _c.HanhDong(_tab).Where(h => h.Hien == null || h.Hien(row)).ToList();
        if (hd.Count > 0)
        {
            var fl = new FlexLayout { Wrap = Microsoft.Maui.Layouts.FlexWrap.Wrap, Margin = new Thickness(0, 6, 0, 0) };
            foreach (var h in hd)
            {
                var nut = AdminUi.Nut(h.Nhan, h.Mau);
                nut.Margin = new Thickness(0, 0, 8, 6);
                var hh = h;
                nut.Clicked += async (_, _) =>
                {
                    try { await hh.Chay(this, row); }
                    catch (Exception ex) { CrashLog.Ghi("AdminHanhDong:" + hh.Nhan, ex); await DisplayAlert("Có lỗi", ex.Message, "Đóng"); }
                    await TaiAsync();
                };
                fl.Add(nut);
            }
            st.Add(fl);
        }

        the.Content = st;
        if (_c.Mo != null)
        {
            var tap = new TapGestureRecognizer();
            tap.Tapped += async (_, _) => await _c.Mo(this, row);
            the.GestureRecognizers.Add(tap);
        }
        return the;
    }
}
