using System.Text.RegularExpressions;
using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Chi tiết khiếu nại / vấn đề: nội dung, người báo, đơn liên quan → Nhận xử lý / Đánh dấu đã giải quyết.</summary>
[QueryProperty(nameof(VanDe), "VanDe")]
public sealed class AdminIssueDetailPage : ContentPage
{
    public VanDeHeThong? VanDe { get; set; }
    private readonly VerticalStackLayout _nd = new() { Spacing = 10, Padding = new Thickness(16, 10, 16, 28) };

    public AdminIssueDetailPage()
    {
        Title = "Chi tiết khiếu nại";
        AdminUi.NenTrang(this);
        Content = new ScrollView { Content = _nd };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (!await PhanQuyenService.KiemTraAsync(this, Quyen.XemTaiKhoan)) { await Shell.Current.GoToAsync(".."); return; }
        Ve();
    }

    private void Ve()
    {
        _nd.Children.Clear();
        if (VanDe is null) { _nd.Add(AdminUi.Nhan("Không tìm thấy khiếu nại.", mo: true)); return; }

        var the = AdminUi.The(14);
        var st = new VerticalStackLayout { Spacing = 6 };
        st.Add(AdminUi.Nhan(VanDe.TieuDe, 16, dam: true));
        st.Add(AdminUi.Nhan($"👤 {VanDe.NguonGoc}   •   {VanDe.NgayBaoCao:HH:mm dd/MM/yyyy}", 12, mo: true));
        st.Add(AdminUi.Nhan(VanDe.MoTa, 13.5));
        var mau = VanDe.TrangThai switch { TrangThaiVanDe.DaGiaiQuyet => "#16A34A", TrangThaiVanDe.DangXuLy => "#D97706", _ => "#DC2626" };
        var nhan = VanDe.TrangThai switch { TrangThaiVanDe.DaGiaiQuyet => "Đã giải quyết", TrangThaiVanDe.DangXuLy => "Đang xử lý", _ => "Mới phát sinh" };
        st.Add(AdminUi.Chip(nhan, mau));
        the.Content = st;
        _nd.Add(the);

        // Đơn hàng liên quan (mã nằm trong tiêu đề dạng "#1024")
        var m = Regex.Match(VanDe.TieuDe ?? "", "#([A-Za-z0-9_-]+)");
        if (m.Success)
        {
            var ma = m.Groups[1].Value;
            var xem = AdminUi.Nut($"📦 Xem đơn #{ma} và trạng thái giao hàng", AdminUi.Tim);
            xem.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(AdminOrderDetailPage), new Dictionary<string, object> { { "Id", ma } });
            _nd.Add(xem);
        }

        if (VanDe.TrangThai != TrangThaiVanDe.DaGiaiQuyet)
        {
            if (VanDe.TrangThai == TrangThaiVanDe.MoiPhatSinh)
            {
                var nhanXl = AdminUi.Nut("Nhận xử lý", AdminUi.Cam, day: true);
                nhanXl.Clicked += async (_, _) => await DoiTrangThaiAsync(TrangThaiVanDe.DangXuLy, "dang-xu-ly", "Nhận xử lý vấn đề");
                _nd.Add(nhanXl);
            }
            var xong = AdminUi.Nut("Đánh dấu đã giải quyết", AdminUi.Xanh, day: true);
            xong.Clicked += async (_, _) => await DoiTrangThaiAsync(TrangThaiVanDe.DaGiaiQuyet, "giai-quyet", "Giải quyết vấn đề");
            _nd.Add(xong);
        }
    }

    private async Task DoiTrangThaiAsync(TrangThaiVanDe moi, string duongDan, string nhatKy)
    {
        if (VanDe is null) return;
        if (!await PhanQuyenService.KiemTraAsync(this, Quyen.XuLyVanDe)) return;
        var cu = VanDe.TrangThai;
        VanDe.TrangThai = moi;
        VendorLocalStore.Luu();
        if (!await DuLieuService.GhiHoanTacAsync("PUT", $"api/mobile/admin/van-de/{VanDe.Id}/{duongDan}", null,
                () => { VanDe.TrangThai = cu; VendorLocalStore.Luu(); }))
        { Ve(); return; }
        NhatKyService.GhiQuanTri(nhatKy, VanDe.TieuDe);
        Ve();
        await DisplayAlert("Đã cập nhật", DuLieuService.ChuThichGhi($"Khiếu nại \"{VanDe.TieuDe}\" đã chuyển sang trạng thái mới."), "OK");
    }
}
