using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Theo dõi phí nền tảng và số tiền thực nhận của gian hàng theo ngày / tháng / năm.</summary>
public partial class VendorFinancePage : ContentPage
{
    private KyBaoCao _ky = KyBaoCao.Thang;
    private DateTime _moc = DateTime.Today;

    public VendorFinancePage()
    {
        InitializeComponent();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        Nap();
        await DuLieuService.TaiDonHangGianHangAsync(MockData.GianHangHienTai.Id);
        Nap();
    }

    private static Color Mau(string key) => VendorPalette.Get(key);

    private void OnChonKyNgay(object? s, EventArgs e) => DoiKy(KyBaoCao.Ngay);
    private void OnChonKyThang(object? s, EventArgs e) => DoiKy(KyBaoCao.Thang);
    private void OnChonKyNam(object? s, EventArgs e) => DoiKy(KyBaoCao.Nam);

    private void DoiKy(KyBaoCao ky)
    {
        _ky = ky;
        _moc = DateTime.Today;
        Nap();
    }

    private void OnKyTruoc(object? s, EventArgs e)
    {
        _moc = DoiTacService.LuiKy(_ky, _moc, -1);
        Nap();
    }

    private void OnKySau(object? s, EventArgs e)
    {
        var moi = DoiTacService.LuiKy(_ky, _moc, +1);
        if (DoiTacService.Khoang(_ky, moi).Tu > DateTime.Today) return;
        _moc = moi;
        Nap();
    }

    private static void ToNutKy(Button nut, bool dangChon)
    {
        nut.BackgroundColor = dangChon ? Mau("Primary") : Colors.White;
        nut.TextColor = dangChon ? Colors.White : Mau("TextGrey");
        nut.BorderColor = Mau("BorderColor");
        nut.BorderWidth = 1;
    }

    private void Nap()
    {
        // TODO: thay bằng GET /api/gian-hang/tai-chinh?ky=...&moc=... khi có API thật (server nên là nơi tính phí chính thức).
        var gh = MockData.GianHangHienTai;
        var donKy = DoiTacService.TrongKy(DoiTacService.DonCuaGianHang(gh.Id), _ky, _moc);
        var tc = DoiTacService.TinhTaiChinh(gh, donKy.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh));
        var tyLe = DoiTacService.TyLeChietKhau(gh);

        ToNutKy(BtnKyNgay, _ky == KyBaoCao.Ngay);
        ToNutKy(BtnKyThang, _ky == KyBaoCao.Thang);
        ToNutKy(BtnKyNam, _ky == KyBaoCao.Nam);
        LblNhanKy.Text = DoiTacService.NhanKy(_ky, _moc);
        BtnKySau.IsEnabled = DoiTacService.Khoang(_ky, DoiTacService.LuiKy(_ky, _moc, +1)).Tu <= DateTime.Today;

        LblThucNhan.Text = $"{tc.ThucNhan:N0}đ";
        LblSoDon.Text = $"{tc.SoDon} đơn hoàn thành";
        LblDoanhThuMon.Text = $"{tc.DoanhThuMon:N0}đ";
        LblGiamGia.Text = tc.GiamGiaQuanChiu > 0 ? $"−{tc.GiamGiaQuanChiu:N0}đ" : "0đ";
        LblNhanPhi.Text = $"Phí nền tảng ({tyLe:P0})";
        LblPhiNenTang.Text = tc.PhiNenTang > 0 ? $"−{tc.PhiNenTang:N0}đ" : "0đ";
        LblThucNhanChiTiet.Text = $"{tc.ThucNhan:N0}đ";

        var ghiChu = $"Phí nền tảng = {tyLe:P0} × (tiền món − giảm giá do quán tài trợ), chỉ tính trên đơn hoàn thành. " +
                     "Phí giao hàng thuộc về tài xế nên không nằm trong doanh thu của quán. Mã khuyến mãi toàn hệ thống do nền tảng chịu, không trừ vào quán.";
        LblGhiChu.Text = ghiChu;

        _tcHienTai = tc;
        NapBieuDo(tc);
        DsDon.ItemsSource = tc.ChiTiet;
        LblRong.IsVisible = tc.ChiTiet.Count == 0;
    }

    private async void OnChiTietGiaoDichTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is DongDonTaiChinh d)
            await Shell.Current.GoToAsync(nameof(VendorTransactionDetailPage), new Dictionary<string, object> { { "Dong", d } });
    }

    private KetQuaTaiChinh? _tcHienTai;

    /// <summary>Thực nhận theo thời gian: kỳ Ngày → theo giờ, Tháng → theo ngày, Năm → theo tháng.</summary>
    private void NapBieuDo(KetQuaTaiChinh tc)
    {
        var nhan = new List<string>(); var gt = new List<decimal>();
        if (_ky == KyBaoCao.Ngay)
        {
            for (int h = 0; h < 24; h++) { nhan.Add($"{h}h"); gt.Add(tc.ChiTiet.Where(d => d.Ngay.Hour == h).Sum(d => d.ThucNhan)); }
            LblTieuDeBieuDo.Text = "Thực nhận theo giờ";
        }
        else if (_ky == KyBaoCao.Thang)
        {
            var n = DateTime.DaysInMonth(_moc.Year, _moc.Month);
            for (int d = 1; d <= n; d++) { nhan.Add(d.ToString()); gt.Add(tc.ChiTiet.Where(x => x.Ngay.Day == d).Sum(x => x.ThucNhan)); }
            LblTieuDeBieuDo.Text = "Thực nhận theo ngày";
        }
        else
        {
            for (int m = 1; m <= 12; m++) { nhan.Add($"T{m}"); gt.Add(tc.ChiTiet.Where(x => x.Ngay.Month == m).Sum(x => x.ThucNhan)); }
            LblTieuDeBieuDo.Text = "Thực nhận theo tháng";
        }
        BieuDo.Dat(nhan, gt);
    }

    private async void OnXuatExcelClicked(object? sender, EventArgs e)
    {
        var tc = _tcHienTai;
        if (tc is null || tc.SoDon == 0) { await DisplayAlert("Chưa có dữ liệu", "Kỳ này chưa có đơn hoàn thành để xuất.", "OK"); return; }
        try
        {
            var gh = MockData.GianHangHienTai;
            var nhanKy = DoiTacService.NhanKy(_ky, _moc);
            var tongHop = new List<object?[]>
            {
                new object?[] { "Chỉ tiêu", "Giá trị" },
                new object?[] { "Gian hàng", gh.TenGianHang },
                new object?[] { "Kỳ báo cáo", nhanKy },
                new object?[] { "Số đơn hoàn thành", tc.SoDon },
                new object?[] { "Tiền món (đ)", tc.DoanhThuMon },
                new object?[] { "Giảm giá do quán tài trợ (đ)", tc.GiamGiaQuanChiu },
                new object?[] { $"Phí nền tảng {DoiTacService.TyLeChietKhau(gh):P0} (đ)", tc.PhiNenTang },
                new object?[] { "Thực nhận (đ)", tc.ThucNhan },
            };
            var chiTiet = new List<object?[]> { new object?[] { "Mã đơn", "Thời gian", "Tiền món (đ)", "Giảm giá quán (đ)", "Phí nền tảng (đ)", "Thực nhận (đ)" } };
            chiTiet.AddRange(tc.ChiTiet.OrderBy(d => d.Ngay).Select(d => new object?[] { d.DonHangId, d.Ngay, d.DoanhThuMon, d.GiamGiaQuanChiu, d.PhiNenTang, d.ThucNhan }));
            chiTiet.Add(new object?[] { "TỔNG", null, tc.DoanhThuMon, tc.GiamGiaQuanChiu, tc.PhiNenTang, tc.ThucNhan });

            var ten = $"TaiChinh_{_ky}_{_moc:yyyyMMdd}.xlsx";
            var path = Path.Combine(FileSystem.CacheDirectory, ten);
            XlsxXuat.Ghi(path, new XlsxXuat.Sheet("Tổng hợp", tongHop), new XlsxXuat.Sheet("Chi tiết đơn", chiTiet));
            await Share.Default.RequestAsync(new ShareFileRequest { Title = "Xuất báo cáo tài chính", File = new ShareFile(path) });
        }
        catch (Exception ex)
        {
            CrashLog.Ghi("VendorFinance.Xuat", ex);
            await DisplayAlert("Không xuất được", ex.Message, "OK");
        }
    }
}
