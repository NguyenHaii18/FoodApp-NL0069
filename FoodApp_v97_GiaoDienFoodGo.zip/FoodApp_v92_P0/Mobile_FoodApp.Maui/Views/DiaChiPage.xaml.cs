using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Sổ địa chỉ: thêm / sửa / xóa / đặt mặc định. Địa chỉ mặc định hiện ở trang chủ và tự điền khi thanh toán.</summary>
public partial class DiaChiPage : ContentPage
{
    private List<DiaChiLuu> _ds = new();

    public DiaChiPage() { InitializeComponent(); }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        _ds = TaiKhoanService.LayDiaChi();
        Ve();
        await DongBoAsync();
    }

    /// <summary>Online: đưa địa chỉ chỉ có trên máy lên máy chủ (bảng DiaChiKhachHang) rồi lấy danh sách chuẩn về. Lỗi giữa chừng: giữ nguyên bản trên máy.</summary>
    private async Task DongBoAsync()
    {
        if (!DuLieuService.DangOnline) return;
        var tatCaLen = true;
        foreach (var d in _ds.Where(x => x.MaDiaChi is null).ToList())
        {
            var r = await ApiClient.PostAsync<DiaChiMayChuDto>("api/customer/addresses", new { nhan = d.Nhan, diaChi = d.DiaChi, macDinh = d.MacDinh });
            if (r.ThanhCong && r.DuLieu is not null) d.MaDiaChi = r.DuLieu.MaDiaChi; else { tatCaLen = false; break; }
        }
        if (!tatCaLen) { TaiKhoanService.LuuDiaChi(_ds); return; }      // chưa gửi hết: không ghi đè bản trên máy bằng danh sách máy chủ

        var ds = await ApiClient.GetAsync<List<DiaChiMayChuDto>>("api/customer/addresses");
        if (!ds.ThanhCong || ds.DuLieu is null) return;
        _ds = ds.DuLieu.Select(x => new DiaChiLuu { MaDiaChi = x.MaDiaChi, Nhan = x.Nhan, DiaChi = x.DiaChi, MacDinh = x.MacDinh }).ToList();
        TaiKhoanService.LuuDiaChi(_ds);
        Ve();
    }

    /// <summary>Gọi máy chủ; lỗi thì báo người dùng và trả false (khi đó KHÔNG đổi dữ liệu trên máy).</summary>
    private async Task<bool> MayChuNhanAsync(Task<ApiKetQua<object>> goi)
    {
        var kq = await goi;
        if (!kq.ThanhCong) await DisplayAlert("Không lưu được", string.IsNullOrWhiteSpace(kq.ThongDiep) ? "Không kết nối được máy chủ. Vui lòng thử lại." : kq.ThongDiep, "OK");
        return kq.ThanhCong;
    }

    private Color Mau(string k) => (Color)Resources[k];

    private void Ve()
    {
        DanhSach.Children.Clear();
        if (_ds.Count == 0)
            DanhSach.Children.Add(new Label { Text = "Chưa có địa chỉ nào. Bấm “Thêm địa chỉ mới”.", Style = (Style)Resources["SubtitleLabel"], HorizontalOptions = LayoutOptions.Center, Margin = new Thickness(0, 40) });

        foreach (var d in _ds)
        {
            var thong = new VerticalStackLayout { Spacing = 3 };
            var dong = new HorizontalStackLayout { Spacing = 8 };
            dong.Children.Add(new Label { Text = (d.Nhan == "Công ty" ? "🏢 " : d.Nhan == "Nhà" ? "🏠 " : "📍 ") + d.Nhan, FontAttributes = FontAttributes.Bold, FontSize = 14 });
            if (d.MacDinh)
                dong.Children.Add(new Frame { BackgroundColor = Mau("PrimarySoft"), BorderColor = Colors.Transparent, CornerRadius = 8, Padding = new Thickness(8, 1), HasShadow = false,
                    Content = new Label { Text = "Mặc định", FontSize = 11, FontAttributes = FontAttributes.Bold, TextColor = Mau("Primary") } });
            thong.Children.Add(dong);
            thong.Children.Add(new Label { Text = d.DiaChi, FontSize = 12.5, TextColor = Mau("TextGrey") });

            var the = new Frame { Style = (Style)Resources["CardFrame"], Content = thong };
            if (d.MacDinh) the.BorderColor = Mau("Primary");
            var item = d;
            the.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => await HanhDongAsync(item)) });
            DanhSach.Children.Add(the);
        }
    }

    private async Task HanhDongAsync(DiaChiLuu d)
    {
        var chon = await DisplayActionSheet(d.Nhan, "Đóng", null, d.MacDinh ? null : "Đặt làm mặc định", "Sửa", "Xóa");
        var online = DuLieuService.DangOnline;
        if (online && d.MaDiaChi is null && chon is "Đặt làm mặc định" or "Sửa" or "Xóa")
        {
            await DisplayAlert("Chưa đồng bộ", "Địa chỉ này chưa được gửi lên máy chủ. Hãy thử lại sau khi mạng ổn định.", "OK");
            return;
        }
        switch (chon)
        {
            case "Đặt làm mặc định":
                if (online && !await MayChuNhanAsync(ApiClient.PostAsync<object>($"api/customer/addresses/{d.MaDiaChi}/default", null))) return;
                foreach (var x in _ds) x.MacDinh = x == d;
                break;
            case "Sửa":
                var moi = await this.NhapAsync("Sửa địa chỉ", d.Nhan, "Lưu", "Hủy", initialValue: d.DiaChi);
                if (string.IsNullOrWhiteSpace(moi)) return;
                if (online && !await MayChuNhanAsync(ApiClient.PutAsync<object>($"api/customer/addresses/{d.MaDiaChi}", new { nhan = d.Nhan, diaChi = moi.Trim(), macDinh = d.MacDinh }))) return;
                d.DiaChi = moi.Trim();
                break;
            case "Xóa":
                if (!await DisplayAlert("Xóa địa chỉ", $"Xóa “{d.Nhan}”?", "Xóa", "Hủy")) return;
                if (online && !await MayChuNhanAsync(ApiClient.DeleteAsync<object>($"api/customer/addresses/{d.MaDiaChi}"))) return;
                var macDinh = d.MacDinh;
                _ds.Remove(d);
                if (macDinh && _ds.Count > 0) _ds[0].MacDinh = true;
                break;
            default: return;
        }
        TaiKhoanService.LuuDiaChi(_ds);
        Ve();
    }

    private async void OnThemClicked(object? sender, EventArgs e)
    {
        var nhan = await DisplayActionSheet("Loại địa chỉ", "Hủy", null, "Nhà", "Công ty", "Khác");
        if (nhan is null or "Hủy") return;
        var cach = await DisplayActionSheet("Cách nhập địa chỉ", "Hủy", null, "📍 Chọn trên bản đồ / lấy vị trí hiện tại", "⌨ Nhập tay");
        if (cach is null or "Hủy") return;
        if (cach.StartsWith("📍"))
        {
            // Bản đồ trả địa chỉ qua callback (người dùng thoát không chọn thì không thêm gì)
            await BanDoPage.MoAsync("", chonDiaChi: true, khiChon: async d => await ThemAsync(nhan, d));
            return;
        }
        var dc = await this.NhapAsync("Địa chỉ mới", "Số nhà, đường, phường/quận, thành phố:", "Thêm", "Hủy");
        await ThemAsync(nhan, dc);
    }

    private async Task ThemAsync(string nhan, string? dc)
    {
        if (string.IsNullOrWhiteSpace(dc)) return;

        var moi = new DiaChiLuu { Nhan = nhan, DiaChi = dc.Trim(), MacDinh = _ds.Count == 0 };
        if (DuLieuService.DangOnline)
        {
            // Máy chủ nhận trước (giới hạn 10 địa chỉ/tài khoản); chỉ khi thành công mới thêm vào sổ trên máy
            var r = await ApiClient.PostAsync<DiaChiMayChuDto>("api/customer/addresses", new { nhan = moi.Nhan, diaChi = moi.DiaChi, macDinh = moi.MacDinh });
            if (!r.ThanhCong || r.DuLieu is null)
            { await DisplayAlert("Không lưu được", string.IsNullOrWhiteSpace(r.ThongDiep) ? "Không kết nối được máy chủ. Vui lòng thử lại." : r.ThongDiep, "OK"); return; }
            moi.MaDiaChi = r.DuLieu.MaDiaChi; moi.MacDinh = r.DuLieu.MacDinh;
            if (moi.MacDinh) foreach (var x in _ds) x.MacDinh = false;
        }
        _ds.Add(moi);
        TaiKhoanService.LuuDiaChi(_ds);
        Ve();
    }
}

public sealed class DiaChiMayChuDto
{
    public int MaDiaChi { get; set; }
    public string Nhan { get; set; } = "";
    public string DiaChi { get; set; } = "";
    public bool MacDinh { get; set; }
}
