using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Tab "Cá nhân" của quản trị viên: thông tin tài khoản, đổi mật khẩu, chế độ tối, đăng xuất.</summary>
public sealed class AdminProfilePage : ContentPage
{
    public AdminProfilePage()
    {
        Title = "Cá nhân";
        Shell.SetNavBarIsVisible(this, false);
        AdminUi.NenTrang(this);

        var admin = MockData.QuanTriVienHienTai;
        var ten = admin?.HoTen ?? "Quản trị viên";

        var avatar = new Border
        {
            WidthRequest = 72, HeightRequest = 72, StrokeThickness = 0, HorizontalOptions = LayoutOptions.Center,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(36) },
            Background = new LinearGradientBrush(
                new GradientStopCollection { new GradientStop(Color.FromArgb("#5B21B6"), 0f), new GradientStop(Color.FromArgb("#8B5CF6"), 1f) },
                new Point(0, 0), new Point(1, 1)),
            Content = new Label { Text = ChuCai(ten), TextColor = Colors.White, FontSize = 26, FontAttributes = FontAttributes.Bold, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center },
        };
        var vaiTro = AdminUi.Chip(admin is null ? "Quản trị" : admin.VaiTro.Nhan(), AdminUi.Tim);
        vaiTro.HorizontalOptions = LayoutOptions.Center;
        var tenLb = AdminUi.Nhan(ten, 18, dam: true); tenLb.HorizontalTextAlignment = TextAlignment.Center;
        var mailLb = AdminUi.Nhan(admin?.Email ?? "", 12.5, mo: true); mailLb.HorizontalTextAlignment = TextAlignment.Center;

        var the = AdminUi.The(18);
        the.Content = new VerticalStackLayout { Spacing = 6, Children = { avatar, tenLb, mailLb, vaiTro } };

        var dsDong = AdminUi.The(4);
        var dong = new VerticalStackLayout { Spacing = 0 };
        dong.Add(Dong("🔑", "Đổi mật khẩu", async () => await Shell.Current.GoToAsync($"{nameof(DoiMatKhauPage)}?VaiTro=QuanTri")));
        dong.Add(DuongKe());
        dong.Add(Dong("🕘", "Lịch sử đăng nhập", async () => await Shell.Current.GoToAsync(nameof(LichSuDangNhapPage))));
        dong.Add(DuongKe());
        dong.Add(DongCongTac("🌙", "Chế độ tối"));
        dsDong.Content = dong;

        var dangXuat = new Button
        {
            Text = "↪   Đăng xuất", BackgroundColor = Colors.Transparent, TextColor = Color.FromArgb(AdminUi.Tim),
            BorderColor = Color.FromArgb(AdminUi.Tim), BorderWidth = 1.2, CornerRadius = 14, HeightRequest = 50, FontAttributes = FontAttributes.Bold,
        };
        dangXuat.Clicked += OnDangXuat;

        var nd = new VerticalStackLayout { Spacing = 14, Padding = new Thickness(16, 16, 16, 24), Children = { the, dsDong, dangXuat } };
        Content = AdminUi.KhungTrang("canhan", AdminUi.ThanhTieuDe("Cá nhân", "Tài khoản quản trị"), new ScrollView { Content = nd });
    }

    private static string ChuCai(string ten)
    {
        var p = (ten ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (p.Length == 0) return "AD";
        return p.Length == 1 ? p[0][..1].ToUpper() : (p[0][..1] + p[^1][..1]).ToUpper();
    }

    private static View DuongKe()
    {
        var b = new BoxView { HeightRequest = 1, Margin = new Thickness(52, 0, 0, 0) };
        b.SetAppThemeColor(BoxView.ColorProperty, Color.FromArgb("#EFE9FB"), Color.FromArgb("#4D4180"));
        return b;
    }

    private static Border Icon(string icon) => new()
    {
        WidthRequest = 36, HeightRequest = 36, StrokeThickness = 0, BackgroundColor = Color.FromArgb("#EDE9FE"), VerticalOptions = LayoutOptions.Center,
        StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(10) },
        Content = new Label { Text = icon, FontSize = 17, TextColor = Colors.Black, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center },
    };

    private static View Dong(string icon, string nhan, Func<Task> chay)
    {
        var g = new Grid { Padding = new Thickness(10, 10), ColumnSpacing = 12, ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        g.Add(Icon(icon), 0, 0);
        var l = AdminUi.Nhan(nhan, 14); l.VerticalOptions = LayoutOptions.Center;
        g.Add(l, 1, 0);
        g.Add(new Label { Text = "›", FontSize = 20, TextColor = Color.FromArgb(AdminUi.Tim), VerticalOptions = LayoutOptions.Center }, 2, 0);
        g.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => { try { await chay(); } catch (Exception ex) { CrashLog.Ghi("AdminProfile", ex); } }) });
        return g;
    }

    private static View DongCongTac(string icon, string nhan)
    {
        var g = new Grid { Padding = new Thickness(10, 6), ColumnSpacing = 12, ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        g.Add(Icon(icon), 0, 0);
        var l = AdminUi.Nhan(nhan, 14); l.VerticalOptions = LayoutOptions.Center;
        g.Add(l, 1, 0);
        var sw = new Switch { IsToggled = ThemeService.Hien == "dark", OnColor = Color.FromArgb("#A78BFA"), ThumbColor = Color.FromArgb(AdminUi.Tim), VerticalOptions = LayoutOptions.Center };
        sw.Toggled += (_, e) => ThemeService.Dat(e.Value ? "dark" : "light");
        g.Add(sw, 2, 0);
        return g;
    }

    private async void OnDangXuat(object? sender, EventArgs e)
    {
        try
        {
            bool xacNhan = await DisplayAlert("Đăng xuất", "Bạn có chắc muốn đăng xuất khỏi cổng quản trị?", "Đăng xuất", "Hủy");
            if (!xacNhan) return;
            NhatKyService.GhiQuanTri("Đăng xuất", chiTiet: NhatKyService.ThietBi());
            Services.Phien.DangXuat();
            await Shell.Current.GoToAsync("//dang-nhap");
        }
        catch (Exception ex) { await Services.DangXuatHelper.LoiAsync(ex); }
    }
}
