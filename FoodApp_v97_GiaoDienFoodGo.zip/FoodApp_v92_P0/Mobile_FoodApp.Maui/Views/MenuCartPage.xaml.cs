using FoodApp.Maui.Services;
using FoodApp.Maui.Models;
using System.Collections.ObjectModel;

namespace FoodApp.Maui.Views;

[QueryProperty(nameof(GianHang), "GianHang")]
public partial class MenuCartPage : ContentPage
{
    // Giỏ dùng chung toàn app (lưu theo tài khoản, đồng bộ server) — xem GioHangService
    private static ObservableCollection<MucGioHang> _gioHang => GioHangService.Gio;

    public GianHang GianHang { get; set; } = null!;

    public MenuCartPage()
    {
        InitializeComponent();
    }

    private ThongTinQuan? _tt;
    private string _danhMucChon = "";

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (GianHang is null) return;
        _tt = ThongTinQuan.Tao(GianHang);
        VeThongTin(_tt);
        LocMon();
        CapNhatThanhGioHang();
        // Khôi phục giỏ đã lưu (server / máy) — vd mở lại app, đổi máy
        await GioHangService.TaiAsync();
        CapNhatThanhGioHang();
        _ = LamMoiChinhSachAsync();
        _ = Services.TaiKhoanService.DongBoYeuThichAsync();   // v64: gửi các lượt thả tim còn chờ khi có mạng
        RealtimeService.CoThayDoi -= OnRealtimeThucDon;
        RealtimeService.CoThayDoi += OnRealtimeThucDon;
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        RealtimeService.CoThayDoi -= OnRealtimeThucDon;
    }

    private bool _dangLamMoiThucDon;

    /// <summary>v95: quán vừa đổi giá / tình trạng món / trạng thái nhận đơn → tải lại từ máy chủ rồi vẽ lại.
    /// Giá hiển thị chỉ để tham khảo; khi đặt, máy chủ luôn tính lại giá từ SQL (xem GioHangService.KiemTraAsync + PlaceOrder).</summary>
    private async void OnRealtimeThucDon(RealtimeSuKien e)
    {
        if (e.Loai is not ("MenuChanged" or "StoreChanged")) return;
        if (GianHang is null || (e.MaGianHang is { Length: > 0 } && e.MaGianHang != GianHang.Id)) return;
        if (_dangLamMoiThucDon || !DuLieuService.DangOnline) return;
        _dangLamMoiThucDon = true;
        try
        {
            if (!await DuLieuService.LamMoiMonAnAsync()) return;
            _tt = ThongTinQuan.Tao(GianHang);
            VeThongTin(_tt);
            LocMon();
            if (GioHangService.Gio.Count > 0 && GioHangService.GianHangId == GianHang.Id)
            {
                var kq = await GioHangService.KiemTraAsync();
                if (kq.CoVanDe) await DisplayAlert("Quán vừa cập nhật thực đơn", "Giá hoặc tình trạng một số món trong giỏ đã thay đổi. Giá cuối cùng do hệ thống xác nhận khi bạn đặt hàng.", "OK");
            }
            CapNhatThanhGioHang();
        }
        catch (Exception ex) { CrashLog.Ghi("MenuCartPage.Realtime", ex); }
        finally { _dangLamMoiThucDon = false; }
    }

    private Color Mau(string khoa) => (Color)Resources[khoa];

    /// <summary>Tên, logo, mô tả, địa chỉ, SĐT, giờ kinh doanh, trạng thái, đánh giá, phí giao, thời gian, khuyến mãi, bán chạy, nổi bật, đánh giá khách.</summary>
    private void VeThongTin(ThongTinQuan tt)
    {
        var g = tt.Gh;
        LblIconGianHang.Text = g.HinhAnh;
        ImgAnhGianHang.Source = g.CoAnh ? ImageSource.FromFile(g.AnhHienThi) : null;
        ImgAnhGianHang.IsVisible = g.CoAnh;
        LblIconGianHang.IsVisible = !g.CoAnh;
        LblTenGianHang.Text = g.TenGianHang;
        LblYeuThich.Text = Services.TaiKhoanService.LaYeuThich(g.Id) ? "♥" : "♡";
        LblThongTinGianHang.Text = tt.SoDanhGia > 0 ? $"⭐ {tt.Sao:0.0} ({tt.SoDanhGia} đánh giá)   {tt.ThoiGianText}" : $"⭐ Mới   {tt.ThoiGianText}";

        // trạng thái mở / đóng
        if (tt.CoTheDat) { KhungTrangThai.BackgroundColor = Color.FromArgb("#16A34A"); LblTrangThai.Text = "🟢 Đang mở cửa — nhận đơn"; }
        else if (tt.DangMo) { KhungTrangThai.BackgroundColor = Color.FromArgb("#D97706"); LblTrangThai.Text = "🟡 " + tt.LyDoKhongDat; }
        else { KhungTrangThai.BackgroundColor = Color.FromArgb("#DC2626"); LblTrangThai.Text = "🔴 Đóng cửa — " + tt.LyDoKhongDat; }

        LblMoTa.Text = g.MoTa;
        LblMoTa.IsVisible = !string.IsNullOrWhiteSpace(g.MoTa);
        LblDiaChi.Text = "📍 " + g.DiaChi;
        LblSdt.Text = string.IsNullOrWhiteSpace(g.SoDienThoai) ? "☎ Quán chưa cung cấp số điện thoại" : "☎ " + g.SoDienThoai + "  (chạm để gọi)";
        LblGio.Text = "🕒 Giờ kinh doanh: " + tt.GioKinhDoanh;
        LblDiem.Text = tt.SoDanhGia > 0 ? $"⭐ Đánh giá trung bình {tt.Sao:0.0}/5 · {tt.SoDanhGia} lượt đánh giá" : "⭐ Chưa có lượt đánh giá";
        LblPhiGiao.Text = "🛵 Phí giao hàng: " + tt.PhiGiaoText;
        LblThoiGian.Text = "⏱ Thời gian dự kiến: " + tt.ThoiGianText;
        LblChuanBi.Text = "👨‍🍳 Thời gian chuẩn bị: " + tt.ThoiGianChuanBiText;
        LblPhamVi.Text = "🧭 Phạm vi giao hàng: " + tt.PhamViGiaoText;
        LblLuotBan.Text = tt.LuotBanText;
        LblDonToiThieu.Text = tt.DonToiThieuText;
        LblChinhSach.Text = tt.ChinhSachText;
        DsAnhKhongGian.ItemsSource = tt.AnhKhongGian;
        DsAnhKhongGian.IsVisible = tt.AnhKhongGian.Count > 0;
        DsMonMoi.ItemsSource = tt.MonMoi;
        KhungMonMoi.IsVisible = tt.MonMoi.Count > 0;

        // khuyến mãi
        DsKhuyenMai.Children.Clear();
        foreach (var k in tt.DsKhuyenMai)
        {
            var cot = new VerticalStackLayout { Spacing = 1 };
            cot.Children.Add(new Label { Text = $"{k.GiaTriGiamHienThi} · mã {k.MaCode}", FontAttributes = FontAttributes.Bold, FontSize = 13, TextColor = Color.FromArgb("#B45309") });
            cot.Children.Add(new Label { Text = $"{k.TenChuongTrinh} ({k.PhamViHienThi})", FontSize = 12 });
            cot.Children.Add(new Label { Text = $"Đơn tối thiểu {k.GiaTriDonToiThieu:N0}đ · HSD {k.NgayKetThuc:dd/MM/yyyy}", FontSize = 11.5, TextColor = Mau("TextGrey") });
            var khung = new Frame { Content = cot, Padding = new Thickness(12, 8), CornerRadius = 10, HasShadow = false, BackgroundColor = Color.FromArgb("#FEF3C7"), BorderColor = Colors.Transparent };
            var ma = k.MaCode;
            khung.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(async () =>
                {
                    bool daSao = await FoodApp.Maui.Services.ClipboardAnToan.SaoChepAsync(ma);
                    await DisplayAlert(daSao ? "Đã sao chép mã " + ma : "Mã " + ma, daSao ? "Dán mã vào ô khuyến mãi khi thanh toán." : "Không sao chép tự động được. Hãy nhập mã này thủ công khi thanh toán.", "OK");
                })
            });
            DsKhuyenMai.Children.Add(khung);
        }
        KhungKhuyenMai.IsVisible = tt.DsKhuyenMai.Count > 0;

        DsBanChay.ItemsSource = tt.BanChay; KhungBanChay.IsVisible = tt.BanChay.Count > 0;
        DsNoiBat.ItemsSource = tt.NoiBat; KhungNoiBat.IsVisible = tt.NoiBat.Count > 0;

        // danh mục thực đơn
        var dm = new List<string> { "Tất cả" };
        dm.AddRange(tt.TatCaMon.Select(m => m.DanhMuc).Where(x => !string.IsNullOrWhiteSpace(x)).Distinct());
        DsDanhMucMon.ItemsSource = dm;
        DsDanhMucMon.IsVisible = dm.Count > 2;

        // đánh giá của khách + phản hồi của quán
        DsDanhGia.Children.Clear();
        LblTieuDeDanhGia.Text = tt.SoDanhGia > 0 ? $"💬 Đánh giá của khách ({tt.SoDanhGia})" : "💬 Đánh giá của khách";
        if (tt.DanhGia.Count == 0)
            DsDanhGia.Children.Add(new Label { Text = "Chưa có đánh giá nào cho quán này.", FontSize = 13, TextColor = Mau("TextGrey") });
        foreach (var d in tt.DanhGia)
        {
            var cot = new VerticalStackLayout { Spacing = 2 };
            cot.Children.Add(new Label { Text = $"{d.SaoText}  ·  {d.KhachTen}", FontAttributes = FontAttributes.Bold, FontSize = 13 });
            if (d.CoThe) cot.Children.Add(new Label { Text = d.TheText, FontSize = 12, TextColor = Mau("Primary") });
            if (d.CoNoiDung) cot.Children.Add(new Label { Text = d.NoiDung, FontSize = 13 });
            if (d.SoSaoGiaoHang > 0) cot.Children.Add(new Label { Text = d.SaoGiaoHangText, FontSize = 11.5, TextColor = Mau("TextGrey") });
            if (d.CoPhanHoi) cot.Children.Add(new Label { Text = d.PhanHoiText, FontSize = 12.5, TextColor = Mau("Primary") });
            cot.Children.Add(new Label { Text = d.NgayText, FontSize = 11, TextColor = Mau("TextGrey") });
            DsDanhGia.Children.Add(new Frame { Content = cot, Padding = new Thickness(14, 10), CornerRadius = 12, HasShadow = false, BorderColor = Mau("PrimarySoft") });
        }
    }

    private void LocMon()
    {
        if (_tt is null) return;
        var ds = _tt.TatCaMon.Where(m => _danhMucChon.Length == 0 || m.DanhMuc == _danhMucChon).ToList();
        DsMonAn.ItemsSource = ds;
        LblKhongCoMon.IsVisible = _tt.TatCaMon.Count == 0;
    }

    private void OnDanhMucMonClicked(object? sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: string ten }) return;
        _danhMucChon = ten == "Tất cả" ? "" : ten;
        LocMon();
    }

    /// <summary>v90: tải chính sách chung (bán kính giao, quy định hủy/hoàn tiền) rồi vẽ lại phần thông tin quán.</summary>
    private async Task LamMoiChinhSachAsync()
    {
        try
        {
            await ChinhSachService.LamMoiAsync();
            if (GianHang is null) return;
            _tt = ThongTinQuan.Tao(GianHang);
            LblPhamVi.Text = "🧭 Phạm vi giao hàng: " + _tt.PhamViGiaoText;
            LblChinhSach.Text = _tt.ChinhSachText;
        }
        catch (Exception ex) { CrashLog.Ghi("MenuCart.ChinhSach", ex); }
    }

    /// <summary>v90: mở bản đồ tại địa chỉ quán (xem vị trí, chỉ đường).</summary>
    private async void OnXemBanDoTapped(object? sender, TappedEventArgs e)
    {
        if (GianHang is null || string.IsNullOrWhiteSpace(GianHang.DiaChi)) { await DisplayAlert("Chưa có địa chỉ", "Quán chưa cung cấp địa chỉ để hiển thị trên bản đồ.", "OK"); return; }
        try { await BanDoPage.MoAsync(GianHang.DiaChi); }
        catch (Exception ex)
        {
            CrashLog.Ghi("MenuCart.BanDo", ex);
            await FoodApp.Maui.Services.ClipboardAnToan.SaoChepAsync(GianHang.DiaChi);
            await DisplayAlert("Không mở được bản đồ", "Đã sao chép địa chỉ quán. Hãy kiểm tra kết nối Internet.", "OK");
        }
    }

    private async void OnGoiQuanTapped(object? sender, TappedEventArgs e) => await Services.LienLac.GoiAsync(GianHang?.SoDienThoai);

    private async void OnMonNgangTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is not MonAn mon) return;
        await MoChiTietMonAsync(mon);
    }

    private async Task MoChiTietMonAsync(MonAn mon) =>
        await Shell.Current.GoToAsync(nameof(MonAnChiTietPage), new Dictionary<string, object> { { "Mon", mon }, { "GianHang", GianHang } });

    private async void OnMonDocTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is MonAn mon) await MoChiTietMonAsync(mon);
    }

    private async void OnYeuThichTapped(object? sender, TappedEventArgs e)
    {
        var gio = Services.TaiKhoanService.DaoYeuThich(GianHang.Id);
        LblYeuThich.Text = gio ? "♥" : "♡";
        await DisplayAlert(gio ? "Đã lưu" : "Đã bỏ", gio ? $"Đã thêm {GianHang.TenGianHang} vào quán yêu thích." : $"Đã bỏ {GianHang.TenGianHang} khỏi quán yêu thích.", "OK");
    }

    private void OnThemMonClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: MonAn mon }) return;
        ThemMon(mon);
    }

    /// <summary>v80: thả/bỏ tim món ăn yêu thích ngay ở thực đơn (đồng bộ máy chủ qua TaiKhoanService).</summary>
    private void OnTimMonTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is not MonAn mon) return;
        Services.TaiKhoanService.DaoYeuThichMon(mon.Id);
        LocMon();      // vẽ lại để đổi ♡/♥
    }

    private async void ThemMon(MonAn mon)
    {
        // v80: món có size / topping / mức cay phải chọn ở trang chi tiết (size bắt buộc) — không thêm thẳng vào giỏ
        if (mon.TuyChon.Count > 0) { await MoChiTietMonAsync(mon); return; }

        if (_tt is { CoTheDat: false })
        {
            await DisplayAlert("Chưa đặt được món", _tt.LyDoKhongDat, "Đóng");
            return;
        }

        // Một giỏ chỉ gồm món của một quán: đang có món quán khác thì hỏi trước khi thay
        if (GioHangService.CoMonQuanKhac(mon.GianHangId))
        {
            var quanCu = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == GioHangService.GianHangId)?.TenGianHang ?? "quán khác";
            var thay = await DisplayAlert("Giỏ hàng của quán khác",
                $"Giỏ hàng đang có {_gioHang.Sum(x => x.SoLuong)} món của {quanCu}. Xóa giỏ cũ và thêm món của {GianHang.TenGianHang}?",
                "Xóa giỏ cũ", "Giữ giỏ cũ");
            if (!thay) return;
        }

        GioHangService.Them(mon);
        CapNhatThanhGioHang();
        await GioHangService.LuuAsync();
    }

    private void CapNhatThanhGioHang()
    {
        if (_gioHang.Count == 0)
        {
            BtnXemGioHang.IsVisible = false;
            return;
        }

        var tongSoLuong = _gioHang.Sum(x => x.SoLuong);
        var tongTien = _gioHang.Sum(x => x.ThanhTien);
        var quanKhac = GianHang is not null && GioHangService.CoMonQuanKhac(GianHang.Id);
        BtnXemGioHang.Text = quanKhac
            ? $"🛒 Giỏ {tongSoLuong} món của quán khác   •   Xem   •   {tongTien:N0}đ"
            : $"{tongSoLuong} món   •   Xem giỏ hàng   •   {tongTien:N0}đ";
        BtnXemGioHang.IsVisible = true;
    }

    private async void OnXemGioHangClicked(object sender, EventArgs e)
    {
        var ghGio = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == GioHangService.GianHangId) ?? GianHang;
        await Shell.Current.GoToAsync(nameof(PaymentPage), new Dictionary<string, object>
        {
            { "GioHang", _gioHang },                 // cùng đối tượng giỏ dùng chung: sửa ở trang thanh toán được lưu lại
            { "TenGianHang", ghGio.TenGianHang },
            { "GianHangId", ghGio.Id },
        });
    }
}
