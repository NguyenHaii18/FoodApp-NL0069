using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Xem đánh giá của khách và phản hồi công khai (NV theo mục đánh giá: gian hàng có quyền phản hồi).</summary>
public partial class VendorReviewsPage : ContentPage
{
    // Loc: 0 = tất cả, 1..5 = đúng số sao, -1 = chưa phản hồi
    private readonly (string Nhan, int Loc)[] _boLoc =
    {
        ("Tất cả", 0), ("Chưa phản hồi", -1), ("5★", 5), ("4★", 4), ("3★", 3), ("2★", 2), ("1★", 1),
    };
    private int _dangLoc;
    private readonly List<Button> _nut = new();
    private List<DanhGiaGianHang>? _tuMayChu;       // đánh giá lấy từ máy chủ (null = dùng bản trên máy)

    public VendorReviewsPage()
    {
        InitializeComponent();
        foreach (var (nhan, loc) in _boLoc)
        {
            var nut = new Button { Text = nhan, CornerRadius = 16, HeightRequest = 34, Padding = new Thickness(14, 0), FontSize = 12, BorderWidth = 1 };
            nut.Clicked += (_, _) => { _dangLoc = loc; Nap(); };
            _nut.Add(nut);
            KhungBoLoc.Children.Add(nut);
        }
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        Nap();
        await TaiTuMayChuAsync();
    }

    private async Task TaiTuMayChuAsync()
    {
        _tuMayChu = await DoiTacService.DanhGiaTuMayChuAsync(MockData.GianHangHienTai.Id);
        if (_tuMayChu is not null) Nap();
    }

    private static Color Mau(string key) => VendorPalette.Get(key);

    private void Nap()
    {
        var tatCa = _tuMayChu ?? DoiTacService.DanhGiaCua(MockData.GianHangHienTai.Id);

        if (tatCa.Count == 0)
        {
            LblDiemTrungBinh.Text = "—";
            LblSaoTrungBinh.Text = "☆☆☆☆☆";
            LblTomTat.Text = "Chưa có đánh giá";
        }
        else
        {
            var tb = tatCa.Average(d => d.SoSaoMonAn);
            var lam = (int)Math.Round(tb);
            LblDiemTrungBinh.Text = tb.ToString("0.0");
            LblSaoTrungBinh.Text = new string('★', lam) + new string('☆', 5 - lam);
            var giao = tatCa.Where(d => d.SoSaoGiaoHang > 0).ToList();
            LblTomTat.Text = $"{tatCa.Count} đánh giá · {tatCa.Count(d => !d.CoPhanHoi)} chưa phản hồi" +
                             (giao.Count > 0 ? $" · giao hàng {giao.Average(d => d.SoSaoGiaoHang):0.0}★" : "");
        }

        for (var i = 0; i < _boLoc.Length; i++)
        {
            var chon = _boLoc[i].Loc == _dangLoc;
            _nut[i].BackgroundColor = chon ? Mau("Primary") : Colors.White;
            _nut[i].TextColor = chon ? Colors.White : Mau("TextGrey");
            _nut[i].BorderColor = Mau("BorderColor");
        }

        var ds = tatCa.Where(d => _dangLoc switch
        {
            0 => true,
            -1 => !d.CoPhanHoi,
            _ => d.SoSaoMonAn == _dangLoc
        }).ToList();

        DsDanhGia.ItemsSource = ds;
        LblRong.IsVisible = ds.Count == 0;
        LblRong.Text = tatCa.Count == 0 ? "Chưa có đánh giá nào." : "Không có đánh giá phù hợp bộ lọc.";
    }

    private async void OnChiTietDanhGiaTapped(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is DanhGiaGianHang dg)
            await Shell.Current.GoToAsync(nameof(VendorReviewDetailPage), new Dictionary<string, object> { { "DanhGia", dg } });
    }

    private async void OnPhanHoiClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: DanhGiaGianHang dg }) return;

        var noiDung = await this.NhapAsync("Phản hồi đánh giá",
            $"Phản hồi sẽ hiển thị công khai cho {dg.KhachTen}.", "Gửi", "Hủy",
            placeholder: "Cảm ơn bạn đã ủng hộ quán!", maxLength: 300, initialValue: dg.PhanHoi);
        if (noiDung is null) return;   // bấm Hủy

        if (dg.TuMayChu)
        {
            if (string.IsNullOrWhiteSpace(noiDung)) { await DisplayAlert("Chưa gửi được", "Nội dung phản hồi không được để trống.", "OK"); return; }
            var loi = await DoiTacService.PhanHoiMayChuAsync(dg, noiDung.Trim());
            if (loi != null) { await DisplayAlert("Chưa gửi được phản hồi", loi, "OK"); return; }
        }
        dg.PhanHoi = noiDung.Trim();   // để trống = xóa phản hồi
        dg.PhanHoiLuc = dg.CoPhanHoi ? DateTime.Now : null;
        if (!dg.TuMayChu) VendorLocalStore.Luu();
        Nap();
    }

    private async void OnRefreshing(object? sender, EventArgs e)
    {
        await TaiTuMayChuAsync();
        Nap();
        RefreshDs.IsRefreshing = false;
    }
}
