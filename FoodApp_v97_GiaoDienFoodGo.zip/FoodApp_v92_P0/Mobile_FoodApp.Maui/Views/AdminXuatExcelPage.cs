using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>v81 — "Báo cáo &amp; xuất Excel": một trang gom 3 loại xuất file .xlsx cho quản trị:
/// doanh thu (chọn khoảng thời gian), tài khoản khách hàng, tài khoản quán. Chạy được cả khi ngoại tuyến.</summary>
public sealed class AdminXuatExcelPage : AdminKyThuatTrang
{
    private static readonly (string Nhan, int? Ngay)[] Khoang =
    {
        ("Hôm nay", 1), ("7 ngày", 7), ("30 ngày", 30), ("Tất cả", null),
    };
    private int _khoang = 1;   // mặc định 7 ngày

    public AdminXuatExcelPage() : base("Báo cáo & xuất Excel") { }

    protected override Task DungAsync()
    {
        Nd.Add(AdminUi.Nhan("Chọn loại báo cáo rồi bấm Xuất. File .xlsx mở bằng Excel / Google Sheets; mật khẩu và giấy tờ cá nhân không bao giờ được xuất.", 12, mo: true));
        Nd.Add(TheDoanhThu());
        Nd.Add(TheTaiKhoan("👥", "Tài khoản khách hàng",
            $"{MockData.DanhSachKhachHang.Count} tài khoản · họ tên, email, SĐT, địa chỉ, trạng thái, số đơn, tổng chi tiêu",
            "Xuất danh sách khách hàng", () => BaoCaoXuatService.XuatKhachHangAsync(this)));
        Nd.Add(TheTaiKhoan("🏬", "Tài khoản quán",
            $"{MockData.DanhSachGianHang.Count} quán · thông tin liên hệ, trạng thái hồ sơ, giờ mở cửa, số đơn, doanh thu",
            "Xuất danh sách quán", () => BaoCaoXuatService.XuatGianHangAsync(this)));
        return Task.CompletedTask;
    }

    private View TheDoanhThu()
    {
        var chip = new HorizontalStackLayout { Spacing = 8 };
        for (var i = 0; i < Khoang.Length; i++)
        {
            var vt = i;
            var nut = AdminUi.NutTab(Khoang[i].Nhan, i == _khoang);
            nut.Clicked += (_, _) => { _khoang = vt; Nd.Children.Clear(); _ = DungAsync(); };
            chip.Add(nut);
        }
        var xuat = AdminUi.Nut("📥 Xuất Excel doanh thu — " + Khoang[_khoang].Nhan, AdminUi.Tim, day: true);
        xuat.HeightRequest = 44;
        xuat.Clicked += async (_, _) => await ChayAsync(xuat, () => BaoCaoXuatService.XuatDoanhThuKhoangAsync(this, Khoang[_khoang].Ngay, Khoang[_khoang].Nhan));
        return KhoiTheo("💰 Doanh thu",
            AdminUi.Nhan("4 sheet: Tổng hợp · Theo ngày · Theo quán · Chi tiết đơn hàng", 11.5, mo: true),
            new ScrollView { Orientation = ScrollOrientation.Horizontal, Content = chip },
            xuat);
    }

    private View TheTaiKhoan(string icon, string tieuDe, string moTa, string nhanNut, Func<Task> xuat)
    {
        var nut = AdminUi.Nut("📥 " + nhanNut, AdminUi.Xanh, day: true);
        nut.HeightRequest = 44;
        nut.Clicked += async (_, _) => await ChayAsync(nut, xuat);
        return KhoiTheo(icon + " " + tieuDe, AdminUi.Nhan(moTa, 11.5, mo: true), nut);
    }

    private static async Task ChayAsync(Button nut, Func<Task> viec)
    {
        var chu = nut.Text;
        nut.IsEnabled = false; nut.Text = "Đang xuất…";
        try { await viec(); }
        catch (Exception ex) { CrashLog.Ghi("AdminXuatExcel", ex); }
        finally { nut.IsEnabled = true; nut.Text = chu; }
    }
}
