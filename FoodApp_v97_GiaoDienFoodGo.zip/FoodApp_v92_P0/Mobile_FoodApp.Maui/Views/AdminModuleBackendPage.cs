namespace FoodApp.Maui.Views;

/// <summary>
/// Phần X — 25 module Backend dùng chung + 17 chức năng hệ thống tự động.
/// Chạm một dòng để đánh dấu đã có / đã kiểm tra. Trạng thái chỉ LƯU TRÊN THIẾT BỊ NÀY (Preferences).
/// </summary>
public sealed class AdminModuleBackendPage : AdminKyThuatTrang
{
    private static readonly (string Ten, string MoTa)[] Modules =
    {
        ("Authentication", "Đăng nhập, đăng ký, OTP, token"),
        ("Authorization", "Phân quyền và kiểm tra quyền"),
        ("User Management", "Quản lý tài khoản"),
        ("Customer Management", "Quản lý khách hàng"),
        ("Restaurant Management", "Quản lý nhà hàng, chi nhánh"),
        ("Product Management", "Quản lý món ăn, giá, topping"),
        ("Cart Management", "Quản lý giỏ hàng"),
        ("Order Management", "Tạo và xử lý đơn hàng"),
        ("Dispatch Management", "Tìm và phân tài xế"),
        ("Driver Management", "Hồ sơ, trạng thái tài xế"),
        ("Tracking Management", "Vị trí và hành trình"),
        ("Pricing Management", "Tính phí và phụ phí"),
        ("Payment Management", "Thanh toán, giao dịch"),
        ("Refund Management", "Hoàn tiền"),
        ("Wallet Management", "Ví và số dư nếu triển khai"),
        ("Promotion Management", "Voucher và khuyến mãi"),
        ("Notification Management", "Push, SMS, email"),
        ("Chat Management", "Trao đổi giữa các đối tượng"),
        ("Review Management", "Đánh giá và phản hồi"),
        ("Complaint Management", "Khiếu nại và xử lý sự cố"),
        ("Settlement Management", "Đối soát nhà hàng, tài xế"),
        ("Report Management", "Thống kê, xuất báo cáo"),
        ("File Management", "Hình ảnh, tài liệu"),
        ("Audit Log", "Nhật ký thao tác"),
        ("Configuration", "Cấu hình hệ thống"),
    };

    private static readonly string[] TuDong =
    {
        "Tự gửi đơn mới cho nhà hàng",
        "Tự gửi thông báo khi nhà hàng xác nhận",
        "Tự tìm tài xế đủ điều kiện",
        "Tự gửi lời mời nhận đơn",
        "Tự chuyển lời mời khi tài xế không phản hồi",
        "Tự thông báo cho khách khi có tài xế",
        "Tự cập nhật trạng thái đơn",
        "Tự cảnh báo đơn có nguy cơ giao trễ",
        "Tự kiểm tra đơn chưa hoàn tất",
        "Tự xử lý lời mời nhận đơn hết hạn",
        "Tự tính tiền giao hàng",
        "Tự tính hoa hồng",
        "Tự tổng hợp báo cáo",
        "Tự tạo thông báo thanh toán",
        "Tự đồng bộ giao dịch và đối soát",
        "Tự sao lưu cơ sở dữ liệu theo lịch",
        "Tự cảnh báo lỗi máy chủ và lỗi dịch vụ",
    };

    /// <summary>Kết quả rà soát backend (chỉ ghi những mục đã xác minh trong mã nguồn Web/; mục không có ghi chú = chưa xác minh).</summary>
    private static readonly Dictionary<int, string> GhiChuTuDong = new()
    {
        [2] = "Backend: bộ máy phân phối đơn chạy nền (PhanPhoiNen) — lọc, xếp hạng, chọn tài xế phù hợp.",
        [3] = "Backend: PhanPhoiNen gửi đề nghị có thời hạn cho tài xế tốt nhất.",
        [4] = "Backend: PhanPhoiNen chuyển cho người kế tiếp, hết ứng viên thì mở rộng bán kính rồi báo quản trị.",
        [9] = "Backend: PhanPhoiNen xử lý đề nghị hết hạn. Riêng quá hạn nhận đơn kiểu cũ chỉ quét khi có yêu cầu API gọi tới, chưa có bộ hẹn giờ.",
        [14] = "Backend: ThanhToanDoiSoatNen hỏi lại VNPay mỗi 5 phút các giao dịch treo.",
        [15] = "Mới có script SQL + hướng dẫn sao lưu; chưa thấy tác vụ tự chạy theo lịch trong ứng dụng — cần lập lịch (SQL Agent / cron).",
    };

    public AdminModuleBackendPage() : base("Module Backend dùng chung") { }

    private static bool Dat(string nhom, int i) { try { return Preferences.Default.Get($"backend-{nhom}-{i}", false); } catch { return false; } }
    private static void Dat(string nhom, int i, bool v) { try { Preferences.Default.Set($"backend-{nhom}-{i}", v); } catch { } }

    protected override Task DungAsync()
    {
        var tong = Modules.Length + TuDong.Length;
        var soDat = Enumerable.Range(0, Modules.Length).Count(i => Dat("m", i)) + Enumerable.Range(0, TuDong.Length).Count(i => Dat("t", i));
        var mau = Color.FromArgb(soDat == tong ? AdminUi.Xanh : AdminUi.Tim);

        var dau = new VerticalStackLayout { Spacing = 4 };
        dau.Add(AdminUi.Nhan("Nền tảng Backend dùng chung", 14, dam: true));
        var pt = AdminUi.Nhan($"{(int)Math.Round(100.0 * soDat / tong)}%", 28, dam: true); pt.TextColor = mau; dau.Add(pt);
        dau.Add(new ProgressBar { Progress = (double)soDat / tong, ProgressColor = mau });
        dau.Add(AdminUi.Nhan($"{soDat}/{tong} hạng mục · tất cả ứng dụng (khách, nhà hàng, tài xế, admin) dùng chung một Backend.", 11.5, mo: true));
        Nd.Add(KhoiTheo("", dau));

        Nd.Add(Nhom("m", $"{Modules.Length} module dùng chung", Modules.Select(m => $"{m.Ten} — {m.MoTa}").ToArray()));
        Nd.Add(Nhom("t", $"{TuDong.Length} chức năng hệ thống tự động", TuDong));
        Nd.Add(KhoiTheo("Kết quả rà soát backend",
            AdminUi.Nhan("✔ Đã thấy trong mã: phân phối đơn (tìm tài xế, mời, chuyển người kế, hết hạn) và đối soát VNPay chạy nền.\n⚠ Sao lưu theo lịch: chưa có tác vụ tự chạy.\n• Các mục còn lại chưa xác minh — cần đối chiếu từng mục.", 12)));
        Nd.Add(KhoiTheo("Yêu cầu bắt buộc cho chức năng tự động",
            AdminUi.Nhan("• Có cơ chế thử lại (retry).\n• Ghi log đầy đủ.\n• Tránh xử lý một sự kiện nhiều lần gây trùng đơn hoặc trùng giao dịch (idempotency).", 12.5)));

        var datLai = AdminUi.Nut("Đặt lại đánh dấu", AdminUi.Xam);
        datLai.Clicked += async (_, _) =>
        {
            if (!await DisplayAlert("Đặt lại?", $"Bỏ đánh dấu toàn bộ {tong} hạng mục trên thiết bị này.", "Đặt lại", "Hủy")) return;
            for (var i = 0; i < Modules.Length; i++) Dat("m", i, false);
            for (var i = 0; i < TuDong.Length; i++) Dat("t", i, false);
            Nd.Children.Clear();
            await DungAsync();
        };
        Nd.Add(KhoiTheo("", datLai));
        return Task.CompletedTask;
    }

    private Border Nhom(string khoa, string tieuDe, string[] muc)
    {
        var datNhom = Enumerable.Range(0, muc.Length).Count(i => Dat(khoa, i));
        var ds = new VerticalStackLayout { Spacing = 2 };
        var td = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        td.Add(AdminUi.Nhan(tieuDe, 15, dam: true), 0, 0);
        td.Add(AdminUi.Nhan($"{datNhom}/{muc.Length}", 13, dam: true), 1, 0);
        ds.Add(td);
        ds.Add(new ProgressBar { Progress = (double)datNhom / muc.Length, ProgressColor = Color.FromArgb(datNhom == muc.Length ? AdminUi.Xanh : AdminUi.Tim) });
        for (var j = 0; j < muc.Length; j++)
        {
            var i = j;
            var xong = Dat(khoa, i);
            var dong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 10, Padding = new Thickness(0, 8) };
            dong.Add(new Label { Text = xong ? "✅" : "⚪", FontSize = 18, VerticalOptions = LayoutOptions.Center }, 0, 0);
            var chu = AdminUi.Nhan(muc[i], 13, mo: xong);
            if (xong) chu.TextDecorations = TextDecorations.Strikethrough;
            var cot = new VerticalStackLayout { Spacing = 2, VerticalOptions = LayoutOptions.Center, Children = { chu } };
            if (khoa == "t" && GhiChuTuDong.TryGetValue(i, out var ghiChu))
                cot.Add(AdminUi.Nhan((i == 15 ? "⚠ " : "✔ ") + ghiChu, 10.5, mo: true));
            dong.Add(cot, 1, 0);
            var tap = new TapGestureRecognizer();
            tap.Tapped += async (_, _) => { Dat(khoa, i, !Dat(khoa, i)); Nd.Children.Clear(); await DungAsync(); };
            dong.GestureRecognizers.Add(tap);
            ds.Add(dong);
        }
        return KhoiTheo("", ds);
    }
}
