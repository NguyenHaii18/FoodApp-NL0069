using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

public partial class VendorHomePage : ContentPage
{
    public VendorHomePage()
    {
        InitializeComponent();
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        NoiSidebar();
        NapHoSo();
        NapThongKeNhanh();
        NapDonMoi();
        _ = LamMoiQuyenAsync();
        VanHanhService.BatDauTheoDoi(() => { NapThongKeNhanh(); NapDonMoi(); });
    }

    protected override void OnDisappearing() { base.OnDisappearing(); VanHanhService.DungTheoDoi(); }

    /// <summary>Nhân viên: hỏi lại quyền (chủ quán có thể vừa đổi) rồi ẩn/hiện mục tương ứng. Chủ quán: thấy đủ.</summary>
    private async Task LamMoiQuyenAsync()
    {
        try { await NhanVienQuan.LamMoiAsync(); } catch (Exception ex) { CrashLog.Ghi("VendorHome.Quyen", ex); }
        var nv = NhanVienQuan.LaNhanVien;
        LblNhanVien.IsVisible = nv;
        LblNhanVien.Text = nv ? $"👤 Nhân viên: {NhanVienQuan.HoTen} · quyền: " + (NhanVienQuan.Quyen.Count == 0 ? "chưa có" : string.Join(", ", NhanVienQuan.Quyen.Select(NhanVienQuan.Nhan))) : "";
        BtnHoSo.IsVisible = !nv;
        TileNhanVien.IsVisible = !nv;
        TileCaiDat.IsVisible = !nv;
        CapNhatSidebar();
        SwitchMoCua.IsEnabled = SwitchNhanDon.IsEnabled = NhanVienQuan.Co(NhanVienQuan.DonHang);
    }

    private async Task<bool> CoQuyenAsync(string quyen)
    {
        if (NhanVienQuan.Co(quyen)) return true;
        await DisplayAlert("Chưa được cấp quyền", $"Tài khoản nhân viên của bạn chưa có quyền \"{NhanVienQuan.Nhan(quyen)}\". Hãy nhờ chủ quán cấp thêm.", "OK");
        return false;
    }

    private async void OnXemVanHanhClicked(object sender, EventArgs e) { if (await CoQuyenAsync(NhanVienQuan.DonHang)) await Shell.Current.GoToAsync(nameof(VendorVanHanhPage)); }
    private async void OnXemDoiSoatClicked(object sender, EventArgs e) { if (await CoQuyenAsync(NhanVienQuan.TaiChinh)) await Shell.Current.GoToAsync(nameof(VendorDoiSoatPage)); }

    private async void OnXemNhanVienTapped(object sender, EventArgs e) { if (!NhanVienQuan.LaNhanVien) await Shell.Current.GoToAsync(nameof(VendorStaffPage)); }

    private void NapHoSo()
    {
        var gh = MockData.GianHangHienTai;
        LblAnhGianHang.Text = gh.HinhAnh;
        LblTenGianHang.Text = gh.TenGianHang;
        LblDiaChiGianHang.Text = gh.DiaChi;

        SwitchMoCua.Toggled -= OnSwitchMoCuaToggled;
        SwitchMoCua.IsToggled = gh.DangMoCua;
        SwitchMoCua.Toggled += OnSwitchMoCuaToggled;
        CapNhatChipMoCua(gh.DangMoCua);

        SwitchNhanDon.Toggled -= OnSwitchNhanDonToggled;
        SwitchNhanDon.IsToggled = gh.DangNhanDon;
        SwitchNhanDon.Toggled += OnSwitchNhanDonToggled;
        CapNhatTrangThaiNhanDon();
    }

    private void CapNhatChipMoCua(bool moCua)
    {
        LblTrangThaiMoCua.Text = moCua ? "● Đang mở cửa" : "● Tạm đóng cửa";
        LblTrangThaiMoCua.TextColor = Color.FromArgb(moCua ? "#15803D" : "#6B7280");
        ChipMoCua.BackgroundColor = Color.FromArgb(moCua ? "#DCFCE7" : "#F3F4F6");
    }

    /// <summary>Dòng xu hướng so với hôm qua: ▲ xanh khi tăng, ▼ đỏ khi giảm.</summary>
    private static void XuHuong(Label lbl, decimal hom_nay, decimal hom_qua)
    {
        if (hom_qua == 0) { lbl.Text = hom_nay > 0 ? "▲ Mới" : "–"; lbl.TextColor = Color.FromArgb(hom_nay > 0 ? "#16A34A" : "#6B7280"); return; }
        var pt = (double)((hom_nay - hom_qua) / hom_qua * 100);
        if (Math.Abs(pt) < 0.05) { lbl.Text = "– Không đổi"; lbl.TextColor = Color.FromArgb("#6B7280"); }
        else { lbl.Text = $"{(pt > 0 ? "▲" : "▼")} {Math.Abs(pt):0.#}%"; lbl.TextColor = Color.FromArgb(pt > 0 ? "#16A34A" : "#DC2626"); }
    }

    private async void OnXemHoSoClicked(object sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(VendorProfilePage));

    private void CapNhatTrangThaiNhanDon()
    {
        var gh = MockData.GianHangHienTai;
        LblTrangThaiNhanDon.Text = gh.CoTheNhanDon
            ? $"Đang nhận đơn · giờ hoạt động: {gh.GioHoatDongHienThi}"
            : $"Khách chưa đặt được: {gh.LyDoKhongNhanDon.ToLowerInvariant()}";
    }

    private void NapThongKeNhanh()
    {
        if (DoiTacService.HuyDonQuaHan(MockData.GianHangHienTai.Id) > 0)
            _ = DisplayAlert("Đơn tự hủy", "Có đơn quá 5 phút chưa phản hồi đã bị hệ thống tự hủy và hoàn tiền cho khách.", "OK");

        var donCuaToi = MockData.DonHangCuaGianHang.Where(d => d.GianHangId == MockData.GianHangHienTai.Id);

        var homNay = donCuaToi.Where(d => d.TrangThai != TrangThaiDonHang.DaHuy && d.NgayDat.Date == DateTime.Now.Date).ToList();
        var hoanThanhHomNay = homNay.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).ToList();
        LblDoanhThuHomNay.Text = $"{hoanThanhHomNay.Sum(d => d.TongTien):N0}đ";
        LblSoDonHomNay.Text = homNay.Count.ToString();
        var homQuaTatCa = donCuaToi.Where(d => d.TrangThai != TrangThaiDonHang.DaHuy && d.NgayDat.Date == DateTime.Now.Date.AddDays(-1)).ToList();
        var homQua = homQuaTatCa.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).ToList();
        XuHuong(LblXuHuongDon, homNay.Count, homQuaTatCa.Count);
        XuHuong(LblXuHuongDT, hoanThanhHomNay.Sum(d => d.TongTien), homQua.Sum(d => d.TongTien));

        var soChoXacNhan = donCuaToi.Count(d => d.TrangThai == TrangThaiDonHang.ChoXacNhan);
        var dangNau = donCuaToi.Count(d => d.TrangThai == TrangThaiDonHang.DangLam && !d.SanSangGiao);
        LblDangChuanBi.Text = dangNau.ToString();
        LblDangGiao.Text = donCuaToi.Count(d => d.TrangThai == TrangThaiDonHang.DangGiao).ToString();
        LblSoDonChoXacNhan.Text = soChoXacNhan > 0 ? $"{soChoXacNhan} đơn chờ xác nhận" : "không có đơn chờ";
        _soDonCho = soChoXacNhan;
        CapNhatSidebar();

        LblSoMonAn.Text = $"{MockData.MonAnCuaGianHang(MockData.GianHangHienTai.Id).Count(m => m.ConHang && !m.TamNgungBan)} món đang bán";

        var danhGia = DoiTacService.DanhGiaCua(MockData.GianHangHienTai.Id);
        var chuaPhanHoi = danhGia.Count(d => !d.CoPhanHoi);
        LblTomTatDanhGia.Text = danhGia.Count == 0 ? "Chưa có đánh giá"
            : $"{danhGia.Average(d => d.SoSaoMonAn):0.0}★ · {danhGia.Count} lượt" + (chuaPhanHoi > 0 ? $" · {chuaPhanHoi} chưa phản hồi" : "");

        var chuaDoc = DoiTacService.SoThongBaoChuaDoc(MockData.GianHangHienTai.Id);
        LblSoThongBao.Text = chuaDoc > 9 ? "9+" : chuaDoc.ToString();
        ((Border)LblSoThongBao.Parent).IsVisible = chuaDoc > 0;
    }

    private void NapDonMoi()
    {
        var donMoi = MockData.DonHangCuaGianHang
            .Where(d => d.GianHangId == MockData.GianHangHienTai.Id && d.TrangThai == TrangThaiDonHang.ChoXacNhan)
            .OrderBy(d => d.NgayDat)
            .ToList();

        DsDonMoi.ItemsSource = donMoi;
        LblKhongCoDonMoi.IsVisible = donMoi.Count == 0;
        NapDonGanDay();
        NapBieuDo();
    }

    private bool _dangHoanTacCongTac;

    private async void OnSwitchMoCuaToggled(object? sender, ToggledEventArgs e)
    {
        if (_dangHoanTacCongTac) return;
        var gh = MockData.GianHangHienTai;
        if (e.Value == gh.DangMoCua) { CapNhatChipMoCua(e.Value); return; }       // chỉ đồng bộ UI, không phải thao tác của người dùng
        if (!await Services.DuLieuService.GhiAsync("PUT", $"api/mobile/gian-hang/{gh.Id}/trang-thai-kinh-doanh", new { dangMoCua = e.Value }))
        {
            _dangHoanTacCongTac = true; SwitchMoCua.IsToggled = gh.DangMoCua; _dangHoanTacCongTac = false;   // không ghi được -> trả công tắc về như cũ
            return;
        }
        gh.DangMoCua = e.Value;
        VendorLocalStore.Luu();
        CapNhatChipMoCua(e.Value);
    }

    private async void OnSwitchNhanDonToggled(object? sender, ToggledEventArgs e)
    {
        if (_dangHoanTacCongTac) return;
        var gh = MockData.GianHangHienTai;
        if (e.Value == gh.DangNhanDon) { CapNhatTrangThaiNhanDon(); return; }
        if (!await Services.DuLieuService.GhiAsync("PUT", $"api/mobile/gian-hang/{gh.Id}/gio-hoat-dong",
                new { gioMoCua = gh.GioMoCua, gioDongCua = gh.GioDongCua, dangNhanDon = e.Value, dangMoCua = gh.DangMoCua }))
        {
            _dangHoanTacCongTac = true; SwitchNhanDon.IsToggled = gh.DangNhanDon; _dangHoanTacCongTac = false;
            return;
        }
        gh.DangNhanDon = e.Value;
        VendorLocalStore.Luu();
        CapNhatTrangThaiNhanDon();
    }

    private async void OnXacNhanNhanhClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: DonHang don }) return;

        var chuanBiPhut = await DoiTacService.ChonThoiGianChuanBiAsync(don);
        if (chuanBiPhut is null) return;
        if (!await DoiTacService.XacNhanDonAsync(don, chuanBiPhut)) return;

        NapThongKeNhanh();
        NapDonMoi();
        await DisplayAlert("Đã xác nhận", $"Đơn #{don.Id} đã được xác nhận và chuyển sang chuẩn bị món.", "OK");
    }

    private async void OnTuChoiNhanhClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: DonHang don }) return;

        if (!await DoiTacService.TuChoiDonAsync(this, don)) return;   // bắt buộc có lý do

        NapThongKeNhanh();
        NapDonMoi();
    }

    private async void OnXemDonHangTapped(object sender, EventArgs e) { if (await CoQuyenAsync(NhanVienQuan.DonHang)) await Shell.Current.GoToAsync(nameof(VendorOrdersPage)); }
    private async void OnXemThucDonTapped(object sender, EventArgs e) { if (await CoQuyenAsync(NhanVienQuan.ThucDon)) await Shell.Current.GoToAsync(nameof(VendorMenuPage)); }
    private async void OnXemDoanhThuTapped(object sender, EventArgs e) { if (await CoQuyenAsync(NhanVienQuan.TaiChinh)) await Shell.Current.GoToAsync(nameof(VendorRevenuePage)); }
    private async void OnXemHoSoTapped(object sender, EventArgs e) { if (!NhanVienQuan.LaNhanVien) await Shell.Current.GoToAsync(nameof(VendorProfilePage)); }
    private async void OnXemKhuyenMaiTapped(object sender, EventArgs e) { if (await CoQuyenAsync(NhanVienQuan.KhuyenMai)) await Shell.Current.GoToAsync(nameof(VendorPromotionsPage)); }
    private async void OnXemChienDichClicked(object sender, EventArgs e) { if (await CoQuyenAsync(NhanVienQuan.KhuyenMai)) await Shell.Current.GoToAsync(nameof(VendorCampaignsPage)); }
    private async void OnXemHuyHoanTienTapped(object sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(VendorCancelRefundPage));
    private async void OnXemDanhGiaTapped(object sender, EventArgs e) { if (await CoQuyenAsync(NhanVienQuan.DanhGia)) await Shell.Current.GoToAsync(nameof(VendorReviewsPage)); }
    private async void OnXemTaiChinhTapped(object sender, EventArgs e) { if (await CoQuyenAsync(NhanVienQuan.TaiChinh)) await Shell.Current.GoToAsync(nameof(VendorFinancePage)); }
    private async void OnXemThongBaoTapped(object sender, EventArgs e) { if (await CoQuyenAsync(NhanVienQuan.DonHang)) await Shell.Current.GoToAsync(nameof(VendorNotificationsPage)); }

    private void OnRefreshing(object? sender, EventArgs e)
    {
        NapHoSo();
        NapThongKeNhanh();
        NapDonMoi();
        RefreshTrangChu.IsRefreshing = false;
    }

    private async void OnDangXuatClicked(object? sender, EventArgs e)
    {
        try
        {
            bool xacNhan = await DisplayAlert("Đăng xuất", "Bạn có chắc muốn đăng xuất khỏi gian hàng?", "Đăng xuất", "Hủy");
            if (!xacNhan) return;

            // Bug cũ: First(g => g.Id == "gh1") ném lỗi khi dữ liệu từ SQL không có gian hàng "gh1".
            MockData.GianHangHienTai = new GianHang();
            Services.NhatKyService.Ghi("GianHang", MockData.GianHangHienTai.Email, "Đăng xuất", MockData.GianHangHienTai.TenGianHang, Services.NhatKyService.ThietBi());
            Services.Phien.DangXuat();
            await Shell.Current.GoToAsync("//dang-nhap");
        }
        catch (Exception ex) { await Services.DangXuatHelper.LoiAsync(ex); }
    }

    // ───────── Sidebar (ngăn kéo trên điện thoại, cố định khi màn rộng) ─────────
    private const double NguongManRong = 900;
    private int _soDonCho;
    private bool _daNoiSidebar;
    private int _kyBieuDo = 7;

    private void NoiSidebar()
    {
        if (_daNoiSidebar) return;
        _daNoiSidebar = true;
        SidebarCoDinh.Chon += async khoa => await DieuHuongSidebarAsync(khoa);
        SidebarNganKeo.Chon += async khoa => { LopNganKeo.IsVisible = false; await DieuHuongSidebarAsync(khoa); };
        SidebarCoDinh.MucChon = SidebarNganKeo.MucChon = "home";
    }

    private void CapNhatSidebar()
    {
        var ten = MockData.GianHangHienTai.TenGianHang;
        SidebarCoDinh.CapNhat(ten, _soDonCho, NhanVienQuan.LaNhanVien);
        SidebarNganKeo.CapNhat(ten, _soDonCho, NhanVienQuan.LaNhanVien);
    }

    private async Task DieuHuongSidebarAsync(string khoa)
    {
        switch (khoa)
        {
            case "orders": OnXemDonHangTapped(this, EventArgs.Empty); break;
            case "menu": OnXemThucDonTapped(this, EventArgs.Empty); break;
            case "promo": OnXemKhuyenMaiTapped(this, EventArgs.Empty); break;
            case "revenue": OnXemDoanhThuTapped(this, EventArgs.Empty); break;
            case "reviews": OnXemDanhGiaTapped(this, EventArgs.Empty); break;
            case "staff": OnXemNhanVienTapped(this, EventArgs.Empty); break;
            case "settings": OnXemHoSoTapped(this, EventArgs.Empty); break;
            case "logout": OnDangXuatClicked(null, EventArgs.Empty); break;
            default: break;   // home: ở lại trang chủ
        }
        await Task.CompletedTask;
    }

    private void OnTrangDoiKichThuoc(object? sender, EventArgs e)
    {
        var rong = Width >= NguongManRong;
        SidebarCoDinh.IsVisible = rong;
        NavDuoi.IsVisible = !rong;
        NutMoSidebar.IsVisible = !rong;
        if (rong) LopNganKeo.IsVisible = false;
    }

    private void OnMoSidebarTapped(object? sender, EventArgs e) { CapNhatSidebar(); LopNganKeo.IsVisible = true; }
    private void OnDongSidebarTapped(object? sender, EventArgs e) => LopNganKeo.IsVisible = false;

    // ───────── Đơn hàng gần đây + trạng thái xử lý ─────────
    private static (string Nhan, string Nen, string Chu) ChipTrangThai(DonHang d) => d.TrangThai switch
    {
        TrangThaiDonHang.ChoXacNhan => ("Chờ xác nhận", "#FFEDD5", "#C2410C"),
        TrangThaiDonHang.DangLam => d.SanSangGiao ? ("Chờ tài xế", "#EEEBFF", "#4A2FB5") : ("Đang chuẩn bị", "#DBEAFE", "#1D4ED8"),
        TrangThaiDonHang.DangGiao => ("Đang giao", "#DCFCE7", "#15803D"),
        TrangThaiDonHang.HoanThanh => ("Hoàn thành", "#F1F5F9", "#475569"),
        _ => ("Đã hủy", "#FEE2E2", "#B91C1C"),
    };

    private void NapDonGanDay()
    {
        var ds = MockData.DonHangCuaGianHang
            .Where(d => d.GianHangId == MockData.GianHangHienTai.Id)
            .OrderByDescending(d => d.NgayDat).Take(6).ToList();
        DsDonGanDay.Children.Clear();
        LblKhongCoDonGanDay.IsVisible = ds.Count == 0;
        foreach (var d in ds)
        {
            var (nhan, nen, chu) = ChipTrangThai(d);
            var mon = d.ChiTiet is { Count: > 0 } ? string.Join(", ", d.ChiTiet.Take(2).Select(c => c.MonAn?.TenMon ?? "")) : "";
            var dong = new Grid
            {
                ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
                RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Auto) },
                ColumnSpacing = 10, Padding = new Thickness(0, 9),
            };
            dong.Add(new Label { Text = $"#{d.Id}  {mon}", FontAttributes = FontAttributes.Bold, FontSize = 13.5, LineBreakMode = LineBreakMode.TailTruncation }, 0, 0);
            dong.Add(new Label { Text = $"{d.NgayDat:HH:mm} · {d.TongTien:N0}đ", FontSize = 12, TextColor = Color.FromArgb("#6B7280") }, 0, 1);
            var chip = new Border
            {
                BackgroundColor = Color.FromArgb(nen), StrokeThickness = 0, Padding = new Thickness(10, 4), VerticalOptions = LayoutOptions.Center,
                StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(12) },
                Content = new Label { Text = nhan, FontSize = 11.5, FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb(chu) }
            };
            dong.Add(chip, 1, 0);
            Grid.SetRowSpan(chip, 2);
            DsDonGanDay.Children.Add(dong);
            if (d != ds[^1]) DsDonGanDay.Children.Add(new BoxView { HeightRequest = 1, Color = Color.FromArgb("#E3E6F5") });
        }
    }

    // ───────── Biểu đồ doanh thu (đơn hoàn thành) ─────────
    private void OnChonKyBieuDo(object? sender, TappedEventArgs e)
    {
        if (e.Parameter is string p && int.TryParse(p, out var ky)) { _kyBieuDo = ky; NapBieuDo(); }
    }

    private void NapBieuDo()
    {
        var hoanThanh = MockData.DonHangCuaGianHang
            .Where(d => d.GianHangId == MockData.GianHangHienTai.Id && d.TrangThai == TrangThaiDonHang.HoanThanh).ToList();
        var homNay = DateTime.Now.Date;
        var nhan = new List<string>(); var gt = new List<decimal>();
        if (_kyBieuDo <= 30)
        {
            for (int i = _kyBieuDo - 1; i >= 0; i--)
            {
                var ngay = homNay.AddDays(-i);
                nhan.Add(ngay.ToString("dd/MM"));
                gt.Add(hoanThanh.Where(d => d.NgayDat.Date == ngay).Sum(d => d.TongTien));
            }
        }
        else
        {
            for (int t = 12; t >= 0; t--)   // 13 tuần ≈ 3 tháng
            {
                var den = homNay.AddDays(-7 * t); var tu = den.AddDays(-6);
                nhan.Add(den.ToString("dd/MM"));
                gt.Add(hoanThanh.Where(d => d.NgayDat.Date >= tu && d.NgayDat.Date <= den).Sum(d => d.TongTien));
            }
        }
        BieuDo.Dat(nhan, gt);
        BieuDo.HeightRequest = 190;
        LblTongKyBieuDo.Text = $"Tổng {(_kyBieuDo == 90 ? "3 tháng" : _kyBieuDo + " ngày")}: {gt.Sum():N0}đ" + (_kyBieuDo == 90 ? " (theo tuần)" : "");
        ToChip(Chip7, _kyBieuDo == 7); ToChip(Chip30, _kyBieuDo == 30); ToChip(Chip90, _kyBieuDo == 90);
    }

    private static void ToChip(Border chip, bool chon)
    {
        chip.BackgroundColor = Color.FromArgb(chon ? "#5B3FD9" : "#EEEBFF");
        if (chip.Content is Label l) l.TextColor = Color.FromArgb(chon ? "#FFFFFF" : "#4A2FB5");
    }
}
