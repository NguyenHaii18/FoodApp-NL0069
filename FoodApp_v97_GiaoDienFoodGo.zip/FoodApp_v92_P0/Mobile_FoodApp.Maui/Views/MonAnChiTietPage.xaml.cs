using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Chi tiết món: ảnh, mô tả, giá, số lượng, ghi chú → "Thêm vào giỏ hàng".</summary>
[QueryProperty(nameof(Mon), "Mon")]
[QueryProperty(nameof(GianHang), "GianHang")]
[QueryProperty(nameof(SoLuongBanDau), "SoLuong")]
public partial class MonAnChiTietPage : ContentPage
{
    public MonAn? Mon { get; set; }
    public GianHang? GianHang { get; set; }
    public int SoLuongBanDau { get; set; } = 1;
    private int _soLuong = 1;
    private readonly List<TuyChonMon> _chon = new();      // tùy chọn khách đang chọn

    public MonAnChiTietPage() { InitializeComponent(); }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        if (Mon is null) return;
        _soLuong = Math.Clamp(SoLuongBanDau, 1, 99);
        LblTen.Text = Mon.TenMon;
        LblGia.Text = $"{Mon.Gia:N0}đ";
        LblMoTa.Text = string.IsNullOrWhiteSpace(Mon.MoTa) ? "Chưa có mô tả cho món này." : Mon.MoTa;
        var gh = GianHang ?? MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == Mon.GianHangId);
        LblQuan.Text = gh is null ? "" : $"🏪 {gh.TenGianHang}";
        LblTinhTrang.Text = Mon.TinhTrangText;
        LblTinhTrang.TextColor = Mon.TinhTrangMau;
        if (Mon.CoAnh) { ImgMon.Source = Mon.AnhPath; ImgMon.IsVisible = true; LblEmoji.IsVisible = false; }
        else { LblEmoji.Text = Mon.HinhAnh; LblEmoji.IsVisible = true; ImgMon.IsVisible = false; }
        KhungGhiChu.IsVisible = Mon.ChoGhiChu;

        LblTimMon.Text = TaiKhoanService.LaYeuThichMon(Mon.Id) ? "♥" : "♡";
        XayDungTuyChon();
        XayDungChipYeuCau();
        XayDungAnKem();
        BtnThem.IsEnabled = Mon.ConHang && !Mon.TamNgungBan;
        CapNhat();
    }

    /// <summary>Dựng phần chọn tùy chọn: Size / Mức cay chọn một (radio), Topping chọn nhiều (ô tick). Giá cập nhật ngay khi chọn.</summary>
    private void XayDungTuyChon()
    {
        KhungTuyChon.Children.Clear();
        _chon.Clear();
        if (Mon is null || Mon.TuyChon.Count == 0) { KhungTuyChon.IsVisible = false; return; }
        KhungTuyChon.IsVisible = true;
        KhungTuyChon.Spacing = 8;
        foreach (var nhom in Mon.TuyChon.GroupBy(t => t.Loai))
        {
            var chonMot = nhom.Key != TuyChonMon.Topping;
            var batBuoc = nhom.Key == TuyChonMon.Size;
            KhungTuyChon.Children.Add(new Label
            {
                Text = TuyChonMon.NhanLoai(nhom.Key) + (batBuoc ? "  (bắt buộc)" : chonMot ? "  (chọn 1)" : "  (chọn nhiều)"),
                FontAttributes = FontAttributes.Bold, FontSize = 14,
            });
            if (chonMot)
            {
                var ten = $"nhom-{nhom.Key}";
                if (!batBuoc)
                {
                    var mac = new RadioButton { Content = "Mặc định", GroupName = ten, IsChecked = true };
                    mac.CheckedChanged += (_, e) => { if (e.Value) { _chon.RemoveAll(c => c.Loai == nhom.Key); CapNhat(); } };
                    KhungTuyChon.Children.Add(mac);
                }
                var dau = true;
                foreach (var t in nhom)
                {
                    var rb = new RadioButton { Content = t.HienThi, GroupName = ten };
                    var tc = t;
                    rb.CheckedChanged += (_, e) =>
                    {
                        if (!e.Value) return;
                        _chon.RemoveAll(c => c.Loai == tc.Loai);
                        _chon.Add(tc);
                        CapNhat();
                    };
                    if (batBuoc && dau) rb.IsChecked = true;      // size đầu tiên được chọn sẵn
                    dau = false;
                    KhungTuyChon.Children.Add(rb);
                }
            }
            else
            {
                foreach (var t in nhom)
                {
                    var tc = t;
                    var cb = new CheckBox { VerticalOptions = LayoutOptions.Center };
                    cb.CheckedChanged += (_, e) =>
                    {
                        if (e.Value) { if (!_chon.Contains(tc)) _chon.Add(tc); } else _chon.Remove(tc);
                        CapNhat();
                    };
                    var dong = new HorizontalStackLayout { Spacing = 6 };
                    dong.Children.Add(cb);
                    dong.Children.Add(new Label { Text = t.HienThi, VerticalOptions = LayoutOptions.Center, FontSize = 14 });
                    var tap = new TapGestureRecognizer();
                    tap.Tapped += (_, _) => cb.IsChecked = !cb.IsChecked;
                    dong.GestureRecognizers.Add(tap);
                    KhungTuyChon.Children.Add(dong);
                }
            }
        }
    }

    private void OnTimMonTapped(object? s, TappedEventArgs e)
    {
        if (Mon is null) return;
        LblTimMon.Text = TaiKhoanService.DaoYeuThichMon(Mon.Id) ? "♥" : "♡";
    }

    // ---------------------------------------------------------------- v80: yêu cầu nhanh (cay / đường / đá / hành…)
    private static readonly string[] TuKhoaDoUong = { "uong", "tra", "ca phe", "cafe", "coffee", "nuoc", "sinh to", "sua", "da xay", "smoothie", "matcha", "soda", "yaourt", "kem" };
    private static readonly string[][] NhomDoUong =
    {
        new[] { "Ít đường", "Không đường", "Nhiều đường" },
        new[] { "Ít đá", "Không đá", "Nhiều đá" },
    };
    private static readonly string[][] NhomMonMan =
    {
        new[] { "Ít cay", "Không cay", "Cay nhiều" },
        new[] { "Không hành", "Không rau thơm" },
        new[] { "Ít muối", "Ít dầu mỡ" },
    };
    private readonly Dictionary<string, Button> _chip = new();

    /// <summary>Chip chọn nhanh đường / đá (đồ uống) hoặc cay / hành (món mặn), ghép vào ô ghi chú. Chỉ hiện khi quán cho ghi chú.
    /// Mỗi nhóm chọn một (Ít/Không/Nhiều); chạm lần nữa để bỏ.</summary>
    private void XayDungChipYeuCau()
    {
        KhungChipYeuCau.Children.Clear();
        _chip.Clear();
        if (Mon is null || !Mon.ChoGhiChu) return;
        var tx = TimKiemService.BoDau(Mon.TenMon + " " + Mon.DanhMuc);
        var nhom = TuKhoaDoUong.Any(k => tx.Contains(k)) ? NhomDoUong : NhomMonMan;
        foreach (var g in nhom)
            foreach (var nhan in g)
            {
                var b = new Button { Text = nhan, FontSize = 12.5, HeightRequest = 34, Padding = new Thickness(12, 0), CornerRadius = 17, Margin = new Thickness(0, 0, 6, 6) };
                var nhomHienTai = g; var ten = nhan;
                b.Clicked += (_, _) => DoiChip(nhomHienTai, ten);
                _chip[nhan] = b;
                KhungChipYeuCau.Children.Add(b);
            }
        ToMauChip();
    }

    private HashSet<string> ChipDangChon() =>
        (EditorGhiChu.Text ?? "").Split(new[] { ',', ';', '\n' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(x => _chip.ContainsKey(x)).ToHashSet();

    private void DoiChip(string[] nhom, string ten)
    {
        var tat = (EditorGhiChu.Text ?? "").Split(new[] { ',', ';', '\n' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList();
        var dangBat = tat.Contains(ten);
        tat.RemoveAll(x => nhom.Contains(x));          // một nhóm chỉ giữ một lựa chọn
        if (!dangBat) tat.Add(ten);
        EditorGhiChu.Text = string.Join(", ", tat);
        ToMauChip();
    }

    private void ToMauChip()
    {
        var bat = ChipDangChon();
        foreach (var (nhan, b) in _chip)
        {
            var on = bat.Contains(nhan);
            b.BackgroundColor = on ? Color.FromArgb("#7C3AED") : Color.FromArgb("#EDE9FE");
            b.TextColor = on ? Colors.White : Color.FromArgb("#5B21B6");
        }
    }

    // ---------------------------------------------------------------- v80: món ăn kèm
    private void XayDungAnKem()
    {
        KhungAnKem.Children.Clear();
        var ds = Mon is null || !(Mon.ConHang && !Mon.TamNgungBan) ? new() : TrangChuService.MonAnKem(Mon, 6);
        KhungAnKem.IsVisible = ds.Count > 0;
        if (ds.Count == 0) return;
        KhungAnKem.Children.Add(new Label { Text = "🍟 Món ăn kèm gợi ý", FontAttributes = FontAttributes.Bold, FontSize = 14 });
        foreach (var (m, lyDo) in ds)
        {
            var mon = m;
            var thong = new VerticalStackLayout { Spacing = 1, VerticalOptions = LayoutOptions.Center };
            thong.Children.Add(new Label { Text = $"{mon.HinhAnh} {mon.TenMon}", FontSize = 13.5, FontAttributes = FontAttributes.Bold, LineBreakMode = LineBreakMode.TailTruncation });
            thong.Children.Add(new Label { Text = $"{mon.Gia:N0}đ · {lyDo}", FontSize = 11.5, TextColor = Colors.Gray });
            var nut = new Button { Text = mon.TuyChon.Count > 0 ? "Chọn" : "+ Thêm", FontSize = 12, HeightRequest = 34, Padding = new Thickness(12, 0), CornerRadius = 17 };
            nut.Clicked += async (_, _) => await ThemAnKemAsync(mon);
            var luoi = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 8 };
            luoi.Add(thong, 0);
            luoi.Add(nut, 1);
            KhungAnKem.Children.Add(luoi);
        }
    }

    private async Task ThemAnKemAsync(MonAn mon)
    {
        if (mon.TuyChon.Count > 0)    // món kèm cần chọn size/topping → mở trang chi tiết của nó
        {
            await Shell.Current.GoToAsync(nameof(MonAnChiTietPage), new Dictionary<string, object> { { "Mon", mon }, { "GianHang", (object?)GianHang ?? MockData.DanhSachGianHang.First(g => g.Id == mon.GianHangId) } });
            return;
        }
        if (GioHangService.CoMonQuanKhac(mon.GianHangId) &&
            !await DisplayAlert("Giỏ hàng của quán khác", "Giỏ đang có món của quán khác. Xóa giỏ cũ và thêm món này?", "Xóa giỏ cũ", "Giữ giỏ cũ")) return;
        GioHangService.Them(mon, 1, "");
        await GioHangService.LuuAsync();
        await DisplayAlert("Đã thêm", $"Đã thêm {mon.TenMon} vào giỏ.", "OK");
    }

    private void CapNhat()
    {
        LblSoLuong.Text = _soLuong.ToString();
        var donGia = (Mon?.Gia ?? 0) + _chon.Sum(t => t.GiaThem);
        if (Mon != null) LblGia.Text = _chon.Sum(t => t.GiaThem) > 0 ? $"{donGia:N0}đ  (gồm phụ thu {_chon.Sum(t => t.GiaThem):N0}đ)" : $"{Mon.Gia:N0}đ";
        BtnThem.Text = Mon is { ConHang: true, TamNgungBan: false }
            ? $"Thêm vào giỏ hàng   •   {(donGia * _soLuong):N0}đ"
            : "Món hiện không đặt được";
    }

    private void OnGiamClicked(object? s, EventArgs e) { if (_soLuong > 1) { _soLuong--; CapNhat(); } }
    private void OnTangClicked(object? s, EventArgs e) { if (_soLuong < 99) { _soLuong++; CapNhat(); } }

    private async void OnThemVaoGioClicked(object? s, EventArgs e)
    {
        if (Mon is null) return;
        if (GioHangService.CoMonQuanKhac(Mon.GianHangId))
        {
            var quanCu = MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == GioHangService.GianHangId)?.TenGianHang ?? "quán khác";
            if (!await DisplayAlert("Giỏ hàng của quán khác", $"Giỏ đang có món của {quanCu}. Xóa giỏ cũ và thêm món này?", "Xóa giỏ cũ", "Giữ giỏ cũ")) return;
        }
        var thieu = Mon.TuyChon.Any(t => t.Loai == TuyChonMon.Size) && !_chon.Any(t => t.Loai == TuyChonMon.Size);
        if (thieu) { await DisplayAlert("Chưa chọn size", "Vui lòng chọn kích cỡ / khẩu phần cho món.", "OK"); return; }
        GioHangService.Them(Mon, _soLuong, EditorGhiChu.Text?.Trim() ?? "", _chon.ToList());
        await GioHangService.LuuAsync();
        await Shell.Current.GoToAsync("..");
    }
}
