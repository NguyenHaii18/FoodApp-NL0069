using System.Globalization;
using System.Text.Json;
using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// v91 — Bảng điều phối (Dispatcher): số liệu trong ngày, tài xế trực tuyến/bận/rảnh, đơn nguy cơ trễ, khu vực thiếu tài xế,
/// gửi lại / thu hồi lời mời nhận đơn, xử lý sự cố nhanh và báo cáo điều phối (xuất Excel).
/// Dùng API sẵn có: GET api/mobile/admin/dieu-phoi, PUT .../dieu-phoi/{id}/tim-lai, PUT .../dieu-phoi/{id}/go-tai-xe.
/// </summary>
public sealed class AdminDieuPhoiTongQuanPage : AdminKyThuatTrang
{
    private const int PhutNguyCoTre = 20;      // đơn chờ tài xế quá số phút này = nguy cơ giao trễ

    protected override Quyen? QuyenCan => Quyen.XemThongKe;
    private JsonElement _goc;
    private string _tim = "";

    public AdminDieuPhoiTongQuanPage() : base("Bảng điều phối")
    {
        ToolbarItems.Add(new ToolbarItem { Text = "📥 Excel", Command = new Command(async () => await XuatAsync()) });
    }

    private static string Khu(string diaChi)
    {
        var p = (diaChi ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (p.Length >= 3) return p[^2];
        return p.Length == 2 ? p[1] : (p.Length == 1 ? p[0] : "Chưa rõ khu vực");
    }

    private static bool CoTre(JsonElement d) =>
        DateTime.TryParse(J.S(d, "ngayDat"), CultureInfo.InvariantCulture, DateTimeStyles.None, out var t) && (DateTime.Now - t).TotalMinutes >= PhutNguyCoTre;

    private static View The(string nhan, string giaTri, string mau)
    {
        var st = new VerticalStackLayout { Spacing = 0, HorizontalOptions = LayoutOptions.Fill };
        var v = AdminUi.Nhan(giaTri, 20, dam: true); v.TextColor = Color.FromArgb(mau);
        st.Add(v); st.Add(AdminUi.Nhan(nhan, 11, mo: true));
        var b = AdminUi.The(10); b.Content = st; return b;
    }

    private static Grid Luoi(params View[] cacThe)
    {
        var g = new Grid { ColumnSpacing = 8, RowSpacing = 8, ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) } };
        for (int i = 0; i < cacThe.Length; i++)
        {
            if (i % 3 == 0) g.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
            g.Add(cacThe[i], i % 3, i / 3);
        }
        return g;
    }

    protected override async Task DungAsync()
    {
        var r = await ApiClient.GetAsync<JsonElement>("api/mobile/admin/dieu-phoi");
        if (!r.ThanhCong)
        {
            Nd.Add(AdminUi.Nhan(r.MatKetNoi ? "Bảng điều phối cần kết nối máy chủ (online).\n" + r.ThongDiep : r.ThongDiep, 13, mo: true));
            return;
        }
        _goc = r.DuLieu;
        try { await DuLieuService.TaiDonToanHeThongAsync(); } catch { /* thiếu dữ liệu trong ngày thì chỉ bỏ phần đó */ }

        var canGiao = J.Mang(_goc, "canGiao").ToList();
        var dangGiao = J.Mang(_goc, "dangGiao").ToList();
        var taiXes = J.Mang(_goc, "taiXes").ToList();
        var homNay = MockData.TatCaDonHangHeThong.Where(d => d.NgayDat.Date == DateTime.Today).ToList();

        int daGiao = homNay.Count(d => d.TrangThai == TrangThaiDonHang.HoanThanh);
        int thatBai = homNay.Count(d => d.GiaoThatBai);
        int dangLay = dangGiao.Count(d => J.S(d, "trangThai") == "DaXacNhan");
        int dangGiaoSo = dangGiao.Count(d => J.S(d, "trangThai") == "DangGiao");
        int online = taiXes.Count(t => J.S(t, "trangThai") != "NgoaiTuyen");
        int offline = taiXes.Count - online;
        int ban = taiXes.Count(t => J.S(t, "trangThai") != "NgoaiTuyen" && (J.S(t, "trangThai") == "DangGiao" || J.L(t, "soDonDangGiao") > 0));
        int ranh = online - ban;
        var nguyCo = canGiao.Where(CoTre).ToList();

        // ---- 1. Dashboard
        Nd.Add(KhoiTheo("Hôm nay",
            Luoi(The("Tổng đơn", homNay.Count.ToString(), AdminUi.Tim),
                 The("Chờ tài xế", canGiao.Count.ToString(), canGiao.Count > 0 ? AdminUi.Cam : AdminUi.Xanh),
                 The("Đã có tài xế", (dangLay + dangGiaoSo).ToString(), AdminUi.Tim),
                 The("Đang lấy hàng", dangLay.ToString(), AdminUi.Tim),
                 The("Đang giao", dangGiaoSo.ToString(), AdminUi.Tim),
                 The("Giao thành công", daGiao.ToString(), AdminUi.Xanh),
                 The("Giao thất bại", thatBai.ToString(), thatBai > 0 ? AdminUi.Do : AdminUi.Xam),
                 The("Nguy cơ trễ", nguyCo.Count.ToString(), nguyCo.Count > 0 ? AdminUi.Do : AdminUi.Xanh))));

        Nd.Add(KhoiTheo("Tài xế",
            Luoi(The("Trực tuyến", online.ToString(), AdminUi.Xanh),
                 The("Ngoại tuyến", offline.ToString(), AdminUi.Xam),
                 The("Đang bận", ban.ToString(), AdminUi.Cam),
                 The("Đang rảnh", ranh.ToString(), AdminUi.Xanh))));

        // ---- Khu vực thiếu tài xế
        var thieu = canGiao.GroupBy(d => Khu(J.S(d, "diaChiGiaoHang")))
            .Select(g => new
            {
                Khu = g.Key, Don = g.Count(),
                Ranh = taiXes.Count(t => J.S(t, "trangThai") == "SanSang" && J.L(t, "soDonDangGiao") == 0 &&
                                         (J.S(t, "khuVucHoatDong").Contains(g.Key, StringComparison.OrdinalIgnoreCase) || J.Rong(t, "khuVucHoatDong")))
            })
            .Where(x => x.Don > x.Ranh).OrderByDescending(x => x.Don - x.Ranh).ToList();
        var thieuView = new VerticalStackLayout { Spacing = 4 };
        if (thieu.Count == 0) thieuView.Add(AdminUi.Nhan("✅ Chưa có khu vực nào thiếu tài xế.", 12.5, mo: true));
        foreach (var x in thieu.Take(8)) thieuView.Add(DongTrai($"{x.Khu}", $"{x.Don} đơn / {x.Ranh} tài xế rảnh", AdminUi.Do));
        Nd.Add(KhoiTheo("Khu vực đang thiếu tài xế", thieuView));

        // ---- 2. Theo dõi tài xế (tìm theo tên/mã, trạng thái, nút mở bản đồ & điều phối)
        var (kt, o) = AdminUi.OTimKiem("Tìm tài xế theo tên hoặc mã…");
        o.Text = _tim;
        o.Completed += async (_, _) => { _tim = o.Text ?? ""; Nd.Children.Clear(); await DungAsync(); };
        var dsTx = new VerticalStackLayout { Spacing = 6 };
        var loc = taiXes.Where(t => string.IsNullOrWhiteSpace(_tim) ||
                                    J.S(t, "hoTen").Contains(_tim, StringComparison.OrdinalIgnoreCase) || J.L(t, "maTaiXe").ToString() == _tim.Trim().TrimStart('#')).Take(40).ToList();
        if (loc.Count == 0) dsTx.Add(AdminUi.Nhan("Không có tài xế phù hợp.", 12.5, mo: true));
        foreach (var t in loc)
        {
            var tt = J.S(t, "trangThai");
            var mau = tt == "NgoaiTuyen" ? AdminUi.Xam : J.L(t, "soDonDangGiao") > 0 ? AdminUi.Cam : AdminUi.Xanh;
            var nhan = tt == "NgoaiTuyen" ? "Ngoại tuyến" : J.L(t, "soDonDangGiao") > 0 ? $"Bận ({J.L(t, "soDonDangGiao")} đơn)" : "Rảnh";
            var donCuaTx = dangGiao.Where(d => J.L(d, "maTaiXe") == J.L(t, "maTaiXe")).Select(d => "#" + J.L(d, "maDonHang"));
            dsTx.Add(DongTrai($"#{J.L(t, "maTaiXe")} {J.S(t, "hoTen")} · {J.S(t, "phuongTien")}" +
                              (J.Rong(t, "khuVucHoatDong") ? "" : $" · {J.S(t, "khuVucHoatDong")}") +
                              (donCuaTx.Any() ? " · đơn " + string.Join(", ", donCuaTx) : ""), nhan, mau));
        }
        var nutBanDo = AdminUi.Nut("🗺 Bản đồ tài xế / lộ trình", AdminUi.Tim);
        nutBanDo.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(AdminLoTrinhPage));
        Nd.Add(KhoiTheo($"Theo dõi tài xế ({taiXes.Count})", kt, dsTx, nutBanDo,
            AdminUi.Nhan("Vị trí GPS theo thời gian thực xem ở bản đồ của đơn đang giao (Theo dõi đơn). Tài xế mất kết nối ≥ 5 phút sẽ có cảnh báo ở Trung tâm vận hành.", 11, mo: true)));

        // ---- 3. Phân phối đơn: đơn chờ tài xế, ưu tiên đơn sắp trễ, gửi lại / thu hồi lời mời
        var dsDon = new VerticalStackLayout { Spacing = 8 };
        if (canGiao.Count == 0) dsDon.Add(AdminUi.Nhan("✅ Không có đơn nào đang chờ tài xế.", 12.5, mo: true));
        foreach (var d in canGiao.OrderByDescending(CoTre).ThenBy(d => J.S(d, "ngayDat")).Take(15))
        {
            var ma = (int)J.L(d, "maDonHang");
            var tre = CoTre(d);
            var hang = new VerticalStackLayout { Spacing = 3 };
            hang.Add(DongTrai($"#{ma} · {J.S(d, "gianHang")}", tre ? "⏰ Sắp trễ" : (J.B(d, "sanSangGiao") ? "Quán đã xong" : "Quán đang làm"), tre ? AdminUi.Do : AdminUi.Xam));
            hang.Add(AdminUi.Nhan($"{J.S(d, "diaChiGiaoHang")} · {J.Ngay(d, "ngayDat", "HH:mm")}", 11.5, mo: true));
            var nut = new HorizontalStackLayout { Spacing = 6 };
            var tl = AdminUi.Nut("🔁 Gửi lại lời mời", AdminUi.Tim);
            tl.Clicked += async (_, _) => { if (await AdminUi.Put(this, $"api/mobile/admin/dieu-phoi/{ma}/tim-lai", null, "Gửi lại lời mời nhận đơn", "#" + ma)) await LamLaiAsync(); };
            var pc = AdminUi.Nut("👤 Phân công / đề xuất", AdminUi.Xanh);
            pc.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(AdminDispatchPage));
            nut.Add(tl); nut.Add(pc);
            hang.Add(nut);
            dsDon.Add(hang);
        }
        var thuHoi = new VerticalStackLayout { Spacing = 6 };
        foreach (var d in dangGiao.Where(d => J.S(d, "trangThai") == "DaXacNhan").Take(10))
        {
            var ma = (int)J.L(d, "maDonHang");
            var nutGo = AdminUi.Nut($"↩ Thu hồi đơn #{ma} khỏi {J.S(d, "taiXe")}", AdminUi.Do);
            nutGo.Clicked += async (_, _) =>
            {
                if (!await DisplayAlert("Thu hồi đơn", $"Gỡ đơn #{ma} khỏi tài xế {J.S(d, "taiXe")} để tìm tài xế khác?", "Thu hồi", "Hủy")) return;
                if (await AdminUi.Put(this, $"api/mobile/admin/dieu-phoi/{ma}/go-tai-xe", new { lyDo = "Điều phối viên thu hồi từ Bảng điều phối" }, "Thu hồi đơn khỏi tài xế", "#" + ma)) await LamLaiAsync();
            };
            thuHoi.Add(nutGo);
        }
        Nd.Add(KhoiTheo($"Đơn cần tìm tài xế ({canGiao.Count}) — ưu tiên đơn sắp trễ", dsDon));
        if (thuHoi.Children.Count > 0) Nd.Add(KhoiTheo("Thu hồi đơn đã phân công (chưa lấy hàng)", thuHoi));

        var nutDieuPhoi = AdminUi.Nut("🧭 Phân công thủ công / đổi tài xế / tự động / bán kính", AdminUi.Tim, day: true);
        nutDieuPhoi.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(AdminDispatchPage));
        Nd.Add(nutDieuPhoi);

        // ---- 4. Xử lý sự cố giao hàng
        var suCo = new VerticalStackLayout { Spacing = 4 };
        foreach (var s in new[]
        {
            "Nhà hàng chưa chuẩn bị xong món", "Tài xế không tìm thấy địa chỉ", "Khách không nghe điện thoại", "Khách yêu cầu đổi địa chỉ",
            "Tài xế gặp tai nạn", "Đơn giao nhầm / thiếu món / đổ hỏng", "Tài xế mất kết nối", "Đơn giao trễ / yêu cầu đổi tài xế",
        }) suCo.Add(AdminUi.Nhan("• " + s, 12.5));
        var nutSuCo = AdminUi.Nut("🛵 Mở danh sách sự cố tài xế", AdminUi.Do, day: true);
        nutSuCo.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(AdminDriverIssuesPage));
        var nutCs = AdminUi.Nut("📨 Chuyển CSKH / quản lý vận hành", AdminUi.Tim);
        nutCs.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(AdminCskhPage));
        Nd.Add(KhoiTheo("Xử lý sự cố giao hàng", suCo, nutSuCo, nutCs));

        // ---- 5. Báo cáo điều phối (tính từ nhật ký điều phối gần nhất + đơn hôm nay)
        var log = J.Mang(_goc, "log").ToList();
        int dem(params string[] k) => log.Count(l => k.Any(x => J.S(l, "hanhDong").Contains(x, StringComparison.OrdinalIgnoreCase)));
        int phanCong = dem("PhanCong", "TuDongPhanCong");
        int deNghi = dem("DeNghi") - dem("DeNghiHetHan");
        int tuChoi = dem("TuChoi");
        int hetHan = dem("HetHan", "QuaHan");
        int khongCo = dem("KhongCoTaiXe");
        int lan = deNghi + tuChoi + hetHan;
        string tl2(int a) => lan == 0 ? "—" : $"{100.0 * a / lan:0.#}%";
        int treHomNay = homNay.Count(d => d.TrangThai == TrangThaiDonHang.HoanThanh && d.GiaoLuc is DateTime gl && (gl - d.NgayDat).TotalMinutes > 60);
        Nd.Add(KhoiTheo("Báo cáo điều phối (20 sự kiện gần nhất + hôm nay)",
            DongTrai("Đơn đã phân phối", phanCong.ToString()),
            DongTrai("Đơn giao thành công hôm nay", daGiao.ToString(), AdminUi.Xanh),
            DongTrai("Tỷ lệ tài xế chấp nhận (ước tính)", tl2(Math.Max(0, deNghi - tuChoi - hetHan))),
            DongTrai("Tỷ lệ từ chối", tl2(tuChoi)),
            DongTrai("Tỷ lệ không phản hồi / hết hạn", tl2(hetHan)),
            DongTrai("Lần không tìm được tài xế", khongCo.ToString(), khongCo > 0 ? AdminUi.Do : null),
            DongTrai("Đơn giao trễ hôm nay (> 60 phút)", treHomNay.ToString(), treHomNay > 0 ? AdminUi.Do : null),
            DongTrai("Đơn giao thất bại / hủy hôm nay", thatBai.ToString()),
            AdminUi.Nhan("Thời gian tìm tài xế trung bình & hiệu suất theo khu vực cần dữ liệu nhiều ngày — bấm 📥 Excel để xuất bản tổng hợp hiện có.", 11, mo: true)));
    }

    private async Task LamLaiAsync() { Nd.Children.Clear(); await DungAsync(); }

    private async Task XuatAsync()
    {
        try
        {
            if (_goc.ValueKind != JsonValueKind.Object) { await DisplayAlert("Chưa có dữ liệu", "Hãy mở lại trang khi đã kết nối máy chủ.", "Đóng"); return; }
            var tx = new List<object?[]> { new object?[] { "Mã", "Tài xế", "SĐT", "Phương tiện", "Khu vực", "Trạng thái", "Số đơn đang giữ" } };
            tx.AddRange(J.Mang(_goc, "taiXes").Select(t => new object?[] { J.L(t, "maTaiXe"), J.S(t, "hoTen"), J.S(t, "sdt"), J.S(t, "phuongTien"), J.S(t, "khuVucHoatDong"), J.S(t, "trangThai"), J.L(t, "soDonDangGiao") }));
            var cho = new List<object?[]> { new object?[] { "Mã đơn", "Quán", "Địa chỉ giao", "Ngày đặt", "Quán sẵn sàng", "Nguy cơ trễ" } };
            cho.AddRange(J.Mang(_goc, "canGiao").Select(d => new object?[] { J.L(d, "maDonHang"), J.S(d, "gianHang"), J.S(d, "diaChiGiaoHang"), J.Ngay(d, "ngayDat"), J.B(d, "sanSangGiao") ? "Có" : "Chưa", CoTre(d) ? "Có" : "" }));
            var dang = new List<object?[]> { new object?[] { "Mã đơn", "Quán", "Tài xế", "Trạng thái", "Ngày đặt" } };
            dang.AddRange(J.Mang(_goc, "dangGiao").Select(d => new object?[] { J.L(d, "maDonHang"), J.S(d, "gianHang"), J.S(d, "taiXe"), J.S(d, "trangThai"), J.Ngay(d, "ngayDat") }));
            var nk = new List<object?[]> { new object?[] { "Thời gian", "Đơn", "Hành động", "Lý do" } };
            nk.AddRange(J.Mang(_goc, "log").Select(l => new object?[] { J.Ngay(l, "thoiGian"), J.L(l, "maDonHang"), J.S(l, "hanhDong"), J.S(l, "lyDo") }));
            var duongDan = Path.Combine(FileSystem.CacheDirectory, $"BaoCaoDieuPhoi_{DateTime.Now:yyyyMMdd_HHmm}.xlsx");
            new XlsxWriter().ThemSheet("Tai xe", tx).ThemSheet("Don cho tai xe", cho).ThemSheet("Don dang giao", dang).ThemSheet("Nhat ky dieu phoi", nk).Luu(duongDan);
            NhatKyService.GhiQuanTri("Xuất báo cáo điều phối (Excel)", "");
            await Share.Default.RequestAsync(new ShareFileRequest { Title = "Báo cáo điều phối", File = new ShareFile(duongDan) });
        }
        catch (Exception ex) { await DisplayAlert("Không xuất được báo cáo", ex.Message, "Đóng"); }
    }
}
