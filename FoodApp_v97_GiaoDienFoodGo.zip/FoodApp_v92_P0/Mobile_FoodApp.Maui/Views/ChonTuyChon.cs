using Microsoft.Maui.Controls.Shapes;

namespace FoodApp.Maui.Views;

/// <summary>
/// Ô chọn tùy chọn cho quán: bấm vào các nhãn có sẵn để bật/tắt (không phải gõ), mục đã chọn hiện ô phụ phí (số) bên dưới.
/// "＋ Thêm" cho phép tạo lựa chọn riêng (chỉ nhập tên). Khách hàng sẽ thấy đúng các lựa chọn này dạng bấm chọn.
/// </summary>
public class ChonTuyChon : ContentView
{
    private readonly FlexLayout _nhan = new() { Wrap = Microsoft.Maui.Layouts.FlexWrap.Wrap, Direction = Microsoft.Maui.Layouts.FlexDirection.Row };
    private readonly VerticalStackLayout _gia = new() { Spacing = 6 };
    private readonly List<(string Ten, decimal Gia)> _mau = new();
    private readonly Dictionary<string, decimal> _chon = new(StringComparer.OrdinalIgnoreCase);
    private readonly List<string> _thuTu = new();
    private bool _coGia = true;
    private readonly Dictionary<string, Label> _lblBan = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>Nếu có: hiện thêm dòng "Giá bán" (= giá món + phụ phí) dưới từng mục để quán thấy ngay giá khách trả. Dùng cho Size.</summary>
    public Func<decimal>? GiaGoc { get; set; }

    /// <summary>Tính lại dòng "Giá bán" của từng mục (gọi khi quán đổi giá món).</summary>
    public void CapNhatGiaBan()
    {
        if (GiaGoc is null) return;
        var goc = GiaGoc();
        foreach (var (ten, lbl) in _lblBan)
            lbl.Text = goc <= 0 ? "Nhập giá món ở trên để xem giá bán"
                : $"Giá bán: {goc + (_chon.TryGetValue(ten, out var pp) ? pp : 0):N0}đ";
    }

    public ChonTuyChon()
    {
        Content = new VerticalStackLayout { Spacing = 8, Children = { _nhan, _gia } };
    }

    /// <summary>Đặt danh sách mẫu (tên, phụ phí gợi ý). coGia=false: không hiện ô phụ phí (vd mức cay).</summary>
    public void DatMau(IEnumerable<(string Ten, decimal Gia)> mau, bool coGia = true)
    {
        _mau.Clear(); _mau.AddRange(mau); _coGia = coGia;
        Ve();
    }

    public void Dat(IEnumerable<(string Ten, decimal Gia)> ds)
    {
        _chon.Clear(); _thuTu.Clear();
        foreach (var (ten, gia) in ds)
        {
            if (string.IsNullOrWhiteSpace(ten) || _chon.ContainsKey(ten.Trim())) continue;
            _chon[ten.Trim()] = gia; _thuTu.Add(ten.Trim());
            if (!_mau.Any(m => string.Equals(m.Ten, ten.Trim(), StringComparison.OrdinalIgnoreCase)))
                _mau.Add((ten.Trim(), gia));   // lựa chọn cũ không có trong mẫu vẫn hiện để bỏ chọn được
        }
        Ve();
    }

    public List<(string Ten, decimal Gia)> Lay() => _thuTu.Where(_chon.ContainsKey).Select(t => (t, _chon[t])).ToList();

    private void Ve()
    {
        _nhan.Children.Clear();
        foreach (var (ten, giaGoiY) in _mau)
        {
            var dangChon = _chon.ContainsKey(ten);
            var ten0 = ten; var gia0 = giaGoiY;
            var chip = new Border
            {
                Margin = new Thickness(0, 0, 8, 8), Padding = new Thickness(14, 8), StrokeThickness = 1,
                Stroke = Color.FromArgb(dangChon ? "#5B3FD9" : "#C9C2F0"),
                BackgroundColor = Color.FromArgb(dangChon ? "#5B3FD9" : "#EEEBFF"),
                StrokeShape = new RoundRectangle { CornerRadius = new CornerRadius(16) },
                Content = new Label { Text = (dangChon ? "✓ " : "") + ten, FontSize = 13, FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb(dangChon ? "#FFFFFF" : "#14193A") }
            };
            SemanticProperties.SetDescription(chip, (dangChon ? "Đã chọn " : "Chưa chọn ") + ten);
            chip.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(() => BatTat(ten0, gia0)) });
            _nhan.Children.Add(chip);
        }
        var them = new Border
        {
            Margin = new Thickness(0, 0, 8, 8), Padding = new Thickness(14, 8), StrokeThickness = 1, Stroke = Color.FromArgb("#F97316"),
            BackgroundColor = Color.FromArgb("#FFF1E2"), StrokeShape = new RoundRectangle { CornerRadius = new CornerRadius(16) },
            Content = new Label { Text = "＋ Thêm", FontSize = 13, FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb("#14193A") }
        };
        them.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => await ThemAsync()) });
        _nhan.Children.Add(them);
        VeGia();
    }

    private void BatTat(string ten, decimal giaGoiY)
    {
        if (_chon.Remove(ten)) _thuTu.Remove(ten);
        else { _chon[ten] = giaGoiY; _thuTu.Add(ten); }
        Ve();
    }

    private async Task ThemAsync()
    {
        var page = Shell.Current;
        if (page is null) return;
        var ten = (await page.NhapAsync("Thêm lựa chọn", "Tên lựa chọn", "Thêm", "Hủy", "VD: Thêm trứng", maxLength: 40))?.Trim();
        if (string.IsNullOrEmpty(ten)) return;
        if (!_mau.Any(m => string.Equals(m.Ten, ten, StringComparison.OrdinalIgnoreCase))) _mau.Add((ten, 0));
        var goc = _mau.First(m => string.Equals(m.Ten, ten, StringComparison.OrdinalIgnoreCase));
        if (!_chon.ContainsKey(goc.Ten)) { _chon[goc.Ten] = goc.Gia; _thuTu.Add(goc.Ten); }
        Ve();
    }

    private void VeGia()
    {
        _gia.Children.Clear();
        _lblBan.Clear();
        if (!_coGia) return;
        foreach (var ten in _thuTu.Where(_chon.ContainsKey).ToList())
        {
            var t = ten;
            var o = new Entry
            {
                Keyboard = Keyboard.Numeric, MaxLength = 7, WidthRequest = 110, HorizontalTextAlignment = TextAlignment.End,
                Placeholder = "0", Text = _chon[t] > 0 ? ((long)_chon[t]).ToString() : "",
            };
            SemanticProperties.SetDescription(o, "Phụ phí của " + ten);
            o.TextChanged += (_, e) =>
            {
                var so = new string((e.NewTextValue ?? "").Where(char.IsDigit).ToArray());
                _chon[t] = so.Length == 0 ? 0 : decimal.Parse(so);
                CapNhatGiaBan();
            };
            var dong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 8 };
            var tenCot = new VerticalStackLayout { Spacing = 1, VerticalOptions = LayoutOptions.Center };
            tenCot.Children.Add(new Label { Text = ten, FontSize = 13.5, FontAttributes = FontAttributes.Bold });
            if (GiaGoc is not null)
            {
                var lblBan = new Label { FontSize = 11.5, TextColor = Color.FromArgb("#5B3FD9") };
                _lblBan[t] = lblBan;
                tenCot.Children.Add(lblBan);
            }
            dong.Add(tenCot, 0);
            dong.Add(new Label { Text = GiaGoc is null ? "Phụ phí" : "+ Phụ phí", FontSize = 12, TextColor = Color.FromArgb("#6B7280"), VerticalOptions = LayoutOptions.Center }, 1);
            var cot = new HorizontalStackLayout { Spacing = 4, Children = { o, new Label { Text = "đ", VerticalOptions = LayoutOptions.Center } } };
            dong.Add(cot, 2);
            _gia.Children.Add(dong);
        }
        CapNhatGiaBan();
    }
}
