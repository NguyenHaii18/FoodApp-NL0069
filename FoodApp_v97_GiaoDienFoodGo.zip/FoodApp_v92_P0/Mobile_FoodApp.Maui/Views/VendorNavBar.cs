namespace FoodApp.Maui.Views;

/// <summary>
/// Thanh tab dưới của khu Gian hàng (Trang chủ · Đơn hàng · Món ăn · Doanh thu · Cá nhân).
/// Các trang này được mở bằng điều hướng đẩy trang, nên khi chuyển tab ta quay về Trang chủ rồi mới mở trang đích
/// để ngăn xếp điều hướng không phình ra.
/// </summary>
public class VendorNavBar : ContentView
{
    private static readonly (string Khoa, string Icon, string Nhan, string Route)[] Muc5 =
    {
        ("home", "🏠", "Trang chủ", nameof(VendorHomePage)),
        ("orders", "🧾", "Đơn hàng", nameof(VendorOrdersPage)),
        ("menu", "🍲", "Món ăn", nameof(VendorMenuPage)),
        ("revenue", "📊", "Doanh thu", nameof(VendorRevenuePage)),
        ("profile", "👤", "Cá nhân", nameof(VendorProfilePage)),
    };

    private string _muc = "";
    public string Muc { get => _muc; set { _muc = value; Ve(); } }

    public VendorNavBar() => Ve();

    private void Ve()
    {
        var luoi = new Grid { Padding = new Thickness(4, 6, 4, 8) };
        luoi.SetAppThemeColor(BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
        for (int i = 0; i < Muc5.Length; i++)
        {
            var (khoa, icon, nhan, route) = Muc5[i];
            var chon = khoa == _muc;
            luoi.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));

            var vien = new Border
            {
                WidthRequest = 48, HeightRequest = 28, StrokeThickness = 0, HorizontalOptions = LayoutOptions.Center,
                BackgroundColor = chon ? VendorPalette.Get("PrimarySoft") : Colors.Transparent,
                StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(14) },
                Content = new Label { Text = icon, FontSize = 17, TextColor = Colors.Black, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center },
            };
            var chu = new Label
            {
                Text = nhan, FontSize = 10.5, HorizontalOptions = LayoutOptions.Center,
                FontAttributes = chon ? FontAttributes.Bold : FontAttributes.None,
            };
            if (chon) chu.TextColor = VendorPalette.Get("Primary");
            else chu.SetAppThemeColor(Label.TextColorProperty, VendorPalette.Get("TextGrey"), Color.FromArgb("#CFC6EA"));

            var o = new VerticalStackLayout { Spacing = 2, BackgroundColor = Colors.Transparent, Children = { vien, chu } };
            o.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => await DiToiAsync(route)) });
            luoi.Add(o, i);
        }

        var duongKe = new BoxView { HeightRequest = 1, VerticalOptions = LayoutOptions.Start, Color = VendorPalette.Get("BorderColor") };
        Content = new Grid { Children = { luoi, duongKe } };
    }

    private static async Task DiToiAsync(string route)
    {
        var shell = Shell.Current;
        if (shell?.CurrentPage?.GetType().Name == route) return;

        var nav = shell!.Navigation;
        if (nav.NavigationStack.Any(p => p is VendorHomePage))
        {
            while (nav.NavigationStack.Count > 1 && nav.NavigationStack[^1] is { } top && top is not VendorHomePage)
                await nav.PopAsync(false);
        }
        if (route != nameof(VendorHomePage)) await shell.GoToAsync(route);
    }
}
