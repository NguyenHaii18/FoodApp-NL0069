using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Trung tâm vận hành của quản trị: cảnh báo hệ thống, theo dõi SLA, phát hiện gian lận, báo cáo lợi nhuận, kiểm duyệt đánh giá.
/// Dữ liệu thật từ api/admin/van-hanh/* (cần đăng nhập quản trị với máy chủ).
/// </summary>
public partial class AdminVanHanhPage : ContentPage
{
    private static readonly string[] TenTab = { "🚨 Cảnh báo", "⏱ SLA", "🕵 Gian lận", "💰 Lợi nhuận", "⭐ Đánh giá" };
    private const string Goc = "api/admin/van-hanh/";
    private int _tab;
    private int _soNgay = 30;

    public AdminVanHanhPage()
    {
        InitializeComponent();
        DungTab();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await NapAsync();
    }

    private async void OnRefreshing(object? sender, EventArgs e)
    {
        await NapAsync();
        LamMoi.IsRefreshing = false;
    }

    // ---------- giao diện dùng chung ----------
    private static void MauChu(Label l, bool xam)
    {
        if (xam) l.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#6B7280"), Color.FromArgb("#9CA3AF"));
    }

    private static Label Chu(string text, double size = 13.5, bool dam = false, bool xam = false)
    {
        var l = new Label { Text = text, FontSize = size, FontAttributes = dam ? FontAttributes.Bold : FontAttributes.None };
        MauChu(l, xam);
        return l;
    }

    private static Frame The(View noiDung, string? vien = null)
    {
        var f = new Frame { Content = noiDung, Padding = new Thickness(14, 10), CornerRadius = 14, HasShadow = false, Margin = new Thickness(0, 0, 0, 8) };
        f.SetAppThemeColor(Microsoft.Maui.Controls.Frame.BackgroundColorProperty, Colors.White, Color.FromArgb("#1B2430"));
        if (vien != null) f.BorderColor = Color.FromArgb(vien);
        else f.SetAppThemeColor(Microsoft.Maui.Controls.Frame.BorderColorProperty, Color.FromArgb("#E5E7EB"), Color.FromArgb("#2F3B4A"));
        return f;
    }

    private static View Dong(string nhan, string giaTri, bool dam = false)
    {
        var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 10 };
        var a = Chu(nhan, 13, false, true);
        var b = Chu(giaTri, 13.5, dam);
        b.HorizontalTextAlignment = TextAlignment.End;
        g.Add(a, 0); g.Add(b, 1);
        return g;
    }

    private static Label TieuDeMuc(string text)
    {
        var l = Chu(text, 15, true);
        l.Margin = new Thickness(0, 8, 0, 6);
        return l;
    }

    private void Trong(string text)
    {
        var l = Chu(text, 13, false, true);
        l.HorizontalTextAlignment = TextAlignment.Center;
        l.Margin = new Thickness(0, 24);
        Noi.Children.Add(l);
    }

    private void DungTab()
    {
        Tabs.Children.Clear();
        for (var i = 0; i < TenTab.Length; i++)
        {
            var idx = i;
            var chon = idx == _tab;
            var b = new Button { Text = TenTab[i], FontSize = 13, Padding = new Thickness(14, 0), HeightRequest = 38, CornerRadius = 19 };
            if (chon) { b.BackgroundColor = Color.FromArgb("#4F46E5"); b.TextColor = Colors.White; }
            else
            {
                b.SetAppThemeColor(Button.BackgroundColorProperty, Color.FromArgb("#EEF2FF"), Color.FromArgb("#2A2F4A"));
                b.SetAppThemeColor(Button.TextColorProperty, Color.FromArgb("#4F46E5"), Color.FromArgb("#A5B4FC"));
            }
            b.Clicked += async (_, _) => { _tab = idx; DungTab(); await NapAsync(); };
            Tabs.Children.Add(b);
        }
    }

    private void BaoTrangThai(string? text)
    {
        LblTrangThai.IsVisible = !string.IsNullOrEmpty(text);
        LblTrangThai.Text = text ?? "";
        LblTrangThai.TextColor = Color.FromArgb("#DC2626");
    }

    private async Task NapAsync()
    {
        BaoTrangThai(null);
        Noi.Children.Clear();
        if (string.IsNullOrEmpty(ApiClient.Token))
        {
            BaoTrangThai("Cần đăng nhập quản trị với máy chủ để xem dữ liệu vận hành thật.");
            return;
        }
        try
        {
            switch (_tab)
            {
                case 0: await HienCanhBaoAsync(); break;
                case 1: await HienSlaAsync(); break;
                case 2: await HienGianLanAsync(); break;
                case 3: await HienLoiNhuanAsync(); break;
                default: await HienDanhGiaAsync(); break;
            }
        }
        catch (Exception ex) { CrashLog.Ghi("AdminVanHanh", ex); BaoTrangThai("Không tải được dữ liệu, vui lòng thử lại."); }
    }

    private bool Loi<T>(ApiKetQua<T> r)
    {
        if (r.ThanhCong && r.DuLieu is not null) return false;
        BaoTrangThai(r.MatKetNoi || string.IsNullOrWhiteSpace(r.ThongDiep) ? "Không kết nối được máy chủ." : r.ThongDiep);
        return true;
    }

    // ---------- 1. Cảnh báo ----------
    private async Task HienCanhBaoAsync()
    {
        var r = await ApiClient.GetAsync<VhCanhBaoRes>(Goc + "canh-bao");
        if (Loi(r)) return;
        var d = r.DuLieu!;
        if (d.CanhBao.Count == 0) { Noi.Children.Add(The(Chu("✅ Hệ thống ổn định, không có cảnh báo nào.", 14, true), "#16A34A")); return; }
        foreach (var c in d.CanhBao)
        {
            var loi = c.Muc == "Error";
            var cot = new VerticalStackLayout { Spacing = 2 };
            cot.Children.Add(Chu((loi ? "🔴 " : "🟠 ") + c.TieuDe, 14, true));
            cot.Children.Add(Chu(c.MoTa, 12.5, false, true));
            Noi.Children.Add(The(cot, loi ? "#DC2626" : "#E99A22"));
        }
        Noi.Children.Add(Chu($"Cập nhật lúc {d.CapNhatLuc:HH:mm dd/MM}", 11, false, true));
    }

    // ---------- 2. SLA ----------
    private async Task HienSlaAsync()
    {
        var r = await ApiClient.GetAsync<VhSlaRes>(Goc + "sla");
        if (Loi(r)) return;
        var d = r.DuLieu!;
        var tong = new VerticalStackLayout { Spacing = 4 };
        tong.Children.Add(Dong("Giao đúng hạn 7 ngày", d.TyLeDungHan7Ngay is double t ? $"{t:P0}" : "—", true));
        tong.Children.Add(Dong("Thời gian giao trung bình", d.ThoiGianGiaoTrungBinhPhut is double tb ? $"{tb:N0} phút" : "—"));
        tong.Children.Add(Dong("Đơn đã giao (7 ngày)", d.SoDonDaGiao7Ngay.ToString()));
        tong.Children.Add(Chu($"Ngưỡng: quán xác nhận ≤ {d.Nguong.XacNhanPhut}′, tìm tài xế ≤ {d.Nguong.TimTaiXePhut}′, giao ≤ {d.Nguong.GiaoPhut}′", 11.5, false, true));
        Noi.Children.Add(The(tong));

        MucSla("Quán chậm xác nhận", d.QuanChamXacNhan);
        MucSla("Chưa có tài xế nhận", d.ChuaCoTaiXe);
        MucSla("Giao trễ", d.GiaoTre);
    }

    private void MucSla(string tieuDe, List<VhDongSla> ds)
    {
        Noi.Children.Add(TieuDeMuc($"{tieuDe} ({ds.Count})"));
        if (ds.Count == 0) { Noi.Children.Add(The(Chu("Không có đơn vi phạm.", 13, false, true))); return; }
        foreach (var x in ds)
        {
            var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 10 };
            var cot = new VerticalStackLayout { Spacing = 1 };
            cot.Children.Add(Chu($"Đơn #{x.MaDonHang}", 13.5, true));
            cot.Children.Add(Chu(x.TenQuan, 12, false, true));
            var p = Chu($"{x.Phut} phút", 13.5, true);
            p.TextColor = Color.FromArgb("#DC2626"); p.VerticalOptions = LayoutOptions.Center;
            g.Add(cot, 0); g.Add(p, 1);
            Noi.Children.Add(The(g));
        }
    }

    // ---------- 3. Gian lận ----------
    private async Task HienGianLanAsync()
    {
        var r = await ApiClient.GetAsync<VhGianLanRes>(Goc + "gian-lan");
        if (Loi(r)) return;
        var d = r.DuLieu!;
        Noi.Children.Add(Chu($"Kỳ xét: {d.KyXet} · {d.Tong} dấu hiệu", 12, false, true));
        if (d.CanhBao.Count == 0) { Noi.Children.Add(The(Chu("✅ Chưa phát hiện hành vi đáng ngờ.", 14, true), "#16A34A")); return; }
        Noi.Children.Add(new BoxView { HeightRequest = 6, Color = Colors.Transparent });
        foreach (var x in d.CanhBao)
        {
            var ten = x.Loai switch
            {
                "HuyNhieu" => "Hủy đơn nhiều",
                "LamDungVoucher" => "Lạm dụng voucher",
                "HoanTienDangNgo" => "Hoàn tiền đáng ngờ",
                "SaiMaNhanHang" => "Sai mã nhận hàng",
                "DonBatThuong" => "Đơn giá trị bất thường",
                _ => x.Loai,
            };
            var cot = new VerticalStackLayout { Spacing = 2 };
            cot.Children.Add(Chu($"{(x.Muc == "Cao" ? "🔴" : "🟠")} {ten} — mức {x.Muc.ToLowerInvariant()}", 14, true));
            cot.Children.Add(Chu($"{x.TenKH}" + (x.MaKH is int k ? $" (#{k})" : ""), 13, true));
            cot.Children.Add(Chu(x.MoTa, 12.5, false, true));
            Noi.Children.Add(The(cot, x.Muc == "Cao" ? "#DC2626" : "#E99A22"));
        }
        Noi.Children.Add(Chu("Đây chỉ là dấu hiệu để rà soát, chưa phải kết luận vi phạm.", 11, false, true));
    }

    // ---------- 4. Lợi nhuận ----------
    private async Task HienLoiNhuanAsync()
    {
        var chon = new HorizontalStackLayout { Spacing = 8, Margin = new Thickness(0, 0, 0, 8) };
        foreach (var n in new[] { 7, 30, 90 })
        {
            var so = n;
            var b = new Button { Text = $"{so} ngày", FontSize = 12.5, HeightRequest = 34, Padding = new Thickness(12, 0), CornerRadius = 17 };
            if (so == _soNgay) { b.BackgroundColor = Color.FromArgb("#4F46E5"); b.TextColor = Colors.White; }
            else
            {
                b.SetAppThemeColor(Button.BackgroundColorProperty, Color.FromArgb("#EEF2FF"), Color.FromArgb("#2A2F4A"));
                b.SetAppThemeColor(Button.TextColorProperty, Color.FromArgb("#4F46E5"), Color.FromArgb("#A5B4FC"));
            }
            b.Clicked += async (_, _) => { _soNgay = so; await NapAsync(); };
            chon.Children.Add(b);
        }
        Noi.Children.Add(chon);

        var den = DateTime.Today; var tu = den.AddDays(-(_soNgay - 1));
        var r = await ApiClient.GetAsync<VhLoiNhuanRes>($"{Goc}loi-nhuan?tuNgay={tu:yyyy-MM-dd}&denNgay={den:yyyy-MM-dd}");
        if (Loi(r)) return;
        var d = r.DuLieu!;

        var kpi = new VerticalStackLayout { Spacing = 6 };
        kpi.Children.Add(Chu("Lợi nhuận ước tính", 12.5, false, true));
        var ln = Chu($"{d.LoiNhuanUocTinh:N0}đ", 26, true);
        ln.TextColor = Color.FromArgb(d.LoiNhuanUocTinh >= 0 ? "#16A34A" : "#DC2626");
        kpi.Children.Add(ln);
        kpi.Children.Add(Chu($"{d.TuNgay:dd/MM} – {d.DenNgay:dd/MM/yyyy} · {d.SoDonDaGiao} đơn đã giao", 11.5, false, true));
        Noi.Children.Add(The(kpi));

        var ct = new VerticalStackLayout { Spacing = 6 };
        ct.Children.Add(Dong("Doanh thu (tổng tiền các đơn)", $"{d.DoanhThu:N0}đ", true));
        ct.Children.Add(Dong("  Tiền hàng", $"{d.TienHang:N0}đ"));
        ct.Children.Add(Dong("  Phí giao hàng (của tài xế)", $"{d.PhiGiaoHang:N0}đ"));
        ct.Children.Add(new BoxView { HeightRequest = 1, Color = Color.FromArgb("#9CA3AF"), Opacity = 0.35 });
        ct.Children.Add(Dong("Phí nền tảng thu được", $"+ {d.PhiNenTang:N0}đ", true));
        ct.Children.Add(Dong("Chi phí ưu đãi", $"− {d.ChiPhiUuDai:N0}đ"));
        ct.Children.Add(Dong("Tiền hoàn cho khách", $"− {d.SoTienHoan:N0}đ"));
        Noi.Children.Add(The(ct));
        Noi.Children.Add(Chu(d.GhiChu, 11, false, true));
    }

    // ---------- 5. Kiểm duyệt đánh giá ----------
    private async Task HienDanhGiaAsync()
    {
        var r = await ApiClient.GetAsync<VhDanhGiaRes>(Goc + "danh-gia-nghi-van");
        if (Loi(r)) return;
        var d = r.DuLieu!;
        if (d.DanhGia.Count == 0) { Noi.Children.Add(The(Chu("✅ Không có đánh giá nghi vấn.", 14, true), "#16A34A")); return; }
        foreach (var x in d.DanhGia)
        {
            var cot = new VerticalStackLayout { Spacing = 3 };
            cot.Children.Add(Chu($"{new string('★', Math.Clamp(x.SoSao, 0, 5))}  {x.TenQuan}", 14, true));
            cot.Children.Add(Chu($"{x.TenKH} · {x.Ngay:dd/MM HH:mm}", 12, false, true));
            cot.Children.Add(Chu(string.IsNullOrWhiteSpace(x.NoiDung) ? "(không có nội dung)" : x.NoiDung, 13));
            var ly = Chu("⚠ " + x.LyDo, 12.5, true); ly.TextColor = Color.FromArgb("#E99A22");
            cot.Children.Add(ly);
            var an = new Button { Text = "Ẩn đánh giá", FontSize = 12.5, HeightRequest = 34, CornerRadius = 17, BackgroundColor = Color.FromArgb("#DC2626"), TextColor = Colors.White, HorizontalOptions = LayoutOptions.Start, Padding = new Thickness(14, 0) };
            var ma = x.MaDanhGia;
            an.Clicked += async (_, _) => await AnAsync(ma, x.LyDo);
            cot.Children.Add(an);
            Noi.Children.Add(The(cot));
        }
    }

    private async Task AnAsync(int maDanhGia, string lyDo)
    {
        if (!await DisplayAlert("Ẩn đánh giá", $"Ẩn đánh giá này khỏi quán và khách hàng?\nLý do: {lyDo}", "Ẩn", "Hủy")) return;
        var r = await ApiClient.PostAsync<object>($"{Goc}danh-gia/{maDanhGia}/an", new { lyDo });
        if (!r.ThanhCong) { await DisplayAlert("Không ẩn được", string.IsNullOrWhiteSpace(r.ThongDiep) ? "Vui lòng thử lại." : r.ThongDiep, "Đóng"); return; }
        await NapAsync();
    }
}

// ---- DTO khớp JSON của AdminVanHanhApiController ----
public class VhCanhBaoRes { public DateTime CapNhatLuc { get; set; } public int SoCanhBao { get; set; } public List<VhCanhBao> CanhBao { get; set; } = new(); }
public class VhCanhBao { public string Muc { get; set; } = ""; public string TieuDe { get; set; } = ""; public string MoTa { get; set; } = ""; public int SoLuong { get; set; } }
public class VhSlaNguong { public int XacNhanPhut { get; set; } public int TimTaiXePhut { get; set; } public int GiaoPhut { get; set; } }
public class VhDongSla { public int MaDonHang { get; set; } public string TenQuan { get; set; } = ""; public int Phut { get; set; } public string TrangThai { get; set; } = ""; }
public class VhSlaRes
{
    public VhSlaNguong Nguong { get; set; } = new();
    public double? TyLeDungHan7Ngay { get; set; }
    public int SoDonDaGiao7Ngay { get; set; }
    public double? ThoiGianGiaoTrungBinhPhut { get; set; }
    public List<VhDongSla> QuanChamXacNhan { get; set; } = new();
    public List<VhDongSla> ChuaCoTaiXe { get; set; } = new();
    public List<VhDongSla> GiaoTre { get; set; } = new();
}
public class VhGianLan { public string Loai { get; set; } = ""; public string Muc { get; set; } = ""; public int? MaKH { get; set; } public string TenKH { get; set; } = ""; public int SoLan { get; set; } public string MoTa { get; set; } = ""; public int? MaDonHang { get; set; } }
public class VhGianLanRes { public string KyXet { get; set; } = ""; public int Tong { get; set; } public List<VhGianLan> CanhBao { get; set; } = new(); }
public class VhLoiNhuanRes
{
    public DateTime TuNgay { get; set; } public DateTime DenNgay { get; set; } public int SoDonDaGiao { get; set; }
    public decimal DoanhThu { get; set; } public decimal TienHang { get; set; } public decimal PhiGiaoHang { get; set; }
    public decimal PhiNenTang { get; set; } public decimal ChiPhiUuDai { get; set; } public decimal SoTienHoan { get; set; }
    public decimal LoiNhuanUocTinh { get; set; } public string GhiChu { get; set; } = "";
}
public class VhDanhGia { public int MaDanhGia { get; set; } public int? MaKH { get; set; } public string TenKH { get; set; } = ""; public string TenQuan { get; set; } = ""; public int SoSao { get; set; } public string NoiDung { get; set; } = ""; public string LyDo { get; set; } = ""; public DateTime Ngay { get; set; } }
public class VhDanhGiaRes { public int Tong { get; set; } public List<VhDanhGia> DanhGia { get; set; } = new(); }
