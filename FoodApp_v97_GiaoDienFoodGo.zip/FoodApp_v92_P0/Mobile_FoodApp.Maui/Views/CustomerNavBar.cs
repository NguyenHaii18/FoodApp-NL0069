namespace FoodApp.Maui.Views;

/// <summary>
/// Thanh tab dưới của khách hàng (Trang chủ · Đơn hàng · Ưu đãi · Tài khoản) dùng trên Windows,
/// nơi Shell mặc định đặt tab ở phía TRÊN. Trên Android/iOS vẫn dùng tab dưới gốc của Shell nên thanh này không hiện.
/// </summary>
public class CustomerNavBar : ContentView
{
    private static readonly (string Khoa, string Icon, string Nhan, string Route)[] Muc =
    {
        ("home", "🏠", "Trang chủ", "//chinh/trang-chu"),
        ("orders", "🧾", "Đơn hàng", "//chinh/don-hang"),
        ("promo", "🎁", "Ưu đãi", "//chinh/uu-dai"),
        ("account", "👤", "Tài khoản", "//chinh/tai-khoan"),
    };

    private readonly string _chon;

    public CustomerNavBar(string chon)
    {
        _chon = chon;
        var luoi = new Grid { Padding = new Thickness(4, 6, 4, 8) };
        luoi.SetAppThemeColor(BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
        for (int i = 0; i < Muc.Length; i++)
        {
            var (khoa, icon, nhan, route) = Muc[i];
            var dangChon = khoa == _chon;
            luoi.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));

            var vien = new Border
            {
                WidthRequest = 56, HeightRequest = 30, StrokeThickness = 0, HorizontalOptions = LayoutOptions.Center,
                BackgroundColor = dangChon ? Color.FromArgb("#F3EEFF") : Colors.Transparent,
                StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(15) },
                Content = new Label { Text = icon, FontSize = 18, TextColor = Colors.Black, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center },
            };
            var chu = new Label
            {
                Text = nhan, FontSize = 11, HorizontalOptions = LayoutOptions.Center,
                FontAttributes = dangChon ? FontAttributes.Bold : FontAttributes.None,
            };
            if (dangChon) chu.TextColor = Color.FromArgb("#6D28D9");
            else chu.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#6B6485"), Color.FromArgb("#CFC6EA"));

            var o = new VerticalStackLayout { Spacing = 2, BackgroundColor = Colors.Transparent, Children = { vien, chu } };
            o.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => await DiToiAsync(route, dangChon)) });
            luoi.Add(o, i);
        }
        var duongKe = new BoxView { HeightRequest = 1, VerticalOptions = LayoutOptions.Start, Color = Color.FromArgb("#E7E0F7") };
        Content = new Grid { Children = { luoi, duongKe } };
    }

    private static async Task DiToiAsync(string route, bool dangO)
    {
        if (dangO || Shell.Current is null) return;
        await Shell.Current.GoToAsync(route);
    }

    /// <summary>Gắn thanh tab dưới vào cuối trang (chỉ trên Windows). Gọi ngay sau InitializeComponent().</summary>
    public static void Gan(ContentPage trang, string chon)
    {
        if (DeviceInfo.Platform != DevicePlatform.WinUI) return;
        var cu = trang.Content;
        if (cu is null) return;
        trang.Content = null;
        var goc = new Grid { RowDefinitions = { new RowDefinition(GridLength.Star), new RowDefinition(GridLength.Auto) } };
        goc.Add(cu, 0, 0);
        goc.Add(new CustomerNavBar(chon), 0, 1);
        trang.Content = goc;
    }
}
