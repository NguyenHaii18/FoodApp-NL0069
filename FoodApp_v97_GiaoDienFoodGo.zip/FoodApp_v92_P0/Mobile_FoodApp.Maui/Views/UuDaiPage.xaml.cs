using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Tab "Ưu đãi": mã giảm giá đang dùng được (toàn hệ thống + của từng nhà hàng), chạm "Sao chép" để lấy mã.</summary>
public partial class UuDaiPage : ContentPage
{
    private string _loc = "";   // "" = tất cả | HeThong | NhaHang

    public UuDaiPage() { InitializeComponent(); CustomerNavBar.Gan(this, "promo"); }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        VeThanhLoc();
        Nap();
    }

    private Color Mau(string k) => (Color)Resources[k];

    private static List<KhuyenMai> DangDung() => MockData.DanhSachKhuyenMai
        .Where(k => k.DangHoatDong && k.ConHan && !k.ChuaBatDau && k.ConLuot)
        .OrderByDescending(k => k.ApDungToanHeThong).ThenBy(k => k.NgayKetThuc).ToList();

    private void VeThanhLoc()
    {
        ThanhLoc.Children.Clear();
        foreach (var (khoa, nhan) in new[] { ("", "Tất cả"), ("HeThong", "Toàn hệ thống"), ("NhaHang", "Của nhà hàng"), ("CuaToi", "Của tôi") })
        {
            var chon = khoa == _loc;
            var nut = new Button
            {
                Text = nhan, CornerRadius = 17, HeightRequest = 34, Padding = new Thickness(16, 0), FontSize = 12.5,
                BackgroundColor = chon ? Mau("Primary") : Mau("PrimarySoft"),
                TextColor = chon ? Colors.White : Mau("Primary"),
            };
            nut.Clicked += (_, _) => { _loc = khoa; VeThanhLoc(); Nap(); };
            ThanhLoc.Children.Add(nut);
        }
    }

    private void Nap()
    {
        var tat = DangDung();
        LblSoMa.Text = tat.Count > 0 ? $"{tat.Count} mã đang dùng được" : "Mã giảm giá từ FoodApp và nhà hàng";
        var ds = tat.Where(k => _loc == "" || (_loc == "HeThong" ? k.ApDungToanHeThong : _loc == "CuaToi" ? VoucherCuaToiService.DaNhan(k.MaCode) : !k.ApDungToanHeThong)).ToList();
        VeSinhNhat();
        if (_loc == "CuaToi") LblTrong.Text = "Bạn chưa nhận voucher nào (hoặc voucher đã nhận không còn dùng được)";
        else LblTrong.Text = "Hiện chưa có ưu đãi nào dùng được";
        DsUuDai.Children.Clear();
        LblTrong.IsVisible = ds.Count == 0;
        foreach (var km in ds) DsUuDai.Children.Add(VeThe(km));
    }

    private View VeThe(KhuyenMai km)
    {
        var gh = km.ApDungToanHeThong ? null : MockData.DanhSachGianHang.FirstOrDefault(g => g.Id == km.GianHangId);
        var icon = gh?.HinhAnh ?? "🎫";

        var anh = new Border
        {
            WidthRequest = 64, HeightRequest = 64, StrokeThickness = 0, BackgroundColor = Mau("PrimarySoft"), VerticalOptions = LayoutOptions.Center,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(14) },
            Content = new Label { Text = icon, FontSize = 30, TextColor = Colors.Black, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center },
        };

        var thongTin = new VerticalStackLayout { Spacing = 2, VerticalOptions = LayoutOptions.Center };
        thongTin.Children.Add(new Label { Text = gh?.TenGianHang ?? "FoodApp", FontAttributes = FontAttributes.Bold, FontSize = 14, LineBreakMode = LineBreakMode.TailTruncation });
        thongTin.Children.Add(new Label { Text = $"{km.GiaTriGiamHienThi} · {km.TenChuongTrinh}", FontSize = 12.5, TextColor = Mau("Primary"), FontAttributes = FontAttributes.Bold, LineBreakMode = LineBreakMode.TailTruncation });
        thongTin.Children.Add(new Label { Text = $"Đơn từ {km.GiaTriDonToiThieu:N0}đ · HSD: {km.NgayKetThuc:dd/MM/yyyy}", FontSize = 11, TextColor = Mau("TextGrey") });

        var nut = new Border
        {
            BackgroundColor = Colors.Transparent, Stroke = Mau("Primary"), StrokeThickness = 1, Padding = new Thickness(12, 5), VerticalOptions = LayoutOptions.End,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(12) },
            Content = new Label { Text = "Sao chép", TextColor = Mau("Primary"), FontSize = 11.5, FontAttributes = FontAttributes.Bold },
        };
        nut.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => await SaoChepAsync(km)) });

        var daNhan = VoucherCuaToiService.DaNhan(km.MaCode);
        var nutNhan = new Border
        {
            BackgroundColor = daNhan ? Mau("PrimarySoft") : Mau("Primary"), StrokeThickness = 0, Padding = new Thickness(12, 5),
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(12) },
            Content = new Label { Text = daNhan ? "✓ Đã nhận" : "Nhận", TextColor = daNhan ? Mau("Primary") : Colors.White, FontSize = 11.5, FontAttributes = FontAttributes.Bold },
        };
        nutNhan.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(() =>
        {
            if (VoucherCuaToiService.DaNhan(km.MaCode)) VoucherCuaToiService.Bo(km.MaCode); else VoucherCuaToiService.Nhan(km.MaCode);
            Nap();
        }) });
        var nutCot = new VerticalStackLayout { Spacing = 6, VerticalOptions = LayoutOptions.End };
        nutCot.Children.Add(nutNhan); nutCot.Children.Add(nut);

        var hang = new Grid { ColumnSpacing = 12, ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        hang.Add(anh, 0); hang.Add(thongTin, 1); hang.Add(nutCot, 2);

        var the = new Border
        {
            Padding = new Thickness(12), StrokeThickness = 1, Stroke = Mau("BorderColor"), Content = hang,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(16) },
        };
        the.SetAppThemeColor(Border.BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
        return the;
    }

    private async Task SaoChepAsync(KhuyenMai km)
    {
        bool daSao = await FoodApp.Maui.Services.ClipboardAnToan.SaoChepAsync(km.MaCode);
        await DisplayAlert(daSao ? "Đã sao chép mã " + km.MaCode : "Mã " + km.MaCode, daSao ? "Dán mã vào ô khuyến mãi khi thanh toán." : "Không sao chép tự động được. Hãy nhập mã này thủ công khi thanh toán.", "OK");
    }

    /// <summary>Nhập mã khuyến mãi → nhận vào "Voucher của tôi" nếu mã tồn tại và còn dùng được.</summary>
    private async void OnNhanMaClicked(object? sender, EventArgs e)
    {
        var ma = EntryNhapMa.Text?.Trim();
        if (string.IsNullOrEmpty(ma)) return;
        var km = MockData.DanhSachKhuyenMai.FirstOrDefault(k => string.Equals(k.MaCode, ma, StringComparison.OrdinalIgnoreCase));
        if (km is null) { await DisplayAlert("Không nhận được mã", "Mã không tồn tại. Voucher đổi từ điểm thưởng thì nhập trực tiếp ở bước thanh toán.", "OK"); return; }
        if (!km.DangHoatDong || km.ChuaBatDau || !km.ConHan || !km.ConLuot) { await DisplayAlert("Không nhận được mã", $"Mã {km.MaCode}: {km.TrangThaiHienThi.ToLowerInvariant()}.", "OK"); return; }
        if (VoucherCuaToiService.DaNhan(km.MaCode)) { await DisplayAlert("Đã nhận rồi", $"Mã {km.MaCode} đã có trong “Của tôi”.", "OK"); return; }
        VoucherCuaToiService.Nhan(km.MaCode);
        EntryNhapMa.Text = "";
        Nap();
        await DisplayAlert("Đã nhận voucher", $"{km.MaCode} · {km.GiaTriGiamHienThi}. Xem trong mục “Của tôi”, dùng ở bước thanh toán.", "OK");
    }

    /// <summary>Ưu đãi sinh nhật: nhập ngày sinh một lần; đúng tháng sinh nhật hiện các chương trình có tên “sinh nhật”.</summary>
    private void VeSinhNhat()
    {
        KhungSinhNhat.Children.Clear();
        if (Phien.Khach is null) return;
        var nut = (string text, Func<Task> viec) =>
        {
            var b = new Button { Text = text, Style = (Style)Resources["OutlineButton"], HeightRequest = 40 };
            b.Clicked += async (_, _) => await viec();
            return b;
        };
        if (VoucherCuaToiService.NgaySinh is not { } ns)
        {
            KhungSinhNhat.Children.Add(nut("🎂 Thêm ngày sinh để nhận ưu đãi sinh nhật", NhapNgaySinhAsync));
            return;
        }
        var ds = DangDung().Where(k => TimKiemService.BoDau(k.TenChuongTrinh + " " + k.MoTa).Contains("sinh nhat")).ToList();
        var khung = new VerticalStackLayout { Spacing = 6 };
        khung.Children.Add(new Label { Text = "🎂 Ưu đãi sinh nhật", FontAttributes = FontAttributes.Bold, FontSize = 14 });
        if (!VoucherCuaToiService.DangThangSinhNhat)
            khung.Children.Add(new Label { Text = $"Sinh nhật của bạn: {ns:dd/MM}. Ưu đãi hiện vào tháng {ns.Month}.", FontSize = 12, TextColor = Mau("TextGrey") });
        else if (ds.Count == 0)
            khung.Children.Add(new Label { Text = "Tháng này là sinh nhật bạn 🎉 Hiện chưa có mã sinh nhật nào đang chạy — hãy quay lại sau.", FontSize = 12, TextColor = Mau("TextGrey") });
        else
            foreach (var k in ds)
                khung.Children.Add(new Label { Text = $"🎁 {k.MaCode} · {k.GiaTriGiamHienThi} — {k.TenChuongTrinh}", FontSize = 12.5, FontAttributes = FontAttributes.Bold, TextColor = Mau("Primary") });
        khung.Children.Add(nut("Đổi ngày sinh", NhapNgaySinhAsync));
        KhungSinhNhat.Children.Add(new Border
        {
            Padding = new Thickness(12), StrokeThickness = 1, Stroke = Mau("BorderColor"), Content = khung,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(16) },
        });
    }

    private async Task NhapNgaySinhAsync()
    {
        var nd = await this.NhapAsync("Ngày sinh", "Nhập theo dạng ngày/tháng/năm, ví dụ 15/08/2000:", "Lưu", "Hủy", maxLength: 10, keyboard: Keyboard.Text);
        if (string.IsNullOrWhiteSpace(nd)) return;
        if (!DateTime.TryParseExact(nd.Trim(), new[] { "d/M/yyyy", "dd/MM/yyyy" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out var d)
            || d > DateTime.Today || d.Year < 1900)
        { await DisplayAlert("Ngày sinh không hợp lệ", "Vui lòng nhập đúng dạng ngày/tháng/năm.", "OK"); return; }
        VoucherCuaToiService.NgaySinh = d;
        VeSinhNhat();
    }

    private async void OnDatNgayTapped(object? sender, TappedEventArgs e) => await Shell.Current.GoToAsync("//chinh/trang-chu");
}
