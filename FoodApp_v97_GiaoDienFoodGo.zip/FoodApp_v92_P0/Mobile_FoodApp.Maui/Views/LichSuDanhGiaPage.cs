using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>v90: khách xem lại các đánh giá đã gửi (món, quán, tài xế, nhận xét, ảnh) và phản hồi của quán; chạm để mở đơn.</summary>
public sealed class LichSuDanhGiaPage : ContentPage
{
    private readonly VerticalStackLayout _ds = new() { Spacing = 10 };
    private readonly Label _tomTat = new() { FontSize = 12.5, TextColor = Colors.Gray };

    public LichSuDanhGiaPage()
    {
        Title = "Lịch sử đánh giá";
        Content = new RefreshView
        {
            Command = new Command(async () => { await TaiAsync(); }),
            Content = new ScrollView { Content = new VerticalStackLayout { Padding = new Thickness(16), Spacing = 12, Children = { _tomTat, _ds } } },
        };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await TaiAsync();
    }

    private async Task TaiAsync()
    {
        try { if (DuLieuService.DangOnline && Phien.Khach is not null) await DuLieuService.TaiDonHangKhachAsync(); }
        catch { /* mất mạng: dùng dữ liệu trên máy */ }
        if (Content is RefreshView rv) rv.IsRefreshing = false;
        Ve();
    }

    private void Ve()
    {
        _ds.Children.Clear();
        if (Phien.Khach is null) { _tomTat.Text = "Hãy đăng nhập để xem lịch sử đánh giá."; return; }

        var don = MockData.LichSuDonHang.Where(d => OrderTrackingPage.DonCuaToi(d) && (d.DaDanhGia || d.DiemTaiXe > 0)).OrderByDescending(d => d.NgayDat).ToList();
        _tomTat.Text = don.Count == 0 ? "Bạn chưa đánh giá đơn nào. Đánh giá ở tab Đơn hàng sau khi đơn hoàn thành." : $"{don.Count} đơn đã đánh giá";

        foreach (var d in don)
        {
            var dgQuan = MockData.DanhSachDanhGia.FirstOrDefault(x => x.DonHangId == d.Id);
            var st = new VerticalStackLayout { Spacing = 3 };
            st.Children.Add(new Label { Text = $"Đơn #{d.Id} · {d.TenGianHang}", FontAttributes = FontAttributes.Bold, FontSize = 14 });
            st.Children.Add(new Label { Text = d.NgayDat.ToString("dd/MM/yyyy HH:mm"), FontSize = 11.5, TextColor = Colors.Gray });
            st.Children.Add(new Label { Text = string.Join("  ·  ", new[]
            {
                d.DiemMonAn > 0 ? $"🍜 Món/quán: {Sao(d.DiemMonAn)}" : "",
                d.DiemTaiXe > 0 ? $"🛵 Tài xế: {Sao(d.DiemTaiXe)}" : "",
            }.Where(x => x.Length > 0)), FontSize = 13 });
            var the = string.IsNullOrWhiteSpace(d.TheDanhGia) ? "" : d.TheDanhGia.Replace("|", " · ");
            if (the.Length > 0) st.Children.Add(new Label { Text = the, FontSize = 12, TextColor = Color.FromArgb("#6D28D9") });
            var nx = !string.IsNullOrWhiteSpace(d.NoiDungDanhGia) ? d.NoiDungDanhGia : dgQuan?.NoiDung ?? "";
            if (nx.Length > 0) st.Children.Add(new Label { Text = "“" + nx + "”", FontSize = 13 });
            if (dgQuan is { CoAnh: true }) st.Children.Add(new Label { Text = $"📷 {dgQuan.Anh.Count} ảnh đính kèm", FontSize = 11.5, TextColor = Colors.Gray });
            if (dgQuan is { CoPhanHoi: true }) st.Children.Add(new Label { Text = dgQuan.PhanHoiText, FontSize = 12.5, TextColor = Colors.SeaGreen });

            var id = d.Id;
            var khung = new Frame { Content = st, Padding = new Thickness(12), CornerRadius = 12, HasShadow = false, BorderColor = Color.FromArgb("#E5E7EB") };
            khung.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(async () => { OrderTrackingPage.DonCanMo = id; await Shell.Current.GoToAsync("//chinh/don-hang"); })
            });
            _ds.Children.Add(khung);
        }
    }

    private static string Sao(int n) => new string('★', Math.Clamp(n, 0, 5)) + new string('☆', 5 - Math.Clamp(n, 0, 5));
}
