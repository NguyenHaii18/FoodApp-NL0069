using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Đối soát tiền mặt thu hộ (COD): khoản cần nộp lại, đã nộp 30 ngày, danh sách đơn chưa đối soát. GET api/mobile/tai-xe/cod.</summary>
public partial class DriverCodPage : ContentPage
{
    public DriverCodPage() => InitializeComponent();

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await TaiAsync();
    }

    private async void OnRefreshing(object? sender, EventArgs e)
    {
        await TaiAsync();
        LamMoi.IsRefreshing = false;
    }

    private async Task TaiAsync()
    {
        LblLoi.IsVisible = false;
        var r = await ApiClient.GetAsync<CodDto>("api/mobile/tai-xe/cod");
        if (!r.ThanhCong || r.DuLieu is null)
        {
            LblLoi.Text = r.MatKetNoi || string.IsNullOrWhiteSpace(r.ThongDiep) ? "Cần kết nối máy chủ để xem đối soát COD." : r.ThongDiep;
            LblLoi.IsVisible = true;
            return;
        }
        var d = r.DuLieu;
        LblCanNop.Text = $"{d.CanNop:N0}đ";
        LblSoDon.Text = d.Don.Count > 0 ? $"{d.Don.Count} đơn chưa được đối soát" : "Không còn khoản nào cần nộp";
        LblDaNop.Text = $"Đã nộp (30 ngày): {d.DaNop30Ngay:N0}đ";

        DsDon.Children.Clear();
        LblTrong.IsVisible = d.Don.Count == 0;
        foreach (var x in d.Don)
        {
            var ma = x.MaDonHang;
            var dong = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            dong.Add(new Label { Text = $"Đơn #{ma}", FontAttributes = FontAttributes.Bold, FontSize = 14, VerticalOptions = LayoutOptions.Center }, 0);
            dong.Add(new Label { Text = $"{x.SoTien:N0}đ", FontAttributes = FontAttributes.Bold, FontSize = 14, TextColor = DriverPalette.Get("Primary") }, 1);
            var khung = new Frame { Content = dong, Padding = new Thickness(14, 12), CornerRadius = 14, HasShadow = false };
            khung.SetAppThemeColor(VisualElement.BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
            khung.SetAppThemeColor(Microsoft.Maui.Controls.Frame.BorderColorProperty, DriverPalette.Get("BorderColor"), Color.FromArgb("#4D4180"));
            khung.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(async () => await Shell.Current.GoToAsync($"{nameof(DriverOrderDetailPage)}?id={ma}")),
            });
            DsDon.Children.Add(khung);
        }
    }

    private async void OnBaoSaiLechClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync($"{nameof(DriverSuCoPage)}?loai=SaiLechCOD");
}
