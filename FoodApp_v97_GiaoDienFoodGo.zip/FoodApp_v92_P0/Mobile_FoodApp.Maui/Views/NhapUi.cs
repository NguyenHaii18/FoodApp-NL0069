namespace FoodApp.Maui.Views;

/// <summary>
/// Hộp thoại nhập chữ dùng ô Entry/Editor của app thay cho DisplayPromptAsync của hệ điều hành.
/// Lý do: trên Windows, DisplayPromptAsync dựng TextBox riêng bên trong ContentDialog nên KHÔNG chịu bản vá gõ tiếng Việt
/// (tắt gợi ý chữ/kiểm tra chính tả) áp cho Entry/Editor trong MauiProgram; gõ Telex/VNI ở đó dễ bị lỗi, nhân đôi hoặc mất dấu.
/// Chữ ký giống DisplayPromptAsync (cùng tên tham số) nên chỉ cần đổi tên hàm gọi.
/// </summary>
public static class NhapUi
{
    public static async Task<string?> NhapAsync(this Page trang, string title, string message, string accept = "OK", string cancel = "Hủy",
        string? placeholder = null, int maxLength = -1, Keyboard? keyboard = null, string initialValue = "")
    {
        var tcs = new TaskCompletionSource<string?>();
        var hop = new HopThoaiNhapPage(title, message, accept, cancel, placeholder, maxLength, keyboard ?? Keyboard.Text, initialValue, tcs);
        var nav = trang.Navigation;
        await nav.PushModalAsync(hop, true);
        var kq = await tcs.Task;
        if (nav.ModalStack.Contains(hop)) await nav.PopModalAsync(true);
        return kq;
    }
}

internal sealed class HopThoaiNhapPage : ContentPage
{
    private readonly TaskCompletionSource<string?> _tcs;
    private readonly InputView _o;

    public HopThoaiNhapPage(string title, string message, string accept, string cancel, string? placeholder, int maxLength,
        Keyboard keyboard, string initialValue, TaskCompletionSource<string?> tcs)
    {
        _tcs = tcs;
        Shell.SetNavBarIsVisible(this, false);
        this.SetAppThemeColor(BackgroundColorProperty, Color.FromArgb("#F5F6FA"), Color.FromArgb("#121216"));

        // Ô số/điện thoại/email/URL: một dòng (Entry). Còn lại (tên, địa chỉ, lý do, ghi chú...): Editor nhiều dòng.
        var motDong = keyboard == Keyboard.Numeric || keyboard == Keyboard.Telephone || keyboard == Keyboard.Email || keyboard == Keyboard.Url;
        if (motDong) _o = new Entry { Keyboard = keyboard, ReturnType = ReturnType.Done };
        else _o = new Editor { Keyboard = keyboard, AutoSize = EditorAutoSizeOption.TextChanges, MinimumHeightRequest = 96 };
        _o.Placeholder = placeholder;
        _o.Text = initialValue ?? "";
        if (maxLength > 0) _o.MaxLength = maxLength;
        _o.FontSize = 15;
        if (_o is Entry e) e.Completed += (_, _) => Xong(_o.Text ?? "");

        var mau = Application.Current?.Resources.TryGetValue("Primary", out var p) == true && p is Color c ? c : Color.FromArgb("#6C4DF6");
        var btnHuy = new Button { Text = cancel, BackgroundColor = Color.FromArgb("#9AA0AE"), TextColor = Colors.White, CornerRadius = 22, HeightRequest = 44 };
        var btnOk = new Button { Text = accept, BackgroundColor = mau, TextColor = Colors.White, CornerRadius = 22, HeightRequest = 44 };
        btnHuy.Clicked += (_, _) => Xong(null);
        btnOk.Clicked += (_, _) => Xong(_o.Text ?? "");

        var nut = new Grid { ColumnSpacing = 10, ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) } };
        nut.Add(btnHuy, 0, 0);
        nut.Add(btnOk, 1, 0);

        var khung = new Border
        {
            Padding = new Thickness(10, 4), StrokeThickness = 1, Stroke = Color.FromArgb("#C9CDD8"),
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(12) },
            Content = _o,
        };
        var td = new Label { Text = title, FontSize = 19, FontAttributes = FontAttributes.Bold };
        var nd = new Label { Text = message, FontSize = 13.5, Opacity = 0.8 };
        Content = new ScrollView
        {
            Content = new VerticalStackLayout { Spacing = 14, Padding = new Thickness(20, 56, 20, 24), Children = { td, nd, khung, nut } },
        };
        Loaded += (_, _) => Dispatcher.Dispatch(() => { _o.Focus(); });
    }

    private void Xong(string? kq) => _tcs.TrySetResult(kq);

    // Nút Back của Android / thao tác quay lại = Hủy
    protected override bool OnBackButtonPressed() { _tcs.TrySetResult(null); return true; }
}
