using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

public partial class DriverEarningsPage : ContentPage
{
    private string _ky = "ngay";

    public DriverEarningsPage() => InitializeComponent();

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await Services.DuLieuService.TaiDonDaGiaoTaiXeAsync();   // lịch sử chuyến thật từ SQL Server (nếu online)
        Ve();
        await TaiCodAsync();
    }

    /// <summary>COD đã thu nhưng chưa nộp lại + đã nộp 30 ngày — lấy từ máy chủ (không thể tính cục bộ vì quản trị xác nhận bên web).</summary>
    private async Task TaiCodAsync()
    {
        if (!DuLieuService.DangOnline) { LblCodCanNop.Text = "—"; LblCodDaNop.Text = "—"; LblCodGhiChu.Text = "Cần kết nối máy chủ để xem đối soát COD."; return; }
        var r = await ApiClient.GetAsync<CodDto>("api/mobile/tai-xe/cod");
        if (!r.ThanhCong || r.DuLieu is null) { LblCodCanNop.Text = "—"; LblCodDaNop.Text = "—"; LblCodGhiChu.Text = "Không tải được đối soát COD."; return; }
        LblCodCanNop.Text = $"{r.DuLieu.CanNop:N0}đ";
        LblCodCanNop.TextColor = r.DuLieu.CanNop > 0 ? DriverPalette.Get("Danger") : DriverPalette.Get("Success");
        LblCodDaNop.Text = $"{r.DuLieu.DaNop30Ngay:N0}đ";
        LblCodGhiChu.Text = r.DuLieu.Don.Count == 0 ? "Không có khoản COD nào cần nộp."
            : $"{r.DuLieu.Don.Count} đơn chưa nộp: " + string.Join(", ", r.DuLieu.Don.Take(8).Select(d => "#" + d.MaDonHang)) + (r.DuLieu.Don.Count > 8 ? "…" : "") + ". Nộp tiền cho quản trị để được xác nhận.";
    }

    private void OnKyClicked(object? sender, EventArgs e)
    {
        if (sender is Button { CommandParameter: string ky }) { _ky = ky; Ve(); }
    }

    private (DateTime Tu, DateTime Den, string Nhan) Khoang()
    {
        var h = DateTime.Today;
        switch (_ky)
        {
            case "tuan": var t = ThuNhapService.DauTuan(h); return (t, t.AddDays(6), $"Tuần {t:dd/MM} – {t.AddDays(6):dd/MM/yyyy}");
            case "thang": var d = new DateTime(h.Year, h.Month, 1); return (d, d.AddMonths(1).AddDays(-1), $"Tháng {h:MM/yyyy}");
            default: return (h, h, $"Hôm nay {h:dd/MM/yyyy}");
        }
    }

    private async void OnBaoSaiLechClicked(object? sender, EventArgs e)
    {
        var chon = await DisplayActionSheet("Báo sai lệch", "Đóng", null, "Sai lệch thu nhập", "Sai lệch tiền COD");
        if (chon is null or "Đóng") return;
        var loai = chon == "Sai lệch tiền COD" ? "SaiLechCOD" : "SaiLechThuNhap";
        await Shell.Current.GoToAsync($"{nameof(DriverSuCoPage)}?loai={loai}");
    }

    private void Ve()
    {
        var chinh = DriverPalette.Get("Primary");
        var nhat = DriverPalette.Get("PrimarySoft");
        foreach (var (nut, ky) in new[] { (BtnNgay, "ngay"), (BtnTuan, "tuan"), (BtnThang, "thang") })
        {
            nut.BackgroundColor = _ky == ky ? chinh : nhat;
            nut.TextColor = _ky == ky ? Colors.White : chinh;
        }

        var (tu, den, nhan) = Khoang();
        LblKy.Text = nhan;
        var tk = ThuNhapService.Tong(tu, den, gomThuongTuan: _ky != "ngay");
        LblTong.Text = $"{tk.Tong:N0}đ";
        LblTongCong.Text = $"{tk.Tong:N0}đ";
        LblPhi.Text = $"{tk.Phi:N0}đ";
        LblPhuCap.Text = $"{tk.PhuCap:N0}đ";
        LblThuong.Text = $"+{tk.Thuong:N0}đ";
        LblHoanThanh.Text = tk.SoDon.ToString();
        LblDaHuy.Text = tk.SoThatBai.ToString();
        LblDangGiao.Text = MockData.DonHangDangGiaoCuaTaiXe is null ? "0" : "1";
        LblTienDo.Text = ThuNhapService.TienDoThuongNgay() + $"\nTuần này: {ThuNhapService.SoDonTuan(DateTime.Today)} đơn";

        // So với kỳ trước (cùng độ dài)
        var soNgay = (den.Date - tu.Date).Days + 1;
        var truoc = ThuNhapService.Tong(tu.AddDays(-soNgay), tu.AddDays(-1), gomThuongTuan: _ky != "ngay");
        if (truoc.Tong <= 0) LblSoSanh.Text = "";
        else
        {
            var pt = (double)((tk.Tong - truoc.Tong) / truoc.Tong * 100);
            LblSoSanh.Text = $"{(pt >= 0 ? "↑" : "↓")} {Math.Abs(pt):0}% so với kỳ trước";
            LblSoSanh.TextColor = DriverPalette.Get(pt >= 0 ? "Success" : "Danger");
        }

        VeBieuDo(tu, den);

        DsLichSu.Children.Clear();
        var ds = MockData.DonHangDaGiaoCuaTaiXe
            .Where(d => d.GiaoLuc is { } g && g.Date >= tu.Date && g.Date <= den.Date)
            .OrderByDescending(d => d.GiaoLuc).ToList();
        if (ds.Count == 0)
            DsLichSu.Children.Add(new Label { Text = "Chưa có đơn nào trong kỳ này.", FontSize = 13, TextColor = DriverPalette.Get("TextGrey") });
        foreach (var d in ds)
        {
            var ok = !d.GiaoThatBai;
            var cot = new VerticalStackLayout { Spacing = 2 };
            cot.Children.Add(new Label { Text = $"{d.TenGianHang} · #{d.Id}", FontAttributes = FontAttributes.Bold, FontSize = 13.5 });
            cot.Children.Add(new Label { Text = $"{d.GiaoLuc:dd/MM HH:mm} · " + (ok ? "Giao thành công" : $"❌ {d.LyDoThatBai}"), FontSize = 12, TextColor = DriverPalette.Get("TextGrey") });
            if (ok && d.DiemTaiXe > 0) cot.Children.Add(new Label { Text = $"Khách chấm {new string('★', d.DiemTaiXe)}", FontSize = 12, TextColor = DriverPalette.Get("Warning") });
            var luoi = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            luoi.Add(cot, 0);
            luoi.Add(new Label
            {
                Text = ok ? $"+{d.PhiGiaoHang + d.PhuCap:N0}đ" : "0đ", FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center,
                TextColor = DriverPalette.Get(ok ? "Success" : "Danger"),
            }, 1);
            var khung = new Frame { Content = luoi, Padding = new Thickness(14, 10), CornerRadius = 14, HasShadow = false };
            khung.SetAppThemeColor(VisualElement.BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
            khung.SetAppThemeColor(Microsoft.Maui.Controls.Frame.BorderColorProperty, DriverPalette.Get("BorderColor"), Color.FromArgb("#4D4180"));
            var maDon = d.Id;
            khung.GestureRecognizers.Add(new TapGestureRecognizer
            {
                Command = new Command(async () => await Shell.Current.GoToAsync($"{nameof(DriverOrderDetailPage)}?id={Uri.EscapeDataString(maDon)}")),
            });
            DsLichSu.Children.Add(khung);
        }
    }

    private async void OnChiTietCodClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverCodPage));

    private async void OnChiTietThuNhapClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverThuNhapChiTietPage));

    /// <summary>Biểu đồ cột: Ngày = theo giờ (0–23), Tuần = 7 ngày, Tháng = từng ngày. Giá trị = phí giao + phụ cấp của đơn thành công.</summary>
    private void VeBieuDo(DateTime tu, DateTime den)
    {
        var don = ThuNhapService.DonThanhCong().Where(d => d.GiaoLuc!.Value.Date >= tu.Date && d.GiaoLuc!.Value.Date <= den.Date).ToList();
        int n = _ky == "ngay" ? 24 : (den.Date - tu.Date).Days + 1;
        var gt = new decimal[n];
        foreach (var d in don)
        {
            var i = _ky == "ngay" ? d.GiaoLuc!.Value.Hour : (d.GiaoLuc!.Value.Date - tu.Date).Days;
            if (i >= 0 && i < n) gt[i] += d.PhiGiaoHang + d.PhuCap;
        }
        LblTieuDeBieuDo.Text = _ky == "ngay" ? "Thu nhập theo giờ" : _ky == "tuan" ? "Thu nhập theo ngày trong tuần" : "Thu nhập theo ngày trong tháng";

        LuoiBieuDo.Children.Clear(); LuoiBieuDo.ColumnDefinitions.Clear();
        LuoiNhan.Children.Clear(); LuoiNhan.ColumnDefinitions.Clear();
        var max = gt.Max();
        for (int i = 0; i < n; i++)
        {
            LuoiBieuDo.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
            LuoiNhan.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
            var cao = max <= 0 ? 3 : Math.Max(3, (double)(gt[i] / max) * 112);
            LuoiBieuDo.Add(new BoxView
            {
                HeightRequest = cao, VerticalOptions = LayoutOptions.End, CornerRadius = 2,
                Color = gt[i] > 0 ? DriverPalette.Get("Primary") : DriverPalette.Get("BorderColor"),
            }, i, 0);

            string nhan = _ky switch
            {
                "ngay" => i % 6 == 0 ? $"{i}h" : "",
                "tuan" => new[] { "T2", "T3", "T4", "T5", "T6", "T7", "CN" }[i % 7],
                _ => (i + 1) % 5 == 0 || i == 0 ? (i + 1).ToString() : "",
            };
            if (nhan != "")
            {
                var l = new Label { Text = nhan, FontSize = 9, HorizontalTextAlignment = TextAlignment.Center, LineBreakMode = LineBreakMode.NoWrap, TextColor = DriverPalette.Get("TextGrey") };
                if (_ky != "tuan") { l.HorizontalTextAlignment = TextAlignment.Start; Grid.SetColumnSpan(l, Math.Min(3, n - i)); }   // nhãn dài hơn một cột
                LuoiNhan.Add(l, i, 0);
            }
        }
    }

    private async void OnXuatBaoCaoClicked(object? sender, EventArgs e) => await Services.ThuNhapXuatService.XuatAsync(this);
    private async void OnThuongClicked(object? sender, EventArgs e) => await Shell.Current.GoToAsync(nameof(DriverThuongPage));
}

public sealed class CodDto
{
    public decimal CanNop { get; set; }
    public decimal DaNop30Ngay { get; set; }
    public List<CodDonDto> Don { get; set; } = new();
}
public sealed class CodDonDto { public int MaDonHang { get; set; } public decimal SoTien { get; set; }
 }
