using FoodApp.Maui.Models;

namespace FoodApp.Maui.Views;

public partial class AdminCustomerListPage : ContentPage
{
    public AdminCustomerListPage()
    {
        InitializeComponent();
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (!await Services.PhanQuyenService.KiemTraAsync(this, Services.Quyen.XemTaiKhoan)) { await Shell.Current.GoToAsync(".."); return; }
        NapDanhSach();
    }

    private void NapDanhSach()
    {
        // TODO: thay bằng GET /api/quan-tri/khach-hang khi có API thật.
        DsKhachHang.ItemsSource = MockData.DanhSachKhachHang.OrderByDescending(k => k.NgayDangKy).ToList();
    }

    /// <summary>Sửa thông tin khách (Admin tổng, cần online): tên, SĐT, email, địa chỉ.</summary>
    private async void OnSuaClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: KhachHang kh }) return;
        if (!Services.PhanQuyenService.Co(Services.Quyen.QuanLyNhanVien)) { await DisplayAlert("Chỉ Admin tổng", "Chỉ Admin tổng được chỉnh sửa thông tin khách hàng.", "Đóng"); return; }
        var ten = await AdminUi.Hoi(this, "Sửa khách hàng (1/4)", "Họ tên", null, 2, kh.HoTen); if (ten == null) return;
        var sdt = await AdminUi.Hoi(this, "Sửa khách hàng (2/4)", "Số điện thoại (9–11 số)", null, 9, kh.SoDienThoai, Keyboard.Telephone); if (sdt == null) return;
        var email = await AdminUi.Hoi(this, "Sửa khách hàng (3/4)", "Email (có thể bỏ trống)", null, 0, kh.Email, Keyboard.Email); if (email == null) return;
        var diaChi = await AdminUi.Hoi(this, "Sửa khách hàng (4/4)", "Địa chỉ giao hàng mặc định (có thể bỏ trống)", null, 0, kh.DiaChi); if (diaChi == null) return;
        if (!await AdminUi.Put(this, $"api/mobile/admin/khach-hang/{kh.Id}", new { hoTen = ten, sdt, email, diaChi }, "Sửa thông tin khách hàng", ten)) return;
        kh.HoTen = ten; kh.SoDienThoai = sdt; kh.Email = email; kh.DiaChi = diaChi;
        Services.VendorLocalStore.Luu();
        NapDanhSach();
    }

    private async void OnKhoaMoClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: KhachHang kh }) return;
        if (!await Services.PhanQuyenService.KiemTraAsync(this, Services.Quyen.KhoaMoTaiKhoan)) return;

        if (kh.TaiKhoanBiKhoa)
        {
            kh.TaiKhoanBiKhoa = false;
            Services.VendorLocalStore.Luu();
            if (!await Services.DuLieuService.GhiHoanTacAsync("PUT", $"api/mobile/admin/khach-hang/{kh.Id}/mo-khoa", null,
                    () => { kh.TaiKhoanBiKhoa = true; Services.VendorLocalStore.Luu(); }))
            { NapDanhSach(); return; }
            Services.NhatKyService.GhiQuanTri("Mở khóa khách hàng", kh.HoTen, kh.Email);
            NapDanhSach();
            await DisplayAlert("Đã mở khóa", Services.DuLieuService.ChuThichGhi($"Tài khoản \"{kh.HoTen}\" đã được kích hoạt lại."), "OK");
            return;
        }

        bool xacNhan = await DisplayAlert(
            "Khóa tài khoản khách hàng",
            $"Khóa tài khoản \"{kh.HoTen}\"? Khách hàng sẽ không thể đăng nhập cho đến khi được mở lại.",
            "Khóa", "Hủy");
        if (!xacNhan) return;

        kh.TaiKhoanBiKhoa = true;
        Services.VendorLocalStore.Luu();
        if (!await Services.DuLieuService.GhiHoanTacAsync("PUT", $"api/mobile/admin/khach-hang/{kh.Id}/khoa", null,
                () => { kh.TaiKhoanBiKhoa = false; Services.VendorLocalStore.Luu(); }))
        { NapDanhSach(); return; }
        Services.NhatKyService.GhiQuanTri("Khóa khách hàng", kh.HoTen, kh.Email);

        NapDanhSach();
        if (Services.DuLieuService.LanGhiCuoi == Services.DuLieuService.KetQuaGhi.LuuTrenMay)
            await DisplayAlert("Đã khóa (chỉ trên máy)", Services.DuLieuService.CanhBaoNgoaiTuyen, "OK");
    }
}
