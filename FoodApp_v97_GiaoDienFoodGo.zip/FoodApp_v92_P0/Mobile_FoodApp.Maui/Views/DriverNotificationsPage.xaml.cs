using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

public partial class DriverNotificationsPage : ContentPage
{
    public DriverNotificationsPage() => InitializeComponent();

    /// <summary>Tạo thông báo từ trạng thái hiện tại: đơn mới, thay đổi đơn, thưởng, hệ thống.</summary>
    public static List<(string Icon, string TieuDe, string NoiDung, DateTime Luc)> TaoDanhSach()
    {
        var ds = new List<(string Icon, string TieuDe, string NoiDung, DateTime Luc)>();
        var t = MockData.TaiXeHienTai;

        if (DriverSettingsPage.NhanThongBaoDon && t.NhanDuocDon && MockData.DonHangDangGiaoCuaTaiXe is null)
            foreach (var d in MockData.DonHangChoTaiXe.Where(d => d.TaiXeId is null && d.SanSangGiao && d.TrangThai == TrangThaiDonHang.DangLam
                         && !MockData.LichSuDonHang.Any(x => x.Id == d.Id && x.TrangThai == TrangThaiDonHang.DaHuy)))
                ds.Add(("📦", "Đơn mới sẵn sàng", $"{d.TenGianHang} · #{d.Id} · +{d.PhiGiaoHang:N0}đ", d.NgayDat));

        var dang = MockData.DonHangDangGiaoCuaTaiXe;
        if (dang is not null)
        {
            if (MockData.LichSuDonHang.Any(x => x.Id == dang.Id && x.TrangThai == TrangThaiDonHang.DaHuy))
                ds.Add(("⚠️", "Khách đã hủy đơn đang giao", $"Đơn #{dang.Id} – {dang.TenGianHang}. Hãy liên hệ hỗ trợ nếu đã lấy hàng.", DateTime.Now));
            else
                ds.Add(("🛵", "Bạn đang có đơn", $"#{dang.Id} · {dang.TenGianHang} → {dang.DiaChiGiao}", dang.NgayDat));
        }

        foreach (var d in MockData.DonHangDaGiaoCuaTaiXe.Where(d => d.GiaoThatBai && d.GiaoLuc is not null).OrderByDescending(d => d.GiaoLuc).Take(5))
            ds.Add(("❌", "Đơn không giao được", $"#{d.Id}: {d.LyDoThatBai}", d.GiaoLuc!.Value));

        foreach (var d in MockData.DonHangDaGiaoCuaTaiXe.Where(d => d.DiemTaiXe > 0).OrderByDescending(d => d.GiaoLuc).Take(5))
            ds.Add(("⭐", $"Khách chấm {d.DiemTaiXe} sao", string.IsNullOrWhiteSpace(d.NhanXetTaiXe) ? $"Đơn #{d.Id}" : $"Đơn #{d.Id}: {d.NhanXetTaiXe}", d.GiaoLuc ?? DateTime.Now));

        var thuong = ThuNhapService.ThuongNgay(DateTime.Today);
        if (thuong > 0) ds.Add(("🎁", "Bạn đạt thưởng hôm nay", $"+{thuong:N0}đ (thưởng ngày)", DateTime.Today));
        else ds.Add(("🎯", "Mục tiêu thưởng", ThuNhapService.TienDoThuongNgay(), DateTime.Today));

        foreach (var tb in ThongBaoMayChuService.DanhSach.Take(30))   // thông báo thật từ SQL Server (đơn được phân công, đơn bị hủy, quản trị...)
            ds.Add((ThongBaoMayChuService.Icon(tb.Loai), tb.TieuDe, tb.NoiDung, tb.Ngay));

        ds.Add(("📢", "Thông báo hệ thống", "Luôn đội mũ bảo hiểm và tuân thủ luật giao thông khi giao hàng.", DateTime.Today));
        return ds.OrderByDescending(x => x.Luc).ToList();
    }

    public static int Dem() => TaoDanhSach().Count(x => x.Icon is "📦" or "⚠️" or "❌" or "⭐" or "🎁") + ThongBaoMayChuService.ChuaDoc;

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await ThongBaoMayChuService.TaiAsync();
        DsThongBao.Children.Clear();
        foreach (var (icon, tieuDe, nd, luc) in TaoDanhSach())
        {
            var cot = new VerticalStackLayout { Spacing = 2 };
            var dong1 = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            dong1.Add(new Label { Text = tieuDe, FontAttributes = FontAttributes.Bold, FontSize = 14, LineBreakMode = LineBreakMode.TailTruncation }, 0);
            dong1.Add(new Label { Text = Gio(luc), FontSize = 11, TextColor = DriverPalette.Get("TextGrey"), VerticalOptions = LayoutOptions.Center }, 1);
            cot.Children.Add(dong1);
            cot.Children.Add(new Label { Text = nd, FontSize = 12.5, TextColor = DriverPalette.Get("TextGrey") });

            var bieu = new Border
            {
                WidthRequest = 42, HeightRequest = 42, StrokeThickness = 0, VerticalOptions = LayoutOptions.Start,
                BackgroundColor = icon is "⚠️" or "❌" ? Color.FromArgb("#FDE8E8") : icon is "🎁" or "⭐" ? Color.FromArgb("#FFF1C9") : DriverPalette.Get("PrimarySoft"),
                StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(21) },
                Content = new Label { Text = icon, FontSize = 19, TextColor = Colors.Black, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center },
            };
            var luoi = new Grid { ColumnSpacing = 12, ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) } };
            luoi.Add(bieu, 0);
            luoi.Add(cot, 1);
            var khung = new Frame { Content = luoi, Padding = new Thickness(14, 12), CornerRadius = 16, HasShadow = false };
            khung.SetAppThemeColor(VisualElement.BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
            khung.SetAppThemeColor(Microsoft.Maui.Controls.Frame.BorderColorProperty, DriverPalette.Get("BorderColor"), Color.FromArgb("#4D4180"));
            DsThongBao.Children.Add(khung);
        }
    }

    private static string Gio(DateTime t) => t.Date == DateTime.Today ? t.ToString("HH:mm") : t.Date == DateTime.Today.AddDays(-1) ? "Hôm qua" : t.ToString("dd/MM");
}
