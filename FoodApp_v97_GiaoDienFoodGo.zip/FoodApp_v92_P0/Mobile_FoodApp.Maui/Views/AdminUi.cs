using System.Globalization;
using System.Text.Json;
using Microsoft.Maui.Controls.Shapes;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Đọc giá trị từ JsonElement do API quản trị trả về (không phân biệt hoa/thường, không ném lỗi khi thiếu trường).</summary>
public static class J
{
    public static bool Co(JsonElement e, string k, out JsonElement v)
    {
        v = default;
        if (e.ValueKind != JsonValueKind.Object) return false;
        if (e.TryGetProperty(k, out v)) return true;
        foreach (var p in e.EnumerateObject())
            if (string.Equals(p.Name, k, StringComparison.OrdinalIgnoreCase)) { v = p.Value; return true; }
        return false;
    }

    public static string S(JsonElement e, string k, string macDinh = "")
    {
        if (!Co(e, k, out var v)) return macDinh;
        return v.ValueKind switch
        {
            JsonValueKind.String => v.GetString() ?? macDinh,
            JsonValueKind.Null or JsonValueKind.Undefined => macDinh,
            JsonValueKind.True => "true",
            JsonValueKind.False => "false",
            _ => v.ToString(),
        };
    }

    public static decimal D(JsonElement e, string k) => Co(e, k, out var v) && v.ValueKind == JsonValueKind.Number && v.TryGetDecimal(out var d) ? d : 0m;
    public static long L(JsonElement e, string k) => Co(e, k, out var v) && v.ValueKind == JsonValueKind.Number && v.TryGetInt64(out var d) ? d : 0L;
    public static bool B(JsonElement e, string k) => Co(e, k, out var v) && v.ValueKind == JsonValueKind.True;
    public static bool Rong(JsonElement e, string k) => !Co(e, k, out var v) || v.ValueKind is JsonValueKind.Null or JsonValueKind.Undefined || (v.ValueKind == JsonValueKind.String && string.IsNullOrWhiteSpace(v.GetString()));
    public static JsonElement Doi(JsonElement e, string k) => Co(e, k, out var v) ? v : default;

    public static IEnumerable<JsonElement> Mang(JsonElement e, string k) =>
        Co(e, k, out var v) && v.ValueKind == JsonValueKind.Array ? v.EnumerateArray() : Enumerable.Empty<JsonElement>();

    public static string Ngay(JsonElement e, string k, string fmt = "dd/MM/yyyy HH:mm") =>
        DateTime.TryParse(S(e, k), CultureInfo.InvariantCulture, DateTimeStyles.None, out var t) ? t.ToString(fmt) : "";
}

/// <summary>Dựng giao diện bằng mã cho các trang quản trị (khớp bảng màu tím #6D28D9 của Admin UI), hỗ trợ chế độ tối.</summary>
public static class AdminUi
{
    public static readonly string Tim = "#6D28D9";
    public static readonly string Xanh = "#16A34A";
    public static readonly string Do = "#DC2626";
    public static readonly string Cam = "#F59E0B";
    public static readonly string Xam = "#6B7280";

    public static string Q(string? s) => Uri.EscapeDataString(s ?? "");
    public static string Tien(decimal t) => t.ToString("N0", CultureInfo.GetCultureInfo("vi-VN")) + "đ";

    /// <summary>Tên tiếng Việt + màu cho mã trạng thái (đơn, thanh toán, hoàn tiền, tài xế…).</summary>
    public static (string Nhan, string Mau) TrangThai(string ma) => ma switch
    {
        "ChoXacNhan" => ("Chờ xác nhận", Cam),
        "DaXacNhan" => ("Đã xác nhận", "#8B5CF6"),
        "DangGiao" => ("Đang giao", Tim),
        "DaGiao" => ("Đã giao", Xanh),
        "DaHuy" => ("Đã hủy", Do),
        "ChoThanhToan" => ("Chờ thanh toán", Cam),
        "DaThanhToan" => ("Đã thanh toán", Xanh),
        "ThatBai" => ("Thất bại", Do),
        "DaHoanTien" => ("Đã hoàn tiền", "#8B5CF6"),
        "TienMat" => ("Tiền mặt", Xam),
        "VNPay" => ("VNPay", Tim),
        "ChuyenKhoan" => ("Chuyển khoản", Tim),
        "ChoDuyet" => ("Chờ duyệt", Cam),
        "DaDuyet" => ("Đã duyệt", Xanh),
        "TuChoi" => ("Từ chối", Do),
        "SanSang" => ("Sẵn sàng", Xanh),
        "NgoaiTuyen" => ("Ngoại tuyến", Xam),
        "TamNghi" => ("Tạm nghỉ", Cam),
        "TamNgung" => ("Tạm ngưng", Do),
        "ConHang" => ("Còn hàng", Xanh),
        "KhachHang" => ("Khách hàng", "#8B5CF6"),
        "GianHang" => ("Gian hàng", Cam),
        "TaiXe" => ("Tài xế", Xanh),
        "QuanTri" => ("Quản trị", Tim),
        "SuperAdmin" => ("Admin tổng", Tim),
        "QuanLy" => ("Quản lý vận hành", "#8B5CF6"),
        "NhanVien" => ("Nhân viên hỗ trợ", Xam),
        "PhanCong" => ("Phân công", Xanh),
        "DoiTaiXe" => ("Đổi tài xế", Cam),
        "GoTaiXe" => ("Gỡ tài xế", Do),
        _ => (ma, Xam),
    };

    // ---------------------------------------------------------------- phần tử giao diện
    public static Label Nhan(string text, double size = 12.5, bool dam = false, bool mo = false)
    {
        var l = new Label { Text = text, FontSize = size, LineBreakMode = LineBreakMode.WordWrap };
        if (dam) l.FontAttributes = FontAttributes.Bold;
        if (mo) l.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#6B7280"), Color.FromArgb("#CFC6EA"));
        else l.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#1F1537"), Color.FromArgb("#F8F5FF"));
        return l;
    }

    public static Border The(double padding = 12)
    {
        var b = new Border
        {
            StrokeShape = new RoundRectangle { CornerRadius = new CornerRadius(14) },
            StrokeThickness = 1,
            Padding = new Thickness(padding),
        };
        b.SetAppThemeColor(VisualElement.BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
        b.SetAppTheme<Brush>(Border.StrokeProperty, new SolidColorBrush(Color.FromArgb("#E4DAF7")), new SolidColorBrush(Color.FromArgb("#4D4180")));
        return b;
    }

    public static Border Chip(string text, string mau)
    {
        var c = Color.FromArgb(mau);
        return new Border
        {
            StrokeShape = new RoundRectangle { CornerRadius = new CornerRadius(10) },
            StrokeThickness = 0,
            Padding = new Thickness(8, 3),
            BackgroundColor = c.WithAlpha(0.15f),
            VerticalOptions = LayoutOptions.Start,
            Content = new Label { Text = text, FontSize = 11, FontAttributes = FontAttributes.Bold, TextColor = c },
        };
    }

    public static Button Nut(string text, string mau, bool day = false)
    {
        var c = Color.FromArgb(mau);
        return new Button
        {
            Text = text, FontSize = 12, FontAttributes = FontAttributes.Bold, HeightRequest = 36, Padding = new Thickness(12, 0),
            CornerRadius = 10, BorderWidth = 1, BorderColor = c,
            BackgroundColor = day ? c : Colors.Transparent,
            TextColor = day ? Colors.White : c,
        };
    }


    /// <summary>Thanh tiêu đề tím (gradient) dùng chung cho các trang quản trị chính: Tổng quan, Quản lý, Thông báo, Cá nhân.</summary>
    public static View ThanhTieuDe(string tieuDe, string? phu = null, View? phai = null)
    {
        var g = new Grid
        {
            Padding = new Thickness(18, 16, 18, 16),
            ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) },
            Background = new LinearGradientBrush(
                new GradientStopCollection { new GradientStop(Color.FromArgb("#5B21B6"), 0f), new GradientStop(Color.FromArgb("#7C3AED"), 1f) },
                new Point(0, 0), new Point(1, 1)),
        };
        var st = new VerticalStackLayout { Spacing = 2, VerticalOptions = LayoutOptions.Center };
        st.Add(new Label { Text = tieuDe, FontSize = 20, FontAttributes = FontAttributes.Bold, TextColor = Colors.White });
        if (!string.IsNullOrEmpty(phu)) st.Add(new Label { Text = phu, FontSize = 11.5, TextColor = Color.FromArgb("#E4DAF7") });
        g.Add(st, 0, 0);
        if (phai != null) g.Add(phai, 1, 0);
        return g;
    }

    /// <summary>Khung trang chính của khu quản trị: thanh tiêu đề tím + nội dung + thanh tab dưới.</summary>
    public static Grid KhungTrang(string muc, View tieuDe, View noiDung)
    {
        var g = new Grid { RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Star), new RowDefinition(GridLength.Auto) } };
        g.Add(tieuDe, 0, 0);
        g.Add(noiDung, 0, 1);
        g.Add(new AdminNavBar { Muc = muc }, 0, 2);
        return g;
    }

    /// <summary>Chữ cái đầu của tên (tối đa 2 ký tự) cho ảnh đại diện tròn.</summary>
    public static string ChuCai(string? ten)
    {
        var p = (ten ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (p.Length == 0) return "?";
        return (p.Length == 1 ? p[0][..1] : p[0][..1] + p[^1][..1]).ToUpperInvariant();
    }

    private static bool Toi => Application.Current?.RequestedTheme == AppTheme.Dark;

    /// <summary>Nút tab dạng viên thuốc: đang chọn = nền tím chữ trắng, còn lại = nền tím rất nhạt chữ tím.</summary>
    public static Button NutTab(string text, bool chon) => new()
    {
        Text = text, FontSize = 12.5, FontAttributes = FontAttributes.Bold, HeightRequest = 36, Padding = new Thickness(16, 0),
        CornerRadius = 18, BorderWidth = 0,
        BackgroundColor = MauTab(chon), TextColor = chon ? Colors.White : Color.FromArgb(Toi ? "#C4B5FD" : Tim),
    };

    public static Color MauTab(bool chon) => chon ? Color.FromArgb(Tim) : Color.FromArgb(Toi ? "#2A2146" : "#F3EEFF");
    public static Color MauChuTab(bool chon) => chon ? Colors.White : Color.FromArgb(Toi ? "#C4B5FD" : Tim);

    /// <summary>Ô tìm kiếm bo tròn có biểu tượng 🔍. Trả về cả khung và ô nhập.</summary>
    public static (Border Khung, Entry O) OTimKiem(string goiY)
    {
        var o = new Entry { Placeholder = goiY, FontSize = 13.5, BackgroundColor = Colors.Transparent, ReturnType = ReturnType.Search };
        o.SetAppThemeColor(Entry.TextColorProperty, Color.FromArgb("#1F1537"), Color.FromArgb("#F8F5FF"));
        o.PlaceholderColor = Color.FromArgb("#9A90B8");
        var g = new Grid { ColumnSpacing = 6, ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) } };
        g.Add(new Label { Text = "🔍", FontSize = 15, VerticalOptions = LayoutOptions.Center, TextColor = Colors.Gray }, 0, 0);
        g.Add(o, 1, 0);
        var khung = new Border
        {
            StrokeThickness = 1, Padding = new Thickness(12, 0), HeightRequest = 44,
            StrokeShape = new RoundRectangle { CornerRadius = new CornerRadius(22) },
            Content = g,
        };
        khung.SetAppThemeColor(VisualElement.BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
        khung.SetAppTheme<Brush>(Border.StrokeProperty, new SolidColorBrush(Color.FromArgb("#E4DAF7")), new SolidColorBrush(Color.FromArgb("#4D4180")));
        return (khung, o);
    }

    /// <summary>Ảnh đại diện tròn/bo góc: ảnh từ địa chỉ (nếu có) hoặc chữ cái/emoji trên nền tím nhạt.</summary>
    public static View AnhDaiDien(string? chu, string? anhUrl, double kichThuoc = 44, double boGoc = 22)
    {
        var o = new Border
        {
            WidthRequest = kichThuoc, HeightRequest = kichThuoc, StrokeThickness = 0, BackgroundColor = Color.FromArgb(Toi ? "#2A2146" : "#EDE4FF"),
            VerticalOptions = LayoutOptions.Center,
            StrokeShape = new RoundRectangle { CornerRadius = new CornerRadius(boGoc) },
        };
        if (!string.IsNullOrWhiteSpace(anhUrl) && Uri.TryCreate(anhUrl, UriKind.Absolute, out var u))
            o.Content = new Image { Source = ImageSource.FromUri(u), Aspect = Aspect.AspectFill };
        else
            o.Content = new Label
            {
                Text = chu ?? "", FontSize = (chu?.Length ?? 0) > 2 ? 22 : 15, FontAttributes = FontAttributes.Bold,
                TextColor = (chu?.Length ?? 0) > 2 ? Colors.Black : Color.FromArgb(Toi ? "#C4B5FD" : Tim),
                HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center,
            };
        return o;
    }

    public static void NenTrang(Page p) =>
        p.SetAppThemeColor(VisualElement.BackgroundColorProperty, Color.FromArgb("#FAF8FF"), Color.FromArgb("#1C1633"));

    // ---------------------------------------------------------------- hộp thoại + gọi API
    /// <summary>Hỏi một dòng chữ. Trả null nếu hủy hoặc ngắn hơn <paramref name="toiThieu"/> ký tự.</summary>
    public static async Task<string?> Hoi(Page p, string tieuDe, string noiDung, string? goiY = null, int toiThieu = 0, string macDinh = "", Keyboard? kb = null)
    {
        var s = await p.NhapAsync(tieuDe, noiDung, "Đồng ý", "Hủy", goiY, 1000, kb ?? Keyboard.Text, macDinh);
        if (s == null) return null;
        s = s.Trim();
        if (s.Length < toiThieu)
        {
            await p.DisplayAlert("Chưa hợp lệ", toiThieu <= 1 ? "Vui lòng nhập nội dung." : $"Cần nhập tối thiểu {toiThieu} ký tự.", "Đóng");
            return null;
        }
        return s;
    }

    private static async Task<bool> Chay(Page p, Func<Task<ApiKetQua<JsonElement>>> goi, string? nhatKy, string? doiTuong, bool baoThanhCong)
    {
        var r = await goi();
        if (!r.ThanhCong)
        {
            await p.DisplayAlert("Không thực hiện được", string.IsNullOrWhiteSpace(r.ThongDiep) ? "Lỗi không xác định." : r.ThongDiep, "Đóng");
            return false;
        }
        if (nhatKy != null) NhatKyService.GhiQuanTri(nhatKy, doiTuong ?? "");
        var tb = r.DuLieu.ValueKind == JsonValueKind.Object ? J.S(r.DuLieu, "thongDiep") : "";
        if (baoThanhCong && tb != "") await p.DisplayAlert("Thành công", tb, "OK");
        return true;
    }

    public static Task<bool> Put(Page p, string url, object? body, string? nhatKy = null, string? doiTuong = null, bool baoThanhCong = true) =>
        Chay(p, () => ApiClient.PutAsync<JsonElement>(url, body), nhatKy, doiTuong, baoThanhCong);

    public static Task<bool> Post(Page p, string url, object? body, string? nhatKy = null, string? doiTuong = null, bool baoThanhCong = true) =>
        Chay(p, () => ApiClient.PostAsync<JsonElement>(url, body), nhatKy, doiTuong, baoThanhCong);

    public static Task<bool> Xoa(Page p, string url, string? nhatKy = null, string? doiTuong = null) =>
        Chay(p, () => ApiClient.DeleteAsync<JsonElement>(url), nhatKy, doiTuong, true);
}
