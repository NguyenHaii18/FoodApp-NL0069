﻿using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;
using FoodApp.Maui.Models;

namespace FoodApp.Maui.Views;

public class DiaDiem
{
    public string Ten { get; set; } = "";
    public double Lat { get; set; }
    public double Lng { get; set; }
}

/// <summary>
/// Bản đồ OpenStreetMap (Leaflet trong WebView, chạy được cả Windows và Android) + tìm kiếm địa điểm bằng Nominatim.
/// Cần Internet. Không dùng khóa API.
/// </summary>
[QueryProperty(nameof(DiaChi), "DiaChi")]
[QueryProperty(nameof(ChonDiaChi), "ChonDiaChi")]
public partial class BanDoPage : ContentPage
{
    /// <summary>Gọi khi người dùng bấm "Dùng địa chỉ này" (chế độ chọn địa chỉ).</summary>
    public static Action<string>? KhiChon;

    public string DiaChi { get; set; } = "";
    public bool ChonDiaChi { get; set; }

    private static readonly HttpClient Http = TaoHttp();
    private WebView? Wv;
    private DiaDiem? _chon;
    private DiaDiem? _cho;       // điểm chờ vẽ khi trang bản đồ tải xong
    private bool _sanSang;
    private bool _daTimLanDau;

    private static HttpClient TaoHttp()
    {
        var c = new HttpClient { Timeout = TimeSpan.FromSeconds(12) };
        c.DefaultRequestHeaders.UserAgent.ParseAdd("FoodApp.Maui/1.0 (do-an-mon-hoc)");   // Nominatim yêu cầu User-Agent
        c.DefaultRequestHeaders.AcceptLanguage.ParseAdd("vi");
        return c;
    }

    private const string Html = """
<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<style>html,body,#map{height:100%;margin:0;background:#eee}</style></head><body><div id="map"></div>
<script>
var map = L.map('map').setView([10.7769, 106.7009], 13);
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom: 19, attribution: '&copy; OpenStreetMap'}).addTo(map);
var marker = null;
function datViTri(lat, lng, nhan) {
  if (marker) map.removeLayer(marker);
  marker = L.marker([lat, lng]).addTo(map).bindPopup(nhan).openPopup();
  map.setView([lat, lng], 17);
}
var toi = null, nhomQuan = L.layerGroup().addTo(map);
function datViTriToi(lat, lng) {
  if (toi) map.removeLayer(toi);
  toi = L.circleMarker([lat, lng], {radius: 9, color: '#fff', weight: 3, fillColor: '#2563eb', fillOpacity: 1}).addTo(map).bindPopup('Vị trí của bạn');
  map.setView([lat, lng], 15);
}
function xoaQuan() { nhomQuan.clearLayers(); }
function themQuan(lat, lng, html) {
  var icon = L.divIcon({className: '', iconSize: [32, 32], iconAnchor: [16, 16], popupAnchor: [0, -14],
    html: '<div style="background:#6D28D9;color:#fff;border-radius:50%;width:32px;height:32px;line-height:30px;text-align:center;border:2px solid #fff;box-shadow:0 1px 5px rgba(0,0,0,.45);font-size:16px">🏬</div>'});
  L.marker([lat, lng], {icon: icon}).addTo(nhomQuan).bindPopup(html);
}
function vuaKhit() {
  var b = nhomQuan.getBounds();
  if (toi) b.extend(toi.getLatLng());
  if (b.isValid()) map.fitBounds(b, {padding: [30, 30], maxZoom: 16});
}
window.diemChon = null;
map.on('click', function(e) { window.diemChon = {lat: e.latlng.lat, lng: e.latlng.lng}; });
function layDiemChon() { var d = window.diemChon; window.diemChon = null; return d ? (d.lat + '|' + d.lng) : ''; }
</script></body></html>
""";

    public BanDoPage()
    {
        InitializeComponent();
    }

    /// <summary>Tạo WebView (Leaflet/OpenStreetMap) bằng mã. Nếu máy không dựng được WebView thì báo lỗi nhẹ nhàng + vẫn dùng được "Mở Google Maps".</summary>
    private bool TaoWebView()
    {
        if (Wv is not null) return true;
        try
        {
            var wv = new WebView { Source = new HtmlWebViewSource { Html = Html } };
            wv.Navigated += async (_, e) =>
            {
                try
                {
                    if (e.Result != WebNavigationResult.Success) return;   // tải trang lỗi (mất mạng...) thì chưa coi là sẵn sàng
                    _sanSang = true;
                    if (_cho is not null) { var d = _cho; _cho = null; await VeDiemAsync(d); }
                }
                catch (Exception ex) { ThongBaoLoi(ex); }
            };
            KhungWv.Children.Add(wv);
            Wv = wv;
            return true;
        }
        catch (Exception ex)
        {
            Services.CrashLog.Ghi("BanDoPage.TaoWebView", ex);
            ThongBao("Không khởi tạo được bản đồ trong ứng dụng trên thiết bị này. Bạn vẫn có thể dùng nút \"Mở Google Maps\".");
            return false;
        }
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        try
        {
            BtnDung.IsVisible = ChonDiaChi;
            if (_daTimLanDau) { _hoi?.Start(); return; }
            _daTimLanDau = true;
            await Task.Delay(150);   // để Shell dựng xong trang rồi mới gắn WebView (gắn quá sớm trên Windows dễ lỗi)
            if (!TaoWebView()) return;
            BatDauHoi();
            if (!string.IsNullOrWhiteSpace(DiaChi) && string.IsNullOrWhiteSpace(EntryTimKiem.Text))
            {
                EntryTimKiem.Text = DiaChi;
                await TimAsync(DiaChi);
            }
        }
        catch (Exception ex) { ThongBaoLoi(ex); }
    }

    /// <summary>Mọi handler async void phải tự bắt lỗi — nếu không, một lỗi nhỏ sẽ làm sập cả app (UnhandledException).</summary>
    private void ThongBaoLoi(Exception ex)
    {
        System.Diagnostics.Debug.WriteLine("BanDoPage: " + ex);
        try { ThongBao("Bản đồ gặp lỗi: " + ex.Message); } catch { /* trang đã đóng */ }
    }


    // ------------------------------------------------------------------ vị trí của tôi + quán gần bạn
    private (double Lat, double Lng)? _toi;
    private CancellationTokenSource? _huyQuan;
    private const string KhoaCache = "ban-do-toa-do-quan";
    private static readonly Dictionary<string, double[]> CacheToaDo = NapCache();

    private static Dictionary<string, double[]> NapCache()
    {
        try { return JsonSerializer.Deserialize<Dictionary<string, double[]>>(Preferences.Default.Get(KhoaCache, "{}")) ?? new(); }
        catch { return new(); }
    }

    private static void LuuCache()
    {
        try { Preferences.Default.Set(KhoaCache, JsonSerializer.Serialize(CacheToaDo)); } catch { /* bỏ qua */ }
    }

    private async Task ChayJsAsync(string js)
    {
        try { if (Wv is not null) await Wv.EvaluateJavaScriptAsync(js); } catch { /* WebView chưa sẵn sàng */ }
    }

    private async void OnViTriToiClicked(object? sender, EventArgs e)
    {
        if (!_sanSang) { ThongBao("Bản đồ đang tải, thử lại sau giây lát."); return; }
        Dang.IsVisible = Dang.IsRunning = true;
        ThongBao(null);
        try
        {
            var quyen = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>();
            if (quyen != PermissionStatus.Granted) quyen = await Permissions.RequestAsync<Permissions.LocationWhenInUse>();
            if (quyen != PermissionStatus.Granted) { ThongBao("Chưa được cấp quyền vị trí. Hãy bật quyền trong Cài đặt."); return; }

            var vt = await Geolocation.Default.GetLocationAsync(new GeolocationRequest(GeolocationAccuracy.Medium, TimeSpan.FromSeconds(10)));
            if (vt is null) { ThongBao("Không lấy được vị trí. Hãy bật GPS rồi thử lại."); return; }

            _toi = (vt.Latitude, vt.Longitude);
            await ChayJsAsync(string.Create(CultureInfo.InvariantCulture, $"datViTriToi({vt.Latitude}, {vt.Longitude});"));
            LblDaChon.Text = string.Create(CultureInfo.InvariantCulture, $"Vị trí của bạn: {vt.Latitude:0.00000}, {vt.Longitude:0.00000}");
        }
        catch (Exception)
        {
            ThongBao("Thiết bị chưa bật định vị hoặc không hỗ trợ.");
        }
        finally { Dang.IsVisible = Dang.IsRunning = false; }
    }

    private static double KhoangCachKm(double lat1, double lng1, double lat2, double lng2)
    {
        const double R = 6371;
        double Rad(double x) => x * Math.PI / 180;
        var dLat = Rad(lat2 - lat1); var dLng = Rad(lng2 - lng1);
        var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) + Math.Cos(Rad(lat1)) * Math.Cos(Rad(lat2)) * Math.Sin(dLng / 2) * Math.Sin(dLng / 2);
        return R * 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
    }

    /// <summary>Đổi địa chỉ quán thành tọa độ (Nominatim, có nhớ lại). Mỗi lần gọi mạng cách nhau &gt;1 giây theo quy định của dịch vụ.</summary>
    private static async Task<(double Lat, double Lng)?> TimToaDoAsync(string diaChi, CancellationToken huy)
    {
        if (CacheToaDo.TryGetValue(diaChi, out var c) && c.Length == 2) return (c[0], c[1]);
        var chuan = Regex.Replace(diaChi, @"\bQ\.\s*(\d+)", "Quận $1", RegexOptions.IgnoreCase);
        if (!chuan.Contains("Hồ Chí Minh", StringComparison.OrdinalIgnoreCase) && !chuan.Contains("TP.HCM", StringComparison.OrdinalIgnoreCase))
            chuan += ", Hồ Chí Minh";
        await Task.Delay(1100, huy);
        var url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=vn&accept-language=vi&q=" + Uri.EscapeDataString(chuan);
        using var doc = JsonDocument.Parse(await Http.GetStringAsync(url, huy));
        foreach (var x in doc.RootElement.EnumerateArray())
        {
            if (double.TryParse(x.GetProperty("lat").GetString(), NumberStyles.Float, CultureInfo.InvariantCulture, out var lat) &&
                double.TryParse(x.GetProperty("lon").GetString(), NumberStyles.Float, CultureInfo.InvariantCulture, out var lng))
            {
                CacheToaDo[diaChi] = new[] { lat, lng };
                LuuCache();
                return (lat, lng);
            }
        }
        return null;
    }

    private async void OnQuanGanBanClicked(object? sender, EventArgs e)
    {
        if (!_sanSang) { ThongBao("Bản đồ đang tải, thử lại sau giây lát."); return; }
        _huyQuan?.Cancel();
        _huyQuan = new CancellationTokenSource();
        var huy = _huyQuan.Token;

        var dsQuan = MockData.DanhSachGianHang
            .Where(g => g.TrangThaiDangKy == TrangThaiDangKyGianHang.DaDuyet && !g.TaiKhoanBiKhoa && !string.IsNullOrWhiteSpace(g.DiaChi))
            .ToList();
        if (dsQuan.Count == 0) { ThongBao("Chưa có quán nào để hiển thị."); return; }

        Dang.IsVisible = Dang.IsRunning = true;
        KhungKetQua.IsVisible = false;
        await ChayJsAsync("xoaQuan();");
        var thay = new List<(DiaDiem D, GianHang G)>();
        var khongThay = 0;
        try
        {
            for (var i = 0; i < dsQuan.Count; i++)
            {
                huy.ThrowIfCancellationRequested();
                var g = dsQuan[i];
                ThongBao($"Đang đặt quán lên bản đồ… {i + 1}/{dsQuan.Count}");
                (double Lat, double Lng)? td;
                try { td = await TimToaDoAsync(g.DiaChi, huy); }
                catch (Exception ex) when (ex is HttpRequestException or JsonException) { td = null; }
                if (td is null) { khongThay++; continue; }

                var html = $"<b>{System.Net.WebUtility.HtmlEncode(g.TenGianHang)}</b><br>{System.Net.WebUtility.HtmlEncode(g.DiaChi)}<br>⭐ {g.DanhGia:0.0} · ~{g.ThoiGianGiaoPhut} phút";
                await ChayJsAsync(string.Create(CultureInfo.InvariantCulture, $"themQuan({td.Value.Lat}, {td.Value.Lng}, {JsonSerializer.Serialize(html)});"));
                thay.Add((new DiaDiem { Ten = g.TenGianHang, Lat = td.Value.Lat, Lng = td.Value.Lng }, g));
            }

            await ChayJsAsync("vuaKhit();");
            var ds = (_toi is { } t
                ? thay.OrderBy(x => KhoangCachKm(t.Lat, t.Lng, x.D.Lat, x.D.Lng))
                : thay.OrderBy(x => x.G.TenGianHang)).Select(x =>
            {
                var km = _toi is { } m ? $" · {KhoangCachKm(m.Lat, m.Lng, x.D.Lat, x.D.Lng):0.0} km" : "";
                return new DiaDiem { Ten = $"{x.G.TenGianHang} — {x.G.DiaChi}{km}", Lat = x.D.Lat, Lng = x.D.Lng };
            }).ToList();
            NapKetQua(ds);
            KhungKetQua.IsVisible = ds.Count > 0;
            ThongBao(thay.Count == 0
                ? "Không xác định được vị trí quán nào (cần Internet)."
                : $"Có {thay.Count} quán trên bản đồ" + (khongThay > 0 ? $" ({khongThay} quán chưa xác định được địa chỉ)" : "") + (_toi is null ? ". Bấm “Vị trí của tôi” để xếp theo khoảng cách." : "."));
        }
        catch (OperationCanceledException) { /* bấm lại nút: lần mới thay thế */ }
        catch (Exception ex) { ThongBaoLoi(ex); }
        finally { Dang.IsVisible = Dang.IsRunning = false; }
    }

    private async void OnTimClicked(object? sender, EventArgs e)
    {
        try { await TimAsync(EntryTimKiem.Text ?? ""); }
        catch (Exception ex) { ThongBaoLoi(ex); }
    }

    private async Task TimAsync(string tuKhoa)
    {
        tuKhoa = tuKhoa.Trim();
        if (tuKhoa.Length < 2) { ThongBao("Hãy nhập ít nhất 2 ký tự để tìm."); return; }

        Dang.IsVisible = Dang.IsRunning = true;
        ThongBao(null);
        try
        {
            var url = "https://nominatim.openstreetmap.org/search?format=jsonv2&limit=6&countrycodes=vn&accept-language=vi&q="
                      + Uri.EscapeDataString(tuKhoa);
            using var doc = JsonDocument.Parse(await Http.GetStringAsync(url));

            var kq = new List<DiaDiem>();
            foreach (var x in doc.RootElement.EnumerateArray())
            {
                if (double.TryParse(x.GetProperty("lat").GetString(), NumberStyles.Float, CultureInfo.InvariantCulture, out var lat) &&
                    double.TryParse(x.GetProperty("lon").GetString(), NumberStyles.Float, CultureInfo.InvariantCulture, out var lng))
                    kq.Add(new DiaDiem { Ten = x.GetProperty("display_name").GetString() ?? tuKhoa, Lat = lat, Lng = lng });
            }

            NapKetQua(kq);
            KhungKetQua.IsVisible = kq.Count > 1;
            if (kq.Count == 0) ThongBao("Không tìm thấy địa điểm phù hợp. Thử gõ cụ thể hơn (số nhà, đường, quận).");
            else await ChonAsync(kq[0]);
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException)
        {
            ThongBao("Không kết nối được dịch vụ bản đồ. Kiểm tra Internet rồi thử lại.");
        }
        catch (JsonException)
        {
            ThongBao("Dịch vụ bản đồ trả về dữ liệu không hợp lệ.");
        }
        catch (Exception ex) { ThongBaoLoi(ex); }
        finally { Dang.IsVisible = Dang.IsRunning = false; }
    }

    /// <summary>Danh sách kết quả dựng bằng StackLayout (không dùng CollectionView: trên Windows nó từng gây NullReferenceException làm sập app).</summary>
    private void NapKetQua(IEnumerable<DiaDiem> ds)
    {
        DsKetQua.Children.Clear();
        foreach (var d in ds)
        {
            var the = new Border
            {
                Padding = new Thickness(12, 8), StrokeThickness = 1,
                Stroke = Application.Current?.RequestedTheme == AppTheme.Dark ? Color.FromArgb("#4D4180") : Color.FromArgb("#E4DAF7"),
                BackgroundColor = Application.Current?.RequestedTheme == AppTheme.Dark ? Color.FromArgb("#2B2250") : Colors.White,
                StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = 12 },
                Content = new Label { Text = "📍 " + d.Ten, FontSize = 12.5, MaxLines = 2, LineBreakMode = LineBreakMode.TailTruncation },
            };
            var cham = new TapGestureRecognizer();
            var diem = d;
            cham.Tapped += async (_, _) => { try { await ChonAsync(diem); } catch (Exception ex) { ThongBaoLoi(ex); } };
            the.GestureRecognizers.Add(cham);
            DsKetQua.Children.Add(the);
        }
    }

    private async void OnKetQuaTapped(object? sender, TappedEventArgs e)
    {
        try { if (e.Parameter is DiaDiem d) await ChonAsync(d); }
        catch (Exception ex) { ThongBaoLoi(ex); }
    }

    private async Task ChonAsync(DiaDiem d)
    {
        _chon = d;
        LblDaChon.Text = d.Ten;
        BtnDung.IsEnabled = true;
        if (!_sanSang) { _cho = d; return; }
        await VeDiemAsync(d);
    }

    private async Task VeDiemAsync(DiaDiem d)
    {
        var js = string.Create(CultureInfo.InvariantCulture, $"datViTri({d.Lat}, {d.Lng}, {JsonSerializer.Serialize(d.Ten)});");
        try { if (Wv is not null) await Wv.EvaluateJavaScriptAsync(js); } catch { /* WebView chưa sẵn sàng */ }
    }

    // Chạm vào bản đồ: trang JS chỉ GHI điểm vừa chạm vào biến window.diemChon; C# hỏi lại định kỳ (0,4 giây) bằng layDiemChon().
    // Cách cũ (điều hướng tới foodapp://pick và chặn trong Navigating) làm WebView2 trên Windows ném lỗi / sập app → bỏ hẳn.
    private IDispatcherTimer? _hoi;
    private bool _dangHoi;
    private bool _dangTraNguoc;

    private void BatDauHoi()
    {
        if (_hoi is not null) { _hoi.Start(); return; }
        _hoi = Dispatcher.CreateTimer();
        _hoi.Interval = TimeSpan.FromMilliseconds(400);
        _hoi.Tick += async (_, _) => await HoiDiemChonAsync();
        _hoi.Start();
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        try { _hoi?.Stop(); } catch { /* bỏ qua */ }
    }

    private async Task HoiDiemChonAsync()
    {
        if (_dangHoi || _dangTraNguoc || !_sanSang || Wv is null) return;
        _dangHoi = true;
        try
        {
            var kq = await Wv.EvaluateJavaScriptAsync("layDiemChon()");
            kq = kq?.Trim().Trim('"');
            if (string.IsNullOrEmpty(kq) || kq == "null") return;
            var p = kq.Split('|');
            if (p.Length != 2 ||
                !double.TryParse(p[0], NumberStyles.Float, CultureInfo.InvariantCulture, out var lat) ||
                !double.TryParse(p[1], NumberStyles.Float, CultureInfo.InvariantCulture, out var lng)) return;
            await ChonTuToaDoAsync(lat, lng);
        }
        catch (Exception ex) { Services.CrashLog.Ghi("BanDoPage.HoiDiemChon", ex); }   // WebView chưa sẵn sàng / đang đóng: bỏ qua
        finally { _dangHoi = false; }
    }

    private async Task ChonTuToaDoAsync(double lat, double lng)
    {
        _dangTraNguoc = true;
        Dang.IsVisible = Dang.IsRunning = true;
        try
        {
            string? ten = null;
            try
            {
                var url = string.Create(CultureInfo.InvariantCulture,
                    $"https://nominatim.openstreetmap.org/reverse?format=jsonv2&accept-language=vi&lat={lat}&lon={lng}");
                using var doc = JsonDocument.Parse(await Http.GetStringAsync(url));
                ten = doc.RootElement.TryGetProperty("display_name", out var n) ? n.GetString() : null;
            }
            catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or JsonException) { /* dùng tọa độ */ }
            await ChonAsync(new DiaDiem { Ten = string.IsNullOrWhiteSpace(ten) ? string.Create(CultureInfo.InvariantCulture, $"{lat:0.00000}, {lng:0.00000}") : ten!, Lat = lat, Lng = lng });
        }
        catch (Exception ex) { ThongBaoLoi(ex); }
        finally { Dang.IsVisible = Dang.IsRunning = false; _dangTraNguoc = false; }
    }

    private async void OnDungClicked(object? sender, EventArgs e)
    {
        if (_chon is null) return;
        try
        {
            KhiChon?.Invoke(_chon.Ten);
            KhiChon = null;
            if (Shell.Current is not null) await Shell.Current.GoToAsync("..");
        }
        catch (Exception ex) { ThongBaoLoi(ex); }
    }

    private async void OnGoogleClicked(object? sender, EventArgs e)
    {
        var q = _chon?.Ten ?? EntryTimKiem.Text;
        if (string.IsNullOrWhiteSpace(q)) { ThongBao("Chưa có địa điểm để mở."); return; }
        try { await Launcher.Default.OpenAsync(new Uri("https://www.google.com/maps/search/?api=1&query=" + Uri.EscapeDataString(q))); }
        catch (Exception) { ThongBao("Không mở được Google Maps trên thiết bị này."); }
    }

    private void ThongBao(string? t)
    {
        LblThongBao.Text = t ?? "";
        LblThongBao.IsVisible = !string.IsNullOrEmpty(t);
    }

    /// <summary>Mở bản đồ. <paramref name="chonDiaChi"/> = true thì có nút "Dùng địa chỉ này" trả địa chỉ về qua <paramref name="khiChon"/>.</summary>
    public static async Task MoAsync(string diaChi = "", bool chonDiaChi = false, Action<string>? khiChon = null)
    {
        KhiChon = khiChon;
        diaChi ??= "";
        try
        {
            if (Shell.Current is null) return;
            if (!CoTheDungWebView(out var lyDo))
            {
                // Máy không có WebView (chưa cài WebView2 Runtime / Android System WebView): mở Google Maps thay vì để app sập
                Services.CrashLog.Ghi("BanDoPage.MoAsync: không có WebView", lyDo);
                await MoGoogleMapsAsync(diaChi, lyDo);
                return;
            }
            await Shell.Current.GoToAsync(nameof(BanDoPage), new Dictionary<string, object>
            {
                { "DiaChi", diaChi }, { "ChonDiaChi", chonDiaChi },
            });
        }
        catch (Exception ex)
        {
            Services.CrashLog.Ghi("BanDoPage.MoAsync", ex);
            await MoGoogleMapsAsync(diaChi, "Không mở được bản đồ trong ứng dụng.");
        }
    }

    /// <summary>Kiểm tra trước khi mở: có thành phần WebView của hệ điều hành không (thiếu thì mở trang bản đồ sẽ làm app thoát).</summary>
    private static bool CoTheDungWebView(out string lyDo)
    {
        lyDo = "";
#if WINDOWS
        try
        {
            // WebView2 Runtime: gọi qua reflection để không phụ thuộc cách tham chiếu gói; không xác định được thì cứ cho mở.
            var kieu = Type.GetType("Microsoft.Web.WebView2.Core.CoreWebView2Environment, Microsoft.Web.WebView2.Core");
            var ham = kieu?.GetMethod("GetAvailableBrowserVersionString", Type.EmptyTypes);
            if (ham is not null && string.IsNullOrWhiteSpace(ham.Invoke(null, null) as string)) { lyDo = "Máy chưa cài Microsoft Edge WebView2 Runtime."; return false; }
        }
        catch (Exception ex) { lyDo = "Máy chưa cài Microsoft Edge WebView2 Runtime (" + (ex.InnerException ?? ex).GetType().Name + ")."; return false; }
#elif ANDROID
        try
        {
            if (OperatingSystem.IsAndroidVersionAtLeast(26) && Android.Webkit.WebView.CurrentWebViewPackage is null)
            { lyDo = "Thiết bị chưa có Android System WebView."; return false; }
        }
        catch (Exception ex) { lyDo = "Không kiểm tra được WebView của thiết bị (" + ex.GetType().Name + ")."; return false; }
#endif
        return true;
    }

    private static async Task MoGoogleMapsAsync(string tuKhoa, string lyDo)
    {
        try
        {
            var trang = Application.Current?.Windows?.FirstOrDefault()?.Page;
            var q = string.IsNullOrWhiteSpace(tuKhoa) ? "nhà hàng gần tôi" : tuKhoa.Trim();
            if (trang is not null && !await trang.DisplayAlert("Bản đồ trong ứng dụng chưa dùng được", lyDo + "\nMở Google Maps để tìm \"" + q + "\"?", "Mở Google Maps", "Đóng")) return;
            await Launcher.Default.OpenAsync(new Uri("https://www.google.com/maps/search/?api=1&query=" + Uri.EscapeDataString(q)));
        }
        catch (Exception ex) { Services.CrashLog.Ghi("BanDoPage.MoGoogleMaps", ex); }
    }
}
