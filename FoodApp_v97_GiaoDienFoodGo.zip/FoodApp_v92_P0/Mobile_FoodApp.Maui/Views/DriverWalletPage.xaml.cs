using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Ví tài khoản của tài xế: số dư, nạp/rút, giao dịch gần đây (xem ViTaiXeService).</summary>
public partial class DriverWalletPage : ContentPage
{
    private bool _tatCa;

    public DriverWalletPage() => InitializeComponent();

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await DuLieuService.TaiDonDaGiaoTaiXeAsync();   // lịch sử chuyến thật (nếu online)
        Ve();
    }

    private void Ve()
    {
        LblSoDu.Text = $"{ViTaiXeService.SoDu():N0}đ";
        var ds = ViTaiXeService.DanhSach();
        LblXemTatCa.Text = _tatCa ? "Thu gọn ›" : "Xem tất cả ›";
        DsGiaoDich.Children.Clear();
        if (ds.Count == 0)
            DsGiaoDich.Children.Add(new Label { Text = "Chưa có giao dịch. Hoàn thành đơn để nhận thu nhập vào ví.", FontSize = 13, TextColor = DriverPalette.Get("TextGrey") });
        foreach (var g in (_tatCa ? ds : ds.Take(6)))
        {
            var cot = new VerticalStackLayout { Spacing = 1, VerticalOptions = LayoutOptions.Center };
            cot.Children.Add(new Label { Text = g.MoTa, FontSize = 13.5, FontAttributes = FontAttributes.Bold, LineBreakMode = LineBreakMode.TailTruncation });
            cot.Children.Add(new Label { Text = g.Luc.ToString("dd/MM/yyyy HH:mm"), FontSize = 11.5, TextColor = DriverPalette.Get("TextGrey") });
            var bieu = new Border
            {
                WidthRequest = 38, HeightRequest = 38, StrokeThickness = 0, BackgroundColor = DriverPalette.Get("PrimarySoft"),
                StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(12) },
                Content = new Label { Text = g.Icon, FontSize = 18, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center, TextColor = Colors.Black },
            };
            var luoi = new Grid { ColumnSpacing = 10, ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            luoi.Add(bieu, 0);
            luoi.Add(cot, 1);
            luoi.Add(new Label
            {
                Text = (g.LaThu ? "+" : "-") + $"{g.SoTien:N0}đ", FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center,
                TextColor = DriverPalette.Get(g.LaThu ? "Success" : "Danger"),
            }, 2);
            var khung = new Frame { Content = luoi, Padding = new Thickness(12, 10), CornerRadius = 14, HasShadow = false };
            khung.SetAppThemeColor(VisualElement.BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
            khung.SetAppThemeColor(Microsoft.Maui.Controls.Frame.BorderColorProperty, DriverPalette.Get("BorderColor"), Color.FromArgb("#4D4180"));
            DsGiaoDich.Children.Add(khung);
        }
    }

    private void HienThongBao(string chu, bool loi)
    {
        LblThongBao.Text = chu;
        LblThongBao.TextColor = DriverPalette.Get(loi ? "Danger" : "Success");
        LblThongBao.IsVisible = true;
    }

    private async void OnNapTapped(object? sender, TappedEventArgs e)
    {
        var nhap = await this.NhapAsync("Nạp tiền", $"Nhập số tiền cần nạp (tối thiểu {ViTaiXeService.NapToiThieu:N0}đ):", "Nạp", "Hủy", "VD: 200000", keyboard: Keyboard.Numeric);
        if (nhap is null) return;
        if (!ViTaiXeService.DocSoTien(nhap, out var tien)) { HienThongBao("Số tiền không hợp lệ.", true); return; }
        var loi = ViTaiXeService.Nap(tien);
        HienThongBao(loi ?? $"✓ Đã nạp {tien:N0}đ vào ví.", loi is not null);
        Ve();
    }

    private async void OnRutTapped(object? sender, TappedEventArgs e)
    {
        var nhap = await this.NhapAsync("Rút tiền", $"Số dư {ViTaiXeService.SoDu():N0}đ. Nhập số tiền cần rút (tối thiểu {ViTaiXeService.RutToiThieu:N0}đ):", "Rút", "Hủy", "VD: 200000", keyboard: Keyboard.Numeric);
        if (nhap is null) return;
        if (!ViTaiXeService.DocSoTien(nhap, out var tien)) { HienThongBao("Số tiền không hợp lệ.", true); return; }
        var loi = ViTaiXeService.Rut(tien);
        HienThongBao(loi ?? $"✓ Đã tạo lệnh rút {tien:N0}đ.", loi is not null);
        Ve();
    }

    private void OnLichSuTapped(object? sender, TappedEventArgs e) { _tatCa = !_tatCa; Ve(); }
}
