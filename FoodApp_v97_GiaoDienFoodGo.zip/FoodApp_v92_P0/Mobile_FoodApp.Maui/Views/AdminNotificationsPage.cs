﻿using System.Text.Json;
using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Một nhóm việc đang chờ quản trị viên xử lý.</summary>
public sealed record AdminViec(string Icon, string Nhan, long So, string Route);

/// <summary>Lấy danh sách việc cần xử lý: từ API khi online, nếu không thì tính từ dữ liệu cục bộ.</summary>
public static class AdminViecService
{
    public static async Task<List<AdminViec>> LayAsync()
    {
        var ds = new List<AdminViec>();
        try
        {
            var r = await ApiClient.GetAsync<JsonElement>("api/mobile/admin/tong-quan");
            if (r.ThanhCong)
            {
                var d = r.DuLieu;
                ds.Add(new("🏬", "Gian hàng chờ duyệt", J.L(d, "gianHangChoDuyet"), nameof(AdminVendorApprovalPage)));
                ds.Add(new("🛵", "Tài xế chờ duyệt", J.L(d, "taiXeChoDuyet"), nameof(AdminDriverApprovalPage)));
                ds.Add(new("📣", "Khiếu nại chưa xử lý", J.L(d, "khieuNaiCho"), nameof(AdminIssuesPage)));
                ds.Add(new("💳", "Yêu cầu hoàn tiền", J.L(d, "hoanTienCho"), nameof(AdminPaymentsPage)));
                ds.Add(new("⭐", "Đánh giá bị báo cáo", J.L(d, "baoCaoDanhGiaCho"), nameof(AdminReviewsPage)));
                ds.Add(new("🧭", "Đơn chưa có tài xế", J.L(d, "donChuaCoTaiXe"), nameof(AdminDispatchPage)));
                ds.Add(new("💵", "Đơn COD chưa đối soát", J.L(d, "codChuaDoiSoat"), nameof(AdminPaymentsPage)));
                return ds.Where(x => x.So > 0).ToList();
            }
        }
        catch (Exception ex) { CrashLog.Ghi("AdminViec", ex); }

        // Ngoại tuyến: tính từ dữ liệu cục bộ (chụp bản sao danh sách để tránh lỗi "collection was modified")
        ds.Clear();
        try
        {
            ds.Add(new("🏬", "Gian hàng chờ duyệt", MockData.DanhSachGianHang.ToList().Count(g => g.TrangThaiDangKy == TrangThaiDangKyGianHang.ChoDuyet), nameof(AdminVendorApprovalPage)));
            ds.Add(new("🛵", "Tài xế chờ duyệt", MockData.DanhSachTaiXe.ToList().Count(t => t.ChoDuyet), nameof(AdminDriverApprovalPage)));
            ds.Add(new("📦", "Đơn chờ xác nhận", MockData.TatCaDonHangHeThong.ToList().Count(d => d.TrangThai == TrangThaiDonHang.ChoXacNhan), nameof(AdminOrdersPage)));
        }
        catch (Exception ex) { CrashLog.Ghi("AdminViec.CucBo", ex); }
        return ds.Where(x => x.So > 0).ToList();
    }

    /// <summary>Dựng một dòng "biểu tượng – tên việc – số lượng" bấm được để mở trang xử lý.</summary>
    public static View DungDong(AdminViec v)
    {
        var g = new Grid { ColumnSpacing = 10, ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        g.Add(new Border
        {
            WidthRequest = 36, HeightRequest = 36, StrokeThickness = 0, BackgroundColor = Color.FromArgb("#EDE9FE"),
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(10) },
            Content = new Label { Text = v.Icon, FontSize = 17, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center, TextColor = Colors.Black },
        }, 0, 0);
        var nhan = AdminUi.Nhan(v.Nhan, 13.5);
        nhan.VerticalOptions = LayoutOptions.Center;
        g.Add(nhan, 1, 0);
        var so = AdminUi.Nhan(v.So.ToString(), 14, dam: true);
        so.VerticalOptions = LayoutOptions.Center;
        so.TextColor = Color.FromArgb(AdminUi.Tim);
        g.Add(so, 2, 0);
        g.GestureRecognizers.Add(new TapGestureRecognizer
        {
            Command = new Command(async () => { try { await Shell.Current.GoToAsync(v.Route); } catch (Exception ex) { CrashLog.Ghi("AdminViecMo", ex); } }),
        });
        return g;
    }
}

/// <summary>Tab "Thông báo" của quản trị viên: danh sách việc cần xử lý, kéo để làm mới.</summary>
public sealed class AdminNotificationsPage : ContentPage
{
    private readonly VerticalStackLayout _ds = new() { Spacing = 10, Padding = new Thickness(16, 14, 16, 24) };
    private readonly RefreshView _lamMoi = new() { RefreshColor = Color.FromArgb(AdminUi.Tim) };

    public AdminNotificationsPage()
    {
        Title = "Thông báo";
        Shell.SetNavBarIsVisible(this, false);
        AdminUi.NenTrang(this);
        _lamMoi.Content = new ScrollView { Content = _ds };
        _lamMoi.Refreshing += async (_, _) =>
        {
            try { await NapAsync(); }
            catch (Exception ex) { CrashLog.Ghi("AdminNotificationsPage.Refreshing", ex); _lamMoi.IsRefreshing = false; }
        };
        Content = AdminUi.KhungTrang("thongbao", AdminUi.ThanhTieuDe("Thông báo", "Những việc đang chờ bạn xử lý"), _lamMoi);
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        try { await NapAsync(); }
        catch (Exception ex) { CrashLog.Ghi("AdminNotificationsPage.OnAppearing", ex); }
    }

    private async Task NapAsync()
    {
        try
        {
            var viec = await AdminViecService.LayAsync();
            _ds.Children.Clear();
            if (viec.Count == 0)
            {
                var the = AdminUi.The(18);
                the.Content = new VerticalStackLayout
                {
                    Spacing = 4, HorizontalOptions = LayoutOptions.Center,
                    Children =
                    {
                        new Label { Text = "🎉", FontSize = 34, HorizontalOptions = LayoutOptions.Center },
                        AdminUi.Nhan("Không có việc cần xử lý", 14, dam: true),
                        AdminUi.Nhan("Mọi thứ đang vận hành ổn định.", 12, mo: true),
                    },
                };
                _ds.Add(the);
                return;
            }
            var khung = AdminUi.The(14);
            var st = new VerticalStackLayout { Spacing = 14 };
            foreach (var v in viec) st.Add(AdminViecService.DungDong(v));
            khung.Content = st;
            _ds.Add(khung);
        }
        catch (Exception ex)
        {
            CrashLog.Ghi("AdminNotificationsPage.NapAsync", ex);
            _ds.Children.Clear();
            _ds.Add(AdminUi.Nhan("Không tải được thông báo: " + ex.Message + "\nKéo xuống để thử lại.", 12.5, mo: true));
        }
        finally { _lamMoi.IsRefreshing = false; }
    }
}
