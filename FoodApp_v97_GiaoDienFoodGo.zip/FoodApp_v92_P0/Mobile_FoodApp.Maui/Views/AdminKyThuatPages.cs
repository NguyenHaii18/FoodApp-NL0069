﻿using System.Text.Json;
using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Khung chung cho các trang kỹ thuật của quản trị: cuộn dọc, kéo để làm mới.</summary>
public abstract class AdminKyThuatTrang : ContentPage
{
    protected readonly VerticalStackLayout Nd = new() { Spacing = 10, Padding = new Thickness(16, 10, 16, 28) };
    private readonly RefreshView _lamMoi = new() { RefreshColor = Color.FromArgb(AdminUi.Tim) };
    protected virtual Quyen? QuyenCan => null;

    protected AdminKyThuatTrang(string tieuDe)
    {
        Title = tieuDe;
        AdminUi.NenTrang(this);
        _lamMoi.Content = new ScrollView { Content = Nd };
        _lamMoi.Refreshing += async (_, _) => { await VeLaiAsync(); _lamMoi.IsRefreshing = false; };
        Content = _lamMoi;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (QuyenCan is Quyen q && !await PhanQuyenService.KiemTraAsync(this, q)) { await Shell.Current.GoToAsync(".."); return; }
        await VeLaiAsync();
    }

    private async Task VeLaiAsync()
    {
        try { Nd.Children.Clear(); await DungAsync(); }
        catch (Exception ex) { CrashLog.Ghi(GetType().Name, ex); Nd.Add(AdminUi.Nhan("Không tải được trang: " + ex.Message, 12.5, mo: true)); }
    }

    protected abstract Task DungAsync();

    protected static Border KhoiTheo(string tieuDe, params View[] noiDung)
    {
        var st = new VerticalStackLayout { Spacing = 6 };
        st.Add(AdminUi.Nhan(tieuDe, 14, dam: true));
        foreach (var v in noiDung) st.Add(v);
        var the = AdminUi.The(14);
        the.Content = st;
        return the;
    }

    protected static View DongTrai(string nhan, string giaTri, string? mau = null)
    {
        var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 8 };
        g.Add(AdminUi.Nhan(nhan, 12.5, mo: true), 0, 0);
        var v = AdminUi.Nhan(giaTri, 12.5, dam: true);
        if (mau != null) v.TextColor = Color.FromArgb(mau);
        v.HorizontalTextAlignment = TextAlignment.End;
        g.Add(v, 1, 0);
        return g;
    }

    protected static View DongKiemTra(bool dat, string tieuDe, string moTa, bool canhBao = false)
    {
        var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 10 };
        g.Add(new Label { Text = dat ? "✅" : canhBao ? "⚠️" : "❌", FontSize = 16, VerticalOptions = LayoutOptions.Start }, 0, 0);
        var st = new VerticalStackLayout { Spacing = 1 };
        st.Add(AdminUi.Nhan(tieuDe, 13, dam: true));
        st.Add(AdminUi.Nhan(moTa, 11.5, mo: true));
        g.Add(st, 1, 0);
        return g;
    }
}

// ============================================================ 1. GIÁM SÁT & GHI LỖI
public sealed class AdminGiamSatPage : AdminKyThuatTrang
{
    protected override Quyen? QuyenCan => Quyen.XemThongKe;
    public AdminGiamSatPage() : base("Giám sát hệ thống") { }

    protected override Task DungAsync()
    {
        var tk = GiamSatService.ThongKe();
        var sk = GiamSatService.SucKhoeCuoi;

        // --- Tình trạng máy chủ
        var nutKt = AdminUi.Nut("Kiểm tra /health", AdminUi.Tim, day: true);
        var ketQua = AdminUi.Nhan(sk is null ? "Chưa kiểm tra." : $"{(sk.Value.Ok ? "🟢" : "🔴")} {sk.Value.ThongDiep} · {sk.Value.Ms}ms · {sk.Value.Luc:HH:mm:ss}", 12, mo: true);
        nutKt.Clicked += async (_, _) =>
        {
            nutKt.IsEnabled = false; ketQua.Text = "Đang kiểm tra…";
            var r = await GiamSatService.KiemTraSucKhoeAsync();
            ketQua.Text = $"{(r.Ok ? "🟢" : "🔴")} {r.ThongDiep} · {r.Ms}ms · {DateTime.Now:HH:mm:ss}";
            nutKt.IsEnabled = true;
        };
        Nd.Add(KhoiTheo("Tình trạng dịch vụ",
            DongTrai("Chế độ dữ liệu", DuLieuService.DangOnline ? "Trực tuyến" : "Ngoại tuyến (dữ liệu trên máy)", DuLieuService.DangOnline ? AdminUi.Xanh : AdminUi.Cam),
            DongTrai("Máy chủ", AppSettings.BaseUrl),
            DongTrai("Môi trường", AppSettings.TenMoiTruong),
            DongTrai("Ứng dụng chạy từ", GiamSatService.KhoiDongLuc.ToString("HH:mm dd/MM")),
            nutKt, ketQua));

        // --- Số liệu API
        string mauLoi = tk.TyLeLoi >= 10 ? AdminUi.Do : tk.TyLeLoi >= 3 ? AdminUi.Cam : AdminUi.Xanh;
        Nd.Add(KhoiTheo("Lời gọi API (phiên hiện tại)",
            DongTrai("Tổng số lần gọi", tk.Tong.ToString("N0")),
            DongTrai("Lỗi", $"{tk.Loi} ({tk.TyLeLoi:0.#}%)", mauLoi),
            DongTrai("Lỗi mất kết nối / quá thời gian", tk.LoiMang.ToString(), tk.LoiMang > 0 ? AdminUi.Cam : null),
            DongTrai("Lỗi thanh toán / đặt đơn", tk.LoiThanhToan.ToString(), tk.LoiThanhToan > 0 ? AdminUi.Do : null),
            DongTrai("Thời gian phản hồi trung bình", tk.Tong == 0 ? "—" : $"{tk.TrungBinhMs} ms"),
            DongTrai("Phản hồi chậm nhất 5% (P95)", tk.Tong == 0 ? "—" : $"{tk.P95Ms} ms", tk.P95Ms > 3000 ? AdminUi.Cam : null)));

        // --- Bất thường trong xử lý đơn
        var ds = MockData.TatCaDonHangHeThong.ToList();
        int quaHan = ds.Count(d => d.QuaHanPhanHoi);
        int chuaTaiXe = ds.Count(d => d.DangChoTaiXe);
        int treGiao = ds.Count(d => d.TrangThai == TrangThaiDonHang.DangGiao && (DateTime.Now - d.NgayDat).TotalMinutes > 90);
        int chuaTT = ds.Count(d => d.TrangThaiThanhToan == "ChoThanhToan" && (DateTime.Now - d.NgayDat).TotalMinutes > 15);
        Nd.Add(KhoiTheo("Bất thường khi xử lý đơn",
            DongTrai($"Quán chưa phản hồi quá {DonHang.PhutPhanHoiToiDa} phút", quaHan.ToString(), quaHan > 0 ? AdminUi.Do : AdminUi.Xanh),
            DongTrai("Món xong nhưng chưa có tài xế", chuaTaiXe.ToString(), chuaTaiXe > 0 ? AdminUi.Cam : AdminUi.Xanh),
            DongTrai("Đang giao quá 90 phút", treGiao.ToString(), treGiao > 0 ? AdminUi.Do : AdminUi.Xanh),
            DongTrai("Chờ thanh toán quá 15 phút", chuaTT.ToString(), chuaTT > 0 ? AdminUi.Cam : AdminUi.Xanh)));

        // --- Thông báo
        Nd.Add(KhoiTheo("Thông báo thời gian thực",
            DongTrai("Thông báo chưa đọc từ máy chủ", ThongBaoMayChuService.ChuaDoc.ToString()),
            DongTrai("Số thông báo đã tải", ThongBaoMayChuService.DanhSach.Count.ToString()),
            AdminUi.Nhan("Ứng dụng tải thông báo khi mở màn hình và khi kéo để làm mới; đẩy thông báo nền cần dịch vụ FCM/APNs (chưa tích hợp).", 11, mo: true)));

        // --- Lỗi gần đây
        var loi = GiamSatService.LoiGanDay(10);
        var khoiLoi = new VerticalStackLayout { Spacing = 8 };
        if (loi.Count == 0) khoiLoi.Add(AdminUi.Nhan("Chưa ghi nhận lỗi API nào 🎉", 12.5, mo: true));
        foreach (var l in loi)
        {
            var st = new VerticalStackLayout { Spacing = 1 };
            st.Add(AdminUi.Nhan($"{l.Method} {l.Url}", 12, dam: true));
            st.Add(AdminUi.Nhan($"{l.Luc:HH:mm:ss} · HTTP {(l.MaHttp == 0 ? "—" : l.MaHttp.ToString())} · {l.Ms}ms{(l.LienQuanThanhToan ? " · thanh toán/đặt đơn" : "")}", 11, mo: true));
            st.Add(AdminUi.Nhan(l.ThongDiep, 11.5, mo: true));
            khoiLoi.Add(st);
        }
        var nutLog = AdminUi.Nut("Xem nhật ký lỗi ứng dụng", AdminUi.Tim);
        nutLog.Clicked += async (_, _) =>
        {
            string nd;
            try { nd = File.Exists(CrashLog.DuongDan) ? string.Join("\n", File.ReadAllLines(CrashLog.DuongDan).TakeLast(30)) : "Chưa có lỗi nào được ghi."; }
            catch (Exception ex) { nd = ex.Message; }
            await DisplayAlert("Nhật ký lỗi (30 dòng cuối)", nd, "Đóng");
        };
        khoiLoi.Add(nutLog);
        Nd.Add(KhoiTheo("Lỗi API gần đây", khoiLoi));
        Nd.Add(AdminUi.Nhan("Số liệu chỉ phản ánh phiên chạy hiện tại trên thiết bị này, không thay thế công cụ giám sát phía máy chủ.", 11, mo: true));
        return Task.CompletedTask;
    }
}

// ============================================================ 2. SAO LƯU & PHỤC HỒI
public sealed class AdminSaoLuuPage : AdminKyThuatTrang
{
    protected override Quyen? QuyenCan => Quyen.QuanLyNhanVien;   // chỉ Admin tổng
    public AdminSaoLuuPage() : base("Sao lưu & phục hồi") { }

    protected override Task DungAsync()
    {
        var cuoi = SaoLuuService.LanCuoi;
        var nutTao = AdminUi.Nut("💾 Sao lưu ngay", AdminUi.Tim, day: true);
        nutTao.Clicked += async (_, _) =>
        {
            var ten = SaoLuuService.Tao("Thủ công");
            NhatKyService.GhiQuanTri("Sao lưu dữ liệu", ten ?? "", ten is null ? "Không có dữ liệu" : "", ten is not null);
            await DisplayAlert(ten is null ? "Chưa có dữ liệu" : "Đã sao lưu", ten ?? "Chưa có dữ liệu cục bộ để sao lưu.", "OK");
            await Task.Yield();
            Nd.Children.Clear(); await DungAsync();
        };
        Nd.Add(KhoiTheo("Sao lưu dữ liệu trên thiết bị",
            DongTrai("Bản gần nhất", cuoi is null ? "Chưa có" : cuoi.Value.ToString("HH:mm dd/MM/yyyy")),
            DongTrai("Tự động", "Mỗi 24 giờ, giữ 7 bản"),
            nutTao,
            AdminUi.Nhan("Gồm tài khoản, món ăn, đơn hàng, khuyến mãi, đánh giá, phản ánh lưu trên máy. CSDL SQL Server cần được sao lưu riêng ở máy chủ (xem hướng dẫn bên dưới).", 11, mo: true)));

        var ds = SaoLuuService.DanhSach();
        var dsView = new VerticalStackLayout { Spacing = 10 };
        if (ds.Count == 0) dsView.Add(AdminUi.Nhan("Chưa có bản sao lưu nào.", 12.5, mo: true));
        foreach (var b in ds)
        {
            var hang = new VerticalStackLayout { Spacing = 4 };
            var tren = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            tren.Add(AdminUi.Nhan($"{b.Luc:HH:mm dd/MM/yyyy} · {b.LyDo}", 12.5, dam: true), 0, 0);
            tren.Add(AdminUi.Chip(b.HopLe ? "Hợp lệ" : "Hỏng", b.HopLe ? AdminUi.Xanh : AdminUi.Do), 1, 0);
            hang.Add(tren);
            hang.Add(AdminUi.Nhan($"{b.TenTep} · {b.KichThuoc / 1024.0:0.#} KB", 11, mo: true));
            var nut = new HorizontalStackLayout { Spacing = 8 };
            var kt = AdminUi.Nut("Kiểm tra", AdminUi.Tim);
            var kp = AdminUi.Nut("Khôi phục", AdminUi.Cam);
            var xoa = AdminUi.Nut("Xóa", AdminUi.Do);
            var ten = b.TenTep;
            kt.Clicked += async (_, _) => { var r = SaoLuuService.KiemTra(ten); await DisplayAlert(r.Ok ? "Khôi phục được ✅" : "Không khôi phục được ❌", r.MoTa, "OK"); };
            kp.Clicked += async (_, _) =>
            {
                if (!await DisplayAlert("Khôi phục dữ liệu", "Dữ liệu hiện tại sẽ được sao lưu trước, rồi nạp lại từ bản này. Tiếp tục?", "Khôi phục", "Hủy")) return;
                var r = SaoLuuService.KhoiPhuc(ten);
                NhatKyService.GhiQuanTri("Khôi phục dữ liệu", ten, r.ThongDiep, r.Ok);
                await DisplayAlert(r.Ok ? "Đã khôi phục" : "Thất bại", r.ThongDiep, "OK");
                Nd.Children.Clear(); await DungAsync();
            };
            xoa.Clicked += async (_, _) =>
            {
                if (!await DisplayAlert("Xóa bản sao lưu", "Xóa bản sao lưu này?", "Xóa", "Hủy")) return;
                SaoLuuService.Xoa(ten); NhatKyService.GhiQuanTri("Xóa bản sao lưu", ten);
                Nd.Children.Clear(); await DungAsync();
            };
            nut.Add(kt); nut.Add(kp); nut.Add(xoa);
            hang.Add(nut);
            dsView.Add(hang);
        }
        Nd.Add(KhoiTheo("Các bản sao lưu", dsView));

        Nd.Add(KhoiTheo("Phương án ứng phó sự cố",
            AdminUi.Nhan("1. Mất kết nối máy chủ: ứng dụng chuyển sang dữ liệu trên máy, các thao tác ghi được báo rõ là “chỉ lưu trên máy”.", 12, mo: true),
            AdminUi.Nhan("2. Dữ liệu trên máy bị lỗi: vào đây, chọn bản “Hợp lệ” gần nhất và khôi phục.", 12, mo: true),
            AdminUi.Nhan("3. Sự cố CSDL SQL Server: dùng bản sao lưu .bak định kỳ của máy chủ (BACKUP DATABASE) và thử RESTORE trên môi trường kiểm thử mỗi tháng.", 12, mo: true),
            AdminUi.Nhan("4. Dịch vụ ngoài (VNPay, bản đồ) lỗi: đơn giữ ở trạng thái “chờ thanh toán”, khách có thể thanh toán lại; quản trị đối soát ở mục Thanh toán.", 12, mo: true)));
        return Task.CompletedTask;
    }
}

// ============================================================ 3. BẢO MẬT & QUYỀN RIÊNG TƯ
public sealed class AdminBaoMatPage : AdminKyThuatTrang
{
    public AdminBaoMatPage() : base("Bảo mật & quyền riêng tư") { }

    protected override async Task DungAsync()
    {
        bool https = AppSettings.BaseUrl.StartsWith("https://", StringComparison.OrdinalIgnoreCase);
        var vaiTro = MockData.QuanTriVienHienTai.VaiTro;
        var quyen = Enum.GetValues<Quyen>().Where(PhanQuyenService.Co).ToList();
        int nhatKy = NhatKyService.TatCa().Count;
        int nhay = NhatKyService.TatCa().Count(x => x.HanhDong.Contains("khóa", StringComparison.OrdinalIgnoreCase) || x.HanhDong.Contains("hoàn tiền", StringComparison.OrdinalIgnoreCase)
            || x.HanhDong.Contains("duyệt", StringComparison.OrdinalIgnoreCase) || x.HanhDong.Contains("khôi phục", StringComparison.OrdinalIgnoreCase));
        PermissionStatus viTri;
        try { viTri = await Permissions.CheckStatusAsync<Permissions.LocationWhenInUse>(); } catch { viTri = PermissionStatus.Unknown; }

        Nd.Add(KhoiTheo("Kiểm tra bảo mật",
            DongKiemTra(https, "Mã hóa kết nối (HTTPS/TLS)", https ? "Ứng dụng đang gọi máy chủ qua HTTPS." : $"Đang dùng {AppSettings.BaseUrl} — chỉ chấp nhận khi chạy thử; khi vận hành phải dùng HTTPS.", canhBao: !https),
            DongKiemTra(!string.IsNullOrEmpty(ApiClient.Token) || !DuLieuService.DangOnline, "Phiên đăng nhập (JWT)", "Token chỉ giữ trong bộ nhớ, không ghi ra đĩa; máy chủ trả 401 thì ứng dụng tự đăng xuất."),
            DongKiemTra(true, "Bảo vệ mật khẩu", "Mật khẩu được băm kèm muối ngẫu nhiên (MatKhauHelper); máy chủ khóa tạm khi nhập sai nhiều lần."),
            DongKiemTra(true, "Phân quyền theo vai trò", $"Bạn là {vaiTro.Nhan()} với {quyen.Count}/{Enum.GetValues<Quyen>().Length} quyền. Thao tác nhạy cảm (khóa tài khoản, duyệt hồ sơ, hoàn tiền) được kiểm tra quyền trước khi thực hiện."),
            DongKiemTra(nhatKy > 0, "Nhật ký thao tác nhạy cảm", $"Đã ghi {nhatKy} thao tác, trong đó {nhay} thao tác khóa / duyệt / hoàn tiền / khôi phục.", canhBao: nhatKy == 0)));

        Nd.Add(KhoiTheo("Quyền của vai trò hiện tại",
            DongTrai("Vai trò", vaiTro.Nhan()),
            new Label { Text = string.Join("\n", Enum.GetValues<Quyen>().Select(q => (PhanQuyenService.Co(q) ? "✔ " : "✖ ") + MoTaQuyen(q))), FontSize = 12, LineHeight = 1.3 }));

        Nd.Add(KhoiTheo("Quyền riêng tư & định vị",
            DongKiemTra(viTri == PermissionStatus.Granted, "Quyền vị trí trên thiết bị này",
                viTri == PermissionStatus.Granted ? "Đã cho phép (chỉ dùng khi đang mở ứng dụng)." : "Chưa cấp. Ứng dụng chỉ hỏi khi dùng bản đồ / giao hàng và luôn cần bạn cho phép.", canhBao: viTri != PermissionStatus.Granted),
            DongKiemTra(true, "Dữ liệu cá nhân", "Khách có thể sửa hồ sơ và xóa tài khoản; quản trị chỉ xem dữ liệu khách theo quyền được cấp và mọi lần xem/sửa đều ghi nhật ký."),
            DongKiemTra(true, "Che thông tin nhạy cảm", "Mật khẩu và mã xác nhận giao hàng không hiển thị trong màn quản trị.")));

        var nut = AdminUi.Nut("Mở nhật ký hệ thống", AdminUi.Tim, day: true);
        nut.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(AdminAuditLogPage));
        Nd.Add(nut);
        Nd.Add(AdminUi.Nhan("Đây là bảng kiểm tra tự động từ cấu hình hiện có, chưa phải kết quả kiểm thử thâm nhập hay đánh giá bảo mật độc lập.", 11, mo: true));
    }

    private static string MoTaQuyen(Quyen q) => q switch
    {
        Quyen.XemTaiKhoan => "Xem tài khoản khách / gian hàng / tài xế",
        Quyen.KhoaMoTaiKhoan => "Khóa / mở khóa tài khoản",
        Quyen.DuyetHoSo => "Duyệt hồ sơ gian hàng, tài xế",
        Quyen.XuLyVanDe => "Xử lý khiếu nại, sự cố",
        Quyen.HoanTien => "Hủy đơn và hoàn tiền",
        Quyen.QuanLyKhuyenMai => "Quản lý khuyến mãi toàn hệ thống",
        Quyen.XemThongKe => "Xem thống kê & báo cáo",
        Quyen.XemNhatKy => "Xem nhật ký thao tác",
        Quyen.QuanLyNhanVien => "Quản lý tài khoản quản trị",
        _ => q.ToString(),
    };
}

// ============================================================ 4. QUY TRÌNH HOẠT ĐỘNG TỔNG THỂ
public sealed class AdminQuyTrinhPage : AdminKyThuatTrang
{
    public AdminQuyTrinhPage() : base("Quy trình hoạt động") { }

    protected override async Task DungAsync()
    {
        if (DuLieuService.DangOnline) { try { await DuLieuService.TaiDonToanHeThongAsync(); } catch (Exception ex) { CrashLog.Ghi("QuyTrinh.Tai", ex); } }
        var ds = MockData.TatCaDonHangHeThong.ToList();
        var homNay = ds.Where(d => d.NgayDat.Date == DateTime.Today).ToList();

        int choQuan = ds.Count(d => d.TrangThai == TrangThaiDonHang.ChoXacNhan);
        int quanLam = ds.Count(d => d.TrangThai == TrangThaiDonHang.DangLam && !d.SanSangGiao);
        int choTaiXe = ds.Count(d => d.DangChoTaiXe);
        int dangGiao = ds.Count(d => d.TrangThai == TrangThaiDonHang.DangGiao || (d.TrangThai == TrangThaiDonHang.DangLam && d.SanSangGiao && !string.IsNullOrEmpty(d.TaiXeId)));
        int xong = homNay.Count(d => d.TrangThai == TrangThaiDonHang.HoanThanh);
        int huy = homNay.Count(d => d.TrangThai == TrangThaiDonHang.DaHuy);

        Nd.Add(AdminUi.Nhan("Đường đi của một đơn hàng và số đơn đang ở từng bước (cập nhật theo dữ liệu hiện có).", 12, mo: true));
        Nd.Add(Buoc(1, "Khách hàng", "Tìm món, chọn nhà hàng, nhập địa chỉ và đặt hàng", $"{homNay.Count} đơn đặt hôm nay", AdminUi.Tim, null));
        Nd.Add(Buoc(2, "Backend", "Kiểm tra món, giá, địa chỉ, ưu đãi, thanh toán và tạo đơn", $"Chống tạo trùng bằng mã yêu cầu đặt · {homNay.Count(d => d.TrangThaiThanhToan == "ChoThanhToan")} đơn chờ thanh toán", AdminUi.Tim, null));
        Nd.Add(Buoc(3, "Nhà hàng", "Xác nhận đơn, chế biến và chuẩn bị bàn giao món", $"{choQuan} chờ xác nhận · {quanLam} đang chế biến", choQuan > 0 ? AdminUi.Cam : AdminUi.Tim, nameof(AdminOrdersPage)));
        Nd.Add(Buoc(4, "Tài xế", "Nhận chuyến, đến lấy món, di chuyển tới địa chỉ khách", $"{choTaiXe} chờ tài xế · {dangGiao} đang giao", choTaiXe > 0 ? AdminUi.Cam : AdminUi.Tim, nameof(AdminDispatchPage)));
        Nd.Add(Buoc(5, "Hoàn thành đơn", "Xác nhận kết quả, cập nhật thanh toán và lưu lịch sử", $"{xong} hoàn thành · {huy} hủy hôm nay", AdminUi.Xanh, nameof(AdminPaymentsPage)));

        var giamSat = AdminUi.The(14);
        var st = new VerticalStackLayout { Spacing = 4 };
        st.Add(AdminUi.Nhan("🛡 Hệ thống quản trị theo dõi xuyên suốt", 13.5, dam: true));
        st.Add(AdminUi.Nhan("Đơn hàng · người dùng · nhà hàng · tài xế · tài chính · báo cáo — mọi thao tác can thiệp đều qua kiểm tra quyền và ghi nhật ký.", 11.5, mo: true));
        giamSat.Content = st;
        Nd.Add(giamSat);
    }

    private View Buoc(int so, string ten, string moTa, string soLieu, string mau, string? route)
    {
        var the = AdminUi.The(12);
        var g = new Grid { ColumnSpacing = 12, ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) } };
        var huy = new Border
        {
            WidthRequest = 34, HeightRequest = 34, StrokeThickness = 0, BackgroundColor = Color.FromArgb(mau), VerticalOptions = LayoutOptions.Start,
            StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(17) },
            Content = new Label { Text = so.ToString(), TextColor = Colors.White, FontAttributes = FontAttributes.Bold, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center },
        };
        g.Add(huy, 0, 0);
        var st = new VerticalStackLayout { Spacing = 2 };
        st.Add(AdminUi.Nhan($"Bước {so}. {ten}", 14, dam: true));
        st.Add(AdminUi.Nhan(moTa, 11.5, mo: true));
        var sl = AdminUi.Nhan(soLieu, 12.5, dam: true); sl.TextColor = Color.FromArgb(mau);
        st.Add(sl);
        g.Add(st, 1, 0);
        the.Content = g;
        if (route != null)
        {
            var tap = new TapGestureRecognizer();
            tap.Tapped += async (_, _) => await Shell.Current.GoToAsync(route);
            the.GestureRecognizers.Add(tap);
        }
        return the;
    }
}


// ============================================================ KHÓA BẢN ĐỒ GOONG
public sealed class AdminGoongPage : AdminKyThuatTrang
{
    public AdminGoongPage() : base("Khóa bản đồ Goong") { }

    protected override async Task DungAsync()
    {
        var r = await GoongKhoaService.XemAsync();
        if (!r.ThanhCong || r.DuLieu is null)
        {
            Nd.Add(AdminUi.Nhan(r.MaHttp == 403 ? "Chỉ Admin tổng được xem và đổi khóa bản đồ." : "Không tải được trạng thái: " + r.ThongDiep, 13, mo: true));
            return;
        }
        var t = r.DuLieu;
        Nd.Add(KhoiTheo("Trạng thái",
            DongKiemTra(t.DaCauHinh, t.DaCauHinh ? "Đã có khóa Goong" : "Chưa có khóa Goong hợp lệ",
                t.DaCauHinh ? $"Khóa: {t.KhoaDaAn}\nNguồn: {t.Nguon}" : "Chưa có khóa thì lộ trình đường thật không chạy; app dùng bản ước tính theo quận/huyện.", canhBao: !t.DaCauHinh)));

        var o = new Entry { Placeholder = "Dán khóa API Goong (đủ 1 chuỗi)", IsPassword = true, FontSize = 13, ClearButtonVisibility = ClearButtonVisibility.WhileEditing };
        var luu = AdminUi.Nut("Lưu khóa", AdminUi.Tim, day: true);
        luu.Clicked += async (_, _) =>
        {
            var khoa = (o.Text ?? "").Trim();
            if (khoa.Length == 0) { await DisplayAlert("Thiếu khóa", "Hãy dán khóa Goong vào ô trên.", "Đóng"); return; }
            luu.IsEnabled = false;
            try
            {
                var (ok, tb, _) = await GoongKhoaService.LuuAsync(khoa);
                await DisplayAlert(ok ? "Đã lưu" : "Không lưu được", tb, "Đóng");
                if (ok) { o.Text = ""; await Shell.Current.GoToAsync(".."); await Shell.Current.GoToAsync(nameof(AdminGoongPage)); }
            }
            finally { luu.IsEnabled = true; }
        };
        var thu = AdminUi.Nut("Kiểm tra khóa đang dùng", AdminUi.Xanh);
        thu.Clicked += async (_, _) =>
        {
            thu.IsEnabled = false;
            try { var (ok, tb) = await GoongKhoaService.KiemTraAsync(); await DisplayAlert(ok ? "Khóa hoạt động" : "Chưa dùng được", tb, "Đóng"); }
            finally { thu.IsEnabled = true; }
        };
        var xoa = AdminUi.Nut("Xóa khóa đã nhập trong ứng dụng", AdminUi.Do);
        xoa.Clicked += async (_, _) =>
        {
            if (!await DisplayAlert("Xóa khóa?", "Hệ thống sẽ dùng lại khóa trong appsettings (nếu có).", "Xóa", "Hủy")) return;
            var (ok, tb, _) = await GoongKhoaService.LuuAsync("");
            await DisplayAlert(ok ? "Đã xóa" : "Không xóa được", tb, "Đóng");
            if (ok) { await Shell.Current.GoToAsync(".."); await Shell.Current.GoToAsync(nameof(AdminGoongPage)); }
        };
        Nd.Add(KhoiTheo("Nhập khóa mới", o, luu, thu, xoa));
        Nd.Add(AdminUi.Nhan("Khóa được lưu ở máy chủ, ưu tiên hơn GoongMaps:ApiKey trong appsettings và không bao giờ gửi đầy đủ về ứng dụng. Lấy khóa tại account.goong.io (bật Geocode, Distance Matrix, Direction).", 11, mo: true));
    }
}


// ============================================================ BÁO CÁO KINH DOANH NÂNG CAO
public sealed class AdminBaoCaoNangCaoPage : AdminKyThuatTrang
{
    private int _ngay = 30;
    public AdminBaoCaoNangCaoPage() : base("Báo cáo kinh doanh nâng cao") { }

    private static string TangTruong(JsonElement d, string k)
    {
        if (!J.Co(d, k, out var v) || v.ValueKind != JsonValueKind.Number) return "chưa có kỳ trước để so";
        var x = v.GetDouble();
        return (x >= 0 ? "▲ +" : "▼ ") + x.ToString("0.#") + "% so với kỳ trước";
    }

    private static string MauTang(JsonElement d, string k) =>
        J.Co(d, k, out var v) && v.ValueKind == JsonValueKind.Number ? (v.GetDouble() >= 0 ? AdminUi.Xanh : AdminUi.Do) : AdminUi.Xam;

    private static View Thanh(string nhan, double gia, double max, string chu, string mau)
    {
        var st = new VerticalStackLayout { Spacing = 2 };
        var hang = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
        hang.Add(AdminUi.Nhan(nhan, 12), 0, 0);
        hang.Add(AdminUi.Nhan(chu, 12, dam: true), 1, 0);
        st.Add(hang);
        st.Add(new ProgressBar { Progress = Math.Clamp(max <= 0 ? 0 : gia / max, 0, 1), ProgressColor = Color.FromArgb(mau), HeightRequest = 6 });
        return st;
    }

    private static View Kpi(string nhan, string giaTri, string phu, string mauPhu)
    {
        var st = new VerticalStackLayout { Spacing = 1 };
        st.Add(AdminUi.Nhan(nhan, 11.5, mo: true));
        st.Add(AdminUi.Nhan(giaTri, 18, dam: true));
        var p = AdminUi.Nhan(phu, 11.5); p.TextColor = Color.FromArgb(mauPhu);
        st.Add(p);
        return st;
    }

    protected override async Task DungAsync()
    {
        var thanh = new HorizontalStackLayout { Spacing = 8 };
        foreach (var n in new[] { 7, 30, 90 })
        {
            var so = n;
            var nut = AdminUi.Nut($"{n} ngày", AdminUi.Tim, day: so == _ngay);
            nut.Clicked += async (_, _) => { _ngay = so; await TaiLaiAsync(); };
            thanh.Add(nut);
        }
        Nd.Add(thanh);

        var r = await ApiClient.GetAsync<JsonElement>($"api/mobile/admin/bao-cao-nang-cao?ngay={_ngay}");
        if (!r.ThanhCong)
        {
            Nd.Add(AdminUi.Nhan(r.MatKetNoi ? "Báo cáo cần kết nối máy chủ (online).\n" + r.ThongDiep : r.ThongDiep, 13, mo: true));
            return;
        }
        var d = r.DuLieu;

        Nd.Add(KhoiTheo($"Tổng quan {_ngay} ngày gần nhất",
            Kpi("Doanh thu (GMV đơn đã giao)", AdminUi.Tien(J.D(d, "gmv")), TangTruong(d, "gmvTangTruong"), MauTang(d, "gmvTangTruong")),
            Kpi("Số đơn hoàn thành", J.L(d, "soDon").ToString("N0"), TangTruong(d, "soDonTangTruong"), MauTang(d, "soDonTangTruong")),
            Kpi("Giá trị đơn trung bình", AdminUi.Tien(J.D(d, "aov")), TangTruong(d, "aovTangTruong"), MauTang(d, "aovTangTruong")),
            Kpi("Tỷ lệ hủy", $"{J.D(d, "tyLeHuy"):0.#}%", $"{J.L(d, "donHuy")} đơn hủy (kỳ trước {J.L(d, "donHuyTruoc")})", AdminUi.Xam),
            Kpi("Khách quay lại (≥ 2 đơn trong kỳ)", $"{J.D(d, "tyLeQuayLai"):0.#}%", $"{J.L(d, "khachQuayLai")}/{J.L(d, "khachCoDon")} khách có đơn", AdminUi.Xam)));

        var gio = J.Mang(d, "theoGio").ToList();
        double maxGio = gio.Count == 0 ? 1 : gio.Max(x => (double)J.L(x, "soDon"));
        var cao = gio.OrderByDescending(x => J.L(x, "soDon")).Take(3).Where(x => J.L(x, "soDon") > 0).Select(x => $"{J.L(x, "gio")}h").ToList();
        Nd.Add(KhoiTheo("⏰ Giờ cao điểm" + (cao.Count > 0 ? " — " + string.Join(", ", cao) : ""),
            gio.Where(x => J.L(x, "soDon") > 0).Select(x => Thanh($"{J.L(x, "gio"):00}:00", J.L(x, "soDon"), maxGio, $"{J.L(x, "soDon")} đơn", AdminUi.Tim)).DefaultIfEmpty(AdminUi.Nhan("Chưa có dữ liệu.", 12, mo: true)).ToArray()));

        var thu = J.Mang(d, "theoThu").ToList();
        double maxThu = thu.Count == 0 ? 1 : thu.Max(x => (double)J.L(x, "soDon"));
        Nd.Add(KhoiTheo("📅 Theo thứ trong tuần",
            thu.Select(x => Thanh(J.S(x, "thu"), J.L(x, "soDon"), maxThu, $"{J.L(x, "soDon")} đơn · {AdminUi.Tien(J.D(x, "doanhThu"))}", AdminUi.Cam)).DefaultIfEmpty(AdminUi.Nhan("Chưa có dữ liệu.", 12, mo: true)).ToArray()));

        var dm = J.Mang(d, "theoDanhMuc").ToList();
        double maxDm = dm.Count == 0 ? 1 : dm.Max(x => (double)J.D(x, "doanhThu"));
        Nd.Add(KhoiTheo("🍽 Doanh thu theo danh mục món",
            dm.Select(x => Thanh(J.S(x, "ten"), (double)J.D(x, "doanhThu"), maxDm, $"{AdminUi.Tien(J.D(x, "doanhThu"))} · {J.L(x, "soLuong")} phần", AdminUi.Xanh)).DefaultIfEmpty(AdminUi.Nhan("Chưa có dữ liệu.", 12, mo: true)).ToArray()));

        View[] Quan(string k) => J.Mang(d, k).Select(x => (View)Thanh(J.S(x, "ten"), (double)Math.Abs(J.D(x, "tangTruongPhanTram")), 100,
            $"{(J.D(x, "tangTruongPhanTram") >= 0 ? "+" : "")}{J.D(x, "tangTruongPhanTram"):0.#}% ({AdminUi.Tien(J.D(x, "doanhThuTruoc"))} → {AdminUi.Tien(J.D(x, "doanhThuNay"))})",
            J.D(x, "tangTruongPhanTram") >= 0 ? AdminUi.Xanh : AdminUi.Do)).ToArray();
        var tang = Quan("quanTangManh"); var giam = Quan("quanGiamManh");
        Nd.Add(KhoiTheo("📈 Gian hàng tăng mạnh nhất", tang.Length > 0 ? tang : new View[] { AdminUi.Nhan("Chưa đủ dữ liệu kỳ trước để so sánh.", 12, mo: true) }));
        Nd.Add(KhoiTheo("📉 Gian hàng giảm mạnh nhất", giam.Length > 0 ? giam : new View[] { AdminUi.Nhan("Chưa đủ dữ liệu kỳ trước để so sánh.", 12, mo: true) }));

        var huy = J.Mang(d, "lyDoHuy").ToList();
        double maxHuy = huy.Count == 0 ? 1 : huy.Max(x => (double)J.L(x, "soDon"));
        Nd.Add(KhoiTheo("🚫 Lý do hủy đơn",
            huy.Select(x => Thanh(J.S(x, "lyDo"), J.L(x, "soDon"), maxHuy, $"{J.L(x, "soDon")} đơn", AdminUi.Do)).DefaultIfEmpty(AdminUi.Nhan("Không có đơn hủy trong kỳ.", 12, mo: true)).ToArray()));

        Nd.Add(AdminUi.Nhan(J.S(d, "ghiChu"), 11, mo: true));
    }

    private async Task TaiLaiAsync()
    {
        Nd.Children.Clear();
        try { await DungAsync(); }
        catch (Exception ex) { CrashLog.Ghi(nameof(AdminBaoCaoNangCaoPage), ex); Nd.Add(AdminUi.Nhan("Không tải được: " + ex.Message, 12.5, mo: true)); }
    }
}


// ============================================================ DASHBOARD (số liệu trực tiếp từ máy chủ)
public sealed class AdminDashboardPage : AdminKyThuatTrang
{
    public AdminDashboardPage() : base("Dashboard") { }

    private static string So(JsonElement d, string k) => J.L(d, k).ToString("N0");

    private static string SoSanh(decimal nay, decimal truoc, string moc)
    {
        if (truoc == 0) return nay > 0 ? $"mới phát sinh (chưa có {moc})" : "chưa có dữ liệu";
        var p = (double)((nay - truoc) / truoc * 100m);
        return (p >= 0 ? "▲ +" : "▼ ") + p.ToString("0.#") + "% so với " + moc;
    }

    private static View The2(string nhan, string giaTri, string phu, string mau)
    {
        var st = new VerticalStackLayout { Spacing = 1 };
        st.Add(AdminUi.Nhan(nhan, 11.5, mo: true));
        var v = AdminUi.Nhan(giaTri, 19, dam: true); v.TextColor = Color.FromArgb(mau);
        st.Add(v);
        st.Add(AdminUi.Nhan(phu, 11, mo: true));
        var the = AdminUi.The(12);
        the.Content = st;
        return the;
    }


    /// <summary>Dựng JSON cùng cấu trúc với api/mobile/admin/dashboard từ dữ liệu cục bộ (MockData).</summary>
    private static JsonElement DuLieuCucBo()
    {
        var now = DateTime.Now; var hn = now.Date; var hq = hn.AddDays(-1);
        var don = MockData.TatCaDonHangHeThong.ToList();
        var xong = don.Where(x => x.TrangThai == TrangThaiDonHang.HoanThanh).ToList();
        decimal Tong(DateTime tu, DateTime den) => xong.Where(x => x.NgayDat.Date >= tu && x.NgayDat.Date < den).Sum(x => x.TongThanhToan);
        var gh = MockData.DanhSachGianHang; var tx = MockData.DanhSachTaiXe;
        var xuHuong = Enumerable.Range(0, 14).Select(i => hn.AddDays(i - 13)).Select(n => new
        {
            ngay = n.ToString("dd/MM"),
            doanhThu = xong.Where(x => x.NgayDat.Date == n).Sum(x => x.TongThanhToan),
            soDon = don.Count(x => x.NgayDat.Date == n)
        }).ToList();
        var obj = new
        {
            capNhatLuc = now,
            nguoiDung = new
            {
                khachHang = MockData.DanhSachKhachHang.Count,
                khachMoiHomNay = MockData.DanhSachKhachHang.Count(k => k.NgayDangKy.Date == hn),
                gianHangDaDuyet = gh.Count(g => g.TrangThaiDangKy == TrangThaiDangKyGianHang.DaDuyet),
                gianHangDangMo = gh.Count(g => g.TrangThaiDangKy == TrangThaiDangKyGianHang.DaDuyet && g.DangMoCua),
                taiXeDaDuyet = tx.Count(t => t.TrangThaiDangKy == TrangThaiDangKyGianHang.DaDuyet),
                taiXeSanSang = tx.Count(t => t.NhanDuocDon),
                taiXeDangGiao = don.Count(x => x.TrangThai == TrangThaiDonHang.DangGiao)
            },
            don = new
            {
                homNay = don.Count(x => x.NgayDat.Date == hn),
                homQua = don.Count(x => x.NgayDat.Date == hq),
                dangXuLy = don.Count(x => x.TrangThai is TrangThaiDonHang.ChoXacNhan or TrangThaiDonHang.DangLam or TrangThaiDonHang.DangGiao),
                chuaCoTaiXe = don.Count(x => x.TrangThai == TrangThaiDonHang.DangLam && string.IsNullOrEmpty(x.TaiXeId)),
                hoanThanhHomNay = xong.Count(x => x.NgayDat.Date == hn),
                huyHomNay = don.Count(x => x.TrangThai == TrangThaiDonHang.DaHuy && x.NgayDat.Date == hn)
            },
            doanhThu = new
            {
                homNay = Tong(hn, hn.AddDays(1)), homQua = Tong(hq, hn),
                tuan = Tong(hn.AddDays(-6), hn.AddDays(1)), tuanTruoc = Tong(hn.AddDays(-13), hn.AddDays(-6)),
                tong = xong.Sum(x => x.TongThanhToan)
            },
            canXuLy = new
            {
                khieuNai = MockData.DanhSachVanDe.Count(v => v.TrangThai != TrangThaiVanDe.DaGiaiQuyet),
                hoanTien = 0,
                gianHangChoDuyet = gh.Count(g => g.TrangThaiDangKy == TrangThaiDangKyGianHang.ChoDuyet),
                taiXeChoDuyet = tx.Count(t => t.TrangThaiDangKy == TrangThaiDangKyGianHang.ChoDuyet),
                baoCaoDanhGia = 0
            },
            xuHuong
        };
        return JsonDocument.Parse(JsonSerializer.Serialize(obj)).RootElement.Clone();
    }

    protected override async Task DungAsync()
    {
        var r = await ApiClient.GetAsync<JsonElement>("api/mobile/admin/dashboard");
        JsonElement d;
        if (r.ThanhCong) d = r.DuLieu;
        else if (r.MatKetNoi)
        {
            // Không có máy chủ: tính số liệu từ dữ liệu lưu trên máy để Dashboard vẫn dùng được.
            d = DuLieuCucBo();
            Nd.Add(AdminUi.Nhan("⚠️ Chế độ ngoại tuyến — số liệu tính từ dữ liệu trên máy (" + AppSettings.BaseUrl + " không phản hồi). Kéo xuống để thử lại.", 12, mo: true));
        }
        else { Nd.Add(AdminUi.Nhan(r.ThongDiep, 13, mo: true)); return; }
        var nd = J.Doi(d, "nguoiDung"); var don = J.Doi(d, "don"); var dt = J.Doi(d, "doanhThu"); var cx = J.Doi(d, "canXuLy");

        Nd.Add(AdminUi.Nhan("Cập nhật " + J.Ngay(d, "capNhatLuc", "HH:mm dd/MM/yyyy") + " · kéo xuống để làm mới", 11, mo: true));

        var luoi = new Grid { ColumnSpacing = 10, RowSpacing = 10, ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Star) } };
        var the = new[]
        {
            The2("Doanh thu hôm nay", AdminUi.Tien(J.D(dt, "homNay")), SoSanh(J.D(dt, "homNay"), J.D(dt, "homQua"), "hôm qua"), AdminUi.Tim),
            The2("Doanh thu 7 ngày", AdminUi.Tien(J.D(dt, "tuan")), SoSanh(J.D(dt, "tuan"), J.D(dt, "tuanTruoc"), "7 ngày trước"), AdminUi.Tim),
            The2("Đơn hôm nay", So(don, "homNay"), SoSanh(J.L(don, "homNay"), J.L(don, "homQua"), "hôm qua"), AdminUi.Xanh),
            The2("Đang xử lý", So(don, "dangXuLy"), $"{J.L(don, "chuaCoTaiXe")} đơn chưa có tài xế", AdminUi.Cam),
            The2("Hoàn thành / hủy hôm nay", $"{J.L(don, "hoanThanhHomNay")} / {J.L(don, "huyHomNay")}", "đơn", AdminUi.Xanh),
            The2("Khách hàng", So(nd, "khachHang"), $"+{J.L(nd, "khachMoiHomNay")} hôm nay", AdminUi.Tim),
            The2("Nhà hàng", So(nd, "gianHangDaDuyet"), $"{J.L(nd, "gianHangDangMo")} đang mở", AdminUi.Cam),
            The2("Tài xế", So(nd, "taiXeDaDuyet"), $"{J.L(nd, "taiXeSanSang")} sẵn sàng · {J.L(nd, "taiXeDangGiao")} đang giao", AdminUi.Xanh),
        };
        for (var i = 0; i < the.Length; i++) luoi.Add(the[i], i % 2, i / 2);
        for (var i = 0; i < the.Length / 2; i++) luoi.RowDefinitions.Add(new RowDefinition(GridLength.Auto));
        Nd.Add(luoi);
        Nd.Add(AdminUi.Nhan($"Tổng doanh thu đơn đã giao từ trước tới nay: {AdminUi.Tien(J.D(dt, "tong"))}", 12, mo: true));

        var xh = J.Mang(d, "xuHuong").ToList();
        double max = xh.Count == 0 ? 1 : Math.Max(1, xh.Max(x => (double)J.D(x, "doanhThu")));
        var bd = xh.Select(x =>
        {
            var st = new VerticalStackLayout { Spacing = 2 };
            var hang = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) } };
            hang.Add(AdminUi.Nhan(J.S(x, "ngay"), 12), 0, 0);
            hang.Add(AdminUi.Nhan($"{AdminUi.Tien(J.D(x, "doanhThu"))} · {J.L(x, "soDon")} đơn", 12, dam: true), 1, 0);
            st.Add(hang);
            st.Add(new ProgressBar { Progress = Math.Clamp((double)J.D(x, "doanhThu") / max, 0, 1), ProgressColor = Color.FromArgb(AdminUi.Tim), HeightRequest = 6 });
            return (View)st;
        }).ToArray();
        Nd.Add(KhoiTheo("📈 Doanh thu & số đơn 14 ngày", bd.Length > 0 ? bd : new View[] { AdminUi.Nhan("Chưa có dữ liệu.", 12, mo: true) }));

        var cho = new (string Ten, long So, string Route)[]
        {
            ("📨 Khiếu nại chưa xử lý", J.L(cx, "khieuNai"), nameof(AdminKhieuNaiPage)),
            ("↩️ Hoàn tiền chờ duyệt", J.L(cx, "hoanTien"), nameof(AdminPaymentsPage)),
            ("✅ Quán chờ duyệt", J.L(cx, "gianHangChoDuyet"), nameof(AdminVendorApprovalPage)),
            ("📝 Tài xế chờ duyệt", J.L(cx, "taiXeChoDuyet"), nameof(AdminDriverApprovalPage)),
            ("⭐ Báo cáo đánh giá", J.L(cx, "baoCaoDanhGia"), nameof(AdminReviewsPage)),
        };
        var dong = cho.Select(c =>
        {
            var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Star), new ColumnDefinition(GridLength.Auto) }, ColumnSpacing = 8, Padding = new Thickness(0, 4) };
            g.Add(AdminUi.Nhan(c.Ten, 13), 0, 0);
            var so = AdminUi.Nhan(c.So.ToString(), 14, dam: true); so.TextColor = Color.FromArgb(c.So > 0 ? AdminUi.Do : AdminUi.Xam);
            g.Add(so, 1, 0);
            var tap = new TapGestureRecognizer();
            var route = c.Route;
            tap.Tapped += async (_, _) => await Shell.Current.GoToAsync(route);
            g.GestureRecognizers.Add(tap);
            return (View)g;
        }).ToArray();
        Nd.Add(KhoiTheo("🔔 Việc cần xử lý (chạm để mở)", dong));
    }
}

// ============================================================ DÒNG THÔNG BÁO TRANG CHỦ
public sealed class AdminThongBaoTrangChuPage : AdminKyThuatTrang
{
    public AdminThongBaoTrangChuPage() : base("Thông báo trang chủ") { }

    protected override async Task DungAsync()
    {
        var r = await ApiClient.GetAsync<JsonElement>("api/mobile/admin/trang-chu/thong-bao");
        if (!r.ThanhCong) { Nd.Add(AdminUi.Nhan(r.ThongDiep, 13, mo: true)); return; }
        var o1 = new Editor { Placeholder = "Ví dụ: Miễn phí giao hàng cuối tuần này!", MaxLength = 200, AutoSize = EditorAutoSizeOption.TextChanges, FontSize = 13, Text = J.S(r.DuLieu, "noiDung"), HeightRequest = 80 };
        var o2 = new Entry { Placeholder = "Liên kết khi bấm (tùy chọn, / hoặc http(s)://)", Keyboard = Keyboard.Url, FontSize = 13, Text = J.S(r.DuLieu, "lienKet") };
        var luu = AdminUi.Nut("Lưu và hiển thị", AdminUi.Tim, day: true);
        luu.Clicked += async (_, _) =>
        {
            luu.IsEnabled = false;
            try { await AdminUi.Put(this, "api/mobile/admin/trang-chu/thong-bao", new { noiDung = o1.Text ?? "", lienKet = o2.Text ?? "" }, "Cập nhật thông báo trang chủ", (o1.Text ?? "").Trim()); }
            finally { luu.IsEnabled = true; }
        };
        var tat = AdminUi.Nut("Tắt thông báo", AdminUi.Do);
        tat.Clicked += async (_, _) =>
        {
            if (await AdminUi.Put(this, "api/mobile/admin/trang-chu/thong-bao", new { noiDung = "", lienKet = "" }, "Tắt thông báo trang chủ")) { o1.Text = ""; o2.Text = ""; }
        };
        Nd.Add(KhoiTheo("Dòng thông báo ở đầu trang chủ khách", o1, o2, luu, tat));
        Nd.Add(AdminUi.Nhan("Hiển thị cho mọi khách ở đầu trang chủ (tối đa 200 ký tự). Để trống hoặc bấm Tắt để ẩn. Cần quyền quản lý nội dung/thông báo; mọi thay đổi được ghi vào nhật ký.", 11, mo: true));
    }
}
