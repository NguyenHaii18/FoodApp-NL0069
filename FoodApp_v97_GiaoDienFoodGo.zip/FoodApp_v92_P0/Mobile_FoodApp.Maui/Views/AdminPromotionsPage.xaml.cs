using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Dòng hiển thị một khuyến mãi trong màn quản trị.</summary>
public class KhuyenMaiVm
{
    public KhuyenMai Km { get; init; } = null!;
    public bool DangDienRa => Km.DangHoatDong && !Km.ChuaBatDau && Km.ConHan && Km.ConLuot;
    public bool SapHetHan => DangDienRa && Km.NgayKetThuc <= DateTime.Now.AddDays(7);
    public bool HetHanHoacTat => !Km.DangHoatDong || !Km.ConHan || !Km.ConLuot;
    public string Tile => Km.LoaiGiam == LoaiGiamGia.PhanTram ? $"-{Km.GiaTriGiam:0.#}%"
        : Km.LoaiGiam == LoaiGiamGia.GiamPhiVanChuyen ? "Freeship"
        : $"-{Km.GiaTriGiam / 1000:0.#}k";
    public string PhuText => $"{Km.PhamViHienThi} • HSD {Km.NgayKetThuc:dd/MM/yyyy}";
    public string MaText => $"{Km.MaCode} · {Km.GiaTriGiamHienThi}";
    public string DaDungText => $"Đã dùng {Km.SoLuongDaDung}/{Km.SoLuongToiDa} lượt";
    public string TrangThaiText => !Km.DangHoatDong ? "Đã tắt" : Km.ChuaBatDau ? "Sắp diễn ra" : !Km.ConHan ? "Hết hạn"
        : !Km.ConLuot ? "Hết lượt" : SapHetHan ? "Sắp hết hạn" : "Đang diễn ra";
    public Color MauTT => Color.FromArgb(!Km.DangHoatDong || !Km.ConHan || !Km.ConLuot ? "#6B7280" : Km.ChuaBatDau ? "#1D4ED8" : SapHetHan ? "#B45309" : "#15803D");
    public Color NenTT => Color.FromArgb(!Km.DangHoatDong || !Km.ConHan || !Km.ConLuot ? "#F3F4F6" : Km.ChuaBatDau ? "#DBEAFE" : SapHetHan ? "#FEF3C7" : "#DCFCE7");
}

public partial class AdminPromotionsPage : ContentPage
{
    // "__all__" = tất cả, "" = toàn hệ thống, còn lại = GianHangId cụ thể
    private string? _dangLoc = "__all__";
    private int _tab;
    private readonly List<Button> _nutTab = new();
    private readonly List<string?> _idPhamVi = new();
    private bool _dangDungPicker;
    private static readonly string[] NhanTab = { "Tất cả", "Đang diễn ra", "Sắp hết hạn", "Hết hạn / tắt" };

    public AdminPromotionsPage()
    {
        InitializeComponent();
        for (int i = 0; i < NhanTab.Length; i++)
        {
            int chiSo = i;
            var nut = AdminUi.NutTab(NhanTab[i], i == 0);
            nut.Clicked += (_, _) => ChonTab(chiSo);
            _nutTab.Add(nut);
            KhungTab.Children.Add(nut);
        }
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        if (!await Services.PhanQuyenService.KiemTraAsync(this, Services.Quyen.QuanLyKhuyenMai)) { await Shell.Current.GoToAsync(".."); return; }
        DungBoLoc();
        NapDanhSach();
        await TaiTuMayChuAsync();
    }

    /// <summary>Online: lấy mọi khuyến mãi (kể cả đã tắt/hết hạn) từ máy chủ rồi vẽ lại.</summary>
    private async Task TaiTuMayChuAsync()
    {
        var loi = await KhuyenMaiQuanLyService.TaiAsync(admin: true);
        NapDanhSach();
        if (loi is not null) await DisplayAlert("Không tải được khuyến mãi", loi, "Đóng");
    }

    private void DungBoLoc()
    {
        _dangDungPicker = true;
        _idPhamVi.Clear();
        PhamViPicker.Items.Clear();
        PhamViPicker.Items.Add("Tất cả phạm vi"); _idPhamVi.Add("__all__");
        PhamViPicker.Items.Add("Toàn hệ thống"); _idPhamVi.Add("");
        foreach (var g in MockData.DanhSachGianHang.Where(g => g.TrangThaiDangKy == TrangThaiDangKyGianHang.DaDuyet))
        {
            PhamViPicker.Items.Add(g.TenGianHang);
            _idPhamVi.Add(g.Id);
        }
        int vt = _idPhamVi.IndexOf(_dangLoc);
        PhamViPicker.SelectedIndex = vt < 0 ? 0 : vt;
        _dangDungPicker = false;
    }

    private void OnPhamViChanged(object? sender, EventArgs e)
    {
        if (_dangDungPicker) return;
        int i = PhamViPicker.SelectedIndex;
        if (i < 0 || i >= _idPhamVi.Count) return;
        _dangLoc = _idPhamVi[i];
        NapDanhSach();
    }

    private void ChonTab(int i)
    {
        _tab = i;
        for (int k = 0; k < _nutTab.Count; k++)
        {
            _nutTab[k].BackgroundColor = AdminUi.MauTab(k == i);
            _nutTab[k].TextColor = AdminUi.MauChuTab(k == i);
        }
        NapDanhSach();
    }

    private void NapDanhSach()
    {
        var danhSach = MockData.DanhSachKhuyenMai.AsEnumerable();

        if (_dangLoc == "")
            danhSach = danhSach.Where(k => k.ApDungToanHeThong);
        else if (_dangLoc != "__all__")
            danhSach = danhSach.Where(k => k.GianHangId == _dangLoc);

        var vm = danhSach.OrderByDescending(k => k.NgayBatDau).Select(k => new KhuyenMaiVm { Km = k });
        vm = _tab switch
        {
            1 => vm.Where(v => v.DangDienRa),
            2 => vm.Where(v => v.SapHetHan),
            3 => vm.Where(v => v.HetHanHoacTat),
            _ => vm,
        };
        DsKhuyenMai.ItemsSource = vm.ToList();
    }

    private async void OnBatTatToggled(object? sender, ToggledEventArgs e)
    {
        if (sender is not Switch { BindingContext: KhuyenMaiVm vm }) return;
        var km = vm.Km;
        if (km.DangHoatDong == e.Value) return;   // vẽ lại danh sách cũng gây Toggled: bỏ qua khi không đổi

        if (KhuyenMaiQuanLyService.Online)
        {
            var loi = await KhuyenMaiQuanLyService.BatTatAsync(km, e.Value, admin: true);
            if (loi is not null)
            {
                await DisplayAlert("Không đổi được trạng thái", loi, "Đóng");
                NapDanhSach();   // trả công tắc về trạng thái thật
                return;
            }
        }
        km.DangHoatDong = e.Value;
        Services.VendorLocalStore.Luu();
        Services.NhatKyService.GhiQuanTri(e.Value ? "Bật khuyến mãi" : "Tắt khuyến mãi", km.MaCode);
        NapDanhSach();
    }

    private async void OnThemClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync(nameof(AdminPromotionEditPage));
    }

    private async void OnXoaClicked(object sender, EventArgs e)
    {
        if (sender is not Button { CommandParameter: KhuyenMai km }) return;

        bool xacNhan = await DisplayAlert("Xóa khuyến mãi", $"Xóa mã \"{km.MaCode}\" ({km.PhamViHienThi})?", "Xóa", "Hủy");
        if (!xacNhan) return;

        if (KhuyenMaiQuanLyService.Online)
        {
            var loi = await KhuyenMaiQuanLyService.XoaAsync(km, admin: true);
            if (loi is not null) { await DisplayAlert("Không xóa được", loi, "Đóng"); return; }
        }
        MockData.DanhSachKhuyenMai.Remove(km);
        Services.VendorLocalStore.Luu();
        Services.NhatKyService.GhiQuanTri("Xóa khuyến mãi", km.MaCode);

        NapDanhSach();
    }

    private async void OnRefreshing(object? sender, EventArgs e)
    {
        await TaiTuMayChuAsync();
        RefreshDsKm.IsRefreshing = false;
    }
}
