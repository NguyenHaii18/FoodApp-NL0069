using System.Text.Json;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>v69 — Phiên đăng nhập theo thiết bị: máy chủ ghi mỗi lần đăng nhập app (api/mobile/tai-khoan/phien).</summary>
public static class PhienMayChu
{
    public sealed class PhienDto
    {
        public Guid Id { get; set; }
        public string? Kenh { get; set; }
        public string? ThietBi { get; set; }
        public string? DiaChiIp { get; set; }
        public DateTime NgayTao { get; set; }
        public DateTime LanCuoi { get; set; }
        public bool HienTai { get; set; }
    }

    /// <summary>Đăng xuất: thu hồi phiên hiện tại ở máy chủ (cố gắng hết sức, lỗi mạng thì bỏ qua).</summary>
    public static async Task ThuHoiPhienHienTaiAsync()
    {
        try
        {
            if (!DuLieuService.DangOnline || string.IsNullOrEmpty(ApiClient.Token)) return;
            var r = await ApiClient.GetAsync<List<PhienDto>>("api/mobile/tai-khoan/phien");
            var p = r.DuLieu?.FirstOrDefault(x => x.HienTai);
            if (p is not null) await ApiClient.DeleteAsync<object>($"api/mobile/tai-khoan/phien/{p.Id}");
        }
        catch { }
    }
}

/// <summary>Trang "Bảo mật tài khoản": lối vào phiên đăng nhập, xác thực SĐT, điều khoản, khóa tài khoản.</summary>
public sealed class BaoMatTaiKhoanPage : ContentPage
{
    public BaoMatTaiKhoanPage()
    {
        Title = "Bảo mật tài khoản";
        this.SetAppThemeColor(BackgroundColorProperty, Color.FromArgb("#FAF8FF"), Color.FromArgb("#1C1633"));
        var ds = new VerticalStackLayout { Spacing = 10, Padding = new Thickness(16, 12, 16, 28) };
        ds.Add(Dong("📱", "Phiên đăng nhập", "Xem các thiết bị đang đăng nhập, đăng xuất từng thiết bị", async () => await Shell.Current.GoToAsync(nameof(PhienDangNhapPage))));
        ds.Add(Dong("🕘", "Lịch sử đăng nhập", "30 lần đăng nhập gần nhất", async () => await Shell.Current.GoToAsync(nameof(LichSuDangNhapPage))));
        ds.Add(Dong("🔑", "Đổi mật khẩu", "Đổi mật khẩu đăng nhập", async () => await Shell.Current.GoToAsync($"{nameof(DoiMatKhauPage)}?VaiTro=KhachHang")));
        ds.Add(Dong("✅", "Xác thực số điện thoại (OTP)", "Nhận mã OTP qua SMS để xác thực số điện thoại", XacThucSdtAsync));
        ds.Add(Dong("📄", "Điều khoản & quyền riêng tư", "Đọc nội dung và xem thời điểm bạn đã đồng ý", async () => await Shell.Current.GoToAsync(nameof(DieuKhoanPage))));
        ds.Add(Dong("☎️", "Liên hệ, chính sách & hướng dẫn", "Hotline, email hỗ trợ, chính sách sử dụng, hướng dẫn", async () => await Shell.Current.GoToAsync(nameof(ThongTinUngDungPage))));
        ds.Add(Dong("🔒", "Khóa tài khoản", "Tạm ngưng tài khoản, đăng xuất mọi thiết bị (dữ liệu được giữ)", KhoaAsync));
        ds.Add(Dong("🗑️", "Xóa tài khoản", "Xóa vĩnh viễn — thực hiện ở Hồ sơ → Xóa tài khoản", async () =>
            await DisplayAlert("Xóa tài khoản", "Vào Hồ sơ → Xóa tài khoản để xóa vĩnh viễn tài khoản và dữ liệu cá nhân.", "OK")));
        Content = new ScrollView { Content = ds };
    }

    private static View Dong(string icon, string tieuDe, string moTa, Func<Task> hanhDong)
    {
        var g = new Grid { ColumnDefinitions = { new ColumnDefinition(40), new ColumnDefinition(GridLength.Star), new ColumnDefinition(20) }, ColumnSpacing = 8 };
        g.Add(new Label { Text = icon, FontSize = 22, VerticalOptions = LayoutOptions.Center, HorizontalOptions = LayoutOptions.Center }, 0);
        var tx = new VerticalStackLayout { Spacing = 2 };
        tx.Add(new Label { Text = tieuDe, FontAttributes = FontAttributes.Bold, FontSize = 14 });
        tx.Add(new Label { Text = moTa, FontSize = 11.5, TextColor = Colors.Gray });
        g.Add(tx, 1);
        g.Add(new Label { Text = "›", FontSize = 20, TextColor = Colors.Gray, VerticalOptions = LayoutOptions.Center }, 2);
        var f = new Frame { Padding = 12, CornerRadius = 12, HasShadow = false, Content = g };
        f.SetAppThemeColor(BackgroundColorProperty, Colors.White, Color.FromArgb("#221A38"));
        f.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => await hanhDong()) });
        return f;
    }

    private async Task XacThucSdtAsync()
    {
        var k = Phien.Khach;
        if (k is null) return;
        if (!DuLieuService.DangOnline) { await DisplayAlert("Cần kết nối", "Xác thực OTP qua SMS cần kết nối máy chủ.", "OK"); return; }
        if (string.IsNullOrWhiteSpace(k.SoDienThoai)) { await DisplayAlert("Chưa có số điện thoại", "Hãy cập nhật số điện thoại trong Hồ sơ → Thông tin cá nhân trước.", "OK"); return; }
        if (await XacThucOtpPage.CanXacThucAsync(OtpService.XacThucSdt, k.SoDienThoai, "Xác thực số điện thoại"))
            await DisplayAlert("Thành công", "Số điện thoại đã được xác thực.", "OK");
    }

    private async Task KhoaAsync()
    {
        var k = Phien.Khach;
        if (k is null) return;
        if (!DuLieuService.DangOnline) { await DisplayAlert("Cần kết nối", "Khóa tài khoản cần kết nối máy chủ.", "OK"); return; }
        if (!await DisplayAlert("Khóa tài khoản",
                "Tài khoản sẽ bị khóa ngay và đăng xuất khỏi MỌI thiết bị. Dữ liệu được giữ nguyên; muốn mở lại bạn phải liên hệ bộ phận hỗ trợ. Tiếp tục?", "Tiếp tục", "Hủy")) return;
        var lyDo = await this.NhapAsync("Lý do (không bắt buộc)", "Cho chúng tôi biết lý do bạn khóa tài khoản:", "Tiếp", "Hủy", maxLength: 200);
        if (lyDo is null) return;
        var mk = await this.NhapAsync("Xác nhận", "Nhập mật khẩu để khóa tài khoản:", "Khóa", "Hủy");
        if (string.IsNullOrEmpty(mk)) return;
        var r = await ApiClient.PostAsync<object>("api/mobile/tai-khoan/yeu-cau-khoa", new { matKhau = mk, lyDo });
        if (!r.ThanhCong) { await DisplayAlert("Không khóa được", r.ThongDiep, "OK"); return; }
        NhatKyService.Ghi("KhachHang", k.Email, "Khóa tài khoản", chiTiet: NhatKyService.ThietBi());
        await DisplayAlert("Đã khóa tài khoản", r.ThongDiep, "OK");
        Phien.DangXuat();
        await Shell.Current.GoToAsync("//dang-nhap");
    }
}

/// <summary>Danh sách thiết bị đang đăng nhập; đăng xuất từng thiết bị hoặc tất cả thiết bị khác.</summary>
public sealed class PhienDangNhapPage : ContentPage
{
    private readonly VerticalStackLayout _ds = new() { Spacing = 8, Padding = new Thickness(16, 12, 16, 28) };

    public PhienDangNhapPage()
    {
        Title = "Phiên đăng nhập";
        this.SetAppThemeColor(BackgroundColorProperty, Color.FromArgb("#FAF8FF"), Color.FromArgb("#1C1633"));
        Content = new ScrollView { Content = _ds };
    }

    protected override async void OnAppearing() { base.OnAppearing(); await NapAsync(); }

    private async Task NapAsync()
    {
        _ds.Clear();
        if (!DuLieuService.DangOnline || Phien.Khach is null)
        {
            _ds.Add(new Label { Text = "Cần kết nối máy chủ và đăng nhập để xem các phiên đăng nhập.", TextColor = Colors.Gray });
            return;
        }
        var r = await ApiClient.GetAsync<List<PhienMayChu.PhienDto>>("api/mobile/tai-khoan/phien");
        if (!r.ThanhCong || r.DuLieu is null) { _ds.Add(new Label { Text = r.ThongDiep, TextColor = Colors.Gray }); return; }
        if (r.DuLieu.Count == 0) { _ds.Add(new Label { Text = "Chưa có phiên nào được ghi (phiên đăng nhập cũ trước bản cập nhật sẽ không hiện ở đây).", TextColor = Colors.Gray }); return; }

        _ds.Add(new Label { Text = "Các thiết bị đã đăng nhập trong 30 ngày qua. Nếu thấy thiết bị lạ, hãy đăng xuất nó và đổi mật khẩu.", FontSize = 12, TextColor = Colors.Gray });
        foreach (var p in r.DuLieu)
        {
            var v = new VerticalStackLayout { Spacing = 3 };
            v.Add(new Label { Text = (p.HienTai ? "📍 Thiết bị này · " : "📱 ") + (string.IsNullOrWhiteSpace(p.ThietBi) ? "Thiết bị không rõ" : p.ThietBi), FontAttributes = FontAttributes.Bold, FontSize = 13 });
            v.Add(new Label { Text = $"Đăng nhập: {p.NgayTao:dd/MM/yyyy HH:mm}" + (string.IsNullOrWhiteSpace(p.DiaChiIp) ? "" : $" · IP {p.DiaChiIp}"), FontSize = 11.5, TextColor = Colors.Gray });
            var id = p.Id; var hienTai = p.HienTai;
            var nut = new Button { Text = hienTai ? "Đăng xuất phiên này" : "Đăng xuất thiết bị", FontSize = 12, HeightRequest = 36, Padding = new Thickness(12, 0), BackgroundColor = Colors.Transparent, TextColor = Colors.Crimson, BorderColor = Colors.Crimson, BorderWidth = 1, HorizontalOptions = LayoutOptions.Start };
            nut.Clicked += async (_, _) => await ThuHoiAsync(id, hienTai);
            v.Add(nut);
            var f = new Frame { Padding = 12, CornerRadius = 12, HasShadow = false, Content = v };
            f.SetAppThemeColor(BackgroundColorProperty, Colors.White, Color.FromArgb("#221A38"));
            _ds.Add(f);
        }
        if (r.DuLieu.Count(x => !x.HienTai) > 0)
        {
            var tatCa = new Button { Text = "Đăng xuất tất cả thiết bị khác", BackgroundColor = Colors.Crimson, TextColor = Colors.White, CornerRadius = 10 };
            tatCa.Clicked += async (_, _) =>
            {
                if (!await DisplayAlert("Đăng xuất thiết bị khác", "Mọi thiết bị khác sẽ phải đăng nhập lại. Tiếp tục?", "Đăng xuất", "Hủy")) return;
                var kq = await ApiClient.PostAsync<JsonElement>("api/mobile/tai-khoan/phien/dang-xuat-khac", null);
                await DisplayAlert(kq.ThanhCong ? "Xong" : "Lỗi", kq.ThanhCong ? "Đã đăng xuất các thiết bị khác." : kq.ThongDiep, "OK");
                await NapAsync();
            };
            _ds.Add(tatCa);
        }
    }

    private async Task ThuHoiAsync(Guid id, bool hienTai)
    {
        if (!await DisplayAlert(hienTai ? "Đăng xuất" : "Đăng xuất thiết bị", hienTai ? "Đăng xuất khỏi thiết bị này?" : "Thiết bị đó sẽ phải đăng nhập lại. Tiếp tục?", "Đăng xuất", "Hủy")) return;
        var kq = await ApiClient.DeleteAsync<object>($"api/mobile/tai-khoan/phien/{id}");
        if (!kq.ThanhCong) { await DisplayAlert("Lỗi", kq.ThongDiep, "OK"); return; }
        if (hienTai)
        {
            Phien.DangXuat();
            await Shell.Current.GoToAsync("//dang-nhap");
            return;
        }
        await NapAsync();
    }
}

/// <summary>Điều khoản sử dụng &amp; chính sách quyền riêng tư (api/mobile/dieu-khoan); khách đã đăng nhập thấy thời điểm đã đồng ý và có thể xác nhận lại.</summary>
public sealed class DieuKhoanPage : ContentPage
{
    private sealed class MucDto { public string TieuDe { get; set; } = ""; public string NoiDung { get; set; } = ""; }
    private sealed class DieuKhoanDto { public string? PhienBan { get; set; } public List<MucDto>? Muc { get; set; } }
    private sealed class DongYDto { public string? PhienBan { get; set; } public DateTime? DongYLuc { get; set; } }

    private static readonly (string, string)[] MacDinh =
    {
        ("1. Điều khoản sử dụng", "Người dùng cung cấp thông tin chính xác khi đăng ký, chịu trách nhiệm về tài khoản của mình và không sử dụng hệ thống cho mục đích gian lận. Hệ thống có quyền khóa tài khoản vi phạm."),
        ("2. Chính sách bảo mật", "Hệ thống thu thập họ tên, số điện thoại, email, địa chỉ giao hàng và lịch sử đơn hàng để xử lý đơn và hỗ trợ khách hàng. Mật khẩu được mã hóa. Thông tin chỉ chia sẻ với gian hàng/tài xế phụ trách đơn của bạn."),
        ("3. Quyền của bạn", "Bạn có thể chỉnh sửa hồ sơ, xem và đăng xuất các thiết bị đang đăng nhập, yêu cầu khóa hoặc xóa tài khoản trong ứng dụng."),
    };

    private readonly VerticalStackLayout _ds = new() { Spacing = 10, Padding = new Thickness(16, 12, 16, 28) };

    public DieuKhoanPage()
    {
        Title = "Điều khoản & quyền riêng tư";
        this.SetAppThemeColor(BackgroundColorProperty, Color.FromArgb("#FAF8FF"), Color.FromArgb("#1C1633"));
        Content = new ScrollView { Content = _ds };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        _ds.Clear();
        var muc = MacDinh.Select(m => (m.Item1, m.Item2)).ToList();
        string? phienBan = null;
        if (DuLieuService.DangOnline)
        {
            var r = await ApiClient.GetAsync<DieuKhoanDto>("api/mobile/dieu-khoan");
            if (r.ThanhCong && r.DuLieu?.Muc is { Count: > 0 } m) { muc = m.Select(x => (x.TieuDe, x.NoiDung)).ToList(); phienBan = r.DuLieu.PhienBan; }
        }
        foreach (var (t, n) in muc)
        {
            _ds.Add(new Label { Text = t, FontAttributes = FontAttributes.Bold, FontSize = 15 });
            _ds.Add(new Label { Text = n, FontSize = 13 });
        }
        if (phienBan is not null) _ds.Add(new Label { Text = $"Phiên bản điều khoản: {phienBan}", FontSize = 11, TextColor = Colors.Gray });

        if (DuLieuService.DangOnline && Phien.Khach is not null)
        {
            var d = await ApiClient.GetAsync<DongYDto>("api/mobile/tai-khoan/dieu-khoan");
            var luc = d.DuLieu?.DongYLuc;
            _ds.Add(new Label { Text = luc is null ? "Bạn chưa xác nhận đồng ý điều khoản." : $"✅ Bạn đã đồng ý lúc {luc:dd/MM/yyyy HH:mm}.", FontSize = 12.5, FontAttributes = FontAttributes.Bold });
            var nut = new Button { Text = luc is null ? "Tôi đồng ý" : "Xác nhận đồng ý lại", CornerRadius = 10 };
            nut.Clicked += async (_, _) =>
            {
                var r2 = await ApiClient.PostAsync<object>("api/mobile/tai-khoan/dieu-khoan/dong-y", null);
                await DisplayAlert(r2.ThanhCong ? "Đã ghi nhận" : "Lỗi", r2.ThanhCong ? "Bạn đã đồng ý Điều khoản và Chính sách quyền riêng tư." : r2.ThongDiep, "OK");
                OnAppearing();
            };
            _ds.Add(nut);
        }
    }
}


/// <summary>Liên hệ · Chính sách sử dụng · Hướng dẫn · Thông tin doanh nghiệp (api/mobile/thong-tin-ung-dung; quản trị sửa ở Cấu hình hệ thống).</summary>
public sealed class ThongTinUngDungPage : ContentPage
{
    private static readonly Dictionary<string, string> MacDinh = new()
    {
        ["App.Ten"] = "FoodApp", ["App.KhauHieu"] = "Giao đồ ăn",
        ["DoanhNghiep.Ten"] = "Chưa cập nhật", ["DoanhNghiep.MaSoThue"] = "Chưa cập nhật", ["DoanhNghiep.DiaChi"] = "Chưa cập nhật",
        ["LienHe.SoDienThoai"] = "Chưa cập nhật", ["LienHe.Email"] = "Chưa cập nhật", ["LienHe.GioHoTro"] = "08:00 - 22:00 hằng ngày",
        ["NoiDung.ChinhSachSuDung"] = "Vui lòng sử dụng ứng dụng đúng mục đích đặt và giao đồ ăn, không gian lận khuyến mãi, không đăng nội dung vi phạm pháp luật.",
        ["NoiDung.HuongDan"] = "Chọn quán, thêm món vào giỏ, đặt hàng và theo dõi đơn trong mục Đơn hàng. Cần hỗ trợ: vào Hồ sơ → Hỗ trợ.",
    };

    private readonly VerticalStackLayout _ds = new() { Spacing = 10, Padding = new Thickness(16, 12, 16, 28) };

    public ThongTinUngDungPage()
    {
        Title = "Liên hệ & chính sách";
        this.SetAppThemeColor(BackgroundColorProperty, Color.FromArgb("#FAF8FF"), Color.FromArgb("#1C1633"));
        Content = new ScrollView { Content = _ds };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        var d = new Dictionary<string, string>(MacDinh);
        if (DuLieuService.DangOnline)
        {
            var r = await ApiClient.GetAsync<Dictionary<string, string>>("api/mobile/thong-tin-ung-dung");
            if (r.ThanhCong && r.DuLieu is not null) foreach (var kv in r.DuLieu) if (!string.IsNullOrWhiteSpace(kv.Value)) d[kv.Key] = kv.Value;
        }
        string G(string k) => d.TryGetValue(k, out var v) ? v : "";
        _ds.Clear();
        _ds.Add(new Label { Text = G("App.Ten"), FontSize = 22, FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb("#5B3FD9") });
        _ds.Add(new Label { Text = G("App.KhauHieu"), FontSize = 13, TextColor = Colors.Gray });

        Muc("☎️ Liên hệ hỗ trợ");
        Dong("Hotline", G("LienHe.SoDienThoai"), "tel:");
        Dong("Email", G("LienHe.Email"), "mailto:");
        Dong("Giờ hỗ trợ", G("LienHe.GioHoTro"), null);
        Muc("📄 Chính sách sử dụng");
        _ds.Add(new Label { Text = G("NoiDung.ChinhSachSuDung"), FontSize = 13 });
        Muc("📘 Hướng dẫn sử dụng");
        _ds.Add(new Label { Text = G("NoiDung.HuongDan"), FontSize = 13 });
        Muc("🏢 Thông tin doanh nghiệp");
        Dong("Tên", G("DoanhNghiep.Ten"), null);
        Dong("Mã số thuế", G("DoanhNghiep.MaSoThue"), null);
        Dong("Địa chỉ", G("DoanhNghiep.DiaChi"), null);
        var dk = new Button { Text = "Điều khoản & quyền riêng tư", CornerRadius = 10, Margin = new Thickness(0, 8, 0, 0) };
        dk.Clicked += async (_, _) => await Shell.Current.GoToAsync(nameof(DieuKhoanPage));
        _ds.Add(dk);
    }

    private void Muc(string t) => _ds.Add(new Label { Text = t, FontAttributes = FontAttributes.Bold, FontSize = 15, Margin = new Thickness(0, 10, 0, 0) });

    private void Dong(string nhan, string giaTri, string? giaoThuc)
    {
        var g = new Grid { ColumnDefinitions = { new ColumnDefinition(GridLength.Auto), new ColumnDefinition(GridLength.Star) }, ColumnSpacing = 12 };
        g.Add(new Label { Text = nhan, FontSize = 13, TextColor = Colors.Gray, WidthRequest = 84 }, 0, 0);
        var v = new Label { Text = giaTri, FontSize = 13 };
        if (giaoThuc is not null && giaTri != "Chưa cập nhật")
        {
            v.TextColor = Color.FromArgb("#5B3FD9"); v.TextDecorations = TextDecorations.Underline;
            v.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => { try { await Launcher.OpenAsync(giaoThuc + giaTri.Replace(" ", "")); } catch (Exception ex) { CrashLog.Ghi("ThongTinUngDung.Mo", ex); } }) });
        }
        g.Add(v, 1, 0);
        _ds.Add(g);
    }
}
