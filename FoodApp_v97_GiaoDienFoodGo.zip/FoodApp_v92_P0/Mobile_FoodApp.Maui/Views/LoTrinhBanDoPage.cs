using System.Text.Json;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>Vẽ lộ trình tối ưu lên bản đồ (OpenStreetMap + Leaflet trong WebView): điểm dừng đánh số, đường đi theo từng chặng.
/// Chặng nào Goong không trả đường chi tiết thì vẽ nét đứt thẳng giữa 2 điểm.</summary>
public sealed class LoTrinhBanDoPage : ContentPage
{
    /// <summary>Dữ liệu cần vẽ — đặt trước khi mở trang.</summary>
    public static LoTrinhThatDto? DuLieu { get; set; }

    public LoTrinhBanDoPage()
    {
        Title = "Lộ trình trên bản đồ";
        var d = DuLieu;
        if (d is null || d.Diem.Count == 0) { Content = new Label { Text = "Chưa có lộ trình để vẽ.", Margin = 24, HorizontalOptions = LayoutOptions.Center }; return; }

        var tom = new Label
        {
            FontSize = 12.5, Margin = new Thickness(14, 8),
            Text = $"≈ {d.TongKm:0.#} km · ~{d.TongPhut} phút" + (d.HeSoKetXe > 1.0001 ? $" (đã tính kẹt xe ×{d.HeSoKetXe:0.##}; không kẹt ~{d.TongPhutKhongKetXe} phút)" : "")
                + (string.IsNullOrEmpty(d.GhiChuKetXe) ? "" : "\n" + d.GhiChuKetXe),
        };
        var wv = new WebView { VerticalOptions = LayoutOptions.Fill, Source = new HtmlWebViewSource { Html = TaoHtml(d) } };
        var luoi = new Grid { RowDefinitions = { new RowDefinition(GridLength.Auto), new RowDefinition(GridLength.Star) } };
        luoi.Add(tom, 0, 0);
        luoi.Add(wv, 0, 1);
        Content = luoi;
    }

    private static string TaoHtml(LoTrinhThatDto d)
    {
        var du = new
        {
            diem = d.Diem.Select(p => new { lat = p.Lat, lng = p.Lng, ma = p.MaDon, loai = p.Loai }),
            batDau = d.BatDau is { } b ? new { lat = b.Lat, lng = b.Lng } : null,
            chang = d.Chang,
        };
        var json = JsonSerializer.Serialize(du).Replace("<", "\\u003c");
        return @"<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'/>
<script src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'></script>
<style>html,body,#m{height:100%;margin:0}.pin{background:#7C3AED;color:#fff;border-radius:50%;width:26px;height:26px;line-height:26px;text-align:center;font:700 13px sans-serif;border:2px solid #fff;box-shadow:0 1px 4px #0006}.pin.lay{background:#F59E0B}.pin.xp{background:#16A34A}</style></head>
<body><div id='m'></div><script>
var D=" + json + @";
var map=L.map('m');L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'&copy; OpenStreetMap'}).addTo(map);
var all=[];
function ic(t,c){return L.divIcon({className:'',html:'<div class=""pin '+c+'"">'+t+'</div>',iconSize:[26,26],iconAnchor:[13,13]});}
var coDau=!!D.batDau;var prev=coDau?[D.batDau.lat,D.batDau.lng]:null;
if(prev){L.marker(prev,{icon:ic('★','xp')}).addTo(map).bindPopup('Vị trí của bạn');all.push(prev);}
D.diem.forEach(function(p,i){
  var cur=[p.lat,p.lng];all.push(cur);
  var seg=D.chang[coDau?i:i-1];
  if(prev||i>0){
    var from=prev||[D.diem[i-1].lat,D.diem[i-1].lng];
    if(seg&&seg.length>1){L.polyline(seg,{color:'#7C3AED',weight:5,opacity:.85}).addTo(map);seg.forEach(function(q){all.push(q);});}
    else L.polyline([from,cur],{color:'#7C3AED',weight:3,dashArray:'6 8'}).addTo(map);
  }
  L.marker(cur,{icon:ic(String(i+1),p.loai==='lay'?'lay':'')}).addTo(map).bindPopup((p.loai==='lay'?'Lấy hàng':'Giao hàng')+' đơn #'+p.ma);
  prev=cur;
});
if(all.length)map.fitBounds(all,{padding:[30,30]});else map.setView([21.03,105.85],12);
</script></body></html>";
    }
}
