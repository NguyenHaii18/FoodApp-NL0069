namespace FoodApp.Maui.Views;

/// <summary>
/// Thanh tiêu đề dùng chung cho các trang tài xế (kiểu FOODAPP): nút quay lại + tiêu đề, nền trắng/tối theo chủ đề.
/// Dùng: &lt;views:DriverHeader Title="Đơn hàng" ShowBack="False" /&gt; (trang phải đặt Shell.NavBarIsVisible="False").
/// </summary>
public class DriverHeader : ContentView
{
    public static readonly BindableProperty TitleProperty =
        BindableProperty.Create(nameof(Title), typeof(string), typeof(DriverHeader), "", propertyChanged: (b, _, _) => ((DriverHeader)b).Ve());
    public static readonly BindableProperty ShowBackProperty =
        BindableProperty.Create(nameof(ShowBack), typeof(bool), typeof(DriverHeader), true, propertyChanged: (b, _, _) => ((DriverHeader)b).Ve());

    public string Title { get => (string)GetValue(TitleProperty); set => SetValue(TitleProperty, value); }
    public bool ShowBack { get => (bool)GetValue(ShowBackProperty); set => SetValue(ShowBackProperty, value); }

    public DriverHeader() => Ve();

    private void Ve()
    {
        var luoi = new Grid { Padding = new Thickness(16, 14, 16, 10), ColumnSpacing = 10 };
        luoi.SetAppThemeColor(BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
        luoi.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));
        luoi.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));
        luoi.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Auto));

        if (ShowBack)
        {
            var lui = new Label { Text = "←", FontSize = 24, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center };
            lui.SetAppThemeColor(Label.TextColorProperty, DriverPalette.Get("TextDark"), Color.FromArgb("#F3EEFF"));
            lui.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => { if (Shell.Current is { } s) await s.GoToAsync(".."); }) });
            luoi.Add(lui, 0);
        }

        var tieuDe = new Label { Text = Title, FontSize = 19, FontAttributes = FontAttributes.Bold, VerticalOptions = LayoutOptions.Center };
        tieuDe.SetAppThemeColor(Label.TextColorProperty, DriverPalette.Get("TextDark"), Color.FromArgb("#F3EEFF"));
        luoi.Add(tieuDe, ShowBack ? 1 : 0);
        if (!ShowBack) Grid.SetColumnSpan(tieuDe, 2);
        // logo FOODAPP: bấm để về trang chủ tài xế
        var logo = VeTrangChu.Gan(new Label { Text = "✔ FOODAPP", FontSize = 12.5, FontAttributes = FontAttributes.Bold, TextColor = Color.FromArgb("#8B5CF6"), VerticalOptions = LayoutOptions.Center, Padding = new Thickness(6, 8) });
        luoi.Add(logo, 2);

        var duongKe = new BoxView { HeightRequest = 1, VerticalOptions = LayoutOptions.End, Color = DriverPalette.Get("BorderColor") };
        Content = new Grid { Children = { luoi, duongKe } };
    }
}
