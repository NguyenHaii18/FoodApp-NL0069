using System.Text.Json;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Cửa sổ ĐỀ NGHỊ GIAO ĐƠN: tóm tắt đơn + đếm ngược. Tài xế bấm Nhận hoặc Từ chối; hết giờ tự đóng (đơn chuyển cho người kế tiếp).
/// Nhận đơn là thao tác nguyên tử trên máy chủ: nếu đề nghị đã hết hạn/đơn đã có người nhận sẽ báo rõ.
/// </summary>
public sealed class DriverOfferPopupPage : ContentPage
{
    private readonly long _maDeNghi;
    private readonly DateTime _hetHan;
    private readonly double _tong;
    private readonly Label _dem = new() { FontSize = 42, FontAttributes = FontAttributes.Bold, HorizontalOptions = LayoutOptions.Center, TextColor = Color.FromArgb(AdminUi.Xanh) };
    private readonly ProgressBar _bar = new() { Progress = 1, ProgressColor = Color.FromArgb(AdminUi.Xanh), HeightRequest = 8 };
    private readonly Button _btnNhan = AdminUi.Nut("✔  NHẬN ĐƠN", AdminUi.Xanh, day: true);
    private readonly Button _btnTuChoi = AdminUi.Nut("Từ chối", AdminUi.Do);
    private IDispatcherTimer? _timer;
    private bool _xuLy;

    public DriverOfferPopupPage(JsonElement d)
    {
        _maDeNghi = J.L(d, "maDeNghi");
        _tong = Math.Max(5, J.L(d, "giayConLai"));
        _hetHan = DateTime.Now.AddSeconds(Math.Max(1, J.L(d, "giayConLai")));
        Title = "Đơn mới";
        AdminUi.NenTrang(this);
        Shell.SetNavBarIsVisible(this, false);

        var don = J.Doi(d, "don");
        var km = J.D(d, "kmDenQuan");
        var dong = new List<string>
        {
            $"🏪 {J.S(don, "quan")}",
            $"📍 Lấy hàng: {J.S(don, "diaChiQuan")}",
            km > 0 ? $"🛵 Cách bạn khoảng {km:0.#} km (~{Math.Ceiling((double)km / 22 * 60) + 1:0} phút)" : "",
            $"📦 Giao đến: {J.S(don, "diaChiGiao")}" + (J.D(don, "kmGiao") > 0 ? $" ({J.D(don, "kmGiao"):0.#} km)" : ""),
            $"🍽 {J.L(don, "soMon")} món · tổng đơn {AdminUi.Tien(J.D(don, "tongTien"))}",
            $"💵 Phí giao (thu nhập của bạn): {AdminUi.Tien(J.D(don, "phiGiao"))}",
            J.B(don, "thuHoCod") ? $"⚠ Thu hộ tiền mặt (COD) khi giao" : "",
            J.B(don, "sanSang") ? "✅ Quán đã báo món sẵn sàng" : "👨‍🍳 Quán đang chuẩn bị món",
        };

        var the = AdminUi.The(16);
        var st = new VerticalStackLayout { Spacing = 6 };
        st.Add(AdminUi.Nhan($"Đơn #{J.S(don, "maDon")}", 18, dam: true));
        foreach (var l in dong.Where(x => x != "")) st.Add(AdminUi.Nhan(l, 13.5));
        the.Content = st;

        _btnNhan.HeightRequest = 56; _btnNhan.FontSize = 16;
        _btnTuChoi.HeightRequest = 48;
        _btnNhan.Clicked += async (_, _) => await NhanAsync();
        _btnTuChoi.Clicked += async (_, _) => await TuChoiAsync();

        Content = new ScrollView
        {
            Content = new VerticalStackLayout
            {
                Padding = new Thickness(20, 50, 20, 24), Spacing = 14,
                Children =
                {
                    AdminUi.Nhan("🔔 Đề nghị đơn mới — hãy phản hồi trong", 13, mo: true),
                    _dem, _bar, the, _btnNhan, _btnTuChoi,
                    AdminUi.Nhan("Hết giờ mà chưa phản hồi, đơn sẽ chuyển cho tài xế khác. Bỏ lỡ nhiều lần liên tiếp sẽ bị tạm ngừng nhận đề nghị.", 11.5, mo: true),
                },
            },
        };
        CapNhatDem();
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        _timer = Dispatcher.CreateTimer();
        _timer.Interval = TimeSpan.FromSeconds(1);
        _timer.Tick += async (_, _) =>
        {
            CapNhatDem();
            if (!_xuLy && DateTime.Now >= _hetHan) await DongAsync("Đề nghị đã hết hạn — đơn được chuyển cho tài xế khác.");
        };
        _timer.Start();
        try { HapticFeedback.Default.Perform(HapticFeedbackType.LongPress); } catch { }
    }

    protected override void OnDisappearing()
    {
        base.OnDisappearing();
        _timer?.Stop();
        DriverPresenceService.DaDongCuaSo();
    }

    protected override bool OnBackButtonPressed() => true;     // phải chọn Nhận / Từ chối (hoặc chờ hết giờ)

    private void CapNhatDem()
    {
        var con = Math.Max(0, (_hetHan - DateTime.Now).TotalSeconds);
        _dem.Text = $"{Math.Ceiling(con):0}s";
        _bar.Progress = Math.Clamp(con / _tong, 0, 1);
        var gap = con <= 8;
        _dem.TextColor = Color.FromArgb(gap ? AdminUi.Do : AdminUi.Xanh);
        _bar.ProgressColor = Color.FromArgb(gap ? AdminUi.Do : AdminUi.Xanh);
    }

    private async Task DongAsync(string? thongBao)
    {
        _timer?.Stop();
        try { await Navigation.PopModalAsync(); } catch { }
        DriverPresenceService.DaDongCuaSo();
        if (!string.IsNullOrEmpty(thongBao))
            try { await (Application.Current?.Windows?.FirstOrDefault()?.Page?.DisplayAlert("Đề nghị đơn", thongBao, "OK") ?? Task.CompletedTask); } catch { }
    }

    private async Task NhanAsync()
    {
        if (_xuLy) return;
        _xuLy = true; _btnNhan.IsEnabled = _btnTuChoi.IsEnabled = false; _btnNhan.Text = "Đang nhận…";
        var kq = await ApiClient.PostAsync<JsonElement>($"api/mobile/driver/de-nghi/{_maDeNghi}/nhan", null);
        if (kq.ThanhCong)
        {
            RealtimeService.YeuCauDongBo();
            await DongAsync("Đã nhận đơn! Hãy đến quán lấy món. Nếu không thể giao, dùng \"Hủy nhận đơn\" trong chi tiết đơn (trước khi lấy hàng).");
        }
        else await DongAsync(string.IsNullOrWhiteSpace(kq.ThongDiep) ? "Không nhận được đơn — đề nghị đã hết hạn hoặc đã có người nhận." : kq.ThongDiep);
    }

    private async Task TuChoiAsync()
    {
        if (_xuLy) return;
        var ly = await DisplayActionSheet("Lý do từ chối", "Quay lại", null, "Quá xa", "Đang bận / sắp nghỉ", "Xe gặp sự cố", "Không phù hợp phương tiện", "Lý do khác");
        if (string.IsNullOrEmpty(ly) || ly == "Quay lại") return;
        _xuLy = true; _btnNhan.IsEnabled = _btnTuChoi.IsEnabled = false;
        var kq = await ApiClient.PostAsync<JsonElement>($"api/mobile/driver/de-nghi/{_maDeNghi}/tu-choi", new { lyDo = ly });
        await DongAsync(kq.ThanhCong ? null : kq.ThongDiep);
    }
}
