using System.Text.Json;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// v69 — Quản lý tin tức / ưu đãi: soạn tin hiện ở mục "Tin mới" của app khách (cùng các tin tự sinh từ khuyến mãi và quán mới).
/// Hẹn ngày đăng, đặt hạn, ghim, ẩn/hiện, xóa; có thể gửi kèm thông báo tới khách khi tạo. Cần quyền quản lý nội dung/thông báo.
/// </summary>
public sealed class AdminTinTucPage : AdminListPage
{
    public AdminTinTucPage() : base(Cfg()) { }

    private const string Api = "api/mobile/admin/tin-tuc";
    private static readonly (string Ma, string Nhan)[] Loais = { ("KhuyenMai", "Khuyến mãi"), ("HeThong", "Hệ thống"), ("TinQuan", "Quán mới") };
    private static string NhanLoai(string ma) => Loais.FirstOrDefault(x => x.Ma == ma).Nhan ?? "Hệ thống";

    private static AdminListCauHinh Cfg() => new()
    {
        TieuDe = "Tin tức & ưu đãi",
        Tab = new[] { "Tất cả", "Đang hiển thị", "Hẹn đăng / ẩn" },
        Url = (_, _, _) => Api,
        LayDs = (tab, g) => g.ValueKind != JsonValueKind.Array ? Enumerable.Empty<JsonElement>()
            : g.EnumerateArray().Where(d => tab == 0 || (tab == 1 ? J.B(d, "dangHienThi") : !J.B(d, "dangHienThi"))).ToList(),
        TomTat = (_, _) => "Tin do bạn soạn xuất hiện ở mục \"Tin mới\" và trang chủ của khách. Tin ghim luôn nằm đầu; tin hẹn đăng chỉ hiện khi đến ngày.",
        Dong = (_, d) =>
        {
            var dong = new List<string>
            {
                $"{(J.B(d, "ghimLen") ? "📌 " : "")}{NhanLoai(J.S(d, "loai"))} · đăng {J.Ngay(d, "ngayDang", "dd/MM/yyyy")}" + (J.Rong(d, "ngayHetHan") ? "" : $" · hết hạn {J.Ngay(d, "ngayHetHan", "dd/MM/yyyy")}"),
                string.IsNullOrWhiteSpace(J.S(d, "tomTat")) ? Cat(J.S(d, "noiDung")) : J.S(d, "tomTat"),
            };
            var (nhan, mau) = J.B(d, "dangHienThi") ? ("Đang hiển thị", AdminUi.Xanh)
                : J.B(d, "henDang") ? ("Hẹn đăng", AdminUi.Cam)
                : J.B(d, "hetHan") ? ("Hết hạn", AdminUi.Xam)
                : ("Đã ẩn", AdminUi.Xam);
            return new AdminDong(J.S(d, "tieuDe"), dong.ToArray(), nhan, mau, J.B(d, "ghimLen") ? "📌" : "📰");
        },
        Mo = async (p, d) => await p.DisplayAlert(J.S(d, "tieuDe"), J.S(d, "noiDung"), "Đóng"),
        HanhDong = _ => new[]
        {
            new AdminHanhDong("Sửa", AdminUi.Tim, null, async (p, d) => await SoanAsync(p, d)),
            new AdminHanhDong("Ghim / bỏ ghim", AdminUi.Cam, null,
                async (p, d) => await AdminUi.Put(p, $"{Api}/{J.S(d, "maTinTuc")}/ghim", null, "Ghim tin tức", J.S(d, "tieuDe"))),
            new AdminHanhDong("Ẩn / hiện", AdminUi.Xam, null,
                async (p, d) => await AdminUi.Put(p, $"{Api}/{J.S(d, "maTinTuc")}/bat-tat", null, "Ẩn/hiện tin tức", J.S(d, "tieuDe"))),
            new AdminHanhDong("Xóa", AdminUi.Do, null, async (p, d) =>
            {
                if (!await p.DisplayAlert("Xóa tin", $"Xóa \"{J.S(d, "tieuDe")}\"?", "Xóa", "Hủy")) return;
                await AdminUi.Xoa(p, $"{Api}/{J.S(d, "maTinTuc")}", "Xóa tin tức", J.S(d, "tieuDe"));
            }),
        },
        HanhDongChung = _ => new[]
        {
            new AdminHanhDong("➕ Soạn tin mới", AdminUi.Tim, null, async (p, _) => await SoanAsync(p, null)),
        },
    };

    private static string Cat(string s) => s.Length > 120 ? s[..120] + "…" : s;

    private static string NgayChu(JsonElement? d, string k) => d is { } e && !J.Rong(e, k) ? J.Ngay(e, k, "dd/MM/yyyy") : "";

    /// <summary>Đọc ngày dd/MM/yyyy; để trống = không đặt. ok=false khi nhập sai định dạng.</summary>
    private static bool DocNgay(string? s, out DateTime? ngay)
    {
        ngay = null;
        if (string.IsNullOrWhiteSpace(s)) return true;
        if (DateTime.TryParseExact(s.Trim(), new[] { "dd/MM/yyyy", "d/M/yyyy" }, System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out var v)) { ngay = v.Date; return true; }
        return false;
    }

    /// <summary>Soạn tin mới (d = null) hoặc sửa tin (d = dòng đang chọn). Hỏi lần lượt: tiêu đề, tóm tắt, nội dung, loại, ngày đăng, hạn, ghim; tin mới hỏi thêm có gửi thông báo không.</summary>
    private static async Task SoanAsync(AdminListPage p, JsonElement? d)
    {
        var sua = d != null;
        var t = sua ? "Sửa tin" : "Tin mới";
        var tieuDe = await AdminUi.Hoi(p, $"{t} (1/6)", "Tiêu đề (3–200 ký tự).", null, 3, sua ? J.S(d!.Value, "tieuDe") : ""); if (tieuDe == null) return;
        var tomTat = await AdminUi.Hoi(p, $"{t} (2/6)", "Tóm tắt hiện ở danh sách (tối đa 300 ký tự, có thể bỏ trống).", null, 0, sua ? J.S(d!.Value, "tomTat") : ""); if (tomTat == null) return;
        var noiDung = await AdminUi.Hoi(p, $"{t} (3/6)", "Nội dung đầy đủ (5–4000 ký tự).", null, 5, sua ? J.S(d!.Value, "noiDung") : ""); if (noiDung == null) return;
        var nhanLoai = await p.DisplayActionSheet("Loại tin", "Hủy", null, Loais.Select(x => x.Nhan).ToArray());
        if (nhanLoai is null or "Hủy") return;
        var loai = Loais.First(x => x.Nhan == nhanLoai).Ma;
        var dang = await AdminUi.Hoi(p, $"{t} (4/6)", "Ngày đăng dd/MM/yyyy. Để trống = đăng ngay (hẹn ngày tương lai thì tin chỉ hiện khi đến ngày).", null, 0, sua ? NgayChu(d, "ngayDang") : ""); if (dang == null) return;
        var het = await AdminUi.Hoi(p, $"{t} (5/6)", "Hết hạn vào ngày dd/MM/yyyy (tin vẫn hiện hết ngày đó). Để trống = không hết hạn.", null, 0, sua ? NgayChu(d, "ngayHetHan") : ""); if (het == null) return;
        if (!DocNgay(dang, out var ngayDang) || !DocNgay(het, out var ngayHet)) { await p.DisplayAlert("Sai định dạng ngày", "Nhập ngày theo dd/MM/yyyy, ví dụ 25/12/2026.", "Đóng"); return; }
        var ghim = await p.DisplayAlert($"{t} (6/6)", "Ghim tin lên đầu danh sách?", "Ghim", "Không");

        var guiTb = false;
        if (!sua) guiTb = await p.DisplayAlert("Thông báo tới khách", "Gửi kèm thông báo tới mọi khách hàng khi đăng tin này? (Không thu hồi được; tin hẹn đăng tương lai không gửi.)", "Gửi thông báo", "Chỉ đăng tin");

        var body = new { tieuDe, tomTat, noiDung, loai, ngayDang, ngayHetHan = ngayHet, ghimLen = ghim, guiThongBao = guiTb };
        if (sua) await AdminUi.Put(p, $"{Api}/{J.S(d!.Value, "maTinTuc")}", body, "Sửa tin tức", tieuDe);
        else await AdminUi.Post(p, Api, body, "Đăng tin tức", tieuDe);
    }
}
