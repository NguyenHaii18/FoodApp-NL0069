using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

public sealed class VnPayUrlDto { public string? PaymentUrl { get; set; } }
public sealed class KiemTraLaiDto { public bool DaThanhToan { get; set; } public string ThongDiep { get; set; } = ""; }
public sealed class VnPayTrangThaiDto
{
    public string? TrangThai { get; set; }
    public bool DaThanhToan { get; set; }
    public bool ThatBai { get; set; }
    public bool DonDaHuy { get; set; }
}

/// <summary>
/// Luồng thanh toán VNPay dùng chung (sau khi đặt hàng và khi "Thanh toán lại" trong tab Đơn hàng):
/// mở cổng VNPay → khách quay lại app → hỏi MÁY CHỦ kết quả (máy chủ ghi qua return/IPN, app không tự tin kết quả).
/// </summary>
public static class VnPayThanhToan
{
    private const string NutKiemTra = "✅ Tôi đã thanh toán — kiểm tra kết quả";
    private const string NutMoLai = "🔁 Mở lại trang thanh toán";

    /// <summary>true = máy chủ xác nhận đã thanh toán; false = chưa trả / thất bại / khách chọn để sau.</summary>
    public static async Task<bool> ThucHienAsync(Page trang, string donId, decimal tongTien, string? paymentUrl = null)
    {
        if (!int.TryParse(donId, out var maDon))
        {
            await trang.DisplayAlert("Thanh toán VNPay", "Đơn này chưa được ghi nhận trên máy chủ nên không thể thanh toán VNPay.", "OK");
            return false;
        }

        var moTrang = true;
        string? loiTruoc = null;
        while (true)
        {
            if (moTrang)
            {
                if (string.IsNullOrEmpty(paymentUrl))
                {
                    // Link VNPay có hạn: khi thanh toán lại / mở lại luôn xin link mới (số tiền do máy chủ quyết định)
                    var u = await ApiClient.PostAsync<VnPayUrlDto>("api/mobile/payment/vnpay/tao-url",
                        new { maDonHang = maDon, soTien = (long)tongTien, noiDung = (string?)null });
                    if (!u.ThanhCong || string.IsNullOrEmpty(u.DuLieu?.PaymentUrl))
                    {
                        await trang.DisplayAlert("Thanh toán VNPay", string.IsNullOrEmpty(u.ThongDiep) ? "Không tạo được liên kết thanh toán." : u.ThongDiep, "OK");
                        return false;
                    }
                    paymentUrl = u.DuLieu!.PaymentUrl;
                }
                try { await Browser.Default.OpenAsync(new Uri(paymentUrl!), BrowserLaunchMode.SystemPreferred); }
                catch
                {
                    await trang.DisplayAlert("Thanh toán VNPay", "Không mở được trang thanh toán. Hãy mở lại đơn trong mục Đơn hàng để thanh toán.", "OK");
                    return false;
                }
                paymentUrl = null;
                moTrang = false;
            }

            var chon = await trang.DisplayActionSheet(
                loiTruoc ?? "Hoàn tất thanh toán trên trang VNPay, rồi quay lại ứng dụng và bấm kiểm tra kết quả.",
                "Để sau", null, NutKiemTra, NutMoLai);

            if (chon == NutMoLai) { moTrang = true; loiTruoc = null; continue; }
            if (chon != NutKiemTra) return false;

            var r = await ApiClient.GetAsync<VnPayTrangThaiDto>($"api/mobile/don-hang/{maDon}/thanh-toan");
            if (!r.ThanhCong || r.DuLieu is null) { loiTruoc = r.ThongDiep; continue; }

            if (r.DuLieu.DaThanhToan)
            {
                await trang.DisplayAlert("Thanh toán thành công ✅", $"Đơn #{donId} đã được ghi nhận thanh toán.", "OK");
                return true;
            }
            if (r.DuLieu.DonDaHuy)
            {
                await trang.DisplayAlert("Đơn đã hủy", $"Đơn #{donId} đã bị hủy nên không thể thanh toán.", "OK");
                return false;
            }
            // v65: chưa thấy kết quả (IPN/return có thể bị mất) → nhờ MÁY CHỦ hỏi lại cổng VNPay; máy chủ chỉ cập nhật khi cổng xác nhận đã thu đúng tiền.
            if (!r.DuLieu.ThatBai)
            {
                var lai = await ApiClient.PostAsync<KiemTraLaiDto>($"api/mobile/don-hang/{maDon}/thanh-toan/kiem-tra-lai", null);
                if (lai.ThanhCong && lai.DuLieu is { DaThanhToan: true })
                {
                    await trang.DisplayAlert("Thanh toán thành công ✅", $"Đơn #{donId} đã được cổng VNPay xác nhận.", "OK");
                    return true;
                }
            }
            loiTruoc = r.DuLieu.ThatBai
                ? "Thanh toán chưa thành công hoặc đã bị hủy. Bạn có thể mở lại trang thanh toán để thử lại."
                : "Chưa nhận được kết quả. Nếu bạn đã trả tiền, chờ vài giây rồi kiểm tra lại.";
        }
    }
}
