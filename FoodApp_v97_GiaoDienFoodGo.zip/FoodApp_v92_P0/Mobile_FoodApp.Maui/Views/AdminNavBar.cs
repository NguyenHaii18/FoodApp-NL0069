﻿namespace FoodApp.Maui.Views;

/// <summary>
/// Thanh tab dưới của khu Quản trị (Tổng quan · Quản lý · Thông báo · Cá nhân), màu tím FoodApp.
/// Các trang được mở bằng điều hướng đẩy trang nên khi chuyển tab ta quay về Tổng quan rồi mới mở trang đích.
/// </summary>
public class AdminNavBar : ContentView
{
    private static readonly (string Khoa, string Icon, string Nhan, string Route)[] Muc4 =
    {
        ("tongquan", "📊", "Tổng quan", nameof(AdminHomePage)),
        ("quanly", "🗂", "Quản lý", nameof(AdminHubPage)),
        ("thongbao", "🔔", "Thông báo", nameof(AdminNotificationsPage)),
        ("canhan", "👤", "Cá nhân", nameof(AdminProfilePage)),
    };

    private string _muc = "";
    public string Muc { get => _muc; set { _muc = value; Ve(); } }

    public AdminNavBar() => Ve();

    private void Ve()
    {
        var luoi = new Grid { Padding = new Thickness(4, 6, 4, 8) };
        luoi.SetAppThemeColor(BackgroundColorProperty, Colors.White, Color.FromArgb("#2B2250"));
        for (int i = 0; i < Muc4.Length; i++)
        {
            var (khoa, icon, nhan, route) = Muc4[i];
            var chon = khoa == _muc;
            luoi.ColumnDefinitions.Add(new ColumnDefinition(GridLength.Star));

            var vien = new Border
            {
                WidthRequest = 52, HeightRequest = 30, StrokeThickness = 0, HorizontalOptions = LayoutOptions.Center,
                BackgroundColor = chon ? Color.FromArgb("#EDE9FE") : Colors.Transparent,
                StrokeShape = new Microsoft.Maui.Controls.Shapes.RoundRectangle { CornerRadius = new CornerRadius(15) },
                Content = new Label { Text = icon, FontSize = 17, TextColor = Colors.Black, HorizontalOptions = LayoutOptions.Center, VerticalOptions = LayoutOptions.Center },
            };
            var chu = new Label
            {
                Text = nhan, FontSize = 10.5, HorizontalOptions = LayoutOptions.Center,
                FontAttributes = chon ? FontAttributes.Bold : FontAttributes.None,
            };
            if (chon) chu.TextColor = Color.FromArgb(AdminUi.Tim);
            else chu.SetAppThemeColor(Label.TextColorProperty, Color.FromArgb("#6B6480"), Color.FromArgb("#CFC6EA"));

            var o = new VerticalStackLayout { Spacing = 2, BackgroundColor = Colors.Transparent, Children = { vien, chu } };
            o.GestureRecognizers.Add(new TapGestureRecognizer { Command = new Command(async () => await DiToiAsync(route)) });
            luoi.Add(o, i);
        }

        var duongKe = new BoxView { HeightRequest = 1, VerticalOptions = LayoutOptions.Start, Color = Color.FromArgb("#E4DAF7") };
        Content = new Grid { Children = { luoi, duongKe } };
    }

    private static async Task DiToiAsync(string route)
    {
        try { await DiToiThatAsync(route); }
        catch (Exception ex) { Services.CrashLog.Ghi("AdminNavBar -> " + route, ex); }
    }

    private static async Task DiToiThatAsync(string route)
    {
        var shell = Shell.Current;
        if (shell is null || shell.CurrentPage?.GetType().Name == route) return;

        var nav = shell.Navigation;
        if (nav.NavigationStack.Any(p => p is AdminHomePage))
        {
            while (nav.NavigationStack.Count > 1 && nav.NavigationStack[^1] is { } top && top is not AdminHomePage)
                await nav.PopAsync(false);
        }
        if (route != nameof(AdminHomePage)) await shell.GoToAsync(route);
    }
}
