using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

[QueryProperty(nameof(DonHang), "DonHang")]
public partial class ReviewPage : ContentPage
{
    public DonHang DonHang { get; set; } = null!;

    private int _soSaoMonAn = 0;
    private int _soSaoQuan = 0;
    private int _soSaoGiaoHang = 0;
    private readonly HashSet<string> _theDaChon = new();
    private readonly List<string> _anh = new();      // ảnh đã chọn (đường dẫn trên máy), tối đa 3
    private readonly string[] _dsThe = { "Món ngon", "Đóng gói đẹp", "Giao đúng giờ", "Đúng số lượng", "Nhân viên thân thiện" };

    public ReviewPage()
    {
        InitializeComponent();
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();
        if (DonHang is not null)
        {
            LblTenGianHang.Text = DonHang.TenGianHang;
            LblMaDon.Text = $"Đơn #{DonHang.Id}";
        }
        VeSao(SaoMonAn, _soSaoMonAn, v => { _soSaoMonAn = v; VeSao(SaoMonAn, _soSaoMonAn, null!); });
        VeSao(SaoQuan, _soSaoQuan, v => { _soSaoQuan = v; VeSao(SaoQuan, _soSaoQuan, null!); });
        VeSao(SaoGiaoHang, _soSaoGiaoHang, v => { _soSaoGiaoHang = v; VeSao(SaoGiaoHang, _soSaoGiaoHang, null!); });
        VeDsThe();
        VeAnh();
    }

    private void VeSao(HorizontalStackLayout khung, int soSao, Action<int>? onChonLai)
    {
        khung.Children.Clear();
        for (int i = 1; i <= 5; i++)
        {
            var idx = i;
            var lbl = new Label
            {
                Text = i <= soSao ? "★" : "☆",
                FontSize = 30,
                TextColor = i <= soSao ? (Color)Resources["Accent"] : (Color)Resources["BorderColor"],
            };
            var tap = new TapGestureRecognizer();
            tap.Tapped += (s, e) => onChonLai?.Invoke(idx);
            lbl.GestureRecognizers.Add(tap);
            khung.Children.Add(lbl);
        }
    }

    private void VeDsThe()
    {
        DsThe.Children.Clear();
        foreach (var the in _dsThe)
        {
            var chon = _theDaChon.Contains(the);
            var frame = new Frame
            {
                Padding = new Thickness(12, 6),
                Margin = new Thickness(4),
                CornerRadius = 16,
                HasShadow = false,
                BackgroundColor = chon ? (Color)Resources["Primary"] : Colors.White,
                BorderColor = chon ? (Color)Resources["Primary"] : (Color)Resources["BorderColor"],
                Content = new Label
                {
                    Text = the,
                    FontSize = 12.5,
                    TextColor = chon ? Colors.White : (Color)Resources["TextDark"],
                }
            };
            var tap = new TapGestureRecognizer();
            tap.Tapped += (s, e) =>
            {
                if (!_theDaChon.Add(the)) _theDaChon.Remove(the);
                VeDsThe();
            };
            frame.GestureRecognizers.Add(tap);
            DsThe.Children.Add(frame);
        }
    }

    private void VeAnh()
    {
        KhungAnh.Children.Clear();
        foreach (var path in _anh.ToList())
        {
            var p = path;
            var hinh = new Image { Source = p, WidthRequest = 84, HeightRequest = 84, Aspect = Aspect.AspectFill };
            var xoa = new Label { Text = "✕", TextColor = Colors.White, BackgroundColor = Color.FromArgb("#99000000"), FontSize = 12, Padding = new Thickness(6, 2), HorizontalOptions = LayoutOptions.End, VerticalOptions = LayoutOptions.Start };
            var tap = new TapGestureRecognizer();
            tap.Tapped += (_, _) => { _anh.Remove(p); VeAnh(); };
            xoa.GestureRecognizers.Add(tap);
            var o = new Grid { Margin = new Thickness(0, 0, 8, 8), WidthRequest = 84, HeightRequest = 84 };
            o.Children.Add(hinh);
            o.Children.Add(xoa);
            KhungAnh.Children.Add(o);
        }
        BtnThemAnh.IsVisible = _anh.Count < 3;
    }

    private async void OnThemAnhClicked(object? sender, EventArgs e)
    {
        if (_anh.Count >= 3) return;
        try
        {
            var chon = await DisplayActionSheet("Thêm ảnh", "Hủy", null, "Chọn từ thư viện", "Chụp ảnh");
            if (chon is null or "Hủy") return;
            var path = await AnhService.ChonVaLuuAsync("dg_" + (DonHang?.Id ?? "x"), "Chọn ảnh món ăn", chup: chon == "Chụp ảnh");
            if (path is null) return;
            _anh.Add(path);
            VeAnh();
        }
        catch (Exception ex) { CrashLog.Ghi("ReviewPage.ThemAnh", ex); await DisplayAlert("Không thêm được ảnh", ex.Message, "Đóng"); }
    }

    /// <summary>Tải các ảnh đã chọn lên máy chủ; trả null nếu có ảnh tải lỗi (đã báo người dùng).</summary>
    private async Task<List<string>?> TaiAnhLenAsync()
    {
        var kq = new List<string>();
        if (_anh.Count == 0 || !Services.DuLieuService.DangOnline) return kq;
        foreach (var path in _anh)
        {
            var up = await ApiClient.PostFileAsync<UploadAnhDto>("api/upload/danhgia", path);
            if (!up.ThanhCong || string.IsNullOrWhiteSpace(up.DuLieu?.ImageUrl))
            {
                await DisplayAlert("Không tải được ảnh", up.ThongDiep, "OK");
                return null;
            }
            kq.Add(up.DuLieu!.ImageUrl!);
        }
        return kq;
    }

    private async void OnGuiDanhGiaClicked(object sender, EventArgs e)
    {
        if (_soSaoMonAn == 0)
        {
            await DisplayAlert("Thiếu thông tin", "Vui lòng chọn số sao cho món ăn (quán và tài xế có thể bỏ qua).", "Đóng");
            return;
        }

        // Lưu đánh giá vào đơn (giữ qua các lần mở app) rồi gửi lên API nếu đang online.
        if (DonHang is not null)
        {
            var theDanhGia = string.Join("|", _theDaChon);
            var noiDungDanhGia = EditorNoiDung.Text?.Trim() ?? "";
            var anhLen = await TaiAnhLenAsync();
            if (anhLen is null) return;
            // Server xác nhận trước; không gửi được thì dừng (người dùng giữ nguyên form để gửi lại), không báo "cảm ơn" giả.
            if (!await Services.DuLieuService.GhiAsync("POST", "api/mobile/danh-gia", new
            {
                donHangId = DonHang.Id, gianHangId = DonHang.GianHangId,
                soSaoMonAn = _soSaoMonAn, soSaoQuan = _soSaoQuan, soSaoGiaoHang = _soSaoGiaoHang,
                theNhanXet = theDanhGia, noiDung = noiDungDanhGia, anh = anhLen,
            })) return;
            DonHang.DiemMonAn = _soSaoMonAn;
            DonHang.TheDanhGia = theDanhGia;
            DonHang.NoiDungDanhGia = noiDungDanhGia;
            Services.DonHangService.DongBo(DonHang);
        }

        // Điểm "Tài xế & dịch vụ giao hàng" chuyển cho tài xế của đơn này
        if (DonHang is not null && _soSaoGiaoHang > 0)
        {
            DonHang.DiemTaiXe = _soSaoGiaoHang;
            DonHang.NhanXetTaiXe = EditorNoiDung.Text?.Trim() ?? "";
            Services.DonHangService.DongBo(DonHang);
            Services.ThuNhapService.CapNhatChiSo();
        }

        // Lưu để gian hàng xem được ở mục "Đánh giá", cập nhật điểm trung bình của quán và gửi thông báo cho quán.
        if (DonHang is not null)
            DoiTacService.GhiDanhGia(DonHang, _soSaoMonAn, _soSaoGiaoHang, _theDaChon, EditorNoiDung.Text ?? "", _anh.ToList());

        KhungForm.IsVisible = false;
        KhungCamOn.IsVisible = true;
    }

    private async Task BaoVanDeAsync(string loai)
    {
        if (DonHang is null || !int.TryParse(DonHang.Id, out _))
        {
            await DisplayAlert("Chưa báo được", "Chỉ đơn đã đồng bộ với máy chủ mới gửi được báo cáo. Hãy kết nối mạng và mở lại đơn.", "OK");
            return;
        }
        await Shell.Current.GoToAsync($"{nameof(HoTroPage)}?DonHangId={DonHang.Id}&Loai={loai}");
    }
    private async void OnBaoMonLoiClicked(object sender, EventArgs e) => await BaoVanDeAsync("ChatLuong");
    private async void OnBaoGiaoChamClicked(object sender, EventArgs e) => await BaoVanDeAsync("GiaoTre");

    private async void OnQuayLaiClicked(object sender, EventArgs e)
    {
        await Shell.Current.GoToAsync("..");
    }
}
