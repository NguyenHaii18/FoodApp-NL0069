using System.Text;
using FoodApp.Maui.Models;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.Views;

/// <summary>
/// Khách hàng: lịch sử thanh toán, hóa đơn / biên nhận từng đơn (chia sẻ được), theo dõi hoàn tiền và lịch sử dùng voucher.
/// Dữ liệu lấy từ danh sách đơn của khách đã đồng bộ về máy (MockData.LichSuDonHang).
/// </summary>
public sealed class LichSuThanhToanPage : ContentPage
{
    private readonly VerticalStackLayout _ds = new() { Spacing = 10 };
    private readonly HorizontalStackLayout _tab = new() { Spacing = 8 };
    private readonly Label _tomTat = new() { FontSize = 12.5, TextColor = Colors.Gray };
    private int _chon;
    private static readonly string[] Tabs = { "Thanh toán", "Hoàn tiền", "Voucher đã dùng" };

    public LichSuThanhToanPage()
    {
        Title = "Thanh toán & hóa đơn";
        Content = new RefreshView
        {
            Command = new Command(async () => { await TaiAsync(); }),
            Content = new ScrollView { Content = new VerticalStackLayout { Padding = new Thickness(16), Spacing = 12, Children =
            {
                new ScrollView { Orientation = ScrollOrientation.Horizontal, Content = _tab }, _tomTat, _ds,
            } } }
        };
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();
        await TaiAsync();
    }

    private async Task TaiAsync()
    {
        try { if (DuLieuService.DangOnline && Phien.Khach is not null) await DuLieuService.TaiDonHangKhachAsync(); }
        catch { /* mất mạng: dùng dữ liệu đã có trên máy */ }
        if (Content is RefreshView rv) rv.IsRefreshing = false;
        Ve();
    }

    private static List<DonHang> DonCuaToi() =>
        MockData.LichSuDonHang.Where(OrderTrackingPage.DonCuaToi).OrderByDescending(d => d.NgayDat).ToList();

    private void Ve()
    {
        _tab.Children.Clear();
        for (var i = 0; i < Tabs.Length; i++)
        {
            var idx = i;
            var b = new Button { Text = Tabs[i], FontSize = 12.5, HeightRequest = 38, CornerRadius = 19, Padding = new Thickness(14, 0),
                BackgroundColor = i == _chon ? Color.FromArgb("#6D28D9") : Color.FromArgb("#EDE4FF"), TextColor = i == _chon ? Colors.White : Color.FromArgb("#4C1D95") };
            b.Clicked += (_, _) => { _chon = idx; Ve(); };
            _tab.Children.Add(b);
        }

        _ds.Children.Clear();
        var don = DonCuaToi();
        if (Phien.Khach is null) { _tomTat.Text = "Hãy đăng nhập để xem lịch sử."; return; }

        IEnumerable<DonHang> ds;
        switch (_chon)
        {
            case 0:
                ds = don.Where(d => d.TrangThai != TrangThaiDonHang.DaHuy || d.TrangThaiThanhToan == "DaThanhToan" || d.DaHoanTien).ToList();
                var tra = don.Where(d => d.TrangThai == TrangThaiDonHang.HoanThanh).Sum(d => d.TongThanhToan);
                _tomTat.Text = $"{ds.Count()} giao dịch · tổng đã chi cho đơn hoàn thành: {tra:N0}đ";
                break;
            case 1:
                ds = don.Where(d => d.DaHoanTien || d.TrangThaiThanhToan == "DaHoanTien").ToList();
                _tomTat.Text = ds.Any() ? $"{ds.Count()} khoản hoàn tiền · tổng {ds.Sum(d => d.TongThanhToan):N0}đ" : "Chưa có khoản hoàn tiền nào.";
                break;
            default:
                ds = don.Where(d => !string.IsNullOrWhiteSpace(d.MaKhuyenMai) && d.TrangThai != TrangThaiDonHang.DaHuy).ToList();
                _tomTat.Text = ds.Any() ? $"Đã dùng {ds.Count()} lần · tiết kiệm {ds.Sum(d => d.GiamGia):N0}đ" : "Bạn chưa dùng voucher nào.";
                break;
        }

        foreach (var d in ds) _ds.Children.Add(VeThe(d));
    }

    private View VeThe(DonHang d)
    {
        var st = new VerticalStackLayout { Spacing = 3 };
        st.Children.Add(new Label { Text = $"Đơn #{d.Id} · {d.TenGianHang}", FontAttributes = FontAttributes.Bold, FontSize = 14 });
        st.Children.Add(new Label { Text = d.NgayDat.ToString("dd/MM/yyyy HH:mm"), FontSize = 11.5, TextColor = Colors.Gray });
        if (_chon == 2)
            st.Children.Add(new Label { Text = $"🎟 {d.MaKhuyenMai} · giảm {d.GiamGia:N0}đ", FontSize = 13, TextColor = Colors.SeaGreen, FontAttributes = FontAttributes.Bold });
        else
        {
            st.Children.Add(new Label { Text = $"💳 {d.HinhThucHienThi}", FontSize = 12.5 });
            st.Children.Add(new Label { Text = $"Tổng: {d.TongThanhToan:N0}đ", FontSize = 13.5, FontAttributes = FontAttributes.Bold });
            if (d.DaHoanTien || d.TrangThaiThanhToan == "DaHoanTien")
                st.Children.Add(new Label { Text = "✅ Đã hoàn tiền " + d.TongThanhToan.ToString("N0") + "đ", FontSize = 12.5, TextColor = Colors.SeaGreen });
            else if (d.TrangThai == TrangThaiDonHang.DaHuy && d.TrangThaiThanhToan == "DaThanhToan")
                st.Children.Add(new Label { Text = "⏳ Đơn đã hủy — đang xử lý hoàn tiền", FontSize = 12.5, TextColor = Colors.DarkOrange });
        }
        var xem = new Button { Text = "🧾 Xem hóa đơn", FontSize = 12, HeightRequest = 34, CornerRadius = 10, HorizontalOptions = LayoutOptions.Start };
        xem.Clicked += async (_, _) => await HienHoaDonAsync(d);
        st.Children.Add(xem);
        return new Frame { Content = st, Padding = new Thickness(12), CornerRadius = 12, HasShadow = false, BorderColor = Color.FromArgb("#E5E7EB") };
    }

    private static string DungHoaDon(DonHang d)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"HÓA ĐƠN / BIÊN NHẬN — Đơn #{d.Id}");
        sb.AppendLine($"Quán: {d.TenGianHang}");
        sb.AppendLine($"Thời gian: {d.NgayDat:dd/MM/yyyy HH:mm}");
        sb.AppendLine($"Giao đến: {d.DiaChiGiao}");
        sb.AppendLine("------------------------------");
        foreach (var m in d.ChiTiet)
        {
            sb.AppendLine($"{m.SoLuong} x {m.MonAn?.TenMon}  {m.ThanhTien:N0}đ");
            if (!string.IsNullOrWhiteSpace(m.TuyChonHienThi)) sb.AppendLine($"   + {m.TuyChonHienThi}");
        }
        sb.AppendLine("------------------------------");
        sb.AppendLine($"Tiền hàng: {d.TongTien:N0}đ");
        sb.AppendLine($"Phí giao hàng: {d.PhiGiaoHang:N0}đ");
        if (d.GiamGia > 0) sb.AppendLine($"Giảm giá{(string.IsNullOrWhiteSpace(d.MaKhuyenMai) ? "" : " (" + d.MaKhuyenMai + ")")}: -{d.GiamGia:N0}đ");
        sb.AppendLine($"TỔNG THANH TOÁN: {d.TongThanhToan:N0}đ");
        sb.AppendLine($"Hình thức: {d.HinhThucHienThi}");
        if (d.DaHoanTien) sb.AppendLine("Đã hoàn tiền cho khách.");
        return sb.ToString();
    }

    private async Task HienHoaDonAsync(DonHang d)
    {
        var nd = DungHoaDon(d);
        var c = await DisplayActionSheet(nd, "Đóng", null, "Chia sẻ hóa đơn", "Sao chép", "Gửi yêu cầu hỗ trợ cho đơn này");
        if (c == "Chia sẻ hóa đơn") await Share.Default.RequestAsync(new ShareTextRequest { Text = nd, Title = $"Hóa đơn đơn #{d.Id}" });
        else if (c == "Sao chép") { await FoodApp.Maui.Services.ClipboardAnToan.SaoChepAsync(nd); await DisplayAlert("Đã sao chép", "Đã sao chép hóa đơn.", "OK"); }
        else if (c == "Gửi yêu cầu hỗ trợ cho đơn này" && int.TryParse(d.Id, out _)) await Shell.Current.GoToAsync($"{nameof(HoTroPage)}?DonHangId={d.Id}");
    }
}
