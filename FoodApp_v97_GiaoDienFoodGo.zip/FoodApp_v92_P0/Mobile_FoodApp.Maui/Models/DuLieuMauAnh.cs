namespace FoodApp.Maui.Models;

/// <summary>
/// Gắn ảnh món/quán đóng gói sẵn (Resources/Images) cho dữ liệu mẫu ngoại tuyến, đúng với từng quán:
/// bún riêu → Bún Riêu Cua Bà Sáu, bún chả → Bún Chả Hương Liên, bún thịt nướng → Bún Thịt Nướng Chị Tuyền,
/// trà cam tắc → Trà Đào Cam Sả Nhà Mình, cơm chiên → Cơm Niêu Thố Sài Gòn (thêm 2 món cơm chiên).
/// Chạy lại nhiều lần an toàn; không ghi đè ảnh quán đã tự tải lên (AnhPath luôn được ưu tiên khi hiển thị).
/// </summary>
public static class DuLieuMauAnh
{
    private static readonly Dictionary<string, string> AnhQuan = new()
    {
        ["gh21"] = "bun_cha.jpg",            // Bún Chả Hương Liên
        ["gh31"] = "com_chien_tom_2.jpg",    // Cơm Niêu Thố Sài Gòn
        ["gh32"] = "bun_rieu_1.jpg",         // Bún Riêu Cua Bà Sáu
        ["gh36"] = "tra_cam_tac.jpg",        // Trà Đào Cam Sả Nhà Mình
        ["gh43"] = "bun_thit_nuong.jpg",     // Bún Thịt Nướng Chị Tuyền
    };

    // (Id quán, tên món, ảnh)
    private static readonly (string Gh, string Mon, string Anh)[] AnhMon =
    {
        ("gh21", "Bún chả nem rán",          "bun_cha.jpg"),
        ("gh21", "Bún chả đặc biệt",         "bun_cha.jpg"),
        ("gh32", "Bún riêu cua đồng",        "bun_rieu_1.jpg"),
        ("gh32", "Bún riêu giò chả",         "bun_rieu_2.jpg"),
        ("gh36", "Trà đào cam sả",           "tra_cam_tac.jpg"),
        ("gh43", "Bún thịt nướng chả giò",   "bun_thit_nuong.jpg"),
        ("gh43", "Bún thịt nướng đặc biệt",  "bun_thit_nuong.jpg"),
        ("gh31", "Cơm chiên tôm",            "com_chien_tom_1.jpg"),
        ("gh31", "Cơm chiên lạp xưởng",      "com_chien_lap_xuong.jpg"),
    };

    // Món bổ sung cho quán cơm (chưa có món cơm chiên): Id, quán, tên, giá, danh mục
    private static readonly (string Id, string Gh, string Ten, decimal Gia, string DanhMuc)[] MonThem =
    {
        ("ma301", "gh31", "Cơm chiên tôm",       58000, "Món chính"),
        ("ma302", "gh31", "Cơm chiên lạp xưởng", 48000, "Món chính"),
    };

    public static void Gan()
    {
        var doi = false;

        foreach (var (id, gh, ten, gia, dm) in MonThem)
        {
            if (MockData.DanhSachGianHang.All(g => g.Id != gh)) continue;                          // quán chưa có trên máy
            if (MockData.DanhSachMonAn.Any(m => m.GianHangId == gh && m.TenMon == ten)) continue;   // món đã có
            MockData.DanhSachMonAn.Add(new MonAn
            {
                Id = id, TenMon = ten, Gia = gia, HinhAnh = "🍚", DanhMuc = dm,
                GianHangId = gh, ConHang = true,
            });
            doi = true;
        }

        foreach (var g in MockData.DanhSachGianHang)
            if (AnhQuan.TryGetValue(g.Id, out var anh) && g.AnhMau != anh) { g.AnhMau = anh; doi = true; }

        foreach (var (gh, ten, anh) in AnhMon)
        {
            var mon = MockData.DanhSachMonAn.FirstOrDefault(m => m.GianHangId == gh && m.TenMon == ten);
            if (mon is not null && mon.AnhMau != anh) { mon.AnhMau = anh; doi = true; }
        }

        if (doi) Services.VendorLocalStore.Luu();
    }
}
