namespace FoodApp.Maui.Models;

/// <summary>
/// Gắn sẵn tùy chọn Size (S / M / L) cho các món nước trong dữ liệu mẫu ngoại tuyến để khách chọn được size khi đặt.
/// Món nào đã có Size (do gian hàng tự cấu hình) thì giữ nguyên. Chạy lại nhiều lần an toàn.
/// </summary>
public static class DuLieuMauSize
{
    private static readonly string[] TuKhoaNuoc =
    {
        "uống", "thức uống", "trà", "cà phê", "ca phe", "đá xay", "sinh tố", "nước ngọt", "sữa chua", "nước ép", "smoothie",
    };

    private static readonly (string Ten, decimal GiaThem)[] SizeMacDinh = { ("S", 0), ("M", 5000), ("L", 10000) };

    public static bool LaMonNuoc(MonAn m)
    {
        var dm = (m.DanhMuc ?? "").ToLowerInvariant();
        return TuKhoaNuoc.Any(k => dm.Contains(k));
    }

    public static void Gan()
    {
        var coDoi = false;
        foreach (var m in MockData.DanhSachMonAn)
        {
            if (!LaMonNuoc(m) || m.TuyChon.Any(t => t.Loai == TuyChonMon.Size)) continue;
            foreach (var (ten, gia) in SizeMacDinh)
                m.TuyChon.Add(new TuyChonMon { Loai = TuyChonMon.Size, Ten = ten, GiaThem = gia });
            coDoi = true;
        }
        if (coDoi) Services.VendorLocalStore.Luu();
    }
}
