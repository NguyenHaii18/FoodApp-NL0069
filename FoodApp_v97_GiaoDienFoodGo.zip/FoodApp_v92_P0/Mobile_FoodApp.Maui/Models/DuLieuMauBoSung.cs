namespace FoodApp.Maui.Models;

/// <summary>
/// Dữ liệu mẫu bổ sung (chế độ ngoại tuyến): 15 gian hàng (gh31–gh45) + 10 tài khoản tài xế (tx2–tx11).
/// Chạy an toàn nhiều lần (bỏ qua quán/tài xế đã có) và cũng áp dụng được khi máy đã có dữ liệu lưu từ các lần chạy trước
/// — khác với <see cref="DuLieuMauNgoaiTuyen.NapNeuChuaCo"/> chỉ chạy khi danh sách gian hàng còn trống.
/// Tài khoản: xem Docs/TAI_KHOAN_MAU_BO_SUNG.md (mật khẩu chung 123456).
/// </summary>
public static class DuLieuMauBoSung
{
    public static void Nap()
    {
        try { NapGianHang(); } catch (Exception ex) { Services.CrashLog.Ghi("DuLieuMauBoSung.GianHang", ex); }
        try { NapTaiXe(); } catch (Exception ex) { Services.CrashLog.Ghi("DuLieuMauBoSung.TaiXe", ex); }
        try { DuLieuMauAnh.Gan(); } catch (Exception ex) { Services.CrashLog.Ghi("DuLieuMauBoSung.Anh", ex); }   // ảnh món/quán đóng gói sẵn
        try { DuLieuMauSize.Gan(); } catch (Exception ex) { Services.CrashLog.Ghi("DuLieuMauBoSung.Size", ex); }   // size S/M/L cho món nước
    }

    private static void NapGianHang()
    {
        var ds = new (string Id, string Ten, string DiaChi, string Anh, string Loai, double Sao, int Phut, string Email, string Sdt,
                      string DanhMuc, string M1, decimal G1, string M2, decimal G2, string M3, decimal G3)[]
        {
            ("gh31", "Cơm Niêu Thố Sài Gòn",       "41 Nguyễn Đình Chiểu, Q.3",   "🍚", "com",   4.6, 24, "comnieutho@foodapp.vn",     "0865000131", "Món chính", "Cơm niêu sườn nướng", 58000, "Cơm niêu cá kho tộ", 55000, "Cơm niêu gà sả ớt", 52000),
            ("gh32", "Bún Riêu Cua Bà Sáu",        "12 Hoàng Văn Thụ, Q.Tân Bình","🍜", "bun",   4.7, 22, "bunrieubasau@foodapp.vn",   "0865000132", "Món chính", "Bún riêu cua đồng", 45000, "Bún riêu giò chả", 52000, "Bún riêu chay", 38000),
            ("gh33", "Hủ Tiếu Nam Vang Thành Đạt", "88 Võ Thị Sáu, Q.3",          "🍲", "pho",   4.5, 20, "hutieunamvang@foodapp.vn",  "0865000133", "Món chính", "Hủ tiếu Nam Vang đặc biệt", 55000, "Hủ tiếu khô", 50000, "Mì hoành thánh", 48000),
            ("gh34", "Bánh Cuốn Nóng Thanh Trì",   "150 Nguyễn Thái Học, Q.1",    "🥟", "banh",  4.4, 18, "banhcuonthanhtri@foodapp.vn","0865000134", "Món chính", "Bánh cuốn nhân thịt", 38000, "Bánh cuốn chả quế", 45000, "Bánh giò", 18000),
            ("gh35", "Gà Nướng Ò Ó O",             "33 Trần Hưng Đạo, Q.5",       "🍗", "ga",    4.5, 30, "ganuongoo@foodapp.vn",      "0865000135", "Gà nướng", "Gà nướng muối ớt (nửa con)", 125000, "Cánh gà nướng mật ong", 69000, "Đùi gà nướng sả", 59000),
            ("gh36", "Trà Đào Cam Sả Nhà Mình",    "21 Nguyễn Huệ, Q.1",          "🍹", "tra",   4.6, 14, "tradaocamsa@foodapp.vn",    "0865000136", "Thức uống", "Trà đào cam sả", 35000, "Trà vải hoa hồng", 38000, "Trà oolong sữa", 36000),
            ("gh37", "Pizza & Pasta Napoli",       "105 Nguyễn Văn Cừ, Q.5",      "🍕", "pizza", 4.6, 32, "pizzanapoli@foodapp.vn",    "0865000137", "Pizza & Mì Ý", "Pizza Margherita", 109000, "Pizza xúc xích Ý", 129000, "Mì Ý carbonara", 79000),
            ("gh38", "Ramen Ichiban",              "8 Lê Thánh Tôn, Q.1",         "🍜", "nhat",  4.7, 30, "ramenichiban@foodapp.vn",   "0865000138", "Món Nhật", "Ramen tonkotsu", 95000, "Ramen miso trứng", 89000, "Gyoza chiên (6 cái)", 49000),
            ("gh39", "Cà Phê Sân Vườn Hẻm Xanh",   "52 Trần Quang Diệu, Q.3",     "☕", "cafe",  4.5, 15, "caphehemxanh@foodapp.vn",   "0865000139", "Cà phê", "Cà phê sữa đá", 28000, "Cà phê cốt dừa", 39000, "Bạc xỉu đá", 30000),
            ("gh40", "Chè Thập Cẩm Hạnh Phúc",     "120 Trần Phú, Q.5",           "🍧", "che",   4.4, 16, "chethapcam@foodapp.vn",     "0865000140", "Chè", "Chè thập cẩm", 25000, "Chè bưởi", 28000, "Sâm bổ lượng", 24000),
            ("gh41", "Bánh Mì Chảo Hòa Hảo",       "24 Hòa Hảo, Q.10",            "🥖", "banh",  4.5, 16, "banhmichao@foodapp.vn",     "0865000141", "Bánh mì", "Bánh mì chảo đầy đủ", 49000, "Bánh mì chảo bò né", 59000, "Bánh mì ốp la pate", 28000),
            ("gh42", "Cơm Gà Hải Nam Chin Chin",   "17 Trần Hưng Đạo B, Q.5",     "🍛", "com,ga",4.6, 26, "comgahainam@foodapp.vn",    "0865000142", "Món chính", "Cơm gà Hải Nam", 55000, "Cơm gà quay", 59000, "Cơm gà chiên giòn", 52000),
            ("gh43", "Bún Thịt Nướng Chị Tuyền",   "205 Cô Giang, Q.1",           "🍜", "bun",   4.6, 21, "bunthitnuong@foodapp.vn",   "0865000143", "Món chính", "Bún thịt nướng chả giò", 48000, "Bún thịt nướng đặc biệt", 58000, "Bún chả giò", 40000),
            ("gh44", "Trà Sữa Đài Loan Lucky",     "64 Hoàng Diệu, Q.4",          "🧋", "tra",   4.5, 17, "trasualucky@foodapp.vn",    "0865000144", "Trà sữa", "Trà sữa trân châu hoàng kim", 39000, "Trà sữa matcha", 42000, "Sữa tươi trân châu đường đen", 45000),
            ("gh45", "Lẩu Bò Lá Giang Út Nhỏ",     "19 Bàn Cờ, Q.3",              "🍲", "pho",   4.5, 35, "laubolagiang@foodapp.vn",   "0865000145", "Lẩu", "Lẩu bò lá giang (2 người)", 229000, "Bò nhúng giấm", 189000, "Bò viên chiên", 49000),
        };

        var maMon = 201;
        foreach (var g in ds)
        {
            var maDau = maMon; maMon += 3;   // mỗi quán giữ đúng 3 mã món, kể cả khi quán đã có sẵn
            if (MockData.DanhSachGianHang.Any(x => x.Id == g.Id ||
                    string.Equals(x.Email, g.Email, StringComparison.OrdinalIgnoreCase))) continue;

            MockData.DanhSachGianHang.Add(new GianHang
            {
                Id = g.Id, TenGianHang = g.Ten, DiaChi = g.DiaChi, HinhAnh = g.Anh, PhanLoai = g.Loai,
                DanhGia = g.Sao, ThoiGianGiaoPhut = g.Phut, DangMoCua = true, DangNhanDon = true,
                SoDienThoai = g.Sdt, Email = g.Email, MatKhau = "123456",
                TrangThaiDangKy = TrangThaiDangKyGianHang.DaDuyet,
            });
            var mon = new[] { (g.M1, g.G1), (g.M2, g.G2), (g.M3, g.G3) };
            for (var i = 0; i < mon.Length; i++)
                MockData.DanhSachMonAn.Add(new MonAn
                {
                    Id = "ma" + (maDau + i), TenMon = mon[i].Item1, Gia = mon[i].Item2, HinhAnh = g.Anh,
                    DanhMuc = g.DanhMuc, GianHangId = g.Id, ConHang = true,
                });
        }
        Services.VendorLocalStore.Luu();
    }

    private static void NapTaiXe()
    {
        var ds = new (string Id, string Ten, string Sdt, string Xe, string Bien, double Sao, string Anh)[]
        {
            ("tx2",  "Trần Minh Tuấn",   "0386000002", "Xe máy",   "59-C1 234.56", 4.8, "🛵"),
            ("tx3",  "Lê Quốc Khánh",    "0386000003", "Xe máy",   "59-D1 345.67", 4.7, "🏍️"),
            ("tx4",  "Phạm Văn Dũng",    "0386000004", "Xe máy",   "59-E2 456.78", 4.9, "🛵"),
            ("tx5",  "Nguyễn Thanh Sơn", "0386000005", "Xe máy",   "59-F1 567.89", 4.6, "🏍️"),
            ("tx6",  "Võ Hoàng Nam",     "0386000006", "Xe máy",   "59-G1 678.90", 4.8, "🛵"),
            ("tx7",  "Đặng Thị Thu Hà",  "0386000007", "Xe máy",   "59-H1 789.01", 4.9, "🛵"),
            ("tx8",  "Bùi Anh Kiệt",     "0386000008", "Xe điện",  "59-MĐ 890.12", 4.5, "🛴"),
            ("tx9",  "Huỳnh Gia Bảo",    "0386000009", "Xe máy",   "59-K1 901.23", 4.7, "🏍️"),
            ("tx10", "Ngô Thị Mỹ Linh",  "0386000010", "Xe máy",   "59-L1 012.34", 4.8, "🛵"),
            ("tx11", "Trương Đức Thịnh", "0386000011", "Xe máy",   "59-M1 123.45", 4.6, "🏍️"),
        };

        var coMoi = false;
        var i = 0;
        foreach (var d in ds)
        {
            i++;
            if (Services.TaiXeStore.TimTheoSdt(d.Sdt) is not null) continue;
            var t = new TaiXe
            {
                Id = d.Id, HoTen = d.Ten, SoDienThoai = d.Sdt, LoaiXe = d.Xe, BienSoXe = d.Bien,
                Anh = d.Anh, DanhGia = d.Sao, DangHoatDong = true,
                SoCccd = $"0790950{i:D5}", SoGplx = $"7900{i:D8}",
                TrangThaiDangKy = TrangThaiDangKyGianHang.DaDuyet, NgayDangKy = DateTime.Now,
            };
            Services.TaiXeStore.DatMatKhau(t, "123456", luu: false);
            MockData.DanhSachTaiXe.Add(t);
            coMoi = true;
        }
        if (coMoi) Services.TaiXeStore.Luu();
    }
}
