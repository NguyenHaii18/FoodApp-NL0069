namespace FoodApp.Maui.Models;

/// <summary>Một dòng trong "Đơn của tôi" của tài xế — khớp DriverOrderListItemDto của Web (GET api/mobile/tai-xe/don-hang?tab=...).</summary>
public class DonTaiXeItem
{
    public int MaDonHang { get; set; }
    public string TrangThai { get; set; } = "";
    public string TrangThaiGiao { get; set; } = "";
    public DateTime NgayDat { get; set; }
    public string TenGianHang { get; set; } = "";
    public string DiaChiGianHang { get; set; } = "";
    public string DiaChiGiaoHang { get; set; } = "";
    public decimal TongTien { get; set; }
    public decimal PhiGiaoHang { get; set; }
    public bool LaCod { get; set; }
    public string TrangThaiThanhToan { get; set; } = "";

    public string TieuDe => $"Đơn #{MaDonHang} · {TenGianHang}";
    public string NhanThu => LaCod ? $"Thu hộ {TongTien:N0}đ (COD)" : $"{TrangThaiThanhToan} · không thu tiền";
    public string NhanPhi => $"+{PhiGiaoHang:N0}đ";
    public string NgayText => NgayDat.ToString("dd/MM HH:mm");

    // --- hiển thị thẻ đơn (kiểu FOODAPP) ---
    public string MaHienThi => $"#{MaDonHang}";
    public string NhanTrangThai => TrangThaiGiao switch
    {
        "DaNhan" => "Chờ lấy hàng", "DangGiao" => "Đang giao", "GiaoThanhCong" => "Hoàn thành", "GiaoThatBai" => "Đã hủy", _ => TrangThaiGiao
    };
    public string MauChuTrangThai => TrangThaiGiao switch
    {
        "DaNhan" => "#B45309", "DangGiao" => "#6D28D9", "GiaoThanhCong" => "#0F9D58", _ => "#6B7280"
    };
    public string MauNenTrangThai => TrangThaiGiao switch
    {
        "DaNhan" => "#FDEFD3", "DangGiao" => "#EDE9FE", "GiaoThanhCong" => "#DFF5E7", _ => "#ECEEF0"
    };
    public string MauChamTrangThai => TrangThaiGiao switch
    {
        "DaNhan" => "#F59E0B", "DangGiao" => "#6D28D9", "GiaoThanhCong" => "#0F9D58", _ => "#9CA3AF"
    };
}

public class MonDonTaiXe
{
    public string TenMon { get; set; } = "";
    public int SoLuong { get; set; }
    public decimal DonGia { get; set; }
    public decimal ThanhTien { get; set; }
    public string Dong => $"{SoLuong} × {TenMon}   {ThanhTien:N0}đ";
}

/// <summary>Chi tiết đơn của tài xế — khớp DriverOrderDetailDto (SĐT khách chỉ có khi đơn đang thực hiện).</summary>
public class DonTaiXeChiTiet
{
    public int MaDonHang { get; set; }
    public string TrangThai { get; set; } = "";
    public string TrangThaiGiao { get; set; } = "";
    public DateTime NgayDat { get; set; }
    public string TenGianHang { get; set; } = "";
    public string DiaChiGianHang { get; set; } = "";
    public string? SdtGianHang { get; set; }
    public string TenKhach { get; set; } = "";
    public string? SdtKhach { get; set; }
    public bool HienSdtKhach { get; set; }
    public string DiaChiGiaoHang { get; set; } = "";
    public string? GhiChu { get; set; }
    public decimal TongTien { get; set; }
    public decimal PhiGiaoHang { get; set; }
    public string HinhThucThanhToan { get; set; } = "";
    public string TrangThaiThanhToan { get; set; } = "";
    public bool LaCod { get; set; }
    public decimal SoTienCanThu { get; set; }
    public decimal? TienThuCOD { get; set; }
    public string? LyDoThatBai { get; set; }
    public List<MonDonTaiXe> ChiTiet { get; set; } = new();
}

public static class DonTaiXeNhan
{
    public static string TrangThaiGiao(string t) => t switch
    {
        "DaNhan" => "Đã nhận — đang đến quán",
        "DangGiao" => "Đang giao",
        "GiaoThanhCong" => "Hoàn thành",
        "GiaoThatBai" => "Giao thất bại / đã hủy",
        _ => t
    };
}
