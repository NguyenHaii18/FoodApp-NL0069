# Chạy app MAUI (Windows) từ VS Code / PowerShell.
# WinUI/Windows App SDK sập (mã 0xc000027b) nếu đường dẫn dự án có ký tự không phải ASCII (vd "HKI_Năm4").
# Script này: nếu đường dẫn có dấu -> chép sang C:\FoodApp_Build rồi chạy ở đó; ngược lại chạy tại chỗ.
$ErrorActionPreference = 'Stop'
$src = $PSScriptRoot
$tfm = 'net8.0-windows10.0.19041.0'

if ($src -match '[^\u0000-\u007F]') {
    $dst = 'C:\FoodApp_Build'
    Write-Host "Đường dẫn có ký tự có dấu -> chép sang $dst" -ForegroundColor Yellow
    robocopy $src $dst /MIR /XD bin obj .vs /NFL /NDL /NJH /NJS | Out-Null
    $src = $dst
}
Set-Location $src
Remove-Item -Recurse -Force bin, obj -ErrorAction SilentlyContinue
dotnet restore .\FoodApp.Maui.csproj
dotnet run --project .\FoodApp.Maui.csproj -f $tfm -p:Unpackaged=true
Write-Host "Nếu app sập khi khởi động, xem: $env:LOCALAPPDATA\FoodApp_crash.log"
