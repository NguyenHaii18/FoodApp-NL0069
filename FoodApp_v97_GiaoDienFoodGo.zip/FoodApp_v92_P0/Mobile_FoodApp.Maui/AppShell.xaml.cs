﻿using FoodApp.Maui.Views;

namespace FoodApp.Maui;

public partial class AppShell : Shell
{
    private static bool _daDangKyRoute;

    public AppShell()
    {
        InitializeComponent();
        if (_daDangKyRoute) return;   // AppShell được tạo lại khi đổi màu chủ đề — chỉ đăng ký route một lần
        _daDangKyRoute = true;

        // Phiên hết hạn (máy chủ trả 401 cho token đang dùng): xóa phiên, báo người dùng và quay về trang đăng nhập.
        Services.ApiClient.PhienHetHan += () => MainThread.BeginInvokeOnMainThread(async () =>
        {
            try
            {
                Services.Phien.DangXuat();
                if (Shell.Current is null) return;
                await Shell.Current.DisplayAlert("Phiên đăng nhập đã hết hạn", "Vui lòng đăng nhập lại để tiếp tục.", "Đăng nhập");
                await Shell.Current.GoToAsync("//dang-nhap");
            }
            catch (Exception ex) { Services.CrashLog.Ghi("PhienHetHan", ex); }
        });

        // Các trang được điều hướng bằng Shell.Current.GoToAsync (push lên trên,
        // không nằm trong TabBar dưới) — tương đương Navigator.push() bên Flutter.
        Routing.RegisterRoute(nameof(IntroPage), typeof(IntroPage));
        Routing.RegisterRoute(nameof(DriverEarningsPage), typeof(DriverEarningsPage));
        Routing.RegisterRoute(nameof(DriverSuCoPage), typeof(DriverSuCoPage));
        Routing.RegisterRoute(nameof(DriverHuongDanPage), typeof(DriverHuongDanPage));
        Routing.RegisterRoute(nameof(DriverRatingPage), typeof(DriverRatingPage));
        Routing.RegisterRoute(nameof(DriverPerformancePage), typeof(DriverPerformancePage));
        Routing.RegisterRoute(nameof(DriverNhuCauPage), typeof(DriverNhuCauPage));
        Routing.RegisterRoute(nameof(DriverTrangThaiPage), typeof(DriverTrangThaiPage));   // v91
        Routing.RegisterRoute(nameof(DriverThuongPage), typeof(DriverThuongPage));         // v91
        Routing.RegisterRoute(nameof(DriverMyOrdersPage), typeof(DriverMyOrdersPage));
        Routing.RegisterRoute(nameof(DriverOrderDetailPage), typeof(DriverOrderDetailPage));
        Routing.RegisterRoute(nameof(DriverNotificationsPage), typeof(DriverNotificationsPage));
        Routing.RegisterRoute(nameof(DriverAccountPage), typeof(DriverAccountPage));
        Routing.RegisterRoute(nameof(DriverWalletPage), typeof(DriverWalletPage));
        Routing.RegisterRoute(nameof(DriverSettingsPage), typeof(DriverSettingsPage));
        Routing.RegisterRoute(nameof(MenuCartPage), typeof(MenuCartPage));
        Routing.RegisterRoute(nameof(PaymentPage), typeof(PaymentPage));
        Routing.RegisterRoute(nameof(MonAnChiTietPage), typeof(MonAnChiTietPage));
        Routing.RegisterRoute(nameof(VendorOrderDetailPage), typeof(VendorOrderDetailPage));
        Routing.RegisterRoute(nameof(VendorStaffPage), typeof(VendorStaffPage));
        Routing.RegisterRoute(nameof(VendorReviewDetailPage), typeof(VendorReviewDetailPage));
        Routing.RegisterRoute(nameof(VendorTransactionDetailPage), typeof(VendorTransactionDetailPage));
        Routing.RegisterRoute(nameof(DatHangThanhCongPage), typeof(DatHangThanhCongPage));
        Routing.RegisterRoute(nameof(OrderTrackingPage) + "Detail", typeof(OrderTrackingPage));
        Routing.RegisterRoute(nameof(ReviewPage), typeof(ReviewPage));
        Routing.RegisterRoute(nameof(HoTroPage), typeof(HoTroPage));
        Routing.RegisterRoute(nameof(LichSuThanhToanPage), typeof(LichSuThanhToanPage));
        Routing.RegisterRoute(nameof(LichSuDanhGiaPage), typeof(LichSuDanhGiaPage));      // v90
        Routing.RegisterRoute(nameof(ProfilePage), typeof(ProfilePage));
        Routing.RegisterRoute(nameof(DoiMatKhauPage), typeof(DoiMatKhauPage));
        Routing.RegisterRoute(nameof(TinTucPage), typeof(TinTucPage));
        Routing.RegisterRoute(nameof(CaiDatPage), typeof(CaiDatPage));
        Routing.RegisterRoute(nameof(DiaChiPage), typeof(DiaChiPage));
        Routing.RegisterRoute(nameof(YeuThichPage), typeof(YeuThichPage));
        Routing.RegisterRoute(nameof(ActivityPage), typeof(ActivityPage));     // Thông báo (mở từ Tài khoản)
        Routing.RegisterRoute(nameof(WalletPage), typeof(WalletPage));         // Ví của tôi
        Routing.RegisterRoute(nameof(MessagesPage), typeof(MessagesPage));     // Tin nhắn

        // Luồng tài xế giao hàng (điều hướng dạng stack, nằm ngoài TabBar khách hàng).
        Routing.RegisterRoute(nameof(DriverLoginPage), typeof(DriverLoginPage));
        Routing.RegisterRoute(nameof(DriverHomePage), typeof(DriverHomePage));
        Routing.RegisterRoute(nameof(DriverOfferDetailPage), typeof(DriverOfferDetailPage));
        Routing.RegisterRoute(nameof(DriverCodPage), typeof(DriverCodPage));
        Routing.RegisterRoute(nameof(DriverThuNhapChiTietPage), typeof(DriverThuNhapChiTietPage));
        Routing.RegisterRoute(nameof(DriverProfilePage), typeof(DriverProfilePage));
        Routing.RegisterRoute(nameof(DriverRegisterPage), typeof(DriverRegisterPage));
        Routing.RegisterRoute(nameof(AdminDriverApprovalPage), typeof(AdminDriverApprovalPage));
        Routing.RegisterRoute(nameof(ChatPage), typeof(ChatPage));
        Routing.RegisterRoute(nameof(BanDoPage), typeof(BanDoPage));
        Routing.RegisterRoute(nameof(TheoDoiBanDoPage), typeof(TheoDoiBanDoPage));
        Routing.RegisterRoute(nameof(DriverDeliveryDetailPage), typeof(DriverDeliveryDetailPage));

        // Luồng quản lý gian hàng (đối tác) — điều hướng dạng stack, nằm ngoài TabBar khách hàng.
        Routing.RegisterRoute(nameof(VendorLoginPage), typeof(VendorLoginPage));
        Routing.RegisterRoute(nameof(VendorRegisterPage), typeof(VendorRegisterPage));
        Routing.RegisterRoute(nameof(VendorHomePage), typeof(VendorHomePage));
        Routing.RegisterRoute(nameof(VendorOrdersPage), typeof(VendorOrdersPage));
        Routing.RegisterRoute(nameof(VendorMenuPage), typeof(VendorMenuPage));
        Routing.RegisterRoute(nameof(VendorMenuItemEditPage), typeof(VendorMenuItemEditPage));
        Routing.RegisterRoute(nameof(VendorRevenuePage), typeof(VendorRevenuePage));
        Routing.RegisterRoute(nameof(VendorProfilePage), typeof(VendorProfilePage));
        Routing.RegisterRoute(nameof(VendorPromotionsPage), typeof(VendorPromotionsPage));
        Routing.RegisterRoute(nameof(VendorPromotionEditPage), typeof(VendorPromotionEditPage));
        Routing.RegisterRoute(nameof(QuenMatKhauPage), typeof(QuenMatKhauPage));
        Routing.RegisterRoute(nameof(XacThucOtpPage), typeof(XacThucOtpPage));
        Routing.RegisterRoute(nameof(LichSuDangNhapPage), typeof(LichSuDangNhapPage));
        Routing.RegisterRoute(nameof(AdminStaffPage), typeof(AdminStaffPage));
        Routing.RegisterRoute(nameof(AdminAuditLogPage), typeof(AdminAuditLogPage));
        Routing.RegisterRoute(nameof(VendorReviewsPage), typeof(VendorReviewsPage));
        Routing.RegisterRoute(nameof(VendorNotificationsPage), typeof(VendorNotificationsPage));
        Routing.RegisterRoute(nameof(VendorFinancePage), typeof(VendorFinancePage));
        Routing.RegisterRoute(nameof(VendorVanHanhPage), typeof(VendorVanHanhPage));
        Routing.RegisterRoute(nameof(VendorDoiSoatPage), typeof(VendorDoiSoatPage));

        // Luồng quản lý quản trị — điều hướng dạng stack, nằm ngoài TabBar khách hàng.
        Routing.RegisterRoute(nameof(AdminLoginPage), typeof(AdminLoginPage));
        Routing.RegisterRoute(nameof(AdminHomePage), typeof(AdminHomePage));
        Routing.RegisterRoute(nameof(AdminVendorApprovalPage), typeof(AdminVendorApprovalPage));
        Routing.RegisterRoute(nameof(AdminVendorListPage), typeof(AdminVendorListPage));
        Routing.RegisterRoute(nameof(AdminCustomerListPage), typeof(AdminCustomerListPage));
        Routing.RegisterRoute(nameof(AdminIssuesPage), typeof(AdminIssuesPage));
        Routing.RegisterRoute(nameof(AdminIssueDetailPage), typeof(AdminIssueDetailPage));
        Routing.RegisterRoute(nameof(AdminPromotionsPage), typeof(AdminPromotionsPage));
        Routing.RegisterRoute(nameof(AdminPromotionEditPage), typeof(AdminPromotionEditPage));
        Routing.RegisterRoute(nameof(AdminStatisticsPage), typeof(AdminStatisticsPage));
        Routing.RegisterRoute(nameof(VendorCampaignsPage), typeof(VendorCampaignsPage));
        Routing.RegisterRoute(nameof(VendorCancelRefundPage), typeof(VendorCancelRefundPage));   // Gian hàng: yêu cầu hủy + hoàn tiền
        Routing.RegisterRoute(nameof(AdminHubPage), typeof(AdminHubPage));
        Routing.RegisterRoute(nameof(AdminGiamSatPage), typeof(AdminGiamSatPage));
        Routing.RegisterRoute(nameof(AdminSaoLuuPage), typeof(AdminSaoLuuPage));
        Routing.RegisterRoute(nameof(AdminBaoMatPage), typeof(AdminBaoMatPage));
        Routing.RegisterRoute(nameof(AdminGoongPage), typeof(AdminGoongPage));
        Routing.RegisterRoute(nameof(AdminKiemTraBanDoPage), typeof(AdminKiemTraBanDoPage));
        Routing.RegisterRoute(nameof(AdminKhieuNaiPage), typeof(AdminKhieuNaiPage));
        Routing.RegisterRoute(nameof(AdminBaoCaoNangCaoPage), typeof(AdminBaoCaoNangCaoPage));
        Routing.RegisterRoute(nameof(AdminDashboardPage), typeof(AdminDashboardPage));
        Routing.RegisterRoute(nameof(AdminThongBaoTrangChuPage), typeof(AdminThongBaoTrangChuPage));
        Routing.RegisterRoute(nameof(LoTrinhBanDoPage), typeof(LoTrinhBanDoPage));
        Routing.RegisterRoute(nameof(AdminQuyTrinhPage), typeof(AdminQuyTrinhPage));
        Routing.RegisterRoute(nameof(AdminThongMinhPage), typeof(AdminThongMinhPage));
        Routing.RegisterRoute(nameof(ThanhVienPage), typeof(ThanhVienPage));
        Routing.RegisterRoute(nameof(DonNhomPage), typeof(DonNhomPage));
        Routing.RegisterRoute(nameof(AdminNotificationsPage), typeof(AdminNotificationsPage));
        Routing.RegisterRoute(nameof(AdminProfilePage), typeof(AdminProfilePage));
        Routing.RegisterRoute(nameof(AdminVanHanhPage), typeof(AdminVanHanhPage));
        Routing.RegisterRoute(nameof(AdminOrdersPage), typeof(AdminOrdersPage));
        Routing.RegisterRoute(nameof(AdminOrderDetailPage), typeof(AdminOrderDetailPage));
        Routing.RegisterRoute(nameof(AdminPaymentsPage), typeof(AdminPaymentsPage));
        Routing.RegisterRoute(nameof(AdminCatalogPage), typeof(AdminCatalogPage));
        Routing.RegisterRoute(nameof(AdminReviewsPage), typeof(AdminReviewsPage));
        Routing.RegisterRoute(nameof(AdminDispatchPage), typeof(AdminDispatchPage));
        Routing.RegisterRoute(nameof(AdminDriverListPage), typeof(AdminDriverListPage));
        Routing.RegisterRoute(nameof(AdminAccountsPage), typeof(AdminAccountsPage));
        Routing.RegisterRoute(nameof(AdminConfigPage), typeof(AdminConfigPage));
        Routing.RegisterRoute(nameof(AdminDriverIssuesPage), typeof(AdminDriverIssuesPage));
        Routing.RegisterRoute(nameof(AdminNotifyPage), typeof(AdminNotifyPage));
        Routing.RegisterRoute(nameof(AdminBannerPage), typeof(AdminBannerPage));
        Routing.RegisterRoute(nameof(AdminFaqPage), typeof(AdminFaqPage));
        Routing.RegisterRoute(nameof(AdminTinTucPage), typeof(AdminTinTucPage));
        Routing.RegisterRoute(nameof(AdminPayablesPage), typeof(AdminPayablesPage));
        Routing.RegisterRoute(nameof(AdminPhiGiaoPage), typeof(AdminPhiGiaoPage));
        Routing.RegisterRoute(nameof(AdminLoTrinhPage), typeof(AdminLoTrinhPage));
        Routing.RegisterRoute(nameof(AdminDieuPhoiTongQuanPage), typeof(AdminDieuPhoiTongQuanPage));
        Routing.RegisterRoute(nameof(AdminCskhPage), typeof(AdminCskhPage));
        Routing.RegisterRoute(nameof(DriverThuongTyLePage), typeof(DriverThuongTyLePage));
        Routing.RegisterRoute(nameof(DriverHoTroPage), typeof(DriverHoTroPage));
        Routing.RegisterRoute(nameof(AdminNghiemThuPage), typeof(AdminNghiemThuPage));
        Routing.RegisterRoute(nameof(AdminChecklistChucNangPage), typeof(AdminChecklistChucNangPage));
        Routing.RegisterRoute(nameof(AdminCapDoPage), typeof(AdminCapDoPage));
        Routing.RegisterRoute(nameof(AdminModuleBackendPage), typeof(AdminModuleBackendPage));
        Routing.RegisterRoute(nameof(AdminThieuSotBackendPage), typeof(AdminThieuSotBackendPage));
        Routing.RegisterRoute(nameof(AdminThieuSotKiemThuPage), typeof(AdminThieuSotKiemThuPage));
        Routing.RegisterRoute(nameof(AdminChucNangAdminPage), typeof(AdminChucNangAdminPage));
        Routing.RegisterRoute(nameof(AdminChucNangTaiXePage), typeof(AdminChucNangTaiXePage));
        Routing.RegisterRoute(nameof(AdminSuperAdminPage), typeof(AdminSuperAdminPage));
        Routing.RegisterRoute(nameof(AdminCustomerSearchPage), typeof(AdminCustomerSearchPage));
        Routing.RegisterRoute(nameof(AdminCustomerOrdersPage), typeof(AdminCustomerOrdersPage));
        Routing.RegisterRoute(nameof(AdminVendorContractPage), typeof(AdminVendorContractPage));
        Routing.RegisterRoute(nameof(FaqPage), typeof(FaqPage));
        Routing.RegisterRoute(nameof(BaoMatTaiKhoanPage), typeof(BaoMatTaiKhoanPage));
        Routing.RegisterRoute(nameof(PhienDangNhapPage), typeof(PhienDangNhapPage));
        Routing.RegisterRoute(nameof(DieuKhoanPage), typeof(DieuKhoanPage));
        Routing.RegisterRoute(nameof(ThongTinUngDungPage), typeof(ThongTinUngDungPage));
        Routing.RegisterRoute(nameof(AdminReportsPage), typeof(AdminReportsPage));
        Routing.RegisterRoute(nameof(AdminXuatExcelPage), typeof(AdminXuatExcelPage));
        Routing.RegisterRoute(nameof(AdminStaffOnlinePage), typeof(AdminStaffOnlinePage));
    }

    /// <summary>
    /// Gọi sau khi đăng nhập thành công: ẩn trang đăng nhập, hiện TabBar chính.
    /// Tương đương Navigator.pushReplacement(HomeScreen) bên Flutter.
    /// </summary>
    public static async Task DangNhapThanhCongAsync()
    {
        await Current.GoToAsync(nameof(IntroPage));   // intro 5 giây, xong tự vào trang chủ
    }
}
