# Giao hàng & bản đồ — phần tài xế

## Chức năng và vị trí trong app
| Chức năng | Ở đâu |
|---|---|
| Địa chỉ lấy hàng / giao hàng (có nút sao chép) | Tài xế → Chi tiết giao hàng → thẻ tuyến đường |
| Khoảng cách, ước tính thời gian, khu vực | Chi tiết giao hàng → thẻ "Khoảng cách / Ước tính / Khu vực"; hộp thoại nhận đơn; khách thấy khi thanh toán |
| Phí giao theo khoảng cách + khu vực | `GiaoHangService.TinhPhi`; tính khi khách thanh toán, tài xế xem bảng phí chi tiết |
| Điều chỉnh phí | Nút "✏ Báo khoảng cách thực tế" → tính lại theo biểu phí |
| Chỉ đường | 🧭 đến quán / đến khách → mở Google Maps (xe máy), điểm đến hiện tại được tô nổi bật |
| Gọi quán / gọi khách | 📞 trên Chi tiết giao hàng (máy tính không gọi được thì sao chép số) |
| Theo dõi tài xế | Tài xế bật "📡 Chia sẻ vị trí" (15 giây/lần); khách thấy ở **Đơn hàng**: tên, biển số, ETA, giờ cập nhật, 📍 Xem vị trí, 📞 Gọi tài xế |
| Xác nhận nhận hàng | Tài xế xác nhận "đã nhận đủ N món" tại quán; khách đọc **mã 4 số** (hiện trên đơn) cho tài xế để xác nhận đã nhận |
| Giao thất bại | Nút "⚠ Giao thất bại" (sau khi lấy hàng) → chọn lý do |

## Biểu phí (sửa ở đầu `Services/GiaoHangService.cs`)
- 15.000đ cho 2 km đầu, +5.000đ mỗi km tiếp theo (làm tròn lên); ngoại thành (Củ Chi, Hóc Môn, Bình Chánh, Nhà Bè, Cần Giờ) +10.000đ; tối đa 70.000đ.
- Ví dụ từ Quận 5: → Quận 10 ≈ 2,9 km, 20.000đ · → Quận 1 ≈ 6,0 km, 35.000đ · → Hóc Môn ≈ 20,5 km, 70.000đ.

## Quy tắc nghiệp vụ đã chọn (có thể đổi)
- **Điều chỉnh phí**: đơn *tiền mặt* tăng/giảm được (khách trả thêm/bớt khi nhận); đơn *đã thanh toán trước* chỉ được giảm, vì không thu thêm được.
- **Giao thất bại**: lỗi do khách (không liên lạc được, từ chối, hẹn lại, sai địa chỉ) → tài xế **vẫn nhận phí giao**; sự cố xe, món hư, lý do khác → **không nhận phí**.
  "Không liên lạc được" yêu cầu tài xế đã bấm gọi khách ít nhất 1 lần. Đơn chuyển sang "Đã hủy" (nhãn "Giao thất bại"); đơn trả trước được đánh dấu hoàn tiền.
- Đơn giao thất bại không tính vào "số đơn hôm nay".

## Giới hạn hiện tại (cần biết khi demo / bảo vệ)
- **Phí và khoảng cách có 2 mức tin cậy (v94).** Ước tính cục bộ (`GiaoHangService.UocTinh`: tâm quận/huyện × 1,25, 20 km/h) chỉ để hiển thị tạm và để chạy ngoại tuyến;
  **không dùng làm căn cứ thu tiền**. Khi online, màn hình thanh toán hỏi máy chủ (`POST api/mobile/map/phi-giao-hang`) và ghi rõ nguồn: `✔ theo quãng đường thật` / `⚠ tạm tính` / `⚠ ước tính (ngoại tuyến)`.
  Trước khi đặt, app lấy lại phí chính thức; phí đổi thì khách phải đồng ý lại. Sau khi đặt, phí/khoảng cách/tổng tiền lấy theo số của máy chủ.
- Máy chủ chưa có khóa Goong (hoặc không geocode được) → máy chủ dùng **phí mặc định** (`Giao.PhiMacDinh`). App báo "chưa xác minh tuyến"; đơn VNPay (trả trước) được cảnh báo và gợi ý chọn tiền mặt.
  Đơn tiền mặt vẫn có thể chỉnh phí theo "Báo khoảng cách thực tế" của tài xế.
- **ETA không phải giao thông trực tiếp**: là thời gian Goong × hệ số theo khung giờ (cao điểm/đêm). Giao diện luôn ghi "ước tính".
- **Bản đồ nhúng**: Leaflet + OpenStreetMap trong WebView (chọn địa chỉ, theo dõi đơn, lộ trình). Cần Internet và WebView2 (Windows) / Android System WebView.
  Không dùng được thì có nút mở Google Maps.
- **Không có đường / đường bị chặn**: app hiện cảnh báo rõ + đường thẳng nét đứt kèm số ước tính, nút "Tìm lại tuyến" và "Mở Google Maps". Tài xế có nút "🚧 Đường bị chặn / tìm tuyến khác".
  Goong Direction không có tham số tránh đường nên app **không tự vẽ đường vòng**; việc tìm đường khác giao cho Google Maps.
- **Theo dõi trực tiếp giữa 2 thiết bị cần server** (`PUT api/mobile/tai-xe/vi-tri` + `GET api/mobile/don-hang/{id}/vi-tri`). Bản đồ khách hiện "cập nhật X giây trước" và số lần thay đổi trong 1 phút.
  Việc kiểm thử đồng bộ thật phải làm bằng 2 thiết bị (xem Admin → Kỹ thuật → Kiểm thử bản đồ & phí giao).
- Mã xác nhận chỉ có ở đơn tạo sau bản này; đơn cũ không yêu cầu mã.
- Cần cấp quyền vị trí (Android đã khai báo trong `AndroidManifest.xml`). Windows dùng thiết lập vị trí của hệ thống.

## Đã sửa kèm theo
- Bản sao đơn gửi cho tài xế trước đây **thiếu** tên/SĐT khách, hình thức thanh toán và giảm giá → tài xế thấy sai số tiền cần thu và không gọi được khách. Nay mang đủ (`DonHang.TaoBanSaoChoTaiXe`).
- Mở lại app: đơn tài xế đang giao dở được khôi phục (trước đó biến mất khỏi màn hình tài xế).

## Chưa kiểm chứng
Chưa biên dịch/chạy được trong môi trường soạn thảo (không có .NET SDK). Đã kiểm tra: XAML hợp lệ, mọi trình xử lý sự kiện có hàm tương ứng, ngoặc C# cân, công thức phí/khoảng cách mô phỏng lại bằng Python.
Nên build và chạy thử các kịch bản: đặt đơn → quán xác nhận/bàn giao → tài xế nhận → lấy hàng → giao (nhập mã) và nhánh giao thất bại.
