﻿using FoodApp.Maui.Services;

namespace FoodApp.Maui;

public partial class App : Application
{
    public App()
    {
        CrashLog.DangKyBatLoiToanCuc();
        InitializeComponent();
        CrashLog.Thu("ThemeColors", ThemeColors.Ap);                     // màu chủ đề người dùng đã chọn
        CrashLog.Thu("ThemeService", ThemeService.Ap);                   // Sáng / Tối / Theo hệ thống
        CrashLog.Thu("VendorLocalStore", VendorLocalStore.Nap);
        CrashLog.Thu("SaoLuu", SaoLuuService.TuDongNeuCan);
        CrashLog.Thu("TaiXeStore", TaiXeStore.Nap);                      // hồ sơ + ảnh đại diện tài xế
        CrashLog.Thu("QuanTriStore", QuanTriStore.Nap);                  // tài khoản quản trị
        CrashLog.Thu("TaiKhoanXoaStore", TaiKhoanXoaStore.ApDung);       // bỏ các tài khoản khách đã xóa
        CrashLog.Thu("KhoiPhucDonDangGiao", GiaoHangService.KhoiPhucDonDangGiao);
        try { MainPage = new AppShell(); }
        catch (Exception ex) { CrashLog.Ghi("new AppShell()", ex); throw; }
        CrashLog.Thu("NgonNgu", NgonNguService.KhoiTao);                 // Việt / Anh
        _ = KhoiTaoAsync();
    }

    /// <summary>Mở lại app: nối lại kênh thời gian thực nếu đã rớt và để các màn hình lấy trạng thái mới nhất từ API (không tin dữ liệu cũ).</summary>
    protected override Window CreateWindow(IActivationState? activationState)
    {
        var w = base.CreateWindow(activationState);
        w.Resumed += (_, _) => RealtimeService.KhiMoLai();
        return w;
    }

    private static async Task KhoiTaoAsync()
    {
      try
      {
        await AppSettings.NapAsync();
        var online = await DuLieuService.TaiDanhMucAsync();

        // An toàn khi demo: nếu không gọi được API thật (chưa bật SQL Server/ASP.NET Core,
        // hoặc máy demo không có mạng), nạp dữ liệu mẫu ngoại tuyến thay vì để trắng màn hình.
        // Chỉ ở Development. Staging/Production KHÔNG bao giờ nạp quán/đơn/tài xế/tài khoản giả: mất kết nối thì hiện trống + báo lỗi.
        if (!online && AppSettings.DuocDungDuLieuMau) Models.DuLieuMauNgoaiTuyen.NapNeuChuaCo();
        if (!online && AppSettings.DuocDungDuLieuMau) Models.DuLieuMauBoSung.Nap();   // 15 quán + 10 tài xế bổ sung (bỏ qua nếu đã có)
        if (!online && !AppSettings.DuocDungDuLieuMau) CrashLog.Ghi("KhoiTao", "Không kết nối được máy chủ (" + (AppSettings.CauHinhMayChuThieu ? "chưa cấu hình BaseUrl" : AppSettings.BaseUrl) + ") — không nạp dữ liệu mẫu.");
      }
      catch (Exception ex) { CrashLog.Ghi("KhoiTaoAsync", ex); }
    }
}
