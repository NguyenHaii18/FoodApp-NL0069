using Android.App;
using Android.Runtime;
using FoodApp.Maui.Services;

namespace FoodApp.Maui;

[Application]
public class MainApplication : MauiApplication
{
    public MainApplication(IntPtr handle, JniHandleOwnership ownership)
        : base(handle, ownership)
    {
    }

    protected override MauiApp CreateMauiApp()
    {
        CrashLog.DangKyBatLoiToanCuc();
        // Lỗi .NET chưa được bắt trong handler giao diện (vd async void): ghi nhật ký rồi tiếp tục thay vì thoát app
        AndroidEnvironment.UnhandledExceptionRaiser += (_, e) => { CrashLog.Ghi("Android.UnhandledException", e.Exception); e.Handled = true; };
        return MauiProgram.CreateMauiApp();
    }
}
