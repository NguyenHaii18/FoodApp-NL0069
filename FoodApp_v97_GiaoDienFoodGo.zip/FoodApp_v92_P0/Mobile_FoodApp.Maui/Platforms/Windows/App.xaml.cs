using Microsoft.UI.Xaml;
using FoodApp.Maui.Services;

namespace FoodApp.Maui.WinUI;

public partial class App : MauiWinUIApplication
{
    public App()
    {
        CrashLog.DangKyBatLoiToanCuc();
        // Đăng ký TRƯỚC InitializeComponent để bắt cả lỗi nạp XAML/resources.pri (nguyên nhân hay gặp của 0xc000027b)
        this.UnhandledException += (_, e) =>
        {
            CrashLog.Ghi("WinUI.UnhandledException: " + e.Message, e.Exception);
            e.Handled = true;   // đã ghi FoodApp_crash.log (có StackTrace); không để một lỗi giao diện làm thoát cả app
        };
        try { this.InitializeComponent(); }
        catch (Exception ex) { CrashLog.Ghi("App.InitializeComponent", ex); throw; }
    }

    protected override MauiApp CreateMauiApp()
    {
        try { return MauiProgram.CreateMauiApp(); }
        catch (Exception ex) { CrashLog.Ghi("CreateMauiApp", ex); throw; }
    }
}
