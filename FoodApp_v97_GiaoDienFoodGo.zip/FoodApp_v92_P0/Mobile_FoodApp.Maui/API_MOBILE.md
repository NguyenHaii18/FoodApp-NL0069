# Hợp đồng API mà app MAUI gọi (đặt trong FoodServiceApp.Web, MobileApi.cs)

Địa chỉ gốc lấy từ `Resources/Raw/appsettings.json`. JSON camelCase; Id có thể là số hoặc chuỗi (app tự đổi sang chuỗi).
Nếu GET api/mobile/gian-hang không trả được, app tự chuyển sang dữ liệu mẫu (chế độ demo).

| Method | URL | Body | Trả về |
|---|---|---|---|
| GET | api/mobile/gian-hang | | [GianHang] |
| GET | api/mobile/mon-an | | [MonAn] (có gianHangId, danhMuc, conHang) |
| GET | api/mobile/khuyen-mai | | [KhuyenMai] |
| POST | api/mobile/khach-hang/dang-nhap | {email, matKhau} | {token, khachHang} |
| POST | api/mobile/khach-hang/dang-ky | {hoTen, sdt, email, matKhau} | {token, khachHang} |
| GET | api/mobile/khach-hang/don-hang | | [DonHang] |
| POST | api/mobile/don-hang | {gianHangId, diaChiGiao, hinhThucThanhToan, maKhuyenMai, chiTiet:[{monAnId, soLuong}]} | {id} |
| POST | api/mobile/gian-hang/dang-nhap | {email, matKhau} | {token, gianHang} |
| GET | api/mobile/gian-hang/{id}/don-hang | | [DonHang] |
| PUT | api/mobile/gian-hang/{id}/trang-thai-kinh-doanh | {dangMoCua} | 200 |
| PUT | api/mobile/don-hang/{id}/xac-nhan, tu-choi, san-sang-giao | | 200 |
| POST | api/mobile/admin/dang-nhap | {email, matKhau} | {token} |
| GET | api/mobile/admin/khach-hang, van-de | | [KhachHang], [VanDeHeThong] |
| PUT | api/mobile/admin/gian-hang/{id}/duyet, tu-choi, khoa, mo-khoa | | 200 |
| PUT | api/mobile/admin/khach-hang/{id}/khoa, mo-khoa | | 200 |
| PUT | api/mobile/admin/van-de/{id}/dang-xu-ly, giai-quyet | | 200 |

Lỗi: trả 4xx kèm {"thongDiep": "..."} để app hiển thị.

| PUT | api/mobile/tai-xe/ho-so | {hoTen, soDienThoai, bienSoXe, loaiXe} | 200 (ảnh đại diện hiện chỉ lưu trên máy) |

## Giao hàng & bản đồ (phần tài xế) — endpoint bổ sung
Mọi lời gọi đều **tùy chọn**: offline app tự lưu cục bộ. Lỗi mạng khi gửi vị trí được bỏ qua (lần cập nhật sau gửi lại).

| Method | URL | Body | Ghi chú |
|---|---|---|---|
| PUT | api/mobile/tai-xe/vi-tri | {donHangId, viDo, kinhDo} | gửi mỗi ~15 giây khi tài xế bật chia sẻ vị trí |
| PUT | api/mobile/don-hang/{id}/da-lay-hang | | tài xế xác nhận đã nhận đủ hàng từ quán |
| PUT | api/mobile/don-hang/{id}/hoan-thanh | {maXacNhan} | server nên kiểm tra mã 4 số khách nhận được |
| PUT | api/mobile/don-hang/{id}/giao-that-bai | {lyDo, tinhPhi} | tinhPhi = true nếu lỗi do khách; đơn trả trước cần hoàn tiền |
| PUT | api/mobile/don-hang/{id}/phi-giao-hang | {khoangCachKm, phiGiaoHang} | tài xế báo khoảng cách thực tế → phí tính lại |

`DonHang` trả về nên có thêm (camelCase, tùy chọn): `khoangCachKm`, `thoiGianDuKienPhut`, `khuVucLay`, `khuVucGiao`, `ngoaiThanh`,
`phiKhoangCach`, `phuPhiKhuVuc`, `phiDaDieuChinh`, `taiXeId`, `taiXeTen`, `taiXeSdt`, `taiXeBienSo`, `daLayHang`, `taiXeLat`, `taiXeLng`,
`viTriCapNhatLuc`, `maXacNhanGiao`, `giaoThatBai`, `lyDoGiaoThatBai`. Thiếu trường nào app dùng giá trị ước tính/bỏ qua trường đó.
Khi nối server, **server nên tự tính phí giao** (Goong DistanceMatrix) và trả về `phiGiaoHang` thay cho ước tính của app.

## Đối tác / Gian hàng — endpoint bổ sung (bản bổ sung chức năng đối tác)
Mọi lời gọi đều **tùy chọn**: offline app tự lưu cục bộ. Các mục "chưa có API" hiện chỉ lưu trên máy (VendorLocalStore).

| Method | URL | Body | Ghi chú |
|---|---|---|---|
| POST | api/mobile/tai-khoan/dat-lai-mat-khau | {taiKhoan, otp, matKhauMoi} | Đặt lại mật khẩu gian hàng sau khi nhập OTP (gửi OTP bằng POST tai-khoan/quen-mat-khau). Endpoint cũ gian-hang/quen-mat-khau đã gỡ. |
| PUT | api/mobile/gian-hang/{id}/gio-hoat-dong | {gioMoCua, gioDongCua, dangNhanDon, dangMoCua} | "HH:mm"; 00:00–23:59 = cả ngày |
| PUT | api/mobile/don-hang/{id}/tu-choi | {lyDo} | **lyDo bắt buộc** (NV04) |

`GianHang` nên có thêm: `gioMoCua`, `gioDongCua`, `dangNhanDon`, `tyLeChietKhau`.
`MonAn` nên có thêm: `moTa`, `tamNgungBan`, `giaVon`, `choGhiChu`, `tuyChon:[{loai: Size|Topping|MucCay, ten, giaThem}]`.
`DonHang` nên có thêm: `lyDoTuChoi`.
Chưa có API (chỉ lưu cục bộ): CRUD món/danh mục/thứ tự danh mục, đánh giá + phản hồi, thông báo, khuyến mãi.
Quy tắc: đơn chờ xác nhận quá 5 phút → server tự hủy + hoàn tiền (app cũng tự hủy khi đối tác mở màn hình đơn).
Phí nền tảng = tyLeChietKhau (mặc định 15%) × (tiền món − giảm giá do quán tài trợ), tính trên đơn hoàn thành.
CSDL: chạy `Database/FoodService_Database.sql` (tạo mới) hoặc `Database/FoodService_NangCap.sql` (CSDL cũ).


## Bổ sung v12 (app MAUI)
| Method | Đường dẫn | Vai trò | Ghi chú |
|---|---|---|---|
| POST | api/mobile/don-hang/{id}/bang-chung | TaiXe | multipart `file`; gọi trước hoan-thanh; đơn không có mã bắt buộc có ảnh |
| PUT | api/mobile/don-hang/{id}/da-lay-hang | TaiXe | trả `coMaXacNhan` |
| PUT | api/mobile/don-hang/{id}/bat-dau-chuan-bi | GianHang | TrangThaiChuanBi = DangChuanBi |
| PUT | api/mobile/don-hang/{id}/san-sang-giao | GianHang | TrangThaiChuanBi = SanSangGiao (lưu CSDL) |
| PUT | api/mobile/don-hang/{id}/ban-giao | GianHang | cần đã có tài xế; thông báo tài xế |
| PUT | api/mobile/don-hang/{id}/xac-nhan-nhan | KhachHang | đơn DaGiao; ghi KhachXacNhanLuc |
| POST | api/mobile/don-hang/{id}/chua-nhan | KhachHang | đơn DaGiao chưa xác nhận; tạo khiếu nại ChuaNhanHang |
| GET | api/mobile/don-hang/{id}/vi-tri | KhachHang | `viTriCu` > 90 giây |
| POST | api/mobile/admin/dang-nhap | — | trả thêm `capQuyenHan`, `quyen[]` (DonHang, ThanhToan, HoanTien, DanhGia, ThongBao) |

Trường mới trong đơn (mọi vai trò): `coMaXacNhan`, `trangThaiChuanBi`, `sanSangGiao`, `quanBanGiaoLuc`, `khachXacNhanLuc`. `maXacNhanGiao` chỉ gửi cho khách.

| PUT | api/mobile/tai-xe/don-hang/{id}/nhan | — | Tài xế nhận đơn (đường dẫn đúng; app gọi server trước rồi mới đổi giao diện) |
| PUT | api/mobile/don-hang/{id}/den-quan | — | Tài xế báo đã đến quán (mới) |
| GET | api/mobile/don-hang/{id}/tin-nhan | — | Chat khách ↔ tài xế của đơn (ChatApiController; bảng TinNhan, có MaClient chống gửi trùng) |
| POST | api/mobile/tin-nhan | {id, donHangId, noiDung} | Gửi tin nhắn (người gửi lấy từ JWT; bảng TinNhan) |

## Bổ sung v23 — Phí & chính sách
| Method | Đường dẫn | Auth | Mô tả |
|---|---|---|---|
| GET | api/mobile/chinh-sach | — | Phí giao/km, phí mặc định, bán kính, hoa hồng mặc định, thời gian tự hủy + quy định hủy đơn, ngưỡng + chính sách hoàn tiền, giới hạn voucher/khách, thời gian dự kiến, quy định khách/gian hàng/tài xế |


## Bổ sung v41
- `POST api/mobile/don-hang`: `hinhThucThanhToan` chỉ nhận `TienMat` | `VNPay`; `ghiChu` được lưu. VNPay trả `paymentUrl`.
- `GET api/mobile/don-hang/{id}/thanh-toan` (KhachHang): `{ trangThai: ChoThanhToan|DaThanhToan|ThatBai|DaHoanTien, daThanhToan, thatBai, donDaHuy, tongTien }`.
- `GET api/mobile/gian-hang`: `phanLoai` = các loại cách nhau dấu phẩy (`com,ga,bun,tra,pizza,banh,nhat,cafe,che`) hoặc rỗng.
- Đơn của khách có thêm `trangThaiThanhToan`.


## Đối chiếu danh sách endpoint đề xuất (v48)

Các đường dẫn mẫu trong tài liệu thiết kế đã được đối chiếu với mã nguồn. Cột "Thực tế" là endpoint chính; "Bí danh" là đường dẫn đề xuất, nay trỏ cùng một xử lý (không nhân đôi logic).

| Nhóm | Đường dẫn đề xuất | Thực tế / bí danh |
|---|---|---|
| Xác thực | `POST /api/auth/login` | Mới: tự nhận vai trò theo tên đăng nhập. Vẫn giữ `POST /api/auth/login/{vaiTro}` và `POST /api/mobile/{khach-hang,gian-hang,tai-xe,admin}/dang-nhap` |
| Đăng ký | `POST /api/auth/register` | Bí danh của `POST /api/mobile/khach-hang/dang-ky`; thêm `/api/auth/register/{khach-hang,gian-hang,tai-xe}` |
| OTP | `POST /api/auth/otp/send`, `/verify` | Bí danh của `POST /api/mobile/tai-khoan/xac-thuc/{gui-otp,xac-nhan}` (xác thực email/SĐT cho tài khoản đang đăng nhập, cần JWT). OTP quên mật khẩu (không cần đăng nhập): `POST /api/mobile/tai-khoan/{quen-mat-khau,dat-lai-mat-khau}` |
| Danh sách quán | `GET /api/mobile/gian-hang` | Có sẵn |
| Chi tiết quán | `GET /api/mobile/gian-hang/{id}` | Bí danh của `GET /api/customer/stores/{id}` |
| Menu | `GET /api/mobile/gian-hang/{id}/mon-an` | Mới (`?tuKhoa=`, `?conHang=true`); cũng có `GET /api/customer/stores/{id}/menu`. Chi tiết một món: `GET /api/mobile/mon-an/{id}` |
| Giỏ hàng | `GET /api/mobile/khach-hang/gio-hang` | Có sẵn (kèm `PUT`) |
| Đặt hàng | `POST /api/mobile/don-hang` | Có sẵn |
| Lịch sử đơn | `GET /api/mobile/don-hang` | Bí danh của `GET /api/customer/orders` (cũng có `GET /api/mobile/khach-hang/don-hang`) |
| Chi tiết đơn | `GET /api/mobile/don-hang/{id}` | Bí danh của `GET /api/customer/orders/{id}` |
| Thanh toán | `POST /api/mobile/thanh-toan` | Mới: body `{maDonHang, phuongThuc?, noiDung?}`. Đơn VNPay → `{paymentUrl}`; đơn tiền mặt (COD) → trạng thái. Phương thức theo đơn đã đặt, không đổi sau khi đặt (trả 409 nếu yêu cầu khác). Có sẵn: `POST /api/mobile/payment/vnpay/tao-url`, `GET /api/mobile/don-hang/{id}/thanh-toan` |
| Chat đơn hàng | `GET/POST /api/mobile/don-hang/{id}/tin-nhan` | `GET` có sẵn; `POST` mới (cùng quy tắc với `POST /api/mobile/tin-nhan`) |
| Địa chỉ khách | `GET/POST /api/mobile/khach-hang/dia-chi` | Bí danh của `/api/customer/addresses`; thêm `POST .../dia-chi/{id}/mac-dinh`, `DELETE .../dia-chi/{id}` |
| Hồ sơ khách | `GET /api/mobile/khach-hang/ho-so` | Bí danh của `GET /api/customer/profile` (`PUT` có sẵn) |
| Đánh giá | `POST /api/mobile/danh-gia` | Có sẵn |
| Quản trị | `/api/admin/...` | Có sẵn (`/api/admin/*` và `/api/mobile/admin/*`) |
| Đối tác | `/api/vendor/...` | Có sẵn (`/api/vendor/*` và `/api/mobile/gian-hang/*`) |
| Tài xế | `/api/driver/...` | Có sẵn; nay **bổ sung vào mobile**: mọi endpoint `/api/driver/{x}` có thêm `/api/mobile/driver/{x}`; thêm tên tiếng Việt `GET /api/mobile/tai-xe/tong-quan`, `POST /api/mobile/tai-xe/bat-tat-san-sang`, `POST /api/mobile/tai-xe/bat-tat-nhan-don`; thu nhập: `GET /api/mobile/tai-xe/thu-nhap` (mới) |

`GET /api/mobile/tai-xe/thu-nhap` trả: số đơn đã nhận / đã giao / giao thất bại / bị hủy (30 ngày), thu nhập hôm nay – tuần – tháng, tổng phí giao + thưởng/phụ cấp − khoản trừ, COD đã thu, **COD cần nộp lại**, khoản nền tảng đã trả/chưa trả, thu nhập theo ngày và lịch sử giao dịch. Cùng cách tính với trang web `TaiXe/ThuNhap`.


## Tin tức & thông báo theo nhóm (v69)

| Endpoint | Ai dùng | Mô tả |
|---|---|---|
| `GET /api/mobile/tin-tuc` | Công khai (app khách) | Tin đang bật, đã đến ngày đăng, chưa hết hạn; ghim trước, mới nhất trước (tối đa 30) |
| `GET /api/mobile/admin/tin-tuc` | Quản trị | Mọi tin, kèm `dangHienThi`, `henDang`, `hetHan` |
| `POST /api/mobile/admin/tin-tuc` | Quản trị (quyền `ThongBao`) | Body `{tieuDe, tomTat?, noiDung, loai (KhuyenMai/TinQuan/HeThong), ngayDang?, ngayHetHan?, ghimLen, guiThongBao}`. `guiThongBao=true` gửi thông báo tới mọi khách đang hoạt động, chỉ khi tin hiện ngay |
| `PUT /api/mobile/admin/tin-tuc/{id}` | Quản trị | Sửa tin |
| `PUT /api/mobile/admin/tin-tuc/{id}/ghim`, `/bat-tat` | Quản trị | Ghim/bỏ ghim, ẩn/hiện |
| `DELETE /api/mobile/admin/tin-tuc/{id}` | Quản trị | Xóa tin |
| `POST /api/mobile/admin/thong-bao/xem-truoc` | Quản trị | Body `{doiTuong, dsTaiKhoan?}` → `{soNguoi, nhom, mau[]}`; không tạo thông báo |
| `POST /api/mobile/admin/thong-bao` | Quản trị | Body `{doiTuong, dsTaiKhoan?, tieuDe, noiDung}` |

Giá trị `doiTuong`: `TatCa`, `KhachHang`, `GianHang`, `TaiXe`, `Nhom` (danh sách tên đăng nhập) và nhóm theo hành vi (v69): `KhachMoi30`, `KhachDatGanDay30`, `KhachLauChuaDat60`, `KhachChuaTungDat`, `KhachThanThiet5`, `QuanDangMo`, `QuanKhongDon30`, `TaiXeSanSang`, `TaiXeDangGiao`. Chỉ gửi tới tài khoản đang hoạt động, không gồm quản trị (trừ khi chọn theo danh sách tên).
