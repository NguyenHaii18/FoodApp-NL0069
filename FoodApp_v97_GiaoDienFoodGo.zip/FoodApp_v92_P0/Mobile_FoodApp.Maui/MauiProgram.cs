using CommunityToolkit.Maui;
using Microsoft.Extensions.Logging;

namespace FoodApp.Maui;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .UseMauiCommunityToolkit()
            .UseMauiCommunityToolkitMediaElement();

        // Ghi chú: bản gốc có cấu hình font OpenSans-Regular.ttf / OpenSans-Semibold.ttf,
        // nhưng project không có sẵn 2 file .ttf đó (không tải được từ môi trường tạo file
        // này), nên tạm bỏ để tránh lỗi "font not found" khi chạy. App vẫn chạy bình thường
        // bằng font hệ thống mặc định. Muốn dùng lại font riêng: tải OpenSans-Regular.ttf và
        // OpenSans-Semibold.ttf (ví dụ từ fonts.google.com/specimen/Open+Sans), bỏ vào
        // Resources/Fonts/, rồi thêm lại đoạn dưới đây:
        //
        // builder.ConfigureFonts(fonts =>
        // {
        //     fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
        //     fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
        // });

#if WINDOWS
        // Gõ tiếng Việt (Telex/VNI) trên Windows: bộ gõ làm việc theo kiểu "soạn thảo" (composition) rồi thay thế ký tự vừa gõ.
        // Gợi ý chữ/kiểm tra chính tả của ô nhập WinUI có thể chen vào quá trình này → mất dấu hoặc dấu sai chỗ.
        // Tắt hai tính năng đó cho mọi ô nhập (Entry/Editor) của app.
        void TatGoiYChu(Microsoft.UI.Xaml.Controls.TextBox tb)
        {
            tb.IsSpellCheckEnabled = false;
            tb.IsTextPredictionEnabled = false;
        }
        Microsoft.Maui.Handlers.EntryHandler.Mapper.AppendToMapping("TatGoiYChuVietNam", (h, _) => TatGoiYChu(h.PlatformView));
        Microsoft.Maui.Handlers.EditorHandler.Mapper.AppendToMapping("TatGoiYChuVietNam", (h, _) => TatGoiYChu(h.PlatformView));
#endif

#if ANDROID
        // Gợi ý tự điền (Google/Samsung/1Password...): ô StyleId="autofill-username"/"autofill-password" được khai báo là tài khoản/mật khẩu.
        Microsoft.Maui.Handlers.EntryHandler.Mapper.AppendToMapping("GoiYTuDienMatKhau", (h, v) =>
        {
            if (!OperatingSystem.IsAndroidVersionAtLeast(26)) return;
            var id = (v as Element)?.StyleId;
            if (id == "autofill-username") { h.PlatformView.SetAutofillHints(Android.Views.View.AutofillHintUsername); h.PlatformView.ImportantForAutofill = Android.Views.ImportantForAutofill.Yes; }
            else if (id == "autofill-password") { h.PlatformView.SetAutofillHints(Android.Views.View.AutofillHintPassword); h.PlatformView.ImportantForAutofill = Android.Views.ImportantForAutofill.Yes; }
        });
#elif IOS || MACCATALYST
        Microsoft.Maui.Handlers.EntryHandler.Mapper.AppendToMapping("GoiYTuDienMatKhau", (h, v) =>
        {
            var id = (v as Element)?.StyleId;
            if (id == "autofill-username") h.PlatformView.TextContentType = UIKit.UITextContentType.Username;
            else if (id == "autofill-password") h.PlatformView.TextContentType = UIKit.UITextContentType.Password;
        });
#endif

#if DEBUG
        builder.Logging.AddDebug();
#endif

        return builder.Build();
    }
}
