#!/usr/bin/env bash
# Giám sát đơn giản: gọi /health mỗi 5 phút, báo qua webhook (Telegram/Slack/Discord...) khi lỗi hoặc cấu hình có cảnh báo.
# cron: */5 * * * * URL=https://api.example.com WEBHOOK=https://... /opt/foodapp/deploy/giam-sat.sh
# Không đặt WEBHOOK thì chỉ in ra màn hình / log cron.
URL="${URL:?Đặt URL=https://tên-miền}"
KQ=$(curl -sS -m 10 -w ' HTTP:%{http_code}' "$URL/health" 2>&1)
if ! echo "$KQ" | grep -q 'HTTP:200'; then
  MSG="⚠️ FoodApp $URL /health LỖI: $KQ"
  echo "$MSG"
  [ -n "${WEBHOOK:-}" ] && curl -sS -m 10 -X POST -H 'Content-Type: application/json' -d "{\"text\":\"$MSG\"}" "$WEBHOOK" >/dev/null
  exit 1
fi
echo "$KQ" | grep -qE '"canhBaoCauHinh":0' || echo "ℹ️ Cấu hình còn cảnh báo — xem log dịch vụ (journalctl -u foodapp | grep Triển khai)."
echo "OK $KQ"
