#!/usr/bin/env bash
# Sao lưu hằng ngày: CSDL (.bak) + thư mục ảnh/tài liệu (uploads). Giữ 14 ngày. Chạy bằng cron: 0 2 * * * /opt/foodapp/deploy/sao-luu.sh
# Cần: sqlcmd, biến môi trường trong /etc/foodapp/foodapp.env (SQLCMDSERVER/SQLCMDUSER/SQLCMDPASSWORD hoặc sửa dòng sqlcmd bên dưới).
set -euo pipefail
DB="${FOOD_DB_NAME:-QuanLyDichVuAnUong}"
DICH="${SAO_LUU_THU_MUC:-/var/backups/foodapp}"
UPLOADS="${UPLOADS_THU_MUC:-/opt/foodapp/app/wwwroot/uploads}"
NGAY=$(date +%Y%m%d_%H%M%S)
mkdir -p "$DICH"
sqlcmd -b -C -Q "BACKUP DATABASE [$DB] TO DISK = N'$DICH/${DB}_$NGAY.bak' WITH INIT, COMPRESSION, CHECKSUM"
sqlcmd -b -C -Q "RESTORE VERIFYONLY FROM DISK = N'$DICH/${DB}_$NGAY.bak' WITH CHECKSUM"
[ -d "$UPLOADS" ] && tar -czf "$DICH/uploads_$NGAY.tar.gz" -C "$(dirname "$UPLOADS")" "$(basename "$UPLOADS")"
# Giấy tờ RIÊNG TƯ (GPLX, giấy phép KD, ATTP) nằm ngoài wwwroot: sao lưu riêng, phân quyền chặt (chỉ chủ sở hữu đọc).
PRIVATE="${PRIVATE_THU_MUC:-/opt/foodapp/app/App_Data/private}"
if [ -d "$PRIVATE" ]; then umask 077; tar -czf "$DICH/private_$NGAY.tar.gz" -C "$(dirname "$PRIVATE")" "$(basename "$PRIVATE")"; fi
find "$DICH" -type f \( -name '*.bak' -o -name 'uploads_*.tar.gz' -o -name 'private_*.tar.gz' \) -mtime +14 -delete
echo "Đã sao lưu $DB lúc $NGAY vào $DICH"
# Nên sao chép thêm $DICH ra nơi khác (rclone/S3/ổ đĩa ngoài). Thử phục hồi định kỳ vào CSDL staging để chắc bản sao dùng được.
