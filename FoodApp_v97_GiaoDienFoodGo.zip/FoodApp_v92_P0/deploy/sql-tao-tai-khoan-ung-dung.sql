/* Tạo CSDL + tài khoản ứng dụng với quyền HẸP (không dùng 'sa'). Chạy: sqlcmd -v DB=... LOGIN=... PW=... -i file
   Idempotent: chạy lại an toàn (cập nhật mật khẩu theo $(PW)). */
SET NOCOUNT ON;
DECLARE @db sysname = N'$(DB)', @login sysname = N'$(LOGIN)', @pw nvarchar(128) = N'$(PW)', @sql nvarchar(max);

IF LEN(@pw) < 12 BEGIN RAISERROR(N'Mat khau tai khoan ung dung phai >= 12 ky tu.', 16, 1); RETURN; END

IF DB_ID(@db) IS NULL
BEGIN
    SET @sql = N'CREATE DATABASE ' + QUOTENAME(@db) + N' COLLATE Vietnamese_CI_AS;';
    EXEC (@sql);
END

IF NOT EXISTS (SELECT 1 FROM sys.server_principals WHERE name = @login)
    SET @sql = N'CREATE LOGIN ' + QUOTENAME(@login) + N' WITH PASSWORD = N''' + REPLACE(@pw, N'''', N'''''') + N''', CHECK_POLICY = ON, DEFAULT_DATABASE = ' + QUOTENAME(@db) + N';';
ELSE
    SET @sql = N'ALTER LOGIN ' + QUOTENAME(@login) + N' WITH PASSWORD = N''' + REPLACE(@pw, N'''', N'''''') + N''';';
EXEC (@sql);

-- Quyền CHỈ trên CSDL của ứng dụng (db_owner trong CSDL này để ứng dụng tự tạo/nâng cấp bảng); không có quyền mức server.
SET @sql = N'USE ' + QUOTENAME(@db) + N';
IF NOT EXISTS (SELECT 1 FROM sys.database_principals WHERE name = N''' + REPLACE(@login, N'''', N'''''') + N''')
    CREATE USER ' + QUOTENAME(@login) + N' FOR LOGIN ' + QUOTENAME(@login) + N';
ALTER ROLE db_owner ADD MEMBER ' + QUOTENAME(@login) + N';';
EXEC (@sql);
PRINT N'San sang tai khoan ung dung: ' + @login + N' tren CSDL ' + @db;
