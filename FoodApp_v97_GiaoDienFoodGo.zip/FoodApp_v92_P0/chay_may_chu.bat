@echo off
chcp 65001 >nul
rem Chạy Website làm máy chủ cho app (bấm chuột phải -> Run as administrator để tự mở tường lửa)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0chay_may_chu.ps1" %*
pause
