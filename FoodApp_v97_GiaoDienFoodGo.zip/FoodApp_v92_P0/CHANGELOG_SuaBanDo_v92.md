# v92 — Sửa lỗi bấm vào bản đồ bị văng

- Nguyên nhân khả dĩ nhất: trang bản đồ báo điểm chạm cho C# bằng cách điều hướng WebView tới `foodapp://pick?...` rồi chặn trong `Navigating`; WebView2 (Windows) không xử lý ổn định scheme lạ này.
- Cách mới (BanDoPage.xaml.cs): JS chỉ ghi điểm chạm vào `window.diemChon`; C# hỏi lại mỗi 0,4 giây bằng `layDiemChon()` (chỉ khi trang đang hiện), rồi tra ngược địa chỉ. Không còn điều hướng/chặn URL.
- WebView được gắn sau khi trang dựng xong (trễ 150 ms); mọi lỗi ghi vào CrashLog thay vì làm sập app.
- Chưa build/chạy thử (môi trường không có .NET SDK).

## Sửa văng khi bấm Đăng xuất / thoát
- 8 nút đăng xuất (khách, quán, tài xế ×3, admin ×2) là `async void` không có try/catch: lỗi lúc thu hồi phiên/gọi API/điều hướng làm app văng.
- Nay bọc try/catch; khi lỗi, `DangXuatHelper.LoiAsync` ghi log, vẫn xóa phiên và đưa về trang đăng nhập.

- csproj: thêm `DISABLE_XAML_GENERATED_BREAK_ON_UNHANDLED_EXCEPTION` để Visual Studio không dừng ở `Debugger.Break()` (App.g.i.cs); lỗi vẫn ghi vào `%LOCALAPPDATA%\FoodApp_crash.log`.
