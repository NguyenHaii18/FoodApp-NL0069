# v48 – v47e + ảnh món/quán mẫu (gộp phần còn thiếu)

Nền: FoodApp_v47e (đã gồm toàn bộ v37–v43: thời gian chuẩn bị, ảnh bìa, món nổi bật, chống đơn trùng, COD, banner...). Phần duy nhất chưa có là đợt ảnh mẫu, đã gộp:

- 8 ảnh JPEG trong `Mobile_FoodApp.Maui/Resources/Images` và `Web/FoodServiceApp.Web/wwwroot/uploads`.
- `GianHang`/`MonAn`: thêm `AnhMau`, `AnhHienThi` (ảnh quán tự tải luôn được ưu tiên); các thẻ quán/món (trang chủ, tìm kiếm, menu, danh sách món của quán, hồ sơ gian hàng) và **danh sách gian hàng của quản trị** (trang mới trong v47e) hiển thị qua `AnhHienThi`.
- `Models/DuLieuMauAnh.cs`: gắn ảnh cho 5 quán (Bún Chả Hương Liên, Bún Riêu Cua Bà Sáu, Bún Thịt Nướng Chị Tuyền, Trà Đào Cam Sả Nhà Mình, Cơm Niêu Thố Sài Gòn) và thêm 2 món cơm chiên cho quán cơm; chạy lại an toàn.
- `FoodService_ThemGianHangMau.sql`: ảnh + 2 món cho Bún Chả Hương Liên. `Docs/ANH_MON_MAU.md`: bảng ghép ảnh – quán – món.
- Không đụng tới `CHANGELOG_v44.md` của bạn (v44 của bạn là bản khác với v44 ảnh mẫu của mình).

Chưa build/chạy (không có .NET SDK/SQL Server).
