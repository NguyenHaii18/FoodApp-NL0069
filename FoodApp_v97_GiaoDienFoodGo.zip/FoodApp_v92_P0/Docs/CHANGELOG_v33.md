# v33 – gộp v32 (của bạn) + chức năng Tài xế mục 1–5 và sửa lỗi "thành công giả" của mình

Nền: **v32 của bạn** (bảo mật, khóa DROP DATABASE, CRUD khuyến mãi qua API, KiemTraSchema, ghi 3 trạng thái ở MAUI).
Gộp ba chiều với v30 làm gốc chung. 26 file chỉ bạn sửa: giữ nguyên. 13 file cả hai cùng sửa: dùng bản của bạn.

## Thêm từ phía mình (29 file, không bên nào khác đụng tới)
- **Tài xế mục 3** – hạn phản hồi đơn: `GiaoHangXuLy.LayPhutPhanHoiAsync` (đọc `Don.TaiXePhanHoiPhut`); web `ChoNhan` + API `don-cho-nhan` (`hanPhanHoiLuc`); thẻ đơn trên app hiện hạn, trang chủ làm mới mỗi 60 giây.
- **Mục 4** – Online/Offline tách khỏi Sẵn sàng: trạng thái `TamNghi`; web dashboard 2 công tắc (`ToggleNhanDon`), API `toggle-nhan-don`; app gửi đủ 3 trạng thái; nhãn "tạm nghỉ" ở Quản trị.
- **Mục 5** – hướng dẫn giao hàng (web `TaiXe/HuongDan`, app `DriverHuongDanPage`) và lọc theo ngày trong "Đơn hàng" của tài xế.
- **Gian hàng/khách – server xác nhận rồi mới đổi dữ liệu** (phần bản của bạn ghi là "chưa xử lý"): `DoiTacService.XacNhanDonAsync/TuChoiDonAsync`, công tắc mở cửa/nhận đơn của gian hàng (tự trả về khi lỗi), gửi đánh giá.
- `.gitignore`.

## Phần của mình đã bỏ vì bản của bạn có sẵn cách khác
Chặn Jwt mẫu/CORS/OTP/tài khoản demo (Program.cs), hash BCrypt và `BamMatKhau`, khóa `@CHO_PHEP_XOA_DB` + sao lưu, chế độ demo `ChoPhepDemo` của MAUI (bản của bạn dùng `GhiTrangThaiAsync/GhiHoanTacAsync`), các tài liệu `BAO_MAT_TRIEN_KHAI.md`, `CSDL_KHOI_TAO_VA_NANG_CAP.md`, `appsettings.Production.example.json`.
Cần biết: ngoại tuyến thì `GhiAsync` của bạn vẫn trả true (lưu trên máy); các hàm mình viết "server trước" nên chạy tiếp ở chế độ này. Nếu muốn từ chối hẳn khi chưa kết nối ở bản Release, cần thêm vào cơ chế của bạn.

## Chưa kiểm chứng
Chưa build Web/MAUI, chưa chạy SQL (không có .NET SDK/SQL Server). Đã kiểm tra: 71 XAML hợp lệ, ngoặc C# cân bằng, handler khớp.
