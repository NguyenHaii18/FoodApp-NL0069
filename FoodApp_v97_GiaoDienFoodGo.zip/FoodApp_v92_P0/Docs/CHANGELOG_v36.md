# v36 – v35 + chống đơn trùng cho app, Banner & quảng cáo (quản trị 4E)

Đối chiếu danh sách "Phân hệ quản trị" và "Chức năng dùng chung": phần lớn đã có (dashboard, tài khoản, duyệt hồ sơ, đơn hàng/thanh toán/hoàn tiền, khuyến mãi, thông báo, cấu hình phí, nhật ký, hỗ trợ, VNPay có kiểm chữ ký, khóa đăng nhập sai, xuất CSV). Còn thiếu và đã thêm:

## Chống tạo đơn trùng cho app (mục 5 – Đơn hàng)
- Web đã có token `MaYeuCauDat`, nhưng `POST api/mobile/don-hang` (app) chưa có: mất mạng/bấm lại là tạo đơn thứ hai.
- API nhận `maYeuCauDat` (tùy chọn, ≤ 64 ký tự): cùng khách + cùng token chỉ tạo một đơn; gửi lại trả đúng đơn cũ (`daTonTai = true`), kiểm tra **trước** khi giữ lượt khuyến mãi. Hai request song song → 409.
- App (`PaymentPage`): giữ nguyên token khi gửi lại cùng một giỏ, đổi token khi giỏ/địa chỉ/thanh toán/mã khuyến mãi đổi.

## Banner & chiến dịch quảng cáo (mới)
- Bảng `Banner` (thêm vào `FoodService_Database.sql` và `FoodService_NangCap.sql`, chạy lại an toàn). **Cần chạy script nâng cấp.**
- Quản trị: menu Hỗ trợ → "Banner & quảng cáo" (tạo có ảnh/liên kết/thứ tự/khoảng ngày, bật-tắt, xóa); dùng chung nhóm quyền "Thông báo". Liên kết chỉ nhận `/...` hoặc `http(s)://`.
- Hiển thị: dải banner ở trang chủ khách (web); API `GET api/mobile/banner` cho app (**app chưa hiển thị**, cần thêm vào màn hình chủ khách).

## Chưa làm
Push notification (FCM), email ngoài OTP, hiển thị banner trong app. Chưa build/chạy (không có .NET SDK/SQL Server).
