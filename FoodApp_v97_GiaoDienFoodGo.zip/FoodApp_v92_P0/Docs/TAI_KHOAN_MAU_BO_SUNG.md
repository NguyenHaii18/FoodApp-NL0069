# Tài khoản mẫu bổ sung: 15 gian hàng + 10 tài xế

Mật khẩu chung: **123456**. Dữ liệu nạp tự động ở chế độ ngoại tuyến (`Models/DuLieuMauBoSung.cs`), không cần chạy SQL. Chạy nhiều lần không bị trùng.

## 15 gian hàng (đăng nhập: Email + mật khẩu)

| # | Mã | Gian hàng | Địa chỉ | Email | SĐT |
|---|---|---|---|---|---|
| 1 | gh31 | Cơm Niêu Thố Sài Gòn | 41 Nguyễn Đình Chiểu, Q.3 | comnieutho@foodapp.vn | 0865000131 |
| 2 | gh32 | Bún Riêu Cua Bà Sáu | 12 Hoàng Văn Thụ, Q.Tân Bình | bunrieubasau@foodapp.vn | 0865000132 |
| 3 | gh33 | Hủ Tiếu Nam Vang Thành Đạt | 88 Võ Thị Sáu, Q.3 | hutieunamvang@foodapp.vn | 0865000133 |
| 4 | gh34 | Bánh Cuốn Nóng Thanh Trì | 150 Nguyễn Thái Học, Q.1 | banhcuonthanhtri@foodapp.vn | 0865000134 |
| 5 | gh35 | Gà Nướng Ò Ó O | 33 Trần Hưng Đạo, Q.5 | ganuongoo@foodapp.vn | 0865000135 |
| 6 | gh36 | Trà Đào Cam Sả Nhà Mình | 21 Nguyễn Huệ, Q.1 | tradaocamsa@foodapp.vn | 0865000136 |
| 7 | gh37 | Pizza & Pasta Napoli | 105 Nguyễn Văn Cừ, Q.5 | pizzanapoli@foodapp.vn | 0865000137 |
| 8 | gh38 | Ramen Ichiban | 8 Lê Thánh Tôn, Q.1 | ramenichiban@foodapp.vn | 0865000138 |
| 9 | gh39 | Cà Phê Sân Vườn Hẻm Xanh | 52 Trần Quang Diệu, Q.3 | caphehemxanh@foodapp.vn | 0865000139 |
| 10 | gh40 | Chè Thập Cẩm Hạnh Phúc | 120 Trần Phú, Q.5 | chethapcam@foodapp.vn | 0865000140 |
| 11 | gh41 | Bánh Mì Chảo Hòa Hảo | 24 Hòa Hảo, Q.10 | banhmichao@foodapp.vn | 0865000141 |
| 12 | gh42 | Cơm Gà Hải Nam Chin Chin | 17 Trần Hưng Đạo B, Q.5 | comgahainam@foodapp.vn | 0865000142 |
| 13 | gh43 | Bún Thịt Nướng Chị Tuyền | 205 Cô Giang, Q.1 | bunthitnuong@foodapp.vn | 0865000143 |
| 14 | gh44 | Trà Sữa Đài Loan Lucky | 64 Hoàng Diệu, Q.4 | trasualucky@foodapp.vn | 0865000144 |
| 15 | gh45 | Lẩu Bò Lá Giang Út Nhỏ | 19 Bàn Cờ, Q.3 | laubolagiang@foodapp.vn | 0865000145 |

## 10 tài xế (đăng nhập: SĐT + mật khẩu)

| # | Mã | Họ tên | SĐT | Loại xe | Biển số |
|---|---|---|---|---|---|
| 1 | tx2 | Trần Minh Tuấn | 0386000002 | Xe máy | 59-C1 234.56 |
| 2 | tx3 | Lê Quốc Khánh | 0386000003 | Xe máy | 59-D1 345.67 |
| 3 | tx4 | Phạm Văn Dũng | 0386000004 | Xe máy | 59-E2 456.78 |
| 4 | tx5 | Nguyễn Thanh Sơn | 0386000005 | Xe máy | 59-F1 567.89 |
| 5 | tx6 | Võ Hoàng Nam | 0386000006 | Xe máy | 59-G1 678.90 |
| 6 | tx7 | Đặng Thị Thu Hà | 0386000007 | Xe máy | 59-H1 789.01 |
| 7 | tx8 | Bùi Anh Kiệt | 0386000008 | Xe điện | 59-MĐ 890.12 |
| 8 | tx9 | Huỳnh Gia Bảo | 0386000009 | Xe máy | 59-K1 901.23 |
| 9 | tx10 | Ngô Thị Mỹ Linh | 0386000010 | Xe máy | 59-L1 012.34 |
| 10 | tx11 | Trương Đức Thịnh | 0386000011 | Xe máy | 59-M1 123.45 |

Mỗi quán có 3 món mẫu (mã ma201–ma245). Tài xế đã duyệt sẵn, đăng nhập được ngay.

Lưu ý: chỉ có hiệu lực khi app chạy ngoại tuyến; khi nối server thật thì thêm dữ liệu vào SQL Server.
