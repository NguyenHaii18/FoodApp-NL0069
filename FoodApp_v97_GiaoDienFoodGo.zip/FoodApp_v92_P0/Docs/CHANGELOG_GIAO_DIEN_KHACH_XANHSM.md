# Giao diện khách hàng kiểu Xanh SM (xanh ngọc / teal)

Thay cho bản xanh lá FoodMart trước đó. Bảng màu: Primary #0E8C95, đậm #0A6E7A, nhạt #4CC3C3, nền mềm #E3F6F6, nút nhấn vàng #FFC93C.

## Cấu trúc điều hướng (AppShell)
- Thanh tab còn **4 mục**: Trang chủ · Đơn hàng · Ưu đãi · Tài khoản (icon mới vẽ: tab_home, tab_orders, tab_uudai, tab_taikhoan).
- **Thông báo, Ví của tôi, Tin nhắn** không còn là tab; mở từ trang Tài khoản (các trang đã đăng ký route: ActivityPage, WalletPage, MessagesPage).
- Avatar 👤 ở trang chủ mở thẳng tab Tài khoản (`//chinh/tai-khoan`).
- `Shell.BackgroundColor` toàn cục trả về màu Primary gốc (tím) để trang Admin / Tài xế giữ nguyên giao diện cũ; các trang khách hàng tự đặt thanh tiêu đề trắng, nút quay lại teal.

## Từng màn hình
- **Trang chủ:** header trắng (logo XANH SM · Giao đồ ăn, chuông, avatar, địa chỉ giao, ô tìm kiếm viền teal có lối tắt bản đồ); banner "Món ngon mỗi ngày" + nút vàng "Đặt ngay" (mở tab Ưu đãi); lưới danh mục tròn; danh sách nhà hàng dạng thẻ 2 cột (ảnh trên, ★ điểm, thời gian · khoảng cách, nhãn giảm giá).
- **Ưu đãi (tab mới, UuDaiPage):** banner, thanh lọc (Tất cả / Toàn hệ thống / Của nhà hàng), thẻ mã giảm giá từ dữ liệu khuyến mãi thật (tên quán, mức giảm, đơn tối thiểu, HSD) với nút "Sao chép".
- **Thực đơn (MenuCartPage):** header teal, thẻ món có nút "+" tròn.
- **Giỏ hàng / thanh toán (PaymentPage):** mỗi món có nút **−/+** số lượng ngay trong giỏ (về 0 sẽ hỏi bỏ món; hết món thì quay lại; voucher được kiểm tra lại theo giỏ mới), tổng cộng teal cỡ lớn.
- **Đơn hàng của tôi:** thẻ đơn teal, nhãn trạng thái, "Hôm nay/Hôm qua".
- **Tài khoản (tab):** hồ sơ + thẻ thống kê teal (Đơn đã đặt · Hoàn thành · Đã chi); danh sách mục có thêm Thông báo, Ví của tôi, Tin nhắn.

## Chưa làm / khác mẫu
- Màn hình chào (splash) vẫn là video giới thiệu hiện có; chưa có màn "Món ngon chạm tới bạn".
- Chưa có màn Theo dõi đơn có bản đồ và tiến trình (Đã xác nhận → Đang chuẩn bị → Đang giao → Đã giao).
- Thẻ "Xanh Member / tích lũy điểm" trong mẫu không có dữ liệu thật, nên thay bằng thẻ thống kê đơn hàng.
- Thanh toán: mẫu có Ví Xanh SM / Thẻ ngân hàng / MoMo; app giữ các hình thức đang có (tiền mặt, chuyển khoản, ví điện tử).
- Trang chi tiết nhà hàng chưa có thẻ ảnh bìa lớn và tab Thực đơn / Đánh giá / Thông tin như mẫu.
- Biểu ngữ trang chủ dùng chữ chung ("Ưu đãi hấp dẫn từ nhà hàng"), không ghi "đến 50%".
- Chưa build được .NET MAUI trong môi trường chỉnh sửa; cần build và chạy thử.
