# v80 — Quản lý nhà hàng và thực đơn trên mobile (nền: v79_1)
Chưa build/chạy (không có .NET SDK) — cần Build trên máy. Không cần SQL / máy chủ mới.

| Yêu cầu | Trạng thái |
|---|---|
| Thông tin nhà hàng, địa chỉ, giờ hoạt động, liên hệ | Có sẵn (trang quán: gọi điện, giờ, phí giao, thời gian) |
| Đánh giá của khách (+ phản hồi của quán) | Có sẵn |
| Thực đơn theo danh mục, ảnh, mô tả, giá, còn/hết hàng | Có sẵn |
| Kích cỡ, khẩu phần, topping, mức cay (chọn + phụ thu + gửi đơn) | Có sẵn từ bản trước (chi tiết món) |
| MỚI: hiện gợi ý "🧩 Size · Topping · Mức cay" ngay trên dòng món | |
| MỚI: nút "+" của món có tùy chọn mở trang chi tiết (trước đây thêm thẳng vào giỏ, bỏ qua bước chọn size bắt buộc) | |
| Đường / đá / yêu cầu đặc biệt | MỚI: chip chọn nhanh trong ghi chú — đồ uống: Ít/Không/Nhiều đường, đá; món mặn: Ít/Không/Cay nhiều, Không hành/rau thơm, Ít muối/dầu mỡ. Chỉ hiện khi quán cho ghi chú; mỗi nhóm chọn một |
| Món ăn kèm | MỚI: "🍟 Món ăn kèm gợi ý" ở chi tiết món — món cùng quán hay gọi chung đơn (đếm trên đơn có sẵn), bổ sung món khác danh mục/bán chạy; "+ Thêm" vào giỏ |
| Lưu nhà hàng yêu thích | Có sẵn (♡ ở trang quán, đồng bộ máy chủ) |
| Lưu món ăn yêu thích | MỚI: ♡/♥ ở chi tiết món và ở từng dòng thực đơn (trước đây chỉ bỏ thích được ở trang Yêu thích) |

Mã: `Views/MonAnChiTietPage.xaml(.cs)`, `Views/MenuCartPage.xaml(.cs)`, `Services/TrangChuService.MonAnKem`, `Services/TimKiemService.MonHienThi`.
Lưu ý: đường/đá/yêu cầu đặc biệt là ghi chú tự do gửi cho quán (không có phụ thu); nếu muốn phụ thu/chọn bắt buộc cần quán khai báo loại tùy chọn mới (chưa có).
