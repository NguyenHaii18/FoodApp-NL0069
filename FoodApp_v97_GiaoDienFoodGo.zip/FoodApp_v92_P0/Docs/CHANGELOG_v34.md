# v34 – gộp v33_gop (của bạn) + phân hệ Khách hàng/Gian hàng bổ sung (v33 của mình)

Nền: v32. Gộp ba chiều: v32 (gốc) – `FoodApp_v33_gop` của bạn (hướng dẫn tài xế, tối ưu luồng giao hàng, chỉnh các trang tài xế, `.gitignore`) – bản v33 của mình.
Hai bên sửa hai nhóm file hoàn toàn khác nhau nên không có xung đột: 17 file của mình được thêm vào nguyên vẹn, mọi file bạn sửa giữ nguyên.
Chưa build/chạy thử (không có .NET SDK/SQL Server ở nơi gộp); cần `dotnet build` Web và MAUI.

## Từ bản của bạn (giữ nguyên)
Toàn bộ thay đổi khu Tài xế (DriverHuongDan, DriverHome/Account/Profile/MyOrders, DriverDonHang/Dashboard, `_DriverLayout`, `GiaoHangXuLy`, API tài xế…),
điều phối quản trị (`AdminDieuPhoi`, `AdminTaiXe`), `.gitignore`, `Docs/CHANGELOG_v33.md` của bạn.

## Từ v33 của mình (thêm vào)
Danh mục, Tùy chọn món, Đánh giá & phản hồi của gian hàng; bắt buộc lý do khi từ chối/hủy đơn; cột "Đã dùng" của khuyến mãi; doanh thu theo kỳ + thực nhận + hoàn tiền + CSV;
sắp xếp "Giao nhanh nhất" cho khách. Chi tiết: `Docs/CHANGELOG_v33_KhachGianHang.md` (đổi tên từ `CHANGELOG_v33.md` của mình để không đè bản của bạn).
