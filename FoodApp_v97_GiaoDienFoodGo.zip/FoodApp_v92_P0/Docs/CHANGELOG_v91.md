# v91 — Tài xế · Điều phối viên · CSKH (bổ sung vào mobile)

Dựng trên v86 + v87, rồi GỘP 3 chiều với `FoodApp_v90.zip` (v89 Đối tác + v90 Khách hàng + v91 Tài xế + Mức đường/đá), `FoodApp_v90_BoSung.zip` (sửa trang chủ khách "Quán gần bạn" bấm được + thanh tab dưới `CustomerNavBar`) và `FoodApp_v90_fixvietnamese.zip` (`NhapAsync`, `TreTimKiem`). CHƯA build thật trên MAUI/SQL Server — hãy build trong Visual Studio và báo lỗi nếu có.

## Đã có từ trước (đối chiếu, không làm lại)
Chỉ đường/bản đồ, đến quán, mã đơn, mã 4 số + ảnh bằng chứng, gọi/nhắn khách, giao thất bại (7 lý do), báo sai địa chỉ, theo dõi hủy đơn, thu nhập ngày/tuần/tháng, thưởng, COD, ví (nạp/rút + lịch sử), đánh giá, hiệu suất, báo sự cố, Điều phối tài xế (phân công/đổi/gỡ/tự động/đề nghị có thời hạn), Tra cứu khách, Khiếu nại, Hoàn tiền.

## Mới
**Tài xế**
- 📈 Tỷ lệ & vi phạm (`DriverThuongTyLePage`; mốc thưởng dùng `DriverThuongPage` của v90): tỷ lệ hoàn thành/hủy 30 ngày, thời gian giao TB, lịch sử cảnh báo/vi phạm, gửi khiếu nại.
- 🆘 Trung tâm hỗ trợ (`DriverHoTroPage`): gửi nhanh 10 tình huống (mất mạng, lỗi GPS, tai nạn/xe hỏng, quán chưa chuẩn bị, khách không nghe máy, sai địa chỉ, khách không có mặt, thiếu/sai món, tranh chấp), chat với điều phối, theo dõi tiến độ yêu cầu.

**Điều phối viên** — 📡 Bảng điều phối (`AdminDieuPhoiTongQuanPage`): số đơn trong ngày theo trạng thái, tài xế trực tuyến/ngoại tuyến/bận/rảnh, đơn nguy cơ trễ (chờ ≥ 20 phút), khu vực thiếu tài xế, tìm tài xế, gửi lại lời mời, thu hồi đơn, lối tắt xử lý sự cố & chuyển CSKH, báo cáo điều phối + xuất Excel.

**CSKH** — 🎧 Chăm sóc khách hàng (`AdminCskhPage`): tra cứu khách, 8 nhóm yêu cầu (đơn, thanh toán, giao hàng, nhà hàng, tài xế, voucher, tài khoản, hoàn tiền), ghi chú nội bộ (nút 📝 trong Tra cứu khách).

## Giới hạn
- Ghi chú nội bộ CSKH lưu trên thiết bị (chưa lên SQL Server).
- Tỷ lệ nhận đơn / thời gian tìm tài xế TB / hiệu suất theo khu vực cần dữ liệu từ máy chủ — chưa có ở bản này.
- Báo cáo điều phối tính từ 20 sự kiện nhật ký gần nhất + đơn hôm nay.
- Bản đồ vị trí tài xế thời gian thực: dùng màn Lộ trình/Theo dõi đơn sẵn có.

## Gộp từ 3 file v90
- Lấy bản `FoodApp_v90.zip` làm nền cho mọi file hai bên cùng sửa (Đối tác, Khách hàng, Tài xế: giấy tờ/ngân hàng, trạng thái làm việc, nghỉ, thưởng, xuất thu nhập, ảnh sự cố, Mức đường/đá, sửa lỗi biên dịch web, SQL `FoodService_BoSung_MucDuongDa.sql`).
- Từ `BoSung`: trang chủ khách (Quán gần bạn bấm được, 1–2 hàng) + `CustomerNavBar` (thanh tab dưới trên Windows) — bản này mới hơn bản 2 hàng trong FoodApp_v90.zip nên được ưu tiên.
- Từ `fixvietnamese`: `NhapUi.NhapAsync` thay `DisplayPromptAsync`, `TreTimKiem`; các lời gọi nhập chữ mới (CSKH, Super Admin, Tùy chọn món, Ngày sinh) cũng đã đổi sang `NhapAsync`.
- Bỏ phần trùng của v91 cũ: nút xuất thu nhập (đã có ở v90), loại sự cố mới trên máy chủ (app v90 đã ánh xạ về loại cũ), khối thưởng.
- Phải chạy `Database/FoodService_BoSung_MucDuongDa.sql` một lần trên CSDL đang dùng.

## Gộp thêm: SuaLoiBanDo + NL0069 + sửa lỗi web
- `FoodApp_v86_SuaLoiBanDo.zip` (chỉ khác v86 gốc ở 4 file: `BanDoPage.xaml(.cs)`, `TrangChuPage.xaml.cs`, `MainApplication.cs` + `Docs/SUA_LOI_NUT_BAN_DO.md`): đã gộp 3 chiều; nút 🗺️ không còn làm app thoát, thiếu WebView thì mở Google Maps.
- `FoodApp-NL0069-main.zip`: bản cũ hơn — chiến dịch quảng cáo (Web + MAUI + API) đã có sẵn từ trước; không có API/lớp/màn hình nào còn thiếu nên không đưa gì thêm. Các script SQL đánh số cũ trong đó cố ý KHÔNG đưa vào để không lẫn với bộ SQL hiện hành.
- Lỗi web trong `attachment.txt` (TaiXe thiếu `ViTriLuc`, `NhipLuc`, `TamKhoaNhanDenLuc`, `SoLanKhongPhanHoi`, `SoLanHuySauNhan`, `ViDo`, `KinhDo`; `DriverDonXuLy` không tồn tại; Razor `Unexpected "{" after "@"`): đã có sửa từ v90 trong bản này (7 cột trong `Entities.cs` + trong 2 script SQL, `using`/tên đầy đủ cho `DriverDonXuLy`, bỏ `@{}` lồng ở `Views/DonHang/Index.cshtml`). Cần chạy `FoodService_NangCap.sql` nếu CSDL cũ chưa có 7 cột này.
