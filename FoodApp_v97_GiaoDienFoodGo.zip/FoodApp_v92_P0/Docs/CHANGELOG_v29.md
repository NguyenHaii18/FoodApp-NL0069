# v29 – v28 + giao diện tài xế của v26

Nền: FoodApp_v28 (giữ nguyên toàn bộ Web/API/SQL và chức năng v27: báo sự cố, hồ sơ CCCD/GPLX, upload).
Phần "gộp các gói trước" (v12 + v15 + v24): v28 đã chứa sẵn (kể cả sửa bảng TaiXeTuChoiDon: LyDo/ThoiGian), nên không có gì phải thêm cho Web/SQL.

## Thay giao diện tài xế bằng bản v26 (XANH EXPRESS)
- Thay: DriverHomePage, DriverMyOrdersPage (chip lọc), DriverOrderDetailPage, DriverEarningsPage (biểu đồ cột), DriverNotificationsPage.
- Mới: DriverAccountPage, DriverWalletPage (+ Services/ViTaiXeService), DriverSettingsPage, DriverHeader, DriverNavBar; route đăng ký trong AppShell.xaml.cs.
- Bỏ DriverBottomBar của v28 (thay bằng DriverNavBar); DriverProfilePage dùng DriverNavBar.
- Giữ DriverTheme.xaml + DriverPalette.cs của v28 (đủ khóa cho mọi trang).

## Giữ chức năng v27 trong giao diện mới
- Tài khoản -> "Báo sự cố & hỗ trợ" mở DriverSuCoPage.
- Thu nhập -> nút "Báo sai lệch thu nhập / COD" (chọn loại rồi mở DriverSuCoPage).
- DriverDeliveryDetailPage (nút Báo sự cố), DriverProfilePage (CCCD, GPLX, ảnh GPLX, trạng thái duyệt), DriverLoginPage, DriverRegisterPage, DriverRatingPage: giữ bản v28.

## Lưu ý
- Ví tài khoản: nạp/rút chỉ ghi sổ trên thiết bị, chưa nối ngân hàng.
- Chưa build MAUI/Web (không có workload); đã kiểm tra cú pháp C#, handler/tên control XAML, khóa tài nguyên theme.
