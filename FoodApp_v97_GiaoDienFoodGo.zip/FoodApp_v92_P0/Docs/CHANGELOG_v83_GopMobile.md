# v83 — gộp các chức năng mobile của v69 vào v82

Nền: `FoodApp_v82` (thư mục bên trong ghi `FoodApp_v81`). Gộp ba chiều: gốc v68, bản của mình v69, đích v82. Chỉ gộp **app mobile** (`Mobile_FoodApp.Maui`) như bạn yêu cầu; Web và SQL không đổi.
Không có xung đột; 8 file mobile khác v82, mọi file khác giữ nguyên.

## Đã gộp
| File | Cách gộp | Nội dung |
|---|---|---|
| `Views/AdminTinTucPage.cs` | thêm mới | Quản trị → Quản lý nội dung → **Tin tức & ưu đãi**: soạn, sửa, hẹn ngày đăng, đặt hạn, ghim, ẩn/hiện, xóa, gửi kèm thông báo |
| `AppShell.xaml.cs` | gộp 3 chiều | đăng ký route `AdminTinTucPage` |
| `Views/AdminPages2.cs` | gộp 3 chiều | mục "Tin tức & ưu đãi" trong menu quản trị |
| `Views/AdminPages3.cs` | chép | **Gửi thông báo theo nhóm**: khách mới / đặt gần đây / lâu chưa đặt / chưa từng đặt / thân thiết; quán đang mở / không có đơn; tài xế sẵn sàng / đang giao; xem trước số người nhận |
| `Models/Models.cs` | gộp 3 chiều | `TinTuc.Ghim`, `TinTucData.TaiTuMayChuAsync`: tin quản trị soạn được gộp vào danh sách "Tin mới" |
| `Views/TrangChuPage.xaml.cs`, `Views/TinTucPage.xaml.cs` | gộp 3 chiều / chép | "Tin mới" tải tin từ máy chủ, tin ghim (📌) lên đầu |
| `API_MOBILE.md` | chép | mục tin tức và nhóm thông báo |

## Hai chỉnh sửa so với v69 để an toàn khi máy chủ chưa cập nhật
1. **Soạn thông báo:** trước đây luôn gọi `admin/thong-bao/xem-truoc` rồi mới gửi; máy chủ chưa có API này thì *mọi* thông báo đều không gửi được. Nay máy chủ cũ vẫn gửi được các nhóm cũ (tất cả, khách, gian hàng, tài xế, danh sách tên), chỉ không hiện số người nhận; các nhóm theo hành vi bị chặn kèm thông báo "cập nhật máy chủ".
2. **Soạn tin:** truyền chuỗi rỗng thay vì `null` vào ô nhập (hàm `AdminUi.Hoi` ở v82 nhận chuỗi không-null).

## Máy chủ cần có để các chức năng này chạy đủ
App mobile gọi các API mà v82 **chưa có** (chưa gộp vì ngoài phạm vi yêu cầu):
- `GET api/mobile/tin-tuc` (công khai) và `api/mobile/admin/tin-tuc` (xem/soạn/sửa/ghim/ẩn-hiện/xóa) — `AdminTinTucApiController.cs`, thực thể `TinTucEntity.cs`, `DbSet<TinTuc>` trong `AppDbContext.cs`.
- `POST api/mobile/admin/thong-bao/xem-truoc` và các nhóm mới của `POST api/mobile/admin/thong-bao` — `AdminMobileExtraApiController.cs`.
- Bảng `TinTuc` trong `FoodService_Database.sql` / `FoodService_NangCap.sql`.
Khi chưa có: tin của quản trị không hiện ở app khách (tin tự sinh vẫn hiện), trang Tin tức & ưu đãi báo lỗi tải danh sách, nhóm thông báo theo hành vi bị chặn.

## Lưu ý
Chưa build/chạy thử (không có .NET SDK ở nơi gộp): cần build lại app MAUI. Đã kiểm tra tên điều khiển, hàm dùng chung (`AdminUi`, `J`, cấu hình danh sách) có đủ và khớp chữ ký ở v82, và ngoặc cân bằng ở các file đã đổi.
