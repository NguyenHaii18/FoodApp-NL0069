# v47c — v47b + phần nâng cấp v39.1 (khách)

Chưa build/chạy (không có .NET SDK/SQL Server).
- v47b đã có sẵn "tài xế của quán / shipper ngoài" (không cần gộp lại).
- Thêm: `POST api/mobile/khuyen-mai/kiem-tra` (server kiểm tra voucher bằng `KhuyenMaiXuLy.TinhAsync`) và app gọi khi nhập mã / chọn ưu đãi (offline thì kiểm tra cục bộ).
- Thêm: trang theo dõi đơn của khách tự cập nhật mỗi 15 giây khi còn đơn đang xử lý.
