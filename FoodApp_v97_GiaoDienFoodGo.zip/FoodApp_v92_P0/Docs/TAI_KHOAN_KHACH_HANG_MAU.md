# Tài khoản khách hàng mẫu (20 tài khoản)

Chạy `Database/FoodService_DuLieuMau.sql`. Mật khẩu chung: **123456**

| Tên đăng nhập | Họ tên | SĐT | Email |
|---|---|---|---|
| khachlan | Nguyễn Thị Lan | 0901234501 | khachlan@foodapp.vn |
| khachminh | Trần Quang Minh | 0901234502 | khachminh@foodapp.vn |
| khachhoa | Lê Thị Hoa | 0901234503 | khachhoa@foodapp.vn |
| khachduc | Phạm Văn Đức | 0901234504 | khachduc@foodapp.vn |
| khachmai | Võ Ngọc Mai | 0901234505 | khachmai@foodapp.vn |
| khachtuan | Đặng Anh Tuấn | 0901234506 | khachtuan@foodapp.vn |
| khachthao | Bùi Thanh Thảo | 0901234507 | khachthao@foodapp.vn |
| khachkhoa | Hoàng Minh Khoa | 0901234508 | khachkhoa@foodapp.vn |
| khachnga | Ngô Thị Nga | 0901234509 | khachnga@foodapp.vn |
| khachhung | Đỗ Mạnh Hùng | 0901234510 | khachhung@foodapp.vn |
| khachphuong | Trịnh Thu Phương | 0901234511 | khachphuong@foodapp.vn |
| khachlong | Lý Hoàng Long | 0901234512 | khachlong@foodapp.vn |
| khachyen | Phan Hải Yến | 0901234513 | khachyen@foodapp.vn |
| khachbao | Dương Gia Bảo | 0901234514 | khachbao@foodapp.vn |
| khachtrang | Mai Thùy Trang | 0901234515 | khachtrang@foodapp.vn |
| khachvinh | Cao Quốc Vinh | 0901234516 | khachvinh@foodapp.vn |
| khachquynh | Tạ Như Quỳnh | 0901234517 | khachquynh@foodapp.vn |
| khachdat | Lâm Tiến Đạt | 0901234518 | khachdat@foodapp.vn |
| khachchi | Vương Kim Chi | 0901234519 | khachchi@foodapp.vn |
| khachson | Huỳnh Thái Sơn | 0901234520 | khachson@foodapp.vn |
