# v41 — Sửa lỗi đồng bộ app MAUI ↔ backend

## P0 — Thanh toán
- `PaymentPage`: chỉ còn **Tiền mặt** và **VNPay** (khớp `MobileApiController.IsValidPayment`, đã bỏ `ChuyenKhoan`).
  Mặc định cũ `ChuyenKhoan`/`ViDienTu` trong Preferences tự quay về tiền mặt. `ProfilePage` (thanh toán mặc định) cũng chỉ còn 2 nút.
- Đặt đơn VNPay: mở cổng VNPay → khách quay lại → app **hỏi máy chủ** kết quả qua `GET api/mobile/don-hang/{id}/thanh-toan`
  (máy chủ ghi kết quả qua return/IPN). Thành công / thất bại / chưa có kết quả đều có thông báo; có nút mở lại trang thanh toán.
- Đơn VNPay chưa trả: tab **Đơn hàng** có nút "💳 Thanh toán VNPay" (xin link mới qua `payment/vnpay/tao-url`), hiện trạng thái thanh toán.
- VNPay khi ngoại tuyến bị chặn (cần máy chủ).
- Backend: thêm `GET api/mobile/don-hang/{id}/thanh-toan`; đơn trả thêm `trangThaiThanhToan`; `tao-url` dùng đúng ReturnUrl.
- Sửa kèm: ghi chú đơn (`ghiChu`) trước đây không được gửi lên máy chủ.

## P1 — Lọc danh mục quán
- `GET api/mobile/gian-hang` trả `phanLoai` thật, suy ra từ tên quán + danh mục + tên món (`Services/PhanLoaiGianHang.cs`),
  một quán có thể nhiều loại: `"com,tra"`. Không cần đổi CSDL. Quán không khớp loại nào vẫn hiện ở "Tất cả".
- App lọc bằng `GianHang.CoLoai()` (hỗ trợ nhiều loại).

## P1 — Giỏ hàng
- `Services/GioHangService.cs`: một giỏ dùng chung, lưu theo tài khoản (Preferences) và đồng bộ `api/mobile/khach-hang/gio-hang`;
  khôi phục khi mở lại app / đổi máy; lưu lại khi mất mạng rồi đẩy lên sau.
- Trang thanh toán: tăng/giảm, 🗑 bỏ món, 📝 ghi chú từng món (ghi chú gộp vào ghi chú đơn).
- Thêm món của quán khác → hỏi trước khi thay giỏ. Đặt xong thì dọn giỏ (app + server). Đăng xuất reset giỏ trong bộ nhớ.
- Chưa làm: chi tiết món + tùy chọn món như website (API `mon-an` chưa trả `TuyChon`).

## P1 — Chat
- Đã có sẵn từ v40: `ChatApiController` (`GET don-hang/{id}/tin-nhan`, `POST tin-nhan`, kiểm tra khách/tài xế của đơn, bảng `TinNhan`)
  và `ChatService` đồng bộ mỗi 2,5 giây. Không phải sửa. Lưu ý: chỉ nhắn được khi đơn ở `DaXacNhan`/`DangGiao` và đã có tài xế.

## P1 — Ví
- `WalletPage` không còn số dư `0đ` và các nút nạp/chuyển/rút/liên kết thẻ giả; ghi rõ "Sắp ra mắt",
  liệt kê phương thức đang hỗ trợ (tiền mặt, VNPay). Giữ phần "Ưu đãi của bạn".
