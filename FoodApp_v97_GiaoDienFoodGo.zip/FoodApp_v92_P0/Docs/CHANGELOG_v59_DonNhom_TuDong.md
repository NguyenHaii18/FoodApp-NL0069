# v59 — Đơn hàng nhóm + tự động phân công hoàn toàn (nền: v58)
Chưa build/chạy (không có .NET SDK) — cần Build trên máy. Đã kiểm tra tĩnh: ngoặc cân bằng, XAML hợp lệ.

## Đơn hàng nhóm
- Server: `Controllers/Api/DonNhomApiController.cs` (`api/mobile/don-nhom`: tạo nhóm, vào bằng mã 5 ký tự, đặt phần món, chốt, rời/giải tán). Nhóm lưu TRONG BỘ NHỚ máy chủ, hết hạn sau 2 giờ, mất khi máy chủ khởi động lại (không cần bảng/migration mới). Đơn thật vẫn tạo bằng `POST api/mobile/don-hang` nên giá/khuyến mãi/thanh toán do máy chủ kiểm tra.
- Mobile: Hồ sơ → **Đặt chung (đơn nhóm)** (`Views/DonNhomPage.cs`, `Services/DonNhomService.cs`): chủ nhóm chọn quán và chia sẻ mã; thành viên vào nhóm, chọn số lượng từng món; tự làm mới 5 giây; chủ nhóm "Chốt, gom vào giỏ & đặt hàng" → giỏ hàng + mở quán để thanh toán như thường. Cần online + đăng nhập khách.

## Tự động phân công hoàn toàn
- Điều phối tài xế → nút **🤖 Tự động: BẬT/tắt**. Khi bật và màn hình đang mở: mỗi 30 giây tự chạy cùng thuật toán "⚡ Tự phân công" (tài xế Sẵn sàng ít đơn nhất, ưu tiên đúng khu vực) nhưng KHÔNG hỏi xác nhận; vẫn ghi lý do + nhật ký. Nút "⚡ Tự phân công" cũ (có xem trước) giữ nguyên.
- Giới hạn: chỉ chạy khi ứng dụng quản trị đang mở màn hình điều phối; chạy nền 24/7 cần đưa thuật toán lên máy chủ.

## Đã có ở v53–v58 (không làm lại)
Đa ngôn ngữ Việt/Anh, giọng nói, gợi ý lộ trình nhiều đơn (tài xế), tự phân công có xem trước.
## Chưa làm
Tối ưu lộ trình theo đường thật (cần Goong/Google Directions + tọa độ); lưu nhóm vào CSDL.

# v60 — Tự động phân công chạy nền trên máy chủ + lộ trình theo đường thật
Chưa build/chạy (không có .NET SDK). Đã kiểm tra tĩnh: ngoặc cân bằng.

## 1. Tự động phân công 24/7 trên máy chủ
- Server: `Services/TuDongPhanCongXuLy.cs` (logic + `BackgroundService` `TuDongPhanCongNen`, đăng ký trong Program.cs) — mỗi 30 giây, nếu cấu hình `DieuPhoi.TuDong = 1` và hệ thống ở chế độ quản trị điều phối: giao đơn quán đã báo sẵn sàng cho tài xế SẴN SÀNG (ưu tiên đúng khu vực hoạt động, rồi ít đơn nhất; mỗi tài xế tối đa 1 đơn/lượt), ghi `DieuPhoiLog` + thông báo cho tài xế như phân công tay.
- API: `GET/PUT api/mobile/admin/dieu-phoi/tu-dong` (xem / bật-tắt), `POST .../tu-dong/chay-ngay`. Cần quyền "DonHang". Không cần bảng mới (dùng bảng cấu hình hệ thống có sẵn).
- Mobile: Điều phối tài xế → **🤖 Tự động** → bật/tắt, xem trạng thái (đã phân công bao nhiêu, lần chạy cuối), chạy ngay. Thay cho bản chạy trên máy (v59). Nút "⚡ Tự phân công" có xem trước giữ nguyên.
- Lưu ý: số liệu "đã phân công / lần chạy cuối" giữ trong bộ nhớ máy chủ (mất khi khởi động lại); trạng thái bật/tắt lưu DB. Nếu chạy nhiều bản máy chủ cùng lúc thì mỗi bản có một vòng lặp riêng — nên chỉ bật ở một bản.

## 2. Lộ trình theo đường thật
- Server: `POST api/map/lo-trinh` (MapController): geocode địa chỉ (nhớ đệm) + Goong DistanceMatrix (xe máy) + giải thứ tự lấy-trước-giao bằng láng giềng gần nhất + 2-opt (`Services/Maps/LoTrinhToiUu.cs`). Tối đa 8 điểm/lần (số lượt gọi Goong tăng theo bình phương nên có giới hạn, có nhớ đệm quãng đường).
- Mobile: tài xế → Đơn hàng → **🧭 Gợi ý lộ trình** gọi API trên trước; hiện km + phút theo đường thật và km tiết kiệm so với thứ tự mặc định. Nếu máy chủ chưa có khóa Goong / không geocode được địa chỉ / quá 8 điểm → tự dùng bản ước tính theo quận/huyện và ghi rõ lý do.
- CẦN LÀM: điền `GoongMaps:ApiKey` thật trong appsettings của máy chủ (hiện là "DIEN_API_KEY_GOONG_CUA_BAN").
- Chưa tính kẹt xe theo giờ; chưa hiển thị đường đi trên bản đồ trong app.

# v61 — Khóa Goong nhập trong app + kẹt xe theo giờ + vẽ lộ trình trên bản đồ
Chưa build/chạy (không có .NET SDK) — cần Build trên máy. Đã kiểm tra tĩnh: ngoặc cân bằng.
- **Khóa Goong**: Admin tổng vào Quản trị → Hệ thống → **Khóa bản đồ Goong** để dán khóa, bấm *Kiểm tra*, hoặc xóa. Lưu ở CSDL (`CauHinhHeThong` khóa `Goong.ApiKey`, có lịch sử), ưu tiên hơn `GoongMaps:ApiKey` trong appsettings; nạp lại khi máy chủ khởi động. API `api/mobile/admin/goong` (chỉ SuperAdmin, không bao giờ trả khóa đầy đủ). Mã nguồn không chứa khóa thật — bạn phải tự nhập khóa của mình.
- **Kẹt xe theo giờ**: `Services/Maps/GiaoThongTheoGio.cs` nhân thời gian di chuyển theo khung giờ (cao điểm sáng ×1.4, trưa ×1.25, chiều ×1.5, cuối tuần nhẹ hơn, đêm ×0.85). Đây là ƯỚC TÍNH, không phải giao thông thời gian thực (Goong DistanceMatrix không có).
- **Vẽ đường đi**: `GoongMapsService.GetRouteAsync` (Goong Direction, giải mã polyline) → `/api/map/lo-trinh` trả thêm `diem`, `chang`, `heSoKetXe`. App: sau khi gợi ý lộ trình bấm **Xem bản đồ** (`Views/LoTrinhBanDoPage.cs`, Leaflet/OSM, điểm đánh số, chặng không có đường chi tiết vẽ nét đứt). Cần Internet để tải ô bản đồ.
- Chưa xác minh với Goong thật: định dạng phản hồi Direction (giả định `routes[0].overview_polyline.points`, độ chính xác 5).
