# v42 — Đổi tên FoodApp, toàn bộ màu tím, giao diện Quản trị mobile mới

Chưa biên dịch / chưa chạy thử (môi trường không có .NET SDK) — cần build và xem thực tế.

- Đổi "XANH SM" / "XANH EXPRESS" thành "FOODAPP" (trang chủ khách, đăng nhập tài xế, chữ "Mã giảm giá từ FoodApp").
- Đổi toàn bộ màu teal / cam / xanh tím cũ trong app MAUI sang bảng tím (#6D28D9, #5B21B6, #8B5CF6, #A78BFA, nền #FAF8FF), gồm CustomerTheme, VendorTheme, DriverTheme và các màu viết cứng trong Views/Services. ThemeColors.cs (bộ chọn màu chủ đề) giữ nguyên, mặc định Tím.
- Quản trị mobile theo mẫu mới:
  - AdminLoginPage: nền tím gradient, logo, thẻ đăng nhập trắng, "Quên mật khẩu?".
  - AdminHomePage (Tổng quan): thanh tiêu đề tím, 4 thẻ số liệu, biểu đồ cột doanh thu 7 ngày, Việc cần xử lý, Thao tác nhanh, đơn theo trạng thái.
  - AdminNavBar (mới): tab dưới Tổng quan · Quản lý · Thông báo · Cá nhân.
  - AdminHubPage thành tab "Quản lý"; AdminNotificationsPage và AdminProfilePage (mới).

## Bản đồ (mobile)
- `BanDoPage`: thêm nút "📍 Vị trí của tôi" (GPS, chấm xanh trên bản đồ) và "🏬 Quán gần bạn" (đặt các quán đã duyệt lên bản đồ bằng Nominatim, nhớ tọa độ đã tra, danh sách xếp theo khoảng cách khi đã có vị trí). Chưa biên dịch/chạy thử; cần Internet.
