# FoodApp v16 (gộp v12–v15 + cập nhật tài khoản & hồ sơ tài xế)

## Code (Web/Controllers)
- DriverAuthController: đăng nhập hiển thị lý do từ chối / yêu cầu bổ sung hồ sơ.
- AdminTaiXeController: duyệt hồ sơ -> xóa lý do cũ, gửi thông báo cho tài xế.
- MobileApiController: đăng nhập tài xế báo lý do; duyệt/từ chối gửi thông báo; chặn xem đơn khi chưa duyệt; cập nhật ảnh đại diện (AnhDaiDien, tùy chọn).
- DriverApiController, DriverDashboardController, DriverDonHangController: chặn tài xế chưa duyệt bật trạng thái sẵn sàng và xem/nhận đơn.

## Trạng thái làm việc và nhận đơn
- Bảng mới TaiXeTuChoiDon (Database/NangCap/NangCap_v21_TaiXeTuChoiDon.sql — chạy trước khi chạy app).
- GiaoHangXuLy: DonChoNhan (ẩn đơn đã từ chối), TuChoiDonAsync, ThongBaoDonMoiAsync (báo tài xế sẵn sàng khi đơn sẵn sàng giao), XuLyQuaHanNhanDonAsync (quá 5 phút chưa ai nhận -> điều phối lại + báo quản trị, cấu hình Don.TaiXePhanHoiPhut), NhanDonAsync chặn tài khoản bị khóa.
- Từ chối đơn: Web (nút Từ chối ở Đơn chờ nhận), API driver POST orders/{id}/reject, Mobile PUT tai-xe/don-hang/{id}/tu-choi.
- DriverHomeDto thêm SoDonDangGiao (tùy chọn).
- Chưa làm: màn hình MAUI (nút Từ chối, hiển thị số đơn đang giao).

## Quản lý đơn giao
- Services/DriverDonXuLy.cs (mới): danh sách đơn theo nhóm (nhan / dang-giao / hoan-thanh / that-bai) và chi tiết đơn, chỉ cho tài xế xem đơn thuộc chuyến của mình. Đơn bị hủy nằm ở nhóm that-bai (GiaoHang "GiaoThatBai").
- Chi tiết đơn: mã đơn, gian hàng (địa chỉ, SĐT), khách (SĐT chỉ hiện khi đơn đang thực hiện, sau đó bị ẩn), ghi chú giao hàng, hình thức + trạng thái thanh toán, số tiền cần thu hộ (COD), tiền đã thu, lý do hủy/thất bại, danh sách món.
- Web: trang "Đơn của tôi" (TaiXe/DonHang/CuaToi), trang chi tiết (TaiXe/DonHang/ChiTiet/{id}), menu mới, mã đơn trong Lịch sử giao hàng có liên kết.
- API driver: GET api/driver/orders?tab=..., GET api/driver/orders/{id}. Mobile: GET tai-xe/don-hang?tab=..., GET tai-xe/don-hang/{id}.
- Chưa làm: màn hình MAUI dùng các endpoint mới.

## Quy trình lấy món tại gian hàng
- DaLayHangAsync: chặn "Đã lấy hàng" khi quán chưa báo sẵn sàng giao / chưa bàn giao (cấu hình Don.BatBuocSanSangGiao, nay mặc định = 1; đặt 0 để tắt cho app quán cũ). Kiểm tra mã đơn: nếu nhập thì phải khớp mã đơn; Don.BatBuocMaDonKhiLayHang = 1 thì bắt buộc nhập (mặc định 0 vì app mobile cũ chưa gửi mã đơn; web luôn bắt nhập).
- Web: ô nhập mã đơn khi bấm "Đã lấy hàng"; nút báo sự cố tại quán trong trang Chuyến hiện tại.
- Loại sự cố mới: QuanChuanBiCham, KhongTimThayDon, SaiMon, ThieuMon, VanDeBanGiao -> thông báo cho gian hàng và quản trị.
- API driver: POST orders/{id}/arrive, POST orders/{id}/pickup-issue, POST orders/{id}/start?maDon=. Mobile: POST tai-xe/don-hang/{id}/su-co, PUT don-hang/{id}/da-lay-hang?maDon=.
- Database/NangCap/NangCap_v21_TaiXeTuChoiDon.sql: bật Don.BatBuocSanSangGiao = 1 và thêm khóa Don.BatBuocMaDonKhiLayHang (cần chạy lại trên CSDL đã có). FoodService_Database.sql đã đổi giá trị mặc định.
- Lưu ý: app MAUI của gian hàng phải bấm "Sẵn sàng giao" thì tài xế mới lấy hàng được (script NghiemThu_E2E đã làm đúng bước này).
- Chưa làm: màn hình MAUI (ô mã đơn, nút báo sự cố).

## Tài liệu
- KhoaLuan_QuanLyDichVuAnUong_HoanChinh.docx: mục 1.3.1 (c) bổ sung nhóm "Tài khoản và hồ sơ tài xế" và "Trạng thái làm việc và nhận đơn" "Quản lý đơn giao" và "Quy trình lấy món tại gian hàng".

## Chưa làm
- Ảnh đại diện trên trang hồ sơ web, nhập CCCD/GPLX khi đăng ký web, gửi lại hồ sơ sau khi bị từ chối.
