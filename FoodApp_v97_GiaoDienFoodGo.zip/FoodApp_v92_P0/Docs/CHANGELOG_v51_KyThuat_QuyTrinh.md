# v51 — Chức năng kỹ thuật bổ sung & quy trình tổng thể (Mobile)

## Mới
- `Services/GiamSatService.cs` + `ApiClient`: ghi mọi lời gọi API (thời gian, mã HTTP, lỗi mạng, lỗi thanh toán/đặt đơn); GET gặp lỗi kết nối tức thời tự thử lại 1 lần (POST/PUT không tự thử lại để không tạo trùng); kiểm tra `/health`.
- `Services/SaoLuuService.cs`: sao lưu dữ liệu cục bộ (tự động mỗi 24h khi mở app, giữ 7 bản), kiểm tra khả năng khôi phục, khôi phục (tự sao lưu trước khi khôi phục).
- 4 trang quản trị (Quản lý → Hệ thống): **Quy trình hoạt động**, **Giám sát hệ thống**, **Bảo mật & quyền riêng tư**, **Sao lưu & phục hồi** (`Views/AdminKyThuatPages.cs`).

## Đã có sẵn từ trước (không viết lại)
HTTPS/HSTS và `/health` phía server; băm mật khẩu có muối; phân quyền theo vai trò; nhật ký thao tác; bản đồ & định vị có xin quyền; chống tạo đơn trùng (`maYeuCauDat`); thanh tiến trình đơn 5 bước phía khách; thông báo từ server.

## Chưa làm / giới hạn
- Thông báo đẩy nền (FCM/APNs) và kết nối thời gian thực (SignalR) chưa có; hiện tải khi mở màn hình / kéo làm mới.
- Sao lưu SQL Server là việc của máy chủ; trang chỉ sao lưu dữ liệu trên thiết bị.
- Số liệu giám sát chỉ cho phiên chạy hiện tại; các yêu cầu chất lượng (hiệu năng, mở rộng, tương thích) cần đo thực tế.
- Chưa biên dịch (không có .NET SDK trong môi trường soạn) — cần Build và thử trên máy.

# v52 — Tính năng nâng cao (mục IX)
Mới: `Services/NangCaoService.cs`, `Views/ThanhVienPage.cs`.
- Khách: Hồ sơ → **Thành viên & gợi ý món** — hạng Đồng/Bạc/Vàng/Kim cương theo tổng chi đơn hoàn thành, điểm, tiến độ lên hạng; ước tính CO₂ chuyến giao; gợi ý món theo lịch sử đặt (luật thống kê, không phải AI học máy).
- Quản trị: Quản lý → Hệ thống → **Vận hành thông minh** — dự báo số đơn/giờ và số tài xế cần; gợi ý tài xế cho đơn chờ (đánh giá cao, ít đơn đang giữ); gợi ý ghép đơn cùng quán.
- Đã có sẵn: chat trong app, đặt giao theo giờ hẹn, phát hiện gian lận (Trung tâm vận hành).
- Chưa làm: đa ngôn ngữ, đặt món bằng giọng nói, đơn hàng nhóm, tối ưu lộ trình thật (cần dịch vụ bản đồ/tọa độ), phân công tự động hoàn toàn, mô hình AI thật.
- Quyền lợi thành viên chưa tự áp vào giá. Chưa biên dịch — cần Build trên máy.
