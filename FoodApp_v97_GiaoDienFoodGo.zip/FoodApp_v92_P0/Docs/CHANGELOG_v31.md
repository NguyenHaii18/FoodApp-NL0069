# v31 – xử lý 3 rủi ro từ bản rà soát (nền: v30)

| Mức | Rủi ro | Đã xử lý |
|---|---|---|
| P0 | Chạy `FoodService_Database.sql` làm mất dữ liệu (DROP DATABASE) | Đã xử lý ở v30 của bạn bằng khóa `@CHO_PHEP_XOA_DB` (tự sao lưu trước khi xóa); bản `SESSION_CONTEXT` ban đầu của mình **không dùng** trong v32. |
| P1 | MAUI báo thành công khi chưa đồng bộ máy chủ | `DuLieuService` phân biệt 3 trạng thái `KetQuaGhi { DaDongBo, LuuTrenMay, ThatBai }` (`GhiTrangThaiAsync`, `LanGhiCuoi`). `GhiAsync` giữ chữ ký cũ nên các nơi gọi khác không đổi. Thêm `ChuThichGhi()` (gắn cảnh báo ngoại tuyến vào thông báo thành công) và `GhiHoanTacAsync()` (máy chủ từ chối thì **trả lại** thay đổi đã áp dụng trên máy). |
| P1 | Quản lý phiên bản CSDL chưa chắc chắn (`EnsureCreated`, không có migrations) | Thêm `Services/KiemTraSchema.cs`: khi khởi động, so sánh mô hình EF với CSDL thật (chỉ đọc), in cảnh báo thiếu bảng/cột ở console, hiện **thanh đỏ trên mọi trang quản trị** và danh sách chi tiết ở "Hệ thống & phiên". Đặt `"Database:DungKhiLechSchema": true` để Web từ chối khởi động khi schema lệch. |

## Chi tiết MAUI
- Admin (duyệt/từ chối gian hàng, xử lý vấn đề, khóa/mở khóa gian hàng và khách): trước đây đổi trạng thái trên máy rồi mới gọi máy chủ và bỏ qua kết quả; nay máy chủ từ chối thì hoàn tác, không báo "Đã duyệt/Đã khóa", không ghi nhật ký. Ngoại tuyến thì thông báo kèm cảnh báo "chỉ lưu trên máy".
- Khách: lưu hồ sơ, gửi góp ý, xác nhận đã nhận hàng, báo chưa nhận, gửi yêu cầu hủy/hoàn tiền, hủy đơn. Thông báo "Đã hủy… được hoàn tiền" chỉ hiện khi đã đồng bộ máy chủ.
- Đặt hàng khi ngoại tuyến: có hộp thoại "Đơn mới lưu trên máy — chưa gửi tới gian hàng, chưa trừ tiền, chưa có tài xế".
- Tài xế: hoàn tất giao hàng, lưu hồ sơ, đổi ảnh đại diện (không còn hiện "✓ Đã lưu" khi máy chủ báo lỗi hoặc mới lưu trên máy).
- Gian hàng: lưu hồ sơ/giờ hoạt động/giấy tờ.

## Chưa xử lý (cần làm tiếp)
- Một số công tắc nhỏ (Online/Sẵn sàng của tài xế, mở cửa/nhận đơn của gian hàng) và trang đánh giá vẫn dùng `GhiAsync` mà chưa hoàn tác khi lỗi.
- Chưa có hàng đợi đồng bộ: dữ liệu ghi khi ngoại tuyến vẫn chỉ nằm trên máy, không tự gửi lên khi có mạng lại.
- Chưa chuyển sang EF Core Migrations: mới chỉ phát hiện schema lệch và dừng/cảnh báo, việc nâng cấp vẫn bằng `FoodService_NangCap.sql`.
- Chưa build/chạy thử (không có .NET SDK/SQL Server ở nơi sửa): cần `dotnet build` cho Web và MAUI, rồi chạy thử file SQL trên CSDL thử nghiệm (cả trường hợp CSDL đã tồn tại và chưa tồn tại).
