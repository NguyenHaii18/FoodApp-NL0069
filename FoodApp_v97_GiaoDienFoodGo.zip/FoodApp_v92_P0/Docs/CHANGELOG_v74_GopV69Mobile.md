# v74 — Gộp chức năng mobile của v69 (tài khoản) vào v73
Chưa build/chạy (không có .NET SDK) — cần Build trên máy. Không cần SQL mới.

- v73 đã có sẵn từ v68: gợi ý món cá nhân hóa, chọn tài xế theo điểm, admin mobile (FAQ, khoản phải trả, hợp đồng–hoa hồng…) → không gộp lại.
- Đã gộp thêm (từ v69 "Đăng ký, đăng nhập và tài khoản"): đăng ký/đăng nhập bằng email hoặc SĐT, OTP SMS, phiên đăng nhập theo thiết bị, khóa tài khoản, điều khoản & quyền riêng tư (xem `CHANGELOG_v69_TaiKhoan.md`).
- Gộp bằng patch từ v67 → bản v69 của mình lên v73; các hunk đã có sẵn tự bỏ qua, không có xung đột. Docs của v73 (`CHANGELOG_v69_ThuNhapDoiSoat.md`) giữ nguyên.
- Chưa gộp: đăng nhập Google/Apple.
