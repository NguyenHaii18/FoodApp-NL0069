# Chức năng 02 — Quản lý đơn hàng & giao hàng / Quản lý khuyến mãi (app mobile)

## Quản lý đơn hàng và giao hàng
| Yêu cầu | Trạng thái | Ở đâu |
|---|---|---|
| Tiếp nhận, xác nhận đơn | Đã có | Gian hàng: *Đơn hàng* (Xác nhận / Từ chối kèm lý do, chọn thời gian chuẩn bị) |
| Theo dõi trạng thái từ đặt đến giao thành công | Đã có | Khách: *Đơn hàng*; Gian hàng: bộ lọc trạng thái + tiến độ chuẩn bị/tài xế; Admin: *Đơn hàng* → chi tiết (dòng thời gian), *Điều phối* |
| Quản lý thanh toán | Đã có | Gian hàng: *Tài chính* (đối soát); Admin: *Thanh toán & hoàn tiền* |
| **Thông tin đơn đầy đủ cho quán** | **Mới (v48)** | Thẻ đơn hiện khách + SĐT, hình thức/trạng thái thanh toán, mã giảm giá và phí giao, ghi chú từng món |
| **Hủy đơn đã nhận (trước khi tài xế lấy hàng)** | **Mới (v48)** | Nút "Hủy đơn (hết món / sự cố)" với lý do bắt buộc; đơn đã trả online tự tạo yêu cầu hoàn tiền |
| **Xử lý yêu cầu hủy của khách** | **Mới (v48)** | Gian hàng → *Hủy & hoàn tiền* → tab *Yêu cầu hủy*: Đồng ý hủy / Từ chối kèm lý do (khách được thông báo; từ chối thì Quản trị quyết định cuối) |
| **Theo dõi hoàn tiền của đơn quán** | **Mới (v48)** | Cùng trang, tab *Hoàn tiền* (quán chỉ xem) |
| Duyệt hoàn tiền theo quy định | Đã có | Admin: *Thanh toán & hoàn tiền* (ngưỡng Quản lý / Admin tổng) |

Quy tắc hủy (server, `TrangThaiDon`): khách tự hủy khi *Chờ xác nhận*; quán hủy được khi *Chờ xác nhận* hoặc *Đã xác nhận (chưa lấy hàng)*; đang giao do Quản trị xử lý.

## Quản lý khuyến mãi
Đã đủ trên app, không đổi: tạo/sửa/xóa/bật-tắt, mã code, loại giảm (% / số tiền / giảm phí giao), đơn tối thiểu, giảm tối đa, thời hạn, giới hạn lượt và 1 lần/khách, giới hạn theo món/danh mục; gian hàng tạo mã riêng của quán, Admin tạo mã toàn hệ thống hoặc chỉ cho một số gian hàng; khách nhập mã khi thanh toán và xem ở tab *Ưu đãi*.

## API mới (`MobileApiController`, vai trò GianHang)
`GET gian-hang/{id}/yeu-cau-huy`, `PUT …/yeu-cau-huy/{ma}/dong-y`, `PUT …/yeu-cau-huy/{ma}/tu-choi`, `GET gian-hang/{id}/hoan-tien`. Không cần SQL mới.

Chưa build/chạy thử (không có .NET SDK).
