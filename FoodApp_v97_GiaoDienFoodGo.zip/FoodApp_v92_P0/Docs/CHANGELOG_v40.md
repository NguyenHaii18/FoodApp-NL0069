# v40 — gộp v39 + v38 (Chiến dịch quảng cáo) + Trung tâm vận hành

Chưa build/chạy (không có .NET SDK / SQL Server) — cần build và thử.

## Kết quả đối chiếu hai gói
- `FoodApp_v38_ChienDichQuangCao` **đã nằm trọn trong** `FoodApp_v39`: không có file nào chỉ có ở v38; 16 file khác nhau đều là v39 sửa tiếp trên v38 (tính năng "người giao: quán / shipper ngoài" – `NGUON_GIAO_HANG_v31.md`). Các dòng chỉ có ở v38 là dòng cũ bị v39 thay (điều kiện lọc tài xế, `NguonGiao`…), không phải tính năng bị thiếu. Chiến dịch quảng cáo (`VendorCampaignsPage`, `GOP_CHIEN_DICH_QUANG_CAO.md`, SQL) có sẵn trong v39.
- Nền của bản gộp là v39.

## Đã thêm vào bản gộp (từ v37, chưa có trong v38/v39)
- **Trung tâm vận hành cho quản trị**: máy chủ `Controllers/Api/AdminVanHanhApiController.cs` (`api/admin/van-hanh/*`) + app `AdminVanHanhPage` (mục "Trung tâm vận hành" trong nhóm Vận hành của `AdminHubPage`): cảnh báo hệ thống, theo dõi SLA, phát hiện gian lận, báo cáo lợi nhuận (7/30/90 ngày), đánh giá nghi vấn (trùng nội dung, đăng dồn dập, bị báo cáo) kèm nút ẩn (chỉ SuperAdmin/QuanLy). Ngưỡng SLA: `Don.SlaXacNhanPhut` (10), `Don.SlaTimTaiXePhut` (10), `Don.SlaGiaoPhut` (60). Chi tiết xem `CHANGELOG_v37.md` (mục "Trung tâm vận hành").
- Khóa luận: mục 1.3.1 (d) thêm bảng "Các chức năng quản trị mở rộng" (12 chức năng). Các phần khác của khóa luận giữ nguyên bản v39.

## Không đổi / chưa gộp
- Tính năng của gói v35 mà v39 ghi là chưa gộp (trang Thông báo web cho tài xế, chế độ tối web, theo dõi lượt bấm banner) vẫn chưa gộp.
- Vẫn cần chạy `Database/FoodService_NangCap.sql` cho tính năng người giao của v39.
