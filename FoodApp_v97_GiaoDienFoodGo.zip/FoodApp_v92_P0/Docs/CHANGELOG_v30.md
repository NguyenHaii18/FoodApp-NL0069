# v30 – P0 bảo mật, CRUD khuyến mãi qua API, tài liệu quy trình

Nền: v29. Chưa build/chạy (không có .NET SDK đầy đủ, SQL Server, workload MAUI); chỉ kiểm tra tĩnh.

## Web
- Mới `Controllers/Api/KhuyenMaiQuanLyApiController.cs`: CRUD khuyến mãi cho gian hàng (`api/mobile/gian-hang/khuyen-mai[/{id}[/tinh-trang]]`) và quản trị (`api/mobile/admin/khuyen-mai[...]`). Kiểm tra mã (3–30 ký tự, duy nhất), loại/mức giảm, thời gian, lượt tối đa ≥ lượt đã dùng, món/danh mục thuộc đúng gian hàng; gian hàng chỉ thao tác mã của mình; mã đã có người dùng thì không xóa (chỉ tắt).
- `Program.cs`: ngoài Development, từ chối khởi động nếu còn tài khoản mẫu (mật khẩu demo công khai) đang bật; cho phép tạm bằng `BaoMat__ChoPhepTaiKhoanMau=true`.

## SQL
- `BaoMat_VoHieuHoaTaiKhoanMau.sql`: bổ sung hash `123456` của PHẦN 6/7 và hash quản trị ban đầu (bản cũ bỏ sót nên không khóa được khách/quán/tài xế mẫu).
- Ghi chú bảng `TinNhanDonHang` là bảng thừa (chat dùng `TinNhan`).

## MAUI
- Mới `Services/KhuyenMaiQuanLyService.cs`. `VendorPromotionsPage`, `VendorPromotionEditPage`, `AdminPromotionsPage`, `AdminPromotionEditPage`: tải/lưu/bật-tắt/xóa qua API khi online, hiện lỗi máy chủ; ngoại tuyến giữ nhánh cục bộ cũ.

## Tài liệu
- Mới: `Docs/CAU_HINH_BAO_MAT.md`, `Docs/QUY_TRINH_CSDL.md`, `Docs/KE_HOACH_HOAN_THIEN.md` (trạng thái từng hạng mục P0–P2 + kịch bản thử).
- Sửa mô tả chat (TinNhan) trong API_MOBILE.md (2 bản) và HUONG_DAN_CHAY.txt.
