# v37 – v36 + sửa lỗi build, hoàn thiện phân hệ khách hàng (app) và cập nhật khóa luận

Chưa build/chạy (không có .NET SDK). Đã kiểm tra: XAML hợp lệ, ngoặc C# cân bằng, quét không còn thành viên trùng tên trong cùng một lớp (226 file .cs).

## Sửa lỗi
- **CS0102 "The type 'DonHang' already contains a definition for 'CoHanPhanHoi'"** (MAUI `Models/Models.cs`): thuộc tính hạn phản hồi của tài xế đổi tên thành `CoHanPhanHoiTaiXe` (kèm `DriverHomePage.xaml`). Bản của gian hàng (`CoHanPhanHoi`, `VendorOrdersPage.xaml`) giữ nguyên.

## Phân hệ khách hàng (app) – phần còn thiếu đã thêm
- **Banner quảng cáo hiển thị trong app**: trang chủ khách nạp `GET api/mobile/banner` (banner do quản trị tạo ở v36), hiện dải ngang ảnh + tiêu đề, bấm mở liên kết (liên kết rỗng → trang Ưu đãi); không có banner/lỗi mạng thì giữ banner mặc định.
- **Sắp xếp theo thời gian giao**: thêm "Giao nhanh nhất" trong bộ lọc (thời gian giao của quán + thời gian di chuyển ước tính).
- Các mục còn lại của danh sách A–E đã có sẵn trong v36 (OTP, lịch sử đăng nhập, nhiều địa chỉ, lọc theo giá/sao/khoảng cách, hẹn giờ giao, mã giảm giá, theo dõi đơn, hủy, đặt lại, COD/VNPay, hoàn tiền, đánh giá món + tài xế, khiếu nại).

## Tài liệu
- `KhoaLuan_QuanLyDichVuAnUong_HoanChinh.docx` thay bản cũ, mục 1.3.1 bổ sung: phân hệ khách hàng (A–E) trong nhóm a), tổng hợp phân hệ tài xế (A–D), d) Nhóm chức năng dành cho Quản trị viên (A–E), e) Chức năng dùng chung toàn hệ thống (bảng).
- Chưa cập nhật `KhoaLuan_Slides.pptx`.

## Còn thiếu / chưa làm
- Push notification (FCM) thật, email ngoài OTP, phân trang kết quả tìm kiếm trên app.

## Bổ sung mobile (đợt 2)
- **Phiên hết hạn**: `ApiClient` nhận biết 401 khi đang có token → xóa phiên, báo "Phiên đăng nhập đã hết hạn" và về trang đăng nhập (`ApiClient.PhienHetHan`, xử lý ở `AppShell`); thêm thông báo mặc định cho mã 423 (khóa tạm thời) và 429 (thao tác quá nhanh).
- **Kiểm tra mã đơn khi lấy hàng** (tài xế): bấm "Đã lấy hàng" phải nhập mã đơn trên túi/hóa đơn; gửi `?maDon=` lên server (server đã so khớp; sai mã thì không cho lấy hàng).
- Đã có sẵn trong v36 nên không thêm: trang Đối soát COD (`DriverEarningsPage` + `GET api/mobile/tai-xe/cod`), quyền vị trí trong Cài đặt tài xế, nút "Báo sự cố" (quán chậm, sai/thiếu món…).

## Giao diện app khách hàng (trang chủ, thực đơn/giỏ hàng, đặt món, theo dõi đơn)
Rà bằng đọc mã (chưa chạy trên thiết bị/giả lập), tập trung chế độ tối, chữ bị tràn/cắt và vùng chạm nhỏ.
- **Chế độ tối**: chữ phụ (`TextGrey`), chữ nhấn (`Primary`), nền chip/ô biểu tượng (`PrimarySoft`) và đường kẻ (`BorderColor`) trước đây dùng màu sáng cố định → mờ hoặc chói trên nền tối. Nay dùng `AppThemeBinding` (bản tối: `TextGreyDark`, `PrimaryLight`, `BorderColorDark`). Áp dụng cho `TrangChuPage`, `MenuCartPage`, `PaymentPage`.
- **Trang chủ**: chữ "XANH" của logo sáng hơn ở chế độ tối (trước đó xanh đậm trên nền tối, khó đọc); nhãn khuyến mãi trên thẻ quán có bản tối; tên quán 14sp; biểu tượng chuông/tài khoản/bản đồ có vùng chạm lớn hơn (Padding 6).
- **Thực đơn**: tên món tối đa 2 dòng, mô tả quán ≤ 2 dòng, tên quán 1 dòng (không còn tràn dòng); nút "+" thêm món 42dp (trước 38dp); danh sách món ngang cao 140 (chừa chỗ khi chữ hệ thống lớn); nhãn món màu hổ phách sáng hơn ở chế độ tối.
- **Đặt món**: tên món tối đa 2 dòng; nút −/+ số lượng 34dp (trước 30dp); ô ghi chú cao hơn; thanh "Xác nhận đặt hàng" có nền thẻ theo chủ đề (không còn trong suốt đè lên nội dung); đường kẻ theo chủ đề.
- **Theo dõi đơn** (`OrderTrackingPage`, giao diện dựng bằng mã): hàm `Mau()` theo chủ đề → chip lọc, đường kẻ, thanh tiến trình, chữ phụ đủ tương phản ở chế độ tối.
- **Nút viền** (`OutlineButton` trong `CustomerTheme`): nền trắng cố định → theo chủ đề (ảnh hưởng mọi trang khách dùng nút này).
