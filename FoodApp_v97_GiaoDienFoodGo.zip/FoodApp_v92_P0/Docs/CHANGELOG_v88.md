# v88 — Checklist nghiệm thu (app quản trị)

CHƯA build/chạy thử — chỉ kiểm tra cú pháp. Hãy build trước khi dùng.

- Mobile → Quản trị → Hệ thống → **"Checklist nghiệm thu"** (`AdminNghiemThuPage`): 18 mục (đăng ký/đăng nhập, đặt món & thanh toán, xử lý đơn, duyệt tài xế, phân đơn chống trùng, theo dõi giao hàng, lịch sử trạng thái, hủy & hoàn tiền, quản trị, phân quyền, báo cáo & đối soát, nhật ký & sao lưu, kiểm thử, triển khai staging/production, tài liệu, hỗ trợ & sự cố).
- Hiển thị tiến độ X/18 + thanh tiến độ; chạm một dòng để đánh dấu/bỏ đánh dấu; nút "Đặt lại checklist".
- Trạng thái chỉ lưu trên thiết bị này (không đồng bộ lên máy chủ). Không tự kiểm tra thay bạn — mục nào đạt là do người nghiệm thu đánh dấu.

## Thứ tự ưu tiên phát triển (trong "Lộ trình & đội ngũ")
Thêm khối "Thứ tự ưu tiên phát triển cho FoodApp" gồm 6 mục: Nền tảng Backend & Database (nền tảng bắt buộc), Luồng đặt hàng & xử lý đơn (ưu tiên cao nhất), Hệ thống điều phối tài xế (ưu tiên cao nhất), Thanh toán & đối soát, Quản trị & báo cáo, Kiểm thử & triển khai. Chạm vào mục để mở trang quản trị liên quan (Quy trình hoạt động, Vận hành thông minh, Khoản phải trả, Báo cáo, Checklist nghiệm thu).
