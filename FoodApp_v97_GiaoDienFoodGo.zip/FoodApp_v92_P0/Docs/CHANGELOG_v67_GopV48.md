# v67 — gộp các chức năng nâng cấp của v48 vào phần mobile

Đối chiếu v67 với v48:
- Đã có sẵn (không gộp lại): app Quản trị (API + các trang Admin), chiến dịch quảng cáo (app gian hàng + banner khách), Quản trị điều phối giao hàng, luồng khách hàng (chi tiết món, đặt hàng thành công, thông báo mở đúng đơn/khuyến mãi, đánh giá 3 điểm món/quán/tài xế, Đặt lại thêm món vào giỏ, chuông → Thông báo).
- **Đã gộp thêm (v48, v67 còn thiếu):**
  1. Gian hàng → trang đơn: hiện khách + SĐT, hình thức/trạng thái thanh toán, mã giảm giá + phí giao, ghi chú từng món.
  2. Nút **Hủy đơn (hết món / sự cố)** khi đang chuẩn bị (trước lúc tài xế lấy hàng), lý do bắt buộc, đơn đã trả online tự tạo yêu cầu hoàn tiền.
  3. Trang **Hủy & hoàn tiền** (`VendorCancelRefundPage`): tab *Yêu cầu hủy* (Đồng ý / Từ chối kèm lý do) và tab *Hoàn tiền* (xem); mở từ trang đơn và từ ô trên trang chủ gian hàng.
  4. Server (cần cho app): 4 API `GET gian-hang/{id}/yeu-cau-huy`, `PUT …/dong-y`, `PUT …/tu-choi`, `GET gian-hang/{id}/hoan-tien` trong `MobileApiController`. Không cần SQL mới.

Chưa build/chạy thử (không có .NET SDK): cần Build lại.
