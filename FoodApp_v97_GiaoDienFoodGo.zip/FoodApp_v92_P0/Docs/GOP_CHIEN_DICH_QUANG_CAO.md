# Gộp từ FoodApp-NL0069-main: Chiến dịch quảng cáo

So sánh cho thấy phần app khách hàng trong FoodApp-NL0069-main là bản cũ hơn v38 (mọi chức năng khách đều đã có và đầy đủ hơn ở v38).
Điểm mới duy nhất của gói đó là **chiến dịch quảng cáo theo gian hàng**, đã gộp vào v38:

**CSDL** — bảng `ChienDichQuangCao` (có khóa ngoại, ràng buộc, chỉ mục) đã thêm vào `Database/FoodService_Database.sql` (tạo mới) và `Database/FoodService_NangCap.sql` (nâng cấp CSDL cũ, chạy lặp lại an toàn).

**Web/API**
- Entity `ChienDichQuangCao`, `DbSet` trong `AppDbContext`.
- Trang Web gian hàng: `ChienDichQuangCaoController` + view `Index`/`Form` + mục menu "📣 Quảng cáo".
- `VendorMobileApiController`: `GET/POST/PUT/DELETE api/mobile/gian-hang/{id}/chien-dich` (chỉ gian hàng sở hữu).
- `MobileApiController`: `GET api/mobile/chien-dich?viTri=` (công khai, chỉ chiến dịch đang chạy của quán đã duyệt, đang mở) và `POST api/mobile/chien-dich/{id}/tuong-tac`.

**App MAUI**
- Gian hàng: trang `VendorCampaignsPage` (tạo / xem / xóa chiến dịch) + ô "Chiến dịch quảng cáo" trên trang chủ gian hàng.
- Khách hàng (mới so với gói gốc, gói gốc chưa hiển thị cho khách): chiến dịch có ảnh hiện cùng carousel banner trên trang chủ; chạm vào sẽ ghi nhận tương tác và mở thực đơn của quán.

Chưa biên dịch (không có .NET SDK trong môi trường tạo gói): cần build và chạy thử.
