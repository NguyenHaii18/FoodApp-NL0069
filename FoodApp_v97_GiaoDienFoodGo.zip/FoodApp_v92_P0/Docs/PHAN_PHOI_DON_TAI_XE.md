# v86 — Hệ thống phân phối đơn cho tài xế

Bộ máy nằm ở `Web/.../Services/PhanPhoiDonXuLy.cs` (chạy nền mỗi ~5 giây qua `PhanPhoiNen`). Chỉ hoạt động khi hệ thống ở chế độ **Quản trị điều phối** (`Don.QuanTriDieuPhoi = 1`) và `PhanPhoi.TuDong = 1` (mặc định bật; tắt thì chỉ phân công tay như cũ).

## 1. Quy trình
```
Quán xác nhận đơn ──► lọc tài xế đủ điều kiện ──► xếp hạng ──► ĐỀ NGHỊ cho người tốt nhất (hết hạn sau N giây)
        ▲                                                         │
        │            từ chối / hết hạn / mất kết nối              ▼
        └──── người kế tiếp ◄──────────────────────────  NHẬN → gán nguyên tử → tài xế đến quán → lấy hàng → giao
Hết ứng viên ở vòng 1 → mở rộng bán kính (vòng 2 gấp đôi, vòng 3 không giới hạn) → vẫn không có → báo quản trị + thử lại theo chu kỳ
```

## 2. Bảy điều kiện backend kiểm tra
| Câu hỏi | Cách xác định |
|---|---|
| Tài xế có đang trực tuyến không? | `TrangThai` ≠ `NgoaiTuyen` **và** còn nhịp kết nối (`NhipLuc` ≤ `PhanPhoi.ViTriCuPhut`) |
| Có bật nhận đơn không? | `TrangThai = SanSang` (công tắc "Sẵn sàng nhận đơn"; `TamNghi` bị loại) |
| Có đang vượt giới hạn đơn không? | Đang giữ < `PhanPhoi.ToiDaDon`; chỉ ghép thêm đơn **cùng quán** và **chưa lấy hàng** |
| Khoảng cách tới nhà hàng? | Haversine từ GPS gần nhất tới tọa độ quán (nhịp ≤ N phút); không có tọa độ → ước tính theo khu vực. Giới hạn bởi bán kính của vòng |
| Phương tiện phù hợp? | Xe đạp: đơn ≤ 3 km và ≤ 4 món · xe máy: ≤ `PhanPhoi.SoMonXeMayToiDa` món · ô tô: mọi đơn |
| Bị khóa / tạm ngừng? | Tài khoản khóa, hồ sơ chưa duyệt, hoặc `TamKhoaNhanDenLuc` (bỏ lỡ nhiều đề nghị / hủy nhiều lần) |
| Khu vực có được phép nhận? | Nếu tài xế khai báo `KhuVucHoatDong` thì phải trùng địa chỉ quán hoặc địa chỉ giao; để trống = mọi khu vực |

Thêm: loại người đã từ chối/hủy đơn này, người đang có đề nghị khác chờ, người mất GPS.
**Xếp hạng** (người đủ điều kiện): 45% gần quán · 25% ít đơn đang giữ · 15% điểm đánh giá · 15% tỷ lệ giao thành công 30 ngày; hiển thị kèm thời gian đến quán dự kiến.

Ví dụ trong yêu cầu (5 tài xế quanh quán) — màn hình **Điều phối → Phân tích tài xế** hiển thị đúng dạng bảng này:
`A 1,2 km Online ✔` · `B 0,8 km Offline ✖ (Đang offline)` · `C 2,0 km Online ✔` · `D 1,5 km đang giao 2 đơn → ✔/✖ tùy giới hạn` · `E 3,2 km Online ✔`.

## 3. Các tình huống bắt buộc xử lý
| Tình huống | Cơ chế |
|---|---|
| Không có tài xế phù hợp | Thử vòng 1→3 (mở rộng bán kính); hết vòng báo mọi quản trị (1 lần/10 phút) + ghi `DieuPhoiLog`; sau 60 giây mở lượt tìm mới (người bỏ lỡ được đề nghị lại) |
| Tài xế không phản hồi | Đề nghị hết hạn sau `PhanPhoi.GiayPhanHoi` → người kế tiếp; bỏ lỡ liên tiếp `PhanPhoi.SoLanBoLoToiDa` lần → tạm ngừng đề nghị `PhanPhoi.PhutTamNgung` phút |
| Nhiều tài xế cùng bấm nhận | Mỗi đơn chỉ có **1 đề nghị chờ** (chỉ mục duy nhất có điều kiện) và nhận = `UPDATE … WHERE MaTaiXe IS NULL AND TrangThai='DaXacNhan'`; chỉ một câu lệnh thành công, người còn lại nhận 409 |
| Nhận đơn nhưng không đến quán | Quá `PhanPhoi.PhutDenQuan` mà chưa bấm "Đã đến quán" → thu hồi, đơn tìm người khác, tài xế bị ghi nhận + báo quản trị |
| Tài xế hủy sau khi nhận | `POST …/orders/{id}/huy-nhan` (lý do bắt buộc, chỉ trước khi lấy hàng) → gỡ nguyên tử, loại tài xế đó khỏi đơn, đơn tìm người khác ngay; hủy 3 lần bị tạm ngừng nhận đề nghị |
| Mất GPS hoặc mạng | App gửi nhịp 20 giây/lần (`POST …/nhip`). Mất nhịp/GPS → không được đề nghị mới; đã nhận mà chưa lấy hàng, mất liên lạc > `PhanPhoi.PhutMatLienLac` → thu hồi; **đã lấy hàng thì không thu hồi**, chỉ báo quản trị liên lạc |
| Khách / quán / quản trị hủy đơn | `TrangThaiDon.SauKhiHuyAsync` thu hồi đề nghị đang chờ (tài xế được báo) và giải phóng tài xế đã nhận |

**Nguyên tử:** không đơn nào thuộc hai tài xế vì (1) chiếm đề nghị rồi chiếm đơn bằng UPDATE có điều kiện, (2) quản trị phân công/đổi tay dùng so-sánh-và-thay theo tài xế cũ, (3) chỉ mục duy nhất có điều kiện trong CSDL. Nếu máy chủ dừng giữa hai bước, `SuaDonThieuGiaoHang` bổ sung chuyến giao còn thiếu ở lượt kế.

## 4. Cấu hình (Cấu hình hệ thống → "Phân phối đơn cho tài xế")
`PhanPhoi.TuDong`(1) · `GiayPhanHoi`(30) · `BanKinhKm`(5) · `SoVongToiDa`(3) · `ToiDaDon`(2) · `SoMonXeMayToiDa`(12) · `ViTriCuPhut`(3) · `PhutDenQuan`(15) · `PhutMatLienLac`(8) · `SoLanBoLoToiDa`(3) · `PhutTamNgung`(15)

## 5. API
- Tài xế: `POST api/driver/nhip` · `GET api/driver/de-nghi` · `POST api/driver/de-nghi/{id}/nhan|tu-choi` · `POST api/driver/orders/{id}/huy-nhan` (có bí danh `api/mobile/driver/...` và `api/mobile/tai-xe/...`); sự kiện realtime `DriverOffer`, `DriverOfferEnd`.
- Quản trị: `GET api/mobile/admin/dieu-phoi` (thêm `phanPhoi`, `deNghi`) · `GET …/dieu-phoi/{id}/phan-tich` · `PUT …/dieu-phoi/{id}/tim-lai`.

## 6. App
- Tài xế: `DriverPresenceService` gửi nhịp + nhận đề nghị; `DriverOfferPopupPage` (đếm ngược, Nhận / Từ chối); nút **Hủy nhận đơn** trong chi tiết đơn.
- Quản trị: trang **Điều phối** có 🔍 Phân tích tài xế, 🔄 Tìm lại, hiện đề nghị đang chờ trong từng đơn và menu 🧠 Phân phối (bật/tắt).

## 7. CSDL
`FoodService_NangCap.sql` (và `FoodService_Database.sql`): cột mới của `TaiXe` (vị trí, nhịp, bộ đếm) + bảng `DeNghiGiaoDon` + 2 chỉ mục duy nhất có điều kiện. **Chạy trước khi bật** (nếu quên, `KiemTraSchema` báo thiếu bảng/cột).

## 8. Chưa làm / lưu ý
- Khoảng cách là chim bay (Haversine), chưa dùng đường đi thực; quán chưa có tọa độ thì chỉ ước tính theo khu vực.
- Chưa có tối ưu tuyến nhiều điểm (kiểu bảng Timeline/Route của Parcelizer) — mỗi lần chỉ ghép đơn cùng quán.
- Phân phối chỉ chạy khi `PhanPhoi.TuDong = 1`; mặc định bật nên cần chạy SQL trước. Chưa build/chạy thử (không có .NET SDK).

## 9. Kịch bản thử
1. 3 tài xế online (A gần nhất) → quán xác nhận đơn → A nhận popup 30 giây.
2. A để hết giờ → B nhận đề nghị; log `DeNghiHetHan` → `DeNghi`.
3. B và quản trị cùng thao tác: quản trị phân công cho C bằng tay → đề nghị của B bị thu hồi, B nhận thông báo.
4. Tắt app tài xế đã nhận (chưa lấy hàng) > 8 phút → đơn bị thu hồi và tìm người khác.
5. Tài xế bấm *Hủy nhận đơn* → đơn tìm người khác, tài xế đó không được đề nghị lại.
6. Khách hủy đơn khi A đang xem popup → popup đóng, A nhận thông báo.
