# Trạng thái đơn hàng & quyền theo vai trò (chuẩn thống nhất Web + API + MAUI)

## 1. Vòng đời đơn (DonHang.TrangThai)

| Bước | DonHang.TrangThai | Cờ phụ | GiaoHang.TrangThai | Ai chuyển |
|---|---|---|---|---|
| Chờ xác nhận | `ChoXacNhan` | – | – | Khách đặt |
| Đã xác nhận / chuẩn bị | `DaXacNhan` | `TrangThaiChuanBi` = null → `DangChuanBi` | – | Quán |
| Sẵn sàng giao – chờ tài xế | `DaXacNhan`, `MaTaiXe` null | `TrangThaiChuanBi=SanSangGiao`, `SanSangGiao=1` | – | Quán |
| Tài xế đã nhận, đang đến quán | `DaXacNhan`, `MaTaiXe` có | (tài xế bấm *Đã đến quán* → `ThoiGianDenQuan`; quán bấm *Đã bàn giao* → `QuanBanGiaoLuc`) | `DaNhan` | Tài xế (nhận) |
| Đang giao | `DangGiao` | sinh `MaXacNhanGiao` (4 số, chỉ khách thấy) | `DangGiao` | Tài xế (*Đã lấy hàng*) |
| Hoàn thành | `DaGiao` | khách bấm *Đã nhận hàng* → `KhachXacNhanLuc` | `GiaoThanhCong` | Tài xế (mã 4 số hoặc ảnh) |
| Giao thất bại | `DaHuy` | `LyDoTuChoi` | `GiaoThatBai` (+ `TinhPhiThatBai` nếu lỗi do khách) | Tài xế |
| Hủy | `DaHuy` | `LyDoTuChoi` bắt buộc | (đóng `GiaoHang` nếu đã có tài xế, giải phóng tài xế) | Khách / Quán / Quản trị |

Quy tắc chuyển hợp lệ: `ChoXacNhan → DaXacNhan | DaHuy`; `DaXacNhan → DangGiao | DaHuy`; `DangGiao → DaGiao | DaHuy(thất bại)`. Trạng thái cuối (`DaGiao`, `DaHuy`) không đi tiếp.
Mọi thay đổi trạng thái đều ghi `LichSuTrangThaiDon`; mọi bước giao ghi `LichSuGiaoHang`; mọi thay đổi thanh toán ghi `GiaoDichThanhToan`.
"Tài xế đang có chuyến" = có đơn `MaTaiXe` = mình và `TrangThai ∈ {DaXacNhan, DangGiao}`; trạng thái tài xế tự về `SanSang` khi hết chuyến (cả khi đơn bị hủy giữa chừng).

## 2. Quyền theo vai trò

| Hành động | Khách | Quán | Tài xế | Quản trị |
|---|---|---|---|---|
| Đặt đơn, thanh toán | ✔ | – | – | – |
| Hủy đơn | chỉ khi `ChoXacNhan` | `ChoXacNhan`, `DaXacNhan` (kèm lý do) | – | mọi đơn chưa kết thúc (kèm lý do) |
| Xác nhận / từ chối đơn | – | ✔ (từ chối bắt buộc lý do) | – | – |
| Báo chuẩn bị / sẵn sàng / bàn giao | – | ✔ | – | – |
| Nhận đơn | – | – | ✔ (đơn đã xác nhận, chưa có tài xế, mỗi lúc 1 chuyến) | phân công / đổi / gỡ tài xế (có lý do) |
| Đến quán, đã lấy hàng, hoàn thành, giao thất bại, gửi vị trí | – | – | ✔ (chỉ đơn của mình) | – |
| Xem mã xác nhận giao | ✔ (chỉ đơn của mình) | ✘ | ✘ | mở khóa/đổi mã khi bị khóa |
| Xác nhận đã nhận hàng / báo chưa nhận | ✔ | – | – | xử lý khiếu nại |
| Đánh giá (1 lần/đơn đã giao) | ✔ | trả lời đánh giá | – | ẩn/duyệt đánh giá |
| Xác nhận chuyển khoản, đối soát, duyệt hoàn tiền | – | – | – | ✔ (hoàn tiền: ngưỡng theo cấp; SuperAdmin không giới hạn) |

Server luôn kiểm tra lại quyền (JWT role + sở hữu đơn); app chỉ ẩn nút.
