# v45 — Đơn đặt hàng chuyển lên Quản trị để điều phối giao hàng

## Luồng mới (mặc định)
1. Khách đặt đơn → quán xác nhận (`DaXacNhan`) và chuẩn bị món.
2. **Ngay khi quán xác nhận**, hệ thống báo mọi quản trị viên đang hoạt động ("Đơn mới cần điều phối"); khi quán báo *Sẵn sàng giao* có thêm thông báo khẩn ("Đơn sẵn sàng, cần phân công tài xế").
3. Đơn xuất hiện ở **Điều phối → Đơn cần giao** (Web `QuanTri/DieuPhoi` và app admin), đơn quán đã báo sẵn sàng được xếp lên đầu, có nhãn "Quán đang chuẩn bị / Quán báo sẵn sàng".
4. Quản trị chọn tài xế và bấm **Phân công** (ô lý do mặc định "Điều phối theo quy trình"). Tài xế nhận thông báo, đơn hiện thành chuyến hiện tại; luồng *đến quán → lấy hàng → mã 4 số → hoàn thành* giữ nguyên.
5. Quá N phút (cấu hình `Don.TaiXePhanHoiPhut`) sau khi quán báo sẵn sàng mà chưa phân công → nhắc quản trị.

## Tài xế
- Hàng chờ chung **đóng**: `DonChoNhan` trả rỗng, `NhanDonAsync` từ chối kèm giải thích; dashboard/app tài xế hiện "Đơn do Quản trị phân công".
- Tài xế của quán (NguonGiao = Quan) không đổi: quán tự gán.

## Công tắc
`Cấu hình hệ thống → Đơn hàng → "Quản trị điều phối giao hàng"` (khóa `Don.QuanTriDieuPhoi`): **1 (mặc định, kể cả khi chưa có dòng cấu hình)** = Quản trị phân công; **0** = quay lại hàng chờ chung cho tài xế tự nhận. Quản trị luôn phân công thủ công được ở cả hai chế độ.

## File đã sửa
- `Services/GiaoHangXuLy.cs` (QuanTriDieuPhoiAsync, BaoQuanTriDonCanDieuPhoiAsync, DonChoNhan, NhanDonAsync, ThongBaoDonMoiAsync, XuLyQuaHan…), `Services/NguonGiaoXuLy.cs`, `Services/ChinhSachMeta.cs`
- `Controllers/DonHangController.cs` và `Controllers/Api/MobileApiController.cs` (báo quản trị khi quán xác nhận)
- `Controllers/AdminDieuPhoiController.cs` + `Views/AdminDieuPhoi/Index.cshtml`, `Controllers/Api/AdminMobileApiController.cs` (`dieu-phoi` thêm `quanTriDieuPhoi`, `sanSangGiao`, `quanTuGiao`)
- `Controllers/DriverDashboardController.cs` + view; chuỗi hiển thị ở `DonHang/Index`, `CustomerOrder/ChiTiet`, `ChinhSach/Index`
- App MAUI: `Views/AdminPages.cs` (trang Điều phối), `Models/Models.cs`, `Views/DriverHomePage.xaml.cs`
- Không cần chạy SQL mới (dùng bảng `CauHinhHeThong`).

## Kịch bản thử (chưa chạy)
1. Khách đặt → quán Xác nhận → admin nhận thông báo; đơn có ở Điều phối.
2. Tài xế ngoài gọi nhận đơn đó → bị từ chối; danh sách đơn chờ của tài xế rỗng.
3. Admin phân công → tài xế nhận thông báo, thấy chuyến hiện tại; hoàn tất giao như cũ.
4. Đặt `Don.QuanTriDieuPhoi = 0` → đơn mới vào hàng chờ chung, tài xế tự nhận được.
