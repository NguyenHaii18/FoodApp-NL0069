# v87 — Lộ trình 12 giai đoạn & đội ngũ (app quản trị)

CHƯA build/chạy thử trong môi trường làm việc — chỉ kiểm tra cú pháp. Hãy build trước khi dùng.

- Mobile → Quản trị → Hệ thống → **"Lộ trình & đội ngũ"** (`AdminLoTrinhPage`):
  - 12 giai đoạn (Khảo sát → Vận hành): công việc, sản phẩm bàn giao, và phần tương ứng trong hệ thống. Chạm để đổi trạng thái Chưa bắt đầu / Đang làm / Hoàn thành; có tổng quan tiến độ.
  - 9 vai trò (Project Manager, BA, UI/UX, Backend, Mobile, Web, QA, DevOps, Business Operations): chạm để ghi người phụ trách.
  - Tiến độ và tên người phụ trách **chỉ lưu trên thiết bị này** (không đồng bộ lên máy chủ).
