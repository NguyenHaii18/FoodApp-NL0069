# v58 – v57 + rà soát luồng tài xế (8 luồng) và 1 chỗ bổ sung

Nền: FoodApp_v57. v57 đã có đủ 8 luồng trong yêu cầu (xem `CHANGELOG_v57_LienKetTaiXe.md`), nên v58 không viết lại.
Chưa build/chạy (không có .NET SDK). Đã kiểm tra tĩnh toàn bộ trang MAUI: XAML hợp lệ, handler khớp code-behind, mọi route điều hướng đã đăng ký, ngoặc cân bằng.

## Đối chiếu
1. Dashboard → danh sách đơn có thể nhận: mục "Đơn hàng sẵn sàng nhận" trên Trang chủ — có.
2. Danh sách → chi tiết đơn → nhận đơn: `DriverOfferDetailPage` (nhận/từ chối thực hiện qua `DriverHomePage.HanhDongCho`) — có.
3. Chi tiết đơn → bản đồ đến quán: nút 🗺️ Bản đồ trong `DriverOfferDetailPage`; Chỉ đường Google Maps ở màn Chuyến đang làm — có.
4. Lấy món thành công → bản đồ đến khách: hộp thoại "Mở bản đồ đến địa chỉ giao" sau "Đã lấy hàng" — có.
5. Đang giao → gọi/chat khách → xác nhận giao (mã 4 số / ảnh bằng chứng, thu COD) — có.
6. Giao thất bại → nhập lý do → gửi yêu cầu hỗ trợ — có; **v58 bổ sung**: lý do vừa nhập được điền sẵn vào ô mô tả của `DriverSuCoPage` (tham số `mota`), loại sự cố chọn sẵn theo lý do.
7. Thu nhập → chi tiết giao dịch → đối soát COD: chạm dòng lịch sử → `DriverOrderDetailPage`; `DriverCodPage` (cần nộp, đã nộp 30 ngày, đơn chưa đối soát, báo sai lệch COD) — có.
8. Hồ sơ → phương tiện, giấy tờ, trạng thái hoạt động: có (khối "Trạng thái hoạt động").

## Hạn chế còn lại (không đổi)
- Chi tiết giao dịch và đối soát COD cần kết nối máy chủ (offline báo lỗi); tài xế không tự đánh dấu "đã nộp COD" — quản trị xác nhận trên hệ thống.
- Chi tiết giao dịch hiện chỉ có phí giao của đơn, chưa tách phụ cấp/thưởng theo từng đơn.
