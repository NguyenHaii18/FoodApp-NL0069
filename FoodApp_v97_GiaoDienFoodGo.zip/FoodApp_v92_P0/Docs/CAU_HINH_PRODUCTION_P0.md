# Cấu hình Production — xử lý 10 thiếu sót P0 (v92)

> Chưa build/chạy thử trong môi trường soạn (không có .NET/SQL Server). Cần `dotnet build` + chạy thử luồng upload/xem giấy tờ trước khi phát hành.

| # | Thiếu sót | Cách đã xử lý |
|---|---|---|
| 1 | Dữ liệu mẫu tự nạp khi API ngoại tuyến | `App.KhoiTaoAsync` chỉ nạp mẫu khi `AppSettings.DuocDungDuLieuMau` (= Development). Staging/Production: hiện trống + ghi log. |
| 2 | Chế độ Production / URL | Bản **Release không bao giờ chạy Development** (ép thành Production). Production/Staging chỉ dùng `BaseUrlProduction`/`BaseUrlStaging` (phải `https://`); rỗng → không gọi mạng, **không rơi về localhost**. Địa chỉ tự nhập ở Cài đặt bị bỏ qua ngoài Development. |
| 3 | OTP SMS | `OtpService` gửi SMS qua cổng HTTP cấu hình được (`Sms__*`). Xem mục bên dưới. |
| 4 | OTP demo | Server: `HienMaDev` chỉ có tác dụng ở Development (đã có) và Production **từ chối khởi động** nếu bật. App: không hiện `maDev`, không tự sinh OTP trên máy ngoài Development. Mã OTP không ghi vào log ngoài Development. |
| 5 | Giấy tờ cá nhân trong wwwroot | GPLX, giấy phép KD, ATTP lưu ở `App_Data/private/{giayto,taixe-giayto}` (ngoài wwwroot). URL dạng `/files/private/...`, chỉ tải được bởi Quản trị, chủ sở hữu (Cookie/JWT) hoặc liên kết ký 5 phút (`POST /api/files/link`). `/uploads/giayto*` bị chặn 404. File cũ tự được chuyển sang kho riêng khi khởi động. |
| 6 | Kiểm tra file tải lên | Kiểm tra **chữ ký nội dung** (JPEG/PNG/WebP, PDF chỉ cho tài liệu riêng tư), đuôi file lấy theo định dạng thật, tên ngẫu nhiên, chặn tên thư mục lạ, giới hạn 5MB. |
| 7 | HTTP không mã hóa (Android) | `usesCleartextTraffic=false` + `network_security_config.xml`: chỉ cho HTTP tới `10.0.2.2`/`localhost` (emulator). |
| 8 | Tài khoản `sa` | Docker Compose dùng tài khoản riêng (`FOOD_DB_USER`, mặc định `foodapp`) do dịch vụ `db-init` tạo (`deploy/sql-tao-tai-khoan-ung-dung.sql`, chỉ `db_owner` trên CSDL ứng dụng). Production **từ chối khởi động** nếu chuỗi kết nối dùng `sa`. |
| 9 | TrustServerCertificate | Compose dùng `Encrypt=False` trong mạng nội bộ Docker (không mở cổng SQL). SQL từ xa: `Encrypt=True;TrustServerCertificate=False`; Production từ chối `TrustServerCertificate=True` với máy chủ từ xa. |
| 10 | Khóa tích hợp | Production từ chối khởi động nếu `VnPay:TmnCode/HashSecret`, `GoongMaps:ApiKey` còn giá trị mẫu (`DIEN_…`). Chỉ chạy COD / chưa dùng Goong: đặt biến rỗng (`GoongMaps__ApiKey=`) để bỏ qua. |

## Việc BẠN phải làm (không thể làm thay trong mã)
1. Điền bí mật thật qua biến môi trường / secret store: `Jwt__Key`, `VnPay__*`, `GoongMaps__ApiKey`, `Smtp__*`, `Sms__*`, `FOOD_DB_PASSWORD` (≥ 12 ký tự, **tránh ký tự `;` và `=`** trong chuỗi kết nối).
2. Điền `BaseUrlProduction` (https) trong `Mobile_FoodApp.Maui/Resources/Raw/appsettings.json` trước khi build Release; đặt `MoiTruong` = `Production`.
3. Đăng ký nhà cung cấp SMS và điền `Sms__Endpoint` + khóa.
4. Chứng chỉ HTTPS (Nginx/Let's Encrypt) cho tên miền máy chủ.
5. Sao lưu cả thư mục `App_Data/private` (script `deploy/sao-luu.sh` đã thêm) và giới hạn quyền (chỉ tài khoản chạy ứng dụng đọc được).

## SMS OTP — ví dụ cấu hình
```
Sms__Endpoint=https://api.nha-cung-cap.vn/sms/send
Sms__Method=POST
Sms__ContentType=application/json
Sms__AuthHeader=Authorization
Sms__AuthValue=Bearer <API_KEY>
Sms__Brand=FoodApp
Sms__BodyTemplate={"to":"{to84}","content":"{message}"}
```
Chỗ giữ chỗ: `{to}` (0909…), `{to84}` (84909…), `{message}`, `{brand}`. Phản hồi 2xx = đã gửi. Mỗi nhà cung cấp (eSMS, SpeedSMS, Twilio…) có định dạng riêng — chỉnh `BodyTemplate`/`ContentType` theo tài liệu của họ. Với `application/x-www-form-urlencoded` đặt `BodyTemplate` kiểu `phone={to84}&content={message}`.

## Truy cập giấy tờ riêng tư
- Web (Cookie): các liên kết "Xem ảnh GPLX", "Giấy phép KD" trong trang quản trị/hồ sơ vẫn hoạt động vì tải qua `/files/private/...` với phiên đăng nhập.
- App: gọi `POST /api/files/link` với `{ "url": "/files/private/..." }` (JWT) để nhận URL có thời hạn 5 phút, rồi mở/tải ảnh.
- App tài xế tải GPLX lên `POST /api/upload/giayto-taixe`; gian hàng dùng `POST /api/upload/giayto-gianhang`.

## Còn lại / giới hạn
- Dữ liệu mẫu trong app mobile chỉ bị chặn ở các điểm nạp đã biết (App.KhoiTaoAsync, OTP); chưa rà từng màn hình để chắc không còn dữ liệu giả nào khác.
- Chưa quét virus/ClamAV cho file tải lên (chỉ kiểm tra chữ ký định dạng, không kiểm tra mã độc nhúng).
- Chưa làm: xoay vòng khóa, WAF/rate-limit riêng cho `/files`, mã hóa file nghỉ (at-rest).
