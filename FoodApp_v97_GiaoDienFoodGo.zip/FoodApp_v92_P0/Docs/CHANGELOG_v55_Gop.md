# v55 — Gộp "v47f (nhánh Admin mobile)" và "main" vào v54

## Nền
- **v54** (thư mục gốc trong file zip là `FoodApp_v50`) là bản mới nhất, kế thừa v47e.
- **v47f (nhánh Admin mobile)** = v47e + phần bổ sung "IV. Quản trị viên" (không cùng tên với `CHANGELOG_v47f_GopV46.md` của nhánh v54 — đó là bản khác).
- **main** (`FoodApp-NL0069-main`) là ảnh chụp cũ của repo: code ngắn hơn v54 ở hầu hết file (vd. `AdminHomePage.xaml` 157 dòng so với 289; `PaymentController` chưa kiểm tra chủ đơn / số tiền phía server). Phần duy nhất main có mà v54 không có là các script SQL rời `NangCap_v8…v16`, `01_TaoMoi_Full.sql`, `SQL/Script.sql` và `README.md` — nội dung đã được gộp sẵn trong `FoodService_Database.sql` / `FoodService_NangCap.sql` của v54.
  → **Không gộp file nào từ main** (gộp sẽ ghi đè bản mới bằng bản cũ).

## Đã gộp từ v47f vào v54 (patch áp sạch, không xung đột)
- Server: `AdminMobileNoiDungApiController` (banner, FAQ, khoản phải trả quán/tài xế, tra cứu khách, hợp đồng & hoa hồng quán, FAQ công khai); `bao-cao` thêm `gmv`, `thoiGianGiaoTrungBinhPhut`; `DonHang.QuanDaTraLuc`; entity `CauHoiThuongGap`; web `MuaHang/HoTro` đọc FAQ từ CSDL.
- SQL: bảng `CauHoiThuongGap` và cột `DonHang.QuanDaTraLuc` ở cả 2 file SQL (chạy lặp lại an toàn).
- Mobile: `AdminPages4.cs` (Banner, FAQ, Khoản phải trả, Tra cứu khách, Đơn của khách, Hợp đồng quán), `FaqPage.cs` + mục trong Hồ sơ khách, route, menu Quản lý, nhãn GMV / doanh thu nền tảng.
- Chi tiết: `CHANGELOG_v55_AdminMobile.md`.

Chưa build/chạy (không có .NET SDK, SQL Server). Sau khi giải nén: build lại, chạy `FoodService_NangCap.sql`.
