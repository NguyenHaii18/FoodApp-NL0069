# v48 – sửa script SQL + bổ sung endpoint mobile (nền: v47e)

## 1. Sửa phần SQL (lỗi bạn gửi)
Các lỗi `Invalid column name 'MaDonHang' / 'TrangThai' / 'MaTaiXe' / 'MaXacNhanGiao' / 'SoLanSaiMa'`, `Invalid column name 'servicename' / 'status_desc'`,
`Invalid object name 'msdb.dbo.sysjobs'`, `Could not find stored procedure 'msdb.dbo.sp_add_job...'` đều là lỗi **biên dịch giả**:
SQL Server vẫn biên dịch toàn bộ lệnh khi dùng `SET NOEXEC ON` (chế độ chặn chạy), hoặc khi đang đứng trong CSDL cũ thiếu cột; trên LocalDB/Express lại không có SQL Agent trong `msdb`.

| File | Sửa |
|---|---|
| `FoodService_NghiemThu_SaoLuu.sql` | Viết lại. **PHẦN A**: kiểm tra CSDL tồn tại và đủ 51 bảng/cột cần thiết (COL_LENGTH), thiếu thì DỪNG kèm danh sách + hướng dẫn chạy `FoodService_NangCap.sql`; các câu kiểm tra chạy bằng SQL động trong đúng CSDL (không `USE`, không NOEXEC). **PHẦN B/C**: bỏ NOEXEC; chỉ chạy khi bật cờ `EXEC sp_set_session_context @key=N'ChayPhanB', @value=1;`; Agent chỉ dùng khi không phải Express/LocalDB, có `msdb.dbo.sysjobs/sp_add_job` và dịch vụ Agent đang chạy; gọi thủ tục msdb qua tên trong biến và `sys.dm_server_services` bằng SQL động. Sửa luôn lỗi dòng tiêu đề nhắc dấu đánh dấu khiến `Tools/NghiemThu_E2E.ps1` cắt nhầm file ngay ở dòng 3 (comment không đóng). |
| `FoodService_Database.sql` | Thêm `USE master` trước chốt an toàn: khi chốt bật NOEXEC (CSDL đã tồn tại), phần còn lại biên dịch ở master nên không còn "Invalid column name" giả do biên dịch trên CSDL cũ. |
| `BaoMat_VoHieuHoaTaiKhoanMau.sql` | Thay `SET NOEXEC ON` bằng `RETURN` (cùng batch); kiểm tra đang ở đúng CSDL. |
| `FoodService_ThemGianHangMau.sql` | Kiểm tra CSDL + cột (`GianHang.Email`, `TaiKhoan.EmailDaXacThuc`...) trước; chèn 10 quán bằng SQL động trong con trỏ (dữ liệu giữ nguyên, chạy lại an toàn). |

Nếu vẫn thấy `Invalid column name` khi chạy `FoodService_NghiemThu_SaoLuu.sql` thì script sẽ dừng và liệt kê đúng cột còn thiếu: CSDL của bạn chưa được nâng cấp → SAO LƯU rồi chạy `FoodService_NangCap.sql`.

## 2. Endpoint mobile (đối chiếu danh sách đề xuất)
Thêm bí danh và endpoint còn thiếu, **không nhân đôi logic**; không có route nào trùng (đã kiểm tra tự động: 250 route, 0 trùng).
Chi tiết bảng đối chiếu: `Web/FoodServiceApp.Web/Docs/API_MOBILE.md` (mục "Đối chiếu danh sách endpoint đề xuất").
- `POST /api/auth/login` (tự nhận vai trò), `POST /api/auth/register[/...]`, `POST /api/auth/otp/{send,verify}`.
- `GET /api/mobile/gian-hang/{id}`, `GET /api/mobile/gian-hang/{id}/mon-an` (mới), `GET /api/mobile/mon-an/{id}`.
- `GET /api/mobile/don-hang`, `GET /api/mobile/don-hang/{id}`, `POST /api/mobile/thanh-toan` (mới), `POST /api/mobile/don-hang/{id}/tin-nhan` (mới).
- `GET|POST /api/mobile/khach-hang/dia-chi` (+ `/{id}/mac-dinh`, `DELETE /{id}`), `GET /api/mobile/khach-hang/ho-so`.
- Tài xế bổ sung vào mobile: `/api/mobile/driver/...` (phản chiếu toàn bộ `/api/driver/...`), tên tiếng Việt `tong-quan`, `bat-tat-san-sang`, `bat-tat-nhan-don`, và `GET /api/mobile/tai-xe/thu-nhap` (mới: đơn nhận/giao/hủy, thu nhập ngày-tuần-tháng, thưởng, COD cần nộp lại, lịch sử).

## Lưu ý
Chưa build/chạy thử (không có .NET SDK và SQL Server ở nơi sửa): cần `dotnet build` và chạy thử các script SQL trên CSDL thử nghiệm, cả trường hợp CSDL cũ thiếu cột và CSDL LocalDB.
"Bổ sung vào mobile" được hiểu là thêm vào nhóm API `/api/mobile/...`; app MAUI chưa được sửa để gọi các đường dẫn mới.
