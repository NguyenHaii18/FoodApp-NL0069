
# v79 — App tài xế
- MỚI "Khu vực có nhu cầu giao hàng" (Tài khoản tài xế): gom đơn đang chờ theo quận/huyện, số đơn, công trung bình, đơn chờ lâu nhất.
- Bật Online: kiểm tra Internet, quyền vị trí và GPS, nhắc nếu thiếu.
- Hiệu suất: thêm số đơn đã nhận / hoàn thành, cảnh báo & lưu ý, hoạt động gần đây, nút gửi phản hồi / khiếu nại.
- Tài khoản tài xế: lối tắt "Gửi phản hồi / khiếu nại".
