# v43 – v42_8 (của bạn) + thời gian chuẩn bị, ảnh bìa quán, món nổi bật do quán đánh dấu

Nền: FoodApp_v42_8 (gồm Chiến dịch quảng cáo, người giao quán/shipper ngoài, Trung tâm vận hành, đổi tên FoodApp + màu tím, quản trị mobile mới, bản đồ, sửa đồng bộ VNPay, tài khoản mẫu bổ sung). Chưa build/chạy (không có .NET SDK/SQL Server).

## Kiểm tra gói v42_8 / 3 file mẫu bạn gửi
- `FoodService_ThemGianHangMau.sql` và `TAI_KHOAN_MAU_BO_SUNG.md`: giống hệt bản đã có trong zip.
- `TAI_KHOAN_GIAN_HANG_MAU.md`: bản trong zip **mới hơn** (có thêm ghi chú đã tích hợp dữ liệu offline gh21–gh30) → giữ bản trong zip.
- SQL 10 gian hàng: cột/giá trị khớp schema (cần `GianHang.Email`, `TaiKhoan.EmailDaXacThuc` từ `FoodService_NangCap.sql`); hash BCrypt đúng mật khẩu 123456; bảng MD khớp SQL từng dòng; không trùng email/SĐT/tên đăng nhập với dữ liệu seed.
- Lưu ý nhỏ: tài xế mẫu `0909888777` dùng mật khẩu `12345`, các tài khoản mẫu khác dùng `123456`.

## Đã gộp (từ v37, v38 của mình; v42_8 chưa có)
- **Thời gian chuẩn bị**: `DonHang.ThoiGianChuanBiPhut`; quán chọn 10–60 phút khi Xác nhận (web, API `xac-nhan` nhận `{chuanBiPhut}`, app); khách thấy ở chi tiết đơn (web) và trang theo dõi đơn (app).
- **Ảnh bìa quán**: `GianHang.AnhBia`; tải ở Hồ sơ (web) và ở hồ sơ gian hàng trên app (`PUT api/mobile/gian-hang/anh-bia`); nền đầu trang quán của khách; API gian hàng trả `anhBia`.
- **Món nổi bật quán đánh dấu**: `MonAn.NoiBat`; tick ở form món (web), món quán ghim hiện đầu mục "Nổi bật" của trang quán. App gian hàng chưa có công tắc (menu app chưa có API ghi).
- Cách gộp: áp bản vá có đối chiếu ngữ cảnh lên v42_8; 2 chỗ không khớp (`Models.cs`, danh sách quán trong `MobileApiController`) đã chèn tay.

**Cần chạy `FoodService_NangCap.sql`** (thêm `DonHang.ThoiGianChuanBiPhut`, `GianHang.AnhBia`, `MonAn.NoiBat`).
