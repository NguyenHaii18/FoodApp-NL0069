# v46 — Giao diện Quản trị "Lighting Food"

Đổi giao diện admin theo mẫu (sidebar tím đậm, thẻ KPI tròn, biểu đồ, bảng đơn gần đây, banner).

## Web (Quản trị)
- `Views/Shared/_AdminLayout.cshtml`: thương hiệu **Lighting Food – Ngon hơn mỗi ngày**; menu gom lại thành 8 nhóm theo mẫu
  (Quản lý gian hàng / món ăn / đơn hàng / khách hàng / tài xế, Khuyến mãi, Báo cáo, Cài đặt hệ thống) — **không bớt chức năng nào**,
  các trang cũ chuyển thành mục con (có số đếm đỏ cho việc chờ xử lý); thanh trên có ô tìm kiếm, chuông, nút toàn màn hình, tài khoản.
- `Views/AdminDashboard/Index.cshtml`: trang **Tổng quan** mới — 4 thẻ KPI, biểu đồ đường doanh thu 7 ngày (SVG), donut trạng thái đơn,
  đơn hàng gần đây, thao tác nhanh, việc cần xử lý, top gian hàng, banner. Phần "Thống kê chi tiết theo kỳ" giữ nguyên bên dưới.
- `Controllers/AdminDashboardController.cs`: thêm `DoanhThu7Ngay`, `TrangThai7Ngay`, `DonGanDay` (dữ liệu thật từ CSDL).
- `wwwroot/css/admin.css` (khối v46 cuối file) và `wwwroot/js/admin.js` (nút toàn màn hình).

## Mobile (MAUI)
- Màn đăng nhập và Tổng quan quản trị đổi nhãn sang **Lighting Food** (bố cục tím đã khớp mẫu từ trước).

## Chưa kiểm chứng
Không có .NET SDK trong môi trường soạn nên chưa biên dịch/chạy. Cần `dotnet build` và mở thử `/QuanTri`.
Các nút "Thêm gian hàng / Thêm món ăn" trong mẫu được thay bằng chức năng thật của admin: Duyệt gian hàng, Kiểm duyệt món ăn.
