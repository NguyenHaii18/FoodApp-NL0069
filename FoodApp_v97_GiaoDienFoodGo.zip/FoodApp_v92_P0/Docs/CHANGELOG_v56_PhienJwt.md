# v56 – v55 + quản lý phiên JWT phía máy chủ (Authentication)

Nền: FoodApp_v55 (bản "gộp v47f Admin mobile vào v54" của bạn). Bản v55 đã có toàn bộ phần của mình đến v50; chỉ thiếu phần dưới đây. Lớp của mình đặt tên `PhienJwt` (không phải `PhienDangNhap`) vì v55 đã có thực thể `PhienDangNhap` (bảng theo dõi phiên đăng nhập web) — hai thứ khác nhau và dùng song song.

Đối chiếu danh sách "Các phân hệ Backend": phần lớn đã có – Authentication (đăng ký/đăng nhập, OTP, khóa tạm khi sai mật khẩu), User/địa chỉ, cửa hàng + thực đơn + giờ hoạt động, món/tùy chọn/tình trạng, giỏ hàng dùng chung Web–app (`CartService`, bảng `GioHang`), đơn hàng với ma trận chuyển trạng thái `TrangThaiDon`, thanh toán VNPay (kiểm chữ ký IPN) + hoàn tiền + đối soát, giao hàng, Goong Maps, khuyến mãi (`KhuyenMaiXuLy`), thông báo trong app và email OTP, đánh giá + kiểm duyệt, báo cáo quản trị.

## Thiếu và đã thêm: quản lý phiên
Trước đây JWT chỉ kiểm chữ ký và hạn (8–12 giờ): tài khoản bị khóa/xóa hoặc vừa đổi mật khẩu vẫn dùng API được tới khi token hết hạn.
- `Services/PhienJwt.cs` + `JwtBearerEvents.OnTokenValidated`: mỗi request kiểm tra tài khoản còn tồn tại, còn hoạt động (`TaiKhoan.TrangThai`) và token chưa bị thu hồi. Trạng thái cache 20 giây (`IMemoryCache`).
- `TaiKhoan.PhienHopLeTu` (UTC): token cấp trước mốc này bị từ chối. Token mới có claim `nbf`.
- Tự thu hồi khi đổi mật khẩu (web và API: 6 chỗ). Sau khi đổi mật khẩu bằng app, lần gọi API kế tiếp trả 401 → app quay về đăng nhập (đây là hành vi mong muốn).
- Endpoint mới `POST api/auth/dang-xuat-tat-ca` (JWT): đăng xuất khỏi mọi thiết bị. App chưa có nút gọi endpoint này.
- Khóa tài khoản bằng quản trị có hiệu lực trong tối đa 20 giây.

**Cần chạy `FoodService_NangCap.sql`** (thêm `TaiKhoan.PhienHopLeTu`). Chưa chạy script thì đăng nhập sẽ lỗi vì thiếu cột.

## Chưa có (cần cấu hình/quyết định)
- Push notification (FCM) và SMS: chưa có nhà cung cấp/khóa cấu hình; thông báo hiện qua trong app + email OTP.
- Tự động phân công tài xế (hiện tài xế tự nhận đơn, quản trị điều phối tay).
- Làm mới token (refresh token): hiện token sống 8–12 giờ rồi đăng nhập lại.

Chưa build/chạy (không có .NET SDK/SQL Server).
