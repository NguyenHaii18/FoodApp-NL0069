# v80 – Màu tối dễ nhìn hơn + chuyển "Thanh toán mặc định" sang Ví
Chưa build (không có .NET SDK).
- Chế độ tối vẫn chủ đạo tím nhưng sáng và tương phản hơn: nền #1C1633 (trước #150F24), thẻ #2B2250 (trước #1F1736), đường kẻ/viền #4D4180 (trước #3A2F58), chữ chính #F8F5FF, chữ phụ #CFC6EA. Đổi đồng bộ ở Colors.xaml và mọi nơi viết tay màu.
- Hồ sơ: bỏ mục "Thanh toán mặc định".
- Ví của tôi: có mục "Thanh toán mặc định" (Tiền mặt / VNPay, dùng chung khóa lưu cũ nên giữ lựa chọn đã có) và nút "Lịch sử thanh toán".

## Bản đồ định vị (bổ sung)
Bản đồ OpenStreetMap (chọn địa chỉ, lấy vị trí hiện tại, theo dõi đơn, lộ trình tài xế) đã có sẵn; v80 thêm điểm vào còn thiếu:
- Đăng ký gian hàng + Hồ sơ cửa hàng: nút "📍 Chọn trên bản đồ / lấy vị trí hiện tại" cạnh ô địa chỉ (máy chủ tự định vị toạ độ từ địa chỉ).
- Sổ địa chỉ của khách: thêm địa chỉ bằng bản đồ hoặc nhập tay.

## Sửa sập app khi mở Bản đồ (Windows)
- BanDoPage: danh sách kết quả tìm kiếm đổi từ CollectionView sang StackLayout (CollectionView trên Windows hay gây NullReferenceException).
- Windows App.xaml.cs: lỗi giao diện không xử lý được ghi vào FoodApp_crash.log rồi bỏ qua (e.Handled) thay vì thoát app.

## Danh sách quán trang chủ
Mỗi quán là một ô vuông (ảnh hoặc biểu tượng + tên quán), chạm vào mở quán. Ô vuông 150×150, kéo ngang để xem thêm; có từ 3 quán trở lên thì xếp 2 hàng.
