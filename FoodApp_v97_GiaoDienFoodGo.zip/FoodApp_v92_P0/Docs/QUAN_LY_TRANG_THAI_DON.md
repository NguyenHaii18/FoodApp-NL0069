# Quản lý trạng thái đơn hàng — quy tắc nghiệp vụ và nơi thực thi (v51)

## 1. Máy trạng thái (nguồn duy nhất: `Services/TrangThaiDon.cs`)
| Từ → Đến | Ai được phép | Điều kiện kèm theo |
|---|---|---|
| ChoXacNhan → DaXacNhan | Gian hàng, Quản trị | Quán xác nhận; tùy chọn thời gian chuẩn bị |
| ChoXacNhan → DaHuy | Khách, Gian hàng, Quản trị | Quán/Quản trị bắt buộc lý do ≥ 5 ký tự; đơn đã trả online → tự tạo yêu cầu hoàn tiền |
| DaXacNhan → DaHuy | Gian hàng, Quản trị | Tài xế đang giữ đơn được giải phóng + báo |
| DaXacNhan → DangGiao | Tài xế được giao | Bấm "Đã lấy hàng"; nếu bật `Don.BatBuocSanSangGiao` thì quán phải báo sẵn sàng trước |
| DangGiao → DaGiao | Tài xế được giao | Bắt buộc đúng mã xác nhận 4 số khách đọc (tối đa 5 lần sai → khóa); đơn không có mã thì bắt buộc ảnh bằng chứng |
| DangGiao → DaHuy | Tài xế (giao thất bại), Quản trị | Server tự phân loại lỗi/phí theo lý do |
| DaGiao, DaHuy | — | Trạng thái cuối, không đổi nữa |

## 2. Lưu người thực hiện, thời điểm, kết quả
* **Thao tác thành công**: mỗi lần đổi trạng thái ghi `LichSuTrangThaiDon` gồm trạng thái cũ → mới, lý do, thời điểm, **người thực hiện (`MaTK`) và vai trò (`VaiTro`: KhachHang/GianHang/TaiXe/QuanTri/HeThong)** — tự động ở `AppDbContext.SaveChangesAsync`, không phụ thuộc controller nào gọi. Tiến trình nền ghi `HeThong`.
* **Thao tác bị từ chối** (chuyển trạng thái ngoài ma trận, sai quyền): ghi Nhật ký hệ thống, nguồn `TrangThaiDon`, mức Cảnh báo — `TrangThaiDon.GhiTuChoiAsync`.
* Giao dịch tiền: `GiaoDichThanhToan` (sổ cái), giao hàng: `LichSuGiaoHang`, điều phối: `DieuPhoiLog`; thao tác quản trị trên app: nhật ký `KiemToan`.

## 3. Các quy tắc bắt buộc → cách hệ thống đảm bảo
| Quy tắc | Thực thi |
|---|---|
| Không cho khách thanh toán đơn đã hủy | Mọi nơi tạo link VNPay (Web, `api/payment`, `api/customer`, `api/mobile`) đều từ chối khi đơn `DaHuy` hoặc đã thanh toán. Nếu khách trả tiền *trong lúc* đơn bị hủy: callback vẫn ghi nhận khoản thu rồi **tự tạo yêu cầu hoàn tiền** (không để mất tiền khách) |
| Không tự đánh dấu giao thành công khi chưa đủ căn cứ | `DaGiao` chỉ được đặt trong `GiaoHangXuLy.HoanThanhAsync`: đơn phải `DangGiao`, phải đúng mã xác nhận (so sánh thời gian hằng) hoặc có ảnh bằng chứng. Không có tiến trình tự động nào đặt `DaGiao` |
| Hai tài xế không cùng nhận một đơn | Nhận đơn dùng cập nhật có điều kiện nguyên tử (`MaTaiXe IS NULL`); CSDL ràng buộc `GiaoHang.MaDonHang UNIQUE`; quản trị phân công có `RowVer` chặn ghi đè (mục dưới) |
| Gửi lặp không trừ tiền / dùng mã giảm giá nhiều lần | Khóa `MaYeuCauDat` (chỉ mục duy nhất) ở **cả Web, `api/mobile` và `api/customer`**: gửi lại cùng khóa trả về đơn cũ; hai yêu cầu song song → yêu cầu sau bị chặn và **trả lại lượt mã** (`KhuyenMaiXuLy.TraLuotAsync`). Lượt mã giữ nguyên tử, không vượt tổng lượt; callback VNPay idempotent theo trạng thái giao dịch |
| Hai người cùng sửa một đơn | `DonHang.RowVer` (rowversion): người ghi sau nhận 409 / thông báo "đơn vừa được cập nhật, tải lại" (`TranhChapDuLieuFilter`) thay vì ghi đè |
| Thanh toán thành công nhưng app chưa nhận phản hồi | (1) VNPay IPN server→server + return đều ghi vào cùng một hàm idempotent; (2) khách bấm **Kiểm tra lại thanh toán** → `POST api/mobile/don-hang/{id}/thanh-toan/kiem-tra-lai` hỏi lại cổng (querydr); (3) **tiến trình nền 5 phút/lần** hỏi lại các giao dịch VNPay còn chờ quá 3 phút (trong 24 giờ); (4) quản trị có nút **Hỏi lại cổng** ở Thanh toán; (5) đơn bị hủy nhưng cổng đã thu → tự hoàn tiền qua quy trình duyệt |

## 4. Hạn chế đã biết
* `querydr` viết theo tài liệu VNPay 2.1.0 (chữ ký yêu cầu/phản hồi); cần thử với sandbox VNPay có TmnCode/HashSecret thật. Chưa cấu hình thật thì chức năng tự bỏ qua, không ảnh hưởng luồng khác.
* Hỏi lại cổng dùng ngày tạo link **gần nhất**; nếu khách tạo link nhiều lần và thanh toán ở lần cũ hơn, cần đối soát tay trên cổng merchant.
* Khóa đồng thời `RowVer` chỉ bảo vệ bảng đơn; các thao tác chỉ chạm bảng khác (VD: sổ giao dịch) dùng các ràng buộc riêng ở trên.
