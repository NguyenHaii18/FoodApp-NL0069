# Cập nhật sau v16 (gộp công việc v18–v21 + MAUI tài xế + tài liệu)

## Database
- FoodService_Database.sql: thêm PHẦN 18c (chạy lại an toàn) đồng bộ v18 (DanhMuc.DaAn, TinNhan.MaClient + chỉ mục duy nhất), v19 (cột tuyến đường DonHang đổi sang FLOAT/INT NULL khớp entity), v21 (cấu hình Don.BatBuocSanSangGiao = 1, Don.BatBuocMaDonKhiLayHang). v20 (ViDo/KinhDo) và bảng TaiXeTuChoiDon đã có sẵn.
- Lưu ý: trước đây file gộp tạo cột KhoangCachKm/KhoangCachThucTeKm dạng DECIMAL NOT NULL, ThoiGianDuKienPhut INT NOT NULL — lệch với entity (double?/int?) nên đọc đơn có thể lỗi; PHẦN 18c đã sửa.
- Bảng TinNhanDonHang (PHẦN 18b) chỉ được nhắc trong API_MOBILE.md, code Web dùng bảng TinNhan.

## MAUI (Mobile_FoodApp.Maui)
- DriverHomePage: nút "Từ chối" nay gọi PUT api/mobile/tai-xe/don-hang/{id}/tu-choi (kèm lý do, có ô nhập "Lý do khác"); chỉ ẩn đơn khi server chấp nhận.
- Mới: DriverMyOrdersPage (4 nhóm đơn: nhan | dang-giao | hoan-thanh | that-bai) và DriverOrderDetailPage (GET tai-xe/don-hang/{id}); nút "Đơn của tôi (n đang thực hiện)" trên trang chủ tài xế; route đăng ký trong AppShell.xaml.cs; DTO ở Models/DonTaiXeDto.cs.
- MauiFix.zip: CrashLog.cs và App.xaml.cs đã trùng bản trong v16; Platforms/Windows/App.xaml.cs của v16 mới hơn (đăng ký bắt lỗi trước InitializeComponent) nên giữ nguyên.
- Chưa làm: ô nhập mã đơn và nút báo sự cố khi lấy món trên MAUI.

## Tài liệu
- Khóa luận: thêm cột ViDo/KinhDo (GianHang), DaAn (danh mục), các cột tuyến đường (DonHang), MaClient (TinNhan); bảng mới TaiXeTuChoiDon (Bảng 3.17a); nguyên tắc giao diện thích ứng (3.3.1); màn hình Đơn của tôi và Chi tiết đơn (Bảng 3.27a); mục 4.3.7 (tìm kiếm, khoảng cách) và 4.3.8 (điều phối, từ chối đơn); cập nhật UC02 và UC14. Cần cập nhật lại mục lục/số trang trong Word (Ctrl+A rồi F9).
- Slides: thêm slide "Cập nhật mới: phiên bản v16 – v21" (slide 13), cập nhật thẻ Tìm kiếm và Hướng phát triển.
