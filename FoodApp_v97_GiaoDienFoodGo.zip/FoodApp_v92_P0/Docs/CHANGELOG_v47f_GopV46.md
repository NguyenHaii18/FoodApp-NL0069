# v47f — gộp phần còn thiếu từ v46 vào v47e

Đối chiếu v47e với toàn bộ phần đã làm trước đó:
- Đã có sẵn trong v47e (không gộp lại): nâng cấp app Quản trị (API `AdminMobileApiController`, các trang Admin), chiến dịch quảng cáo (server, SQL, app gian hàng, banner trang chủ khách), Quản trị điều phối giao hàng (`Don.QuanTriDieuPhoi`), chi tiết món (`MonAnChiTietPage`), đặt hàng thành công (`DatHangThanhCongPage`), thông báo mở đúng đơn / khuyến mãi.

Đã bổ sung (v47e còn thiếu):
1. **Đánh giá 3 điểm**: 🍜 món ăn, 🏪 quán, 🛵 tài xế (`ReviewPage`). Server: cột `DanhGia.SoSaoMon` (SQL chạy lặp lại an toàn ở `FoodService_Database.sql` và `FoodService_NangCap.sql`), API `POST api/mobile/danh-gia` nhận thêm `soSaoQuan` (SoSao = quán; app cũ chỉ gửi một điểm vẫn dùng được).
2. **Đặt lại** (lịch sử đơn): thêm đúng món/số lượng/ghi chú của đơn cũ vào giỏ, bỏ món ngừng bán (có báo), kiểm tra quán đóng cửa, hỏi trước khi thay giỏ, rồi mở giỏ hàng/thanh toán. Trước đây chỉ mở menu quán.
3. **Chuông 🔔 trang chủ** mở Thông báo (trước đây mở Tin tức), số hiển thị = tin chưa xem + thông báo máy chủ chưa đọc.

Chưa build/chạy (không có .NET SDK): cần Build lại.
