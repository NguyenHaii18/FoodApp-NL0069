# v75 — Trang chủ khách: bổ sung chức năng còn thiếu (nền: v74)
Chưa build/chạy (không có .NET SDK) — cần Build trên máy. Không cần SQL/máy chủ mới.

| Yêu cầu Trang chủ | Trạng thái |
|---|---|
| Banner quảng cáo | Có sẵn |
| Khuyến mãi nổi bật | Có sẵn ("Ưu đãi hot") |
| Nhà hàng gần khách | Có sẵn ("Quán gần bạn", lọc/sắp xếp theo khoảng cách) |
| Món phổ biến và bán chạy | MỚI: mục "🔥 Món bán chạy" (số phần đã bán). "Món phổ biến" cũ (nút gợi ý khi tìm kiếm) giữ nguyên |
| Danh mục món ăn | Có sẵn |
| Nhà hàng được đề xuất | MỚI: "🏆 Quán được đề xuất" — chỉ quán đang mở; điểm = đánh giá làm mượt + bán chạy + khuyến mãi + quán bạn từng đặt − khoảng cách, kèm lý do |
| Quán đang mở cửa | MỚI: nút nhanh "🟢 Đang mở cửa" (+ "Gần nhất", "Đánh giá cao") ngay trên danh sách quán |
| Lịch sử tìm kiếm / đặt gần đây | Tìm kiếm có sẵn; MỚI: "🕘 Đặt lại đơn gần đây" (mỗi quán 1 đơn gần nhất, bấm để đưa món vào giỏ, bỏ món đã hết) |
| Gợi ý món theo sở thích | Có sẵn ("Dành riêng cho bạn") |
| Chọn địa chỉ giao hàng ở trang chủ | NÂNG CẤP: chọn từ sổ địa chỉ / dùng vị trí hiện tại (GPS→địa chỉ, có xác nhận) / nhập khác; đồng bộ máy chủ; tính lại khoảng cách |

Các mục mới ẩn khi đang tìm kiếm/lọc. Mã: `Services/TrangChuService.cs`, `Views/TrangChuPage.xaml(.cs)`, `TimKiemService.DonTinhBanChay` đổi sang internal.
Lưu ý: "Đặt lại" chỉ đưa món vào giỏ rồi mở quán (giá hiện hành, không giữ nguyên giá cũ); GPS cần quyền vị trí.
