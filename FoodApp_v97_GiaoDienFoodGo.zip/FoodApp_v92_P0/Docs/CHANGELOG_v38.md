# v38 — Nâng cấp app Quản trị viên (bổ sung các chức năng còn thiếu)

## Đối chiếu 20 nhóm chức năng
| Nhóm | v37 trên app | v38 |
|---|---|---|
| Dashboard | Có (số liệu đã đồng bộ) | + khung **Cần xử lý ngay** (duyệt quán/tài xế, khiếu nại, hoàn tiền, đánh giá bị báo cáo, đơn chưa có tài xế, COD chưa đối soát) |
| Tài khoản | Thiếu | **Mới**: toàn bộ vai trò, tìm kiếm, khóa/mở khóa |
| Khách hàng | Xem, khóa/mở | + **Sửa thông tin** (Admin tổng) |
| Gian hàng | Có | giữ nguyên |
| Tài xế | Chỉ duyệt | **Mới**: danh sách, chi tiết/thống kê, sửa, duyệt/từ chối, khóa/mở |
| Danh mục | Thiếu | **Mới**: đổi tên, ẩn/hiện, xóa (có lý do, báo gian hàng) |
| Món ăn | Thiếu | **Mới**: ẩn món vi phạm / hiện lại |
| Đơn hàng | Thiếu | **Mới**: tìm/lọc (trễ, thất bại, khiếu nại), chi tiết điều tra, hủy can thiệp, mở khóa mã giao |
| Thanh toán | Thiếu | **Mới**: giao dịch, đối soát (từng cái/tất cả), xác nhận chuyển khoản, tóm tắt COD |
| Hoàn tiền | Thiếu | **Mới**: tạo, duyệt (VNPay tự động / thủ công), từ chối; theo ngưỡng Quản lý/Admin tổng |
| Khuyến mãi / Voucher | Có | giữ nguyên |
| Đánh giá | Thiếu | **Mới**: báo cáo vi phạm (ẩn / bác), tất cả đánh giá theo sao |
| Khiếu nại | Có | giữ nguyên (đơn có khiếu nại xem được trong chi tiết đơn) |
| Điều phối tài xế | Thiếu | **Mới**: đơn cần giao, đang giao, tài xế, nhật ký; phân công / đổi / gỡ |
| Báo cáo | Thống kê cơ bản | **Mới**: theo ngày/tháng/năm, KPI, phí nền tảng, tỉ lệ hủy |
| Thống kê | Cơ bản | **Mới**: top quán, top món, khu vực nhiều đơn, theo hình thức thanh toán, top tài xế |
| Cấu hình | Thiếu | **Mới**: sửa phí giao, phí nền tảng, hoàn tiền, thời gian xử lý…; xem lịch sử (Admin tổng) |
| Phân quyền | Offline | **Mới (online)**: thêm tài khoản, đổi cấp, bật/tắt quyền chi tiết |
| Nhật ký | Có | thao tác mới tự ghi vào NhatKyHeThong ở server |

## Kỹ thuật
- Server: `Controllers/Api/AdminMobileApiController.cs` (route `api/mobile/admin/...`), dùng lại đúng logic các trang Web QuanTri. Xem: mọi quản trị viên; ghi: theo quyền chi tiết (DonHang, ThanhToan, HoanTien, DanhGia, ThongBao) hoặc chỉ Admin tổng (tài khoản, cấu hình, phân quyền).
- App: khung `AdminListPage` (tab + tìm kiếm + lọc + nút thao tác) và `AdminUi/J` (dựng UI, đọc JSON); các trang `AdminPages.cs`, `AdminPages2.cs`; trung tâm điều hướng `AdminHubPage`.
- Các màn hình mới cần app **online**; offline hiện thông báo thay vì dữ liệu giả.
- Chưa biên dịch trong môi trường này (không có .NET SDK): hãy build và chạy thử trước khi phát hành.
