# v64 — Khắc phục các hạn chế của v63 (chưa build — cần Build trên máy)

## 1. Quản trị: hiển thị ảnh đánh giá
- `AdminDong` thêm trường `Anh` (mảng địa chỉ ảnh). `AdminListPage` vẽ dải ảnh nhỏ (tối đa 3, 72×72) dưới thẻ; chạm để mở ảnh lớn.
- `Kiểm duyệt đánh giá` đọc `anhDanhGia` (ngăn bởi `|`), đổi thành địa chỉ đầy đủ theo `AppSettings.BaseUrl`, thêm dòng "📷 N ảnh đính kèm".
- Không đổi máy chủ (API `admin/danh-gia` đã trả `anhDanhGia` từ v63).

## 2. Đồng bộ tùy chọn món của quán lên máy chủ
**Server** — `VendorMobileApiController`:
- `PUT api/mobile/gian-hang/{id}/mon-an/{maMon}/tuy-chon`, body `{ tuyChon: [{loai, ten, giaThem}] }`.
- Kiểm tra: đúng quán và đúng món; loại ∈ Size/Topping/MucCay; tên 1–100 ký tự; giá thêm 0–500.000đ; không trùng (loại + tên); tối đa 30 tùy chọn/món.
- Thay toàn bộ danh sách; tùy chọn trùng (loại + tên) giữ nguyên `MaTuyChon`, mục không còn thì xóa, mục mới thì thêm. Trả về danh sách `[{id, loai, ten, giaThem}]`.
- Đường dẫn chứa `/mon-an` nên nhân viên cần quyền `ThucDon` (không phải sửa `QuyenNhanVien`).

**App** — `VendorMenuItemEditPage`:
- Khi sửa món có `Id` là số (món đã có trên máy chủ) và đang online: gọi API trước khi lưu cục bộ; máy chủ từ chối thì báo lỗi và ở lại trang.
- Nhận lại mã tùy chọn từ máy chủ để lưu vào `MonAn.TuyChon`.
- Ngoại tuyến: vẫn lưu trên máy và hiện cảnh báo "chưa gửi lên máy chủ".

## Còn lại / lưu ý
- Món do quán **tạo mới trên app** (Id dạng "ma1"...) vẫn chỉ lưu trên máy vì máy chủ chưa có API tạo/sửa món; tùy chọn của món này chưa lên máy chủ. Cần thêm API tạo/sửa món ở bản sau.
- Nhân viên cửa hàng vẫn cần kết nối máy chủ để đăng nhập (thiết kế có chủ đích: quyền kiểm tra trên máy chủ).
- Không cần chạy thêm SQL.

## 3. Chat khách ↔ tài xế: trạng thái gửi thật (đối chiếu API)
Máy chủ đã có sẵn `ChatApiController` (`GET api/mobile/don-hang/{id}/tin-nhan`, `POST api/mobile/tin-nhan`, `POST api/mobile/don-hang/{id}/tin-nhan`; bảng `TinNhan` + cột `MaClient` chống gửi trùng) và app đã gọi các API này. Lỗ hổng thật: app bỏ qua kết quả gửi nên tin bị mất mạng hoặc bị máy chủ từ chối (đơn hết chuyến → 409, sai quyền → 403) vẫn hiện như đã gửi và không bao giờ gửi lại.
- `TinNhan` thêm `TrangThaiGui` (`DaGui` | `DangCho` | `Loi`) và `LoiGui`; tin cũ mặc định `DaGui`.
- `ChatService.GuiAsync` ghi nhận kết quả thật: thành công → `DaGui`; mất mạng/ngoại tuyến → `DangCho` và tự gửi lại ở lần đồng bộ sau (máy chủ chống trùng theo Id); máy chủ từ chối → `Loi` kèm lý do, không gửi lại.
- `DongBoAsync` gửi lại tin `DangCho`, đánh dấu `DaGui` khi máy chủ đã có tin.
- `ChatPage`: dưới tin của mình hiện "⏳ Chưa gửi — sẽ tự gửi khi có mạng" hoặc "⚠ Không gửi được: …"; vẽ lại khi trạng thái đổi.

## 4. Thanh toán VNPay: đã nối sẵn, không đổi mã
Đối chiếu v63: checkout đã gọi `POST api/mobile/don-hang` (nhận `paymentUrl`), mở cổng VNPay, rồi hỏi máy chủ `GET api/mobile/don-hang/{id}/thanh-toan` (máy chủ ghi kết quả qua return/IPN; số tiền do máy chủ quyết định); "Thanh toán lại" ở tab Đơn hàng xin link mới qua `POST api/mobile/payment/vnpay/tao-url`. Màn thanh toán của khách chỉ có TienMat và VNPay; MoMo/chuyển khoản/ví không còn trong checkout. Cần điền `VnPay:TmnCode`, `VnPay:HashSecret` và `ReturnUrl` công khai thì mới chạy thật.

## 5. Đồng bộ dữ liệu khách: giỏ hàng (đã có) và quán/món yêu thích (mới)
- **Giỏ hàng**: đã đồng bộ máy chủ từ trước (`GET/PUT api/mobile/khach-hang/gio-hang`, có cờ `ChuaDongBo` để đẩy lại sau khi mất mạng) — không đổi.
- **Quán / món yêu thích** trước đây chỉ nằm trong `Preferences` của máy. Nay đồng bộ qua bảng `YeuThich` có sẵn (dùng chung với web):
  - Server: `YeuThichApiController` mới — `GET api/mobile/khach-hang/yeu-thich` → `{gianHang:[id], monAn:[id]}`; `PUT`/`DELETE api/mobile/khach-hang/yeu-thich/{gian-hang|mon-an}/{id}` (idempotent, kiểm tra quán/món tồn tại, tối đa 300 mục).
  - App (`TaiKhoanService`): mỗi lượt thả tim ghi vào bản trên máy và hàng đợi thao tác chưa gửi; online thì gửi lên, lỗi mạng giữ lại gửi sau, máy chủ từ chối thì bỏ. Sau đó kéo danh sách máy chủ về và gộp (thao tác chưa gửi vẫn có hiệu lực). Gọi khi mở trang Yêu thích và khi vào thực đơn quán.
  - Món/quán mẫu ngoại tuyến (Id không phải số) vẫn chỉ ở trên máy.
- Chế độ ngoại tuyến vẫn là chế độ demo: dữ liệu tạo khi offline (đơn, tin nhắn, tùy chọn món mới…) chỉ ở máy đó cho tới khi gửi được lên máy chủ; các màn hình quan trọng đã có cảnh báo riêng.

## 6. Bản đồ & vị trí tài xế
- Luồng có sẵn: tài xế gửi `PUT api/mobile/tai-xe/vi-tri` mỗi 15 giây (lưu CSDL bảng `TaiXeViTri`); bản đồ khách vẽ lại mỗi 10 giây, cảnh báo "mất tín hiệu" khi quá 90 giây.
- Cải tiến v64:
  - `GET api/mobile/don-hang/{id}/vi-tri` nay trả vị trí cả khi tài xế đã nhận đơn và đang đến quán (trước chỉ khi `DangGiao`), thêm `coChuyen`, `trangThai`; `dangGiao` giữ nghĩa cũ.
  - `TheoDoiBanDoPage` mỗi 10 giây chỉ gọi API vị trí nhẹ (`GiaoHangService.TaiViTriTaiXeAsync`) thay vì tải lại cả danh sách đơn; danh sách đơn đầy đủ tải mỗi 30 giây hoặc khi đơn chưa có tài xế / đã hết chuyến.
  - `ViTriTaiXeService` (tài xế): khi ngoại tuyến hiện "chỉ lưu trên máy, khách chưa thấy" thay vì "Đang chia sẻ"; máy chủ trả 404/409 (đơn đã hết chuyến) thì tự dừng chia sẻ.
- **Chưa làm / cần thử trên thiết bị thật**: chia sẻ vị trí hiện chạy bằng bộ hẹn giờ khi app đang mở (quyền `LocationWhenInUse`) nên sẽ dừng khi app xuống nền hoặc khóa màn hình. Muốn chạy nền cần dịch vụ foreground trên Android (quyền `ACCESS_BACKGROUND_LOCATION`, `FOREGROUND_SERVICE_LOCATION`, thông báo thường trực) và chế độ nền trên iOS — phải viết mã nền tảng và thử trên máy thật. Bản đồ cần Internet (Leaflet/OSM, Nominatim); đường thật cần khóa Goong.
