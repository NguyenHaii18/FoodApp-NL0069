# v65 (gói vá) — v64 patch + toàn bộ chức năng v51

Nội dung: 17 file của `FoodApp_v64_patch` (nguyên vẹn, xem `CHANGELOG_v64_KhacPhucHanChe.md`) + chức năng v51 (xem `CHANGELOG_v51.md`, `QUAN_LY_TRANG_THAI_DON.md`).

* File mới của v51 đặt sẵn đúng thư mục (không trùng file nào của v64).
* 20 file v51 sửa: cho dưới dạng bản vá `_GopV51/Diff/*.diff` + script `ap_dung_v51.sh/.ps1` (áp dụng có kiểm tra, không ghi đè thay đổi v52–v63) + bản đầy đủ `_GopV51/Full_v51/`.
* Hướng dẫn và danh sách kiểm tra sau khi gộp: `_GopV51/HUONG_DAN_GOP_V51.md`.
* Không có file nào v64 và v51 cùng sửa → không có xung đột giữa hai bên. Chưa build; chưa thử trên cây v63 thật (chỉ có gói vá v64, không có cây đầy đủ).

---
# Gộp vào cây đầy đủ (v65 hợp nhất)
Cây này = v58 + v59/v60/v61 (đơn nhóm, tự phân công nền, lộ trình đường thật, khóa Goong nhập trong app, kẹt xe theo giờ, bản đồ lộ trình) + gói vá v64 (17 file) + v51 (trạng thái đơn, chống ghi đè, đối soát VNPay).
- Gói vá v64 chép đè nguyên vẹn: các file này đã chứa sẵn chức năng v59/v60 (khác biệt chỉ là phần v64), nên không mất gì.
- 18/20 file v51 áp dụng tự động bằng script; `Program.cs` (filter `TranhChapDuLieuFilter` + `ThanhToanDoiSoatNen`) và `Database/FoodService_NangCap.sql` (mục v51) gộp tay. Thư mục `_GopV51` đã áp dụng xong nên bỏ khỏi cây; `Program.cs` giữ cả `TuDongPhanCongNen` và đoạn nạp khóa Goong.
- App: màn VNPay nay gọi `POST api/mobile/don-hang/{id}/thanh-toan/kiem-tra-lai` khi chưa thấy kết quả (đã trừ tiền mà app chưa báo). `maYeuCauDat` đã được app gửi sẵn.
- CẦN LÀM: chạy mục v51 trong `Database/FoodService_NangCap.sql` (3 cột: DonHang.RowVer, LichSuTrangThaiDon.VaiTro, ThanhToan.NgayTaoLinkCong); Build; nhập khóa Goong trong app. Chưa build, chưa thử trên máy thật.

---
# v66 — Chức năng nâng cao còn thiếu (mục 8)
Chưa build/chạy. Đối chiếu 11 mục: gợi ý món, chọn tài xế, tối ưu lộ trình, ghép đơn, dự báo nhu cầu, phát hiện bất thường, đơn nhóm, hạng thành viên đã có từ các bản trước (luật + thống kê, không phải mô hình học máy). Bản này bổ sung 3 mục còn thiếu:
- **Đặt món theo lịch (nối máy chủ)**: app đã có chọn khung giờ nhưng máy chủ không biết. Nay `POST api/mobile/don-hang` nhận `henGiaoLuc` (phải sau ≥ 30 phút, ≤ 7 ngày), lưu cột `DonHang.HenGiaoLuc`, trả `henGiaoLuc/gioHenGiao` trong danh sách đơn; tự phân công nền chỉ lấy đơn hẹn khi còn ≤ 30 phút; quán thấy nhãn "🕒 Hẹn giao". CẦN chạy SQL mục v66.
- **Chat 3 bên (khách – quán – tài xế)**: `ChatApiController` cho vai trò `GianHang` (chủ quán của đơn); mọi bên của đơn đọc cùng một luồng tin, người gửi lấy từ JWT, thông báo gửi cho các bên còn lại; gửi được khi đơn ở ChoXacNhan/DaXacNhan/DangGiao. App: khách bấm "🏪 Nhắn quán" ở theo dõi đơn; quán bấm "💬 Nhắn khách / tài xế" ở danh sách đơn; mỗi tin ghi rõ người gửi. Nhân viên quán (không phải chủ) chưa được vào chat.
- **Báo cáo kinh doanh nâng cao**: `GET api/mobile/admin/bao-cao-nang-cao?ngay=7|30|90` + trang *Quản trị → Báo cáo kinh doanh nâng cao*: GMV/số đơn/giá trị đơn TB so với kỳ trước, tỷ lệ hủy và lý do, khách quay lại, giờ cao điểm, theo thứ, theo danh mục, quán tăng/giảm mạnh nhất.
- Hạn chế: hạng thành viên mới chỉ hiển thị quyền lợi, chưa tự áp vào giá; gợi ý món là luật theo lịch sử đặt.

---
# v67 — Hỗ trợ · Nội dung · Dashboard · Nhật ký (app quản trị)
Chưa build/chạy. Không cần SQL mới (dùng bảng `CauHinhHeThong` có sẵn).
- **Hỗ trợ — khiếu nại**: đã có từ trước (*Khiếu nại của khách*: tiếp nhận, phân công người xử lý `PUT .../phan-cong`, phân loại, trả lời, chuyển hoàn tiền) — không đổi.
- **Nội dung**:
  - Banner: thêm **Sửa** (tiêu đề, liên kết, thứ tự, ngày bắt đầu/kết thúc) bằng `PUT api/mobile/admin/banner/{id}`; tạo mới cũng nhập được lịch hiển thị (trước đây app không đặt được ngày).
  - **Thông báo trang chủ** (mới): quản trị đặt một dòng chữ nổi bật (≤ 200 ký tự, kèm liên kết tùy chọn) — `GET/PUT api/mobile/admin/trang-chu/thong-bao`, công khai `GET api/mobile/trang-chu/thong-bao`; khách thấy ở đầu trang chủ app, chạm để mở liên kết. Cần quyền `ThongBao`.
  - Danh mục/FAQ/gửi thông báo: giữ nguyên bản cũ.
- **Dashboard** (mới, mục *Vận hành → Dashboard*): `GET api/mobile/admin/dashboard` — doanh thu hôm nay/7 ngày (so kỳ trước), đơn hôm nay/đang xử lý/chưa có tài xế, số khách/nhà hàng đang mở/tài xế sẵn sàng–đang giao, biểu đồ 14 ngày, danh sách việc cần xử lý (chạm để mở màn tương ứng). Số liệu lấy thẳng từ máy chủ.
- **Nhật ký** (`api/mobile/admin/nhat-ky`, chỉ Admin tổng): thêm lọc **Hôm nay / 7 ngày / 30 ngày / Tất cả**, tối đa 500 dòng, hiển thị tên đăng nhập + vai trò thay vì mã số, chạm dòng để xem chi tiết, **Xuất CSV** (ghi lại việc xuất vào nhật ký). Nhật ký vẫn chỉ đọc, không có nút xóa. Máy chủ còn nhận thêm `tuNgay`, `mucDo`, `q` để lọc.
- Lưu ý: nhật ký máy chủ ghi các thao tác ghi dữ liệu và đăng nhập qua `NhatKyThaoTacFilter`; thao tác chỉ đọc không được ghi.
