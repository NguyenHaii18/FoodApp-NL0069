# v80 – Bổ sung chức năng Nhà hàng (Restaurant App)

CHƯA BIÊN DỊCH được trong môi trường làm việc (không có .NET SDK) — chỉ kiểm tra tĩnh. Hãy build trước khi dùng.
**Bắt buộc chạy lại `Database/FoodService_NangCap.sql`** (phần v80 ở cuối, chạy lặp lại an toàn).

## Đã có sẵn từ trước (không làm lại)
Đăng ký/đăng nhập/hồ sơ pháp lý/trạng thái duyệt, nhân viên + quyền, thực đơn + size/topping/mức cay, hết hàng/tạm ngừng, mở cửa/nhận đơn/giờ hoạt động,
xác nhận/từ chối/bắt đầu chế biến/sẵn sàng/bàn giao, khuyến mãi riêng, chiến dịch quảng cáo, doanh thu ngày/tháng/năm, tài chính (phí nền tảng, thực nhận).

## Mới trong v80
| Mục trong danh sách | Nội dung |
|---|---|
| 2. Thời gian chuẩn bị | Mỗi món có "thời gian chuẩn bị (phút)"; khi xác nhận đơn, app gợi ý "theo món" = món lâu nhất |
| 2. Món bán theo khung giờ | Món có "Bán từ – đến"; ngoài giờ server từ chối đặt, app hiện "Ngoài giờ bán" |
| 2. Món ăn kèm | Ô "Món ăn kèm" trong form món |
| 2. Xóa món theo quy tắc | Không xóa món đang nằm trong đơn chưa xong; hướng dẫn chọn "Tạm ngừng bán" |
| 3. Số đơn đang chế biến | Trang chủ quán hiển thị "N đang nấu"; trang "Vận hành quán" có 3 bộ đếm |
| 3. Giờ cao điểm | "Số đơn tối đa cùng lúc" (0 = không giới hạn); đủ ngưỡng thì khách bị chặn đặt (HTTP 409) |
| 3. Âm thanh/thông báo đơn mới | Kiểm tra 30 giây/lần khi mở app: rung + chuông (Android), bật/tắt được |
| 6. Đối soát, báo cáo | Trang "Đối soát & báo cáo": tổng quan 30 ngày, đơn hủy, giá trị TB, phí nền tảng, dự kiến thanh toán, lịch sử theo tháng, món bán chạy, xuất CSV |

Server: `VendorVanHanhApiController` (van-hanh, cau-hinh-cao-diem, mon-an/van-hanh, tai-chinh/mon-ban-chay|doi-soat|xuat-csv).

## Chưa làm / lưu ý
- Giới hạn giờ cao điểm và khung giờ bán chỉ được ép ở máy chủ (chế độ ngoại tuyến demo không chặn).
- Chuông âm thanh chỉ có trên Android; Windows chỉ cập nhật danh sách.
- Món ăn kèm hiện chỉ lưu và hiển thị gợi ý; muốn tính tiền phải nhập thêm vào Topping.
- Phần "Quản trị tài khoản" của admin (phiên đăng nhập, cảnh báo truy cập trái phép) chưa đưa vào bản này.
