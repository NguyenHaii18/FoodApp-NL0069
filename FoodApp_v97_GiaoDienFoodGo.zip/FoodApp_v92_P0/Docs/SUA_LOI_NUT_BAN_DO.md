# Sửa lỗi: bấm biểu tượng bản đồ 🗺️ ở thanh tìm kiếm bị văng

Chưa có nhật ký lỗi nên chưa khẳng định được nguyên nhân duy nhất; đã chặn mọi đường có thể làm app thoát và ghi nguyên nhân thật ra file:

1. **Trang chủ** (`TrangChuPage.OnBanDoTapped`): bọc try/catch (trước đây là `async void` không bắt lỗi — một ngoại lệ khi mở trang là app thoát).
2. **`BanDoPage.MoAsync`**: kiểm tra trước khi mở xem máy có thành phần WebView không (Windows: Edge **WebView2 Runtime**; Android: **Android System WebView**). Thiếu thì hiện hộp thoại và mở **Google Maps** thay vì mở trang bản đồ (nguyên nhân thường gặp làm app thoát hẳn). Mọi lỗi khi điều hướng cũng rơi về Google Maps.
3. **`BanDoPage`**: WebView được tạo bằng mã trong try/catch (`TaoWebView`), không khai báo cứng trong XAML; tạo lỗi thì chỉ báo nhẹ và vẫn dùng được "Mở Google Maps".
4. **Android**: `MainApplication` bắt lỗi chưa xử lý và ghi nhật ký (Windows đã có sẵn từ trước).

## Xem nhật ký lỗi nếu vẫn bị
- Windows: `%LOCALAPPDATA%\FoodApp_crash.log`
- Android: `adb shell run-as <package> cat files/.local/share/FoodApp_crash.log` hoặc `adb logcat | findstr /i FoodApp`
Gửi nội dung file (dòng cuối cùng trước lúc thoát) để xác định đúng nguyên nhân.

Chưa build/chạy thử (không có .NET SDK).
