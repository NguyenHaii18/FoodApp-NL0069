# v31 — Quán chọn giao bằng tài xế của quán hay shipper ngoài

## Khái niệm
| Thuộc tính | Giá trị | Ý nghĩa |
|---|---|---|
| `TaiXe.MaGianHang` | NULL / mã quán | NULL = shipper ngoài (nền tảng); có giá trị = tài xế nội bộ của quán đó |
| `GianHang.CheDoGiao` | `Ngoai` (mặc định) / `Quan` | Cách giao mặc định, áp cho đơn mới **khi quán bấm Xác nhận** |
| `DonHang.NguonGiao` | `Ngoai` / `Quan` | Cách giao của từng đơn; quán đổi được cho tới khi tài xế lấy hàng |

## Quy tắc
- **Shipper ngoài**: đơn vào hàng chờ chung như cũ (quá hạn → điều phối lại + báo quản trị).
- **Tài xế của quán**: đơn **không** vào hàng chờ chung và **không** báo shipper ngoài; quán gán trực tiếp một tài xế của quán (đơn chuyển ngay sang "tài xế đang đến quán").
- Tài xế của quán chỉ giao đơn do quán gán, không thấy/không nhận được đơn ở hàng chờ chung (`NhanDonAsync` từ chối).
- Quán chỉ đổi người giao khi đơn `DaXacNhan` và tài xế chưa bấm "Đã lấy hàng". Shipper ngoài đã nhận rồi thì quán không tự đổi (liên hệ Quản trị).
- Phí giao của đơn nội bộ: `GiaoHang.TrangThaiThuNhap = 'NoiBo'` (nền tảng không trả thu nhập; tiền thuộc về quán).
- Quản trị phân công thủ công: chỉ chọn trong shipper ngoài; tài xế của quán chỉ được gán cho đơn của chính quán.
- Chọn mặc định "Tài xế của quán" bị từ chối nếu quán chưa có tài xế riêng đã duyệt.
- Khóa tài xế của quán bị từ chối khi tài xế còn chuyến đang giao.

## Nơi dùng
- **Web (quán)**: menu **🛵 Tài xế của quán** (thêm/khóa tài xế, cách giao mặc định); trang **Đơn hàng** có ô chọn người giao cho đơn đã xác nhận.
- **API (app MAUI gian hàng)**:
  - `GET api/mobile/gian-hang/tai-xe` · `POST api/mobile/gian-hang/tai-xe` · `PUT api/mobile/gian-hang/tai-xe/{id}/hoat-dong` `{hoatDong}`
  - `PUT api/mobile/gian-hang/che-do-giao` `{che:"Quan"|"Ngoai"}`
  - `PUT api/mobile/don-hang/{id}/nguoi-giao` `{nguon:"Quan"|"Ngoai", maTaiXe?}`
  - Đơn của quán (`GET api/mobile/gian-hang/{id}/don-hang`) có thêm `nguonGiao`, `taiXeLaCuaQuan`.
- **App MAUI**: trang Đơn hàng của gian hàng có nút **🛵 Người giao** (mặc định, thêm/khóa tài xế) và nút **Chọn người giao** trên từng đơn.
- Tài xế của quán đăng nhập **app tài xế** bằng tài khoản quán tạo; luồng giao (đến quán → lấy hàng → mã 4 số → hoàn thành) giữ nguyên.

## CSDL
Chạy `Database/FoodService_NangCap.sql` (idempotent) trên DB cũ; DB mới tạo từ `FoodService_Database.sql` đã có sẵn. Thêm: `TaiXe.MaGianHang` (+FK, index), `GianHang.CheDoGiao`, `DonHang.NguonGiao`.

## Kịch bản thử (chưa chạy trong môi trường soạn code)
1. Quán A thêm tài xế "Tèo" → khách đặt đơn → quán Xác nhận (mặc định Ngoai) → đơn hiện ở hàng chờ tài xế ngoài.
2. Quán đổi đơn đó sang "Tài xế của quán: Tèo" → đơn biến mất khỏi hàng chờ chung; Tèo thấy đơn hiện tại; tài xế ngoài không nhận được.
3. Đặt mặc định "Tài xế của quán" → đơn mới sau Xác nhận có `NguonGiao='Quan'`, không báo tài xế ngoài; quán chọn Tèo → luồng giao hoàn tất.
4. Tèo bấm "Đã lấy hàng" → quán thử đổi người giao → bị từ chối.
5. Tài xế ngoài gọi nhận đơn `Quan` → bị từ chối. Khóa Tèo khi đang giao → bị từ chối.
