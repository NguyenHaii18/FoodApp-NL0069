# Changelog v27 – Chức năng Tài xế (mục 1 & 2)

## 1. Báo sự cố / hỗ trợ trên app MAUI
- **Mới** `Views/DriverSuCoPage` – chọn loại sự cố (tai nạn, món hư, an toàn, khách không liên lạc được, sai địa chỉ, khách không nhận, quán chuẩn bị chậm, không tìm thấy đơn, sai/thiếu món, vấn đề bàn giao, sai lệch thu nhập, sai lệch COD, khác), nhập mô tả, mã đơn; xem danh sách báo cáo kèm trạng thái xử lý và phản hồi của quản trị.
- Lối vào: `DriverProfilePage` (menu "Báo sự cố & hỗ trợ"), `DriverDeliveryDetailPage` (nút "Báo sự cố", tự điền mã đơn), `DriverEarningsPage` (nút "Báo sai lệch thu nhập / COD").
- API mới (`MobileApiController`): `GET tai-xe/su-co` (danh sách loại + báo cáo của tôi), `POST tai-xe/su-co`.
- `DriverDonXuLy.TaoSuCoAsync` dùng chung cho Web và Mobile (kiểm tra loại, mô tả ≥ 5 ký tự, đơn thuộc tài xế; báo quản trị, báo gian hàng với sự cố lấy món). `DriverSuCoController` (web) gọi lại hàm này.

## 2. Hồ sơ tài xế
- **Web** `TaiXe/HoSo`: thêm ảnh đại diện, số CCCD, số GPLX, ảnh GPLX; hiển thị trạng thái hồ sơ (chờ duyệt / được duyệt / bị từ chối), lý do từ chối, yêu cầu bổ sung; kiểm tra SĐT 9–11 số.
- **Web** đăng ký tài xế: thêm CCCD, GPLX, ảnh GPLX.
- **App**: `DriverProfilePage` hiện trạng thái duyệt + lý do, nhập CCCD/GPLX, tải ảnh GPLX; ảnh đại diện được đồng bộ lên máy chủ.
- API: `GET tai-xe/ho-so` (mới), `PUT tai-xe/ho-so` nhận thêm `soCccd`, `soGplx`, `anhGplx`; `POST api/upload/taixe` (mới).
- Đổi CCCD/GPLX/ảnh GPLX → gửi thông báo cho quản trị xem lại (không tự đổi trạng thái duyệt).

## Chưa kiểm chứng
Chưa build/chạy (không có .NET SDK trong môi trường soạn). Đã kiểm tra XAML hợp lệ, cân bằng ngoặc, handler khớp. Cần build và chạy thử trên máy.
