# v35 – v34 (của bạn) + đối soát COD, tranh chấp giao hàng, quyền vị trí tài xế

Nền: v34 của bạn (đã gồm Khách hàng/Gian hàng bổ sung và các mục tài xế 1–5). Gộp ba chiều với v32 làm gốc chung: 17 file chỉ bạn sửa giữ nguyên, 12 file chỉ mình sửa được chép vào, 3 file cả hai cùng sửa (`MobileApiController.cs`, `ViewModels.cs`, `AdminTaiXe/ChiTiet.cshtml`) gộp tự động không xung đột.

## Thêm
- **Đối soát COD**: cột `GiaoHang.CodDaNopLuc` (cả `FoodService_Database.sql` và `FoodService_NangCap.sql`); trang Thu nhập tài xế (web/app) hiện khoản cần nộp lại; quản trị xác nhận đã nhận (chỉ Admin tổng) tại chi tiết tài xế; API `GET api/mobile/tai-xe/cod`.
- Loại sự cố "Tranh chấp giao hàng".
- Cài đặt tài xế (app): trạng thái quyền vị trí + nút "Mở cài đặt".

**Cần chạy `FoodService_NangCap.sql`** trước khi dùng (thêm cột; COD đơn cũ hơn 30 ngày coi như đã nộp).
Chưa build/chạy thử (không có .NET SDK/SQL Server): đã kiểm tra 71 XAML hợp lệ, ngoặc C# cân bằng.
