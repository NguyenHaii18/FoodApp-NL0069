# v69 — Đăng ký, đăng nhập và tài khoản trên mobile (nền: v68)
Chưa build/chạy (không có .NET SDK) — cần Build trên máy. Không cần SQL mới.

| Yêu cầu | Trạng thái |
|---|---|
| Đăng ký bằng SĐT hoặc email | MỚI: đăng ký chỉ cần email HOẶC SĐT; đăng nhập bằng email hoặc SĐT |
| Đăng nhập / đăng xuất | Có sẵn; đăng xuất giờ thu hồi cả phiên ở máy chủ |
| Xác thực OTP | Có sẵn (email); MỚI: OTP qua SMS cho SĐT (sau đăng ký bằng SĐT và trong Bảo mật tài khoản) |
| Đăng nhập Google / Apple | KHÔNG làm (xem ghi chú) |
| Quên / đặt lại / đổi mật khẩu | Có sẵn |
| Cập nhật họ tên, SĐT, email, ảnh đại diện | Có sẵn (Hồ sơ → Thông tin cá nhân) |
| Quản lý phiên đăng nhập | MỚI: Hồ sơ → Bảo mật tài khoản → Phiên đăng nhập (xem thiết bị, đăng xuất từng thiết bị / tất cả thiết bị khác) |
| Yêu cầu khóa tài khoản | MỚI: tự khóa (cần mật khẩu, chặn nếu còn đơn đang xử lý), đăng xuất mọi thiết bị |
| Xóa tài khoản | Có sẵn |
| Điều khoản & quyền riêng tư | MỚI: tick bắt buộc khi đăng ký + trang đọc điều khoản, xem/ghi lại thời điểm đồng ý |

## Server
- `Controllers/Api/TaiKhoanMoRongApiController.cs`: `GET/DELETE tai-khoan/phien`, `POST tai-khoan/phien/dang-xuat-khac`, `POST tai-khoan/yeu-cau-khoa`, `GET dieu-khoan` (công khai), `GET tai-khoan/dieu-khoan`, `POST tai-khoan/dieu-khoan/dong-y`.
- `MobileApiController`: mỗi lần đăng nhập app ghi `PhienDangNhap` (kênh "mobile", tên thiết bị từ header `X-Thiet-Bi`) và gắn claim `MaPhien` vào JWT; đăng ký nhận `dongYDieuKhoan` (bắt buộc true) và email hoặc SĐT; đăng nhập khách nhận email hoặc SĐT.
- `PhienJwt`: token có `MaPhien` bị từ chối khi phiên đã bị thu hồi (cache 20 giây). Token cũ không có claim vẫn dùng bình thường.
## Mobile
- `Views/BaoMatTaiKhoanPages.cs` (BaoMatTaiKhoanPage, PhienDangNhapPage, DieuKhoanPage, PhienMayChu), LoginPage (ô email/SĐT, checkbox điều khoản), ProfilePage (dòng "Bảo mật tài khoản"), OtpService (kênh SMS), ApiClient (header thiết bị), AppShell (3 route).
## Lưu ý
- OTP SMS dùng cơ chế gửi sẵn của máy chủ; nếu chưa cấu hình nhà cung cấp SMS thì chỉ hiện mã dev khi bật `Otp:HienMaDev`.
- Khóa tài khoản là khóa tự nguyện: mở lại qua quản trị viên (web) / hỗ trợ.
- Google/Apple: cần tài khoản nhà phát triển, client ID và xác minh token phía máy chủ; chưa tích hợp (yêu cầu ghi "nếu tích hợp").
- Chỉ áp dụng cho app khách; app gian hàng/tài xế giữ màn hình riêng của họ.
