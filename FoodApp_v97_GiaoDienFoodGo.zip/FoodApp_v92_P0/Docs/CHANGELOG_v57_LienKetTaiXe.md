# v57 — liên kết điều hướng app tài xế (nền v56)

Chưa build/chạy (không có .NET SDK). Đã kiểm tra: XAML hợp lệ, ngoặc C# cân bằng, không có thành viên trùng tên trong cùng lớp (273 file .cs), route mới đã đăng ký trong `AppShell.xaml.cs`.

## Đối chiếu 8 luồng trong yêu cầu
| # | Luồng | Hiện trạng v56 | Xử lý v57 |
|---|---|---|---|
| 1 | Dashboard → Danh sách đơn có thể nhận | Đã có: mục "Đơn hàng sẵn sàng nhận" ngay trên Trang chủ + nút "Nhận đơn mới" (làm mới) | Giữ nguyên |
| 2 | Danh sách đơn → Chi tiết đơn → Nhận đơn | **Thiếu bước chi tiết**: danh sách chỉ có nút "Nhận đơn này/Từ chối", không có trang xem chi tiết trước khi nhận | **Mới** `DriverOfferDetailPage`: chạm vào thẻ đơn → xem tuyến lấy/giao, phí giao, tiền thu hộ, món, hạn phản hồi → Nhận đơn / Từ chối |
| 3 | Chi tiết đơn → Bản đồ đến quán | Đã có ở màn Chuyến đang làm (🗺️ + "Chỉ đường Google Maps") | Thêm nút **🗺️ Bản đồ** (bản đồ trong app) ở trang chi tiết đơn có thể nhận |
| 4 | Lấy món thành công → Bản đồ đến khách | **Thiếu** | Sau "Đã lấy hàng" hiện hộp thoại "Mở bản đồ đến địa chỉ giao?" → `BanDoPage` |
| 5 | Đang giao → Gọi/chat khách → Xác nhận giao | Đã có (📞 Gọi khách, 💬 Nhắn tin, nút hoàn tất giao) | Giữ nguyên |
| 6 | Giao thất bại → Nhập lý do → Gửi yêu cầu hỗ trợ | Có chọn/nhập lý do nhưng **không có bước gửi hỗ trợ** | Sau khi ghi nhận thất bại hỏi "Gửi yêu cầu hỗ trợ?" → mở `DriverSuCoPage` chọn sẵn loại theo lý do (không liên lạc được khách / khách từ chối / sai địa chỉ / sự cố xe / món hư hỏng / tranh chấp giao hàng) và mã đơn |
| 7 | Thu nhập → Chi tiết giao dịch → Đối soát COD | Có mục COD tóm tắt trong Thu nhập, **chưa có chi tiết/đối soát riêng** | Thu nhập: nút "Xem chi tiết đối soát COD" + chạm một dòng lịch sử → `DriverOrderDetailPage` (chi tiết giao dịch); trang chi tiết đơn COD có nút "Đối soát COD"; **mới** `DriverCodPage` (cần nộp / đã nộp 30 ngày / đơn chưa đối soát + Báo sai lệch COD) |
| 8 | Hồ sơ → Phương tiện, giấy tờ, trạng thái hoạt động | Đã có phương tiện, biển số, CCCD, GPLX, trạng thái hồ sơ; **thiếu trạng thái hoạt động** | Thêm khối "Trạng thái hoạt động" (Offline / Online · Sẵn sàng / Tạm không nhận) kèm liên kết về Trang chủ để bật/tắt |

## Thay đổi kỹ thuật
- `DriverHomePage`: tách `NhanDonAsync(DonHang)` và `TuChoiDonAsync(DonHang)` từ hai handler nút (hành vi cũ giữ nguyên) để dùng chung; thêm `DriverHomePage.HanhDongCho` — trang chi tiết đặt "nhan"/"tuchoi" rồi quay lại, Trang chủ thực hiện khi hiện lại.
- Trang mới: `DriverOfferDetailPage`, `DriverCodPage` (dùng `GET api/mobile/tai-xe/cod` và `CodDto` có sẵn).
- Lưu ý: trang chi tiết giao dịch (`DriverOrderDetailPage`) và `DriverCodPage` cần kết nối máy chủ; offline hiện thông báo lỗi.
