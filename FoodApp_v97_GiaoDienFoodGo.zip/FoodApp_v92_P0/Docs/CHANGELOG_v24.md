# FoodApp v24 – Tìm kiếm & thông tin quán trên app MAUI (khách hàng)

Nền: v23. Web (Razor) đã có đủ hai nhóm chức năng này từ v11 nên KHÔNG đổi; v24 bổ sung cho app MAUI.
Chưa được biên dịch thử trong môi trường tạo gói (không có .NET SDK) – build lại và chạy thử trước khi dùng.

## File thay đổi (Mobile_FoodApp.Maui)
- Services/TimKiemService.cs (mới): BoLocTimKiem, QuanKetQua, TimKiemService (tìm/lọc/sắp xếp, lịch sử, gợi ý phổ biến), MonHienThi, ThongTinQuan.
- Views/TrangChuPage.xaml(.cs): thanh tìm kiếm + bộ lọc + sắp xếp + lịch sử + gợi ý + thông báo không có kết quả + thẻ quán đầy đủ thông tin.
- Views/MenuCartPage.xaml(.cs): trang thông tin quán (logo, mô tả, địa chỉ, SĐT, giờ, trạng thái mở/đóng, đánh giá, phí giao, thời gian, khuyến mãi, bán chạy, nổi bật, danh mục, đánh giá + phản hồi của quán).

## Đối chiếu yêu cầu: Tìm kiếm nhà hàng và món ăn
| Yêu cầu | App MAUI (v24) | Web |
|---|---|---|
| Tìm theo tên nhà hàng | Ô tìm kiếm trang chủ (không phân biệt hoa/thường, dấu) | Có |
| Tìm theo tên món ăn | Khớp tên/mô tả món; hiện danh sách "Món khớp" | Có |
| Tìm theo từ khóa | Nhiều từ: mọi từ phải khớp ở tên quán/địa chỉ/mô tả/loại/món/danh mục | Có |
| Tìm theo danh mục món | Picker "Danh mục món ăn" (MonAn.DanhMuc) + từ khóa | Có |
| Tìm theo khu vực, địa chỉ | Ô "Khu vực / địa chỉ" + từ khóa khớp địa chỉ | Có |
| Lọc quán đang mở | Công tắc "Chỉ quán đang mở cửa" (bật mở bán + trong giờ hoạt động) | Có |
| Lọc mức giá | Picker: <30k, 30–60k, 60–100k, >100k (quán có ≥1 món đang bán trong khoảng) | Có |
| Lọc đánh giá sao | Picker ≥3★, ≥4★, ≥4,5★ | Có |
| Lọc loại món | Dãy chip loại món (cơm, gà, bún/phở...) | Có |
| Lọc khoảng cách | Picker ≤2/5/10 km | Có |
| Sắp xếp | Mặc định (đang mở, bán chạy) · Gần nhất · Đánh giá cao · Giá thấp→cao · Giá cao→thấp · Bán chạy | Có |
| Lịch sử tìm kiếm | Lưu khi nhấn Enter (8 từ gần nhất), chạm để tìm lại, "Xóa lịch sử" | Có (cookie) |
| Gợi ý phổ biến | Chip "Món phổ biến" (món đặt nhiều nhất; chưa có đơn thì món đang bán) | Có |
| Thông báo không có kết quả | Khung "Không tìm thấy kết quả cho …" + gợi ý + nút xóa lọc | Có |

## Đối chiếu yêu cầu: Xem thông tin nhà hàng/gian hàng
| Yêu cầu | App MAUI (v24) |
|---|---|
| Tên, ảnh, logo, mô tả | Header (ảnh/logo tròn, tên) + mô tả dưới header |
| Địa chỉ, SĐT, giờ kinh doanh | Thẻ thông tin; chạm số điện thoại để gọi |
| Trạng thái mở/đóng | Thanh màu xanh/vàng/đỏ kèm lý do (ngoài giờ, tạm đóng, tạm dừng nhận đơn); chặn thêm món khi quán không nhận đơn |
| Đánh giá trung bình, số lượt | Tính từ các đánh giá của khách (DanhSachDanhGia) |
| Phí giao, thời gian dự kiến | Ước tính theo địa chỉ giao hàng của khách (GiaoHangService); chưa có địa chỉ thì hiện phí cơ bản |
| Danh mục / danh sách món | Chip danh mục lọc thực đơn; mỗi món có ảnh, mô tả, giá |
| Món nổi bật, bán chạy | Hai dải cuộn ngang; nhãn 🔥/⭐ trên từng món |
| Khuyến mãi của quán | Mã của quán + mã toàn hệ thống đang dùng được; chạm để sao chép mã |
| Phản hồi đánh giá | Danh sách đánh giá gần đây kèm phản hồi của quán |

## Giới hạn đã biết
- Khoảng cách trên app là ƯỚC TÍNH theo quận/huyện nhận ra trong địa chỉ (xem GiaoHangService); địa chỉ không nhận ra thì quán không lọt bộ lọc khoảng cách. Web dùng tọa độ thật.
- "Bán chạy" và "nổi bật" tính từ các đơn đang có trong app (ở chế độ online chỉ gồm đơn của chính người dùng/quán đang đăng nhập); nên nối API thống kê toàn hệ thống nếu cần số liệu chính xác.
- Chưa tìm theo giọng nói; chưa lưu bộ lọc giữa các lần mở app.

## Giao diện trang chủ Admin (Mobile_FoodApp.Maui/Views/AdminHomePage)
- Thiết kế lại theo giao diện "Hệ thống quản trị" mới: thanh trên + avatar, banner chào (ngày giờ, vai trò), thẻ trạng thái hệ thống, 4 thẻ thống kê 2×2, mục "Quản lý hệ thống" gồm 10 ô chức năng có icon màu, nút Đổi mật khẩu / Đăng xuất. Hỗ trợ chế độ nền tối.
- Số liệu mới tính từ dữ liệu thực: doanh thu tuần (7 ngày gần nhất so với 7 ngày trước), đơn trong ngày (so với hôm qua), số hồ sơ gian hàng / tài xế chờ duyệt.
- Giữ nguyên điều hướng, kiểm tra phân quyền (Admin tổng / Nhân viên), làm mới kéo xuống, đổi mật khẩu và đăng xuất.
- Chưa có: ô tìm kiếm và chuông thông báo trên thanh trên; "Hệ thống ổn định" hiện là chữ cố định (chưa kiểm tra máy chủ thật). Các trang con của Admin vẫn giao diện cũ.

## Giao diện khách hàng kiểu Xanh SM
- Đã gộp bộ giao diện khách hàng xanh lá/trắng/bạc hà (Resources/Styles/CustomerTheme.xaml và 20 trang khách hàng, AppShell.xaml). Chi tiết: Docs/CHANGELOG_GIAO_DIEN_KHACH_HANG.md.
- Giữ giao diện Admin mới (AdminHomePage) — không bị ghi đè bởi bản cũ trong gói Xanh SM.
- FoodApp.Maui.csproj và Views/KhoiDongVideoPage.xaml.cs dùng đúng bản người dùng cung cấp. Màu icon/splash trong csproj vẫn là tím #3C0293 (gói Xanh SM đổi sang xanh #008A68).

## Giao diện gian hàng (cam) — xem Docs/CHANGELOG_GIAO_DIEN_GIAN_HANG.md
- Theme cam riêng cho khu Gian hàng, thanh tab dưới, làm lại Trang chủ / Quản lý món / Đơn hàng / Doanh thu / Cá nhân / Thông báo.
- Đường dẫn gộp theme khách hàng đổi thành gốc (`/Resources/Styles/CustomerTheme.xaml`) để chắc chắn tìm được file dù trang nằm trong thư mục Views.

## Giao diện khách hàng kiểu Xanh SM (teal) — xem Docs/CHANGELOG_GIAO_DIEN_KHACH_XANHSM.md
- Đổi bảng màu khách hàng sang xanh ngọc; thanh tab còn 4 mục (Trang chủ, Đơn hàng, Ưu đãi, Tài khoản); thêm trang Ưu đãi; thêm nút +/− trong giỏ hàng.
