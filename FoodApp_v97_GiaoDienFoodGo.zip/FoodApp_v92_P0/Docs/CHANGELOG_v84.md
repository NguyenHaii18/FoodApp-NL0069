# v84 — Chuẩn bị triển khai (Staging / Production)

CHƯA build/chạy thử trong môi trường làm việc (không có MAUI/SQL Server/máy chủ) — chỉ kiểm tra cú pháp.

- **Web**: `appsettings.Staging.json`, `appsettings.Production.json`; chạy sau Nginx (`ReverseProxy__Bat`, đọc `X-Forwarded-*`); `MoiTruongKiemTra` (Production từ chối chạy nếu CSDL tên staging/test/dev/demo hoặc bật `Otp:HienMaDev`; cảnh báo VNPay sandbox/ReturnUrl localhost, AllowedHosts `*`, thiếu Goong key, LocalDB…); `/health` trả thêm `moiTruong`, `canhBaoCauHinh`.
- **Mobile**: `Api.MoiTruong` (Development/Staging/Production) + `BaseUrlStaging`/`BaseUrlProduction`; nhãn môi trường ở Cài đặt và trang kiểm tra kỹ thuật của quản trị; Production không nhận chứng chỉ tự ký.
- **deploy/**: Nginx (HTTPS + WebSocket), systemd, mẫu biến môi trường, Dockerfile + docker-compose, sao lưu CSDL + ảnh, giám sát `/health` qua webhook.
- **Docs/TRIEN_KHAI.md**: 13 bước triển khai ↔ file tương ứng, bảng 3 môi trường, quy tắc tách dữ liệu.

Chưa có: lưu ảnh lên S3/cloud (hiện ổ đĩa), tách worker khỏi tiến trình web, push FCM.
