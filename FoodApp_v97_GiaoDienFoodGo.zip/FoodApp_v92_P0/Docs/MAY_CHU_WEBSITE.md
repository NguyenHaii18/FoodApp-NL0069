# Website là MÁY CHỦ của app (v96)

Website (ASP.NET Core `FoodServiceApp.Web`) chính là máy chủ: một tiến trình duy nhất phục vụ
1. giao diện web (khách / gian hàng / tài xế / quản trị),
2. Web API `/api/...` (JWT) cho app MAUI,
3. kênh thời gian thực SignalR `/hubs/don-hang`,
4. SQL Server dùng chung. App **không** tự lưu dữ liệu nghiệp vụ; giá, tồn kho, phí giao, khuyến mãi do máy chủ tính.

## Chạy nhanh (phát triển / demo trong mạng LAN)
1. Cài SQL Server (hoặc LocalDB), chạy SQL theo `Database/HUONG_DAN_CHAY_SQL.txt`, kiểm tra chuỗi kết nối trong `Web/FoodServiceApp.Web/appsettings.json`.
2. Mở PowerShell tại thư mục gốc, **Run as Administrator**: `.\chay_may_chu.ps1` (hoặc bấm đúp `chay_may_chu.bat`).
   Script: tìm IP LAN → mở cổng 5000 → ghi IP vào app (`appsettings.json`, `network_security_config.xml`) → chạy Web ở `http://0.0.0.0:5000`.
3. **Build lại app MAUI** một lần (vì IP đã ghi vào app), cài lên điện thoại cùng Wi-Fi.
4. Kiểm tra: trên điện thoại mở `http://<IP>:5000/api/may-chu/thong-tin` → phải thấy `"trangThai":"SanSang"`.
   Cách khác: nhập địa chỉ máy chủ trong app: Cài đặt → Địa chỉ máy chủ (chỉ Development).

| Thiết bị | Địa chỉ app dùng |
|---|---|
| Windows (app MAUI) | `https://localhost:5001` (chạy `dotnet run` thường) |
| Android emulator | `http://10.0.2.2:5000` |
| Điện thoại thật | `http://<IP máy chạy Web>:5000` |

## Không vào được? Kiểm tra theo thứ tự
- `…/api/may-chu/thong-tin` mở được trên chính máy chủ chưa? (không → Web chưa chạy hoặc lỗi SQL, xem console)
- Điện thoại cùng Wi-Fi với máy chủ? Mạng Wi-Fi có chặn "AP isolation"?
- Tường lửa cổng 5000 đã mở (script tự mở khi chạy Administrator)?
- Mạng Windows đang đặt là **Public** thì quy tắc tường lửa của script (Private/Domain) không áp dụng → đổi sang Private.
- Android chặn HTTP: IP phải có trong `network_security_config.xml` (script tự thêm) và đã build lại app.

## Chạy thật (Staging/Production)
Không dùng chế độ LAN. Dùng `deploy/` (Docker/Nginx/systemd): HTTPS bắt buộc, `Jwt:Key` mạnh, `Cors:AllowedOrigins`, `MoiTruong` của app = Production + `BaseUrlProduction` = `https://tên-miền`. VNPay cần `ReturnUrl` công khai.

## Ghi chú trung thực
Các file này chưa được build/chạy ở nơi soạn (không có .NET SDK / Windows). Script PowerShell và endpoint `/api/may-chu/thong-tin` cần chạy thử một lần.
