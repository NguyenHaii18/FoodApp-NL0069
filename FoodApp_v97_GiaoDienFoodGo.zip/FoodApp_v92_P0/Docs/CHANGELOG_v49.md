# v49 – Sổ địa chỉ giao hàng của app đồng bộ với bảng DiaChiKhachHang

Đối chiếu danh sách "Liên kết giữa các bảng": 15/15 quan hệ có đủ khóa ngoại trong `FoodService_Database.sql` (TaiKhoan→KhachHang/GianHang/TaiXe/QuanTri, GianHang→DanhMuc→MonAn, KhachHang→DonHang→ChiTietDonHang/ThanhToan/GiaoHang/DanhGia/PhanHoi, GiaoHang→TaiXe, KhachHang→DiaChiKhachHang, KhuyenMai→GianHang với `MaGianHang NULL` = khuyến mãi toàn hệ thống). Khuyến mãi theo quán và toàn hệ thống đã nối API trong app (`KhuyenMaiQuanLyService`).

## Sửa
- App lưu nhiều địa chỉ chỉ trong Preferences, không dùng bảng `DiaChiKhachHang`. Nay `DiaChiPage` đồng bộ với `api/customer/addresses`:
  - Mở trang (online): đưa địa chỉ chỉ có trên máy lên máy chủ, rồi lấy danh sách chuẩn về (nếu chưa gửi hết thì không ghi đè bản trên máy).
  - Thêm / sửa / xóa / đặt mặc định: máy chủ nhận trước, lỗi thì dừng và báo (không đổi sổ trên máy). Ngoại tuyến: chỉ đổi trên máy như trước.
  - `DiaChiLuu.MaDiaChi` lưu mã bản ghi trên máy chủ.
- Server: thêm `PUT api/customer/addresses/{id}` (sửa nhãn/địa chỉ/mặc định); giới hạn 10 địa chỉ/tài khoản như web.

Chưa build/chạy (không có .NET SDK/SQL Server).
