# 20 tài khoản gian hàng mẫu

Đăng nhập app → Gian hàng bằng **Email** và **Mật khẩu** bên dưới. Dữ liệu tạo bằng `Database/FoodService_DuLieuMau.sql` (chạy 1 lần trên SQL Server).

| # | Gian hàng | Email | Mật khẩu | SĐT |
|---|---|---|---|---|
| 1 | Bún Chả Hương Liên | bunchahuonglien@foodapp.vn | 123456 | 0968881347 |
| 2 | Cơm Gà Xối Mỡ Út Hiền | comgauthien@foodapp.vn | 123456 | 0993957772 |
| 3 | Bánh Xèo Miền Tây Hai Lúa | banhxeo2lua@foodapp.vn | 123456 | 0950322955 |
| 4 | Mì Quảng Bà Mua | miquangbamua@foodapp.vn | 123456 | 0971165393 |
| 5 | Sushi Kohaku | sushikohaku@foodapp.vn | 123456 | 0993934431 |
| 6 | Pizza Nhà Làm Mama | pizzamama@foodapp.vn | 123456 | 0973185837 |
| 7 | Cà Phê Muối Phố Cổ | caphemuoipho@foodapp.vn | 123456 | 0928133569 |
| 8 | Lẩu Thái Tomyum Bangkok | lauthaibangkok@foodapp.vn | 123456 | 0951633055 |
| 9 | Xôi Gà Nướng Cô Tư | xoigacotu@foodapp.vn | 123456 | 0936168676 |
| 10 | Kem Trái Cây Mát Lạnh | kemtraicay@foodapp.vn | 123456 | 0941547797 |
| 11 | Hủ Tiếu Nam Vang Cô Ba | hutieunamvang@foodapp.vn | 123456 | 0930008019 |
| 12 | Bánh Mì Hòa Mã | banhmihoaima@foodapp.vn | 123456 | 0930015938 |
| 13 | Chè Sương Sa Hạt Lựu | chegiaiphong@foodapp.vn | 123456 | 0930023857 |
| 14 | Bún Bò Huế O Tâm | bunbohue7@foodapp.vn | 123456 | 0930031776 |
| 15 | Cơm Tấm Sườn Bì Chả Q8 | comtamq8@foodapp.vn | 123456 | 0930039695 |
| 16 | Bánh Cuốn Nóng Thanh Trì | banhcuonq11@foodapp.vn | 123456 | 0930047614 |
| 17 | Trà Sữa Mây Hồng | trasuaq12@foodapp.vn | 123456 | 0930055533 |
| 18 | Ốc Đêm Gò Vấp | ocgovap@foodapp.vn | 123456 | 0930063452 |
| 19 | Phở Bò Tái Lăn Tân Bình | phobotanbinh@foodapp.vn | 123456 | 0930071371 |
| 20 | Bún Thịt Nướng Thủ Đức | bunthitnuongtd@foodapp.vn | 123456 | 0930079290 |

Gian hàng 11–20 (Q.1, 4, 6, 7, 8, 11, 12, Gò Vấp, Tân Bình, Thủ Đức) chỉ có trong SQL. Đã tích hợp: 10 gian hàng đầu cũng được thêm vào dữ liệu mẫu ngoại tuyến của app (Models/DuLieuMauNgoaiTuyen.cs, gh21–gh30, mỗi quán 2 món) nên đăng nhập được ngay khi chưa bật server; khi online thì cần chạy file SQL.

Lưu ý: cả 20 tài khoản dùng chung mật khẩu demo `123456` (cùng mật khẩu với các tài khoản mẫu có sẵn). Trước khi đưa lên máy chủ thật, hãy chạy `BaoMat_VoHieuHoaTaiKhoanMau.sql` hoặc đổi mật khẩu.
