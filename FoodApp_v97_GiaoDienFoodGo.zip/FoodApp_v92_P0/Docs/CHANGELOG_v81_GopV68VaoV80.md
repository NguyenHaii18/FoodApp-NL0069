# v81 — Gộp toàn bộ chức năng v68 vào v80 (bản Mobile + SQL mới)
Chưa build/chạy (không có .NET SDK) — cần Build trên máy.

Nền: `FoodApp_v80_Mobile_SQL.zip` (Mobile + SQL mới nhất) đè lên cây `FoodApp_v80` đầy đủ (lấy phần Web). Gộp 3 chiều với gốc v58.

## Đã có sẵn trong v80 (giữ nguyên)
Goong đường thật + khóa trong CSDL, đơn nhóm, tự động phân công chạy nền, v51 (RowVer, đối soát VNPay), v64, đặt hẹn giờ `HenGiaoLuc`, AI gợi ý món, chọn tài xế theo điểm, Admin: Goong / Báo cáo nâng cao / Dashboard / Thông báo trang chủ / Nhật ký.

## Bổ sung từ v68
- Chat: quán nhắn khách/tài xế (`NhanVaiTro = GianHang`), nút "🏪 Nhắn quán" ở theo dõi đơn, "💬 Nhắn khách / tài xế" ở đơn quán, `DonHang.ConChat`, `TinNhan.TrangThaiGui/LoiGui`.
- Trang chủ khách: dải thông báo (`KhungThongBaoTrangChu`).
- Admin: sửa banner (ngày dd/MM/yyyy), các trang Goong/Báo cáo nâng cao/Dashboard.
- Hẹn giờ giao: nhãn `NhanHenGio`, gửi `henGiaoLuc` khi thanh toán.
- API quản lý thực đơn cho quán `VendorThucDonApiController` + `VendorThucDonService` (`api/mobile/gian-hang/{id}/thuc-don|danh-muc|mon-an|thong-tin`).
- SQL: sửa ràng buộc `TinNhan.NguoiGui` cho phép `GianHang` (nếu không, tin nhắn của quán bị SQL từ chối).

## KHÔNG đưa vào (trùng với v80)
Hệ thống **nhân viên cửa hàng** của tôi (bảng/Filter/trang/đăng nhập riêng) bị bỏ, vì v80 đã có bản riêng (`NhanVienGianHang`, `NhanVienQuyenFilter`, `VendorStaffPage`); giữ bản v80 để khỏi trùng bảng và lớp.

## Cần làm
1. Chạy `Database/FoodService_NangCap.sql` (chạy lặp lại an toàn; có khối sửa CHECK của TinNhan).
2. Nếu cho nhân viên dùng `VendorThucDonApiController`, thêm đường dẫn đó vào bảng quyền của `NhanVienQuyen`.
3. Mobile mới (`VanHanhService`) gọi `gian-hang/{id}/cau-hinh-cao-diem` và `mon-an/.../van-hanh`; thư mục Web đi kèm chưa có các API này — dùng Web mới nhất của bạn.

## Thêm: chọn size cho món ăn và nước
Chọn size cho khách và nhập size cho quán đã có từ v63 (Size chọn một, phụ phí cộng vào giá). Bản này thêm vào trang sửa món của quán 3 nút: "🥤 Nước: S/M/L", "🍜 Món ăn: Nhỏ/Vừa/Lớn" (điền sẵn phụ phí gợi ý, sửa lại được) và "Xóa". Không đổi server/SQL.
