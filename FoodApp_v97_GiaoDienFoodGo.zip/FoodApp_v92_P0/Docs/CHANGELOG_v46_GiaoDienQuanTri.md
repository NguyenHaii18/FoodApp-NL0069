# v46 — Giao diện quản trị viên theo mẫu tím (FoodApp)

- Quản lý đơn hàng: ô tìm kiếm bo tròn, tab Tất cả / Đang xử lý / Đang giao / Đã giao, dòng đơn gọn (avatar, trạng thái, giờ, số tiền), thanh điều hướng dưới.
- Quản lý gian hàng: tìm kiếm, thẻ có ảnh/emoji, sao đánh giá, trạng thái (Hoạt động / Tạm đóng / Đã khóa), doanh thu ước tính, nút Khóa/Mở khóa (giữ nguyên phân quyền, hoàn tác, nhật ký).
- Khuyến mãi: nút "＋ Tạo" trên thanh tiêu đề, tab Tất cả / Đang diễn ra / Sắp hết hạn / Hết hạn–tắt, lọc phạm vi bằng Picker, thẻ có ô giảm giá, HSD, lượt dùng, công tắc bật/tắt, nút Xóa.
- Tổng quan: thêm "Đơn hàng gần đây" (5 đơn mới nhất) và "Top gian hàng" (theo doanh thu đơn hoàn thành).
- Đổi nốt màu #0EA5E9 → #8B5CF6 trong AdminUi.cs, AdminPages2.cs.
- Chưa có: biểu đồ donut, sidebar bản web, ảnh thật cho khuyến mãi (đang dùng ô màu).
- LƯU Ý: chưa biên dịch được trong môi trường này (không có .NET SDK). Cần Build lại trên máy.
