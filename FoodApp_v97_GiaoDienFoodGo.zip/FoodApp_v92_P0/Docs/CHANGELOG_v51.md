# v51 – Quản lý trạng thái đơn hàng: truy vết người thực hiện, chống ghi đè, chống gửi lặp, đối soát lại cổng thanh toán

> Chưa build / chưa chạy SQL / chưa thử với cổng VNPay thật (môi trường tạo gói không có .NET SDK, SQL Server, mạng VNPay). Nền: v50.
> Chạy `Database/FoodService_NangCap.sql` (mục v51) rồi build.

Đối chiếu từng quy tắc yêu cầu với v50, chi tiết: `Docs/QUAN_LY_TRANG_THAI_DON.md`. v50 đã đạt: máy trạng thái tập trung, nhận đơn nguyên tử, ràng buộc 1 tài xế/đơn, hoàn thành giao cần mã/ảnh, VNPay idempotent + hoàn tiền khi trả muộn, khóa chống đặt lặp ở Web và app. v51 bổ sung phần còn thiếu:

1. **Người thực hiện + vai trò + thời điểm** tự động trong `LichSuTrangThaiDon` (cột mới `VaiTro`; `AppDbContext` đọc người dùng từ `IHttpContextAccessor`).
2. **Kết quả thao tác bị từ chối** ghi Nhật ký hệ thống (`TrangThaiDon.GhiTuChoiAsync`), áp dụng cho các điểm quán đổi trạng thái (Web, API gian hàng, app).
3. **Chống ghi đè đồng thời**: `DonHang.RowVer` (rowversion) + `TranhChapDuLieuFilter` (API → 409, Web → quay lại kèm thông báo).
4. **Chống gửi lặp ở `api/customer/orders`** (trước đó thiếu): trường `MaYeuCauDat`; yêu cầu song song cùng khóa → trả lại lượt mã giảm giá (`KhuyenMaiXuLy.TraLuotAsync`, cũng áp dụng cho `api/mobile`).
5. **Thanh toán thành công nhưng mất phản hồi**: lưu `ThanhToan.NgayTaoLinkCong`; `IVnPayService.QueryAsync` (querydr); `VnPayXuLy.DoiSoatLaiAsync` (đi qua cùng hàm ghi idempotent); endpoint khách `POST api/mobile/don-hang/{id}/thanh-toan/kiem-tra-lai`; tiến trình nền `ThanhToanDoiSoatNen`; nút **Hỏi lại cổng** cho quản trị.
6. SQL: `DonHang.RowVer`, `LichSuTrangThaiDon.VaiTro`, `ThanhToan.NgayTaoLinkCong` (FoodService_Database.sql + FoodService_NangCap.sql).

## Cần làm
* Chạy SQL (mục v51); build Web.
* App MAUI: gọi endpoint kiểm tra lại thanh toán khi người dùng quay lại từ cổng nhưng chưa thấy "đã thanh toán"; app đặt hàng qua `api/customer/orders` nên gửi `MaYeuCauDat` (GUID mỗi lần bấm Đặt hàng). Phần app này chưa sửa trong v51.
* Thử `querydr` với sandbox VNPay.
