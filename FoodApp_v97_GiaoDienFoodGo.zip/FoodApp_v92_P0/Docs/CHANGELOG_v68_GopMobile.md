# v68 — Gộp toàn bộ phần mobile, lấy v67 (GopV48) làm mốc
Chưa build/chạy (không có .NET SDK) — cần Build trên máy.

Nền: `FoodApp_v67_GopV48` (đã chứa sẵn các trang Admin mobile, FAQ, Khoản phải trả/đã chuyển khoản, lịch sử đơn khách, hợp đồng–hoa hồng quán từ v55).

## Thêm vào từ v56 (v67 chưa có)
- **AI gợi ý món cá nhân hóa**: `Services/GoiYMonXuLy.cs`, `Controllers/Api/GoiYMonApiController.cs` (`GET api/mobile/khach/goi-y-mon?top=8`); Trang chủ khách có mục "✨ Dành riêng cho bạn" (lỗi/offline → dùng gợi ý theo lịch sử trên máy).
- **Chọn tài xế theo điểm** (khoảng cách GPS, tải, đánh giá, tỷ lệ giao thành công): `Services/TuDongChonTaiXeXuLy.cs`, `Controllers/Api/AdminMobileThongMinhApiController.cs` (`GET dieu-phoi/{id}/goi-y`, `PUT dieu-phoi/{id}/tu-dong`, `PUT dieu-phoi/tu-dong-tat-ca`); Điều phối tài xế → nút **🤖 Tự động chọn** trên từng đơn chờ (xem top 3 + lý do, xác nhận để giao).

## Giữ nguyên của v67, KHÔNG thêm bản v56 (tránh trùng)
- Tự động phân công chạy nền: giữ `TuDongPhanCongNen` (cấu hình `DieuPhoi.TuDong`); bỏ `TuDongPhanCongHostedService` và 2 mục cấu hình `Don.TuDongPhanCong/TuDongSauGiay` của v56 — chỉ còn MỘT công tắc.
- Lộ trình: giữ `LoTrinhThatService` + `LoTrinhBanDoPage` (đường thật qua Goong); bỏ `LoTrinhTaiXePage`/`LoTrinhToiUuService` (OSRM) của v56.

## Khác
- Xóa các file thừa `*.orig`.
- Không gộp bản "main" (cũ hơn v67).
