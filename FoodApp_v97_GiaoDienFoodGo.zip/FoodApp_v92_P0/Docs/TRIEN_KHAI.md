# Triển khai FoodApp (Development → Staging → Production)

> Các file mẫu trong thư mục `deploy/` **chưa được chạy thử trên máy chủ thật** — thử ở Staging trước, sửa tên miền/mật khẩu cho đúng.

## Ba môi trường — không dùng chung dữ liệu

| | Development | Staging | Production |
|---|---|---|---|
| Mục đích | Lập trình trên máy cá nhân | Kiểm thử gần giống thực tế, nghiệm thu | Phục vụ khách thật |
| `ASPNETCORE_ENVIRONMENT` | Development | Staging | Production |
| CSDL | LocalDB / `QuanLyDichVuAnUong` cục bộ | **Riêng**, vd `QuanLyDichVuAnUong_Staging` | **Riêng**, `QuanLyDichVuAnUong` |
| Dữ liệu | Mẫu thoải mái | Mẫu / bản sao đã ẩn danh — **không** chép dữ liệu khách thật | Dữ liệu khách thật |
| Tài khoản mẫu (123456/admin123) | Có | Chỉ khi cố ý: `BaoMat__ChoPhepTaiKhoanMau=true` | **Không** — chạy `Database/BaoMat_VoHieuHoaTaiKhoanMau.sql` |
| VNPay | Sandbox | **Sandbox** | Cổng thật |
| Khóa JWT / API key | Khóa tạm tự sinh | Khóa riêng | Khóa riêng, khác Staging |
| Tên miền | localhost | `staging-api.example.com` | `api.example.com` |
| App mobile | `MoiTruong: Development` | `MoiTruong: Staging` (hiện nhãn STAGING) | `MoiTruong: Production` |

Ứng dụng **tự từ chối chạy** ở Production nếu tên CSDL có chữ staging/test/dev/demo hoặc `Otp:HienMaDev` đang bật, và in cảnh báo khi cấu hình chưa phù hợp môi trường (xem log: `journalctl -u foodapp | grep "Triển khai"`). `/health` trả về `moiTruong` và `canhBaoCauHinh` (số cảnh báo).

## 13 bước và file tương ứng

| # | Bước | Làm gì / file nào |
|---|---|---|
| 1 | Tên miền + DNS | Mua tên miền; trỏ bản ghi A `api` (production) và `staging-api` về IP máy chủ. |
| 2 | Máy chủ + hệ điều hành | Ubuntu 22.04/24.04 LTS, tường lửa chỉ mở 22/80/443 (`ufw allow 22,80,443/tcp`), tạo user `foodapp`, cập nhật bảo mật tự động. |
| 3 | Môi trường chạy | .NET 8 ASP.NET Core Runtime, Nginx, `sqlcmd` (hoặc dùng `deploy/Dockerfile` + `docker-compose.yml`). |
| 4 | Cơ sở dữ liệu | SQL Server 2022 (Express đủ cho thử nghiệm). Tạo mới: `Database/FoodService_Database.sql`; nâng cấp giữ dữ liệu: `FoodService_NangCap.sql`. Mỗi môi trường một CSDL. Tạo user SQL riêng quyền hạn vừa đủ (không dùng `sa`). |
| 5 | Biến môi trường | Sao `deploy/foodapp.env.example` → `/etc/foodapp/foodapp.env` (chmod 600). Bí mật chỉ nằm ở đây, **không** nằm trong mã nguồn/zip. |
| 6 | SSL/HTTPS | `certbot --nginx -d api.example.com` (tự gia hạn). Cấu hình mẫu: `deploy/nginx-foodapp.conf`. |
| 7 | Backend API | `dotnet publish Web/FoodServiceApp.Web -c Release -o /opt/foodapp/app`; chạy bằng `deploy/foodapp.service` (systemd, tự khởi động lại). Kestrel chỉ nghe `127.0.0.1:5000`, Nginx đứng trước, bật `ReverseProxy__Bat=true`. |
| 8 | WebSocket + worker | **WebSocket (SignalR `/hubs/don-hang`)**: Nginx đã có khối `location /hubs/` (Upgrade, `proxy_read_timeout 1h`). **Worker hàng đợi** (đối soát VNPay, tự phân công tài xế…) chạy *trong cùng tiến trình web* (`AddHostedService`) → **chỉ chạy 1 bản** ứng dụng; nếu sau này chạy nhiều bản cần tách worker riêng/khóa phân tán. |
| 9 | Lưu ảnh/tài liệu | Hiện lưu ổ đĩa tại `wwwroot/uploads` (`LocalFileStorageService`). Phải **sao lưu** thư mục này (`deploy/sao-luu.sh` đã làm) và giữ nguyên khi triển khai bản mới (Docker: volume `uploads`). Muốn dùng S3/Cloud storage: viết thêm một lớp `IFileStorageService` — chưa có sẵn. |
| 10 | Website + app mobile | Website nằm trong cùng dự án web. App mobile: trước khi build bản phát hành sửa `Resources/Raw/appsettings.json`: `MoiTruong` = `Staging` hoặc `Production` và điền `BaseUrlStaging` / `BaseUrlProduction` (https). Production **không** chấp nhận chứng chỉ tự ký. Ký ứng dụng Android (keystore riêng, không đưa vào git). |
| 11 | Kiểm thử Staging | Build app với `MoiTruong: Staging`; chạy `Tools/NghiemThu_E2E.ps1`, `NghiemThu_TinhHuongLoi.ps1`, `FoodService_NghiemThu_SaoLuu.sql`; thử VNPay sandbox, OTP email, thông báo thời gian thực, upload ảnh. |
| 12 | Chuyển Production | Nghiệm thu xong → **sao lưu** → chạy script CSDL trên Production → `BaoMat_VoHieuHoaTaiKhoanMau.sql` (khóa tài khoản mẫu, đặt mật khẩu admin thật) → deploy → kiểm `/health` → build app `MoiTruong: Production` đưa lên cửa hàng ứng dụng. |
| 13 | Sao lưu, giám sát, cảnh báo | `deploy/sao-luu.sh` (cron 02:00, giữ 14 ngày, có kiểm tra bản `.bak`); **chép ra nơi khác** và thử phục hồi định kỳ vào Staging. `deploy/giam-sat.sh` (cron mỗi 5 phút, gọi `/health`, báo qua webhook Telegram/Slack). Nhật ký ứng dụng: trang quản trị → Nhật ký hệ thống / Kiểm tra kỹ thuật; log dịch vụ: `journalctl -u foodapp`. Nên thêm giám sát bên ngoài (UptimeRobot…) cho `https://api.example.com/health`. |

## Quy tắc tách dữ liệu
1. Không bao giờ trỏ Staging vào CSDL Production (và ngược lại). Ứng dụng chỉ chặn được trường hợp Production trỏ vào CSDL *đặt tên* kiểu staging/test — hãy đặt tên CSDL theo đúng quy ước.
2. Muốn thử với dữ liệu giống thật: phục hồi bản sao lưu Production vào CSDL Staging rồi **ẩn danh** (đổi email/SĐT/địa chỉ khách, tắt gửi email/SMS thật) trước khi cho người thử dùng.
3. Staging dùng khóa JWT, API key, VNPay sandbox và email riêng. Token của Staging không dùng được ở Production.
4. App mobile Staging hiện nhãn "STAGING (thử nghiệm)" ở Cài đặt và trang kiểm tra kỹ thuật của quản trị để tránh nhầm.
