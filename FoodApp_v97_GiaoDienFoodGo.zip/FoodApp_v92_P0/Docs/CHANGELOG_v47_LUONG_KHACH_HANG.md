# v47 – Luồng khách hàng
- MỚI Views/MonAnChiTietPage: Chi tiết món (ảnh, mô tả, tùy chọn, số lượng, ghi chú) → "Thêm vào giỏ hàng". Bấm món ở danh sách và thẻ ngang trong trang quán đều mở trang này.
- MỚI Views/DatHangThanhCongPage: sau khi đặt hàng → mã đơn, tóm tắt, nút "Xem chi tiết đơn hàng" (mở sẵn đơn trong tab Đơn hàng) / "Về trang chủ".
- Thông báo: chạm thông báo đơn hàng → mở đúng đơn; thông báo khuyến mãi → tab Ưu đãi.
- GioHangService.Them(mon, soLuong, ghiChu).
- Chưa đổi: đánh giá riêng từng món (hiện đánh giá món chung + tài xế + quán).
- CHƯA biên dịch được trong môi trường này; hãy Build trong Visual Studio.

## Bổ sung luồng Quản trị viên (v47b)
- MỚI Views/AdminIssueDetailPage: Trung tâm sự cố → chạm khiếu nại → Chi tiết (người báo, nội dung, trạng thái, nút xem đơn liên quan) → Nhận xử lý / Đã giải quyết (kiểm quyền XuLyVanDe, ghi nhật ký).
- MỚI Services/BaoCaoXuatService: nút "Xuất báo cáo" (CSV mở bằng Excel) trên trang Thống kê và Báo cáo & thống kê, kiểm quyền XemThongKe, ghi nhật ký.
- Đã có sẵn từ trước: duyệt hồ sơ quán/tài xế, danh sách khách, đơn hàng → chi tiết → giao hàng, khuyến mãi tạo/sửa, giao dịch & hoàn tiền theo ngưỡng quyền, phân quyền nhân viên và nhật ký.
