# v53 — Mobile (chưa biên dịch — cần Build trên máy)
## Mới
- **Đa ngôn ngữ Việt/Anh** (`Services/NgonNguService.cs`): Cài đặt → Ngôn ngữ. Cơ chế dịch chữ cố định theo từ điển (~130 cụm: tab, trang chủ, giỏ/thanh toán, đơn hàng, cài đặt, đánh giá…). Chưa dịch: chữ ghép động, hộp thoại DisplayAlert, mục trong danh sách (CollectionView), khu quán/tài xế/quản trị. Thêm cụm mới = thêm một dòng vào `TuDien`.
- **Giọng nói** (`Services/GiongNoiService.cs`): nút 🎤 ở ô tìm kiếm Trang chủ. Nói "đặt hai phở bò" → mở Chi tiết món với số lượng 2; nói tên món/quán → điền ô tìm kiếm. Dùng CommunityToolkit.Maui SpeechToText (vi-VN); đã thêm quyền RECORD_AUDIO (Android) và microphone (Windows). iOS: nếu build iOS cần thêm NSMicrophoneUsageDescription + NSSpeechRecognitionUsageDescription vào Info.plist.
- **Gợi ý lộ trình nhiều đơn** (tài xế → Đơn hàng → "🧭 Gợi ý lộ trình"): thứ tự lấy/giao theo điểm gần nhất, luôn lấy trước giao. Khoảng cách ước tính theo tâm quận/huyện, KHÔNG phải đường thật.
- **Tự phân công** (quản trị → Điều phối → "⚡ Tự phân công"): đơn đã sẵn sàng → tài xế "Sẵn sàng" ít đơn nhất, ưu tiên trùng khu vực; hiện bản xem trước, quản trị xác nhận một lần. Quán tự giao bị bỏ qua.
- **3 trang chi tiết của gian hàng**: chi tiết đơn (xác nhận/từ chối/bàn giao), chi tiết đánh giá (phản hồi khách), chi tiết giao dịch (doanh thu → thực nhận). Chạm vào thẻ ở danh sách tương ứng.
## Chưa làm
- Đơn hàng nhóm (cần bảng + API ở server), tối ưu lộ trình theo đường thật (cần Goong/Google Directions + tọa độ), phân công hoàn toàn không cần người xác nhận.
- API SpeechToText: viết theo CommunityToolkit.Maui 9.x (StartListenAsync / RecognitionResultCompleted); nếu Build báo khác tên, chỉnh trong GiongNoiService.NgheAsync.
