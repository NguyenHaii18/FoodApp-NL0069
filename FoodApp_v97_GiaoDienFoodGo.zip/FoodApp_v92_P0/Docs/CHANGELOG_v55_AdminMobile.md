# v55 (trước đó gọi là v47f của nhánh admin) — Bổ sung app mobile phần "IV. Quản trị viên"

## Đối chiếu danh sách chức năng với app mobile
| Mục | Trước v47f | v47f |
|---|---|---|
| 1. Đăng nhập, phân quyền, nhật ký | Có (đăng nhập admin, 3 cấp quyền, nhật ký, quản lý nhân viên) | — |
| 2. Khách hàng | Có: danh sách, sửa, khóa/mở khóa | **Mới:** Tra cứu khách (tên/SĐT/email/mã) + lịch sử đơn + số khiếu nại |
| 3. Nhà hàng | Có: duyệt hồ sơ, danh sách, khóa, kiểm duyệt món/danh mục | **Mới:** Hợp đồng & hoa hồng quán (ngày tham gia, GMV, hoa hồng đã thu, đặt tỷ lệ riêng — Admin tổng) |
| 4. Tài xế | Có: duyệt, sửa, khóa, sự cố, điều phối | — |
| 5. Đơn hàng | Có: tìm, lọc, chi tiết + lịch sử, hủy/hoàn tiền, mở khóa mã giao | — |
| 6. Khuyến mãi | Có | — |
| 7. Thanh toán – tài chính | Có: giao dịch, đối soát COD, hoàn tiền, báo cáo, xuất Excel | **Mới:** Khoản phải trả quán / tài xế + đánh dấu đã trả (lưu trạng thái) |
| 8. Dashboard | Có: tỷ lệ hủy, khu vực, top quán/món | **Mới:** tách GMV và doanh thu nền tảng; thời gian giao trung bình |
| 9. Hỗ trợ & nội dung | Có: thông báo, khiếu nại, đánh giá vi phạm, danh mục | **Mới:** Banner trang chủ, Câu hỏi thường gặp |

## Thay đổi
**Server**
- `Controllers/Api/AdminMobileNoiDungApiController.cs`: banner (GET/POST/PUT bat-tat/DELETE + POST banner/anh), FAQ (GET/POST/PUT/PUT bat-tat/DELETE), GET `tai-chinh/phai-tra`, PUT `tai-chinh/tai-xe/{id}/da-tra`, GET công khai `api/mobile/faq`.
- Entity `CauHoiThuongGap` + `DbSet`; SQL tạo bảng trong `FoodService_Database.sql` và `FoodService_NangCap.sql` (chạy lặp lại an toàn).
- `bao-cao`: thêm `gmv`, `thoiGianGiaoTrungBinhPhut`.
- Web `MuaHang/HoTro` đọc FAQ từ CSDL (chưa có câu nào → dùng bộ câu mặc định).

**Mobile**: `Views/AdminPages4.cs` (AdminBannerPage, AdminFaqPage, AdminPayablesPage), đăng ký route, thêm 3 mục vào menu Quản lý, đổi nhãn báo cáo (GMV / Doanh thu nền tảng) và thêm ô thời gian giao TB.

**Quyền**: ghi banner/FAQ cần quyền chi tiết `ThongBao`; đánh dấu đã trả tài xế cần `ThanhToan`; xem thì mọi quản trị viên.

## Bổ sung lần 2 (cùng v47f)
- Cột mới `DonHang.QuanDaTraLuc` (có trong cả 2 file SQL): phải trả quán chỉ tính đơn đã giao chưa trả; nút "Đã trả cho quán" ghi mốc thời gian; hiển thị tổng đã trả 30 ngày qua. Bỏ bộ lọc ngày của trang Khoản phải trả (luôn là số còn nợ).
- API: `GET khach-hang/tim`, `GET don-hang/tim?maKH=`, `GET gian-hang/hop-dong`, `PUT gian-hang/{id}/hoa-hong` (Admin tổng), `PUT tai-chinh/gian-hang/{id}/da-tra`.
- App khách: trang `FaqPage` (mục "Câu hỏi thường gặp" trong Hồ sơ), đọc `GET api/mobile/faq`, có bộ câu mặc định khi offline/chưa có dữ liệu.
- Menu Quản lý: thêm "Tra cứu khách & lịch sử đơn", "Hợp đồng & hoa hồng quán".

## Giới hạn
- Chưa build/chạy (không có .NET, SQL Server trong môi trường soạn).
- Khóa/mở khóa khách vẫn chỉ Admin tổng (quy tắc sẵn có của server).
- "Đã trả cho quán" ghi theo từng quán, không theo từng đợt chuyển khoản (chưa có bảng lịch sử đợt trả).
