# Ảnh món/quán mẫu

8 ảnh nằm ở `Mobile_FoodApp.Maui/Resources/Images/` (app) và `Web/FoodServiceApp.Web/wwwroot/uploads/` (web).

| Ảnh | Quán | Món |
|---|---|---|
| `bun_rieu_1.jpg` | Bún Riêu Cua Bà Sáu (gh32) – ảnh quán | Bún riêu cua đồng |
| `bun_rieu_2.jpg` | Bún Riêu Cua Bà Sáu (gh32) | Bún riêu giò chả |
| `bun_cha.jpg` | Bún Chả Hương Liên (gh21) – ảnh quán | Bún chả nem rán, Bún chả đặc biệt |
| `bun_thit_nuong.jpg` | Bún Thịt Nướng Chị Tuyền (gh43) – ảnh quán | Bún thịt nướng chả giò, Bún thịt nướng đặc biệt |
| `tra_cam_tac.jpg` | Trà Đào Cam Sả Nhà Mình (gh36) – ảnh quán | Trà đào cam sả |
| `com_chien_tom_1.jpg` | Cơm Niêu Thố Sài Gòn (gh31) | Cơm chiên tôm (món mới, ma301) |
| `com_chien_tom_2.jpg` | Cơm Niêu Thố Sài Gòn (gh31) – ảnh quán | |
| `com_chien_lap_xuong.jpg` | Cơm Niêu Thố Sài Gòn (gh31) | Cơm chiên lạp xưởng (món mới, ma302) |

- App (ngoại tuyến): `Models/DuLieuMauAnh.cs` gắn ảnh khi khởi động; ảnh quán tự tải lên luôn được ưu tiên.
- Web/SQL: chỉ "Bún Chả Hương Liên" có trong `FoodService_DuLieuMau.sql` nên chỉ quán này được thêm ảnh và 2 món; 4 quán còn lại chỉ có ở dữ liệu ngoại tuyến của app.
- Ảnh `com_chien_tom_1/2` có dấu mờ của trang ảnh stock ở góc; nếu đưa vào báo cáo/đồ án công khai nên thay bằng ảnh có bản quyền.
