# v83 — Phí giao hàng & chia tiền tài xế / ứng dụng (Admin chỉnh được)

Nối trọn tính năng đã có file rời trong v82 (trang quản trị, API, PhiGiaoService) vào luồng thật:

- **Công thức phí** (theo bảng tính): phí = max(tối thiểu, cơ bản + km vượt + ngoại thành + %cao điểm + %mưa), làm tròn lên, không vượt tối đa.
  Mặc định: 12.000đ cho 2 km đầu, 4.000đ/km vượt, cao điểm +20% (10:30-13:00; 17:00-20:00), mưa +15%, tối thiểu 12.000đ, tối đa 70.000đ, ngoại thành +10.000đ.
- **Tỉ lệ chia phí giao**: `ChiaTien.TyLeTaiXe` (mặc định 80% tài xế / 20% ứng dụng). Chốt vào từng đơn lúc đặt (`DonHang.TyLeTaiXe`, NULL = đơn cũ → tài xế nhận 100%).
- **Admin**: Mobile → Quản trị → Tài chính → "Phí giao & chia tiền" (xem tổng quan, sửa từng mức, tính thử, khôi phục mặc định). Chỉ Admin tổng được lưu. Web: trang Chính sách có thêm các mục mới.
- **Đặt đơn** dùng cùng một công thức ở mọi nơi: `MobileApiController`, `CustomerApiController`, `CustomerCartController` (ước tính giỏ nhớ 10 phút).
- **Thu nhập tài xế / khoản phải trả tài xế / báo cáo** tính theo tỉ lệ trên từng đơn.
- **CSDL**: cột `DonHang.TyLeTaiXe DECIMAL(5,4) NULL` (cả `FoodService_Database.sql` và `FoodService_NangCap.sql`); seed `Giao.PhiMoiKm` = 4000.

Chưa làm: phụ phí mưa tự động theo thời tiết (hiện admin bật tay), `MapController.phi-giao-hang` và trang chi tiết quán web vẫn ước tính theo phí/km cũ.
