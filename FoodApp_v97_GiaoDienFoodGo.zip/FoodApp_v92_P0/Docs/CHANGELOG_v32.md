# v32 – gộp v30 (của bạn) + v31 (quản trị bổ sung, đồng bộ ngoại tuyến, kiểm tra schema)

Nền: v29. Gộp ba chiều: v29 (gốc) – v30 của bạn (bảo mật, CRUD khuyến mãi qua API, tài liệu quy trình) – v31 của mình.
Hai bản sửa các file khác nhau gần như hoàn toàn; chỉ 3 file bị sửa ở cả hai phía và đã được xử lý như dưới đây.
Chưa build/chạy thử (không có .NET SDK/SQL Server ở nơi gộp); cần `dotnet build` Web và MAUI.

## Giữ nguyên từ v30 của bạn
Bảo mật (BCrypt, chặn chạy thật khi còn tài khoản mẫu, `BaoMat_VoHieuHoaTaiKhoanMau.sql`), `KhuyenMaiQuanLyApiController` + `KhuyenMaiQuanLyService` và 4 trang khuyến mãi MAUI, `Docs/CAU_HINH_BAO_MAT.md`, `QUY_TRINH_CSDL.md`, `KE_HOACH_HOAN_THIEN.md`, `appsettings*.json`, `csproj`, `MatKhauHelper`, `OtpService`, `API_MOBILE.md`, `CHANGELOG_v30.md`.

## Thêm từ v31 của mình
- Web quản trị: hồ sơ tài xế + điều chỉnh thu nhập, trang sự cố tài xế báo, danh mục món ăn, cập nhật/xóa dữ liệu khách (xem `CHANGELOG_v30_QuanTri.md`).
- MAUI: ghi dữ liệu phân biệt 3 trạng thái đã đồng bộ / chỉ lưu trên máy / thất bại, hoàn tác khi máy chủ từ chối, cảnh báo đặt hàng ngoại tuyến (xem `CHANGELOG_v31.md`).
- Web: `Services/KiemTraSchema.cs` + thanh đỏ trang quản trị + mục "Phiên bản CSDL" ở "Hệ thống & phiên".

## 3 file bị sửa ở cả hai phía và cách xử lý
| File | Xử lý |
|---|---|
| `Database/FoodService_Database.sql` | Dùng nguyên **bản của bạn** (khóa `@CHO_PHEP_XOA_DB`, tự sao lưu `.bak` trước khi xóa, sao lưu lỗi thì không xóa). Bản `SESSION_CONTEXT` của mình bị bỏ vì trùng mục đích và kém hơn. |
| `Web/.../Program.cs` | Giữ toàn bộ khối bảo mật của bạn (chuyển mật khẩu rõ sang BCrypt, chặn tài khoản mẫu, cảnh báo cấu hình). Thêm khối kiểm tra schema ngay sau `EnsureCreated()` (chạy trước các khối bảo mật). |
| `HUONG_DAN_CHAY.txt` | Bước 1 viết lại theo cơ chế `@CHO_PHEP_XOA_DB` của bạn; giữ mục về kiểm tra schema khi khởi động. |

Thêm: `Docs/QUY_TRINH_CSDL.md` có ghi chú về `KiemTraSchema`. `CHANGELOG_v30.md` của mình đổi tên thành `CHANGELOG_v30_QuanTri.md` để không đè bản của bạn; `CHANGELOG_v31.md` đã sửa dòng P0 cho khớp.
