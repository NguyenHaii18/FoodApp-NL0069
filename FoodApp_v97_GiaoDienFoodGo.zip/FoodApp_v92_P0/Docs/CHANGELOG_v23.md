# FoodApp v23 – bản gộp

Gộp từ các gói:
- FoodApp_v16.zip (nền: Web + MAUI + Database + Docs + Tools)
- FoodApp_CapNhat_v22.zip (CSDL PHẦN 18c, MAUI tài xế: Từ chối / Đơn của tôi / Chi tiết đơn, tài liệu + slides)
- Maui_SuaLoi.zip (sửa ReviewPage: kiểm tra null DonHang; DriverNotificationsPage: đổi tên biến lặp t -> tb)

FoodService_Merged_v14.zip là bản cũ, đã nằm trọn trong v16 nên không gộp thêm.
Chi tiết: xem CHANGELOG_v16.md và CHANGELOG_v22.md.

## Cài đặt phí & chính sách (Quản trị → "Phí & chính sách")
Trang đã có từ trước (bảng CauHinhHeThong + lịch sử); v23 hoàn thiện:
- Giao diện chia nhóm: Phí giao hàng · Hoa hồng gian hàng · Hủy đơn · Hoàn tiền · Voucher · Thời gian xử lý đơn · Quy định (khách/gian hàng/tài xế) · Thanh toán chuyển khoản. Mỗi mục có đơn vị, mô tả, kiểm tra khoảng hợp lệ (Services/ChinhSachMeta.cs). Nhập "15%" hoặc "0.15", "15.000" hoặc "15000" đều được.
- Ghi nhận người đổi + thời điểm: cột "Sửa gần nhất" ở từng mục; bảng lịch sử đầy đủ (giá trị cũ/mới), lọc theo từng mục.
- Giới hạn voucher Voucher.ToiDaMoiKhach nay được áp dụng thật (trước đó chỉ lưu): một khách dùng cùng một mã tối đa N lần/30 ngày, 0 = không giới hạn. Áp ở cả giỏ hàng Web và API (KhuyenMaiXuLy).
- Khóa mới: QuyDinh.HuyDon (nội dung quy định hủy đơn), Don.TaiXePhanHoiPhut (chờ tài xế nhận). Các khóa còn thiếu tự được tạo khi mở trang.
- Sửa lỗi: ThanhToan.ThongTinChuyenKhoan trước đây bị kiểm tra như số nên không lưu được.
- Trang công khai /ChinhSach (khách, gian hàng, tài xế đều xem; có link trong menu) và API GET api/mobile/chinh-sach.
- Ghi chú: phí giao tính theo khoảng cách + bán kính phục vụ; chưa có bảng phí riêng theo quận/khu vực.

### Việc cần làm khi nâng cấp
1. Chạy Database/FoodService_NangCap.sql (mục v23; hoặc PHẦN 18d trong FoodService_Database.sql nếu tạo mới) để mở rộng cột lưu lên 1000 ký tự.
2. Build lại Web (bản gộp này chưa được biên dịch thử trong môi trường tạo gói).

## Gộp file CSDL: 26 file -> 3 file (thư mục Database/)
- FoodService_Database.sql: tạo mới toàn bộ CSDL (giữ nguyên tên).
- FoodService_NangCap.sql: gộp 20 file nâng cấp trong Database/NangCap (mục v8 … v23, đúng thứ tự phụ thuộc). Mục v19 (cột FLOAT) đặt trước 05_BoSung_GiaoHang_BanDo để tránh cột DECIMAL NOT NULL lệch entity. Bỏ 05_GioHang_GOC (đã có trong v10).
- FoodService_NghiemThu_SaoLuu.sql: PHẦN A nghiệm thu (Tools/NghiemThu_E2E.ps1 chỉ chạy phần này) + PHẦN B sao lưu/phục hồi (mặc định khóa bằng SET NOEXEC ON để tránh chạy nhầm) + 2 truy vấn kiểm tra nhanh cũ (đang để comment).
- Đã cập nhật đường dẫn trong HUONG_DAN_CHAY.txt, Tools/NghiemThu_E2E.ps1, API_MOBILE.md.
