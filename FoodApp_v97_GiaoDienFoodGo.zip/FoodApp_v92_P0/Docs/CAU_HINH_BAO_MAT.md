# Cấu hình bảo mật (chạy thật / nộp demo)

## 1. Khóa JWT (bắt buộc ngoài Development)
`appsettings.json` để `Jwt:Key` rỗng có chủ ý. Khóa phải là chuỗi ngẫu nhiên ≥ 32 ký tự, KHÔNG commit vào git.
- Tạo khóa: PowerShell `[Convert]::ToBase64String((1..48 | % { Get-Random -Max 256 }) -as [byte[]])`
- Máy phát triển: `dotnet user-secrets init --project Web/FoodServiceApp.Web` rồi `dotnet user-secrets set "Jwt:Key" "<khóa>" --project Web/FoodServiceApp.Web`
- Máy chủ: biến môi trường `Jwt__Key`.
- Development không đặt khóa: app tự sinh khóa tạm (token mất hiệu lực khi chạy lại). Môi trường khác không có khóa: app KHÔNG khởi động.

## 2. OTP / email
- `Otp:HienMaDev` chỉ có tác dụng khi `ASPNETCORE_ENVIRONMENT=Development` (xem OtpService). Production luôn tắt dù cấu hình thế nào.
- Cấu hình SMTP bằng biến môi trường: `Smtp__Host`, `Smtp__Port`, `Smtp__Ssl`, `Smtp__User`, `Smtp__Password`, `Smtp__From` (Gmail: dùng "mật khẩu ứng dụng").
- Chưa cấu hình SMTP: OTP không gửi được; ở Production app chỉ in cảnh báo khi khởi động.

## 3. CORS
`Cors:AllowedOrigins` (mảng). App MAUI không bị CORS chặn; chỉ cần khi có web khác gọi API bằng trình duyệt. Để trống ở Production = không origin nào được phép.

## 4. Tài khoản mẫu
`FoodService_Database.sql` tạo ~150 tài khoản demo dùng mật khẩu công khai (khách/quán/tài xế `123456`, quản trị `admin123`); đã lưu BCrypt, không còn mật khẩu rõ.
- Tài khoản cũ còn mật khẩu rõ (chưa `$2...`) được chuyển sang BCrypt khi Web khởi động.
- **Ngoài Development, Web từ chối khởi động nếu còn tài khoản mẫu đang bật.** Xử lý: chạy `Database/BaoMat_VoHieuHoaTaiKhoanMau.sql` (khóa mọi tài khoản mẫu, đặt mật khẩu mới cho MỘT quản trị bạn chọn). Tạo hash: `dotnet run --project Web/FoodServiceApp.Web -- --hash "MatKhauMoiManh"`.
- Cố ý demo trên máy chủ: đặt `BaoMat__ChoPhepTaiKhoanMau=true` (chỉ in cảnh báo).
- `Tools/NghiemThu_E2E.ps1` dùng tài khoản mẫu nên chỉ chạy ở Development / DB thử.

## 5. Khóa dịch vụ ngoài
VNPay `TmnCode`/`HashSecret`, Goong `ApiKey`: đặt bằng `user-secrets` hoặc biến môi trường (`VnPay__HashSecret`, `GoongMaps__ApiKey`); không để khóa thật trong `appsettings.json`.
