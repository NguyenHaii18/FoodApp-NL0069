# Cập nhật thời gian thực (v85)

Nguyên tắc: **SQL qua API là nguồn dữ liệu chính.** Kênh thời gian thực (SignalR/WebSocket) và thông báo đẩy chỉ là *tín hiệu* "có thay đổi";
app nhận tín hiệu rồi gọi lại API. Mở lại app, nối lại mạng hoặc mất WebSocket đều dẫn tới tải lại từ API, nên không hiển thị sai trạng thái.

## Luồng khi khách đặt đơn
1. Khách `POST /api/orders` → Backend lưu đơn vào SQL.
2. `AppDbContext.SaveChangesAsync` thấy `DonHang` mới → sau khi lưu thành công phát `OrderCreated` tới khách và gian hàng.
3. Gian hàng đang mở app nhận sự kiện → app tải lại danh sách đơn từ API (và rung máy).
4. Gian hàng xác nhận (`POST /api/restaurant/orders/{id}/confirm`) → `OrderStatusChanged` tới khách + gian hàng.
5. Gian hàng báo món xong (`.../ready`, `SanSangGiao`) và chưa có tài xế → `DriverInvite` tới mọi tài xế đang kết nối; app tài xế gọi lại API đơn chờ nhận (server lọc theo điều phối/khu vực) rồi báo đơn mới.
6. Tài xế nhận đơn (`POST /api/driver/orders/{id}/accept`) → Backend cập nhật `MaTaiXe` → `OrderDriverAssigned` + `OrderStatusChanged` tới khách, gian hàng, tài xế.
7. Khách và gian hàng nhận trạng thái mới qua WebSocket và tải lại đơn từ API.

## Sự kiện (hub `/hubs/don-hang`)
| Sự kiện | Khi nào | Gửi tới |
|---|---|---|
| `OrderCreated` | đơn mới được lưu | khách, gian hàng |
| `OrderStatusChanged` | đổi `TrangThai` hoặc `TrangThaiChuanBi` | khách, gian hàng, tài xế (nếu có) |
| `OrderDriverAssigned` | đơn được gán tài xế | khách, gian hàng, tài xế |
| `DriverInvite` | đơn sẵn sàng giao, chưa có tài xế | nhóm vai trò `TaiXe` |
| `NotificationCreated` | thêm bản ghi `ThongBao` | chủ tài khoản |

Nội dung chỉ gồm `maDon`, `tuTrangThai`, `trangThai`, `trangThaiChuanBi`, `maTaiXe`, `luc`. Hook đặt tại một chỗ duy nhất (`Data/AppDbContext.cs`), nên mọi đường ghi (website, API mobile, API tài xế, điều phối quản trị) đều phát sự kiện.
Xác thực: JWT gửi qua `?access_token=` (chỉ chấp nhận cho đường dẫn `/hubs`); mỗi kết nối vào nhóm `tk-{MaTK}` và `role-{VaiTro}`. Lỗi phát sự kiện không làm hỏng thao tác ghi SQL.

## Phía app
- `Services/RealtimeService.cs`: tự bật khi `ApiClient.Token` có giá trị, tự tắt khi đăng xuất/hết phiên; nối lại tự động (0s, 2s, 5s, 10s, rồi 30s/lần).
- Mỗi lần nối được, nối lại, hoặc mở lại app (`Window.Resumed`) phát `DongBo` để màn hình lấy lại trạng thái từ API.
- Màn hình đã nghe sự kiện: Theo dõi đơn (khách), Đơn hàng (gian hàng), Trang chủ tài xế. Các bộ đếm giờ cũ (15/30/60 giây) giữ làm phương án dự phòng khi WebSocket không dùng được.
- Thư viện: `Microsoft.AspNetCore.SignalR.Client` 8.0.8 (cần restore NuGet).

## Chưa làm
- Thông báo đẩy nền khi app đóng (FCM/APNs): cần tài khoản Firebase và mã riêng cho Android; hiện chỉ có WebSocket khi app đang mở.
- Chat và vị trí tài xế vẫn dùng thăm dò định kỳ (chưa chuyển sang hub).
- Chưa build/chạy thử (không có .NET SDK). Nếu chạy nhiều máy chủ Web, cần thêm backplane (Redis) cho SignalR.
