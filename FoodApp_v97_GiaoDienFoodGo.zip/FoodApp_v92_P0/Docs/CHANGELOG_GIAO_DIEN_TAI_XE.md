# Changelog – Giao diện Tài xế (Xanh Express)

Đổi giao diện khu Tài xế theo mockup 10 màn hình: màu xanh ngọc (teal) thay cho tím, thanh điều hướng dưới, bố cục mới.

## File mới
- `Resources/Styles/DriverTheme.xaml` – bảng màu + style khu Tài xế (có thêm màu `Gold`, `GoldSoft`). Mỗi trang tài xế tự nạp theme này, giống cách khu Gian hàng dùng `VendorTheme.xaml`.
- `Views/DriverPalette.cs` – màu dùng trong code C# (khớp `DriverTheme.xaml`). Code-behind không đọc `Application.Current.Resources` nữa vì ở đó vẫn là màu tím.
- `Views/DriverBottomBar.xaml(.cs)` – thanh điều hướng dưới: Trang chủ · Đơn hàng · Bản đồ · Thu nhập · Tài khoản. Dùng bằng `<views:DriverBottomBar Active="home|orders|map|earnings|account" />`.
  `DriverNav.DiDenAsync` quay về Trang chủ rồi mới mở trang đích để không chồng trang. Tab "Bản đồ" mở chi tiết đơn đang giao; chưa có đơn thì báo lại.

## Trang đã đổi
| Trang | Thay đổi |
|---|---|
| `DriverHomePage` | Đầu trang (ảnh, tên, trạng thái, chuông có huy hiệu), thẻ "Hôm nay", nút "Nhận đơn mới" (làm mới đơn chờ), 4 lối tắt, banner thưởng (hiện tiến độ thưởng ngày), "Đơn hàng gần đây". Đăng xuất chuyển sang trang Tài khoản. |
| `DriverEarningsPage` | Tổng thu nhập, 3 ô thống kê đơn, biểu đồ cột (theo giờ / theo ngày), bảng chi tiết (phí giao, phụ cấp, thưởng, tổng cộng). |
| `DriverMyOrdersPage` | Tab dạng chip bo tròn, thẻ đơn mới. |
| `DriverNotificationsPage` | Biểu tượng trong vòng tròn, thẻ bo tròn. |
| `DriverProfilePage` | Menu (Thông báo, Đánh giá, Thu nhập), nút Đăng xuất. |
| `DriverLoginPage` | Nền gradient xanh ngọc, thương hiệu XANH EXPRESS. |
| `DriverDeliveryDetailPage`, `DriverOrderDetailPage`, `DriverRatingPage`, `DriverRegisterPage` | Chỉ đổi sang theme xanh ngọc, giữ nguyên bố cục và logic. |

## Chưa làm (mockup có nhưng dự án chưa có dữ liệu/trang tương ứng)
- Màn "Ví tài khoản" (nạp/rút tiền, lịch sử giao dịch) – chưa có model/API ví cho tài xế.
- Màn "Cài đặt" của tài xế (bật/tắt thông báo, âm thanh, chế độ tối, ngôn ngữ).
- Màn splash có ảnh minh họa và logo – hiện dùng trang đăng nhập có sẵn.
- Màn "Bản đồ giao hàng" kiểu mockup – hiện vẫn dùng `DriverDeliveryDetailPage`.

## Lưu ý
Chưa build được trong môi trường này (không có .NET SDK). Đã kiểm tra XAML hợp lệ về cú pháp và đối chiếu tên control/handler với code-behind; cần build và chạy thử trên máy.
