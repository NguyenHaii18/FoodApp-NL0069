# v47e — app khách: theo dõi đơn trên bản đồ trong app

Chưa build/chạy (không có .NET SDK). Cần Internet (OpenStreetMap/Leaflet qua WebView, Nominatim tìm tọa độ; không dùng khóa API).

- Trang mới `Views/TheoDoiBanDoPage.cs` (route đã đăng ký ở `AppShell`): bản đồ có quán 🏬, địa chỉ nhận 🏠, tài xế 🛵; đường nét đứt từ tài xế tới điểm kế tiếp (quán khi đang lấy món, khách khi đang giao).
- Vị trí tài xế tự cập nhật mỗi 10 giây (dừng khi đơn hoàn thành/hủy); báo "mất tín hiệu GPS" khi quá 90 giây; ETA còn ~km/phút khi đang giao; nút Xem toàn tuyến, Gọi tài xế.
- Tọa độ quán/khách tìm bằng Nominatim từ địa chỉ (có cache); không tìm được thì chỉ hiện điểm xác định được.
- `OrderTrackingPage`: nút "📍 Xem vị trí tài xế" (mở Google Maps ngoài) đổi thành "🗺 Theo dõi trên bản đồ"; nếu mở lỗi thì quay về mở Google Maps.
- Bản đồ chọn địa chỉ (`BanDoPage`: tìm địa chỉ, vị trí của tôi, quán gần bạn) giữ nguyên.
- Hạn chế: chưa vẽ tuyến đường theo đường phố (chỉ nối thẳng); độ chính xác phụ thuộc Nominatim.
