# v30 – v29 + chức năng Quản trị viên bổ sung (từ gói v27)

Đối chiếu bản mô tả "Chức năng Quản trị viên" (15 mục) với mã nguồn. Phần lớn đã có sẵn (dashboard, duyệt gian hàng/tài xế,
đơn hàng, điều phối, thanh toán & hoàn tiền, khuyến mãi gồm giới hạn lượt theo khách, đánh giá/khiếu nại, cấu hình phí,
9 loại báo cáo CSV, thông báo theo nhóm, nhật ký, phiên đăng nhập, sao lưu). Các phần dưới đây là chỗ còn thiếu và đã được bổ sung.
Không đổi cấu trúc CSDL (dùng bảng/cột sẵn có), không cần chạy thêm script SQL.

## Đã bổ sung
| Mục trong mô tả | Thêm mới | File |
|---|---|---|
| 5. Tài xế: xem đơn đã nhận, lịch sử giao, hiệu suất, tỷ lệ hoàn thành / giao thất bại, online-offline | Trang hồ sơ tài xế `QuanTri/TaiXe/ChiTiet/{id}` (nút "Chi tiết" ở danh sách) | `AdminTaiXeController.ChiTiet`, `Views/AdminTaiXe/ChiTiet.cshtml` |
| 5. Tài xế: kiểm tra / tạo điều chỉnh thu nhập | Ghi thưởng, phụ cấp, phạt, điều chỉnh (bắt buộc lý do, tối đa 5.000.000đ, chỉ Admin tổng, thông báo cho tài xế). Bảng `DieuChinhThuNhap` trước đây chỉ có tài xế đọc, chưa có nơi tạo | `AdminTaiXeController.GhiDieuChinh` |
| 5, 8, 14. Xử lý phản ánh liên quan đến tài xế | Trang `QuanTri/SuCoTaiXe`: xem sự cố tài xế báo (kể cả sai lệch thu nhập/COD), chuyển "đang xử lý", đóng kèm kết quả, thông báo lại cho tài xế. Có số chờ xử lý ở chuông và menu | `AdminSuCoTaiXeController`, `Views/AdminSuCoTaiXe/Index.cshtml` |
| 6. Quản lý danh mục món ăn | Trang `QuanTri/DanhMuc`: lọc theo gian hàng, đổi tên, ẩn/hiện, xóa danh mục trống (không nằm trong khuyến mãi); bắt buộc lý do và thông báo cho gian hàng | `AdminDanhMucController`, `Views/AdminDanhMuc/Index.cshtml` |
| 3. Xử lý yêu cầu thay đổi hoặc xóa dữ liệu | Trong hồ sơ khách: cập nhật họ tên/SĐT/email theo yêu cầu (kiểm tra trùng SĐT, đổi email/SĐT thì phải xác thực lại); xóa dữ liệu = ẩn danh hồ sơ + xóa địa chỉ + khóa tài khoản + thu hồi phiên (gõ XOA để xác nhận, chặn khi còn đơn đang xử lý, giữ đơn hàng làm chứng từ). Chỉ Admin tổng | `AdminKhachHangController.CapNhatThongTin / AnDanhDuLieu`, `Views/AdminKhachHang/ChiTiet.cshtml` |

Menu: thêm "Danh mục món ăn" (nhóm Đơn hàng) và "Sự cố tài xế báo" (nhóm Hỗ trợ) trong `_AdminLayout.cshtml`.

## Chưa làm / cần cân nhắc
- "Theo dõi món bị báo cáo" (mục 6): hiện chỉ có báo cáo đánh giá, chưa có khách báo cáo riêng một món; cần thêm bảng/cột mới.
- "Quản lý phương tiện" của tài xế: mới xem được loại xe/biển số ở hồ sơ, chưa có chỗ sửa hoặc xác minh riêng.
- Xóa dữ liệu khách chưa động tới nội dung phản hồi/khiếu nại khách đã viết và địa chỉ đã lưu trong từng đơn cũ (giữ làm chứng từ).

## Lưu ý
Chưa build được trong môi trường này (không có .NET SDK / NuGet). Đã kiểm tra cân bằng cú pháp và đối chiếu tên entity, DbSet, thuộc tính;
cần chạy `dotnet build` và thử từng trang trên máy.

## Cách gộp vào v29
- Nền: FoodApp_v29 (giữ nguyên toàn bộ MAUI, API, SQL và giao diện tài xế XANH EXPRESS của v29).
- Chỉ thêm phần Web quản trị của gói v27 (10 file: 3 controller mới/sửa, 3 view mới, 3 view sửa, `_AdminLayout.cshtml`). v29 không sửa các file này nên không có xung đột.
- KHÔNG đưa phần giao diện tài xế MAUI của gói v27 vào: v29 đã có bản giao diện tài xế mới hơn (thay `DriverBottomBar` bằng `DriverNavBar`), ghi đè sẽ làm mất Ví, Cài đặt, Báo sự cố.
- Trang "Sự cố tài xế báo" dùng chung danh sách loại sự cố `DriverSuCoController.Loais` của v29 (13 loại, gồm quán chuẩn bị chậm, sai/thiếu món, vấn đề bàn giao...), nên khớp với app tài xế và phản hồi quản trị hiện lại ở màn Báo sự cố của tài xế.
- Chưa build được trong môi trường này (không có .NET SDK); cần `dotnet build` và thử từng trang trên máy.
