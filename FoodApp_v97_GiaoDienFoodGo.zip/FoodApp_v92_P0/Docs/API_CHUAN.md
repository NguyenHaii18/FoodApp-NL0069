# API chuẩn cho app mobile (v84)

App và website không nối thẳng SQL; mọi thao tác gọi Backend API. App vẫn viết đường dẫn cũ `api/mobile/...` ở các màn hình,
nhưng `Services/ApiChuan.cs` + `ApiClient` tự dịch sang đường dẫn chuẩn dưới đây. Máy chủ trả 403/404/405 cho đường dẫn chuẩn
thì app gọi lại đường dẫn cũ (chạy được với Web bản cũ). Tắt hẳn: `ApiChuan.Bat = false`.

| Phân hệ | Endpoint chuẩn | Đường dẫn cũ (vẫn dùng được) | Ghi chú |
|---|---|---|---|
| Đăng nhập | `POST /api/auth/login` | `POST api/mobile/{vai-tro}/dang-nhap` | Đã có ở Web; app giữ luồng cũ vì cần hồ sơ trả kèm |
| Đăng ký | `POST /api/auth/register` | `POST api/mobile/{vai-tro}/dang-ky` | như trên |
| Danh sách nhà hàng | `GET /api/restaurants` | `GET api/mobile/gian-hang` | app dùng |
| Chi tiết nhà hàng | `GET /api/restaurants/{id}` | `GET api/mobile/gian-hang/{id}` | app dùng |
| Danh sách món | `GET /api/restaurants/{id}/products` | `GET api/mobile/gian-hang/{id}/mon-an` | chỉ có ở Web; app khách tải toàn bộ món qua `api/mobile/mon-an` nên chưa dùng |
| Tạo đơn | `POST /api/orders` | `POST api/mobile/don-hang` | app dùng |
| Chi tiết đơn | `GET /api/orders/{id}` | `GET api/mobile/don-hang/{id}` | chỉ có ở Web; app lấy qua danh sách đơn |
| Hủy đơn | `POST /api/orders/{id}/cancel` | `PUT api/mobile/don-hang/{id}/huy` | app dùng |
| Nhà hàng xác nhận | `POST /api/restaurant/orders/{id}/confirm` | `PUT api/mobile/don-hang/{id}/xac-nhan` | app dùng |
| Nhà hàng báo món xong | `POST /api/restaurant/orders/{id}/ready` | `PUT api/mobile/don-hang/{id}/san-sang-giao` | app dùng |
| Tài xế bật nhận đơn | `POST /api/driver/availability` | `PUT api/mobile/tai-xe/trang-thai` | body `{trangThai: SanSang/TamNghi/NgoaiTuyen}` |
| Tài xế cập nhật vị trí | `POST /api/driver/location` | `PUT api/mobile/tai-xe/vi-tri` | app dùng |
| Tài xế nhận đơn | `POST /api/driver/orders/{id}/accept` | `PUT api/mobile/tai-xe/don-hang/{id}/nhan` | route đã có sẵn ở `DriverApiController` |
| Xác nhận lấy món | `POST /api/driver/orders/{id}/pickup` | `PUT api/mobile/don-hang/{id}/da-lay-hang` | giữ `?maDon=` |
| Xác nhận giao hàng | `POST /api/driver/orders/{id}/complete` | `PUT api/mobile/don-hang/{id}/hoan-thanh` | route đã có sẵn ở `DriverApiController` |
| Theo dõi đơn | `GET /api/orders/{id}/tracking` | `GET api/mobile/don-hang/{id}/vi-tri` | app dùng |
| Báo cáo doanh thu | `GET /api/admin/reports/revenue?ky=Ngay, Thang hoặc Nam` | `GET api/mobile/admin/bao-cao` | app dùng |

Phía Web chỉ thêm route bí danh (`[HttpGet/Post("~/api/...")]`) lên các action hiện có, nên logic, quyền (JWT + vai trò) và dữ liệu trả về không đổi.
Chưa build/chạy thử (không có .NET SDK).
