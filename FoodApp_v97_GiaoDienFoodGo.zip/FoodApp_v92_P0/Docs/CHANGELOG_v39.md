# v39 — v38 + quán chọn tài xế của quán / shipper ngoài

Gộp vào v38 (không đổi gì khác). Chưa build/chạy (không có .NET SDK / SQL Server) — cần build và thử.

- So sánh với FoodApp_v35: phần app MAUI của v35 là bản cũ hơn v38 (mọi khác biệt đều đã được v38 cải tiến/sửa, vd. lỗi CS0102 `CoHanPhanHoi`), nên không có gì cần chép thêm cho mobile.
- Thêm tính năng người giao: xem `NGUON_GIAO_HANG_v31.md` (cột `TaiXe.MaGianHang`, `GianHang.CheDoGiao`, `DonHang.NguonGiao`; **chạy `FoodService_NangCap.sql`**).
- Điều phối của app Quản trị (`AdminMobileApiController`) cũng áp quy tắc mới: chỉ liệt kê shipper ngoài, đơn của quán chỉ gán tài xế của chính quán.
- Web của gói v35 có mấy thứ v38 không có (không thuộc mobile, CHƯA gộp): trang Thông báo web cho tài xế (`DriverThongBaoController`), chế độ tối web (`wwwroot/css/dark.css`), theo dõi lượt bấm banner (`CustomerBannerController`).
