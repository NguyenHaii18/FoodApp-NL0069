# v76 — Tìm kiếm và lọc (nền: v75)
Chưa build/chạy (không có .NET SDK) — cần Build trên máy. Không cần SQL/máy chủ mới.

| Yêu cầu | Trạng thái |
|---|---|
| Tìm quán theo tên / món theo tên | Có sẵn (ô tìm kiếm + giọng nói; khớp không dấu; hiện "Món khớp") |
| Loại món / ẩm thực | Có sẵn (chip loại + chọn danh mục món) |
| Khu vực | Có sẵn |
| Khoảng giá, đánh giá, khoảng cách | Có sẵn |
| Thời gian giao dự kiến | MỚI: bộ lọc "Trong 20/30/45/60 phút" (dùng đúng số phút hiện trên thẻ quán; quán chưa có ước tính bị loại khi bật lọc) |
| Đang mở cửa | Có sẵn (công tắc + nút nhanh ở Trang chủ) |
| Sắp xếp phổ biến / giá / đánh giá | Có sẵn; đổi nhãn "Bán chạy" → "Phổ biến (bán chạy)" |
| Lưu lịch sử tìm kiếm | Có sẵn |
| Xóa lịch sử | Có sẵn "Xóa lịch sử" (tất cả); MỚI: nút ✕ xóa từng từ khóa |

Mã: `Services/TimKiemService.cs` (PhutToiDa, XoaMotLichSu), `Views/TrangChuPage.xaml(.cs)`.
