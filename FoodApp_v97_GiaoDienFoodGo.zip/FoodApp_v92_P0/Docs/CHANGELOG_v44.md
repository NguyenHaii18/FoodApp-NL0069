# v44 – v43 + hai chức năng quản trị mobile còn thiếu

Nền: FoodApp_v43. v43 đã chứa toàn bộ v42_8 (v42_4 là bản cũ hơn v42_8: thiếu bản sửa gõ tiếng Việt trên Windows, bản sửa trigger SQL và khóa an toàn trong NghiemThu_SaoLuu) nên không cần gộp thêm từ v42_4/v42_8.
Chưa build/chạy (không có .NET SDK/SQL Server); đã kiểm tra cân bằng ngoặc, tên route, tên lớp và chữ ký hàm dùng lại của v43.

## Kiểm tra 3 file mẫu bạn gửi
- `FoodService_ThemGianHangMau.sql`, `TAI_KHOAN_MAU_BO_SUNG.md`: giống hệt bản đã có trong v43.
- `TAI_KHOAN_GIAN_HANG_MAU.md`: bản trong v43 mới hơn (có ghi chú dữ liệu ngoại tuyến gh21–gh30) → giữ bản v43.

## Thêm mới (đối chiếu 15 mục "Chức năng Quản trị viên": v43 đã phủ gần hết, còn thiếu 2 mục)
- **Sự cố tài xế** (mục 5, 11): `GET api/mobile/admin/su-co-tai-xe?trangThai=`, `PUT .../su-co-tai-xe/{id}/xu-ly` (chuyển đang xử lý; đóng sự cố bắt buộc ghi kết quả; tài xế nhận thông báo). Màn hình `AdminDriverIssuesPage` (tab Chờ xử lý / Đang xử lý / Đã xử lý / Tất cả).
- **Gửi thông báo hệ thống** (mục 14): `POST api/mobile/admin/thong-bao` (tất cả / khách / gian hàng / tài xế / nhóm tên đăng nhập; cần quyền ThongBao), `GET .../thong-bao/gan-day`. Màn hình `AdminNotifyPage`.
- Controller mới `AdminMobileExtraApiController` (không đụng `AdminMobileApiController`); trang mới ở `Views/AdminPages3.cs` dùng lại `AdminListPage`/`AdminUi` của v43; thêm 2 mục vào `AdminHubPage` và 2 route trong `AppShell.xaml.cs`.
- Không cần chạy SQL mới (dùng bảng SuCoGiaoHang, ThongBao sẵn có).

## Còn thiếu so với danh sách quản trị (chưa làm)
- Quản lý phiên đăng nhập / thu hồi phiên trên mobile; yêu cầu bổ sung hồ sơ gian hàng/tài xế; xử lý yêu cầu dữ liệu cá nhân và báo cáo vi phạm; phí giao theo khu vực; xuất CSV trên mobile.
- Tài liệu (khóa luận/slides) chưa cập nhật cho các chức năng v38–v44 (chiến dịch quảng cáo, người giao quán, trung tâm vận hành, ảnh bìa, thời gian chuẩn bị, món nổi bật, quản trị mobile mới).
