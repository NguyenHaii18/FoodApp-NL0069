# v33 – bổ sung phân hệ Khách hàng và Gian hàng (nền: v32)

Đối chiếu bản mô tả "Phân hệ khách hàng" (A–E) và "Phân hệ nhà hàng / gian hàng" (A–E) với mã nguồn. Phân hệ khách đã đầy đủ gần hết
(đăng ký/đăng nhập, quên mật khẩu OTP, sổ địa chỉ, lịch sử đăng nhập + thu hồi phiên, tìm/lọc/sắp xếp, tùy chọn món, giỏ hàng, mã giảm giá,
COD + VNPay, theo dõi đơn + vị trí tài xế, hủy đơn, xác nhận nhận hàng, mua lại, hoàn tiền, đánh giá, khiếu nại, thông báo). Phần dưới đây là chỗ còn thiếu
đã được bổ sung. Không đổi cấu trúc CSDL (dùng bảng/cột sẵn có).

## Gian hàng (cổng web)
| Mục trong mô tả | Thêm mới |
|---|---|
| B. Thêm, sửa, xóa danh mục | Trang **Danh mục** (`/DanhMuc`): thêm, đổi tên, xóa danh mục trống (chặn khi còn món hoặc nằm trong khuyến mãi). Trước đây chỉ tạo được danh mục ngay trong form món. |
| B. Quản lý topping, kích cỡ, tùy chọn | Trang **Tùy chọn món** (`/TuyChon?maMonAn=`, nút "Tùy chọn" ở Thực đơn): Kích cỡ / Topping / Mức cay, giá thêm 0–500.000đ, tối đa 30 tùy chọn/món. Trước đây không có chỗ nào tạo `TuyChonMon` nên khách không thấy tùy chọn nào ngoài dữ liệu mẫu. |
| C. Xác nhận hoặc từ chối đơn, ghi rõ lý do | Từ chối/hủy đơn trên web **bắt buộc nhập lý do** (≥ 5 ký tự), lưu vào `LyDoTuChoi` và gửi cho khách; trước đây tự ghi "Gian hàng hủy đơn". |
| D. Theo dõi lượt sử dụng mã giảm giá | Bảng Khuyến mãi có cột **Đã dùng / tối đa**. |
| D. Xem đánh giá và phản hồi khách hàng, tiếp nhận khiếu nại | Trang **Đánh giá** (`/DanhGiaQuan`): điểm trung bình, lọc theo sao, **trả lời đánh giá** (khách nhận thông báo), danh sách phản hồi/khiếu nại liên quan đến quán (chỉ xem; Quản trị xử lý). Chỉ hiện tên gọi của khách. |
| E. Thống kê ngày/tuần/tháng, giá trị đơn trung bình, phí nền tảng, thực nhận, hoàn tiền & hủy, xuất báo cáo | Trang **Doanh thu** chọn kỳ Hôm nay / Tuần / Tháng; thêm giá trị đơn trung bình, bảng thực nhận (tiền hàng − phí nền tảng theo tỷ lệ chiết khấu của quán, cùng công thức báo cáo của Quản trị), số đơn hủy, yêu cầu hoàn tiền và tổng đã duyệt hoàn, nút **Xuất CSV** theo kỳ đang xem. |

## Khách hàng
| Mục | Thêm mới |
|---|---|
| B. Sắp xếp theo thời gian giao | Tùy chọn **Giao nhanh nhất** ở trang chủ web; thẻ quán hiện "⏱ ~N phút" (cùng công thức app: 20 km/h + 3 phút, tối thiểu 5 phút). Cần cho phép vị trí như "Gần nhất". |

## Chưa làm (cần đổi CSDL hoặc quyết định nghiệp vụ)
- Gian hàng đánh dấu món nổi bật/bán chạy: hiện chỉ có "bán chạy" tính tự động; cần thêm cột trên `MonAn`.
- Ảnh bìa riêng cho quán (hiện chỉ một ảnh): cần thêm cột trên `GianHang`.
- Gian hàng nhập ước tính thời gian chuẩn bị cho từng đơn: `ThoiGianDuKienPhut` hiện là thời gian giao do hệ thống tính.
- Khách chọn thời gian giao hẹn và phụ phí trên web: web chưa có (app MAUI có hẹn giờ cục bộ nhưng cột này chưa có ở máy chủ).
- Khiếu nại có loại riêng "thiếu món / giao sai món": hiện khách gửi qua Khiếu nại (chữ tự do); và nút "thanh toán lại" cho đơn VNPay thất bại.
- Khách "tìm theo vị trí" đã có (Gần tôi, khu vực, bán kính); chưa kiểm tra riêng phần MAUI cho các mục mới ở trên.

## Lưu ý
Chưa build/chạy thử (không có .NET SDK/SQL Server ở nơi sửa): cần `dotnet build` và thử từng trang. Các trang mới nằm trong cổng gian hàng nên cần đăng nhập
bằng tài khoản gian hàng đã được duyệt.
