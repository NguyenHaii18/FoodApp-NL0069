# Cập nhật giao diện khách hàng – FoodMart

- Chuyển giao diện khách hàng sang bảng màu xanh lá, trắng và xanh bạc hà, lấy cảm hứng từ ngôn ngữ thiết kế Xanh SM nhưng giữ nguyên thương hiệu FoodMart.
- Thêm bộ theme riêng cho 20 trang khách hàng để không thay đổi bảng màu gốc của màn hình quản trị.
- Làm mới phần đầu trang chủ: vị trí giao hàng, thông báo/tài khoản, nhận diện FoodMart, ô tìm kiếm và lối tắt bản đồ.
- Thêm thẻ giới thiệu “Món ngon mỗi ngày” trước danh mục; đồng nhất góc bo, màu viền, nút và nền cho danh mục, gian hàng, thanh toán, đơn hàng, ví, hồ sơ và các trang khách hàng liên quan.
- Đổi thanh điều hướng khách hàng và màu màn hình khởi động sang xanh lá.
- Giữ nguyên các tên điều khiển và event handler đã có để các luồng tìm kiếm/lọc, xem gian hàng, giỏ hàng, thanh toán, hồ sơ và thông báo tiếp tục được gọi như trước.
- Cập nhật các thành phần được tạo trong C# để lấy màu từ tài nguyên của chính trang khách hàng, tránh sót màu tím ở những khu vực động.

## Kiểm tra

- Đã kiểm tra cú pháp XML của các file XAML và dự án.
- Chưa chạy được build .NET MAUI trong môi trường chỉnh sửa vì không có `dotnet` SDK cài sẵn ở đây. Nên mở solution trên máy phát triển và chạy build trước khi phát hành.

## Làm lại giao diện theo mẫu FoodMart (10 màn hình)
- **Trang chủ (TrangChuPage):** header xanh bo góc dưới (địa chỉ giao đến, chuông, tài khoản, thương hiệu FoodMart + tài xế, ô tìm kiếm bo tròn có lối tắt bản đồ); lưới danh mục tròn 5 cột (viền xanh ở mục đang chọn); banner "Ưu đãi mỗi ngày – Giảm đến 50%" (nút "Xem ngay" sao chép mã ưu đãi đầu tiên đang dùng được); danh sách nhà hàng dạng thẻ có ảnh bo góc, ★ điểm, khoảng cách/thời gian, giá và nhãn giảm giá; "Xem tất cả" xóa bộ lọc.
- **Thực đơn gian hàng (MenuCartPage):** header xanh bo góc dưới, thẻ món trắng bo góc với nút "+" tròn xanh, nút xem giỏ hàng lớn.
- **Giỏ hàng / thanh toán (PaymentPage):** tiêu đề mục rõ hơn, dòng món có ảnh, tổng cộng xanh cỡ lớn, nút Đặt hàng lớn.
- **Đơn hàng của tôi (OrderTrackingPage):** thẻ đơn có ảnh món, mã đơn, tên quán, tổng tiền, nhãn trạng thái và thời gian (Hôm nay/Hôm qua); các thao tác hủy, đánh giá, đặt lại, theo dõi tài xế giữ nguyên.
- **Ví (WalletPage):** thẻ số dư xanh + nút Nạp tiền, 3 lối tắt (Chuyển tiền, Rút tiền, Lịch sử), "Ưu đãi của bạn" lấy từ khuyến mãi thật (nút Sử dụng sao chép mã), mục thêm thẻ ngân hàng.
- **Tài khoản (ProfilePage):** hồ sơ có ảnh đại diện, nhãn xác thực, thống kê; danh sách mục có icon tròn. "Thông tin cá nhân", "Thanh toán mặc định", "Ưu đãi của tôi" gập/mở khi chạm. Mọi chức năng cũ (lưu hồ sơ, đổi ảnh, xác thực email, đổi mật khẩu, xóa tài khoản, đăng xuất) giữ nguyên.
- **Thông báo (ActivityPage, tab "Thông báo"):** thanh lọc Tất cả / Đơn hàng / Khuyến mãi / Hệ thống, dòng thông báo có icon tròn, giờ bên phải, chấm xanh cho mục chưa đọc.

### Chưa làm / khác mẫu
- Số dư ví vẫn là 0đ và các nút Nạp/Chuyển/Rút/Lịch sử/Thêm thẻ hiện chỉ báo "chưa kết nối" (app chưa có API ví).
- Thanh tab dưới giữ nguyên 5 mục (Trang chủ, Đơn hàng, Thông báo, Ví tiền, Tin nhắn); mẫu dùng 4 mục (Trang chủ, Đơn hàng, Ưu đãi, Tài khoản).
- Chưa có trang "Danh mục" riêng, màn hình "Đang giao hàng" có bản đồ và giỏ hàng có nút +/− số lượng như mẫu.
- Chưa build được .NET MAUI trong môi trường chỉnh sửa; cần mở solution và build trước khi phát hành.
