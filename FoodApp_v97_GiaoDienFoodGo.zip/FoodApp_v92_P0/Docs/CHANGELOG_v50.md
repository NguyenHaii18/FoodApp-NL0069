# v50 – v49 + toàn bộ chức năng còn thiếu từ FoodApp_v48.zip và FoodApp_v47f_GopTatCa.zip

Nền: v49 (v47e + ảnh món/quán mẫu + sổ địa chỉ đồng bộ). Cả hai file bạn gửi đều xuất phát từ v47e nên gộp ba chiều (gốc = v47e); không có hunk nào bị từ chối.

## Từ v47f (CHANGELOG_v47f_GopV46.md)
- Đánh giá 3 điểm (món ăn / quán / tài xế): `ReviewPage`, cột `DanhGia.SoSaoMon` (có trong `FoodService_Database.sql` và `FoodService_NangCap.sql`), API `POST api/mobile/danh-gia` nhận `soSaoQuan`.
- Đặt lại đơn cũ từ lịch sử đơn (`OrderTrackingPage`), chuông 🔔 trang chủ mở Thông báo (`TrangChuPage`).

## Từ v48 (CHANGELOG_v48.md)
- Sửa script SQL: `FoodService_NghiemThu_SaoLuu.sql` (viết lại), `FoodService_Database.sql` (thêm `USE master` trước chốt an toàn), `BaoMat_VoHieuHoaTaiKhoanMau.sql`, `FoodService_ThemGianHangMau.sql` (SQL động trong con trỏ).
- Endpoint mobile mới/bí danh: `/api/auth/*`, `/api/mobile/gian-hang/{id}[/mon-an]`, `/api/mobile/mon-an/{id}`, `/api/mobile/don-hang[/{id}]`, `/api/mobile/thanh-toan`, `/api/mobile/don-hang/{id}/tin-nhan`, `/api/mobile/khach-hang/dia-chi`, `/api/mobile/driver/...`, `/api/mobile/tai-xe/thu-nhap` (mới `DriverThuNhapApiController`); tài liệu `API_MOBILE.md`.

## Điều chỉnh khi gộp
- `FoodService_ThemGianHangMau.sql`: giữ phần viết lại của v48 và nối lại khối ảnh + 2 món cho Bún Chả Hương Liên (từ v44) ở cuối.
- `CustomerApiController.cs`: có cả các endpoint của v48 và `PUT addresses/{id}` (sửa địa chỉ, v49).
- Changelog trùng tên `CHANGELOG_v48.md`: bản ảnh mẫu của mình đổi thành `CHANGELOG_v48_AnhMau.md`; `CHANGELOG_v48.md` là của bạn.
- Đã kiểm tra: route API không trùng, không trùng thành viên/phương thức, 254 file C# cân bằng ngoặc, XAML hợp lệ.

Chưa build/chạy (không có .NET SDK/SQL Server). Cần chạy lại các script SQL trên CSDL thử nghiệm (CSDL cũ thiếu cột và LocalDB).
