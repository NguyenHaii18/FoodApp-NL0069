# v69 — Thu nhập & đối soát cho app tài xế (nền v68)

Chưa build/chạy (không có .NET SDK/SQL Server). Đã kiểm tra: XAML hợp lệ, ngoặc C# cân bằng, không có thành viên trùng tên trong cùng lớp. Không cần chạy thêm SQL.

## Đối chiếu 9 mục yêu cầu với v68
| # | Mục | Hiện trạng v68 | v69 |
|---|---|---|---|
| 1 | Thu nhập từng chuyến | Chỉ có dòng "đơn trong kỳ" tính trên máy (dữ liệu mẫu), không lấy từ máy chủ | **Mới**: danh sách từng chuyến từ máy chủ (phí giao, giờ giao, trạng thái trả, tiền thu hộ) |
| 2 | Tổng theo ngày/tuần/tháng | Có (tính trên máy) | Số liệu thật từ máy chủ + thanh tổng Hôm nay / Tuần này / Tháng này |
| 3 | Thưởng và phụ cấp | Chỉ hiện **bảng quy tắc** cố định | **Mới**: khoản thưởng/phụ cấp thật của tài xế trong kỳ |
| 4 | Lịch sử giao hàng | Có (Đơn của tôi + lịch sử trong Thu nhập) | Giữ nguyên |
| 5 | Tiền mặt thu từ khách | Chỉ có số cần nộp | **Mới**: đã thu 30 ngày, đang cầm (đơn đang giao chưa thu), cần nộp |
| 6 | Đối soát COD | Có `DriverCodPage` | Giữ nguyên; nối từ trang mới |
| 7 | Điều chỉnh / khấu trừ | **Chưa có** trên app | **Mới**: danh sách điều chỉnh (+/−), phạt, lý do, trạng thái |
| 8 | Lịch thanh toán | **Chưa có** | **Mới**: chu kỳ, ngày thanh toán tới (còn bao nhiêu ngày), khoản chờ nền tảng trả / đã được trả (30 ngày) |
| 9 | Gửi yêu cầu khi sai lệch | Có nút chung → trang báo sự cố | Thêm báo **theo từng khoản/chuyến** (chạm → "Báo sai lệch khoản này"), mở sẵn loại `SaiLechThuNhap` và mã đơn |

## Thay đổi
**Máy chủ**
- `Services/DriverThuNhapApi.cs` + `GET api/mobile/tai-xe/thu-nhap?ky=ngay|tuan|thang` (tài xế đăng nhập). Cùng quy tắc với trang web "Thu nhập & COD": phí giao từng chuyến; giao thất bại do khách (`TinhPhiThatBai`) vẫn được phí giao và hiển thị riêng; đơn hủy không tính; thưởng/phụ cấp/phạt/điều chỉnh từ `DieuChinhThuNhap` (dương = cộng, âm = trừ); trạng thái trả `ChoThanhToan`/`DaThanhToan`.
- Lịch thanh toán lấy từ cấu hình `TaiXe.NgayThanhToanThu` (1 = Thứ Hai … 7 = Chủ nhật; **mặc định Thứ Hai hằng tuần**). Đây là giá trị mặc định do bản này đặt ra, cần chỉnh theo chính sách thật (bảng `CauHinhHeThong`, không cần SQL nếu dùng mặc định).

**App**
- Trang mới `DriverThuNhapChiTietPage` (route đã đăng ký): chọn Ngày/Tuần/Tháng; tổng quan; tiền mặt; lịch thanh toán; từng chuyến; thưởng/phụ cấp/điều chỉnh/khấu trừ; nút gửi yêu cầu sai lệch.
- `DriverEarningsPage`: nút "📊 Thu nhập từng chuyến, khấu trừ & lịch thanh toán ›".

## Còn lại / lưu ý
- Trang mới cần kết nối máy chủ (không có chế độ ngoại tuyến).
- Màn Thu nhập cũ vẫn dùng số liệu tính trên máy (kèm bảng quy tắc thưởng cố định); chưa chuyển sang dữ liệu máy chủ để tránh làm lệch hai nguồn số — nên thống nhất ở bản sau.
- Chưa có thao tác "rút tiền/nhận thanh toán" thật: nền tảng trả theo lịch, app chỉ theo dõi.
