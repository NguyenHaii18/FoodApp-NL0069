# v90 – Sửa lỗi không gõ được tiếng Việt trong app

Nền: FoodApp_v89_DoiTac. Chưa chạy được app trong môi trường soạn nên nguyên nhân được xác định bằng đọc mã; nếu còn lỗi ở một màn hình cụ thể, ghi lại tên màn hình + hệ điều hành + bộ gõ (Unikey/Telex hay bàn phím Windows, Gboard...) để khoanh tiếp.

## Nguyên nhân tìm thấy
- Bản vá gõ tiếng Việt cũ (`MauiProgram.TatGoiYChu`, chỉ Windows) tắt gợi ý chữ / kiểm tra chính tả nhưng chỉ áp cho `Entry` và `Editor`.
- 36 chỗ trong app nhập chữ bằng `DisplayPromptAsync` (lý do từ chối, phản hồi, tên, địa chỉ, ghi chú, trang quản trị...). Trên Windows hộp thoại này tạo `TextBox` riêng trong ContentDialog nên **không được vá**, gõ Telex/VNI ở đó dễ nhân đôi/mất dấu.
- Ngoài ra danh sách bị lọc/dựng lại và tính phí giao ngay trong từng phím gõ, dễ làm bộ gõ mất đồng bộ.
- Đã kiểm tra và loại trừ: kiểu bàn phím của các ô nhập (không ô chữ nào dùng bàn phím số/điện thoại/email), font, regex/pattern ở web, mã đặt lại con trỏ/focus.

## Sửa
- `Views/NhapUi.cs`: `NhapAsync` (cùng chữ ký, cùng tên tham số với `DisplayPromptAsync`) mở trang nhập riêng dùng `Entry`/`Editor` của app (đã vá), nút Hủy/Back trả `null`. 36 lời gọi `DisplayPromptAsync` đã đổi sang `NhapAsync` (22 file, gồm `AdminUi.Hoi`, `DoiTacService`).
- `Services/TreTimKiem.cs`: làm trễ 280 ms sau phím cuối cho lọc danh sách trang chủ (tìm kiếm + khu vực), địa chỉ giao hàng (tính phí), nhật ký thao tác, danh sách quản trị và gian hàng.

## Lưu ý
- Hộp thoại nhập giờ là trang toàn màn hình thay vì hộp thoại nhỏ của hệ điều hành.
- Chưa build/chạy; cần thử gõ Telex/VNI ở: ô tìm kiếm trang chủ, địa chỉ giao hàng, các hộp nhập lý do (từ chối đơn, hủy đơn, khiếu nại).
