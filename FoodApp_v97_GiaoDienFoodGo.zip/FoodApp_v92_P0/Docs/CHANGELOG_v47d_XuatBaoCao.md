# v47d — app Quản trị: xuất báo cáo Excel

Chưa build/chạy (không có .NET SDK). Đối chiếu 9 luồng quản trị: đều đã có trên app; chỗ còn hạn chế là xuất báo cáo chỉ CSV.
- Nút **Xuất báo cáo** (Thống kê + trang báo cáo) giờ hỏi định dạng: **Excel (.xlsx)** hoặc CSV.
- Excel có 3 sheet: *Don hang* (từng đơn + tổng doanh thu hoàn thành), *Theo ngay* (số đơn/hoàn thành/hủy/doanh thu), *Theo quan* (xếp theo doanh thu).
- `Services/XlsxWriter.cs`: ghi .xlsx bằng Open XML thuần (System.IO.Compression), không thêm gói NuGet.
- Vẫn kiểm tra quyền `XemThongKe` và ghi nhật ký quản trị.
- Chưa có xuất PDF.
