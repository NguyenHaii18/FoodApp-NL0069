# Giao diện Gian hàng kiểu FoodGo (cam)

## Chung
- `Resources/Styles/VendorTheme.xaml`: bảng màu cam (Primary #F26A21), có chế độ nền tối. Gộp vào toàn bộ 13 trang `Vendor*` (đường dẫn gốc `/Resources/Styles/...`).
- `Views/VendorPalette.cs`: màu cam dùng trong code C# (thay cho `Application.Current.Resources`, vốn là màu tím chung).
- `Views/VendorNavBar.cs`: thanh tab dưới (Trang chủ · Đơn hàng · Món ăn · Doanh thu · Cá nhân) dùng chung cho 5 trang chính. Khi chuyển tab, app quay về Trang chủ rồi mở trang đích để ngăn xếp điều hướng không phình ra.
- Trang con (Thêm/Sửa món, Khuyến mãi, Đánh giá, Tài chính, Thông báo…) dùng thanh tiêu đề trắng, chữ đậm, nút quay lại cam.

## Từng trang
- **Trang chủ:** header cam bo góc "FoodGo – Gian hàng thông minh" + chuông (chấm đỏ số thông báo chưa đọc); thẻ gian hàng (ảnh, tên, chip Đang mở cửa, địa chỉ, công tắc Mở cửa / Nhận đơn); 3 chỉ số hôm nay (Đơn, Doanh thu có ▲▼ so với hôm qua, Đánh giá); banner "Tăng đơn – Tăng doanh thu" (mở trang Khuyến mãi); lưới 6 chức năng; danh sách đơn mới cần xác nhận.
- **Quản lý món:** tiêu đề, chip danh mục, thẻ món có ảnh bo góc, giá cam, trạng thái màu (xanh còn hàng / xám tạm ngừng / đỏ hết hàng), nút nổi "＋ Thêm món". Thêm `MonAn.TinhTrangMau` trong Models.cs.
- **Đơn hàng:** thẻ đơn có biểu tượng, mã đơn, giờ, nhãn trạng thái; mọi nút xử lý đơn giữ nguyên.
- **Doanh thu:** thẻ cam "Tổng doanh thu" + 3 chỉ số (đơn hoàn thành, giá trị TB, lợi nhuận); biểu đồ xu hướng, báo cáo đơn và món bán chạy giữ nguyên.
- **Cá nhân:** đầu trang cam (ảnh, tên, trạng thái), 3 chỉ số (điểm đánh giá, lượt đánh giá, món đang bán), danh sách mục (Thông tin cửa hàng, Thực đơn, Đơn hàng, Khuyến mãi, Đánh giá, Tài chính, Thông báo, Đổi mật khẩu) và nút Đăng xuất. Form chỉnh sửa hồ sơ cũ nằm trong mục "Thông tin cửa hàng" (chạm để mở).
- **Thông báo:** biểu tượng tròn cam nhạt, giờ màu cam.

## Chưa làm / khác mẫu
- Chưa có tính năng Kho & Nguyên liệu, Quản lý nhân viên, Cài đặt (app chưa có dữ liệu cho chúng); lưới chức năng dùng Đánh giá và Tài chính thay thế.
- Chưa làm: màn Chi tiết đơn hàng riêng, Theo dõi đơn có bản đồ, ô tìm món, công tắc bật/tắt bán ngay trên dòng món (đang dùng nút "Tình trạng").
- Biểu đồ cột doanh thu theo ngày vẫn là biểu đồ cũ trong code.
- Chưa build được .NET MAUI trong môi trường chỉnh sửa.
