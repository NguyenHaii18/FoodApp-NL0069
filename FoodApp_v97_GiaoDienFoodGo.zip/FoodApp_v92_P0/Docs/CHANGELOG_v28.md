# v28 – Rà soát v27 + cập nhật tài liệu

## Rà soát tĩnh gói v27 (không có .NET SDK / SQL Server nên CHƯA build, CHƯA chạy SQL)
Đã kiểm tra, không thấy lỗi thật:
- Entity (Web) so với FoodService_Database.sql: mọi bảng và cột đều có (kể cả cột thêm bằng ALTER).
- FoodService_NangCap.sql: 131 cặp bảng–cột đều có trong FoodService_Database.sql; không có bảng nào chỉ nằm ở NangCap.
- XAML (MAUI): tất cả file đều hợp lệ; handler Clicked/Tapped/... khớp code-behind; route GoToAsync đều đã đăng ký trong AppShell.
- API: mọi đường dẫn api/... mà app MAUI gọi đều có route trong Web (128 route); Razor asp-controller/asp-action không tham chiếu sai; mọi khóa cấu hình dùng trong code đều có trong SQL; các service inject đều đã đăng ký DI.
- Không phát hiện kiểu lỗi CS0136 (trùng tên biến trong phạm vi lồng nhau) theo kiểm tra heuristic.
Các cảnh báo từng thấy đều là báo nhầm (chuỗi chứa "//" hay chuỗi thô """ trong BanDoPage làm lệch đếm ngoặc; SoCCCD so với SoCccd khác hoa/thường).
Giới hạn: kiểm tra tĩnh không thay được việc build; hãy build và chạy thử trên máy.

## Tài liệu
- Khóa luận: bảng TaiXe thêm SoGplx/AnhGplx/AnhDaiDien/LyDoTuChoi/YeuCauBoSung; bảng mới CauHinhHeThong (3.17b), CauHinhHeThongLichSu (3.17c), SuCoGiaoHang (3.17d); danh sách màn hình thêm 6 dòng (Ưu đãi, Đơn của tôi, Báo sự cố, Hồ sơ tài xế, Phí và chính sách, Chính sách); nguyên tắc giao diện theo vai trò; màn hình Báo sự cố và Hồ sơ tài xế (Bảng 3.27b); mục 4.3.7 bổ sung giới hạn của app MAUI; mục 4.3.9 phí, chính sách, giới hạn voucher; cập nhật UC04, UC12, UC15. Mở Word, Ctrl+A rồi F9 để cập nhật mục lục/số trang.
- Slides: thêm slide 14 "Cập nhật mới: phiên bản v23 – v27".
