# v54 — Đối chiếu chức năng app tài xế (Mobile, chưa biên dịch)
Đã có sẵn: đăng ký/đăng nhập, hồ sơ + GPLX, bật/tắt online, nhận/từ chối đơn, GPS + chỉ đường, đến quán/kiểm tra mã đơn/lấy hàng, gọi/nhắn khách, mã 4 số + ảnh bằng chứng, giao thất bại (sai địa chỉ, không liên lạc được…), báo sự cố, thu nhập/thưởng/phụ cấp, đối soát COD, trợ giúp.
Mới:
- `Views/DriverPerformancePage.cs`: Tài khoản → "Hiệu suất của tôi" — số đơn, tỷ lệ giao thành công, đánh giá TB, thời gian giao TB (7 ngày / 30 ngày / tất cả).
- Hồ sơ tài xế: dòng "Hồ sơ giấy tờ x/4 mục" (CCCD, GPLX, ảnh GPLX, biển số).
Chưa làm: ảnh CCCD (server chưa có trường lưu), tìm nhà hàng trên bản đồ cho tài xế.
