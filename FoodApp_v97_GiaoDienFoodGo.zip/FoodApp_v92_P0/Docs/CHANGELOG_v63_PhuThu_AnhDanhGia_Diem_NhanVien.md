# v63 — Phụ thu topping/size, ảnh đánh giá, đổi điểm thành voucher, nhân viên cửa hàng

> Chưa biên dịch được (môi trường không có .NET SDK). Hãy build lại, sửa lỗi nhỏ nếu có, và **chạy `Database/FoodService_NangCap.sql`** trước khi chạy server (thêm cột `DanhGia.AnhDanhGia` và bảng `NhanVienGianHang`; chạy lặp lại an toàn).

## 1. Topping / size có phụ thu
**Server**
- `GET api/mobile/mon-an` trả thêm `tuyChon: [{id, loai, ten, giaThem}]` cho từng món.
- `POST api/mobile/don-hang`: mỗi dòng nhận thêm `tuyChonIds` và `ghiChu`. Server kiểm tra bằng `TuyChonHelper` (tối đa 1 size + 1 mức cay, món có size thì bắt buộc chọn size), tính **đơn giá = giá món + phụ thu**, dùng đơn giá này cho tổng tiền, khuyến mãi và `ChiTietDonHang.DonGia`; lưu `TuyChon` ("Lớn; Trân châu") và `GhiChu` của dòng.
- Đơn trả về (`chiTiet`) có thêm `donGia`, `tuyChon`, `ghiChu`.
- `POST api/mobile/khuyen-mai/kiem-tra` đã nhận `tuyChonIds` từ trước; app giờ gửi lên.

**App**
- `Chi tiết món`: Size / Mức cay chọn một (radio), Topping chọn nhiều (ô tick); size đầu tiên được chọn sẵn; giá và nút "Thêm vào giỏ" cập nhật ngay, hiện "gồm phụ thu".
- Giỏ hàng: cùng món nhưng khác tùy chọn là hai dòng riêng; thành tiền = (giá + phụ thu) × số lượng; hiển thị tùy chọn dưới tên món. Thêm nhanh từ thực đơn tự chọn size đầu tiên.
- Lưu giỏ (máy + server) kèm tên tùy chọn; "Đặt lại" từ đơn cũ khôi phục đúng tùy chọn.
- Thanh toán gửi `tuyChonIds`, `ghiChu` từng dòng. Token chống đặt trùng tính cả tùy chọn.

## 2. Ảnh trong đánh giá
- Cột mới `DanhGia.AnhDanhGia` (tối đa 3 đường dẫn, ngăn bởi `|`).
- `POST api/upload/danhgia` (ảnh ≤ 5MB, jpg/png/webp). `POST api/mobile/danh-gia` nhận `anh: []` (chỉ nhận đường dẫn `/uploads/danhgia/...`, tối đa 3) và `theNhanXet` (trước đây bị bỏ qua).
- Quán: `GET gian-hang/{id}/danh-gia` trả `anhDanhGia`. Quản trị: `GET admin/danh-gia` trả `anhDanhGia`.
- App khách: trang đánh giá chọn/chụp tối đa 3 ảnh, tải lên rồi gửi kèm.
- App quán: trang Đánh giá giờ lấy từ máy chủ khi online (kèm ảnh); chi tiết đánh giá hiện ảnh; phản hồi gửi lên máy chủ (`PUT .../phan-hoi`).

## 3. Đổi điểm thành voucher
- `GET api/mobile/khach-hang/diem`: điểm tích lũy (1.000đ = 1 điểm, đơn đã giao), đã đổi, còn lại, các mức đổi, voucher đã đổi.
- `POST api/mobile/khach-hang/diem/doi {diem}`: mức 50 → 10.000đ, 100 → 25.000đ, 200 → 60.000đ (đơn tối thiểu = 4× số giảm). Phát một mã ngẫu nhiên `DIEMxxxxxx` dùng 1 lần, hạn 30 ngày, mọi quán, **chỉ chủ tài khoản dùng được**.
- Không thêm bảng: voucher là một dòng `KhuyenMai` có `MoTa = "DOIDIEM|{maKH}|{điểm}"`; điểm đã đổi = tổng các voucher này. `KhuyenMaiXuLy` (và giỏ hàng web) từ chối mã của người khác; các danh sách khuyến mãi công khai/quản trị ẩn các mã này.
- Đổi điểm chạy tuần tự (khóa) để không đổi lố điểm.
- App: thẻ "Đổi điểm lấy voucher" trong Thành viên (chạm để sao chép mã). Cần online.

## 4. Nhân viên cửa hàng
**Server**
- Bảng `NhanVienGianHang` (MaNV, MaGianHang, TenDangNhap duy nhất, HoTen, MatKhau BCrypt, Quyen, TrangThai, ...).
- 5 quyền: `DonHang`, `ThucDon`, `KhuyenMai`, `DanhGia`, `TaiChinh`.
- Chủ quán: `GET/POST api/mobile/gian-hang/{id}/nhan-vien`, `PUT/DELETE .../{maNV}`, `PUT .../{maNV}/mat-khau` (tối đa 20 nhân viên/quán).
- Nhân viên: `POST api/mobile/gian-hang/nhan-vien/dang-nhap` (sai 5 lần khóa 10 phút), `GET api/mobile/nhan-vien/toi`, `PUT api/mobile/nhan-vien/mat-khau`.
- Token nhân viên mang MaTK của chủ quán + claim `nv` nên các API quán dùng chung. `NhanVienQuyenFilter` (bộ lọc toàn cục) kiểm tra mỗi request: nhân viên còn hoạt động, và đường dẫn nằm trong quyền được cấp. Hồ sơ quán, giấy tờ, quản lý nhân viên, tài khoản và mọi đường dẫn chưa liệt kê → mặc định **từ chối**. Khóa/đổi quyền có hiệu lực trong ≤ 15 giây.

**App**
- Đăng nhập quán: liên kết "Bạn là nhân viên cửa hàng?" chuyển sang đăng nhập bằng tên đăng nhập nhân viên.
- Trang chủ quán: nhân viên chỉ vào được mục có quyền (có thông báo khi thiếu quyền), không thấy Hồ sơ cửa hàng / Nhân viên; quyền tự làm mới khi mở trang.
- Chủ quán: nút "Nhân viên & phân quyền" → thêm, sửa quyền, đặt lại mật khẩu, khóa/mở khóa, xóa.

## Chưa làm / lưu ý
- Trang quản trị chỉ nhận `anhDanhGia` trong dữ liệu, chưa hiển thị ảnh trong danh sách kiểm duyệt.
- Tùy chọn do quán nhập trên app (`VendorMenuItemEditPage`) chưa thấy đồng bộ lên bảng `TuyChonMon` của máy chủ (mình chưa tìm thấy API ghi tùy chọn món) — nên khách chỉ thấy tùy chọn có phụ thu khi món có dữ liệu `TuyChonMon` trên server (thêm qua web quản lý món).
- Nhân viên đăng nhập cần kết nối máy chủ (không có chế độ ngoại tuyến).
