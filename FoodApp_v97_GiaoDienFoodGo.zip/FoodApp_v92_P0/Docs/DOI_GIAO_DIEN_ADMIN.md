# Đổi giao diện Quản trị (v37 → bản AdminUI)

Chưa biên dịch, chưa chạy thử (môi trường không có .NET SDK) — cần build và xem thực tế.

## Web
- `wwwroot/css/admin.css`: giao diện sáng kiểu Sneat, ô số liệu màu đặc kiểu Bootstrap, biểu tượng nền pastel.
- `Views/AdminDashboard/Index.cshtml`: thêm biểu đồ cột "Đơn theo trạng thái" và biểu đồ tròn "Thanh toán" (thuần CSS).

## App MAUI
- `Views/Admin*.xaml`: đổi bảng màu sang tím xanh #696CFF, nền #F5F5F9.
- `AdminHomePage.xaml(.cs)`: 4 thẻ thống kê đổi sang màu đặc (chữ trắng); thêm thẻ "Đơn theo trạng thái" dùng ProgressBar.
