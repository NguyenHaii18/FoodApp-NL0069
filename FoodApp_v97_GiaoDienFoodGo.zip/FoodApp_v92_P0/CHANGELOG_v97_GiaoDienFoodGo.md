# v97 — Giao diện FoodGo cho website
- Mới: Web/FoodServiceApp.Web/wwwroot/css/foodgo.css (sidebar tím đậm, thẻ KPI gradient, thẻ bo tròn, nền lavender).
- _AdminLayout.cshtml: thương hiệu FoodGo, khối "FoodGo Pro", nạp foodgo.css.
- _Layout.cshtml (Gian hàng): nạp foodgo.css, sidebar tím đậm.
- AdminDashboard/Index.cshtml: 4 thẻ KPI gradient (Tổng đơn, Tổng doanh thu, Nhà hàng, Tài xế), tiêu đề "Tổng quan hệ thống".
- Chưa build/chạy thật (không có .NET trong môi trường tạo). Cần `dotnet build` và xem trên trình duyệt.
