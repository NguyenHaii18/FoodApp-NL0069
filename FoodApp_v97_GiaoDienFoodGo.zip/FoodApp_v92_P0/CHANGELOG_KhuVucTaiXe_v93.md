# Khu vực chạy thường xuyên của tài xế (v93, đã gộp vào v94)

- Tài xế chọn nhiều quận trong Hồ sơ (app MAUI: các nút chọn; web: ô văn bản). Lưu vào TaiXe.KhuVucHoatDong (tối đa 150 ký tự).
- Server hiểu mọi cách viết: "Quận 1", "Q1", "Q.1", "q 1", "District 1", "Bình Thạnh"... (TP Thủ Đức = Q.2 + Q.9 + Thủ Đức) — Services/KhuVucHelper.cs.
- Điều phối (PhanPhoiDonXuLy): đơn có quán HOẶC địa chỉ giao thuộc quận tài xế đăng ký → tài xế được cộng điểm ưu tiên
  (khớp quận khách +0.6, khớp quận quán +0.4, cả hai +1.0) nên được gửi đề nghị TRƯỚC. Tài xế có đăng ký khu vực mà đơn ngoài khu vực thì không nhận (như trước).
  Tài xế không đăng ký = nhận mọi khu vực.
- Quán bấm xác nhận đơn → đánh thức bộ điều phối NGAY (không chờ chu kỳ quét 5 giây).
- Sửa: tài xế không có GPS (máy tính, giả lập, chưa cấp quyền vị trí) không còn bị loại khỏi phân phối; hệ thống ước tính khoảng cách theo khu vực.
- Gộp lại các sửa trước đó lên v93: size S/M/L cho món nước + quán chỉnh giá size, sửa lỗi SetAppThemeColor ở NhapUi.cs.

## v94 — Phần IX (app admin)
- Thêm trang "Thiếu sót Database & Backend" (Admin → Hệ thống): 12 hạng mục STT 94–105, kèm kết quả đối chiếu mã nguồn và ô đánh dấu đã khắc phục.
  Mobile_FoodApp.Maui/Views/AdminThieuSotBackendPage.cs (+ đăng ký route trong AppShell.xaml.cs, mục menu trong AdminPages2.cs).

## v94 — Phần X (app admin)
- Thêm trang "Thiếu sót kiểm thử & triển khai" (Admin → Hệ thống): 19 hạng mục STT 106–124 (build, test, CI/CD, staging, production, Android/iOS, monitoring, sự cố) kèm kết quả đối chiếu mã nguồn.
  Mobile_FoodApp.Maui/Views/AdminThieuSotKiemThuPage.cs (+ route trong AppShell.xaml.cs, mục menu trong AdminPages2.cs).
