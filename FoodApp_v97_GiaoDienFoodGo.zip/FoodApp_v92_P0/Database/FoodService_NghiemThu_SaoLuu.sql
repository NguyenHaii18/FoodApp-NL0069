﻿/* ============================================================
   FoodService_NghiemThu_SaoLuu.sql — gồm 2 phần:
   PHẦN A: NGHIỆM THU dữ liệu (dùng cùng Tools/NghiemThu_E2E.ps1 — script chỉ chạy PHẦN A, cắt ở dòng đánh dấu SAO_LUU_PHUC_HOI)
   PHẦN B: SAO LƯU / PHỤC HỒI (SQL Server Agent) — chạy thủ công trong SSMS, KHÔNG nằm trong luồng nghiệm thu
   ============================================================ */

/* ################ PHẦN A: NGHIỆM THU ################ */
/* NGHIỆM THU DỮ LIỆU sau khi chạy kịch bản end-to-end. Đặt @MaDon rồi chạy (SSMS hoặc Tools\NghiemThu_E2E.ps1).
   Mỗi dòng trả về KetQua = PASS/FAIL. Kết thúc bằng THROW nếu có FAIL (sqlcmd -b trả mã lỗi).
   ĐÃ SỬA (lỗi "Invalid column name 'MaDonHang' / 'TrangThai' / 'MaTaiXe' / 'MaXacNhanGiao' / 'SoLanSaiMa'"):
     - Trước đây các câu kiểm tra được biên dịch ngay; nếu CSDL đang mở là bản CŨ (thiếu cột) hoặc đang ở sai CSDL thì báo hàng loạt lỗi cột.
       Nay script (1) kiểm tra CSDL tồn tại, (2) kiểm tra đủ bảng/cột cần thiết bằng COL_LENGTH và DỪNG với danh sách còn thiếu
       + hướng dẫn chạy FoodService_NangCap.sql, (3) chỉ khi đủ mới chạy các câu kiểm tra (bằng SQL động, trong đúng CSDL).
     - Không dùng "USE" và không dùng SET NOEXEC, nên không còn lỗi biên dịch giả; chạy ở CSDL nào cũng được. */
SET NOCOUNT ON;
DECLARE @MaDon INT = NULL;   -- đặt mã đơn cần kiểm tra (NULL = đơn ĐÃ GIAO mới nhất)
DECLARE @Db sysname = N'QuanLyDichVuAnUong';

IF DB_ID(@Db) IS NULL
    THROW 50010, N'DỪNG: chưa có CSDL QuanLyDichVuAnUong. Chạy FoodService_Database.sql (máy mới) hoặc FoodService_NangCap.sql trước.', 1;

-- Các bảng/cột mà PHẦN A cần (CSDL cũ chưa chạy FoodService_NangCap.sql sẽ thiếu một số cột)
DECLARE @can TABLE (Bang sysname, Cot sysname NULL);
INSERT @can (Bang, Cot) VALUES
 (N'NhatKyHeThong', NULL),
 (N'ChiTietDonHang', NULL),
 (N'ChiTietDonHang', N'DonGia'),
 (N'ChiTietDonHang', N'MaDonHang'),
 (N'ChiTietDonHang', N'SoLuong'),
 (N'DanhGia', NULL),
 (N'DanhGia', N'MaDonHang'),
 (N'DanhGia', N'MaGianHang'),
 (N'DanhGia', N'MaKH'),
 (N'DanhGia', N'MaTaiXe'),
 (N'DonHang', NULL),
 (N'DonHang', N'MaDonHang'),
 (N'DonHang', N'MaGianHang'),
 (N'DonHang', N'MaKH'),
 (N'DonHang', N'MaTaiXe'),
 (N'DonHang', N'MaXacNhanGiao'),
 (N'DonHang', N'PhiGiaoHang'),
 (N'DonHang', N'SoLanSaiMa'),
 (N'DonHang', N'ThoiGianSanSang'),
 (N'DonHang', N'TienGiam'),
 (N'DonHang', N'TongTien'),
 (N'DonHang', N'TrangThai'),
 (N'DonHang', N'TrangThaiChuanBi'),
 (N'GiaoDichThanhToan', NULL),
 (N'GiaoDichThanhToan', N'MaDonHang'),
 (N'GiaoHang', NULL),
 (N'GiaoHang', N'MaDonHang'),
 (N'GiaoHang', N'ThoiGianGiao'),
 (N'GiaoHang', N'ThoiGianLayHang'),
 (N'GiaoHang', N'ThoiGianNhan'),
 (N'GiaoHang', N'TienThuCOD'),
 (N'GiaoHang', N'TrangThai'),
 (N'KhachHang', NULL),
 (N'KhachHang', N'MaKH'),
 (N'KhachHang', N'MaTK'),
 (N'LichSuGiaoHang', NULL),
 (N'LichSuGiaoHang', N'MaDonHang'),
 (N'LichSuTrangThaiDon', NULL),
 (N'LichSuTrangThaiDon', N'DenTrangThai'),
 (N'LichSuTrangThaiDon', N'MaDonHang'),
 (N'TaiXe', NULL),
 (N'TaiXe', N'MaTaiXe'),
 (N'TaiXe', N'TrangThai'),
 (N'TaiXeViTri', NULL),
 (N'TaiXeViTri', N'MaDonHang'),
 (N'ThanhToan', NULL),
 (N'ThanhToan', N'HinhThuc'),
 (N'ThanhToan', N'MaDonHang'),
 (N'ThanhToan', N'TrangThai'),
 (N'ThongBao', NULL),
 (N'ThongBao', N'MaTK'),
 (N'ThongBao', N'MaThamChieu');

DECLARE @thieu NVARCHAR(MAX) = N'';
SELECT @thieu = @thieu + N'  - ' + Bang + ISNULL(N'.' + Cot, N' (bảng)') + NCHAR(10)
FROM @can
WHERE (Cot IS NULL     AND OBJECT_ID(QUOTENAME(@Db) + N'.dbo.' + QUOTENAME(Bang), N'U') IS NULL)
   OR (Cot IS NOT NULL AND COL_LENGTH(QUOTENAME(@Db) + N'.dbo.' + QUOTENAME(Bang), Cot) IS NULL);
IF @thieu <> N''
BEGIN
    SET @thieu = N'DỪNG: CSDL chưa nâng cấp đủ, còn thiếu:' + NCHAR(10) + LEFT(@thieu, 1300)
               + N'=> SAO LƯU CSDL rồi chạy Database/FoodService_NangCap.sql (không xóa dữ liệu), sau đó chạy lại nghiệm thu.';
    THROW 50011, @thieu, 1;
END

IF OBJECT_ID('tempdb..#kq') IS NOT NULL DROP TABLE #kq;
CREATE TABLE #kq (Muc NVARCHAR(120), KetQua NVARCHAR(4), ChiTiet NVARCHAR(300));

-- Các câu kiểm tra chạy bằng SQL động trong đúng CSDL (bảng tạm #kq nhìn thấy được từ bên trong)
DECLARE @sql NVARCHAR(MAX) = N'DECLARE @tt NVARCHAR(20), @gh NVARCHAR(20), @tx INT, @ma NVARCHAR(10), @sai INT;
-- Mặc định nghiệm thu đơn MỚI NHẤT ĐÃ GIAO (ưu tiên đơn có đánh giá), không lấy đơn mới nhất bất kỳ (đơn đang dở sẽ FAIL oan).
IF @MaDon IS NULL SET @MaDon = (SELECT MAX(d.MaDonHang) FROM DonHang d WHERE d.TrangThai = N''DaGiao'' AND EXISTS (SELECT 1 FROM DanhGia g WHERE g.MaDonHang = d.MaDonHang));
IF @MaDon IS NULL SET @MaDon = (SELECT MAX(MaDonHang) FROM DonHang WHERE TrangThai = N''DaGiao'');
IF @MaDon IS NULL AND EXISTS (SELECT 1 FROM DonHang)
BEGIN
    RAISERROR(N''Chưa có đơn nào đã GIAO để nghiệm thu (các đơn hiện có đang dở). Hãy chạy hết luồng: đặt đơn → quán xác nhận → tài xế nhận → giao xong → khách đánh giá, rồi chạy lại.'', 16, 1);
    RETURN;
END
IF @MaDon IS NULL
BEGIN
    RAISERROR(N''Chưa có đơn hàng nào để nghiệm thu. Hãy chạy kịch bản end-to-end trước (đặt đơn → quán xác nhận → tài xế nhận → giao xong → khách đánh giá) rồi chạy lại.'', 16, 1);
    RETURN;
END
PRINT N''Đang kiểm tra đơn #'' + CAST(@MaDon AS NVARCHAR(20)) + N''. Mục FAIL xem ở tab Results (nhớ: đơn phải đi hết luồng tới DaGiao + có đánh giá thì mới PASS hết).'';
SELECT @tt = TrangThai, @tx = MaTaiXe, @ma = MaXacNhanGiao, @sai = SoLanSaiMa FROM DonHang WHERE MaDonHang = @MaDon;
INSERT #kq SELECT N''Đơn tồn tại và ở trạng thái DaGiao'', IIF(@tt = N''DaGiao'',''PASS'',''FAIL''), N''TrangThai='' + ISNULL(@tt,''NULL'');
INSERT #kq SELECT N''Đơn có tài xế'', IIF(@tx IS NOT NULL,''PASS'',''FAIL''), CAST(@tx AS NVARCHAR(20));

SELECT @gh = TrangThai FROM GiaoHang WHERE MaDonHang = @MaDon;
INSERT #kq SELECT N''Đúng 1 GiaoHang, trạng thái GiaoThanhCong'', IIF((SELECT COUNT(*) FROM GiaoHang WHERE MaDonHang=@MaDon)=1 AND @gh=N''GiaoThanhCong'',''PASS'',''FAIL''), ISNULL(@gh,''NULL'');
INSERT #kq SELECT N''GiaoHang có đủ mốc nhận/lấy/giao theo thứ tự'', IIF(EXISTS(SELECT 1 FROM GiaoHang WHERE MaDonHang=@MaDon AND ThoiGianNhan IS NOT NULL AND ThoiGianLayHang IS NOT NULL AND ThoiGianGiao IS NOT NULL AND ThoiGianNhan<=ThoiGianLayHang AND ThoiGianLayHang<=ThoiGianGiao),''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Quán đã báo sẵn sàng giao'', IIF(EXISTS(SELECT 1 FROM DonHang WHERE MaDonHang=@MaDon AND TrangThaiChuanBi=N''SanSangGiao'' AND ThoiGianSanSang IS NOT NULL),''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Đúng 1 ThanhToan'', IIF((SELECT COUNT(*) FROM ThanhToan WHERE MaDonHang=@MaDon)=1,''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''COD đã thu: ThanhToan=DaThanhToan và TienThuCOD = TongTien'', IIF(EXISTS(SELECT 1 FROM ThanhToan t JOIN DonHang d ON d.MaDonHang=t.MaDonHang JOIN GiaoHang g ON g.MaDonHang=d.MaDonHang WHERE d.MaDonHang=@MaDon AND t.HinhThuc=N''TienMat'' AND t.TrangThai=N''DaThanhToan'' AND g.TienThuCOD=d.TongTien),''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Tổng tiền = tiền món - giảm + phí giao'', IIF(EXISTS(SELECT 1 FROM DonHang d WHERE d.MaDonHang=@MaDon AND d.TongTien = (SELECT ISNULL(SUM(SoLuong * DonGia),0) FROM ChiTietDonHang WHERE MaDonHang=@MaDon) - ISNULL(d.TienGiam,0) + d.PhiGiaoHang),''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Có chi tiết đơn'', IIF(EXISTS(SELECT 1 FROM ChiTietDonHang WHERE MaDonHang=@MaDon),''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Lịch sử trạng thái đơn ghi đủ ChoXacNhan→DaXacNhan→DangGiao→DaGiao'', IIF((SELECT COUNT(DISTINCT DenTrangThai) FROM LichSuTrangThaiDon WHERE MaDonHang=@MaDon AND DenTrangThai IN (N''ChoXacNhan'',N''DaXacNhan'',N''DangGiao'',N''DaGiao''))=4,''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Lịch sử giao hàng ghi các bước'', IIF((SELECT COUNT(*) FROM LichSuGiaoHang WHERE MaDonHang=@MaDon)>=3,''PASS'',''FAIL''), CAST((SELECT COUNT(*) FROM LichSuGiaoHang WHERE MaDonHang=@MaDon) AS NVARCHAR(10));
INSERT #kq SELECT N''Sổ giao dịch thanh toán có dòng cho đơn'', IIF((SELECT COUNT(*) FROM GiaoDichThanhToan WHERE MaDonHang=@MaDon)>=1,''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Vị trí tài xế đã lưu'', IIF(EXISTS(SELECT 1 FROM TaiXeViTri WHERE MaDonHang=@MaDon),''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Số lần nhập sai mã <= 5 (không bị khóa)'', IIF(@sai<=5,''PASS'',''FAIL''), CAST(@sai AS NVARCHAR(10));
INSERT #kq SELECT N''Đánh giá gắn đúng khách/quán/tài xế'', IIF(EXISTS(SELECT 1 FROM DanhGia d WHERE d.MaDonHang=@MaDon AND d.MaTaiXe=@tx AND d.MaGianHang=(SELECT MaGianHang FROM DonHang WHERE MaDonHang=@MaDon) AND d.MaKH=(SELECT MaKH FROM DonHang WHERE MaDonHang=@MaDon)),''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Chỉ 1 đánh giá cho đơn'', IIF((SELECT COUNT(*) FROM DanhGia WHERE MaDonHang=@MaDon)=1,''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Khách có thông báo về đơn'', IIF(EXISTS(SELECT 1 FROM ThongBao tb JOIN KhachHang k ON k.MaTK=tb.MaTK JOIN DonHang d ON d.MaKH=k.MaKH WHERE d.MaDonHang=@MaDon AND tb.MaThamChieu=CAST(@MaDon AS NVARCHAR(20))),''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Tài xế trở lại SanSang (không kẹt DangGiao)'', IIF(EXISTS(SELECT 1 FROM TaiXe WHERE MaTaiXe=@tx AND TrangThai IN (N''SanSang'',N''NgoaiTuyen'')),''PASS'',''FAIL''), ISNULL((SELECT TrangThai FROM TaiXe WHERE MaTaiXe=@tx),'''');
INSERT #kq SELECT N''Thu nhập: chuyến này tính vào doanh thu tài xế (GiaoThanhCong)'', IIF(EXISTS(SELECT 1 FROM GiaoHang WHERE MaDonHang=@MaDon AND TrangThai=N''GiaoThanhCong''),''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Nhật ký thao tác quản trị tồn tại (bảng NhatKyHeThong)'', IIF(OBJECT_ID(''NhatKyHeThong'',''U'') IS NOT NULL,''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Không có tài xế kẹt DangGiao mà không có chuyến'', IIF(NOT EXISTS(SELECT 1 FROM TaiXe t WHERE t.TrangThai=N''DangGiao'' AND NOT EXISTS(SELECT 1 FROM DonHang d WHERE d.MaTaiXe=t.MaTaiXe AND d.TrangThai IN (N''DaXacNhan'',N''DangGiao''))),''PASS'',''FAIL''), N'''';
INSERT #kq SELECT N''Không có đơn DaXacNhan/DangGiao bị 2 GiaoHang'', IIF(NOT EXISTS(SELECT MaDonHang FROM GiaoHang GROUP BY MaDonHang HAVING COUNT(*)>1),''PASS'',''FAIL''), N'''';';
SET @sql = N'USE ' + QUOTENAME(@Db) + N'; ' + @sql;
EXEC sp_executesql @sql, N'@MaDon INT OUTPUT', @MaDon = @MaDon OUTPUT;

IF NOT EXISTS (SELECT 1 FROM #kq) RETURN;      -- chưa có đơn nào để nghiệm thu (đã báo lỗi ở trên)
SELECT * FROM #kq;
IF EXISTS (SELECT 1 FROM #kq WHERE KetQua='FAIL') THROW 50001, N'Có mục kiểm tra dữ liệu KHÔNG ĐẠT', 1;

/* ---- Truy vấn kiểm tra nhanh (từ Tools/03_BoSung.sql, 04_table.sql) — bỏ "-- " để chạy ---- */
-- SELECT COUNT(*) FROM GianHang;
-- SELECT COUNT(*) FROM MonAn;
-- SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE
-- FROM INFORMATION_SCHEMA.COLUMNS
-- ORDER BY TABLE_NAME, ORDINAL_POSITION;
GO

-- @@SAO_LUU_PHUC_HOI@@
/* ################ PHẦN B: SAO LƯU / PHỤC HỒI ################ */
/* ============================================================
   SAO LƯU / PHỤC HỒI CSDL QuanLyDichVuAnUong
   Chiến lược: Full mỗi đêm 02:00 + Differential mỗi 6 giờ + Log mỗi 15 phút (mất tối đa ~15 phút dữ liệu)
   + dọn dữ liệu quá hạn lúc 03:00. Mục C cần SQL Server Agent (không có trên Express/LocalDB: tự bỏ qua, xem mục B/C).
   ĐỔI @Dir sang thư mục có quyền ghi của tài khoản chạy SQL Server, và nên là ổ đĩa/NAS khác máy DB.

   CÁCH CHẠY: PHẦN B KHÔNG tự chạy khi bấm Execute cả file. Muốn chạy, trước hết chạy RIÊNG lệnh sau trong CÙNG cửa sổ truy vấn:
        EXEC sp_set_session_context @key = N'ChayPhanB', @value = 1;
   rồi chạy phần cần dùng (hoặc cả file). Mỗi khối dưới đây bắt đầu bằng "chốt" kiểm tra cờ đó và thoát nếu chưa bật.

   ĐÃ SỬA (lỗi "Invalid object name 'msdb.dbo.sysjobs'", "Could not find stored procedure 'msdb.dbo.sp_add_job'",
          "Invalid column name 'servicename' / 'status_desc'"): trước đây khóa PHẦN B bằng SET NOEXEC ON — chế độ này vẫn BIÊN DỊCH
   toàn bộ lệnh nên trên LocalDB/Express (không có SQL Agent trong msdb) sinh hàng loạt lỗi giả. Nay không dùng NOEXEC; mọi lệnh
   chạm tới msdb / sys.dm_server_services chỉ được gọi bằng SQL động / tên thủ tục trong biến SAU KHI đã kiểm tra có SQL Server Agent.
   ============================================================ */

/* ---------- A. Thiết lập ---------- */
IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'ChayPhanB')), 0) <> 1
BEGIN
    PRINT N'Bỏ qua PHẦN B (mục A): chưa bật cờ. Chạy trước: EXEC sp_set_session_context @key = N''ChayPhanB'', @value = 1;';
    RETURN;
END
IF DB_ID(N'QuanLyDichVuAnUong') IS NOT NULL
    ALTER DATABASE QuanLyDichVuAnUong SET RECOVERY FULL;     -- bắt buộc để sao lưu Log
GO

/* ---------- B. Sao lưu thủ công (chạy được trên mọi phiên bản, kể cả Express) ----------
   (1) thư mục C:\Backup\FoodService chưa có → tự tạo, không được thì dùng thư mục sao lưu mặc định của SQL Server;
   (2) bản Express không hỗ trợ COMPRESSION → chỉ dùng khi không phải Express. */
IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'ChayPhanB')), 0) <> 1
BEGIN
    PRINT N'Bỏ qua PHẦN B (mục B): chưa bật cờ ChayPhanB.';
    RETURN;
END
IF DB_ID(N'QuanLyDichVuAnUong') IS NULL
BEGIN
    PRINT N'Bỏ qua mục B: chưa có CSDL QuanLyDichVuAnUong.';
    RETURN;
END
DECLARE @Dir NVARCHAR(300) = N'C:\Backup\FoodService\';
BEGIN TRY
    EXEC master.dbo.xp_create_subdir @Dir;
END TRY
BEGIN CATCH
    SET @Dir = CAST(SERVERPROPERTY('InstanceDefaultBackupPath') AS NVARCHAR(300)) + N'\';
    PRINT N'Không tạo được C:\Backup\FoodService, dùng thư mục mặc định: ' + @Dir;
END CATCH
DECLARE @nen NVARCHAR(30) = IIF(CAST(SERVERPROPERTY('EngineEdition') AS INT) = 4, N'', N'COMPRESSION, ');
DECLARE @f NVARCHAR(400) = @Dir + N'Full_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + N'.bak';
DECLARE @sql NVARCHAR(MAX) = N'BACKUP DATABASE QuanLyDichVuAnUong TO DISK = N''' + REPLACE(@f, N'''', N'''''')
                           + N''' WITH ' + @nen + N'CHECKSUM, INIT, STATS = 10, NAME = N''FoodService Full'';';
EXEC(@sql);
RESTORE VERIFYONLY FROM DISK = @f WITH CHECKSUM;         -- kiểm tra file sao lưu đọc được
PRINT N'Đã sao lưu: ' + @f;
GO

/* Differential:
DECLARE @f NVARCHAR(400) = N'C:\Backup\FoodService\Diff_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + N'.bak';
BACKUP DATABASE QuanLyDichVuAnUong TO DISK = @f WITH DIFFERENTIAL, CHECKSUM, INIT;
   Log:
DECLARE @f NVARCHAR(400) = N'C:\Backup\FoodService\Log_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + N'.trn';
BACKUP LOG QuanLyDichVuAnUong TO DISK = @f WITH CHECKSUM, INIT;
*/

/* ---------- C. Tạo lịch tự động bằng SQL Server Agent ----------
   Chỉ chạy khi có SQL Server Agent đang chạy. Bản Express/LocalDB KHÔNG có Agent → mục này tự bỏ qua
   (dùng Windows Task Scheduler + sqlcmd để sao lưu). */
IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'ChayPhanB')), 0) <> 1
BEGIN
    PRINT N'Bỏ qua PHẦN B (mục C): chưa bật cờ ChayPhanB.';
    RETURN;
END
IF CAST(SERVERPROPERTY('EngineEdition') AS INT) = 4
BEGIN
    PRINT N'Bỏ qua mục C: bản Express/LocalDB không có SQL Server Agent.';
    RETURN;
END
IF OBJECT_ID(N'msdb.dbo.sysjobs', N'U') IS NULL OR OBJECT_ID(N'msdb.dbo.sp_add_job', N'P') IS NULL
BEGIN
    PRINT N'Bỏ qua mục C: msdb không có đối tượng SQL Server Agent (sysjobs / sp_add_job).';
    RETURN;
END

-- Kiểm tra Agent đang chạy (SQL động: không biên dịch trên máy không có sys.dm_server_services)
DECLARE @agent INT = 0;
BEGIN TRY
    EXEC sp_executesql
        N'SELECT @n = COUNT(*) FROM sys.dm_server_services WHERE servicename LIKE N''SQL Server Agent%'' AND status_desc = N''Running'';',
        N'@n INT OUTPUT', @n = @agent OUTPUT;
END TRY
BEGIN CATCH
    SET @agent = 0;
END CATCH
IF @agent = 0
BEGIN
    PRINT N'Bỏ qua mục C: SQL Server Agent chưa chạy (hoặc không đọc được trạng thái dịch vụ).';
    RETURN;
END

DECLARE @Dir NVARCHAR(300) = N'C:\Backup\FoodService\';     -- phải trùng thư mục ở trên và đã tồn tại
DECLARE @DB  sysname = N'QuanLyDichVuAnUong';

DECLARE @jobs TABLE (Ten sysname, Lenh NVARCHAR(MAX), FreqType INT, FreqInterval INT, SubType INT, SubInterval INT, StartTime INT);
INSERT INTO @jobs VALUES
 (N'FoodService - Full backup 02:00',
  N'DECLARE @f NVARCHAR(400)=N''' + @Dir + N'Full_''+FORMAT(GETDATE(),''yyyyMMdd_HHmmss'')+N''.bak''; '
  + N'BACKUP DATABASE ' + QUOTENAME(@DB) + N' TO DISK=@f WITH COMPRESSION, CHECKSUM, INIT; RESTORE VERIFYONLY FROM DISK=@f WITH CHECKSUM;',
  4, 1, 1, 0, 020000),
 (N'FoodService - Differential 6 gio',
  N'DECLARE @f NVARCHAR(400)=N''' + @Dir + N'Diff_''+FORMAT(GETDATE(),''yyyyMMdd_HHmmss'')+N''.bak''; '
  + N'BACKUP DATABASE ' + QUOTENAME(@DB) + N' TO DISK=@f WITH DIFFERENTIAL, COMPRESSION, CHECKSUM, INIT;',
  4, 1, 8, 6, 080000),
 (N'FoodService - Log backup 15 phut',
  N'DECLARE @f NVARCHAR(400)=N''' + @Dir + N'Log_''+FORMAT(GETDATE(),''yyyyMMdd_HHmmss'')+N''.trn''; '
  + N'BACKUP LOG ' + QUOTENAME(@DB) + N' TO DISK=@f WITH COMPRESSION, CHECKSUM, INIT;',
  4, 1, 4, 15, 000500),
 (N'FoodService - Don dep du lieu 03:00',
  N'EXEC ' + QUOTENAME(@DB) + N'.dbo.sp_DonDepDuLieu;',
  4, 1, 1, 0, 030000);

-- Gọi thủ tục msdb qua TÊN LƯU TRONG BIẾN: không bị ràng buộc/biên dịch khi chạy trên máy không có Agent
DECLARE @pJob sysname = N'msdb.dbo.sp_add_job',        @pStep sysname = N'msdb.dbo.sp_add_jobstep',
        @pSch sysname = N'msdb.dbo.sp_add_jobschedule', @pSrv  sysname = N'msdb.dbo.sp_add_jobserver';
DECLARE @n sysname, @c NVARCHAR(MAX), @ft INT, @fi INT, @st INT, @si INT, @t INT, @co INT;
DECLARE jc CURSOR LOCAL FAST_FORWARD FOR SELECT Ten, Lenh, FreqType, FreqInterval, SubType, SubInterval, StartTime FROM @jobs;
OPEN jc; FETCH NEXT FROM jc INTO @n, @c, @ft, @fi, @st, @si, @t;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @co = 0;
    EXEC sp_executesql N'SELECT @k = COUNT(*) FROM msdb.dbo.sysjobs WHERE name = @ten;', N'@ten sysname, @k INT OUTPUT', @ten = @n, @k = @co OUTPUT;
    IF @co = 0
    BEGIN
        EXEC @pJob  @job_name = @n, @enabled = 1;
        EXEC @pStep @job_name = @n, @step_name = N'Chay', @subsystem = N'TSQL', @command = @c, @database_name = N'master';
        EXEC @pSch  @job_name = @n, @name = N'Lich', @freq_type = @ft, @freq_interval = @fi,
                    @freq_subday_type = @st, @freq_subday_interval = @si, @active_start_time = @t;
        EXEC @pSrv  @job_name = @n;
        PRINT N'Đã tạo job: ' + @n;
    END
    FETCH NEXT FROM jc INTO @n, @c, @ft, @fi, @st, @si, @t;
END
CLOSE jc; DEALLOCATE jc;
GO

/* ---------- D. Phục hồi (ví dụ) — CHẠY TỪNG BƯỚC, thay tên file cho đúng ----------
USE master;
ALTER DATABASE QuanLyDichVuAnUong SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
RESTORE DATABASE QuanLyDichVuAnUong FROM DISK = N'C:\Backup\FoodService\Full_20261007_020000.bak' WITH NORECOVERY, REPLACE;
RESTORE DATABASE QuanLyDichVuAnUong FROM DISK = N'C:\Backup\FoodService\Diff_20261007_080000.bak' WITH NORECOVERY;
RESTORE LOG      QuanLyDichVuAnUong FROM DISK = N'C:\Backup\FoodService\Log_20261007_081500.trn'  WITH NORECOVERY;
-- ... các file Log kế tiếp theo thứ tự; muốn dừng ở thời điểm cụ thể: WITH STOPAT = '2026-10-07 09:10:00', RECOVERY
RESTORE DATABASE QuanLyDichVuAnUong WITH RECOVERY;
ALTER DATABASE QuanLyDichVuAnUong SET MULTI_USER;
-- Nên thử phục hồi sang một DB tên khác (WITH MOVE ...) định kỳ để chắc chắn bản sao lưu dùng được.
-- Xóa file sao lưu cũ hơn 14 ngày: dùng Windows Task Scheduler/PowerShell (Get-ChildItem | Where LastWriteTime -lt (Get-Date).AddDays(-14) | Remove-Item).
*/
