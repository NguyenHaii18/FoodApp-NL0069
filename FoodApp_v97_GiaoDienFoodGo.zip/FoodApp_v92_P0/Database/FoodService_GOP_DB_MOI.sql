﻿/* >>> BẬT Query > SQLCMD Mode trong SSMS trước khi chạy (file dùng :ON ERROR EXIT để dừng ngay khi có lỗi). <<<
   Nếu quên bật, khối dưới đây tự chặn toàn bộ file (không có gì bị thay đổi) và in hướng dẫn. */
:setvar __IsSqlCmdEnabled "True"
GO
IF N'$(__IsSqlCmdEnabled)' NOT LIKE N'True'
BEGIN
    PRINT N'>>> DỪNG: chưa bật SQLCMD Mode. Vào menu Query > SQLCMD Mode, rồi chạy lại. Chưa có gì bị thay đổi.';
    SET NOEXEC ON;
END
GO
:ON ERROR EXIT
GO
/* ============================================================
   FoodService_GOP_DB_MOI.sql — GỘP TẤT CẢ SQL (kể cả phần quản trị) để TẠO CSDL QuanLyDichVuAnUong MỚI từ đầu. (bản v94)
   Bật Query > SQLCMD Mode rồi chạy cả file một lần. Nếu CSDL đã tồn tại thì file DỪNG ngay ở bước 1 (không xóa gì) —
   khi đó dùng FoodService_GOP_TATCA.sql. (Chỉ đặt @CHO_PHEP_XOA_DB = 1 trong bước 1 khi chắc chắn muốn XÓA + TẠO LẠI; có sao lưu trước.)
   Thứ tự: 1) Database  2) BoSung_ThietKe  3) MucDuongDa  4) KhachHangMau(20)  5) GianHangMau(20)  6) ThemSizeNuoc
           7) SuaTaiKhoan_MoKhoa  8) BaoMat (chỉ xem trước)  9) NghiemThu_SaoLuu (comment).  NangCap không cần: Database đã gồm sẵn.
   ============================================================ */
/* ============================================================
   FoodService_Database.sql — FILE DUY NHẤT (gộp toàn bộ thư mục Database)
   - PHẦN 1-18c: tạo mới toàn bộ CSDL (đã gồm mọi bản nâng cấp v8 → v21, đối tác, giỏ hàng, giao hàng/bản đồ, tuyến đường, tài xế từ chối đơn).
     Database/FoodService_NangCap.sql là bản nâng cấp từng phần (cho CSDL cũ) của cùng nội dung này.
   - PHẦN 19 (cuối file): sao lưu/phục hồi (bản chạy được nằm ở PHẦN B của FoodService_NghiemThu_SaoLuu.sql) — ĐỂ SẴN DẠNG COMMENT vì cần SQL Server Agent
     (không chạy được trên Express). Cần dùng thì bỏ dấu "-- " ở đầu từng dòng.
   LƯU Ý: bật SQLCMD Mode trong SSMS trước khi chạy file. Khi CSDL đã tồn tại, THROW kết hợp :ON ERROR EXIT sẽ dừng hẳn script, không chạy/biên dịch các phần tạo bảng phía sau.
   AN TOÀN: nếu CSDL đã tồn tại, file này DỪNG (không xóa gì) trừ khi bạn đặt @CHO_PHEP_XOA_DB = 1 (khi đó tự sao lưu trước, sao lưu lỗi thì không xóa).
   ============================================================ */
/* ============================================================
   CƠ SỞ DỮ LIỆU: QuanLyDichVuAnUong (FILE DUY NHẤT - TRỌN BỘ)
   Đề tài: CNTT-KLCN069 - Xây dựng ứng dụng quản lý dịch vụ ăn uống
   Hệ quản trị: SQL Server

   File này gộp toàn bộ, chạy 1 lần là xong, không cần file phụ nào khác:
     PHẦN 1: Tạo DB + 16 bảng (KhachHang/GianHang/QuanTri + Shipper)
     PHẦN 2-5: Dữ liệu mẫu nhỏ (8 gian hàng, 5 khách hàng, 4 tài xế,
               2 quản trị viên, khuyến mãi, đơn hàng mẫu)
     PHẦN 6: Đặt mật khẩu demo (lưu dạng BCrypt, không còn mật khẩu rõ; khách/quán/tài xế = 123456, quản trị = admin123)
     PHẦN 7: Sinh thêm dữ liệu lớn — 100 khách hàng, 30 quán ăn
             (kèm thực đơn), 40 tài xế — mật khẩu cũng = 123456
   ============================================================ */

/* Đặt ngữ cảnh về master trước khi kiểm tra CSDL. Nếu CSDL đã tồn tại, THROW kết hợp :ON ERROR EXIT (SQLCMD Mode) dừng toàn bộ file ngay tại đây. */
USE master;
GO

/* ---------- KHÓA AN TOÀN: mặc định KHÔNG xóa CSDL đang có ----------
   Nếu QuanLyDichVuAnUong đã tồn tại, file này dừng ngay (không tạo, không xóa gì).
   Chỉ khi bạn CHỦ ĐỘNG đổi @CHO_PHEP_XOA_DB = 1 thì script mới: (1) sao lưu tự động, (2) nếu sao lưu thành công mới xóa và tạo lại.
   Muốn GIỮ dữ liệu -> dùng Database/FoodService_NangCap.sql (nâng cấp, không xóa). */
DECLARE @CHO_PHEP_XOA_DB BIT = 0;      -- <<< đổi thành 1 chỉ khi chắc chắn muốn XÓA và TẠO LẠI CSDL
DECLARE @BO_QUA_SAO_LUU  BIT = 0;      -- 1 = không sao lưu trước khi xóa (KHÔNG khuyến nghị)

IF DB_ID('QuanLyDichVuAnUong') IS NOT NULL
BEGIN
    IF @CHO_PHEP_XOA_DB = 0
    BEGIN
        THROW 51000, N'DỪNG: CSDL QuanLyDichVuAnUong đã tồn tại. Không có dữ liệu nào bị thay đổi. Muốn GIỮ dữ liệu: chạy FoodService_NangCap.sql (rồi FoodService_ThemGianHangMau.sql nếu cần tài khoản mẫu). Muốn XÓA và TẠO LẠI: đặt @CHO_PHEP_XOA_DB = 1 rồi chạy lại file này.', 1;
    END
    ELSE
    BEGIN
        IF @BO_QUA_SAO_LUU = 0
        BEGIN
            DECLARE @thuMuc NVARCHAR(400) = CAST(SERVERPROPERTY('InstanceDefaultBackupPath') AS NVARCHAR(400));
            DECLARE @tep NVARCHAR(600) = @thuMuc + N'\QuanLyDichVuAnUong_truoc_khi_xoa_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + N'.bak';
            BEGIN TRY
                BACKUP DATABASE QuanLyDichVuAnUong TO DISK = @tep WITH INIT, CHECKSUM;
                PRINT N'Đã sao lưu CSDL cũ: ' + @tep;
            END TRY
            BEGIN CATCH
                THROW 51001, N'DỪNG: không sao lưu được CSDL cũ nên KHÔNG xóa. Tự sao lưu rồi chạy lại, hoặc đặt @BO_QUA_SAO_LUU = 1 nếu chấp nhận mất dữ liệu.', 1;
            END CATCH
        END
        ALTER DATABASE QuanLyDichVuAnUong SET SINGLE_USER WITH ROLLBACK IMMEDIATE;   -- ngắt kết nối đang mở (SSMS/Web) để DROP không bị chặn
        DROP DATABASE QuanLyDichVuAnUong;
    END
END
GO

CREATE DATABASE QuanLyDichVuAnUong;
GO

USE QuanLyDichVuAnUong;
GO

/* ============================================================
   PHẦN 1: TẠO BẢNG
   ============================================================ */

CREATE TABLE TaiKhoan (
    MaTK            INT IDENTITY(1,1) PRIMARY KEY,
    TenDangNhap     NVARCHAR(50)  NOT NULL UNIQUE,
    MatKhau         NVARCHAR(255) NOT NULL,
    VaiTro          NVARCHAR(20)  NOT NULL
        CHECK (VaiTro IN (N'KhachHang', N'GianHang', N'QuanTri', N'TaiXe')),
    NgayTao         DATETIME      NOT NULL DEFAULT GETDATE(),
    TrangThai       BIT           NOT NULL DEFAULT 1
);
GO

CREATE TABLE KhachHang (
    MaKH            INT IDENTITY(1,1) PRIMARY KEY,
    MaTK            INT NOT NULL UNIQUE REFERENCES TaiKhoan(MaTK),
    HoTen           NVARCHAR(100) NOT NULL,
    SDT             VARCHAR(15)   NOT NULL,
    Email           VARCHAR(100)  NULL,
    DiaChiGiaoHang  NVARCHAR(255) NULL
);
GO

CREATE TABLE GianHang (
    MaGianHang        INT IDENTITY(1,1) PRIMARY KEY,
    MaTK              INT NOT NULL UNIQUE REFERENCES TaiKhoan(MaTK),
    TenCuaHang        NVARCHAR(150) NOT NULL,
    DiaChi            NVARCHAR(255) NOT NULL,
    SDT               VARCHAR(15)   NOT NULL,
    MoTa              NVARCHAR(500) NULL,
    HinhAnh           NVARCHAR(500) NULL,
    TrangThaiKinhDoanh NVARCHAR(20) NOT NULL DEFAULT N'DangMo'
        CHECK (TrangThaiKinhDoanh IN (N'DangMo', N'DongCua', N'TamNgung')),
    TrangThaiDuyet    NVARCHAR(20) NOT NULL DEFAULT N'ChoDuyet'
        CHECK (TrangThaiDuyet IN (N'ChoDuyet', N'DaDuyet', N'TuChoi')),
    NgayDangKy        DATETIME NOT NULL DEFAULT GETDATE()
);
GO

CREATE TABLE QuanTri (
    MaQuanTri       INT IDENTITY(1,1) PRIMARY KEY,
    MaTK            INT NOT NULL UNIQUE REFERENCES TaiKhoan(MaTK),
    HoTen           NVARCHAR(100) NOT NULL,
    SDT             VARCHAR(15)   NOT NULL,
    Email           VARCHAR(100)  NULL,
    CapQuyenHan     NVARCHAR(30)  NOT NULL DEFAULT N'NhanVien'
        CHECK (CapQuyenHan IN (N'SuperAdmin', N'QuanLy', N'NhanVien')),
    PhongBanPhuTrach NVARCHAR(100) NULL
);
GO

CREATE TABLE TaiXe (
    MaTaiXe         INT IDENTITY(1,1) PRIMARY KEY,
    MaTK            INT NOT NULL UNIQUE REFERENCES TaiKhoan(MaTK),
    HoTen           NVARCHAR(100) NOT NULL,
    SDT             VARCHAR(15)   NOT NULL,
    PhuongTien      NVARCHAR(50)  NULL,
    BienSo          VARCHAR(20)   NULL,
    KhuVucHoatDong  NVARCHAR(150) NULL,
    TrangThai       NVARCHAR(20)  NOT NULL DEFAULT N'SanSang'
        CHECK (TrangThai IN (N'SanSang', N'DangGiao', N'NgoaiTuyen')),
    TrangThaiDuyet  NVARCHAR(20)  NOT NULL DEFAULT N'DaDuyet'
        CHECK (TrangThaiDuyet IN (N'ChoDuyet', N'DaDuyet', N'TuChoi')),
    NgayDangKy      DATETIME      NOT NULL DEFAULT GETDATE()
);
GO

CREATE TABLE DanhMuc (
    MaDanhMuc       INT IDENTITY(1,1) PRIMARY KEY,
    MaGianHang      INT NOT NULL REFERENCES GianHang(MaGianHang),
    TenDanhMuc      NVARCHAR(100) NOT NULL
);
GO

CREATE TABLE MonAn (
    MaMonAn         INT IDENTITY(1,1) PRIMARY KEY,
    MaDanhMuc       INT NOT NULL REFERENCES DanhMuc(MaDanhMuc),
    TenMon          NVARCHAR(150) NOT NULL,
    Gia             DECIMAL(12,0) NOT NULL CHECK (Gia >= 0),
    MoTa            NVARCHAR(500) NULL,
    HinhAnh         NVARCHAR(255) NULL,
    TinhTrang       NVARCHAR(20) NOT NULL DEFAULT N'ConHang'
        CHECK (TinhTrang IN (N'ConHang', N'HetHang'))
);
GO

CREATE TABLE DonHang (
    MaDonHang       INT IDENTITY(1,1) PRIMARY KEY,
    MaKH            INT NOT NULL REFERENCES KhachHang(MaKH),
    MaGianHang      INT NOT NULL REFERENCES GianHang(MaGianHang),
    MaTaiXe         INT NULL REFERENCES TaiXe(MaTaiXe),
    NgayDat         DATETIME NOT NULL DEFAULT GETDATE(),
    TrangThai       NVARCHAR(30) NOT NULL DEFAULT N'ChoXacNhan'
        CHECK (TrangThai IN (N'ChoXacNhan', N'DaXacNhan', N'DangGiao', N'DaGiao', N'DaHuy')),
    TongTien        DECIMAL(12,0) NOT NULL DEFAULT 0,
    PhiGiaoHang     DECIMAL(12,0) NOT NULL DEFAULT 0, -- đã gồm trong TongTien; là thu nhập tài xế
    DiaChiGiaoHang  NVARCHAR(255) NOT NULL,
    GhiChu          NVARCHAR(255) NULL,
    MaKhuyenMaiApDung INT NULL -- FK thêm bằng ALTER TABLE bên dưới, sau khi có bảng KhuyenMai
);
GO

CREATE TABLE ChiTietDonHang (
    MaCTDH          INT IDENTITY(1,1) PRIMARY KEY,
    MaDonHang       INT NOT NULL REFERENCES DonHang(MaDonHang),
    MaMonAn         INT NOT NULL REFERENCES MonAn(MaMonAn),
    SoLuong         INT NOT NULL CHECK (SoLuong > 0),
    DonGia          DECIMAL(12,0) NOT NULL CHECK (DonGia >= 0)
);
GO

CREATE TABLE ThanhToan (
    MaThanhToan     INT IDENTITY(1,1) PRIMARY KEY,
    MaDonHang       INT NOT NULL UNIQUE REFERENCES DonHang(MaDonHang),
    HinhThuc        NVARCHAR(30) NOT NULL
        CHECK (HinhThuc IN (N'TienMat', N'VNPay', N'Momo')),
    TrangThai       NVARCHAR(20) NOT NULL DEFAULT N'ChoThanhToan'
        CHECK (TrangThai IN (N'ChoThanhToan', N'DaThanhToan', N'ThatBai', N'DaHoanTien')),
    MaGiaoDich      VARCHAR(100) NULL,
    NgayThanhToan   DATETIME NULL
);
GO

CREATE TABLE GiaoHang (
    MaGiaoHang      INT IDENTITY(1,1) PRIMARY KEY,
    MaDonHang       INT NOT NULL UNIQUE REFERENCES DonHang(MaDonHang),
    MaTaiXe         INT NOT NULL REFERENCES TaiXe(MaTaiXe),
    TrangThai       NVARCHAR(20) NOT NULL DEFAULT N'DaNhan'
        CHECK (TrangThai IN (N'DaNhan', N'DangGiao', N'GiaoThanhCong', N'GiaoThatBai')),
    ThoiGianNhan    DATETIME NULL,
    ThoiGianGiao    DATETIME NULL
    -- Không có cột PhiGiaoHang ở đây: phí giao hàng (= thu nhập tài xế) được
    -- tính và lưu thẳng vào DonHang.PhiGiaoHang ngay lúc khách đặt hàng
    -- (CustomerCartController), không phải lúc tài xế nhận đơn.
);
GO

CREATE TABLE KhuyenMai (
    MaKhuyenMai     INT IDENTITY(1,1) PRIMARY KEY,
    MaGianHang      INT NULL REFERENCES GianHang(MaGianHang),
    MaMonAn         INT NULL REFERENCES MonAn(MaMonAn),   -- NULL = giảm cả đơn; có giá trị = chỉ giảm trên món này
    MaCode          VARCHAR(30) NOT NULL UNIQUE,
    MoTa            NVARCHAR(255) NULL,
    PhanTramGiam    DECIMAL(5,2) NULL CHECK (PhanTramGiam BETWEEN 0 AND 100),
    SoTienGiam      DECIMAL(12,0) NULL,
    DieuKienApDung  NVARCHAR(255) NULL,
    NgayBatDau      DATETIME NOT NULL,
    NgayKetThuc     DATETIME NOT NULL,
    TrangThai       BIT NOT NULL DEFAULT 1
);
GO

ALTER TABLE DonHang ADD CONSTRAINT FK_DonHang_KhuyenMai
    FOREIGN KEY (MaKhuyenMaiApDung) REFERENCES KhuyenMai(MaKhuyenMai);
GO

CREATE TABLE DanhGia (
    MaDanhGia       INT IDENTITY(1,1) PRIMARY KEY,
    MaKH            INT NOT NULL REFERENCES KhachHang(MaKH),
    MaGianHang      INT NOT NULL REFERENCES GianHang(MaGianHang),
    MaDonHang       INT NOT NULL REFERENCES DonHang(MaDonHang),
    SoSao           INT NOT NULL CHECK (SoSao BETWEEN 1 AND 5),
    NoiDung         NVARCHAR(500) NULL,
    NgayDanhGia     DATETIME NOT NULL DEFAULT GETDATE()
);
GO

CREATE TABLE DanhGiaMon (
    MaDanhGiaMon    INT IDENTITY(1,1) PRIMARY KEY,
    MaKH            INT NOT NULL REFERENCES KhachHang(MaKH),
    MaMonAn         INT NOT NULL REFERENCES MonAn(MaMonAn),
    MaDonHang       INT NOT NULL REFERENCES DonHang(MaDonHang),
    SoSao           INT NOT NULL CHECK (SoSao BETWEEN 1 AND 5),
    NoiDung         NVARCHAR(500) NULL,
    NgayDanhGia     DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT UQ_DanhGiaMon UNIQUE (MaDonHang, MaMonAn)
);
GO

CREATE TABLE DiaChiKhachHang (
    MaDiaChi        INT IDENTITY(1,1) PRIMARY KEY,
    MaKH            INT NOT NULL REFERENCES KhachHang(MaKH),
    Nhan            NVARCHAR(50)  NOT NULL,
    DiaChi          NVARCHAR(255) NOT NULL,
    MacDinh         BIT NOT NULL DEFAULT 0
);
GO

CREATE TABLE PhanHoi (
    MaPhanHoi       INT IDENTITY(1,1) PRIMARY KEY,
    MaKH            INT NOT NULL REFERENCES KhachHang(MaKH),
    MaDonHang       INT NULL REFERENCES DonHang(MaDonHang),
    MaGianHang      INT NULL REFERENCES GianHang(MaGianHang),
    Loai            NVARCHAR(20) NOT NULL DEFAULT N'GopY'
        CHECK (Loai IN (N'GopY', N'KhieuNai', N'Khac')),
    TieuDe          NVARCHAR(150) NOT NULL,
    NoiDung         NVARCHAR(1000) NOT NULL,
    TrangThai       NVARCHAR(20) NOT NULL DEFAULT N'ChuaXuLy'
        CHECK (TrangThai IN (N'ChuaXuLy', N'DaXuLy')),
    TraLoi          NVARCHAR(1000) NULL,
    NgayGui         DATETIME NOT NULL DEFAULT GETDATE(),
    NgayXuLy        DATETIME NULL
);
GO

/* ---- Tài xế từ chối đơn giao (ẩn đơn khỏi danh sách của riêng tài xế đó) ---- */
IF OBJECT_ID('TaiXeTuChoiDon', 'U') IS NULL
CREATE TABLE TaiXeTuChoiDon (
    MaTuChoi    INT IDENTITY(1,1) PRIMARY KEY,
    MaTaiXe     INT NOT NULL REFERENCES TaiXe(MaTaiXe),
    MaDonHang   INT NOT NULL REFERENCES DonHang(MaDonHang),
    LyDo        NVARCHAR(300) NULL,
    ThoiGian    DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
    CONSTRAINT UQ_TaiXeTuChoiDon UNIQUE (MaTaiXe, MaDonHang)
);
GO


/* ============================================================
   PHẦN 2: NGUỒN DỮ LIỆU LỚN - TÀI KHOẢN
   5 khách hàng, 8 gian hàng, 2 quản trị viên, 4 tài xế
   ============================================================ */

INSERT INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro) VALUES
(N'khachhang01', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'KhachHang'),
(N'khachhang02', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'KhachHang'),
(N'khachhang03', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'KhachHang'),
(N'khachhang04', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'KhachHang'),
(N'khachhang05', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'KhachHang'),
(N'gianhang01', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'GianHang'),
(N'gianhang02', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'GianHang'),
(N'gianhang03', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'GianHang'),
(N'gianhang04', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'GianHang'),
(N'gianhang05', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'GianHang'),
(N'gianhang06', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'GianHang'),
(N'gianhang07', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'GianHang'),
(N'gianhang08', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'GianHang'),
(N'quantri01', N'$2b$11$4W4e54I7Wm8IZICGB5WG5eJicrEVilueK2EWGeKHOeTK/8ZNZnzzW', N'QuanTri'),
(N'quantri02', N'$2b$11$4W4e54I7Wm8IZICGB5WG5eJicrEVilueK2EWGeKHOeTK/8ZNZnzzW', N'QuanTri'),
(N'taixe01', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'TaiXe'),
(N'taixe02', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'TaiXe'),
(N'taixe03', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'TaiXe'),
(N'taixe04', N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu', N'TaiXe');
GO

INSERT INTO QuanTri (MaTK, HoTen, SDT, Email, CapQuyenHan, PhongBanPhuTrach)
SELECT MaTK, HoTen, SDT, Email, CapQuyen, PhongBan FROM (VALUES
    (N'quantri01', N'Nguyễn Thị Quản Lý', '0920000001', 'quanly@huit.edu.vn', N'SuperAdmin', N'Điều hành hệ thống'),
    (N'quantri02', N'Trần Văn Giám Sát', '0921000002', 'giamsat@huit.edu.vn', N'NhanVien', N'Giám sát đối tác & khuyến mãi')
) AS d(TenDN, HoTen, SDT, Email, CapQuyen, PhongBan)
JOIN TaiKhoan t ON t.TenDangNhap = d.TenDN;
GO

INSERT INTO KhachHang (MaTK, HoTen, SDT, Email, DiaChiGiaoHang)
SELECT MaTK, HoTen, SDT, Email, DiaChi FROM (VALUES
    (N'khachhang01', N'Nguyễn Văn A', '0901000001', 'a@gmail.com', N'123 Lê Lợi, Q.1, TP.HCM'),
    (N'khachhang02', N'Phạm Thị D', '0907000007', 'd@gmail.com', N'56 Lý Thường Kiệt, Q.10, TP.HCM'),
    (N'khachhang03', N'Trần Văn E', '0908000008', 'e@gmail.com', N'89 Nguyễn Thị Minh Khai, Q.3, TP.HCM'),
    (N'khachhang04', N'Lê Thị F', '0909000009', 'f@gmail.com', N'12 Điện Biên Phủ, Bình Thạnh, TP.HCM'),
    (N'khachhang05', N'Hoàng Văn G', '0910000010', 'g@gmail.com', N'34 Cộng Hòa, Tân Bình, TP.HCM')
) AS d(TenDN, HoTen, SDT, Email, DiaChi)
JOIN TaiKhoan t ON t.TenDangNhap = d.TenDN;
GO

/* ---------- 8 gian hàng thuộc nhiều nhóm ẩm thực khác nhau ---------- */
INSERT INTO GianHang (MaTK, TenCuaHang, DiaChi, SDT, MoTa, TrangThaiKinhDoanh, TrangThaiDuyet)
SELECT MaTK, TenCuaHang, DiaChi, SDT, MoTa, N'DangMo', N'DaDuyet' FROM (VALUES
    (N'gianhang01', N'Quán Cơm Tấm Cô Ba', N'45 Nguyễn Trãi, Q.5, TP.HCM', '0902000002', N'Cơm tấm sườn bì chả truyền thống'),
    (N'gianhang02', N'Bún Bò Huế Mệ Ba', N'12 Trần Hưng Đạo, Q.1, TP.HCM', '0904000004', N'Bún bò chuẩn vị Huế, mở cửa từ 6h sáng'),
    (N'gianhang03', N'Trà Sữa Mộc Trà', N'88 Cách Mạng Tháng 8, Q.3, TP.HCM', '0905000005', N'Trà sữa, trà trái cây tươi mỗi ngày'),
    (N'gianhang04', N'Phở Hà Nội Xưa', N'20 Hai Bà Trưng, Q.1, TP.HCM', '0911000011', N'Phở bò/gà theo công thức Hà Nội gốc'),
    (N'gianhang05', N'Bánh Mì Bà Huynh', N'5 Nguyễn Đình Chiểu, Q.3, TP.HCM', '0912000012', N'Bánh mì thịt nướng, pate nhà làm'),
    (N'gianhang06', N'Gà Rán Cô Út', N'150 Ba Tháng Hai, Q.10, TP.HCM', '0913000013', N'Gà rán giòn, combo học sinh sinh viên'),
    (N'gianhang07', N'Hủ Tiếu Nam Vang Sáu Sài Gòn', N'77 Trần Phú, Q.5, TP.HCM', '0914000014', N'Hủ tiếu Nam Vang, hủ tiếu khô'),
    (N'gianhang08', N'Chè Ba Miền', N'22 Sư Vạn Hạnh, Q.10, TP.HCM', '0915000015', N'Chè Bắc - Trung - Nam đủ loại')
) AS d(TenDN, TenCuaHang, DiaChi, SDT, MoTa)
JOIN TaiKhoan t ON t.TenDangNhap = d.TenDN;
GO

INSERT INTO TaiXe (MaTK, HoTen, SDT, PhuongTien, KhuVucHoatDong)
SELECT MaTK, HoTen, SDT, PhuongTien, KhuVuc FROM (VALUES
    (N'taixe01', N'Trần Văn B', '0903000003', N'Xe máy', N'Quận 1, Quận 5'),
    (N'taixe02', N'Lê Thị C', '0906000006', N'Xe máy', N'Quận 3, Quận 10'),
    (N'taixe03', N'Đỗ Văn H', '0916000016', N'Xe máy', N'Bình Thạnh, Quận 1'),
    (N'taixe04', N'Ngô Thị K', '0917000017', N'Xe đạp điện', N'Quận 5, Quận 10')
) AS d(TenDN, HoTen, SDT, PhuongTien, KhuVuc)
JOIN TaiKhoan t ON t.TenDangNhap = d.TenDN;
GO

/* ============================================================
   PHẦN 3: DANH MỤC + MÓN ĂN CHO TỪNG GIAN HÀNG (~45 món)
   ============================================================ */

DECLARE @gh1 INT = (SELECT MaGianHang FROM GianHang WHERE TenCuaHang = N'Quán Cơm Tấm Cô Ba');
DECLARE @gh2 INT = (SELECT MaGianHang FROM GianHang WHERE TenCuaHang = N'Bún Bò Huế Mệ Ba');
DECLARE @gh3 INT = (SELECT MaGianHang FROM GianHang WHERE TenCuaHang = N'Trà Sữa Mộc Trà');
DECLARE @gh4 INT = (SELECT MaGianHang FROM GianHang WHERE TenCuaHang = N'Phở Hà Nội Xưa');
DECLARE @gh5 INT = (SELECT MaGianHang FROM GianHang WHERE TenCuaHang = N'Bánh Mì Bà Huynh');
DECLARE @gh6 INT = (SELECT MaGianHang FROM GianHang WHERE TenCuaHang = N'Gà Rán Cô Út');
DECLARE @gh7 INT = (SELECT MaGianHang FROM GianHang WHERE TenCuaHang = N'Hủ Tiếu Nam Vang Sáu Sài Gòn');
DECLARE @gh8 INT = (SELECT MaGianHang FROM GianHang WHERE TenCuaHang = N'Chè Ba Miền');

-- Cơm Tấm Cô Ba
INSERT INTO DanhMuc (MaGianHang, TenDanhMuc) VALUES (@gh1, N'Cơm phần'), (@gh1, N'Món thêm'), (@gh1, N'Nước uống');
DECLARE @gh1_com INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh1 AND TenDanhMuc=N'Cơm phần');
DECLARE @gh1_them INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh1 AND TenDanhMuc=N'Món thêm');
DECLARE @gh1_nuoc INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh1 AND TenDanhMuc=N'Nước uống');
INSERT INTO MonAn (MaDanhMuc, TenMon, Gia, MoTa) VALUES
(@gh1_com, N'Cơm sườn bì chả', 45000, N'Sườn nướng, bì, chả trứng'),
(@gh1_com, N'Cơm sườn trứng', 40000, NULL),
(@gh1_com, N'Cơm sườn ốp la', 42000, NULL),
(@gh1_com, N'Cơm gà nướng', 48000, NULL),
(@gh1_them, N'Trứng ốp la', 8000, N'Trứng chiên lòng đào'),
(@gh1_them, N'Chả trứng hấp', 15000, NULL),
(@gh1_nuoc, N'Trà đá', 5000, NULL),
(@gh1_nuoc, N'Nước ngọt lon', 12000, NULL);

-- Bún Bò Huế Mệ Ba
INSERT INTO DanhMuc (MaGianHang, TenDanhMuc) VALUES (@gh2, N'Món chính'), (@gh2, N'Nước uống');
DECLARE @gh2_chinh INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh2 AND TenDanhMuc=N'Món chính');
DECLARE @gh2_nuoc INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh2 AND TenDanhMuc=N'Nước uống');
INSERT INTO MonAn (MaDanhMuc, TenMon, Gia, MoTa) VALUES
(@gh2_chinh, N'Bún bò giò heo', 55000, N'Tô đầy đủ giò, chả, huyết'),
(@gh2_chinh, N'Bún bò đặc biệt', 65000, N'Thêm giò heo và chả cua'),
(@gh2_chinh, N'Bún chả cua', 50000, NULL),
(@gh2_chinh, N'Bún giò heo', 48000, NULL),
(@gh2_nuoc, N'Trà đá', 5000, NULL),
(@gh2_nuoc, N'Nước sâm', 10000, NULL);

-- Trà Sữa Mộc Trà
INSERT INTO DanhMuc (MaGianHang, TenDanhMuc) VALUES (@gh3, N'Trà sữa'), (@gh3, N'Trà trái cây');
DECLARE @gh3_ts INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh3 AND TenDanhMuc=N'Trà sữa');
DECLARE @gh3_tc INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh3 AND TenDanhMuc=N'Trà trái cây');
INSERT INTO MonAn (MaDanhMuc, TenMon, Gia, MoTa) VALUES
(@gh3_ts, N'Trà sữa truyền thống', 35000, NULL),
(@gh3_ts, N'Trà sữa trân châu đường đen', 42000, NULL),
(@gh3_ts, N'Trà sữa matcha', 40000, NULL),
(@gh3_tc, N'Trà đào cam sả', 39000, NULL),
(@gh3_tc, N'Trà vải', 39000, NULL);

-- Phở Hà Nội Xưa
INSERT INTO DanhMuc (MaGianHang, TenDanhMuc) VALUES (@gh4, N'Phở'), (@gh4, N'Nước uống');
DECLARE @gh4_pho INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh4 AND TenDanhMuc=N'Phở');
DECLARE @gh4_nuoc INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh4 AND TenDanhMuc=N'Nước uống');
INSERT INTO MonAn (MaDanhMuc, TenMon, Gia, MoTa) VALUES
(@gh4_pho, N'Phở bò tái', 50000, NULL),
(@gh4_pho, N'Phở bò chín', 50000, NULL),
(@gh4_pho, N'Phở gà', 45000, NULL),
(@gh4_pho, N'Phở đặc biệt', 65000, N'Tái, nạm, gân, bò viên'),
(@gh4_nuoc, N'Trà đá', 5000, NULL),
(@gh4_nuoc, N'Nước ngọt lon', 12000, NULL);

-- Bánh Mì Bà Huynh
INSERT INTO DanhMuc (MaGianHang, TenDanhMuc) VALUES (@gh5, N'Bánh mì'), (@gh5, N'Nước uống');
DECLARE @gh5_bm INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh5 AND TenDanhMuc=N'Bánh mì');
DECLARE @gh5_nuoc INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh5 AND TenDanhMuc=N'Nước uống');
INSERT INTO MonAn (MaDanhMuc, TenMon, Gia, MoTa) VALUES
(@gh5_bm, N'Bánh mì thịt nướng', 25000, NULL),
(@gh5_bm, N'Bánh mì pate chả', 20000, NULL),
(@gh5_bm, N'Bánh mì trứng ốp la', 18000, NULL),
(@gh5_bm, N'Bánh mì xíu mại', 22000, NULL),
(@gh5_nuoc, N'Sữa đậu nành', 10000, NULL);

-- Gà Rán Cô Út
INSERT INTO DanhMuc (MaGianHang, TenDanhMuc) VALUES (@gh6, N'Gà rán'), (@gh6, N'Món ăn kèm'), (@gh6, N'Nước ngọt');
DECLARE @gh6_ga INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh6 AND TenDanhMuc=N'Gà rán');
DECLARE @gh6_kem INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh6 AND TenDanhMuc=N'Món ăn kèm');
DECLARE @gh6_nuoc INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh6 AND TenDanhMuc=N'Nước ngọt');
INSERT INTO MonAn (MaDanhMuc, TenMon, Gia, MoTa) VALUES
(@gh6_ga, N'Gà rán miếng đùi', 35000, NULL),
(@gh6_ga, N'Combo 2 miếng gà + cơm', 55000, NULL),
(@gh6_kem, N'Khoai tây chiên', 20000, NULL),
(@gh6_kem, N'Salad trộn', 15000, NULL),
(@gh6_nuoc, N'Pepsi lon', 12000, NULL);

-- Hủ Tiếu Nam Vang
INSERT INTO DanhMuc (MaGianHang, TenDanhMuc) VALUES (@gh7, N'Hủ tiếu'), (@gh7, N'Nước uống');
DECLARE @gh7_ht INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh7 AND TenDanhMuc=N'Hủ tiếu');
DECLARE @gh7_nuoc INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh7 AND TenDanhMuc=N'Nước uống');
INSERT INTO MonAn (MaDanhMuc, TenMon, Gia, MoTa) VALUES
(@gh7_ht, N'Hủ tiếu Nam Vang', 45000, NULL),
(@gh7_ht, N'Hủ tiếu khô', 45000, NULL),
(@gh7_ht, N'Hủ tiếu đặc biệt', 55000, N'Tôm, thịt bằm, gan, trứng cút'),
(@gh7_nuoc, N'Trà đá', 5000, NULL);

-- Chè Ba Miền
INSERT INTO DanhMuc (MaGianHang, TenDanhMuc) VALUES (@gh8, N'Chè'), (@gh8, N'Sữa chua');
DECLARE @gh8_che INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh8 AND TenDanhMuc=N'Chè');
DECLARE @gh8_sc INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang=@gh8 AND TenDanhMuc=N'Sữa chua');
INSERT INTO MonAn (MaDanhMuc, TenMon, Gia, MoTa) VALUES
(@gh8_che, N'Chè đậu xanh', 18000, NULL),
(@gh8_che, N'Chè bà ba', 20000, NULL),
(@gh8_che, N'Chè thái', 25000, NULL),
(@gh8_che, N'Chè khúc bạch', 25000, NULL),
(@gh8_sc, N'Sữa chua nếp cẩm', 20000, NULL),
(@gh8_sc, N'Sữa chua trân châu', 20000, NULL);
GO

/* ============================================================
   PHẦN 4: KHUYẾN MÃI MẪU
   ============================================================ */
DECLARE @gh_bunbo INT = (SELECT MaGianHang FROM GianHang WHERE TenCuaHang = N'Bún Bò Huế Mệ Ba');
DECLARE @gh_traSua INT = (SELECT MaGianHang FROM GianHang WHERE TenCuaHang = N'Trà Sữa Mộc Trà');

INSERT INTO KhuyenMai (MaGianHang, MaCode, MoTa, PhanTramGiam, SoTienGiam, DieuKienApDung, NgayBatDau, NgayKetThuc) VALUES
(NULL, N'CHAODON10', N'Giảm 10% cho đơn hàng đầu tiên toàn hệ thống', 10, NULL, N'Áp dụng 1 lần/tài khoản', '2026-01-01', '2026-12-31'),
(NULL, N'FREESHIP', N'Miễn phí giao hàng cho đơn từ 150.000đ', NULL, 15000, N'Đơn tối thiểu 150.000đ', '2026-01-01', '2026-12-31'),
(@gh_bunbo, N'BUNBO20K', N'Giảm 20.000đ cho đơn từ 100.000đ tại Bún Bò Huế Mệ Ba', NULL, 20000, N'Đơn tối thiểu 100.000đ', '2026-01-01', '2026-12-31'),
(@gh_traSua, N'TRASUA15', N'Giảm 15% cho mọi đơn trà sữa', 15, NULL, N'Không giới hạn giá trị đơn', '2026-01-01', '2026-12-31');
GO

/* ============================================================
   PHẦN 5: ĐƠN HÀNG MẪU (kèm chi tiết, thanh toán, giao hàng, đánh giá)
   ============================================================ */
DECLARE @kh1 INT = (SELECT MaKH FROM KhachHang WHERE SDT = '0901000001');
DECLARE @kh2 INT = (SELECT MaKH FROM KhachHang WHERE SDT = '0907000007');
DECLARE @tx1 INT = (SELECT MaTaiXe FROM TaiXe WHERE SDT = '0903000003');
DECLARE @tx2 INT = (SELECT MaTaiXe FROM TaiXe WHERE SDT = '0906000006');
DECLARE @gh1_id INT = (SELECT MaGianHang FROM GianHang WHERE TenCuaHang = N'Quán Cơm Tấm Cô Ba');
DECLARE @gh2_id INT = (SELECT MaGianHang FROM GianHang WHERE TenCuaHang = N'Bún Bò Huế Mệ Ba');
DECLARE @mon_com1 INT = (SELECT MaMonAn FROM MonAn WHERE TenMon = N'Cơm sườn bì chả');
DECLARE @mon_bunbo1 INT = (SELECT MaMonAn FROM MonAn WHERE TenMon = N'Bún bò giò heo');

-- Đơn 1: đã giao thành công
INSERT INTO DonHang (MaKH, MaGianHang, MaTaiXe, TrangThai, TongTien, PhiGiaoHang, DiaChiGiaoHang)
VALUES (@kh1, @gh1_id, @tx1, N'DaGiao', 45000, 15000, N'123 Lê Lợi, Q.1, TP.HCM');
DECLARE @dh1 INT = SCOPE_IDENTITY();
INSERT INTO ChiTietDonHang (MaDonHang, MaMonAn, SoLuong, DonGia) VALUES (@dh1, @mon_com1, 1, 45000);
INSERT INTO ThanhToan (MaDonHang, HinhThuc, TrangThai, NgayThanhToan) VALUES (@dh1, N'Momo', N'DaThanhToan', GETDATE());
INSERT INTO GiaoHang (MaDonHang, MaTaiXe, TrangThai, ThoiGianNhan, ThoiGianGiao)
VALUES (@dh1, @tx1, N'GiaoThanhCong', DATEADD(MINUTE,-40,GETDATE()), DATEADD(MINUTE,-10,GETDATE()));
INSERT INTO DanhGia (MaKH, MaGianHang, MaDonHang, SoSao, NoiDung) VALUES (@kh1, @gh1_id, @dh1, 5, N'Cơm ngon, giao nhanh');

-- Đơn 2: đang giao
INSERT INTO DonHang (MaKH, MaGianHang, MaTaiXe, TrangThai, TongTien, PhiGiaoHang, DiaChiGiaoHang)
VALUES (@kh2, @gh2_id, @tx2, N'DangGiao', 55000, 20000, N'56 Lý Thường Kiệt, Q.10, TP.HCM');
DECLARE @dh2 INT = SCOPE_IDENTITY();
INSERT INTO ChiTietDonHang (MaDonHang, MaMonAn, SoLuong, DonGia) VALUES (@dh2, @mon_bunbo1, 1, 55000);
INSERT INTO ThanhToan (MaDonHang, HinhThuc, TrangThai) VALUES (@dh2, N'VNPay', N'DaThanhToan');
INSERT INTO GiaoHang (MaDonHang, MaTaiXe, TrangThai, ThoiGianNhan) VALUES (@dh2, @tx2, N'DangGiao', DATEADD(MINUTE,-10,GETDATE()));

-- Đơn 3: chờ xác nhận (chưa gán tài xế)
INSERT INTO DonHang (MaKH, MaGianHang, TrangThai, TongTien, DiaChiGiaoHang)
VALUES (@kh1, @gh2_id, N'ChoXacNhan', 65000, N'123 Lê Lợi, Q.1, TP.HCM');
DECLARE @dh3 INT = SCOPE_IDENTITY();
INSERT INTO ChiTietDonHang (MaDonHang, MaMonAn, SoLuong, DonGia)
SELECT @dh3, MaMonAn, 1, Gia FROM MonAn WHERE TenMon = N'Bún bò đặc biệt';
INSERT INTO ThanhToan (MaDonHang, HinhThuc, TrangThai) VALUES (@dh3, N'TienMat', N'ChoThanhToan');
GO

PRINT N'Hoàn tất: CSDL QuanLyDichVuAnUong với 17 bảng (đúng đề cương: KhachHang/GianHang/QuanTri + Shipper hỗ trợ giao hàng), 8 gian hàng, ~45 món ăn, 5 khách hàng, 2 quản trị viên, 4 tài xế, 4 khuyến mãi, 3 đơn hàng mẫu.';

/* ============================================================
   PHẦN 6: CẬP NHẬT MẬT KHẨU DEMO CHO TÀI KHOẢN MẪU BAN ĐẦU
   (8 gian hàng, 5 khách hàng, 4 tài xế, 2 quản trị viên ở PHẦN 2-4 ở trên)
   Lưu dạng BCrypt (không plaintext). CHỈ DÙNG DEMO: trước khi đưa lên môi trường thật hãy chạy Database/BaoMat_VoHieuHoaTaiKhoanMau.sql.
   ============================================================ */

-- Khách hàng: mật khẩu = 123456
UPDATE TaiKhoan SET MatKhau = '$2b$11$/kiGvUEE4J218RaDaW8cReCEE3eH53tJBuwpXN5FzQc/BPWr3MHMO' WHERE VaiTro = N'KhachHang';

-- Gian hàng (quán ăn / đối tác): mật khẩu = 123456
UPDATE TaiKhoan SET MatKhau = '$2b$11$/kiGvUEE4J218RaDaW8cReCEE3eH53tJBuwpXN5FzQc/BPWr3MHMO' WHERE VaiTro = N'GianHang';

-- Tài xế: mật khẩu = 123456
UPDATE TaiKhoan SET MatKhau = '$2b$11$/kiGvUEE4J218RaDaW8cReCEE3eH53tJBuwpXN5FzQc/BPWr3MHMO' WHERE VaiTro = N'TaiXe';

-- Quản trị: mật khẩu = admin123 (đổi riêng cho dễ phân biệt khi demo)
UPDATE TaiKhoan SET MatKhau = '$2b$11$OEARrK8p.cB1O2wFsKq.j.2mAuC/7.MsCfpubv6AXzRqwqG9QDkaS' WHERE VaiTro = N'QuanTri';
GO

-- Xem lại danh sách tài khoản vừa cập nhật để đối chiếu khi đăng nhập thử
SELECT
    t.MaTK,
    t.TenDangNhap,
    t.MatKhau,
    t.VaiTro,
    COALESCE(kh.HoTen, gh.TenCuaHang, tx.HoTen, qt.HoTen) AS TenHienThi
FROM TaiKhoan t
LEFT JOIN KhachHang kh ON kh.MaTK = t.MaTK
LEFT JOIN GianHang gh ON gh.MaTK = t.MaTK
LEFT JOIN TaiXe tx ON tx.MaTK = t.MaTK
LEFT JOIN QuanTri qt ON qt.MaTK = t.MaTK
ORDER BY t.VaiTro, t.MaTK;
GO

/* ============================================================
   PHẦN 7: SINH DỮ LIỆU LỚN — 100 KHÁCH HÀNG, 30 QUÁN ĂN, 40 TÀI XẾ
   Mật khẩu tất cả tài khoản sinh ra = 123456 (plaintext, chỉ để demo).
   ============================================================ */

-- ---------- Bảng tạm chứa các thành phần tên tiếng Việt để ghép ngẫu nhiên ----------
DECLARE @Ho TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(20));
INSERT INTO @Ho (Ten) VALUES
(N'Nguyễn'),(N'Trần'),(N'Lê'),(N'Phạm'),(N'Hoàng'),(N'Huỳnh'),(N'Phan'),(N'Vũ'),
(N'Võ'),(N'Đặng'),(N'Bùi'),(N'Đỗ'),(N'Hồ'),(N'Ngô'),(N'Dương'),(N'Lý');

DECLARE @TenDemNam TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(20));
INSERT INTO @TenDemNam (Ten) VALUES (N'Văn'),(N'Hữu'),(N'Đức'),(N'Công'),(N'Quang'),(N'Minh'),(N'Thành'),(N'Anh');

DECLARE @TenDemNu TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(20));
INSERT INTO @TenDemNu (Ten) VALUES (N'Thị'),(N'Ngọc'),(N'Thu'),(N'Kim'),(N'Hồng'),(N'Bích'),(N'Diễm'),(N'Ánh');

DECLARE @TenNam TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(20));
INSERT INTO @TenNam (Ten) VALUES
(N'An'),(N'Bình'),(N'Cường'),(N'Dũng'),(N'Đạt'),(N'Hải'),(N'Hùng'),(N'Khang'),
(N'Long'),(N'Minh'),(N'Nam'),(N'Phong'),(N'Quân'),(N'Sơn'),(N'Tài'),(N'Thắng'),
(N'Tuấn'),(N'Việt'),(N'Vinh'),(N'Đăng');

DECLARE @TenNu TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(20));
INSERT INTO @TenNu (Ten) VALUES
(N'Anh'),(N'Chi'),(N'Diệp'),(N'Giang'),(N'Hà'),(N'Hoa'),(N'Huyền'),(N'Lan'),
(N'Linh'),(N'Mai'),(N'My'),(N'Ngân'),(N'Nhi'),(N'Phương'),(N'Quyên'),(N'Thảo'),
(N'Thư'),(N'Trang'),(N'Vy'),(N'Yến');

DECLARE @QuanHuyen TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(50));
INSERT INTO @QuanHuyen (Ten) VALUES
(N'Quận 1'),(N'Quận 3'),(N'Quận 4'),(N'Quận 5'),(N'Quận 6'),(N'Quận 7'),
(N'Quận 8'),(N'Quận 10'),(N'Quận 11'),(N'Quận 12'),(N'Bình Thạnh'),(N'Tân Bình'),
(N'Tân Phú'),(N'Phú Nhuận'),(N'Gò Vấp'),(N'Bình Tân'),(N'Thủ Đức');

DECLARE @TenDuong TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(50));
INSERT INTO @TenDuong (Ten) VALUES
(N'Lê Lợi'),(N'Nguyễn Trãi'),(N'Trần Hưng Đạo'),(N'Cách Mạng Tháng 8'),
(N'Nguyễn Thị Minh Khai'),(N'Điện Biên Phủ'),(N'Hai Bà Trưng'),(N'Ba Tháng Hai'),
(N'Lý Thường Kiệt'),(N'Nguyễn Văn Cừ'),(N'Sư Vạn Hạnh'),(N'Cộng Hòa'),
(N'Phan Xích Long'),(N'Quang Trung'),(N'Nguyễn Oanh');

-- ---------- Loại hình quán ăn để đặt tên gian hàng ----------
DECLARE @LoaiQuan TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(50));
INSERT INTO @LoaiQuan (Ten) VALUES
(N'Cơm Tấm'),(N'Bún Bò Huế'),(N'Phở'),(N'Bánh Mì'),(N'Hủ Tiếu'),(N'Bún Riêu'),
(N'Mì Quảng'),(N'Cơm Gà'),(N'Trà Sữa'),(N'Chè'),(N'Gà Rán'),(N'Pizza'),
(N'Bún Chả'),(N'Bánh Xèo'),(N'Lẩu'),(N'Nướng BBQ'),(N'Sushi'),(N'Bún Đậu'),
(N'Xôi'),(N'Ốc'),(N'Trà Chanh'),(N'Bánh Canh'),(N'Cháo'),(N'Cơm Niêu'),
(N'Bò Kho'),(N'Nem Nướng'),(N'Bánh Cuốn'),(N'Cà Phê'),(N'Sinh Tố'),(N'Bún Thịt Nướng');

DECLARE @TenChuQuan TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(30));
INSERT INTO @TenChuQuan (Ten) VALUES
(N'Cô Ba'),(N'Cô Út'),(N'Cô Sáu'),(N'Cô Tư'),(N'Chú Hai'),(N'Chú Bảy'),
(N'Mẹ Ba'),(N'Bà Năm'),(N'Anh Tuấn'),(N'Chị Hoa'),(N'Sài Gòn'),(N'Hà Nội'),
(N'Miền Tây'),(N'Ba Miền'),(N'Xưa'),(N'136'),(N'168'),(N'Number One'),
(N'Gia Truyền'),(N'Truyền Thống'),(N'Ngon'),(N'Đệ Nhất'),(N'Phố'),(N'Quê'),
(N'Nhà Làm'),(N'Việt'),(N'Sài Thành'),(N'Ông Địa'),(N'Cây Bàng'),(N'Xóm Nhỏ');

-- ==============================================================
-- 100 TÀI KHOẢN KHÁCH HÀNG
-- ==============================================================
DECLARE @i INT = 1;
WHILE @i <= 100
BEGIN
    DECLARE @tenDangNhap NVARCHAR(50) = N'khachhang' + RIGHT('000' + CAST(@i AS VARCHAR), 3);
    DECLARE @laNam BIT = @i % 2;
    DECLARE @hoLot NVARCHAR(20) = (SELECT Ten FROM @Ho WHERE STT = @i % 16);
    DECLARE @tenDem NVARCHAR(20) = CASE WHEN @laNam = 1
        THEN (SELECT Ten FROM @TenDemNam WHERE STT = @i % 8)
        ELSE (SELECT Ten FROM @TenDemNu WHERE STT = @i % 8) END;
    DECLARE @ten NVARCHAR(20) = CASE WHEN @laNam = 1
        THEN (SELECT Ten FROM @TenNam WHERE STT = @i % 20)
        ELSE (SELECT Ten FROM @TenNu WHERE STT = @i % 20) END;
    DECLARE @hoTen NVARCHAR(100) = @hoLot + N' ' + @tenDem + N' ' + @ten;
    DECLARE @sdt VARCHAR(15) = '09' + RIGHT('00000000' + CAST(30000000 + @i AS VARCHAR), 8);
    DECLARE @diaChi NVARCHAR(255) =
        CAST(10 + (@i % 90) AS VARCHAR) + N' Đường ' +
        (SELECT Ten FROM @TenDuong WHERE STT = @i % 15) + N', ' +
        (SELECT Ten FROM @QuanHuyen WHERE STT = @i % 17) + N', TP.HCM';

    INSERT INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro) VALUES (@tenDangNhap, '$2b$11$/kiGvUEE4J218RaDaW8cReCEE3eH53tJBuwpXN5FzQc/BPWr3MHMO', N'KhachHang');
    DECLARE @maTK INT = SCOPE_IDENTITY();

    INSERT INTO KhachHang (MaTK, HoTen, SDT, Email, DiaChiGiaoHang)
    VALUES (@maTK, @hoTen, @sdt, LOWER(REPLACE(@tenDangNhap, N' ', '')) + '@gmail.com', @diaChi);

    SET @i += 1;
END
GO

-- ==============================================================
-- 30 TÀI KHOẢN QUÁN ĂN (GIAN HÀNG)
-- ==============================================================
DECLARE @Ho TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(20));
INSERT INTO @Ho (Ten) VALUES
(N'Nguyễn'),(N'Trần'),(N'Lê'),(N'Phạm'),(N'Hoàng'),(N'Huỳnh'),(N'Phan'),(N'Vũ'),
(N'Võ'),(N'Đặng'),(N'Bùi'),(N'Đỗ'),(N'Hồ'),(N'Ngô'),(N'Dương'),(N'Lý');

DECLARE @QuanHuyen TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(50));
INSERT INTO @QuanHuyen (Ten) VALUES
(N'Quận 1'),(N'Quận 3'),(N'Quận 4'),(N'Quận 5'),(N'Quận 6'),(N'Quận 7'),
(N'Quận 8'),(N'Quận 10'),(N'Quận 11'),(N'Quận 12'),(N'Bình Thạnh'),(N'Tân Bình'),
(N'Tân Phú'),(N'Phú Nhuận'),(N'Gò Vấp'),(N'Bình Tân'),(N'Thủ Đức');

DECLARE @TenDuong TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(50));
INSERT INTO @TenDuong (Ten) VALUES
(N'Lê Lợi'),(N'Nguyễn Trãi'),(N'Trần Hưng Đạo'),(N'Cách Mạng Tháng 8'),
(N'Nguyễn Thị Minh Khai'),(N'Điện Biên Phủ'),(N'Hai Bà Trưng'),(N'Ba Tháng Hai'),
(N'Lý Thường Kiệt'),(N'Nguyễn Văn Cừ'),(N'Sư Vạn Hạnh'),(N'Cộng Hòa'),
(N'Phan Xích Long'),(N'Quang Trung'),(N'Nguyễn Oanh');

DECLARE @LoaiQuan TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(50));
INSERT INTO @LoaiQuan (Ten) VALUES
(N'Cơm Tấm'),(N'Bún Bò Huế'),(N'Phở'),(N'Bánh Mì'),(N'Hủ Tiếu'),(N'Bún Riêu'),
(N'Mì Quảng'),(N'Cơm Gà'),(N'Trà Sữa'),(N'Chè'),(N'Gà Rán'),(N'Pizza'),
(N'Bún Chả'),(N'Bánh Xèo'),(N'Lẩu'),(N'Nướng BBQ'),(N'Sushi'),(N'Bún Đậu'),
(N'Xôi'),(N'Ốc'),(N'Trà Chanh'),(N'Bánh Canh'),(N'Cháo'),(N'Cơm Niêu'),
(N'Bò Kho'),(N'Nem Nướng'),(N'Bánh Cuốn'),(N'Cà Phê'),(N'Sinh Tố'),(N'Bún Thịt Nướng');

DECLARE @TenChuQuan TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(30));
INSERT INTO @TenChuQuan (Ten) VALUES
(N'Cô Ba'),(N'Cô Út'),(N'Cô Sáu'),(N'Cô Tư'),(N'Chú Hai'),(N'Chú Bảy'),
(N'Mẹ Ba'),(N'Bà Năm'),(N'Anh Tuấn'),(N'Chị Hoa'),(N'Sài Gòn'),(N'Hà Nội'),
(N'Miền Tây'),(N'Ba Miền'),(N'Xưa'),(N'136'),(N'168'),(N'Number One'),
(N'Gia Truyền'),(N'Truyền Thống'),(N'Ngon'),(N'Đệ Nhất'),(N'Phố'),(N'Quê'),
(N'Nhà Làm'),(N'Việt'),(N'Sài Thành'),(N'Ông Địa'),(N'Cây Bàng'),(N'Xóm Nhỏ');

DECLARE @j INT = 1;
WHILE @j <= 30
BEGIN
    DECLARE @tenDN NVARCHAR(50) = N'gianhang' + RIGHT('000' + CAST(@j AS VARCHAR), 3);
    DECLARE @tenCuaHang NVARCHAR(150) =
        (SELECT Ten FROM @LoaiQuan WHERE STT = (@j - 1) % 30) + N' ' +
        (SELECT Ten FROM @TenChuQuan WHERE STT = @j % 30);
    DECLARE @diaChiQ NVARCHAR(255) =
        CAST(5 + (@j % 200) AS VARCHAR) + N' ' +
        (SELECT Ten FROM @TenDuong WHERE STT = @j % 15) + N', ' +
        (SELECT Ten FROM @QuanHuyen WHERE STT = @j % 17) + N', TP.HCM';
    DECLARE @sdtQ VARCHAR(15) = '09' + RIGHT('00000000' + CAST(40000000 + @j AS VARCHAR), 8);

    INSERT INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro) VALUES (@tenDN, '$2b$11$/kiGvUEE4J218RaDaW8cReCEE3eH53tJBuwpXN5FzQc/BPWr3MHMO', N'GianHang');
    DECLARE @maTKQ INT = SCOPE_IDENTITY();

    INSERT INTO GianHang (MaTK, TenCuaHang, DiaChi, SDT, MoTa, TrangThaiKinhDoanh, TrangThaiDuyet)
    VALUES (@maTKQ, @tenCuaHang, @diaChiQ, @sdtQ, N'Quán ăn phục vụ tận tâm, nguyên liệu tươi mỗi ngày',
            CASE WHEN @j % 10 = 0 THEN N'TamNgung' ELSE N'DangMo' END, N'DaDuyet');

    -- Mỗi gian hàng có sẵn 1 danh mục "Món chính" + 3 món ăn cơ bản để không bị trống thực đơn
    DECLARE @maGH INT = SCOPE_IDENTITY();
    INSERT INTO DanhMuc (MaGianHang, TenDanhMuc) VALUES (@maGH, N'Món chính');
    DECLARE @maDM INT = SCOPE_IDENTITY();

    INSERT INTO MonAn (MaDanhMuc, TenMon, Gia, TinhTrang) VALUES
    (@maDM, (SELECT Ten FROM @LoaiQuan WHERE STT = (@j - 1) % 30) + N' đặc biệt', 45000 + (@j % 6) * 5000, N'ConHang'),
    (@maDM, (SELECT Ten FROM @LoaiQuan WHERE STT = (@j - 1) % 30) + N' thường', 35000 + (@j % 5) * 3000, N'ConHang'),
    (@maDM, N'Nước ngọt', 12000, N'ConHang');

    SET @j += 1;
END
GO

-- ==============================================================
-- 40 TÀI KHOẢN TÀI XẾ
-- ==============================================================
DECLARE @Ho2 TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(20));
INSERT INTO @Ho2 (Ten) VALUES
(N'Nguyễn'),(N'Trần'),(N'Lê'),(N'Phạm'),(N'Hoàng'),(N'Huỳnh'),(N'Phan'),(N'Vũ'),
(N'Võ'),(N'Đặng'),(N'Bùi'),(N'Đỗ'),(N'Hồ'),(N'Ngô'),(N'Dương'),(N'Lý');

DECLARE @TenDemNam2 TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(20));
INSERT INTO @TenDemNam2 (Ten) VALUES (N'Văn'),(N'Hữu'),(N'Đức'),(N'Công'),(N'Quang'),(N'Minh'),(N'Thành'),(N'Anh');

DECLARE @TenNam2 TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(20));
INSERT INTO @TenNam2 (Ten) VALUES
(N'An'),(N'Bình'),(N'Cường'),(N'Dũng'),(N'Đạt'),(N'Hải'),(N'Hùng'),(N'Khang'),
(N'Long'),(N'Minh'),(N'Nam'),(N'Phong'),(N'Quân'),(N'Sơn'),(N'Tài'),(N'Thắng'),
(N'Tuấn'),(N'Việt'),(N'Vinh'),(N'Đăng');

DECLARE @QuanHuyen2 TABLE (STT INT IDENTITY(0,1), Ten NVARCHAR(50));
INSERT INTO @QuanHuyen2 (Ten) VALUES
(N'Quận 1'),(N'Quận 3'),(N'Quận 4'),(N'Quận 5'),(N'Quận 6'),(N'Quận 7'),
(N'Quận 8'),(N'Quận 10'),(N'Quận 11'),(N'Quận 12'),(N'Bình Thạnh'),(N'Tân Bình'),
(N'Tân Phú'),(N'Phú Nhuận'),(N'Gò Vấp'),(N'Bình Tân'),(N'Thủ Đức');

DECLARE @k INT = 1;
WHILE @k <= 40
BEGIN
    DECLARE @tenDNTX NVARCHAR(50) = N'taixe' + RIGHT('000' + CAST(@k AS VARCHAR), 3);
    DECLARE @hoTX NVARCHAR(20) = (SELECT Ten FROM @Ho2 WHERE STT = @k % 16);
    DECLARE @tenDemTX NVARCHAR(20) = (SELECT Ten FROM @TenDemNam2 WHERE STT = @k % 8);
    DECLARE @tenTX NVARCHAR(20) = (SELECT Ten FROM @TenNam2 WHERE STT = @k % 20);
    DECLARE @hoTenTX NVARCHAR(100) = @hoTX + N' ' + @tenDemTX + N' ' + @tenTX;
    DECLARE @sdtTX VARCHAR(15) = '09' + RIGHT('00000000' + CAST(50000000 + @k AS VARCHAR), 8);
    DECLARE @khuVuc NVARCHAR(150) =
        (SELECT Ten FROM @QuanHuyen2 WHERE STT = @k % 17) + N', ' +
        (SELECT Ten FROM @QuanHuyen2 WHERE STT = (@k + 3) % 17);
    DECLARE @phuongTien NVARCHAR(50) = CASE WHEN @k % 5 = 0 THEN N'Xe đạp điện' ELSE N'Xe máy' END;
    DECLARE @bienSo VARCHAR(20) = N'59-' + CHAR(65 + (@k % 26)) + N'1-' +
        RIGHT('00000' + CAST(10000 + @k AS VARCHAR), 5);

    INSERT INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro) VALUES (@tenDNTX, '$2b$11$/kiGvUEE4J218RaDaW8cReCEE3eH53tJBuwpXN5FzQc/BPWr3MHMO', N'TaiXe');
    DECLARE @maTKTX INT = SCOPE_IDENTITY();

    INSERT INTO TaiXe (MaTK, HoTen, SDT, PhuongTien, BienSo, KhuVucHoatDong, TrangThai)
    VALUES (@maTKTX, @hoTenTX, @sdtTX, @phuongTien, @bienSo, @khuVuc,
            CASE WHEN @k % 7 = 0 THEN N'NgoaiTuyen' ELSE N'SanSang' END);

    SET @k += 1;
END
GO

PRINT N'Đã sinh xong: 100 khách hàng, 30 gian hàng (kèm 3 món/gian hàng), 40 tài xế. Mật khẩu tất cả = 123456.';

SELECT VaiTro, COUNT(*) AS SoLuong FROM TaiKhoan
WHERE TenDangNhap LIKE 'khachhang0%' OR TenDangNhap LIKE 'gianhang0%' OR TenDangNhap LIKE 'taixe0%'
GROUP BY VaiTro;
GO

/* ============================================================
   PHẦN 8: DỮ LIỆU MẪU CHO CÁC CHỨC NĂNG MỚI (sổ địa chỉ, đánh giá món...)
   ============================================================ */

-- Sổ địa chỉ: mỗi khách mẫu có 1 địa chỉ mặc định từ hồ sơ
INSERT INTO DiaChiKhachHang (MaKH, Nhan, DiaChi, MacDinh)
SELECT MaKH, N'Nhà', DiaChiGiaoHang, 1 FROM KhachHang WHERE DiaChiGiaoHang IS NOT NULL;
GO

-- Đánh giá món ăn mẫu (cho các đơn đã giao có chi tiết món)
INSERT INTO DanhGiaMon (MaKH, MaMonAn, MaDonHang, SoSao, NoiDung)
SELECT TOP 5 d.MaKH, c.MaMonAn, d.MaDonHang, 5, N'Món ngon, đúng vị'
FROM DonHang d JOIN ChiTietDonHang c ON c.MaDonHang = d.MaDonHang
WHERE d.TrangThai = N'DaGiao';
GO

-- Phản hồi mẫu
INSERT INTO PhanHoi (MaKH, Loai, TieuDe, NoiDung)
SELECT TOP 1 MaKH, N'GopY', N'Mong có thêm nhiều quán trong khu vực', N'Ứng dụng dùng rất tiện, mong sớm có thêm quán ở khu vực của mình.'
FROM KhachHang ORDER BY MaKH;
GO

/* ============================================================
   TỔNG KẾT TOÀN BỘ
   ============================================================ */
PRINT N'====== HOÀN TẤT TOÀN BỘ FILE ======';

SELECT VaiTro, COUNT(*) AS TongSoTaiKhoan FROM TaiKhoan GROUP BY VaiTro;
SELECT COUNT(*) AS TongSoGianHang FROM GianHang;
SELECT COUNT(*) AS TongSoMonAn FROM MonAn;
SELECT COUNT(*) AS TongSoDonHangMau FROM DonHang;
GO

/* ============================================================
   GHI CHÚ: nếu bạn ĐÃ có CSDL QuanLyDichVuAnUong chạy từ trước (tạo bằng
   bản cũ hơn của file này) và không muốn DROP/tạo lại từ đầu, KHÔNG chạy
   các lệnh ALTER thủ công ở đây — hãy chạy file NangCap_CSDL.sql đi kèm,
   đã gộp đầy đủ mọi cột/bảng còn thiếu và an toàn để chạy lại nhiều lần.
   ============================================================ */

/* ============================================================
   PHẦN 9: GÁN HÌNH ẢNH MINH HOẠ cho Gian hàng / Món ăn
   Ảnh SVG tự vẽ (không vi phạm bản quyền) đặt sẵn ở wwwroot/uploads/ —
   khớp theo TÊN (an toàn dù ID tự tăng khác nhau giữa các lần tạo DB).
   ============================================================ */

-- 1) Ảnh đại diện Gian hàng
UPDATE GianHang SET HinhAnh = N'/uploads/gh1_comtam_coba.svg'     WHERE TenCuaHang = N'Quán Cơm Tấm Cô Ba';
UPDATE GianHang SET HinhAnh = N'/uploads/gh2_bunbo_meba.svg'      WHERE TenCuaHang = N'Bún Bò Huế Mệ Ba';
UPDATE GianHang SET HinhAnh = N'/uploads/gh3_trasua_moctra.svg'   WHERE TenCuaHang = N'Trà Sữa Mộc Trà';
UPDATE GianHang SET HinhAnh = N'/uploads/gh4_pho_hanoi.svg'       WHERE TenCuaHang = N'Phở Hà Nội Xưa';
UPDATE GianHang SET HinhAnh = N'/uploads/gh5_banhmi_bahuynh.svg'  WHERE TenCuaHang = N'Bánh Mì Bà Huynh';
UPDATE GianHang SET HinhAnh = N'/uploads/gh6_garan_cout.svg'      WHERE TenCuaHang = N'Gà Rán Cô Út';
UPDATE GianHang SET HinhAnh = N'/uploads/gh7_hutieu_namvang.svg'  WHERE TenCuaHang = N'Hủ Tiếu Nam Vang Sáu Sài Gòn';
UPDATE GianHang SET HinhAnh = N'/uploads/gh8_che_bamien.svg'      WHERE TenCuaHang = N'Chè Ba Miền';
GO

-- 2) Ảnh món ăn tiêu biểu (1 món/gian hàng — có thể tự thêm ảnh cho các món còn lại theo mẫu này)
UPDATE MonAn SET HinhAnh = N'/uploads/mon1_com_suon_bi_cha.svg'              WHERE TenMon = N'Cơm sườn bì chả';
UPDATE MonAn SET HinhAnh = N'/uploads/mon2_bun_bo_gio_heo.svg'               WHERE TenMon = N'Bún bò giò heo';
UPDATE MonAn SET HinhAnh = N'/uploads/mon3_trasua_tranchau_duongden.svg'     WHERE TenMon = N'Trà sữa trân châu đường đen';
UPDATE MonAn SET HinhAnh = N'/uploads/mon4_pho_dac_biet.svg'                 WHERE TenMon = N'Phở đặc biệt';
UPDATE MonAn SET HinhAnh = N'/uploads/mon5_banhmi_thitnuong.svg'             WHERE TenMon = N'Bánh mì thịt nướng';
UPDATE MonAn SET HinhAnh = N'/uploads/mon6_combo_ga_com.svg'                 WHERE TenMon = N'Combo 2 miếng gà + cơm';
UPDATE MonAn SET HinhAnh = N'/uploads/mon7_hutieu_dac_biet.svg'              WHERE TenMon = N'Hủ tiếu đặc biệt';
UPDATE MonAn SET HinhAnh = N'/uploads/mon8_che_thai.svg'                     WHERE TenMon = N'Chè thái';
GO

-- Kiểm tra nhanh
SELECT TenCuaHang, HinhAnh FROM GianHang;
SELECT TenMon, HinhAnh FROM MonAn WHERE HinhAnh IS NOT NULL;

/* ============================================================
   PHẦN 10: BỔ SUNG CHO APP MAUI v8 (chạy được NHIỀU LẦN, an toàn)
   - Tài xế: CCCD, GPLX, ảnh GPLX, lý do từ chối (khóa tài khoản dùng TaiKhoan.TrangThai = 0)
   - Tin nhắn khách <-> tài xế theo đơn hàng (bảng TinNhan)
   - Khuyến mãi: loại giảm (kể cả GIẢM PHÍ GIAO), giảm tối đa, đơn tối thiểu, số lượt,
     mỗi khách 1 lần, giới hạn món / danh mục / gian hàng
   - Giao hàng: bước tài xế, phụ cấp, điểm & nhận xét của khách cho tài xế, lý do thất bại, ảnh giao
   - Đơn hàng: SanSangGiao (quán đã làm xong, chờ tài xế); đánh giá: thẻ nhận xét
   - Thanh toán: cho phép ChuyenKhoan, ViDienTu (app gửi 2 giá trị này)

   Ánh xạ trạng thái đơn app <-> DB:
     ChoXacNhan -> ChoXacNhan | DangLam -> DaXacNhan (SanSangGiao = 0: đang chuẩn bị; =1 & MaTaiXe NULL: chờ tài xế)
     DangGiao -> DangGiao | HoanThanh -> DaGiao | DaHuy -> DaHuy
   Ánh xạ khuyến mãi: GiaTriGiam -> PhanTramGiam (LoaiGiam = PhanTram) hoặc SoTienGiam (SoTien / GiamPhiVanChuyen;
     GiamPhiVanChuyen với SoTienGiam NULL hoặc 0 = miễn phí giao hàng)
   ============================================================ */
USE QuanLyDichVuAnUong;
GO

/* ---- 10.1 TaiXe: hồ sơ xét duyệt ---- */
IF COL_LENGTH('TaiXe', 'SoCCCD') IS NULL     ALTER TABLE TaiXe ADD SoCCCD   VARCHAR(20)   NULL;
IF COL_LENGTH('TaiXe', 'SoGPLX') IS NULL     ALTER TABLE TaiXe ADD SoGPLX   VARCHAR(20)   NULL;
IF COL_LENGTH('TaiXe', 'AnhGPLX') IS NULL    ALTER TABLE TaiXe ADD AnhGPLX  NVARCHAR(500) NULL;
IF COL_LENGTH('TaiXe', 'LyDoTuChoi') IS NULL ALTER TABLE TaiXe ADD LyDoTuChoi NVARCHAR(255) NULL;
GO

/* ---- 10.2 DonHang / GiaoHang / DanhGia ---- */
IF COL_LENGTH('DonHang', 'SanSangGiao') IS NULL
    ALTER TABLE DonHang ADD SanSangGiao BIT NOT NULL CONSTRAINT DF_DonHang_SanSangGiao DEFAULT 0;
IF COL_LENGTH('DanhGia', 'SoSaoMon') IS NULL
    ALTER TABLE DanhGia ADD SoSaoMon INT NULL CONSTRAINT CK_DanhGia_SaoMon CHECK (SoSaoMon BETWEEN 1 AND 5);   -- điểm riêng cho món (SoSao = quán)
GO
IF COL_LENGTH('DanhGia', 'TheNhanXet') IS NULL
    ALTER TABLE DanhGia ADD TheNhanXet NVARCHAR(300) NULL;      -- các thẻ khách chọn, ngăn cách bằng |
IF COL_LENGTH('GiaoHang', 'BuocTaiXe') IS NULL
    ALTER TABLE GiaoHang ADD BuocTaiXe INT NOT NULL CONSTRAINT DF_GiaoHang_BuocTaiXe DEFAULT 0;  -- 0 đang đến quán, 1 đang lấy hàng
IF COL_LENGTH('GiaoHang', 'PhuCap') IS NULL
    ALTER TABLE GiaoHang ADD PhuCap DECIMAL(12,0) NOT NULL CONSTRAINT DF_GiaoHang_PhuCap DEFAULT 0;
IF COL_LENGTH('GiaoHang', 'DiemTaiXe') IS NULL
    ALTER TABLE GiaoHang ADD DiemTaiXe INT NULL;                 -- khách chấm 1-5, NULL = chưa chấm
IF COL_LENGTH('GiaoHang', 'NhanXetTaiXe') IS NULL
    ALTER TABLE GiaoHang ADD NhanXetTaiXe NVARCHAR(500) NULL;
IF COL_LENGTH('GiaoHang', 'LyDoThatBai') IS NULL
    ALTER TABLE GiaoHang ADD LyDoThatBai NVARCHAR(255) NULL;
IF COL_LENGTH('GiaoHang', 'AnhGiaoHang') IS NULL
    ALTER TABLE GiaoHang ADD AnhGiaoHang NVARCHAR(500) NULL;     -- ảnh bằng chứng giao hàng
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_GiaoHang_DiemTaiXe')
    ALTER TABLE GiaoHang ADD CONSTRAINT CK_GiaoHang_DiemTaiXe CHECK (DiemTaiXe IS NULL OR DiemTaiXe BETWEEN 1 AND 5);
GO

/* ---- 10.3 ThanhToan: thêm ChuyenKhoan, ViDienTu (xóa CHECK cũ không đặt tên rồi tạo lại) ---- */
DECLARE @ck sysname;
SELECT @ck = cc.name FROM sys.check_constraints cc
WHERE cc.parent_object_id = OBJECT_ID('ThanhToan') AND cc.definition LIKE '%HinhThuc%' AND cc.name <> 'CK_ThanhToan_HinhThuc';
IF @ck IS NOT NULL EXEC('ALTER TABLE ThanhToan DROP CONSTRAINT ' + @ck);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_ThanhToan_HinhThuc')
    ALTER TABLE ThanhToan ADD CONSTRAINT CK_ThanhToan_HinhThuc
        CHECK (HinhThuc IN (N'TienMat', N'ChuyenKhoan', N'ViDienTu', N'VNPay', N'Momo'));
GO

/* ---- 10.4 TinNhan ---- */
IF OBJECT_ID('TinNhan', 'U') IS NULL
BEGIN
    CREATE TABLE TinNhan (
        MaTinNhan   INT IDENTITY(1,1) PRIMARY KEY,
        MaDonHang   INT NOT NULL REFERENCES DonHang(MaDonHang),
        NguoiGui    NVARCHAR(20) NOT NULL CHECK (NguoiGui IN (N'KhachHang', N'TaiXe')),
        TenNguoiGui NVARCHAR(100) NULL,
        NoiDung     NVARCHAR(1000) NOT NULL,
        ThoiGian    DATETIME NOT NULL DEFAULT GETDATE()
    );
    EXEC(N'CREATE INDEX IX_TinNhan_DonHang ON TinNhan (MaDonHang, ThoiGian)');
END
GO

/* ---- 10.5 KhuyenMai: các cột mới ---- */
IF COL_LENGTH('KhuyenMai', 'TenChuongTrinh') IS NULL
    ALTER TABLE KhuyenMai ADD TenChuongTrinh NVARCHAR(150) NULL;
IF COL_LENGTH('KhuyenMai', 'LoaiGiam') IS NULL
    ALTER TABLE KhuyenMai ADD LoaiGiam NVARCHAR(20) NOT NULL CONSTRAINT DF_KhuyenMai_LoaiGiam DEFAULT N'PhanTram';
IF COL_LENGTH('KhuyenMai', 'GiamToiDa') IS NULL
    ALTER TABLE KhuyenMai ADD GiamToiDa DECIMAL(12,0) NULL;
IF COL_LENGTH('KhuyenMai', 'GiaTriDonToiThieu') IS NULL
    ALTER TABLE KhuyenMai ADD GiaTriDonToiThieu DECIMAL(12,0) NOT NULL CONSTRAINT DF_KhuyenMai_DonToiThieu DEFAULT 0;
IF COL_LENGTH('KhuyenMai', 'SoLuongToiDa') IS NULL
    ALTER TABLE KhuyenMai ADD SoLuongToiDa INT NULL;             -- NULL = không giới hạn lượt
IF COL_LENGTH('KhuyenMai', 'SoLuongDaDung') IS NULL
    ALTER TABLE KhuyenMai ADD SoLuongDaDung INT NOT NULL CONSTRAINT DF_KhuyenMai_DaDung DEFAULT 0;
IF COL_LENGTH('KhuyenMai', 'MoiKhachMotLan') IS NULL
    ALTER TABLE KhuyenMai ADD MoiKhachMotLan BIT NOT NULL CONSTRAINT DF_KhuyenMai_MotLan DEFAULT 0;
GO

IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_KhuyenMai_LoaiGiam')
    ALTER TABLE KhuyenMai ADD CONSTRAINT CK_KhuyenMai_LoaiGiam
        CHECK (LoaiGiam IN (N'PhanTram', N'SoTien', N'GiamPhiVanChuyen'));
GO

/* ---- 10.6 Khuyến mãi: món / danh mục / gian hàng áp dụng, khách đã dùng (rỗng = không giới hạn) ---- */
IF OBJECT_ID('KhuyenMaiMonAn', 'U') IS NULL
    CREATE TABLE KhuyenMaiMonAn (
        MaKhuyenMai INT NOT NULL REFERENCES KhuyenMai(MaKhuyenMai) ON DELETE CASCADE,
        MaMonAn     INT NOT NULL REFERENCES MonAn(MaMonAn),
        PRIMARY KEY (MaKhuyenMai, MaMonAn)
    );
IF OBJECT_ID('KhuyenMaiDanhMuc', 'U') IS NULL
    CREATE TABLE KhuyenMaiDanhMuc (
        MaKhuyenMai INT NOT NULL REFERENCES KhuyenMai(MaKhuyenMai) ON DELETE CASCADE,
        MaDanhMuc   INT NOT NULL REFERENCES DanhMuc(MaDanhMuc),
        PRIMARY KEY (MaKhuyenMai, MaDanhMuc)
    );
IF OBJECT_ID('KhuyenMaiGianHang', 'U') IS NULL
    CREATE TABLE KhuyenMaiGianHang (
        MaKhuyenMai INT NOT NULL REFERENCES KhuyenMai(MaKhuyenMai) ON DELETE CASCADE,
        MaGianHang  INT NOT NULL REFERENCES GianHang(MaGianHang),
        PRIMARY KEY (MaKhuyenMai, MaGianHang)
    );
IF OBJECT_ID('KhuyenMaiKhachDung', 'U') IS NULL
    CREATE TABLE KhuyenMaiKhachDung (
        MaKhuyenMai INT NOT NULL REFERENCES KhuyenMai(MaKhuyenMai) ON DELETE CASCADE,
        MaKH        INT NOT NULL REFERENCES KhachHang(MaKH),
        MaDonHang   INT NOT NULL REFERENCES DonHang(MaDonHang),
        NgaySuDung  DATETIME NOT NULL DEFAULT GETDATE(),
        PRIMARY KEY (MaKhuyenMai, MaKH, MaDonHang)
    );
GO

/* ---- 10.7 Chuẩn hóa dữ liệu mẫu cũ cho khớp cột mới (chạy lại vẫn an toàn) ---- */
UPDATE KhuyenMai SET TenChuongTrinh = MaCode WHERE TenChuongTrinh IS NULL;
UPDATE KhuyenMai SET LoaiGiam = N'SoTien'
 WHERE LoaiGiam = N'PhanTram' AND PhanTramGiam IS NULL AND SoTienGiam > 0;
UPDATE KhuyenMai SET SoLuongDaDung = x.SoLuot
FROM KhuyenMai k
JOIN (SELECT MaKhuyenMaiApDung AS Ma, COUNT(*) AS SoLuot FROM DonHang
      WHERE MaKhuyenMaiApDung IS NOT NULL AND TrangThai <> N'DaHuy' GROUP BY MaKhuyenMaiApDung) x ON x.Ma = k.MaKhuyenMai
WHERE k.SoLuongDaDung = 0;

-- Số CCCD/GPLX demo cho tài xế mẫu chưa có (chỉ để dữ liệu mẫu đầy đủ, không phải số thật)
UPDATE TaiXe SET SoCCCD = '079' + RIGHT('000000000' + CAST(MaTaiXe AS VARCHAR(9)), 9)
 WHERE SoCCCD IS NULL;
UPDATE TaiXe SET SoGPLX = '79' + RIGHT('0000000000' + CAST(MaTaiXe AS VARCHAR(10)), 10)
 WHERE SoGPLX IS NULL;

-- Mã mẫu "miễn phí giao hàng" (toàn hệ thống) để thử loại GiamPhiVanChuyen
IF NOT EXISTS (SELECT 1 FROM KhuyenMai WHERE MaCode = 'FREESHIP')
    INSERT INTO KhuyenMai (MaGianHang, MaMonAn, MaCode, MoTa, PhanTramGiam, SoTienGiam, DieuKienApDung,
                           NgayBatDau, NgayKetThuc, TrangThai,
                           TenChuongTrinh, LoaiGiam, GiaTriDonToiThieu, SoLuongToiDa, MoiKhachMotLan)
    VALUES (NULL, NULL, 'FREESHIP', N'Miễn phí giao hàng cho đơn từ 100.000đ', NULL, 0, N'Đơn từ 100.000đ',
            GETDATE(), DATEADD(MONTH, 3, GETDATE()), 1,
            N'Miễn phí giao hàng', N'GiamPhiVanChuyen', 100000, 500, 1);
GO

/* ============================================================
   PHẦN 12: BỔ SUNG HẠ TẦNG BACKEND (chạy được NHIỀU LẦN, an toàn)
   12.1 TaiKhoan: khóa tạm khi sai mật khẩu nhiều lần, xác thực email/SĐT
   12.2 Cột còn thiếu: GianHang.Email, ảnh đại diện, DonHang.TienGiam/HenGiaoLuc, PhanHoi.DangXuLy
   12.3 Bảng mới: RefreshToken, OtpXacThuc, NhatKyHeThong, AuditLog, ThongBao, TepTin
   12.4 Chỉ mục + FULLTEXT (tìm kiếm nhanh)
   12.5 Trigger audit: ghi ai/khi nào/đổi gì ở các bảng quan trọng (ghi đè JSON cũ/mới, KHÔNG ghi mật khẩu)
   12.6 sp_DonDepDuLieu: dọn token/OTP/nhật ký quá hạn
   Việc sao lưu: xem SQL_NangCap/SaoLuu_PhucHoi.sql
   ============================================================ */
USE QuanLyDichVuAnUong;
GO

/* ---- 12.1 TaiKhoan ---- */
IF COL_LENGTH('TaiKhoan', 'SoLanDangNhapSai') IS NULL
    ALTER TABLE TaiKhoan ADD SoLanDangNhapSai INT NOT NULL CONSTRAINT DF_TaiKhoan_SaiLan DEFAULT 0;
IF COL_LENGTH('TaiKhoan', 'KhoaDen') IS NULL
    ALTER TABLE TaiKhoan ADD KhoaDen DATETIME NULL;                 -- khóa tạm tới thời điểm này
IF COL_LENGTH('TaiKhoan', 'LanDangNhapCuoi') IS NULL
    ALTER TABLE TaiKhoan ADD LanDangNhapCuoi DATETIME NULL;
IF COL_LENGTH('TaiKhoan', 'EmailDaXacThuc') IS NULL
    ALTER TABLE TaiKhoan ADD EmailDaXacThuc BIT NOT NULL CONSTRAINT DF_TaiKhoan_EmailXT DEFAULT 0;
IF COL_LENGTH('TaiKhoan', 'SdtDaXacThuc') IS NULL
    ALTER TABLE TaiKhoan ADD SdtDaXacThuc BIT NOT NULL CONSTRAINT DF_TaiKhoan_SdtXT DEFAULT 0;
GO

/* ---- 12.2 Cột còn thiếu ---- */
IF COL_LENGTH('GianHang', 'Email') IS NULL      ALTER TABLE GianHang ADD Email VARCHAR(100) NULL;
IF COL_LENGTH('KhachHang', 'AnhDaiDien') IS NULL ALTER TABLE KhachHang ADD AnhDaiDien NVARCHAR(500) NULL;
IF COL_LENGTH('TaiXe', 'AnhDaiDien') IS NULL     ALTER TABLE TaiXe ADD AnhDaiDien NVARCHAR(500) NULL;
IF COL_LENGTH('DonHang', 'TienGiam') IS NULL
    ALTER TABLE DonHang ADD TienGiam DECIMAL(12,0) NOT NULL CONSTRAINT DF_DonHang_TienGiam DEFAULT 0;  -- đã trừ khỏi TongTien
IF COL_LENGTH('DonHang', 'HenGiaoLuc') IS NULL   ALTER TABLE DonHang ADD HenGiaoLuc DATETIME NULL;      -- đơn hẹn giờ
GO

/* PhanHoi.TrangThai: thêm 'DangXuLy' (app có 3 trạng thái: mới / đang xử lý / đã giải quyết) */
DECLARE @ck sysname;
SELECT @ck = cc.name FROM sys.check_constraints cc
WHERE cc.parent_object_id = OBJECT_ID('PhanHoi') AND cc.definition LIKE '%ChuaXuLy%' AND cc.name <> 'CK_PhanHoi_TrangThai';
IF @ck IS NOT NULL EXEC('ALTER TABLE PhanHoi DROP CONSTRAINT ' + @ck);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_PhanHoi_TrangThai')
    ALTER TABLE PhanHoi ADD CONSTRAINT CK_PhanHoi_TrangThai CHECK (TrangThai IN (N'ChuaXuLy', N'DangXuLy', N'DaXuLy'));
GO

/* Đồng bộ dữ liệu mẫu với app: quản trị mẫu đăng nhập bằng admin@fooddelivery.vn; gian hàng mẫu có email */
UPDATE QuanTri SET Email = 'admin@fooddelivery.vn'
WHERE MaTK = (SELECT MaTK FROM TaiKhoan WHERE TenDangNhap = N'quantri01')
  AND NOT EXISTS (SELECT 1 FROM QuanTri WHERE Email = 'admin@fooddelivery.vn');
UPDATE gh SET Email = LOWER(tk.TenDangNhap) + '@foodapp.vn'
FROM GianHang gh JOIN TaiKhoan tk ON tk.MaTK = gh.MaTK WHERE gh.Email IS NULL AND LEN(tk.TenDangNhap) <= 80;
GO

/* ---- 12.3 Bảng mới ---- */
IF OBJECT_ID('RefreshToken', 'U') IS NULL
BEGIN
    CREATE TABLE RefreshToken (
        MaRT        BIGINT IDENTITY(1,1) PRIMARY KEY,
        MaTK        INT NOT NULL REFERENCES TaiKhoan(MaTK) ON DELETE CASCADE,
        TokenHash   CHAR(64) NOT NULL UNIQUE,          -- SHA-256 của token; KHÔNG lưu token gốc
        NgayTao     DATETIME NOT NULL DEFAULT GETDATE(),
        HetHan      DATETIME NOT NULL,
        ThuHoiLuc   DATETIME NULL,
        ThayBangHash CHAR(64) NULL,                    -- token mới thay thế (xoay vòng)
        DiaChiIP    NVARCHAR(45) NULL,
        ThietBi     NVARCHAR(200) NULL
    );
    EXEC(N'CREATE INDEX IX_RefreshToken_MaTK ON RefreshToken (MaTK, HetHan)');
END
GO

IF OBJECT_ID('OtpXacThuc', 'U') IS NULL
BEGIN
    CREATE TABLE OtpXacThuc (
        MaOTP       BIGINT IDENTITY(1,1) PRIMARY KEY,
        MucDich     NVARCHAR(30) NOT NULL CHECK (MucDich IN (N'DangKy', N'QuenMatKhau', N'DoiLienHe', N'XacNhan')),
        Kenh        VARCHAR(10)  NOT NULL CHECK (Kenh IN ('email', 'sms')),
        NguoiNhan   NVARCHAR(150) NOT NULL,
        MaTK        INT NULL REFERENCES TaiKhoan(MaTK),
        OtpHash     CHAR(64) NOT NULL,                  -- HMAC-SHA256, không lưu mã gốc
        NgayTao     DATETIME NOT NULL DEFAULT GETDATE(),
        HetHan      DATETIME NOT NULL,
        SoLanSai    INT NOT NULL DEFAULT 0,
        DaDung      BIT NOT NULL DEFAULT 0
    );
    EXEC(N'CREATE INDEX IX_Otp_NguoiNhan ON OtpXacThuc (NguoiNhan, MucDich, NgayTao DESC)');
END
GO

IF OBJECT_ID('NhatKyHeThong', 'U') IS NULL
BEGIN
    CREATE TABLE NhatKyHeThong (
        MaLog       BIGINT IDENTITY(1,1) PRIMARY KEY,
        ThoiGian    DATETIME2(3) NOT NULL DEFAULT SYSDATETIME(),
        MucDo       VARCHAR(10)  NOT NULL CHECK (MucDo IN ('Info', 'Warn', 'Error')),
        Nguon       NVARCHAR(30) NOT NULL,              -- Http | Auth | Loi | Upload | Otp | Sao luu ...
        ThongDiep   NVARCHAR(500) NOT NULL,
        ChiTiet     NVARCHAR(MAX) NULL,                 -- stack trace (chỉ khi Error)
        MaTK        INT NULL,
        DiaChiIP    NVARCHAR(45) NULL,
        PhuongThuc  VARCHAR(10) NULL,
        DuongDan    NVARCHAR(300) NULL,
        MaTrangThai INT NULL,
        ThoiGianMs  INT NULL
    );
    EXEC(N'CREATE INDEX IX_NhatKy_ThoiGian ON NhatKyHeThong (ThoiGian DESC)');
    EXEC(N'CREATE INDEX IX_NhatKy_MucDo ON NhatKyHeThong (MucDo, ThoiGian DESC)');
END
GO

IF OBJECT_ID('AuditLog', 'U') IS NULL
BEGIN
    CREATE TABLE AuditLog (
        MaAudit     BIGINT IDENTITY(1,1) PRIMARY KEY,
        ThoiGian    DATETIME2(3) NOT NULL DEFAULT SYSDATETIME(),
        MaTK        INT NULL,                           -- người thao tác (từ SESSION_CONTEXT, NULL = thao tác trực tiếp trên DB)
        HanhDong    NVARCHAR(10) NOT NULL,              -- INSERT | UPDATE | DELETE
        Bang        NVARCHAR(60) NOT NULL,
        KhoaChinh   NVARCHAR(50) NOT NULL,
        GiaTriCu    NVARCHAR(MAX) NULL,                 -- JSON
        GiaTriMoi   NVARCHAR(MAX) NULL                  -- JSON
    );
    EXEC(N'CREATE INDEX IX_Audit_Bang ON AuditLog (Bang, KhoaChinh, ThoiGian DESC)');
    EXEC(N'CREATE INDEX IX_Audit_MaTK ON AuditLog (MaTK, ThoiGian DESC)');
END
GO

IF OBJECT_ID('ThongBao', 'U') IS NULL
BEGIN
    CREATE TABLE ThongBao (
        MaThongBao  BIGINT IDENTITY(1,1) PRIMARY KEY,
        MaTK        INT NOT NULL REFERENCES TaiKhoan(MaTK) ON DELETE CASCADE,
        TieuDe      NVARCHAR(150) NOT NULL,
        NoiDung     NVARCHAR(500) NOT NULL,
        Loai        NVARCHAR(20) NOT NULL DEFAULT N'HeThong' CHECK (Loai IN (N'HeThong', N'DonHang', N'KhuyenMai', N'TinNhan')),
        MaThamChieu NVARCHAR(50) NULL,                  -- ví dụ Id đơn hàng
        DaDoc       BIT NOT NULL DEFAULT 0,
        NgayTao     DATETIME NOT NULL DEFAULT GETDATE()
    );
    EXEC(N'CREATE INDEX IX_ThongBao_MaTK ON ThongBao (MaTK, DaDoc, NgayTao DESC)');
END
GO

IF OBJECT_ID('TepTin', 'U') IS NULL
BEGIN
    CREATE TABLE TepTin (
        MaTep       BIGINT IDENTITY(1,1) PRIMARY KEY,
        MaTK        INT NULL REFERENCES TaiKhoan(MaTK),
        Loai        NVARCHAR(20) NOT NULL CHECK (Loai IN (N'MonAn', N'GianHang', N'AvatarKhach', N'AvatarTaiXe', N'GPLX', N'GiaoHang')),
        TenGoc      NVARCHAR(200) NULL,
        DuongDan    NVARCHAR(400) NOT NULL,             -- đường dẫn tương đối trong thư mục lưu trữ
        MimeType    VARCHAR(50) NOT NULL,
        KichThuoc   BIGINT NOT NULL,
        Sha256      CHAR(64) NOT NULL,
        RiengTu     BIT NOT NULL DEFAULT 0,             -- 1 = chỉ chủ sở hữu/quản trị xem (GPLX)
        NgayTai     DATETIME NOT NULL DEFAULT GETDATE()
    );
    EXEC(N'CREATE INDEX IX_TepTin_MaTK ON TepTin (MaTK, Loai)');
END
GO

/* ---- 12.4 Chỉ mục ---- */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_DonHang_KhachHang')
    EXEC(N'CREATE INDEX IX_DonHang_KhachHang ON DonHang (MaKH, NgayDat DESC)');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_DonHang_GianHang')
    EXEC(N'CREATE INDEX IX_DonHang_GianHang ON DonHang (MaGianHang, TrangThai, NgayDat DESC)');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_DonHang_TaiXe')
    EXEC(N'CREATE INDEX IX_DonHang_TaiXe ON DonHang (MaTaiXe, TrangThai)');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_DonHang_ChoTaiXe')
    EXEC(N'CREATE INDEX IX_DonHang_ChoTaiXe ON DonHang (TrangThai, SanSangGiao, MaTaiXe) WHERE MaTaiXe IS NULL');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_ChiTiet_DonHang')
    EXEC(N'CREATE INDEX IX_ChiTiet_DonHang ON ChiTietDonHang (MaDonHang) INCLUDE (MaMonAn, SoLuong, DonGia)');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_MonAn_DanhMuc')
    EXEC(N'CREATE INDEX IX_MonAn_DanhMuc ON MonAn (MaDanhMuc, TinhTrang)');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_DanhMuc_GianHang')
    EXEC(N'CREATE INDEX IX_DanhMuc_GianHang ON DanhMuc (MaGianHang)');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_GianHang_Duyet')
    EXEC(N'CREATE INDEX IX_GianHang_Duyet ON GianHang (TrangThaiDuyet, TrangThaiKinhDoanh)');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_GianHang_Email')
    EXEC(N'CREATE INDEX IX_GianHang_Email ON GianHang (Email) WHERE Email IS NOT NULL');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_GianHang_SDT')
    EXEC(N'CREATE INDEX IX_GianHang_SDT ON GianHang (SDT)');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KhachHang_Email')
    EXEC(N'CREATE INDEX IX_KhachHang_Email ON KhachHang (Email) WHERE Email IS NOT NULL');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KhachHang_SDT')
    EXEC(N'CREATE INDEX IX_KhachHang_SDT ON KhachHang (SDT)');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_TaiXe_SDT')
    EXEC(N'CREATE INDEX IX_TaiXe_SDT ON TaiXe (SDT)');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_GiaoHang_TaiXe')
    EXEC(N'CREATE INDEX IX_GiaoHang_TaiXe ON GiaoHang (MaTaiXe, TrangThai)');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_DanhGia_GianHang')
    EXEC(N'CREATE INDEX IX_DanhGia_GianHang ON DanhGia (MaGianHang) INCLUDE (SoSao)');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_KhuyenMai_Hieu')
    EXEC(N'CREATE INDEX IX_KhuyenMai_Hieu ON KhuyenMai (TrangThai, NgayKetThuc)');
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_PhanHoi_TrangThai')
    EXEC(N'CREATE INDEX IX_PhanHoi_TrangThai ON PhanHoi (TrangThai, NgayGui DESC)');
GO

/* FULLTEXT cho tìm kiếm tên quán / món (cần cài tính năng Full-Text; không có thì bỏ qua, server tự dùng LIKE) */
IF FULLTEXTSERVICEPROPERTY('IsFullTextInstalled') = 1
BEGIN
    BEGIN TRY
        IF NOT EXISTS (SELECT 1 FROM sys.fulltext_catalogs WHERE name = 'ftc_FoodService')
            EXEC('CREATE FULLTEXT CATALOG ftc_FoodService');

        DECLARE @pk sysname, @s NVARCHAR(500);
        IF NOT EXISTS (SELECT 1 FROM sys.fulltext_indexes WHERE object_id = OBJECT_ID('MonAn'))
        BEGIN
            SELECT @pk = name FROM sys.indexes WHERE object_id = OBJECT_ID('MonAn') AND is_primary_key = 1;
            SET @s = N'CREATE FULLTEXT INDEX ON MonAn (TenMon LANGUAGE 0, MoTa LANGUAGE 0) KEY INDEX ' + QUOTENAME(@pk) + N' ON ftc_FoodService WITH CHANGE_TRACKING AUTO';
            EXEC(@s);
        END
        IF NOT EXISTS (SELECT 1 FROM sys.fulltext_indexes WHERE object_id = OBJECT_ID('GianHang'))
        BEGIN
            SELECT @pk = name FROM sys.indexes WHERE object_id = OBJECT_ID('GianHang') AND is_primary_key = 1;
            SET @s = N'CREATE FULLTEXT INDEX ON GianHang (TenCuaHang LANGUAGE 0, MoTa LANGUAGE 0) KEY INDEX ' + QUOTENAME(@pk) + N' ON ftc_FoodService WITH CHANGE_TRACKING AUTO';
            EXEC(@s);
        END
    END TRY
    BEGIN CATCH
        PRINT N'Bỏ qua FULLTEXT: ' + ERROR_MESSAGE();
    END CATCH
END
ELSE PRINT N'Full-Text chưa được cài: server sẽ tìm kiếm bằng LIKE.';
GO

/* ---- 12.5 Trigger audit ---- */
-- Bảng thường: ghi JSON giá trị cũ/mới của cả dòng. Người thao tác lấy từ SESSION_CONTEXT('MaTK') do server đặt.
DECLARE @bang TABLE (Ten SYSNAME, Pk SYSNAME);
INSERT INTO @bang VALUES (N'GianHang', N'MaGianHang'), (N'TaiXe', N'MaTaiXe'), (N'KhuyenMai', N'MaKhuyenMai'),
                         (N'MonAn', N'MaMonAn'), (N'DonHang', N'MaDonHang'), (N'ThanhToan', N'MaThanhToan'),
                         (N'PhanHoi', N'MaPhanHoi'), (N'KhachHang', N'MaKH');
DECLARE @t SYSNAME, @key SYSNAME, @ci NVARCHAR(MAX), @cd NVARCHAR(MAX), @sql NVARCHAR(MAX);
DECLARE cur CURSOR LOCAL FAST_FORWARD FOR SELECT Ten, Pk FROM @bang;
OPEN cur;
FETCH NEXT FROM cur INTO @t, @key;
WHILE @@FETCH_STATUS = 0
BEGIN
    SELECT @ci = STRING_AGG(CAST(N'i.' + QUOTENAME(COLUMN_NAME) AS NVARCHAR(MAX)), N',') WITHIN GROUP (ORDER BY ORDINAL_POSITION),
           @cd = STRING_AGG(CAST(N'd.' + QUOTENAME(COLUMN_NAME) AS NVARCHAR(MAX)), N',') WITHIN GROUP (ORDER BY ORDINAL_POSITION)
    FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = @t;

    SET @sql = N'CREATE OR ALTER TRIGGER ' + QUOTENAME(N'trg_Audit_' + @t) + N' ON ' + QUOTENAME(@t) + N' AFTER INSERT, UPDATE, DELETE AS
BEGIN
    SET NOCOUNT ON;
    IF NOT EXISTS (SELECT 1 FROM inserted) AND NOT EXISTS (SELECT 1 FROM deleted) RETURN;
    DECLARE @tk INT = TRY_CAST(SESSION_CONTEXT(N''MaTK'') AS INT);
    INSERT INTO AuditLog (MaTK, HanhDong, Bang, KhoaChinh, GiaTriCu, GiaTriMoi)
    SELECT @tk,
           CASE WHEN d.' + QUOTENAME(@key) + N' IS NULL THEN N''INSERT'' WHEN i.' + QUOTENAME(@key) + N' IS NULL THEN N''DELETE'' ELSE N''UPDATE'' END,
           N''' + @t + N''',
           CAST(COALESCE(i.' + QUOTENAME(@key) + N', d.' + QUOTENAME(@key) + N') AS NVARCHAR(50)),
           CASE WHEN d.' + QUOTENAME(@key) + N' IS NULL THEN NULL ELSE (SELECT ' + @cd + N' FOR JSON PATH, WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES) END,
           CASE WHEN i.' + QUOTENAME(@key) + N' IS NULL THEN NULL ELSE (SELECT ' + @ci + N' FOR JSON PATH, WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES) END
    FROM inserted i FULL OUTER JOIN deleted d ON i.' + QUOTENAME(@key) + N' = d.' + QUOTENAME(@key) + N';
END';
    EXEC(@sql);
    FETCH NEXT FROM cur INTO @t, @key;
END
CLOSE cur; DEALLOCATE cur;
GO

-- TaiKhoan: không ghi mật khẩu; chỉ ghi khi đổi trạng thái / vai trò / tên đăng nhập / mật khẩu (chỉ cờ DoiMatKhau)
-- Tạo bằng EXEC (SQL động): khi khóa an toàn ở đầu file bật NOEXEC (CSDL đã tồn tại), SSMS vẫn biên dịch CREATE TRIGGER
-- và báo lỗi 8197 vì bảng TaiKhoan không có trong CSDL hiện hành. Đặt trong EXEC thì bị bỏ qua hoàn toàn.
EXEC(N'CREATE OR ALTER TRIGGER trg_Audit_TaiKhoan ON TaiKhoan AFTER INSERT, UPDATE, DELETE AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @tk INT = TRY_CAST(SESSION_CONTEXT(N''MaTK'') AS INT);
    INSERT INTO AuditLog (MaTK, HanhDong, Bang, KhoaChinh, GiaTriCu, GiaTriMoi)
    SELECT @tk,
           CASE WHEN d.MaTK IS NULL THEN N''INSERT'' WHEN i.MaTK IS NULL THEN N''DELETE'' ELSE N''UPDATE'' END,
           N''TaiKhoan'', CAST(COALESCE(i.MaTK, d.MaTK) AS NVARCHAR(50)),
           CASE WHEN d.MaTK IS NULL THEN NULL
                ELSE (SELECT d.TenDangNhap, d.VaiTro, d.TrangThai FOR JSON PATH, WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES) END,
           CASE WHEN i.MaTK IS NULL THEN NULL
                ELSE (SELECT i.TenDangNhap, i.VaiTro, i.TrangThai,
                             CAST(CASE WHEN d.MaTK IS NOT NULL AND i.MatKhau <> d.MatKhau THEN 1 ELSE 0 END AS BIT) AS DoiMatKhau
                      FOR JSON PATH, WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES) END
    FROM inserted i FULL OUTER JOIN deleted d ON i.MaTK = d.MaTK
    WHERE d.MaTK IS NULL OR i.MaTK IS NULL
       OR i.TrangThai <> d.TrangThai OR i.VaiTro <> d.VaiTro OR i.TenDangNhap <> d.TenDangNhap OR i.MatKhau <> d.MatKhau;
END');
GO

/* ---- 12.6 Dọn dữ liệu quá hạn ---- */
CREATE OR ALTER PROCEDURE sp_DonDepDuLieu
    @GiuNhatKyNgay INT = 90,
    @GiuAuditNgay  INT = 365
AS
BEGIN
    SET NOCOUNT ON;
    DELETE FROM RefreshToken WHERE HetHan < DATEADD(DAY, -7, GETDATE()) OR (ThuHoiLuc IS NOT NULL AND ThuHoiLuc < DATEADD(DAY, -7, GETDATE()));
    DELETE FROM OtpXacThuc   WHERE NgayTao < DATEADD(DAY, -1, GETDATE());
    DELETE FROM NhatKyHeThong WHERE ThoiGian < DATEADD(DAY, -@GiuNhatKyNgay, GETDATE());
    DELETE FROM AuditLog     WHERE ThoiGian < DATEADD(DAY, -@GiuAuditNgay, GETDATE());
    DELETE FROM ThongBao     WHERE DaDoc = 1 AND NgayTao < DATEADD(DAY, -60, GETDATE());
END
GO

/* ============================================================
   PHẦN 13: TRUY VẤN KIỂM TRA SAU KHI TẠO (gộp từ 03_BoSung.sql, 04_table.sql)
   ============================================================ */
USE QuanLyDichVuAnUong;
GO

-- Đếm nhanh số gian hàng / món ăn đã sinh
SELECT COUNT(*) FROM GianHang;
SELECT COUNT(*) FROM MonAn;
GO

-- Xem cấu trúc cột của toàn bộ bảng
SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
ORDER BY TABLE_NAME, ORDINAL_POSITION;
GO

GO

/* ============================================================
   PHẦN 14: BỔ SUNG ĐỐI TÁC / GIAN HÀNG (cùng nội dung 04_BoSung_DoiTac.sql — chạy lại an toàn)
   ============================================================ */
USE QuanLyDichVuAnUong;
GO
/* ---- 1. GianHang: giờ hoạt động, nhận đơn, chiết khấu ---- */
IF COL_LENGTH('GianHang', 'GioMoCua') IS NULL
    ALTER TABLE GianHang ADD GioMoCua TIME(0) NOT NULL CONSTRAINT DF_GianHang_GioMoCua DEFAULT '00:00';
GO
IF COL_LENGTH('GianHang', 'GioDongCua') IS NULL
    ALTER TABLE GianHang ADD GioDongCua TIME(0) NOT NULL CONSTRAINT DF_GianHang_GioDongCua DEFAULT '23:59';   -- 00:00–23:59 = hoạt động cả ngày
GO
IF COL_LENGTH('GianHang', 'DangNhanDon') IS NULL
    ALTER TABLE GianHang ADD DangNhanDon BIT NOT NULL CONSTRAINT DF_GianHang_DangNhanDon DEFAULT 1;           -- tạm dừng nhận đơn nhưng vẫn mở cửa
GO
IF COL_LENGTH('GianHang', 'TyLeChietKhau') IS NULL
    ALTER TABLE GianHang ADD TyLeChietKhau DECIMAL(5,4) NOT NULL CONSTRAINT DF_GianHang_TyLeChietKhau DEFAULT 0.15;   -- 0.15 = 15% (NV09: thỏa thuận lúc đăng ký)
GO

/* ---- 2. DanhMuc: thứ tự hiển thị ---- */
IF COL_LENGTH('DanhMuc', 'ThuTu') IS NULL
    ALTER TABLE DanhMuc ADD ThuTu INT NOT NULL CONSTRAINT DF_DanhMuc_ThuTu DEFAULT 0;
GO
-- Đánh số thứ tự ban đầu theo mã danh mục cho mỗi gian hàng (chỉ khi chưa có thứ tự nào)
;WITH x AS (
    SELECT MaDanhMuc, ROW_NUMBER() OVER (PARTITION BY MaGianHang ORDER BY MaDanhMuc) AS stt
    FROM DanhMuc
)
UPDATE d SET d.ThuTu = x.stt
FROM DanhMuc d JOIN x ON x.MaDanhMuc = d.MaDanhMuc
WHERE NOT EXISTS (SELECT 1 FROM DanhMuc t WHERE t.MaGianHang = d.MaGianHang AND t.ThuTu <> 0);
GO

/* ---- 3. MonAn: tạm ngừng bán, giá vốn, cho ghi chú ---- */
IF COL_LENGTH('MonAn', 'GiaVon') IS NULL
    ALTER TABLE MonAn ADD GiaVon DECIMAL(12,0) NOT NULL CONSTRAINT DF_MonAn_GiaVon DEFAULT 0
        CONSTRAINT CK_MonAn_GiaVon CHECK (GiaVon >= 0);
GO
IF COL_LENGTH('MonAn', 'ChoGhiChu') IS NULL
    ALTER TABLE MonAn ADD ChoGhiChu BIT NOT NULL CONSTRAINT DF_MonAn_ChoGhiChu DEFAULT 1;
-- v95: tồn kho theo số lượng (NULL = không giới hạn). Server trừ khi đặt đơn, cộng lại khi đơn bị hủy.
IF COL_LENGTH('MonAn', 'SoLuongTon') IS NULL
    EXEC(N'ALTER TABLE MonAn ADD SoLuongTon INT NULL CONSTRAINT CK_MonAn_SoLuongTon CHECK (SoLuongTon IS NULL OR SoLuongTon >= 0)');
GO
-- Mở rộng CHECK của TinhTrang: thêm 'TamNgung' (tạm ngừng bán)
DECLARE @ck sysname;
SELECT @ck = cc.name
FROM sys.check_constraints cc
JOIN sys.columns c ON c.object_id = cc.parent_object_id AND c.column_id = cc.parent_column_id
WHERE cc.parent_object_id = OBJECT_ID('MonAn') AND c.name = 'TinhTrang';
IF @ck IS NOT NULL EXEC('ALTER TABLE MonAn DROP CONSTRAINT ' + @ck);
ALTER TABLE MonAn ADD CONSTRAINT CK_MonAn_TinhTrang
    CHECK (TinhTrang IN (N'ConHang', N'HetHang', N'TamNgung'));
GO

/* ---- 4. TuyChonMon: size / topping / mức cay của từng món ---- */
IF OBJECT_ID('TuyChonMon', 'U') IS NULL
CREATE TABLE TuyChonMon (
    MaTuyChon   INT IDENTITY(1,1) PRIMARY KEY,
    MaMonAn     INT NOT NULL REFERENCES MonAn(MaMonAn) ON DELETE CASCADE,
    Loai        NVARCHAR(10)  NOT NULL CHECK (Loai IN (N'Size', N'Topping', N'MucCay', N'MucDuong', N'MucDa')),
    TenTuyChon  NVARCHAR(100) NOT NULL,
    GiaThem     DECIMAL(12,0) NOT NULL DEFAULT 0 CHECK (GiaThem >= 0),
    CONSTRAINT UQ_TuyChonMon UNIQUE (MaMonAn, Loai, TenTuyChon)
);
GO

/* ---- 5. DonHang: lý do từ chối / hủy (NV04: từ chối bắt buộc có lý do) ---- */
IF COL_LENGTH('DonHang', 'LyDoTuChoi') IS NULL
    ALTER TABLE DonHang ADD LyDoTuChoi NVARCHAR(255) NULL;
GO

/* ---- 6. DanhGia: đánh giá giao hàng, thẻ nhanh, phản hồi của gian hàng ---- */
IF COL_LENGTH('DanhGia', 'SoSaoGiaoHang') IS NULL
    ALTER TABLE DanhGia ADD SoSaoGiaoHang INT NULL CONSTRAINT CK_DanhGia_SaoGiao CHECK (SoSaoGiaoHang BETWEEN 1 AND 5);
GO
IF COL_LENGTH('DanhGia', 'TheNhanXet') IS NULL
    ALTER TABLE DanhGia ADD TheNhanXet NVARCHAR(200) NULL;          -- "Món ngon;Đóng gói đẹp"
GO
IF COL_LENGTH('DanhGia', 'PhanHoi') IS NULL
    ALTER TABLE DanhGia ADD PhanHoi NVARCHAR(500) NULL;
GO
IF COL_LENGTH('DanhGia', 'NgayPhanHoi') IS NULL
    ALTER TABLE DanhGia ADD NgayPhanHoi DATETIME NULL;
GO

/* ---- 7. Thông báo cho gian hàng: dùng bảng ThongBao (theo MaTK) của NangCap_v9_Backend.sql — không tạo bảng riêng ---- */

/* ---- Kiểm tra nhanh ---- */
SELECT N'GianHang' AS Bang, name FROM sys.columns WHERE object_id = OBJECT_ID('GianHang') AND name IN ('GioMoCua','GioDongCua','DangNhanDon','TyLeChietKhau')
UNION ALL SELECT N'MonAn', name FROM sys.columns WHERE object_id = OBJECT_ID('MonAn') AND name IN ('GiaVon','ChoGhiChu')
UNION ALL SELECT N'DanhGia', name FROM sys.columns WHERE object_id = OBJECT_ID('DanhGia') AND name IN ('SoSaoGiaoHang','TheNhanXet','PhanHoi','NgayPhanHoi')
UNION ALL SELECT N'Bang moi', name FROM sys.tables WHERE name IN ('TuyChonMon');
GO
GO

/* ============================================================
   PHẦN 15: GIẤY TỜ GIAN HÀNG + GIỎ HÀNG TRÊN SERVER (cùng nội dung NangCap_v10_TaiKhoan_GioHang.sql)
   ============================================================ */
USE QuanLyDichVuAnUong;
GO

IF COL_LENGTH('GianHang', 'GiayPhepKinhDoanh') IS NULL ALTER TABLE GianHang ADD GiayPhepKinhDoanh NVARCHAR(500) NULL;
IF COL_LENGTH('GianHang', 'GiayChungNhanATTP') IS NULL ALTER TABLE GianHang ADD GiayChungNhanATTP NVARCHAR(500) NULL;
GO

IF OBJECT_ID('GioHang', 'U') IS NULL
BEGIN
    CREATE TABLE GioHang (
        MaGioHang   INT IDENTITY(1,1) PRIMARY KEY,
        MaKH        INT NOT NULL UNIQUE REFERENCES KhachHang(MaKH),       -- UNIQUE: mỗi khách đúng một giỏ
        MaGianHang  INT NOT NULL REFERENCES GianHang(MaGianHang),
        NgayCapNhat DATETIME NOT NULL DEFAULT GETDATE()
    );
END
GO

IF OBJECT_ID('GioHangChiTiet', 'U') IS NULL
BEGIN
    CREATE TABLE GioHangChiTiet (
        MaChiTiet   INT IDENTITY(1,1) PRIMARY KEY,
        MaGioHang   INT NOT NULL REFERENCES GioHang(MaGioHang) ON DELETE CASCADE,
        MaMonAn     INT NOT NULL REFERENCES MonAn(MaMonAn),
        SoLuong     INT NOT NULL CHECK (SoLuong BETWEEN 1 AND 99),
        GhiChu      NVARCHAR(255) NULL,
        TuyChon     NVARCHAR(MAX) NULL                                    -- JSON: ["Lớn","Trân châu"]
    );
    EXEC(N'CREATE INDEX IX_GioHangChiTiet_GioHang ON GioHangChiTiet(MaGioHang)');
END
-- Giá tiền KHÔNG lưu trong giỏ: luôn lấy MonAn.Gia hiện tại. API kiểm tra mọi món thuộc đúng gian hàng khi PUT giỏ.
GO
GO

/* ============================================================
   PHẦN 16: CHỨC NĂNG KHÁCH HÀNG v11 (cùng nội dung NangCap_v11_KhachHang.sql)
   ============================================================ */
USE QuanLyDichVuAnUong;
GO

IF COL_LENGTH('TaiKhoan', 'DongYDieuKhoanLuc') IS NULL ALTER TABLE TaiKhoan ADD DongYDieuKhoanLuc DATETIME NULL;
GO

/* ---- Sổ địa chỉ ---- */
IF COL_LENGTH('DiaChiKhachHang', 'Tinh')     IS NULL ALTER TABLE DiaChiKhachHang ADD Tinh     NVARCHAR(80)  NULL;
IF COL_LENGTH('DiaChiKhachHang', 'Quan')     IS NULL ALTER TABLE DiaChiKhachHang ADD Quan     NVARCHAR(80)  NULL;
IF COL_LENGTH('DiaChiKhachHang', 'Phuong')   IS NULL ALTER TABLE DiaChiKhachHang ADD Phuong   NVARCHAR(80)  NULL;
IF COL_LENGTH('DiaChiKhachHang', 'HuongDan') IS NULL ALTER TABLE DiaChiKhachHang ADD HuongDan NVARCHAR(300) NULL;
IF COL_LENGTH('DiaChiKhachHang', 'Lat')      IS NULL ALTER TABLE DiaChiKhachHang ADD Lat DECIMAL(9,6) NULL;
IF COL_LENGTH('DiaChiKhachHang', 'Lng')      IS NULL ALTER TABLE DiaChiKhachHang ADD Lng DECIMAL(9,6) NULL;
GO

/* ---- Cài đặt thông báo ---- */
IF COL_LENGTH('KhachHang', 'NhanTbDonHang')  IS NULL ALTER TABLE KhachHang ADD NhanTbDonHang  BIT NOT NULL CONSTRAINT DF_KH_TbDon DEFAULT 1;
IF COL_LENGTH('KhachHang', 'NhanTbThanhToan') IS NULL ALTER TABLE KhachHang ADD NhanTbThanhToan BIT NOT NULL CONSTRAINT DF_KH_TbTT  DEFAULT 1;
IF COL_LENGTH('KhachHang', 'NhanTbKhuyenMai') IS NULL ALTER TABLE KhachHang ADD NhanTbKhuyenMai BIT NOT NULL CONSTRAINT DF_KH_TbKM  DEFAULT 1;
GO

/* ---- Đơn hàng: chống tạo trùng + tùy chọn món ---- */
IF COL_LENGTH('DonHang', 'MaYeuCauDat') IS NULL ALTER TABLE DonHang ADD MaYeuCauDat VARCHAR(40) NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_DonHang_MaYeuCauDat')
    EXEC(N'CREATE UNIQUE INDEX UX_DonHang_MaYeuCauDat ON DonHang(MaYeuCauDat) WHERE MaYeuCauDat IS NOT NULL');
GO
IF COL_LENGTH('ChiTietDonHang', 'GhiChu')  IS NULL ALTER TABLE ChiTietDonHang ADD GhiChu  NVARCHAR(255) NULL;
IF COL_LENGTH('ChiTietDonHang', 'TuyChon') IS NULL ALTER TABLE ChiTietDonHang ADD TuyChon NVARCHAR(500) NULL;   -- "Lớn; Trân châu"
GO

/* ---- Yêu thích ---- */
IF OBJECT_ID('YeuThich', 'U') IS NULL
BEGIN
    CREATE TABLE YeuThich (
        MaYeuThich  INT IDENTITY(1,1) PRIMARY KEY,
        MaKH        INT NOT NULL REFERENCES KhachHang(MaKH) ON DELETE CASCADE,
        Loai        NVARCHAR(10) NOT NULL CHECK (Loai IN (N'GianHang', N'MonAn')),
        MaThamChieu INT NOT NULL,
        NgayTao     DATETIME NOT NULL DEFAULT GETDATE(),
        CONSTRAINT UQ_YeuThich UNIQUE (MaKH, Loai, MaThamChieu)
    );
END
GO

/* ---- Phiên đăng nhập (xem / đăng xuất thiết bị khác) ---- */
IF OBJECT_ID('PhienDangNhap', 'U') IS NULL
BEGIN
    CREATE TABLE PhienDangNhap (
        MaPhien     UNIQUEIDENTIFIER NOT NULL PRIMARY KEY,
        MaTK        INT NOT NULL REFERENCES TaiKhoan(MaTK) ON DELETE CASCADE,
        Kenh        VARCHAR(10) NOT NULL DEFAULT 'web',      -- web | app
        ThietBi     NVARCHAR(200) NULL,
        DiaChiIP    NVARCHAR(45) NULL,
        NgayTao     DATETIME NOT NULL DEFAULT GETDATE(),
        LanCuoi     DATETIME NOT NULL DEFAULT GETDATE(),
        ThuHoiLuc   DATETIME NULL
    );
    EXEC(N'CREATE INDEX IX_PhienDangNhap_MaTK ON PhienDangNhap(MaTK, ThuHoiLuc)');
END
GO

/* ---- Báo cáo đánh giá không phù hợp ---- */
IF OBJECT_ID('BaoCaoDanhGia', 'U') IS NULL
BEGIN
    CREATE TABLE BaoCaoDanhGia (
        MaBaoCao   INT IDENTITY(1,1) PRIMARY KEY,
        MaKH       INT NOT NULL REFERENCES KhachHang(MaKH),
        MaDanhGia  INT NOT NULL REFERENCES DanhGia(MaDanhGia) ON DELETE CASCADE,
        LyDo       NVARCHAR(255) NOT NULL,
        NgayTao    DATETIME NOT NULL DEFAULT GETDATE(),
        TrangThai  NVARCHAR(15) NOT NULL DEFAULT N'ChoXuLy' CHECK (TrangThai IN (N'ChoXuLy', N'DaXuLy')),
        CONSTRAINT UQ_BaoCaoDanhGia UNIQUE (MaKH, MaDanhGia)
    );
END
GO

/* ========================================================================
   PHẦN 17: CHỨC NĂNG QUẢN TRỊ v12 (cùng nội dung NangCap_v12_QuanTri.sql)
   ======================================================================== */

IF OBJECT_ID('LichSuTrangThaiDon', 'U') IS NULL
    CREATE TABLE LichSuTrangThaiDon (
        MaLichSu   BIGINT IDENTITY(1,1) PRIMARY KEY,
        MaDonHang  INT NOT NULL REFERENCES DonHang(MaDonHang) ON DELETE CASCADE,
        TuTrangThai NVARCHAR(30) NULL,
        DenTrangThai NVARCHAR(30) NOT NULL,
        LyDo       NVARCHAR(300) NULL,
        MaTK       INT NULL,
        ThoiGian   DATETIME NOT NULL DEFAULT GETDATE()
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_LichSuTrangThaiDon' AND object_id = OBJECT_ID('LichSuTrangThaiDon'))
    EXEC(N'CREATE INDEX IX_LichSuTrangThaiDon ON LichSuTrangThaiDon(MaDonHang, ThoiGian)');
GO

IF OBJECT_ID('YeuCauHoanTien', 'U') IS NULL
    CREATE TABLE YeuCauHoanTien (
        MaYeuCau   INT IDENTITY(1,1) PRIMARY KEY,
        MaDonHang  INT NOT NULL REFERENCES DonHang(MaDonHang) ON DELETE CASCADE,
        MaKH       INT NULL,
        SoTien     DECIMAL(12,0) NOT NULL CHECK (SoTien >= 0),
        LyDo       NVARCHAR(400) NOT NULL,
        Nguon      NVARCHAR(20) NOT NULL DEFAULT N'KhachHang',     -- KhachHang | QuanTri | KhieuNai
        TrangThai  NVARCHAR(15) NOT NULL DEFAULT N'ChoDuyet' CHECK (TrangThai IN (N'ChoDuyet', N'DaDuyet', N'TuChoi')),
        MaTKXuLy   INT NULL,
        KetQua     NVARCHAR(400) NULL,
        NgayTao    DATETIME NOT NULL DEFAULT GETDATE(),
        NgayXuLy   DATETIME NULL
    );
GO

IF OBJECT_ID('CauHinhHeThong', 'U') IS NULL
    CREATE TABLE CauHinhHeThong (
        Khoa      NVARCHAR(60) NOT NULL PRIMARY KEY,
        GiaTri    NVARCHAR(300) NOT NULL,
        MoTa      NVARCHAR(300) NULL,
        MaTKSua   INT NULL,
        NgaySua   DATETIME NOT NULL DEFAULT GETDATE()
    );
GO
IF OBJECT_ID('CauHinhHeThongLichSu', 'U') IS NULL
    CREATE TABLE CauHinhHeThongLichSu (
        MaLichSu  BIGINT IDENTITY(1,1) PRIMARY KEY,
        Khoa      NVARCHAR(60) NOT NULL,
        GiaTriCu  NVARCHAR(300) NULL,
        GiaTriMoi NVARCHAR(300) NOT NULL,
        MaTK      INT NULL,
        ThoiGian  DATETIME NOT NULL DEFAULT GETDATE()
    );
GO
MERGE CauHinhHeThong AS t
USING (VALUES
  (N'Giao.PhiMoiKm',        N'4000',   N'Phí giao hàng cho mỗi km (đ)'),
  (N'Giao.PhiMacDinh',      N'15000',  N'Phí giao mặc định khi không xác định được khoảng cách (đ)'),
  (N'Giao.BanKinhKm',       N'20',     N'Bán kính phục vụ tối đa (km)'),
  (N'HoaHong.MacDinh',      N'0.15',   N'Phí nền tảng/hoa hồng mặc định cho gian hàng mới (0.15 = 15%)'),
  (N'Don.TuHuyPhut',        N'15',     N'Khách được tự hủy khi đơn còn Chờ xác nhận (không giới hạn phút nếu để 0)'),
  (N'Don.DuKienPhut',       N'45',     N'Thời gian dự kiến xử lý + giao đơn (phút)'),
  (N'Don.TreSauPhut',       N'30',     N'Đơn bị coi là trễ khi quá thời gian dự kiến thêm bao nhiêu phút'),
  (N'Don.KetTrangThaiPhut', N'60',     N'Đơn đứng yên một trạng thái quá bao nhiêu phút thì coi là bị kẹt'),
  (N'HoanTien.NguongQuanLy',N'200000', N'Quản lý được duyệt hoàn tiền tới mức này (đ); trên mức cần Admin tổng'),
  (N'HoanTien.ChinhSach',   N'Hoàn tiền khi đơn đã thanh toán online bị hủy hoặc giao thất bại do lỗi gian hàng/tài xế; xét theo từng trường hợp với khiếu nại.', N'Nội dung chính sách hoàn tiền hiển thị cho khách'),
  (N'Voucher.ToiDaMoiKhach',N'5',      N'Giới hạn số lần một khách dùng cùng một mã trong 30 ngày (cảnh báo lạm dụng)'),
  (N'QuyDinh.KhachHang',    N'Khách hàng cung cấp thông tin đúng, không đặt đơn ảo, không lạm dụng khuyến mãi.', N'Quy định áp dụng cho khách hàng'),
  (N'QuyDinh.GianHang',     N'Gian hàng đăng thông tin món/giá đúng thực tế, không đăng nội dung vi phạm, xử lý đơn đúng thời hạn.', N'Quy định áp dụng cho gian hàng'),
  (N'QuyDinh.TaiXe',        N'Tài xế giao đúng đơn, giữ thái độ phục vụ, không từ chối đơn đã nhận vô cớ.', N'Quy định áp dụng cho tài xế')
) AS s(Khoa, GiaTri, MoTa) ON t.Khoa = s.Khoa
WHEN NOT MATCHED THEN INSERT (Khoa, GiaTri, MoTa) VALUES (s.Khoa, s.GiaTri, s.MoTa);
GO

IF OBJECT_ID('DieuPhoiLog', 'U') IS NULL
    CREATE TABLE DieuPhoiLog (
        MaLog       BIGINT IDENTITY(1,1) PRIMARY KEY,
        MaDonHang   INT NOT NULL REFERENCES DonHang(MaDonHang) ON DELETE CASCADE,
        HanhDong    NVARCHAR(30) NOT NULL,          -- PhanCong | DoiTaiXe | GoTaiXe | HuyDon
        MaTaiXeCu   INT NULL,
        MaTaiXeMoi  INT NULL,
        LyDo        NVARCHAR(300) NOT NULL,
        MaTK        INT NULL,
        ThoiGian    DATETIME NOT NULL DEFAULT GETDATE()
    );
GO

/* ---- Cột bổ sung ---- */
IF COL_LENGTH('DanhGia', 'DaAn') IS NULL ALTER TABLE DanhGia ADD DaAn BIT NOT NULL CONSTRAINT DF_DanhGia_DaAn DEFAULT 0;
IF COL_LENGTH('DanhGia', 'LyDoAn') IS NULL ALTER TABLE DanhGia ADD LyDoAn NVARCHAR(255) NULL;
IF COL_LENGTH('BaoCaoDanhGia', 'KetQua') IS NULL ALTER TABLE BaoCaoDanhGia ADD KetQua NVARCHAR(255) NULL;
IF COL_LENGTH('BaoCaoDanhGia', 'NgayXuLy') IS NULL ALTER TABLE BaoCaoDanhGia ADD NgayXuLy DATETIME NULL;
IF COL_LENGTH('PhanHoi', 'MaTKPhuTrach') IS NULL ALTER TABLE PhanHoi ADD MaTKPhuTrach INT NULL;
IF COL_LENGTH('PhanHoi', 'YeuCauBoSung') IS NULL ALTER TABLE PhanHoi ADD YeuCauBoSung NVARCHAR(400) NULL;
IF COL_LENGTH('PhanHoi', 'PhanLoai') IS NULL ALTER TABLE PhanHoi ADD PhanLoai NVARCHAR(30) NULL;   -- DonHang | MonAn | TaiXe | GianHang | ThanhToan | Khac
IF COL_LENGTH('GianHang', 'YeuCauBoSung') IS NULL ALTER TABLE GianHang ADD YeuCauBoSung NVARCHAR(400) NULL;
IF COL_LENGTH('GianHang', 'LyDoTuChoi') IS NULL ALTER TABLE GianHang ADD LyDoTuChoi NVARCHAR(255) NULL;
IF COL_LENGTH('TaiXe', 'YeuCauBoSung') IS NULL ALTER TABLE TaiXe ADD YeuCauBoSung NVARCHAR(400) NULL;
IF COL_LENGTH('MonAn', 'LyDoAn') IS NULL ALTER TABLE MonAn ADD LyDoAn NVARCHAR(255) NULL;
IF COL_LENGTH('DonHang', 'TienGiam') IS NULL ALTER TABLE DonHang ADD TienGiam DECIMAL(12,0) NOT NULL CONSTRAINT DF_DonHang_TienGiam DEFAULT 0;
IF COL_LENGTH('ThanhToan', 'DaDoiSoat') IS NULL ALTER TABLE ThanhToan ADD DaDoiSoat BIT NOT NULL CONSTRAINT DF_ThanhToan_DaDoiSoat DEFAULT 0;
IF COL_LENGTH('ThanhToan', 'NgayDoiSoat') IS NULL ALTER TABLE ThanhToan ADD NgayDoiSoat DATETIME NULL;
GO

/* ===== v13: hoàn tiền qua cổng + phân quyền chi tiết ===== */
IF COL_LENGTH('ThanhToan', 'NgayGiaoDichCong') IS NULL ALTER TABLE ThanhToan ADD NgayGiaoDichCong VARCHAR(14) NULL;   -- vnp_PayDate
IF COL_LENGTH('ThanhToan', 'MaGiaoDichHoan')   IS NULL ALTER TABLE ThanhToan ADD MaGiaoDichHoan NVARCHAR(100) NULL;
IF COL_LENGTH('ThanhToan', 'NgayHoan')         IS NULL ALTER TABLE ThanhToan ADD NgayHoan DATETIME NULL;
IF COL_LENGTH('ThanhToan', 'KetQuaHoan')       IS NULL ALTER TABLE ThanhToan ADD KetQuaHoan NVARCHAR(400) NULL;
IF COL_LENGTH('QuanTri', 'QuyenChiTiet')       IS NULL ALTER TABLE QuanTri ADD QuyenChiTiet NVARCHAR(300) NULL;      -- NULL = mặc định theo CapQuyenHan
GO

/* ===== v14: mã xác nhận giao hàng an toàn, bằng chứng giao hàng, vị trí tài xế lưu bền ===== */
IF COL_LENGTH('DonHang', 'MaXacNhanGiao') IS NULL ALTER TABLE DonHang ADD MaXacNhanGiao VARCHAR(8) NULL;
IF COL_LENGTH('DonHang', 'SoLanSaiMa')    IS NULL ALTER TABLE DonHang ADD SoLanSaiMa INT NOT NULL CONSTRAINT DF_DonHang_SoLanSaiMa DEFAULT 0;
IF COL_LENGTH('GiaoHang', 'AnhBangChung')   IS NULL ALTER TABLE GiaoHang ADD AnhBangChung NVARCHAR(300) NULL;
IF COL_LENGTH('GiaoHang', 'ViDoGiao')       IS NULL ALTER TABLE GiaoHang ADD ViDoGiao FLOAT NULL;
IF COL_LENGTH('GiaoHang', 'KinhDoGiao')     IS NULL ALTER TABLE GiaoHang ADD KinhDoGiao FLOAT NULL;
IF COL_LENGTH('GiaoHang', 'LyDoThatBai')    IS NULL ALTER TABLE GiaoHang ADD LyDoThatBai NVARCHAR(300) NULL;
IF COL_LENGTH('GiaoHang', 'TinhPhiThatBai') IS NULL ALTER TABLE GiaoHang ADD TinhPhiThatBai BIT NOT NULL CONSTRAINT DF_GiaoHang_TinhPhiTB DEFAULT 0;
IF COL_LENGTH('GiaoHang', 'NguoiGayLoi')    IS NULL ALTER TABLE GiaoHang ADD NguoiGayLoi NVARCHAR(20) NULL;
IF COL_LENGTH('GiaoHang', 'TienThuCOD')     IS NULL ALTER TABLE GiaoHang ADD TienThuCOD DECIMAL(12,0) NULL;
GO
IF OBJECT_ID('TaiXeViTri', 'U') IS NULL
    CREATE TABLE TaiXeViTri (
        MaDonHang  INT NOT NULL PRIMARY KEY REFERENCES DonHang(MaDonHang) ON DELETE CASCADE,
        MaTaiXe    INT NOT NULL,
        ViDo       FLOAT NOT NULL,
        KinhDo     FLOAT NOT NULL,
        CapNhatLuc DATETIME NOT NULL DEFAULT GETDATE()
    );
GO
/* Chuyển mã cũ "[MA_GIAO:1234]" trong GhiChu sang cột riêng (trước đây tài xế đọc được ghi chú) rồi xóa khỏi ghi chú */
UPDATE DonHang
SET MaXacNhanGiao = SUBSTRING(GhiChu, CHARINDEX('[MA_GIAO:', GhiChu) + 9, CHARINDEX(']', GhiChu, CHARINDEX('[MA_GIAO:', GhiChu)) - CHARINDEX('[MA_GIAO:', GhiChu) - 9),
    GhiChu = NULLIF(LTRIM(RTRIM(STUFF(GhiChu, CHARINDEX('[MA_GIAO:', GhiChu), CHARINDEX(']', GhiChu, CHARINDEX('[MA_GIAO:', GhiChu)) - CHARINDEX('[MA_GIAO:', GhiChu) + 1, ''))), '')
WHERE MaXacNhanGiao IS NULL AND GhiChu LIKE '%[[]MA_GIAO:%]%';
GO

/* ===== v15: sổ giao dịch thanh toán + lịch sử giao hàng ===== */
IF OBJECT_ID('GiaoDichThanhToan', 'U') IS NULL
    CREATE TABLE GiaoDichThanhToan (
        MaGiaoDichTT   BIGINT IDENTITY(1,1) PRIMARY KEY,
        MaThanhToan    INT NOT NULL,
        MaDonHang      INT NOT NULL REFERENCES DonHang(MaDonHang) ON DELETE CASCADE,
        HanhDong       NVARCHAR(20) NOT NULL,      -- TaoMoi | Thu | ThatBai | Hoan | DoiSoat | CapNhat
        HinhThuc       NVARCHAR(20) NOT NULL,
        TuTrangThai    NVARCHAR(30) NULL,
        DenTrangThai   NVARCHAR(30) NOT NULL,
        SoTien         DECIMAL(12,0) NOT NULL DEFAULT 0,
        MaGiaoDichCong NVARCHAR(100) NULL,
        GhiChu         NVARCHAR(500) NULL,
        ThoiGian       DATETIME NOT NULL DEFAULT GETDATE()
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_GiaoDichThanhToan_Don' AND object_id = OBJECT_ID('GiaoDichThanhToan'))
    EXEC(N'CREATE INDEX IX_GiaoDichThanhToan_Don ON GiaoDichThanhToan(MaDonHang, ThoiGian)');
GO
IF OBJECT_ID('LichSuGiaoHang', 'U') IS NULL
    CREATE TABLE LichSuGiaoHang (
        MaLichSuGH   BIGINT IDENTITY(1,1) PRIMARY KEY,
        MaGiaoHang   INT NOT NULL,
        MaDonHang    INT NOT NULL REFERENCES DonHang(MaDonHang) ON DELETE CASCADE,
        MaTaiXe      INT NOT NULL,
        TuTrangThai  NVARCHAR(30) NULL,
        DenTrangThai NVARCHAR(30) NOT NULL,
        ViDo         FLOAT NULL,
        KinhDo       FLOAT NULL,
        GhiChu       NVARCHAR(500) NULL,
        ThoiGian     DATETIME NOT NULL DEFAULT GETDATE()
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_LichSuGiaoHang_Don' AND object_id = OBJECT_ID('LichSuGiaoHang'))
    EXEC(N'CREATE INDEX IX_LichSuGiaoHang_Don ON LichSuGiaoHang(MaDonHang, ThoiGian)');
GO
-- Điền lịch sử ban đầu từ dữ liệu hiện có (chạy một lần)
INSERT INTO GiaoDichThanhToan (MaThanhToan, MaDonHang, HanhDong, HinhThuc, DenTrangThai, SoTien, MaGiaoDichCong, ThoiGian)
SELECT t.MaThanhToan, t.MaDonHang, N'CapNhat', t.HinhThuc, t.TrangThai, d.TongTien, t.MaGiaoDich, ISNULL(t.NgayThanhToan, d.NgayDat)
FROM ThanhToan t JOIN DonHang d ON d.MaDonHang = t.MaDonHang
WHERE NOT EXISTS (SELECT 1 FROM GiaoDichThanhToan g WHERE g.MaThanhToan = t.MaThanhToan);
GO
INSERT INTO LichSuGiaoHang (MaGiaoHang, MaDonHang, MaTaiXe, DenTrangThai, ThoiGian)
SELECT g.MaGiaoHang, g.MaDonHang, g.MaTaiXe, g.TrangThai, ISNULL(g.ThoiGianGiao, ISNULL(g.ThoiGianNhan, GETDATE()))
FROM GiaoHang g
WHERE NOT EXISTS (SELECT 1 FROM LichSuGiaoHang l WHERE l.MaGiaoHang = g.MaGiaoHang);
GO

/* ===== v16: thu nhập tài xế (thưởng/phụ cấp/điều chỉnh, trạng thái trả thu nhập), sự cố giao hàng ===== */
IF COL_LENGTH('GiaoHang', 'ThoiGianLayHang') IS NULL ALTER TABLE GiaoHang ADD ThoiGianLayHang DATETIME NULL;
GO
IF COL_LENGTH('GiaoHang', 'TrangThaiThuNhap') IS NULL ALTER TABLE GiaoHang ADD TrangThaiThuNhap NVARCHAR(15) NOT NULL CONSTRAINT DF_GiaoHang_TTThuNhap DEFAULT N'ChoThanhToan';
GO
IF COL_LENGTH('GiaoHang', 'NgayThanhToanThuNhap') IS NULL ALTER TABLE GiaoHang ADD NgayThanhToanThuNhap DATETIME NULL;
GO
IF COL_LENGTH('GiaoHang', 'CodDaNopLuc') IS NULL ALTER TABLE GiaoHang ADD CodDaNopLuc DATETIME NULL;   -- đối soát COD: lúc quản trị nhận tiền tài xế nộp lại
GO
-- COD của đơn cũ hơn 30 ngày coi như đã nộp (tránh hiện "cần nộp" hàng loạt cho dữ liệu trước khi có tính năng); sửa tay nếu cần
UPDATE GiaoHang SET CodDaNopLuc = ThoiGianGiao WHERE TienThuCOD > 0 AND CodDaNopLuc IS NULL AND ThoiGianGiao < GETDATE() - 30;
GO
IF OBJECT_ID('DieuChinhThuNhap', 'U') IS NULL
    CREATE TABLE DieuChinhThuNhap (
        MaDieuChinh INT IDENTITY(1,1) PRIMARY KEY,
        MaTaiXe     INT NOT NULL,
        MaDonHang   INT NULL,
        Loai        NVARCHAR(15) NOT NULL DEFAULT N'Thuong',   -- Thuong | PhuCap | Phat | DieuChinh
        SoTien      DECIMAL(12,0) NOT NULL,                      -- dương = cộng, âm = trừ
        LyDo        NVARCHAR(300) NOT NULL,
        MaTK        INT NULL,
        NgayTao     DATETIME NOT NULL DEFAULT GETDATE(),
        TrangThai   NVARCHAR(15) NOT NULL DEFAULT N'ChoThanhToan',
        NgayThanhToan DATETIME NULL
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_DieuChinhThuNhap_TaiXe' AND object_id = OBJECT_ID('DieuChinhThuNhap'))
    EXEC(N'CREATE INDEX IX_DieuChinhThuNhap_TaiXe ON DieuChinhThuNhap(MaTaiXe, NgayTao)');
GO
IF OBJECT_ID('SuCoGiaoHang', 'U') IS NULL
    CREATE TABLE SuCoGiaoHang (
        MaSuCo      INT IDENTITY(1,1) PRIMARY KEY,
        MaTaiXe     INT NOT NULL,
        MaDonHang   INT NULL,
        Loai        NVARCHAR(25) NOT NULL DEFAULT N'Khac',
        MoTa        NVARCHAR(1000) NOT NULL,
        AnhMinhChung NVARCHAR(300) NULL,
        TrangThai   NVARCHAR(15) NOT NULL DEFAULT N'ChoXuLy',
        PhanHoiQuanTri NVARCHAR(1000) NULL,
        MaTKXuLy    INT NULL,
        NgayTao     DATETIME NOT NULL DEFAULT GETDATE(),
        NgayXuLy    DATETIME NULL
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_SuCoGiaoHang_TaiXe' AND object_id = OBJECT_ID('SuCoGiaoHang'))
    EXEC(N'CREATE INDEX IX_SuCoGiaoHang_TaiXe ON SuCoGiaoHang(MaTaiXe, NgayTao)');
GO
-- Đơn giao thành công trước v16 coi như đã trả thu nhập (tránh hiện "chờ thanh toán" hàng loạt); sửa tay nếu cần
UPDATE GiaoHang SET TrangThaiThuNhap = N'DaThanhToan', NgayThanhToanThuNhap = ThoiGianGiao
WHERE TrangThai IN (N'GiaoThanhCong', N'GiaoThatBai') AND TrangThaiThuNhap = N'ChoThanhToan' AND ThoiGianGiao < GETDATE() - 30;
GO

/* ===== v31: Quán chọn giao bằng TÀI XẾ CỦA QUÁN hay SHIPPER NGOÀI (nền tảng) =====
   TaiXe.MaGianHang      : NULL = shipper ngoài (nền tảng); có giá trị = tài xế nội bộ của quán đó
   GianHang.CheDoGiao    : Ngoai (mặc định) | Quan  -> áp cho đơn mới khi quán xác nhận; quán vẫn đổi được từng đơn
   DonHang.NguonGiao     : Ngoai | Quan
   Tài xế của quán chỉ nhận đơn do quán gán, không thấy hàng chờ chung; phí giao đơn nội bộ không tính vào thu nhập nền tảng trả. */
IF COL_LENGTH('TaiXe', 'MaGianHang') IS NULL ALTER TABLE TaiXe ADD MaGianHang INT NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_TaiXe_GianHang')
    ALTER TABLE TaiXe ADD CONSTRAINT FK_TaiXe_GianHang FOREIGN KEY (MaGianHang) REFERENCES GianHang(MaGianHang);
GO
IF COL_LENGTH('GianHang', 'CheDoGiao') IS NULL ALTER TABLE GianHang ADD CheDoGiao NVARCHAR(10) NOT NULL CONSTRAINT DF_GianHang_CheDoGiao DEFAULT N'Ngoai';
GO
IF COL_LENGTH('DonHang', 'NguonGiao') IS NULL ALTER TABLE DonHang ADD NguonGiao NVARCHAR(10) NOT NULL CONSTRAINT DF_DonHang_NguonGiao DEFAULT N'Ngoai';
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_TaiXe_GianHang' AND object_id = OBJECT_ID('TaiXe'))
    EXEC(N'CREATE INDEX IX_TaiXe_GianHang ON TaiXe (MaGianHang) WHERE MaGianHang IS NOT NULL');
GO

/* ===== v16: tiến độ chuẩn bị món, xác nhận nhận hàng của khách, mốc đến quán, chuyển khoản ===== */
IF COL_LENGTH('DonHang', 'TrangThaiChuanBi') IS NULL ALTER TABLE DonHang ADD TrangThaiChuanBi NVARCHAR(15) NULL;
IF COL_LENGTH('DonHang', 'ThoiGianSanSang')  IS NULL ALTER TABLE DonHang ADD ThoiGianSanSang DATETIME NULL;
IF COL_LENGTH('DonHang', 'KhachXacNhanLuc')  IS NULL ALTER TABLE DonHang ADD KhachXacNhanLuc DATETIME NULL;
IF COL_LENGTH('GiaoHang', 'ThoiGianDenQuan') IS NULL ALTER TABLE GiaoHang ADD ThoiGianDenQuan DATETIME NULL;
GO
DECLARE @ck sysname;
SELECT @ck = cc.name FROM sys.check_constraints cc
WHERE cc.parent_object_id = OBJECT_ID('ThanhToan') AND cc.definition LIKE '%HinhThuc%' AND cc.name <> 'CK_ThanhToan_HinhThuc';
IF @ck IS NOT NULL EXEC('ALTER TABLE ThanhToan DROP CONSTRAINT ' + @ck);
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = 'CK_ThanhToan_HinhThuc')
    ALTER TABLE ThanhToan ADD CONSTRAINT CK_ThanhToan_HinhThuc
        CHECK (HinhThuc IN (N'TienMat', N'ChuyenKhoan', N'ViDienTu', N'VNPay', N'Momo'));
GO
IF NOT EXISTS (SELECT 1 FROM CauHinhHeThong WHERE Khoa = N'ThanhToan.ThongTinChuyenKhoan')
    INSERT INTO CauHinhHeThong (Khoa, GiaTri, MoTa) VALUES (N'ThanhToan.ThongTinChuyenKhoan', N'Ngân hàng ... - STK ... - Chủ TK ...', N'Thông tin tài khoản hiển thị cho khách chọn chuyển khoản (SỬA lại cho đúng)');
IF NOT EXISTS (SELECT 1 FROM CauHinhHeThong WHERE Khoa = N'Don.BatBuocSanSangGiao')
    INSERT INTO CauHinhHeThong (Khoa, GiaTri, MoTa) VALUES (N'Don.BatBuocSanSangGiao', N'0', N'1 = tài xế chỉ được bấm "Đã lấy hàng" sau khi quán báo "Sẵn sàng giao"');
GO

/* ===== v17: DanhGia gắn tài xế (TaiXe 1-N DanhGia), quán xác nhận bàn giao ===== */
IF COL_LENGTH('DanhGia', 'MaTaiXe') IS NULL ALTER TABLE DanhGia ADD MaTaiXe INT NULL;
GO
IF COL_LENGTH('GiaoHang', 'QuanBanGiaoLuc') IS NULL ALTER TABLE GiaoHang ADD QuanBanGiaoLuc DATETIME NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = 'FK_DanhGia_TaiXe')
    ALTER TABLE DanhGia ADD CONSTRAINT FK_DanhGia_TaiXe FOREIGN KEY (MaTaiXe) REFERENCES TaiXe(MaTaiXe);
GO
UPDATE d SET d.MaTaiXe = g.MaTaiXe FROM DanhGia d JOIN GiaoHang g ON g.MaDonHang = d.MaDonHang WHERE d.MaTaiXe IS NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_DanhGia_TaiXe' AND object_id = OBJECT_ID('DanhGia'))
    EXEC(N'CREATE INDEX IX_DanhGia_TaiXe ON DanhGia(MaTaiXe)');
GO

/* ========================================================================
   PHẦN 18: GIAO HÀNG THEO KM + BẢN ĐỒ (gộp từ 05_BoSung_GiaoHang_BanDo.sql — chạy lại an toàn)
   ======================================================================== */
/* ============================================================
   BỔ SUNG CSDL CHO GIAO HÀNG THEO KHOẢNG CÁCH + BẢN ĐỒ (chạy được NHIỀU LẦN, an toàn)
   Khớp app: phí giao tính theo km (15.000đ/2 km đầu, +5.000đ/km, +10.000đ ngoại thành, tối đa 70.000đ),
   chia sẻ vị trí tài xế, mã xác nhận giao 4 số, giao thất bại (lỗi khách vẫn nhận phí giao).
   Chạy SAU 03_NangCap_v8.sql.
   ============================================================ */
/* ---- DonHang: tuyến đường, phí, mã xác nhận ---- */
IF COL_LENGTH('DonHang','DiaChiLayHang')      IS NULL ALTER TABLE DonHang ADD DiaChiLayHang NVARCHAR(300) NULL;
IF COL_LENGTH('DonHang','KhoangCachKm')       IS NULL ALTER TABLE DonHang ADD KhoangCachKm DECIMAL(6,1) NOT NULL CONSTRAINT DF_DonHang_KhoangCachKm DEFAULT 0;      -- 0 = chưa xác định
IF COL_LENGTH('DonHang','KhoangCachThucTeKm') IS NULL ALTER TABLE DonHang ADD KhoangCachThucTeKm DECIMAL(6,1) NOT NULL CONSTRAINT DF_DonHang_KmThucTe DEFAULT 0;      -- tài xế báo lại
IF COL_LENGTH('DonHang','ThoiGianDuKienPhut') IS NULL ALTER TABLE DonHang ADD ThoiGianDuKienPhut INT NOT NULL CONSTRAINT DF_DonHang_ThoiGianDuKien DEFAULT 0;
IF COL_LENGTH('DonHang','KhuVucLay')          IS NULL ALTER TABLE DonHang ADD KhuVucLay NVARCHAR(60) NULL;
IF COL_LENGTH('DonHang','KhuVucGiao')         IS NULL ALTER TABLE DonHang ADD KhuVucGiao NVARCHAR(60) NULL;
IF COL_LENGTH('DonHang','NgoaiThanh')         IS NULL ALTER TABLE DonHang ADD NgoaiThanh BIT NOT NULL CONSTRAINT DF_DonHang_NgoaiThanh DEFAULT 0;
IF COL_LENGTH('DonHang','PhiKhoangCach')      IS NULL ALTER TABLE DonHang ADD PhiKhoangCach DECIMAL(12,0) NOT NULL CONSTRAINT DF_DonHang_PhiKm DEFAULT 0;
IF COL_LENGTH('DonHang','PhuPhiKhuVuc')       IS NULL ALTER TABLE DonHang ADD PhuPhiKhuVuc DECIMAL(12,0) NOT NULL CONSTRAINT DF_DonHang_PhuPhi DEFAULT 0;
IF COL_LENGTH('DonHang','PhiDaDieuChinh')     IS NULL ALTER TABLE DonHang ADD PhiDaDieuChinh BIT NOT NULL CONSTRAINT DF_DonHang_PhiDaDieuChinh DEFAULT 0;
IF COL_LENGTH('DonHang','MaXacNhanGiao')      IS NULL ALTER TABLE DonHang ADD MaXacNhanGiao VARCHAR(4) NULL;   -- khách đọc cho tài xế khi nhận hàng
GO

/* ---- GiaoHang: lấy hàng, vị trí tài xế, liên lạc, giao thất bại ---- */
IF COL_LENGTH('GiaoHang','LayHangLuc')        IS NULL ALTER TABLE GiaoHang ADD LayHangLuc DATETIME NULL;
IF COL_LENGTH('GiaoHang','TaiXeLat')          IS NULL ALTER TABLE GiaoHang ADD TaiXeLat DECIMAL(9,6) NULL;
IF COL_LENGTH('GiaoHang','TaiXeLng')          IS NULL ALTER TABLE GiaoHang ADD TaiXeLng DECIMAL(9,6) NULL;
IF COL_LENGTH('GiaoHang','ViTriCapNhatLuc')   IS NULL ALTER TABLE GiaoHang ADD ViTriCapNhatLuc DATETIME NULL;
IF COL_LENGTH('GiaoHang','SoLanGoiKhach')     IS NULL ALTER TABLE GiaoHang ADD SoLanGoiKhach INT NOT NULL CONSTRAINT DF_GiaoHang_SoLanGoi DEFAULT 0;
IF COL_LENGTH('GiaoHang','GiaoThatBaiLuc')    IS NULL ALTER TABLE GiaoHang ADD GiaoThatBaiLuc DATETIME NULL;
IF COL_LENGTH('GiaoHang','TinhPhiKhiThatBai') IS NULL ALTER TABLE GiaoHang ADD TinhPhiKhiThatBai BIT NOT NULL CONSTRAINT DF_GiaoHang_TinhPhiThatBai DEFAULT 0;  -- lỗi do khách: tài xế vẫn nhận phí giao
GO

SELECT N'DonHang' AS Bang, name FROM sys.columns WHERE object_id = OBJECT_ID('DonHang') AND name IN ('KhoangCachKm','PhiKhoangCach','PhuPhiKhuVuc','MaXacNhanGiao')
UNION ALL SELECT N'GiaoHang', name FROM sys.columns WHERE object_id = OBJECT_ID('GiaoHang') AND name IN ('TaiXeLat','TaiXeLng','SoLanGoiKhach','TinhPhiKhiThatBai');
GO

/* ========================================================================
   v18: TỌA ĐỘ GIAN HÀNG — phục vụ lọc/sắp xếp theo khoảng cách (chạy lại an toàn)
   Web tự geocode địa chỉ quán qua Goong Maps và lưu vào 2 cột này; null = chưa xác định.
   ======================================================================== */
IF COL_LENGTH('GianHang', 'ViDo')   IS NULL ALTER TABLE GianHang ADD ViDo FLOAT NULL;
IF COL_LENGTH('GianHang', 'KinhDo') IS NULL ALTER TABLE GianHang ADD KinhDo FLOAT NULL;
GO


/* ============================================================
   PHẦN 18b: bảng TinNhanDonHang — KHÔNG DÙNG (thừa từ v15; chat thật dùng bảng TinNhan của ChatApiController). Giữ để DB cũ không lỗi, có thể xóa bảng này nếu rỗng.
   ============================================================ */
IF OBJECT_ID('TinNhanDonHang', 'U') IS NULL
BEGIN
    CREATE TABLE TinNhanDonHang (
        MaTinNhan   NVARCHAR(40)   NOT NULL PRIMARY KEY,
        MaDonHang   INT            NOT NULL REFERENCES DonHang(MaDonHang) ON DELETE CASCADE,
        NguoiGui    NVARCHAR(20)   NOT NULL CHECK (NguoiGui IN (N'KhachHang', N'TaiXe')),
        TenNguoiGui NVARCHAR(100)  NOT NULL,
        NoiDung     NVARCHAR(1000) NOT NULL,
        ThoiGian    DATETIME       NOT NULL DEFAULT GETDATE()
    );
    EXEC(N'CREATE INDEX IX_TinNhanDonHang_Don ON TinNhanDonHang (MaDonHang, ThoiGian)');
END
GO

/* ============================================================
   PHẦN 18c: ĐỒNG BỘ v18 → v21 (chạy lại an toàn) — khớp entity của Web v16
   Gộp từ: NangCap_v18_DanhMucDaAn, NangCap_v18_TinNhan_MaClient, NangCap_v19_TuyenDuongGiaoHang, NangCap_v21_TaiXeTuChoiDon.
   (v20 — toạ độ gian hàng ViDo/KinhDo — đã nằm ngay phía trên.)
   ============================================================ */

/* ===== v18: DanhMuc.DaAn (ẩn danh mục) ===== */
IF COL_LENGTH('DanhMuc', 'DaAn') IS NULL ALTER TABLE DanhMuc ADD DaAn BIT NOT NULL CONSTRAINT DF_DanhMuc_DaAn DEFAULT 0;
GO

/* ===== v18: chat khách <-> tài xế qua API (cột MaClient chống gửi trùng) ===== */
IF OBJECT_ID('TinNhan', 'U') IS NULL
BEGIN
    CREATE TABLE TinNhan (
        MaTinNhan   INT IDENTITY(1,1) PRIMARY KEY,
        MaDonHang   INT NOT NULL REFERENCES DonHang(MaDonHang),
        NguoiGui    NVARCHAR(20) NOT NULL CHECK (NguoiGui IN (N'KhachHang', N'TaiXe')),
        TenNguoiGui NVARCHAR(100) NULL,
        NoiDung     NVARCHAR(1000) NOT NULL,
        ThoiGian    DATETIME NOT NULL DEFAULT GETDATE()
    );
    EXEC(N'CREATE INDEX IX_TinNhan_DonHang ON TinNhan (MaDonHang, ThoiGian)');
END
GO
IF COL_LENGTH('TinNhan', 'MaClient') IS NULL ALTER TABLE TinNhan ADD MaClient NVARCHAR(40) NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_TinNhan_MaClient' AND object_id = OBJECT_ID('TinNhan'))
    EXEC(N'CREATE UNIQUE INDEX UX_TinNhan_MaClient ON TinNhan (MaDonHang, MaClient) WHERE MaClient IS NOT NULL');
GO

/* ===== v19: cột tuyến đường/phí giao của DonHang (entity dùng FLOAT) — chạy nhiều lần an toàn ===== */
IF COL_LENGTH('DonHang', 'KhoangCachKm') IS NULL ALTER TABLE DonHang ADD KhoangCachKm FLOAT NULL;
IF COL_LENGTH('DonHang', 'KhoangCachThucTeKm') IS NULL ALTER TABLE DonHang ADD KhoangCachThucTeKm FLOAT NULL;
IF COL_LENGTH('DonHang', 'ThoiGianDuKienPhut') IS NULL ALTER TABLE DonHang ADD ThoiGianDuKienPhut INT NULL;
IF COL_LENGTH('DonHang', 'NgoaiThanh') IS NULL ALTER TABLE DonHang ADD NgoaiThanh BIT NOT NULL CONSTRAINT DF_DonHang_NgoaiThanh DEFAULT 0;
IF COL_LENGTH('DonHang', 'PhiDaDieuChinh') IS NULL ALTER TABLE DonHang ADD PhiDaDieuChinh BIT NOT NULL CONSTRAINT DF_DonHang_PhiDaDieuChinh DEFAULT 0;
GO
-- Nếu trước đó đã chạy 05_BoSung_GiaoHang_BanDo.sql (cột DECIMAL NOT NULL + DEFAULT) -> đổi sang FLOAT NULL để khớp entity
DECLARE @c TABLE (Cot sysname);
INSERT @c VALUES (N'KhoangCachKm'), (N'KhoangCachThucTeKm');
DECLARE @cot sysname, @sql NVARCHAR(MAX);
DECLARE cur CURSOR LOCAL FOR SELECT Cot FROM @c;
OPEN cur; FETCH NEXT FROM cur INTO @cot;
WHILE @@FETCH_STATUS = 0
BEGIN
    IF EXISTS (SELECT 1 FROM sys.columns col JOIN sys.types t ON t.user_type_id = col.user_type_id
               WHERE col.object_id = OBJECT_ID('DonHang') AND col.name = @cot AND t.name <> 'float')
    BEGIN
        SELECT @sql = 'ALTER TABLE DonHang DROP CONSTRAINT ' + QUOTENAME(dc.name)
        FROM sys.default_constraints dc JOIN sys.columns col ON col.object_id = dc.parent_object_id AND col.column_id = dc.parent_column_id
        WHERE dc.parent_object_id = OBJECT_ID('DonHang') AND col.name = @cot;
        IF @sql IS NOT NULL EXEC(@sql);
        SET @sql = NULL;
        EXEC('ALTER TABLE DonHang ALTER COLUMN ' + @cot + ' FLOAT NULL');
    END
    FETCH NEXT FROM cur INTO @cot;
END
CLOSE cur; DEALLOCATE cur;
GO
DECLARE @s2 NVARCHAR(MAX);
SELECT @s2 = 'ALTER TABLE DonHang DROP CONSTRAINT ' + QUOTENAME(dc.name)
FROM sys.default_constraints dc JOIN sys.columns col ON col.object_id = dc.parent_object_id AND col.column_id = dc.parent_column_id
WHERE dc.parent_object_id = OBJECT_ID('DonHang') AND col.name = 'ThoiGianDuKienPhut';
IF @s2 IS NOT NULL EXEC(@s2);
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('DonHang') AND name = 'ThoiGianDuKienPhut' AND is_nullable = 0)
    ALTER TABLE DonHang ALTER COLUMN ThoiGianDuKienPhut INT NULL;
GO

/* ---- v21: tài xế từ chối đơn — bảng TaiXeTuChoiDon đã tạo ở PHẦN 12; ở đây chỉ đồng bộ cấu hình ---- */
/* Quy trình lấy món (v16): bật điều kiện "quán báo sẵn sàng giao / đã bàn giao" trước khi tài xế bấm "Đã lấy hàng". */
IF EXISTS (SELECT 1 FROM CauHinhHeThong WHERE Khoa = N'Don.BatBuocSanSangGiao')
    UPDATE CauHinhHeThong SET GiaTri = N'1' WHERE Khoa = N'Don.BatBuocSanSangGiao';
ELSE
    INSERT INTO CauHinhHeThong (Khoa, GiaTri, MoTa) VALUES (N'Don.BatBuocSanSangGiao', N'1', N'1 = tài xế chỉ được bấm "Đã lấy hàng" sau khi quán báo "Sẵn sàng giao"');
IF NOT EXISTS (SELECT 1 FROM CauHinhHeThong WHERE Khoa = N'Don.BatBuocMaDonKhiLayHang')
    INSERT INTO CauHinhHeThong (Khoa, GiaTri, MoTa) VALUES (N'Don.BatBuocMaDonKhiLayHang', N'0', N'1 = bắt buộc nhập mã đơn khi bấm "Đã lấy hàng" (web luôn yêu cầu nhập)');
GO

/* ============================================================
   PHẦN 18d (v23): CÀI ĐẶT PHÍ & CHÍNH SÁCH — chạy lại an toàn
   - Mở rộng cột lưu để chứa nội dung chính sách/quy định dài (tới 1000 ký tự)
   - Bổ sung khóa: QuyDinh.HuyDon, Don.TaiXePhanHoiPhut
   ============================================================ */
IF COL_LENGTH('CauHinhHeThong', 'GiaTri') < 2000 ALTER TABLE CauHinhHeThong ALTER COLUMN GiaTri NVARCHAR(1000) NOT NULL;
IF COL_LENGTH('CauHinhHeThongLichSu', 'GiaTriCu') < 2000 ALTER TABLE CauHinhHeThongLichSu ALTER COLUMN GiaTriCu NVARCHAR(1000) NULL;
IF COL_LENGTH('CauHinhHeThongLichSu', 'GiaTriMoi') < 2000 ALTER TABLE CauHinhHeThongLichSu ALTER COLUMN GiaTriMoi NVARCHAR(1000) NOT NULL;
GO
MERGE CauHinhHeThong AS t
USING (VALUES
  (N'QuyDinh.HuyDon', N'Khách được tự hủy khi đơn còn Chờ xác nhận trong thời gian cho phép. Sau khi gian hàng đã xác nhận, vui lòng liên hệ hỗ trợ để được xem xét.', N'Nội dung quy định hủy đơn hiển thị cho khách'),
  (N'Don.TaiXePhanHoiPhut', N'5', N'Quá số phút này chưa có tài xế nhận thì điều phối lại + báo quản trị')
) AS s(Khoa, GiaTri, MoTa) ON t.Khoa = s.Khoa
WHEN NOT MATCHED THEN INSERT (Khoa, GiaTri, MoTa) VALUES (s.Khoa, s.GiaTri, s.MoTa);
GO

/* ############ v39: Chiến dịch quảng cáo của gian hàng (gộp từ NangCap_v16_ChienDichQuangCao.sql) — chạy lặp lại an toàn ############ */
/* Nâng cấp v16: chiến dịch quảng cáo của gian hàng. Có thể chạy lặp lại an toàn. */
IF OBJECT_ID(N'dbo.ChienDichQuangCao', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ChienDichQuangCao (
        MaChienDich   INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ChienDichQuangCao PRIMARY KEY,
        MaGianHang    INT NOT NULL,
        TenChienDich  NVARCHAR(150) NOT NULL,
        LoaiViTri     NVARCHAR(20) NOT NULL CONSTRAINT DF_ChienDichQuangCao_LoaiViTri DEFAULT N'NoiBat',
        TieuDe        NVARCHAR(150) NOT NULL,
        NoiDung       NVARCHAR(500) NULL,
        HinhAnh       NVARCHAR(500) NULL,
        NgayBatDau    DATETIME2 NOT NULL,
        NgayKetThuc   DATETIME2 NOT NULL,
        NganSach      DECIMAL(12,0) NOT NULL CONSTRAINT DF_ChienDichQuangCao_NganSach DEFAULT 0,
        TrangThai     NVARCHAR(20) NOT NULL CONSTRAINT DF_ChienDichQuangCao_TrangThai DEFAULT N'BanNhap',
        LuotHienThi   INT NOT NULL CONSTRAINT DF_ChienDichQuangCao_LuotHienThi DEFAULT 0,
        LuotTuongTac  INT NOT NULL CONSTRAINT DF_ChienDichQuangCao_LuotTuongTac DEFAULT 0,
        NgayTao       DATETIME2 NOT NULL CONSTRAINT DF_ChienDichQuangCao_NgayTao DEFAULT GETDATE(),
        CONSTRAINT FK_ChienDichQuangCao_GianHang FOREIGN KEY (MaGianHang)
            REFERENCES dbo.GianHang(MaGianHang) ON DELETE CASCADE,
        CONSTRAINT CK_ChienDichQuangCao_LoaiViTri CHECK (LoaiViTri IN (N'Banner', N'NoiBat', N'GoiY')),
        CONSTRAINT CK_ChienDichQuangCao_TrangThai CHECK (TrangThai IN (N'BanNhap', N'DangChay', N'TamDung')),
        CONSTRAINT CK_ChienDichQuangCao_ThoiGian CHECK (NgayKetThuc > NgayBatDau),
        CONSTRAINT CK_ChienDichQuangCao_NganSach CHECK (NganSach >= 0)
    );
END;
GO

IF OBJECT_ID(N'dbo.ChienDichQuangCao', N'U') IS NOT NULL
   AND NOT EXISTS (
       SELECT 1 FROM sys.indexes
       WHERE object_id = OBJECT_ID(N'dbo.ChienDichQuangCao')
         AND name = N'IX_ChienDichQuangCao_MaGianHang_TrangThai_ThoiGian'
   )
BEGIN
    EXEC(N'CREATE INDEX IX_ChienDichQuangCao_MaGianHang_TrangThai_ThoiGian
        ON dbo.ChienDichQuangCao(MaGianHang, TrangThai, NgayBatDau, NgayKetThuc)');
END;
GO

/* ############ v51 – Trạng thái đơn: người thực hiện, chống ghi đè, đối soát lại cổng thanh toán ############ */
IF COL_LENGTH('DonHang', 'RowVer') IS NULL ALTER TABLE DonHang ADD RowVer ROWVERSION;
GO
IF COL_LENGTH('LichSuTrangThaiDon', 'VaiTro') IS NULL ALTER TABLE LichSuTrangThaiDon ADD VaiTro NVARCHAR(20) NULL;
GO
IF COL_LENGTH('ThanhToan', 'NgayTaoLinkCong') IS NULL ALTER TABLE ThanhToan ADD NgayTaoLinkCong NVARCHAR(14) NULL;
GO

/* ############ v86: Phân phối đơn cho tài xế (đề nghị có thời hạn, nhịp kết nối, tạm khóa nhận đơn) — chạy lặp lại an toàn ############ */
IF COL_LENGTH('TaiXe', 'ViDo') IS NULL ALTER TABLE TaiXe ADD ViDo FLOAT NULL;
IF COL_LENGTH('TaiXe', 'KinhDo') IS NULL ALTER TABLE TaiXe ADD KinhDo FLOAT NULL;
IF COL_LENGTH('TaiXe', 'ViTriLuc') IS NULL ALTER TABLE TaiXe ADD ViTriLuc DATETIME2 NULL;
IF COL_LENGTH('TaiXe', 'NhipLuc') IS NULL ALTER TABLE TaiXe ADD NhipLuc DATETIME2 NULL;
IF COL_LENGTH('TaiXe', 'SoLanKhongPhanHoi') IS NULL ALTER TABLE TaiXe ADD SoLanKhongPhanHoi INT NOT NULL CONSTRAINT DF_TaiXe_KhongPhanHoi DEFAULT 0;
IF COL_LENGTH('TaiXe', 'SoLanHuySauNhan') IS NULL ALTER TABLE TaiXe ADD SoLanHuySauNhan INT NOT NULL CONSTRAINT DF_TaiXe_HuySauNhan DEFAULT 0;
IF COL_LENGTH('TaiXe', 'TamKhoaNhanDenLuc') IS NULL ALTER TABLE TaiXe ADD TamKhoaNhanDenLuc DATETIME2 NULL;
GO
IF OBJECT_ID(N'dbo.DeNghiGiaoDon', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.DeNghiGiaoDon (
        MaDeNghi     BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_DeNghiGiaoDon PRIMARY KEY,
        MaDonHang    INT NOT NULL CONSTRAINT FK_DeNghi_DonHang REFERENCES dbo.DonHang(MaDonHang),
        MaTaiXe      INT NOT NULL CONSTRAINT FK_DeNghi_TaiXe REFERENCES dbo.TaiXe(MaTaiXe),
        Vong         INT NOT NULL CONSTRAINT DF_DeNghi_Vong DEFAULT 1,
        TrangThai    NVARCHAR(20) NOT NULL CONSTRAINT DF_DeNghi_TrangThai DEFAULT N'ChoPhanHoi'
                     CONSTRAINT CK_DeNghi_TrangThai CHECK (TrangThai IN (N'ChoPhanHoi', N'DaNhan', N'TuChoi', N'HetHan', N'Huy')),
        Diem         FLOAT NOT NULL CONSTRAINT DF_DeNghi_Diem DEFAULT 0,
        KmDenQuan    FLOAT NULL,
        LyDoChon     NVARCHAR(400) NULL,
        LyDoPhanHoi  NVARCHAR(200) NULL,
        TaoLuc       DATETIME2 NOT NULL CONSTRAINT DF_DeNghi_TaoLuc DEFAULT SYSDATETIME(),
        HetHanLuc    DATETIME2 NOT NULL,
        PhanHoiLuc   DATETIME2 NULL
    );
END
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_DeNghi_Don_Cho' AND object_id = OBJECT_ID('dbo.DeNghiGiaoDon'))
    EXEC(N'CREATE UNIQUE INDEX UX_DeNghi_Don_Cho ON dbo.DeNghiGiaoDon(MaDonHang) WHERE TrangThai = N''ChoPhanHoi'''); -- 1 đơn chỉ có 1 đề nghị đang chờ
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_DeNghi_TaiXe_Cho' AND object_id = OBJECT_ID('dbo.DeNghiGiaoDon'))
    EXEC(N'CREATE UNIQUE INDEX UX_DeNghi_TaiXe_Cho ON dbo.DeNghiGiaoDon(MaTaiXe) WHERE TrangThai = N''ChoPhanHoi'''); -- 1 tài xế chỉ có 1 đề nghị đang chờ
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_DeNghi_Don' AND object_id = OBJECT_ID('dbo.DeNghiGiaoDon'))
    EXEC(N'CREATE INDEX IX_DeNghi_Don ON dbo.DeNghiGiaoDon(MaDonHang, TrangThai, Vong)');
GO

/* ============================================================
   PHẦN 19: SAO LƯU / PHỤC HỒI (TÙY CHỌN — đang comment)
   ============================================================ */
-- /* ============================================================
--    SAO LƯU / PHỤC HỒI CSDL QuanLyDichVuAnUong
--    Chiến lược: Full mỗi đêm 02:00 + Differential mỗi 6 giờ + Log mỗi 15 phút (mất tối đa ~15 phút dữ liệu)
--    + dọn dữ liệu quá hạn lúc 03:00. Chạy trên SQL Server có SQL Server Agent (không dùng được trên Express: xem mục B).
--    ĐỔI @Dir sang thư mục có quyền ghi của tài khoản chạy SQL Server, và nên là ổ đĩa/NAS khác máy DB.
--    ============================================================ */
-- 
-- /* ---------- A. Thiết lập ---------- */
-- USE master;
-- GO
-- ALTER DATABASE QuanLyDichVuAnUong SET RECOVERY FULL;     -- bắt buộc để sao lưu Log
-- GO
-- 
-- /* ---------- B. Sao lưu thủ công (chạy được trên mọi phiên bản, kể cả Express) ---------- */
-- DECLARE @Dir NVARCHAR(300) = N'C:\Backup\FoodService\';
-- DECLARE @f NVARCHAR(400) = @Dir + N'Full_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + N'.bak';
-- BACKUP DATABASE QuanLyDichVuAnUong TO DISK = @f
--     WITH COMPRESSION, CHECKSUM, INIT, STATS = 10, NAME = N'FoodService Full';
-- RESTORE VERIFYONLY FROM DISK = @f WITH CHECKSUM;         -- kiểm tra file sao lưu đọc được
-- GO
-- 
-- /* Differential:
-- DECLARE @f NVARCHAR(400) = N'C:\Backup\FoodService\Diff_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + N'.bak';
-- BACKUP DATABASE QuanLyDichVuAnUong TO DISK = @f WITH DIFFERENTIAL, COMPRESSION, CHECKSUM, INIT;
--    Log:
-- DECLARE @f NVARCHAR(400) = N'C:\Backup\FoodService\Log_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + N'.trn';
-- BACKUP LOG QuanLyDichVuAnUong TO DISK = @f WITH COMPRESSION, CHECKSUM, INIT;
-- */
-- 
-- /* ---------- C. Tạo lịch tự động bằng SQL Server Agent ---------- */
-- USE msdb;
-- GO
-- DECLARE @Dir NVARCHAR(300) = N'C:\Backup\FoodService\';     -- phải trùng thư mục ở trên
-- DECLARE @DB  sysname = N'QuanLyDichVuAnUong';
-- 
-- DECLARE @jobs TABLE (Ten sysname, Lenh NVARCHAR(MAX), FreqType INT, FreqInterval INT, SubType INT, SubInterval INT, StartTime INT);
-- INSERT INTO @jobs VALUES
--  (N'FoodService - Full backup 02:00',
--   N'DECLARE @f NVARCHAR(400)=N''' + @Dir + N'Full_''+FORMAT(GETDATE(),''yyyyMMdd_HHmmss'')+N''.bak''; '
--   + N'BACKUP DATABASE ' + QUOTENAME(@DB) + N' TO DISK=@f WITH COMPRESSION, CHECKSUM, INIT; RESTORE VERIFYONLY FROM DISK=@f WITH CHECKSUM;',
--   4, 1, 1, 0, 020000),
--  (N'FoodService - Differential 6 gio',
--   N'DECLARE @f NVARCHAR(400)=N''' + @Dir + N'Diff_''+FORMAT(GETDATE(),''yyyyMMdd_HHmmss'')+N''.bak''; '
--   + N'BACKUP DATABASE ' + QUOTENAME(@DB) + N' TO DISK=@f WITH DIFFERENTIAL, COMPRESSION, CHECKSUM, INIT;',
--   4, 1, 8, 6, 080000),
--  (N'FoodService - Log backup 15 phut',
--   N'DECLARE @f NVARCHAR(400)=N''' + @Dir + N'Log_''+FORMAT(GETDATE(),''yyyyMMdd_HHmmss'')+N''.trn''; '
--   + N'BACKUP LOG ' + QUOTENAME(@DB) + N' TO DISK=@f WITH COMPRESSION, CHECKSUM, INIT;',
--   4, 1, 4, 15, 000500),
--  (N'FoodService - Don dep du lieu 03:00',
--   N'EXEC ' + QUOTENAME(@DB) + N'.dbo.sp_DonDepDuLieu;',
--   4, 1, 1, 0, 030000);
-- 
-- DECLARE @n sysname, @c NVARCHAR(MAX), @ft INT, @fi INT, @st INT, @si INT, @t INT;
-- DECLARE jc CURSOR LOCAL FAST_FORWARD FOR SELECT Ten, Lenh, FreqType, FreqInterval, SubType, SubInterval, StartTime FROM @jobs;
-- OPEN jc; FETCH NEXT FROM jc INTO @n, @c, @ft, @fi, @st, @si, @t;
-- WHILE @@FETCH_STATUS = 0
-- BEGIN
--     IF NOT EXISTS (SELECT 1 FROM dbo.sysjobs WHERE name = @n)
--     BEGIN
--         EXEC dbo.sp_add_job         @job_name = @n, @enabled = 1;
--         EXEC dbo.sp_add_jobstep     @job_name = @n, @step_name = N'Chay', @subsystem = N'TSQL', @command = @c, @database_name = N'master';
--         EXEC dbo.sp_add_jobschedule @job_name = @n, @name = N'Lich', @freq_type = @ft, @freq_interval = @fi,
--                                     @freq_subday_type = @st, @freq_subday_interval = @si, @active_start_time = @t;
--         EXEC dbo.sp_add_jobserver   @job_name = @n;
--     END
--     FETCH NEXT FROM jc INTO @n, @c, @ft, @fi, @st, @si, @t;
-- END
-- CLOSE jc; DEALLOCATE jc;
-- GO
-- 
-- /* ---------- D. Phục hồi (ví dụ) — CHẠY TỪNG BƯỚC, thay tên file cho đúng ----------
-- USE master;
-- ALTER DATABASE QuanLyDichVuAnUong SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
-- RESTORE DATABASE QuanLyDichVuAnUong FROM DISK = N'C:\Backup\FoodService\Full_20261007_020000.bak' WITH NORECOVERY, REPLACE;
-- RESTORE DATABASE QuanLyDichVuAnUong FROM DISK = N'C:\Backup\FoodService\Diff_20261007_080000.bak' WITH NORECOVERY;
-- RESTORE LOG      QuanLyDichVuAnUong FROM DISK = N'C:\Backup\FoodService\Log_20261007_081500.trn'  WITH NORECOVERY;
-- -- ... các file Log kế tiếp theo thứ tự; muốn dừng ở thời điểm cụ thể: WITH STOPAT = '2026-10-07 09:10:00', RECOVERY
-- RESTORE DATABASE QuanLyDichVuAnUong WITH RECOVERY;
-- ALTER DATABASE QuanLyDichVuAnUong SET MULTI_USER;
-- -- Nên thử phục hồi sang một DB tên khác (WITH MOVE ...) định kỳ để chắc chắn bản sao lưu dùng được.
-- -- Xóa file sao lưu cũ hơn 14 ngày: dùng Windows Task Scheduler/PowerShell (Get-ChildItem | Where LastWriteTime -lt (Get-Date).AddDays(-14) | Remove-Item).
-- */

IF OBJECT_ID('Banner', 'U') IS NULL
    CREATE TABLE Banner (
        MaBanner INT IDENTITY(1,1) PRIMARY KEY,
        TieuDe NVARCHAR(150) NOT NULL,
        HinhAnh NVARCHAR(300) NOT NULL DEFAULT N'',
        LienKet NVARCHAR(300) NULL,
        ThuTu INT NOT NULL DEFAULT 0,
        NgayBatDau DATETIME NULL,
        NgayKetThuc DATETIME NULL,
        TrangThai BIT NOT NULL DEFAULT 1,
        NgayTao DATETIME NOT NULL DEFAULT GETDATE(),
        MaTKTao INT NULL
    );
GO

IF COL_LENGTH('DonHang', 'ThoiGianChuanBiPhut') IS NULL ALTER TABLE DonHang ADD ThoiGianChuanBiPhut INT NULL;      -- quán ước tính thời gian chuẩn bị khi xác nhận
IF COL_LENGTH('GianHang', 'AnhBia') IS NULL ALTER TABLE GianHang ADD AnhBia NVARCHAR(300) NULL;                         -- ảnh bìa trang quán
GO

IF COL_LENGTH('MonAn', 'NoiBat') IS NULL ALTER TABLE MonAn ADD NoiBat BIT NOT NULL CONSTRAINT DF_MonAn_NoiBat DEFAULT 0;      -- quán đánh dấu món nổi bật
GO

IF COL_LENGTH('TaiKhoan', 'PhienHopLeTu') IS NULL ALTER TABLE TaiKhoan ADD PhienHopLeTu DATETIME NULL;      -- thu hồi phiên đăng nhập (JWT cấp trước mốc này bị từ chối)
GO


/* ############ v47f: Câu hỏi thường gặp do quản trị biên tập — chạy lặp lại an toàn ############ */
IF OBJECT_ID('CauHoiThuongGap', 'U') IS NULL
    CREATE TABLE CauHoiThuongGap (
        MaCauHoi INT IDENTITY(1,1) PRIMARY KEY,
        CauHoi NVARCHAR(300) NOT NULL,
        TraLoi NVARCHAR(2000) NOT NULL,
        ThuTu INT NOT NULL DEFAULT 0,
        TrangThai BIT NOT NULL DEFAULT 1,
        NgayTao DATETIME NOT NULL DEFAULT GETDATE(),
        MaTKTao INT NULL
    );
GO

/* ############ v47f: Đánh dấu đã trả tiền cho gian hàng — chạy lặp lại an toàn ############ */
IF COL_LENGTH('DonHang', 'QuanDaTraLuc') IS NULL ALTER TABLE DonHang ADD QuanDaTraLuc DATETIME NULL;
GO

/* ############ v66 – Đặt món theo lịch ############ */
IF COL_LENGTH('DonHang', 'HenGiaoLuc') IS NULL ALTER TABLE DonHang ADD HenGiaoLuc DATETIME2 NULL;
GO

/* ############ v83 – Tỉ lệ phí giao tài xế nhận (chốt lúc đặt đơn; NULL = đơn cũ nhận 100%) ############ */
IF COL_LENGTH('DonHang', 'TyLeTaiXe') IS NULL ALTER TABLE DonHang ADD TyLeTaiXe DECIMAL(5,4) NULL;
GO

/* ############ v63: Ảnh đính kèm đánh giá — chạy lặp lại an toàn ############ */
IF COL_LENGTH('DanhGia', 'AnhDanhGia') IS NULL ALTER TABLE DanhGia ADD AnhDanhGia NVARCHAR(700) NULL;   -- tối đa 3 đường dẫn ảnh, ngăn cách bằng |
GO

/* ############ v63: Nhân viên gian hàng (tài khoản + quyền) — chạy lặp lại an toàn ############ */
IF OBJECT_ID('NhanVienGianHang', 'U') IS NULL
    CREATE TABLE NhanVienGianHang (
        MaNV INT IDENTITY(1,1) PRIMARY KEY,
        MaGianHang INT NOT NULL,
        TenDangNhap NVARCHAR(50) NOT NULL,
        HoTen NVARCHAR(100) NOT NULL,
        MatKhau NVARCHAR(200) NOT NULL,                 -- hash BCrypt
        Quyen NVARCHAR(200) NOT NULL DEFAULT 'DonHang',  -- DonHang,ThucDon,KhuyenMai,DanhGia,TaiChinh
        TrangThai BIT NOT NULL DEFAULT 1,
        NgayTao DATETIME NOT NULL DEFAULT GETDATE(),
        LanDangNhapCuoi DATETIME NULL,
        CONSTRAINT FK_NhanVienGianHang_GianHang FOREIGN KEY (MaGianHang) REFERENCES GianHang(MaGianHang)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_NhanVienGianHang_TenDangNhap')
    EXEC(N'CREATE UNIQUE INDEX IX_NhanVienGianHang_TenDangNhap ON NhanVienGianHang (TenDangNhap)');
GO


/* ############ v80 – Vận hành quán nâng cao (giờ cao điểm, món: thời gian chuẩn bị / khung giờ bán / món kèm) — chạy lặp lại an toàn ############ */
IF COL_LENGTH('GianHang', 'ToiDaDonDong') IS NULL ALTER TABLE GianHang ADD ToiDaDonDong INT NOT NULL CONSTRAINT DF_GianHang_ToiDaDonDong DEFAULT 0;
GO
IF COL_LENGTH('MonAn', 'ThoiGianChuanBiPhut') IS NULL ALTER TABLE MonAn ADD ThoiGianChuanBiPhut INT NULL;
GO
IF COL_LENGTH('MonAn', 'BanTuGio') IS NULL ALTER TABLE MonAn ADD BanTuGio TIME NULL;
GO
IF COL_LENGTH('MonAn', 'BanDenGio') IS NULL ALTER TABLE MonAn ADD BanDenGio TIME NULL;
GO
IF COL_LENGTH('MonAn', 'MonAnKem') IS NULL ALTER TABLE MonAn ADD MonAnKem NVARCHAR(500) NULL;
GO

/* ############ v68 – Sửa ràng buộc chat để quán nhắn tin được (NguoiGui thêm 'GianHang') ############ */
DECLARE @ckTinNhan sysname = (SELECT TOP 1 name FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID('TinNhan') AND definition LIKE '%NguoiGui%' AND definition NOT LIKE '%GianHang%');
IF @ckTinNhan IS NOT NULL
BEGIN
    EXEC('ALTER TABLE TinNhan DROP CONSTRAINT ' + @ckTinNhan);
    ALTER TABLE TinNhan ADD CONSTRAINT CK_TinNhan_NguoiGui CHECK (NguoiGui IN (N'KhachHang', N'TaiXe', N'GianHang'));
END
GO
GO

/* Kết thúc script. Cơ chế dừng khi CSDL tồn tại được xử lý ở đầu file bằng THROW + SQLCMD :ON ERROR EXIT. */
-- Không cần SET NOEXEC OFF: THROW + SQLCMD :ON ERROR EXIT dừng hẳn script khi CSDL đã tồn tại.
GO

GO

/* ======================= [2/9] BỔ SUNG THIẾT KẾ (BoSung_ThietKe) ======================= */
USE QuanLyDichVuAnUong;
GO
/* ============================================================
   FoodService_BoSung_ThietKe.sql
   BỔ SUNG CSDL THEO "6. Thiết kế cơ sở dữ liệu SQL"
   (Tài khoản – Khách hàng – Nhà hàng – Thực đơn – Tài xế – Đơn hàng – Giao hàng
    – Thanh toán – Khuyến mãi – Đánh giá – Thông báo – Hỗ trợ – Báo cáo)

   CÁCH CHẠY: chạy SAU FoodService_Database.sql (hoặc FoodService_NangCap.sql).
              Chạy lại nhiều lần an toàn (idempotent). KHÔNG sửa, KHÔNG xóa bảng/cột đang có.
              Chạy bằng SSMS, hoặc sqlcmd có cờ -I (bật QUOTED_IDENTIFIER cho chỉ mục có lọc).

   NGUYÊN TẮC: đề tài đã có ~55 bảng nên file này CHỈ THÊM phần còn thiếu, không tạo bảng thứ hai
   cho thứ đã có (tránh dữ liệu trùng lặp). Đối chiếu 37 bảng của đề bài ở mục 12 cuối file.

   ĐÃ CÓ SẴN (giữ nguyên, không tạo lại)          →  BẢNG MỚI TRONG FILE NÀY
   users            = TaiKhoan                         roles / permissions / user_roles
   customers        = KhachHang                          = VaiTro / Quyen (+VaiTro_Quyen) / TaiKhoan_VaiTro
   customer_addresses = DiaChiKhachHang                restaurant_branches = ChiNhanhGianHang
   restaurants      = GianHang                         restaurant_hours    = GioLamViecGianHang
   categories       = DanhMuc                          product_images      = HinhAnhMonAn
   products         = MonAn                            driver_vehicles     = PhuongTienTaiXe
   product_options  = TuyChonMon                       driver_documents    = GiayToTaiXe
   drivers          = TaiXe                            driver_locations    = LichSuViTriTaiXe
   orders / order_items = DonHang / ChiTietDonHang     delivery_assignments= PhanCongGiaoHang
   order_status_histories = LichSuTrangThaiDon         promotions          = ChuongTrinhKhuyenMai (+ _Voucher)
   deliveries       = GiaoHang                         notification_logs   = NhatKyThongBao
   payments / refunds / transactions                   support_tickets/messages = PhieuHoTro / TinNhanHoTro
     = ThanhToan / YeuCauHoanTien / GiaoDichThanhToan  settlements        = KyDoiSoat
   vouchers / voucher_usages                           restaurant_payouts  = ChiTraGianHang (+ChiTiet)
     = KhuyenMai / KhuyenMaiKhachDung                  driver_payouts      = ChiTraTaiXe (+ChiTiet)
   reviews / ratings = DanhGia / DanhGiaMon (+ 3 view điểm trung bình ở mục 10)
   notifications    = ThongBao

   LƯU Ý QUAN TRỌNG (đọc trước khi dùng):
   * Web/API hiện tại (EF Core) CHƯA biết các bảng mới. File này chỉ cung cấp lược đồ + thủ tục;
     muốn app ghi/đọc các bảng mới cần thêm entity + DbContext + sửa API (xem cuối file).
   * Vài chỗ có "bản cũ" mà app vẫn đang dùng (TaiXe.BienSo/SoCCCD/SoGPLX, PhanHoi, GianHang.GioMoCua...).
     Các thủ tục sp_DongBo... ở mục 11 nạp một chiều từ bản cũ sang bảng mới, chạy lại bao nhiêu lần cũng được.
   * KHÔNG tạo TRIGGER trên bảng đang có (EF Core lỗi khi INSERT vào bảng có trigger nếu không khai báo).
   ============================================================ */

USE QuanLyDichVuAnUong;
GO
SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

/* ============================================================
   1. TÀI KHOẢN: VaiTro, Quyen, VaiTro_Quyen, TaiKhoan_VaiTro
   Hiện trạng: TaiKhoan.VaiTro là chuỗi 1 giá trị; quyền admin là chuỗi QuanTri.QuyenChiTiet;
   quyền nhân viên quán là chuỗi NhanVienGianHang.Quyen. Bảng mới chuẩn hóa thành quan hệ nhiều-nhiều.
   (Quyền ghi đè từng người QuanTri.QuyenChiTiet vẫn do cột đó quản lý; view v_QuyenTaiKhoan là quyền theo vai trò.)
   ============================================================ */
IF OBJECT_ID('VaiTro', 'U') IS NULL
    CREATE TABLE VaiTro (
        MaVaiTro   INT IDENTITY(1,1) CONSTRAINT PK_VaiTro PRIMARY KEY,
        TenVaiTro  NVARCHAR(30)  NOT NULL CONSTRAINT UQ_VaiTro_Ten UNIQUE,
        LoaiVaiTro NVARCHAR(12)  NOT NULL CONSTRAINT DF_VaiTro_Loai DEFAULT N'TuyChinh'
                   CONSTRAINT CK_VaiTro_Loai CHECK (LoaiVaiTro IN (N'Goc', N'CapQuanTri', N'TuyChinh')),
                   -- Goc = trùng TaiKhoan.VaiTro; CapQuanTri = trùng QuanTri.CapQuyenHan; TuyChinh = tạo thêm
        MoTa       NVARCHAR(200) NULL,
        NgayTao    DATETIME      NOT NULL CONSTRAINT DF_VaiTro_NgayTao DEFAULT GETDATE()
    );
GO

IF OBJECT_ID('Quyen', 'U') IS NULL
    CREATE TABLE Quyen (
        MaQuyen   INT IDENTITY(1,1) CONSTRAINT PK_Quyen PRIMARY KEY,
        PhamVi    NVARCHAR(10)  NOT NULL CONSTRAINT CK_Quyen_PhamVi CHECK (PhamVi IN (N'QuanTri', N'GianHang')),
        KhoaQuyen NVARCHAR(40)  NOT NULL,      -- cùng khóa với code hiện tại (QuyenAdmin.cs / NhanVienGianHang.Quyen)
        TenQuyen  NVARCHAR(100) NOT NULL,
        CONSTRAINT UQ_Quyen UNIQUE (PhamVi, KhoaQuyen)
    );
GO

IF OBJECT_ID('VaiTro_Quyen', 'U') IS NULL
    CREATE TABLE VaiTro_Quyen (
        MaVaiTro INT NOT NULL CONSTRAINT FK_VaiTroQuyen_VaiTro REFERENCES VaiTro(MaVaiTro) ON DELETE CASCADE,
        MaQuyen  INT NOT NULL CONSTRAINT FK_VaiTroQuyen_Quyen  REFERENCES Quyen(MaQuyen)  ON DELETE CASCADE,
        CONSTRAINT PK_VaiTro_Quyen PRIMARY KEY (MaVaiTro, MaQuyen)
    );
GO

IF OBJECT_ID('TaiKhoan_VaiTro', 'U') IS NULL
BEGIN
    CREATE TABLE TaiKhoan_VaiTro (
        MaTK     INT NOT NULL CONSTRAINT FK_TKVaiTro_TaiKhoan REFERENCES TaiKhoan(MaTK) ON DELETE CASCADE,
        MaVaiTro INT NOT NULL CONSTRAINT FK_TKVaiTro_VaiTro   REFERENCES VaiTro(MaVaiTro),
        NgayCap  DATETIME NOT NULL CONSTRAINT DF_TKVaiTro_NgayCap DEFAULT GETDATE(),
        MaTKCap  INT NULL CONSTRAINT FK_TKVaiTro_NguoiCap REFERENCES TaiKhoan(MaTK),
        CONSTRAINT PK_TaiKhoan_VaiTro PRIMARY KEY (MaTK, MaVaiTro)
    );
    EXEC(N'CREATE INDEX IX_TKVaiTro_VaiTro ON TaiKhoan_VaiTro (MaVaiTro)');
END
GO

/* --- dữ liệu nền: vai trò + quyền (khớp code hiện tại) --- */
INSERT INTO VaiTro (TenVaiTro, LoaiVaiTro, MoTa)
SELECT v.Ten, v.Loai, v.MoTa
FROM (VALUES
    (N'KhachHang',  N'Goc',        N'Khách đặt món'),
    (N'GianHang',   N'Goc',        N'Chủ gian hàng / nhà hàng (đối tác)'),
    (N'TaiXe',      N'Goc',        N'Tài xế giao hàng'),
    (N'QuanTri',    N'Goc',        N'Quản trị viên (cấp cụ thể xem 3 vai trò bên dưới)'),
    (N'SuperAdmin', N'CapQuanTri', N'Admin tổng: mọi quyền'),
    (N'QuanLy',     N'CapQuanTri', N'Quản lý: đơn, thanh toán, hoàn tiền, đánh giá, thông báo'),
    (N'NhanVien',   N'CapQuanTri', N'Nhân viên: chỉ xem + xử lý phản hồi/sự cố (quyền thêm do Admin tổng cấp)')
) v (Ten, Loai, MoTa)
WHERE NOT EXISTS (SELECT 1 FROM VaiTro x WHERE x.TenVaiTro = v.Ten);
GO

INSERT INTO Quyen (PhamVi, KhoaQuyen, TenQuyen)
SELECT q.PhamVi, q.Khoa, q.Ten
FROM (VALUES
    (N'QuanTri',  N'DonHang',   N'Đơn hàng & điều phối'),
    (N'QuanTri',  N'ThanhToan', N'Giao dịch & đối soát'),
    (N'QuanTri',  N'HoanTien',  N'Duyệt hoàn tiền'),
    (N'QuanTri',  N'DanhGia',   N'Kiểm duyệt đánh giá'),
    (N'QuanTri',  N'ThongBao',  N'Thông báo & món ăn'),
    (N'GianHang', N'DonHang',   N'Xử lý đơn hàng'),
    (N'GianHang', N'ThucDon',   N'Quản lý thực đơn'),
    (N'GianHang', N'KhuyenMai', N'Quản lý khuyến mãi'),
    (N'GianHang', N'DanhGia',   N'Trả lời đánh giá'),
    (N'GianHang', N'TaiChinh',  N'Xem doanh thu / tài chính')
) q (PhamVi, Khoa, Ten)
WHERE NOT EXISTS (SELECT 1 FROM Quyen x WHERE x.PhamVi = q.PhamVi AND x.KhoaQuyen = q.Khoa);
GO

/* SuperAdmin + QuanLy: 5 quyền quản trị (QuyenAdmin.MacDinhQuanLy); GianHang: 5 quyền gian hàng; NhanVien: không có quyền mặc định */
INSERT INTO VaiTro_Quyen (MaVaiTro, MaQuyen)
SELECT v.MaVaiTro, q.MaQuyen
FROM VaiTro v
JOIN Quyen q ON (v.TenVaiTro IN (N'SuperAdmin', N'QuanLy') AND q.PhamVi = N'QuanTri')
             OR (v.TenVaiTro = N'GianHang' AND q.PhamVi = N'GianHang')
WHERE NOT EXISTS (SELECT 1 FROM VaiTro_Quyen x WHERE x.MaVaiTro = v.MaVaiTro AND x.MaQuyen = q.MaQuyen);
GO

/* Quyền theo vai trò của từng tài khoản (không gồm ghi đè QuanTri.QuyenChiTiet) */
CREATE OR ALTER VIEW v_QuyenTaiKhoan AS
SELECT tv.MaTK, t.TenDangNhap, v.TenVaiTro, q.PhamVi, q.KhoaQuyen, q.TenQuyen
FROM TaiKhoan_VaiTro tv
JOIN TaiKhoan  t ON t.MaTK = tv.MaTK
JOIN VaiTro    v ON v.MaVaiTro = tv.MaVaiTro
JOIN VaiTro_Quyen vq ON vq.MaVaiTro = v.MaVaiTro
JOIN Quyen     q ON q.MaQuyen = vq.MaQuyen;
GO

/* ============================================================
   2. NHÀ HÀNG: ChiNhanhGianHang (chi nhánh phụ), GioLamViecGianHang (giờ theo thứ trong tuần)
   - Trụ sở = chính bản ghi GianHang (địa chỉ, toạ độ, trạng thái đã có) -> KHÔNG chép sang bảng chi nhánh.
     View v_ChiNhanhTatCa gộp trụ sở + chi nhánh phụ.
   - Giờ mở cửa mặc định vẫn là GianHang.GioMoCua/GioDongCua; bảng mới chỉ ghi đè theo thứ/ca
     (thứ nào không có dòng nào thì dùng mặc định). View v_GioLamViecHieuLuc cho ra đủ 7 ngày/quán.
   ============================================================ */
IF OBJECT_ID('ChiNhanhGianHang', 'U') IS NULL
BEGIN
    CREATE TABLE ChiNhanhGianHang (
        MaChiNhanh  INT IDENTITY(1,1) CONSTRAINT PK_ChiNhanhGianHang PRIMARY KEY,
        MaGianHang  INT NOT NULL CONSTRAINT FK_ChiNhanh_GianHang REFERENCES GianHang(MaGianHang) ON DELETE CASCADE,
        TenChiNhanh NVARCHAR(150) NOT NULL,
        DiaChi      NVARCHAR(255) NOT NULL,
        SDT         VARCHAR(15)   NULL,
        ViDo        FLOAT NULL CONSTRAINT CK_ChiNhanh_ViDo  CHECK (ViDo  IS NULL OR ViDo  BETWEEN -90  AND 90),
        KinhDo      FLOAT NULL CONSTRAINT CK_ChiNhanh_KinhDo CHECK (KinhDo IS NULL OR KinhDo BETWEEN -180 AND 180),
        TrangThai   NVARCHAR(10)  NOT NULL CONSTRAINT DF_ChiNhanh_TrangThai DEFAULT N'DangMo'
                    CONSTRAINT CK_ChiNhanh_TrangThai CHECK (TrangThai IN (N'DangMo', N'DongCua', N'TamNgung')),
        NgayTao     DATETIME NOT NULL CONSTRAINT DF_ChiNhanh_NgayTao DEFAULT GETDATE(),
        CONSTRAINT UQ_ChiNhanh_Ten UNIQUE (MaGianHang, TenChiNhanh)
    );
    EXEC(N'CREATE INDEX IX_ChiNhanh_GianHang ON ChiNhanhGianHang (MaGianHang, TrangThai)');
END
GO

IF OBJECT_ID('GioLamViecGianHang', 'U') IS NULL
BEGIN
    CREATE TABLE GioLamViecGianHang (
        MaGio       INT IDENTITY(1,1) CONSTRAINT PK_GioLamViecGianHang PRIMARY KEY,
        MaGianHang  INT NOT NULL CONSTRAINT FK_GioLamViec_GianHang REFERENCES GianHang(MaGianHang) ON DELETE CASCADE,
        MaChiNhanh  INT NULL     CONSTRAINT FK_GioLamViec_ChiNhanh REFERENCES ChiNhanhGianHang(MaChiNhanh),
                    -- NULL = giờ của trụ sở (chính gian hàng)
        Thu         TINYINT NOT NULL CONSTRAINT CK_GioLamViec_Thu CHECK (Thu BETWEEN 1 AND 7),   -- 1 = Thứ Hai … 7 = Chủ nhật (cùng quy ước TaiXe.NgayThanhToanThu)
        GioMo       TIME(0) NULL,
        GioDong     TIME(0) NULL,                 -- GioDong < GioMo = quán qua nửa đêm (vd 18:00 → 02:00)
        NghiCaNgay  BIT NOT NULL CONSTRAINT DF_GioLamViec_Nghi DEFAULT 0,
        CONSTRAINT CK_GioLamViec_Gio CHECK (NghiCaNgay = 1 OR (GioMo IS NOT NULL AND GioDong IS NOT NULL AND GioMo <> GioDong)),
        CONSTRAINT UQ_GioLamViec UNIQUE (MaGianHang, MaChiNhanh, Thu, GioMo)
    );
    EXEC(N'CREATE INDEX IX_GioLamViec_GianHang ON GioLamViecGianHang (MaGianHang, Thu)');
END
GO

CREATE OR ALTER VIEW v_ChiNhanhTatCa AS
SELECT g.MaGianHang, CAST(NULL AS INT) AS MaChiNhanh, g.TenCuaHang AS TenChiNhanh, g.DiaChi, g.SDT,
       g.ViDo, g.KinhDo, CAST(1 AS BIT) AS LaTruSo, g.TrangThaiKinhDoanh AS TrangThai
FROM GianHang g
UNION ALL
SELECT c.MaGianHang, c.MaChiNhanh, c.TenChiNhanh, c.DiaChi, c.SDT,
       c.ViDo, c.KinhDo, CAST(0 AS BIT), c.TrangThai
FROM ChiNhanhGianHang c;
GO

CREATE OR ALTER VIEW v_GioLamViecHieuLuc AS    -- giờ của TRỤ SỞ, đủ 7 thứ cho mọi gian hàng
SELECT g.MaGianHang, d.Thu, h.GioMo, h.GioDong, h.NghiCaNgay, CAST(N'Lich' AS NVARCHAR(10)) AS Nguon
FROM GianHang g
CROSS JOIN (VALUES (1),(2),(3),(4),(5),(6),(7)) d (Thu)
JOIN GioLamViecGianHang h ON h.MaGianHang = g.MaGianHang AND h.MaChiNhanh IS NULL AND h.Thu = d.Thu
UNION ALL
SELECT g.MaGianHang, d.Thu, g.GioMoCua, g.GioDongCua, CAST(0 AS BIT), N'MacDinh'
FROM GianHang g
CROSS JOIN (VALUES (1),(2),(3),(4),(5),(6),(7)) d (Thu)
WHERE NOT EXISTS (SELECT 1 FROM GioLamViecGianHang h WHERE h.MaGianHang = g.MaGianHang AND h.MaChiNhanh IS NULL AND h.Thu = d.Thu);
GO

/* ============================================================
   3. THỰC ĐƠN: HinhAnhMonAn (thư viện ảnh phụ)
   Ảnh đại diện vẫn là MonAn.HinhAnh (không chép lại). View v_HinhAnhMon gộp cả hai.
   ============================================================ */
IF OBJECT_ID('HinhAnhMonAn', 'U') IS NULL
BEGIN
    CREATE TABLE HinhAnhMonAn (
        MaHinhAnh INT IDENTITY(1,1) CONSTRAINT PK_HinhAnhMonAn PRIMARY KEY,
        MaMonAn   INT NOT NULL CONSTRAINT FK_HinhAnhMon_MonAn REFERENCES MonAn(MaMonAn) ON DELETE CASCADE,
        DuongDan  NVARCHAR(500) NOT NULL,
        ChuThich  NVARCHAR(200) NULL,
        ThuTu     INT NOT NULL CONSTRAINT DF_HinhAnhMon_ThuTu DEFAULT 0,
        NgayTao   DATETIME NOT NULL CONSTRAINT DF_HinhAnhMon_NgayTao DEFAULT GETDATE()
    );
    EXEC(N'CREATE INDEX IX_HinhAnhMon_Mon ON HinhAnhMonAn (MaMonAn, ThuTu)');
END
GO

CREATE OR ALTER VIEW v_HinhAnhMon AS
SELECT m.MaMonAn, CAST(NULL AS INT) AS MaHinhAnh, m.HinhAnh AS DuongDan, CAST(1 AS BIT) AS LaAnhChinh, 0 AS ThuTu
FROM MonAn m WHERE m.HinhAnh IS NOT NULL AND m.HinhAnh <> N''
UNION ALL
SELECT h.MaMonAn, h.MaHinhAnh, h.DuongDan, CAST(0 AS BIT), h.ThuTu
FROM HinhAnhMonAn h;
GO

/* ============================================================
   4. TÀI XẾ: PhuongTienTaiXe, GiayToTaiXe, LichSuViTriTaiXe
   TaiXe.PhuongTien/BienSo/SoCCCD/SoGPLX/AnhGPLX là bản cũ app đang dùng; mục 11 nạp một chiều sang bảng mới.
   TaiXeViTri (có sẵn) chỉ giữ vị trí MỚI NHẤT THEO ĐƠN; LichSuViTriTaiXe giữ lịch sử theo tài xế (kể cả lúc rảnh).
   ============================================================ */
IF OBJECT_ID('PhuongTienTaiXe', 'U') IS NULL
BEGIN
    CREATE TABLE PhuongTienTaiXe (
        MaPhuongTien INT IDENTITY(1,1) CONSTRAINT PK_PhuongTienTaiXe PRIMARY KEY,
        MaTaiXe      INT NOT NULL CONSTRAINT FK_PhuongTien_TaiXe REFERENCES TaiXe(MaTaiXe) ON DELETE CASCADE,
        LoaiXe       NVARCHAR(50) NOT NULL CONSTRAINT DF_PhuongTien_Loai DEFAULT N'Xe máy',
        BienSo       VARCHAR(20)  NOT NULL,
        HangXe       NVARCHAR(50) NULL,
        DongXe       NVARCHAR(50) NULL,
        MauSac       NVARCHAR(30) NULL,
        NamSanXuat   SMALLINT NULL CONSTRAINT CK_PhuongTien_Nam CHECK (NamSanXuat IS NULL OR NamSanXuat BETWEEN 1980 AND 2100),
        LaXeChinh    BIT NOT NULL CONSTRAINT DF_PhuongTien_Chinh DEFAULT 0,
        TrangThai    NVARCHAR(12) NOT NULL CONSTRAINT DF_PhuongTien_TrangThai DEFAULT N'HoatDong'
                     CONSTRAINT CK_PhuongTien_TrangThai CHECK (TrangThai IN (N'HoatDong', N'NgungSuDung')),
        NgayTao      DATETIME NOT NULL CONSTRAINT DF_PhuongTien_NgayTao DEFAULT GETDATE()
    );
    EXEC(N'CREATE INDEX IX_PhuongTien_TaiXe  ON PhuongTienTaiXe (MaTaiXe)');
    EXEC(N'CREATE INDEX IX_PhuongTien_BienSo ON PhuongTienTaiXe (BienSo)');
    EXEC(N'CREATE UNIQUE INDEX UX_PhuongTien_XeChinh ON PhuongTienTaiXe (MaTaiXe) WHERE LaXeChinh = 1'); -- mỗi tài xế tối đa 1 xe chính
END
GO

IF OBJECT_ID('GiayToTaiXe', 'U') IS NULL
BEGIN
    CREATE TABLE GiayToTaiXe (
        MaGiayTo       INT IDENTITY(1,1) CONSTRAINT PK_GiayToTaiXe PRIMARY KEY,
        MaTaiXe        INT NOT NULL CONSTRAINT FK_GiayTo_TaiXe REFERENCES TaiXe(MaTaiXe) ON DELETE CASCADE,
        LoaiGiayTo     NVARCHAR(20) NOT NULL
                       CONSTRAINT CK_GiayTo_Loai CHECK (LoaiGiayTo IN (N'CCCD', N'GPLX', N'DangKyXe', N'BaoHiem', N'LyLichTuPhap', N'KhamSucKhoe', N'Khac')),
        SoGiayTo       VARCHAR(30)  NULL,
        NgayCap        DATE NULL,
        NgayHetHan     DATE NULL,
        DuongDanAnh    NVARCHAR(500) NULL,        -- nên là tệp RIÊNG TƯ (TepTin.RiengTu = 1)
        TrangThaiDuyet NVARCHAR(10) NOT NULL CONSTRAINT DF_GiayTo_Duyet DEFAULT N'ChoDuyet'
                       CONSTRAINT CK_GiayTo_Duyet CHECK (TrangThaiDuyet IN (N'ChoDuyet', N'DaDuyet', N'TuChoi')),
        LyDoTuChoi     NVARCHAR(255) NULL,
        MaTKDuyet      INT NULL CONSTRAINT FK_GiayTo_NguoiDuyet REFERENCES TaiKhoan(MaTK),
        NgayDuyet      DATETIME NULL,
        NgayTao        DATETIME NOT NULL CONSTRAINT DF_GiayTo_NgayTao DEFAULT GETDATE(),
        CONSTRAINT CK_GiayTo_HanDung CHECK (NgayHetHan IS NULL OR NgayCap IS NULL OR NgayHetHan >= NgayCap)
    );
    EXEC(N'CREATE INDEX IX_GiayTo_TaiXe ON GiayToTaiXe (MaTaiXe, LoaiGiayTo)');
    EXEC(N'CREATE INDEX IX_GiayTo_HetHan ON GiayToTaiXe (NgayHetHan) WHERE NgayHetHan IS NOT NULL');
END
GO

IF OBJECT_ID('LichSuViTriTaiXe', 'U') IS NULL
BEGIN
    CREATE TABLE LichSuViTriTaiXe (
        MaViTri     BIGINT IDENTITY(1,1) CONSTRAINT PK_LichSuViTriTaiXe PRIMARY KEY,
        MaTaiXe     INT NOT NULL CONSTRAINT FK_ViTriTX_TaiXe REFERENCES TaiXe(MaTaiXe) ON DELETE CASCADE,
        MaDonHang   INT NULL CONSTRAINT FK_ViTriTX_Don REFERENCES DonHang(MaDonHang) ON DELETE SET NULL,
        ViDo        FLOAT NOT NULL CONSTRAINT CK_ViTriTX_ViDo   CHECK (ViDo   BETWEEN -90  AND 90),
        KinhDo      FLOAT NOT NULL CONSTRAINT CK_ViTriTX_KinhDo CHECK (KinhDo BETWEEN -180 AND 180),
        DoChinhXacM FLOAT NULL,
        TocDoKmh    FLOAT NULL,
        ThoiGian    DATETIME2(3) NOT NULL CONSTRAINT DF_ViTriTX_ThoiGian DEFAULT SYSDATETIME()
    );
    EXEC(N'CREATE INDEX IX_ViTriTX_TaiXe ON LichSuViTriTaiXe (MaTaiXe, ThoiGian DESC) INCLUDE (ViDo, KinhDo)');
    EXEC(N'CREATE INDEX IX_ViTriTX_Don   ON LichSuViTriTaiXe (MaDonHang, ThoiGian) WHERE MaDonHang IS NOT NULL');
END
GO

CREATE OR ALTER VIEW v_ViTriTaiXeMoiNhat AS
SELECT x.MaTaiXe, x.ViDo, x.KinhDo, x.TocDoKmh, x.MaDonHang, x.ThoiGian
FROM (SELECT l.MaTaiXe, l.ViDo, l.KinhDo, l.TocDoKmh, l.MaDonHang, l.ThoiGian,
             ROW_NUMBER() OVER (PARTITION BY l.MaTaiXe ORDER BY l.ThoiGian DESC, l.MaViTri DESC) AS rn
      FROM LichSuViTriTaiXe l) x
WHERE x.rn = 1;
GO

CREATE OR ALTER PROCEDURE sp_GhiViTriTaiXe
    @MaTaiXe INT, @ViDo FLOAT, @KinhDo FLOAT,
    @MaDonHang INT = NULL, @TocDoKmh FLOAT = NULL, @DoChinhXacM FLOAT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO LichSuViTriTaiXe (MaTaiXe, MaDonHang, ViDo, KinhDo, TocDoKmh, DoChinhXacM)
    VALUES (@MaTaiXe, @MaDonHang, @ViDo, @KinhDo, @TocDoKmh, @DoChinhXacM);
END;
GO

CREATE OR ALTER PROCEDURE sp_DonDepViTriTaiXe @GiuNgay INT = 30   -- xóa theo lô để không khóa bảng lâu; gọi trong job đêm cùng sp_DonDepDuLieu
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @han DATETIME2(3) = DATEADD(DAY, -@GiuNgay, SYSDATETIME());
    WHILE 1 = 1
    BEGIN
        DELETE TOP (5000) FROM LichSuViTriTaiXe WHERE ThoiGian < @han;
        IF @@ROWCOUNT = 0 BREAK;
    END
END;
GO

/* ============================================================
   5. GIAO HÀNG: PhanCongGiaoHang — lịch sử đề nghị/nhận/từ chối/gỡ tài xế cho từng đơn
   GiaoHang (1 dòng/đơn) vẫn là chuyến đang hiệu lực; DieuPhoiLog + TaiXeTuChoiDon được nạp sang đây ở mục 11.
   Ràng buộc: mỗi đơn chỉ có tối đa MỘT phân công đang ở trạng thái DaNhan.
   ============================================================ */
IF OBJECT_ID('PhanCongGiaoHang', 'U') IS NULL
BEGIN
    CREATE TABLE PhanCongGiaoHang (
        MaPhanCong    BIGINT IDENTITY(1,1) CONSTRAINT PK_PhanCongGiaoHang PRIMARY KEY,
        MaDonHang     INT NOT NULL CONSTRAINT FK_PhanCong_Don    REFERENCES DonHang(MaDonHang) ON DELETE CASCADE,
        MaTaiXe       INT NOT NULL CONSTRAINT FK_PhanCong_TaiXe  REFERENCES TaiXe(MaTaiXe),
        HinhThuc      NVARCHAR(10) NOT NULL CONSTRAINT DF_PhanCong_HinhThuc DEFAULT N'TuNhan'
                      CONSTRAINT CK_PhanCong_HinhThuc CHECK (HinhThuc IN (N'TuNhan', N'QuanTri', N'TuDong')),
        TrangThai     NVARCHAR(12) NOT NULL CONSTRAINT DF_PhanCong_TrangThai DEFAULT N'DeNghi'
                      CONSTRAINT CK_PhanCong_TrangThai CHECK (TrangThai IN (N'DeNghi', N'DaNhan', N'TuChoi', N'HetHan', N'DaGo', N'HoanThanh')),
        LyDo          NVARCHAR(300) NULL,
        MaTKPhanCong  INT NULL CONSTRAINT FK_PhanCong_NguoiPhanCong REFERENCES TaiKhoan(MaTK),
        NgayDeNghi    DATETIME NOT NULL CONSTRAINT DF_PhanCong_NgayDeNghi DEFAULT GETDATE(),
        HanPhanHoi    DATETIME NULL,
        NgayPhanHoi   DATETIME NULL
    );
    EXEC(N'CREATE INDEX IX_PhanCong_Don   ON PhanCongGiaoHang (MaDonHang, NgayDeNghi)');
    EXEC(N'CREATE INDEX IX_PhanCong_TaiXe ON PhanCongGiaoHang (MaTaiXe, TrangThai, NgayDeNghi)');
    EXEC(N'CREATE UNIQUE INDEX UX_PhanCong_DangGiu ON PhanCongGiaoHang (MaDonHang) WHERE TrangThai = N''DaNhan''');
END
GO

/* ============================================================
   6. KHUYẾN MÃI: ChuongTrinhKhuyenMai (chiến dịch) gom nhiều voucher (KhuyenMai)
   KhuyenMai = voucher/mã giảm giá; KhuyenMaiKhachDung = lượt dùng (đã có). Banner/ChienDichQuangCao (đã có) là quảng bá, không phải giảm giá.
   ============================================================ */
IF OBJECT_ID('ChuongTrinhKhuyenMai', 'U') IS NULL
    CREATE TABLE ChuongTrinhKhuyenMai (
        MaChuongTrinh INT IDENTITY(1,1) CONSTRAINT PK_ChuongTrinhKhuyenMai PRIMARY KEY,
        TenChuongTrinh NVARCHAR(150) NOT NULL,
        MoTa          NVARCHAR(500) NULL,
        Loai          NVARCHAR(10) NOT NULL CONSTRAINT DF_CTKM_Loai DEFAULT N'NenTang'
                      CONSTRAINT CK_CTKM_Loai CHECK (Loai IN (N'NenTang', N'GianHang', N'FlashSale', N'SuKien')),
        MaGianHang    INT NULL CONSTRAINT FK_CTKM_GianHang REFERENCES GianHang(MaGianHang),   -- bắt buộc khi Loai = GianHang
        NgayBatDau    DATETIME NOT NULL,
        NgayKetThuc   DATETIME NOT NULL,
        NganSach      DECIMAL(14,0) NULL CONSTRAINT CK_CTKM_NganSach CHECK (NganSach IS NULL OR NganSach >= 0),
        TrangThai     NVARCHAR(10) NOT NULL CONSTRAINT DF_CTKM_TrangThai DEFAULT N'BanNhap'
                      CONSTRAINT CK_CTKM_TrangThai CHECK (TrangThai IN (N'BanNhap', N'DangChay', N'TamDung', N'KetThuc')),
        HinhAnh       NVARCHAR(500) NULL,
        MaTKTao       INT NULL CONSTRAINT FK_CTKM_NguoiTao REFERENCES TaiKhoan(MaTK),
        NgayTao       DATETIME NOT NULL CONSTRAINT DF_CTKM_NgayTao DEFAULT GETDATE(),
        CONSTRAINT CK_CTKM_ThoiGian CHECK (NgayKetThuc > NgayBatDau),
        CONSTRAINT CK_CTKM_GianHang CHECK (Loai <> N'GianHang' OR MaGianHang IS NOT NULL)
    );
GO

IF OBJECT_ID('ChuongTrinhKhuyenMai_Voucher', 'U') IS NULL
    CREATE TABLE ChuongTrinhKhuyenMai_Voucher (
        MaChuongTrinh INT NOT NULL CONSTRAINT FK_CTKMV_ChuongTrinh REFERENCES ChuongTrinhKhuyenMai(MaChuongTrinh) ON DELETE CASCADE,
        MaKhuyenMai   INT NOT NULL CONSTRAINT FK_CTKMV_KhuyenMai   REFERENCES KhuyenMai(MaKhuyenMai) ON DELETE CASCADE,
        CONSTRAINT PK_CTKM_Voucher PRIMARY KEY (MaChuongTrinh, MaKhuyenMai)
    );
GO

/* ============================================================
   7. THÔNG BÁO: NhatKyThongBao — mỗi lần gửi (push/email/sms) một ThongBao và kết quả
   ThongBao (đã có) = nội dung hiển thị trong app; bảng này = nhật ký gửi qua từng kênh.
   ============================================================ */
IF OBJECT_ID('NhatKyThongBao', 'U') IS NULL
BEGIN
    CREATE TABLE NhatKyThongBao (
        MaNhatKy     BIGINT IDENTITY(1,1) CONSTRAINT PK_NhatKyThongBao PRIMARY KEY,
        MaThongBao   BIGINT NOT NULL CONSTRAINT FK_NhatKyTB_ThongBao REFERENCES ThongBao(MaThongBao) ON DELETE CASCADE,
        Kenh         VARCHAR(10) NOT NULL CONSTRAINT CK_NhatKyTB_Kenh CHECK (Kenh IN ('push', 'email', 'sms', 'inapp')),
        NguoiNhan    NVARCHAR(300) NULL,                     -- email / SĐT / token thiết bị (đã rút gọn nếu cần)
        TrangThai    NVARCHAR(10) NOT NULL CONSTRAINT DF_NhatKyTB_TrangThai DEFAULT N'ChoGui'
                     CONSTRAINT CK_NhatKyTB_TrangThai CHECK (TrangThai IN (N'ChoGui', N'DaGui', N'DaNhan', N'ThatBai')),
        SoLanThu     INT NOT NULL CONSTRAINT DF_NhatKyTB_SoLan DEFAULT 0,
        MaPhanHoiNCC NVARCHAR(100) NULL,                     -- id tin nhắn của nhà cung cấp (FCM, SMS gateway...)
        ThongDiepLoi NVARCHAR(500) NULL,
        NgayTao      DATETIME NOT NULL CONSTRAINT DF_NhatKyTB_NgayTao DEFAULT GETDATE(),
        NgayGui      DATETIME NULL
    );
    EXEC(N'CREATE INDEX IX_NhatKyTB_ThongBao ON NhatKyThongBao (MaThongBao)');
    EXEC(N'CREATE INDEX IX_NhatKyTB_TrangThai ON NhatKyThongBao (TrangThai, NgayTao) WHERE TrangThai <> N''DaGui'' AND TrangThai <> N''DaNhan'''); -- = ChoGui + ThatBai (để job gửi lại quét nhanh)
END
GO

/* ============================================================
   8. HỖ TRỢ: PhieuHoTro (phiếu) + TinNhanHoTro (hội thoại trong phiếu)
   PhanHoi (đã có) là 1 lần góp ý/khiếu nại của KHÁCH có đúng 1 câu trả lời. Phiếu mới: mọi vai trò mở được,
   nhiều lượt trao đổi, có ưu tiên + người phụ trách. Cột MaPhanHoi nối phiếu với phản hồi cũ (nạp ở mục 11).
   (Khác TinNhan: đó là chat khách–tài xế–quán theo đơn.)
   ============================================================ */
IF OBJECT_ID('PhieuHoTro', 'U') IS NULL
BEGIN
    CREATE TABLE PhieuHoTro (
        MaPhieu        INT IDENTITY(1,1) CONSTRAINT PK_PhieuHoTro PRIMARY KEY,
        MaTKNguoiGui   INT NOT NULL CONSTRAINT FK_PhieuHoTro_NguoiGui REFERENCES TaiKhoan(MaTK),
        VaiTroNguoiGui NVARCHAR(10) NOT NULL CONSTRAINT CK_PhieuHoTro_VaiTro CHECK (VaiTroNguoiGui IN (N'KhachHang', N'GianHang', N'TaiXe')),
        MaDonHang      INT NULL CONSTRAINT FK_PhieuHoTro_Don REFERENCES DonHang(MaDonHang),
        MaGianHang     INT NULL CONSTRAINT FK_PhieuHoTro_GianHang REFERENCES GianHang(MaGianHang),
        PhanLoai       NVARCHAR(30) NULL,        -- DonHang | MonAn | TaiXe | GianHang | ThanhToan | TaiKhoan | Khac (cùng PhanHoi.PhanLoai)
        Loai           NVARCHAR(10) NOT NULL CONSTRAINT DF_PhieuHoTro_Loai DEFAULT N'HoTro'
                       CONSTRAINT CK_PhieuHoTro_Loai CHECK (Loai IN (N'HoTro', N'GopY', N'KhieuNai', N'Khac')),
        TieuDe         NVARCHAR(150) NOT NULL,
        TrangThai      NVARCHAR(10) NOT NULL CONSTRAINT DF_PhieuHoTro_TrangThai DEFAULT N'ChuaXuLy'
                       CONSTRAINT CK_PhieuHoTro_TrangThai CHECK (TrangThai IN (N'ChuaXuLy', N'DangXuLy', N'DaXuLy', N'Dong')),
        UuTien         NVARCHAR(10) NOT NULL CONSTRAINT DF_PhieuHoTro_UuTien DEFAULT N'TrungBinh'
                       CONSTRAINT CK_PhieuHoTro_UuTien CHECK (UuTien IN (N'Thap', N'TrungBinh', N'Cao', N'Khan')),
        MaTKPhuTrach   INT NULL CONSTRAINT FK_PhieuHoTro_PhuTrach REFERENCES TaiKhoan(MaTK),
        MaPhanHoi      INT NULL CONSTRAINT FK_PhieuHoTro_PhanHoi REFERENCES PhanHoi(MaPhanHoi),
        NgayTao        DATETIME NOT NULL CONSTRAINT DF_PhieuHoTro_NgayTao DEFAULT GETDATE(),
        NgayCapNhat    DATETIME NOT NULL CONSTRAINT DF_PhieuHoTro_NgayCN DEFAULT GETDATE(),
        NgayDong       DATETIME NULL
    );
    EXEC(N'CREATE INDEX IX_PhieuHoTro_NguoiGui ON PhieuHoTro (MaTKNguoiGui, NgayTao DESC)');
    EXEC(N'CREATE INDEX IX_PhieuHoTro_XuLy     ON PhieuHoTro (TrangThai, UuTien, NgayTao) INCLUDE (MaTKPhuTrach)');
    EXEC(N'CREATE INDEX IX_PhieuHoTro_Don      ON PhieuHoTro (MaDonHang) WHERE MaDonHang IS NOT NULL');
    EXEC(N'CREATE UNIQUE INDEX UX_PhieuHoTro_PhanHoi ON PhieuHoTro (MaPhanHoi) WHERE MaPhanHoi IS NOT NULL');
END
GO

IF OBJECT_ID('TinNhanHoTro', 'U') IS NULL
BEGIN
    CREATE TABLE TinNhanHoTro (
        MaTinNhan      BIGINT IDENTITY(1,1) CONSTRAINT PK_TinNhanHoTro PRIMARY KEY,
        MaPhieu        INT NOT NULL CONSTRAINT FK_TinNhanHoTro_Phieu REFERENCES PhieuHoTro(MaPhieu) ON DELETE CASCADE,
        MaTKGui        INT NULL CONSTRAINT FK_TinNhanHoTro_NguoiGui REFERENCES TaiKhoan(MaTK),    -- NULL = hệ thống
        VaiTroGui      NVARCHAR(10) NOT NULL CONSTRAINT CK_TinNhanHoTro_VaiTro CHECK (VaiTroGui IN (N'KhachHang', N'GianHang', N'TaiXe', N'QuanTri', N'HeThong')),
        NoiDung        NVARCHAR(2000) NOT NULL,
        TepDinhKem     NVARCHAR(500) NULL,
        LaGhiChuNoiBo  BIT NOT NULL CONSTRAINT DF_TinNhanHoTro_NoiBo DEFAULT 0,     -- 1 = chỉ nhân viên thấy
        NgayGui        DATETIME NOT NULL CONSTRAINT DF_TinNhanHoTro_NgayGui DEFAULT GETDATE()
    );
    EXEC(N'CREATE INDEX IX_TinNhanHoTro_Phieu ON TinNhanHoTro (MaPhieu, NgayGui)');
END
GO

/* ============================================================
   9. BÁO CÁO / ĐỐI SOÁT
   KyDoiSoat 1 ─ n ChiTraGianHang 1 ─ n ChiTietChiTraGianHang (mỗi đơn chỉ thuộc MỘT khoản chi: PK = MaDonHang)
              └─ n ChiTraTaiXe    1 ─ n ChiTietChiTraTaiXe    (mỗi chuyến / điều chỉnh chỉ thuộc MỘT khoản chi)
   Công thức khớp báo cáo hiện tại (AdminMobileNoiDungApiController / DriverThuNhapApi):
     Quán:   tiền hàng = TongTien − PhiGiaoHang;  phí nền tảng = tiền hàng × GianHang.TyLeChietKhau;  phải trả = tiền hàng − phí.
     Tài xế: phí giao (DonHang.PhiGiaoHang) của chuyến GiaoThanhCong, hoặc GiaoThatBai có TinhPhiThatBai; cộng thưởng/phụ cấp/phạt
             từ DieuChinhThuNhap (đang ChoThanhToan). Tiền COD chưa nộp chỉ để THAM KHẢO, không trừ vào khoản chi.
   Khi đánh dấu đã chi, thủ tục cập nhật luôn cờ cũ (DonHang.QuanDaTraLuc, GiaoHang.TrangThaiThuNhap, DieuChinhThuNhap.TrangThai)
   để các màn hình hiện có vẫn đúng.
   ============================================================ */
IF OBJECT_ID('KyDoiSoat', 'U') IS NULL
    CREATE TABLE KyDoiSoat (
        MaKy              INT IDENTITY(1,1) CONSTRAINT PK_KyDoiSoat PRIMARY KEY,
        TenKy             NVARCHAR(100) NOT NULL,
        TuNgay            DATE NOT NULL,
        DenNgay           DATE NOT NULL,
        TrangThai         NVARCHAR(10) NOT NULL CONSTRAINT DF_KyDoiSoat_TrangThai DEFAULT N'BanNhap'
                          CONSTRAINT CK_KyDoiSoat_TrangThai CHECK (TrangThai IN (N'BanNhap', N'DaChot', N'DangChi', N'HoanTat', N'Huy')),
        TongSoDon         INT NOT NULL CONSTRAINT DF_KyDoiSoat_SoDon DEFAULT 0,
        TongTienHang      DECIMAL(14,0) NOT NULL CONSTRAINT DF_KyDoiSoat_TienHang DEFAULT 0,
        TongPhiNenTang    DECIMAL(14,0) NOT NULL CONSTRAINT DF_KyDoiSoat_Phi DEFAULT 0,
        TongPhaiTraQuan   DECIMAL(14,0) NOT NULL CONSTRAINT DF_KyDoiSoat_TraQuan DEFAULT 0,
        TongPhaiTraTaiXe  DECIMAL(14,0) NOT NULL CONSTRAINT DF_KyDoiSoat_TraTX DEFAULT 0,
        GhiChu            NVARCHAR(300) NULL,
        MaTKTao           INT NULL CONSTRAINT FK_KyDoiSoat_NguoiTao REFERENCES TaiKhoan(MaTK),
        NgayTao           DATETIME NOT NULL CONSTRAINT DF_KyDoiSoat_NgayTao DEFAULT GETDATE(),
        NgayChot          DATETIME NULL,
        CONSTRAINT CK_KyDoiSoat_Ngay CHECK (DenNgay >= TuNgay)
    );
GO

IF OBJECT_ID('ChiTraGianHang', 'U') IS NULL
BEGIN
    CREATE TABLE ChiTraGianHang (
        MaChiTraQuan       INT IDENTITY(1,1) CONSTRAINT PK_ChiTraGianHang PRIMARY KEY,
        MaKy               INT NOT NULL CONSTRAINT FK_ChiTraQuan_Ky REFERENCES KyDoiSoat(MaKy),
        MaGianHang         INT NOT NULL CONSTRAINT FK_ChiTraQuan_GianHang REFERENCES GianHang(MaGianHang),
        SoDon              INT NOT NULL CONSTRAINT DF_ChiTraQuan_SoDon DEFAULT 0,
        TienHang           DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraQuan_TienHang DEFAULT 0,
        TyLeChietKhau      DECIMAL(5,4) NOT NULL CONSTRAINT DF_ChiTraQuan_Ty DEFAULT 0,      -- tỷ lệ tại lúc chốt (lưu lại để đối chiếu sau này)
        PhiNenTang         DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraQuan_Phi DEFAULT 0,
        DieuChinh          DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraQuan_DieuChinh DEFAULT 0,   -- dương = cộng thêm, âm = trừ (sửa tay trước khi chi)
        SoTienChiTra       DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraQuan_SoTien DEFAULT 0,
        TrangThai          NVARCHAR(8) NOT NULL CONSTRAINT DF_ChiTraQuan_TrangThai DEFAULT N'ChoChi'
                           CONSTRAINT CK_ChiTraQuan_TrangThai CHECK (TrangThai IN (N'ChoChi', N'DaChi', N'Loi', N'Huy')),
        PhuongThuc         NVARCHAR(15) NULL CONSTRAINT CK_ChiTraQuan_PhuongThuc CHECK (PhuongThuc IS NULL OR PhuongThuc IN (N'ChuyenKhoan', N'TienMat', N'ViDienTu', N'Khac')),
        MaGiaoDichNganHang NVARCHAR(100) NULL,
        GhiChu             NVARCHAR(300) NULL,
        MaTKChi            INT NULL CONSTRAINT FK_ChiTraQuan_NguoiChi REFERENCES TaiKhoan(MaTK),
        NgayTao            DATETIME NOT NULL CONSTRAINT DF_ChiTraQuan_NgayTao DEFAULT GETDATE(),
        NgayChi            DATETIME NULL,
        CONSTRAINT UQ_ChiTraQuan UNIQUE (MaKy, MaGianHang)
    );
    EXEC(N'CREATE INDEX IX_ChiTraQuan_GianHang ON ChiTraGianHang (MaGianHang, TrangThai)');
END
GO

IF OBJECT_ID('ChiTietChiTraGianHang', 'U') IS NULL
    CREATE TABLE ChiTietChiTraGianHang (
        MaDonHang    INT NOT NULL CONSTRAINT PK_ChiTietChiTraGianHang PRIMARY KEY CONSTRAINT FK_CTCTQuan_Don REFERENCES DonHang(MaDonHang),
        MaChiTraQuan INT NOT NULL CONSTRAINT FK_CTCTQuan_ChiTra REFERENCES ChiTraGianHang(MaChiTraQuan) ON DELETE CASCADE,
        TienHang     DECIMAL(14,0) NOT NULL,
        PhiNenTang   DECIMAL(14,0) NOT NULL
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CTCTQuan_ChiTra' AND object_id = OBJECT_ID('ChiTietChiTraGianHang'))
    EXEC(N'CREATE INDEX IX_CTCTQuan_ChiTra ON ChiTietChiTraGianHang (MaChiTraQuan)');
GO

IF OBJECT_ID('ChiTraTaiXe', 'U') IS NULL
BEGIN
    CREATE TABLE ChiTraTaiXe (
        MaChiTraTX         INT IDENTITY(1,1) CONSTRAINT PK_ChiTraTaiXe PRIMARY KEY,
        MaKy               INT NOT NULL CONSTRAINT FK_ChiTraTX_Ky REFERENCES KyDoiSoat(MaKy),
        MaTaiXe            INT NOT NULL CONSTRAINT FK_ChiTraTX_TaiXe REFERENCES TaiXe(MaTaiXe),
        SoChuyen           INT NOT NULL CONSTRAINT DF_ChiTraTX_SoChuyen DEFAULT 0,
        TienPhiGiao        DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraTX_PhiGiao DEFAULT 0,
        TienDieuChinh      DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraTX_DieuChinh DEFAULT 0,   -- thưởng/phụ cấp (+) và phạt/khấu trừ (−) từ DieuChinhThuNhap
        TienCODChuaNop     DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraTX_COD DEFAULT 0,         -- tham khảo: COD đã thu trong kỳ nhưng chưa nộp
        SoTienChiTra       DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraTX_SoTien DEFAULT 0,      -- = phí giao + điều chỉnh; có thể ÂM (khấu trừ vượt thu nhập)
        TrangThai          NVARCHAR(8) NOT NULL CONSTRAINT DF_ChiTraTX_TrangThai DEFAULT N'ChoChi'
                           CONSTRAINT CK_ChiTraTX_TrangThai CHECK (TrangThai IN (N'ChoChi', N'DaChi', N'Loi', N'Huy')),
        PhuongThuc         NVARCHAR(15) NULL CONSTRAINT CK_ChiTraTX_PhuongThuc CHECK (PhuongThuc IS NULL OR PhuongThuc IN (N'ChuyenKhoan', N'TienMat', N'ViDienTu', N'Khac')),
        MaGiaoDichNganHang NVARCHAR(100) NULL,
        GhiChu             NVARCHAR(300) NULL,
        MaTKChi            INT NULL CONSTRAINT FK_ChiTraTX_NguoiChi REFERENCES TaiKhoan(MaTK),
        NgayTao            DATETIME NOT NULL CONSTRAINT DF_ChiTraTX_NgayTao DEFAULT GETDATE(),
        NgayChi            DATETIME NULL,
        CONSTRAINT UQ_ChiTraTX UNIQUE (MaKy, MaTaiXe)
    );
    EXEC(N'CREATE INDEX IX_ChiTraTX_TaiXe ON ChiTraTaiXe (MaTaiXe, TrangThai)');
END
GO

IF OBJECT_ID('ChiTietChiTraTaiXe', 'U') IS NULL
    CREATE TABLE ChiTietChiTraTaiXe (
        Loai        NVARCHAR(10) NOT NULL CONSTRAINT CK_CTCTTX_Loai CHECK (Loai IN (N'Chuyen', N'DieuChinh')),   -- Chuyen -> GiaoHang.MaGiaoHang; DieuChinh -> DieuChinhThuNhap.MaDieuChinh
        MaThamChieu INT NOT NULL,
        MaChiTraTX  INT NOT NULL CONSTRAINT FK_CTCTTX_ChiTra REFERENCES ChiTraTaiXe(MaChiTraTX) ON DELETE CASCADE,
        SoTien      DECIMAL(14,0) NOT NULL,
        CONSTRAINT PK_ChiTietChiTraTaiXe PRIMARY KEY (Loai, MaThamChieu)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CTCTTX_ChiTra' AND object_id = OBJECT_ID('ChiTietChiTraTaiXe'))
    EXEC(N'CREATE INDEX IX_CTCTTX_ChiTra ON ChiTietChiTraTaiXe (MaChiTraTX)');
GO

/* ---- 9.1 Tạo kỳ đối soát: gom đơn/chuyến CHƯA chi trong khoảng ngày giao ---- */
CREATE OR ALTER PROCEDURE sp_TaoKyDoiSoat
    @TuNgay DATE, @DenNgay DATE, @MaTK INT = NULL, @TenKy NVARCHAR(100) = NULL, @MaKy INT = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF @DenNgay < @TuNgay THROW 50101, N'Ngày kết thúc phải sau hoặc bằng ngày bắt đầu.', 1;
    IF EXISTS (SELECT 1 FROM KyDoiSoat WHERE TrangThai <> N'Huy' AND TuNgay <= @DenNgay AND DenNgay >= @TuNgay)
        THROW 50102, N'Khoảng thời gian trùng với một kỳ đối soát đã có (hủy kỳ cũ trước nếu cần tạo lại).', 1;

    DECLARE @tu DATETIME = CAST(@TuNgay AS DATETIME), @den DATETIME = DATEADD(DAY, 1, CAST(@DenNgay AS DATETIME));
    IF @TenKy IS NULL SET @TenKy = N'Đối soát ' + CONVERT(NVARCHAR(10), @TuNgay, 103) + N' - ' + CONVERT(NVARCHAR(10), @DenNgay, 103);

    CREATE TABLE #Don    (MaDonHang INT PRIMARY KEY, MaGianHang INT NOT NULL, TienHang DECIMAL(14,0) NOT NULL, Ty DECIMAL(5,4) NOT NULL, Phi DECIMAL(14,0) NOT NULL);
    CREATE TABLE #Chuyen (MaGiaoHang INT PRIMARY KEY, MaTaiXe INT NOT NULL, SoTien DECIMAL(14,0) NOT NULL, Cod DECIMAL(14,0) NOT NULL);
    CREATE TABLE #DC     (MaDieuChinh INT PRIMARY KEY, MaTaiXe INT NOT NULL, SoTien DECIMAL(14,0) NOT NULL);

    /* đơn đã giao, quán chưa được trả, chưa nằm trong khoản chi nào */
    INSERT INTO #Don (MaDonHang, MaGianHang, TienHang, Ty, Phi)
    SELECT d.MaDonHang, d.MaGianHang, d.TongTien - d.PhiGiaoHang, gh.TyLeChietKhau,
           CAST(ROUND((d.TongTien - d.PhiGiaoHang) * gh.TyLeChietKhau, 0) AS DECIMAL(14,0))
    FROM DonHang d
    JOIN GianHang gh ON gh.MaGianHang = d.MaGianHang
    LEFT JOIN GiaoHang g ON g.MaDonHang = d.MaDonHang
    WHERE d.TrangThai = N'DaGiao' AND d.QuanDaTraLuc IS NULL
      AND COALESCE(g.ThoiGianGiao, d.NgayDat) >= @tu AND COALESCE(g.ThoiGianGiao, d.NgayDat) < @den
      AND NOT EXISTS (SELECT 1 FROM ChiTietChiTraGianHang c WHERE c.MaDonHang = d.MaDonHang);

    /* chuyến giao tính thu nhập (cùng quy tắc DriverThuNhapApi), chưa trả, chưa nằm trong khoản chi nào */
    INSERT INTO #Chuyen (MaGiaoHang, MaTaiXe, SoTien, Cod)
    SELECT g.MaGiaoHang, g.MaTaiXe, d.PhiGiaoHang,
           CASE WHEN g.TrangThai = N'GiaoThanhCong' AND g.CodDaNopLuc IS NULL THEN ISNULL(g.TienThuCOD, 0) ELSE 0 END
    FROM GiaoHang g
    JOIN DonHang d ON d.MaDonHang = g.MaDonHang
    WHERE (g.TrangThai = N'GiaoThanhCong' OR (g.TrangThai = N'GiaoThatBai' AND g.TinhPhiThatBai = 1))
      AND g.TrangThaiThuNhap = N'ChoThanhToan'
      AND g.ThoiGianGiao >= @tu AND g.ThoiGianGiao < @den
      AND NOT EXISTS (SELECT 1 FROM ChiTietChiTraTaiXe c WHERE c.Loai = N'Chuyen' AND c.MaThamChieu = g.MaGiaoHang);

    INSERT INTO #DC (MaDieuChinh, MaTaiXe, SoTien)
    SELECT dc.MaDieuChinh, dc.MaTaiXe, dc.SoTien
    FROM DieuChinhThuNhap dc
    JOIN TaiXe x ON x.MaTaiXe = dc.MaTaiXe
    WHERE dc.TrangThai = N'ChoThanhToan' AND dc.NgayTao >= @tu AND dc.NgayTao < @den
      AND NOT EXISTS (SELECT 1 FROM ChiTietChiTraTaiXe c WHERE c.Loai = N'DieuChinh' AND c.MaThamChieu = dc.MaDieuChinh);

    BEGIN TRAN;
        INSERT INTO KyDoiSoat (TenKy, TuNgay, DenNgay, MaTKTao) VALUES (@TenKy, @TuNgay, @DenNgay, @MaTK);
        SET @MaKy = SCOPE_IDENTITY();

        INSERT INTO ChiTraGianHang (MaKy, MaGianHang, SoDon, TienHang, TyLeChietKhau, PhiNenTang, SoTienChiTra)
        SELECT @MaKy, MaGianHang, COUNT(*), SUM(TienHang), MAX(Ty), SUM(Phi), SUM(TienHang) - SUM(Phi)
        FROM #Don GROUP BY MaGianHang;

        INSERT INTO ChiTietChiTraGianHang (MaDonHang, MaChiTraQuan, TienHang, PhiNenTang)
        SELECT o.MaDonHang, c.MaChiTraQuan, o.TienHang, o.Phi
        FROM #Don o JOIN ChiTraGianHang c ON c.MaKy = @MaKy AND c.MaGianHang = o.MaGianHang;

        ;WITH a AS (SELECT MaTaiXe, COUNT(*) AS SoChuyen, SUM(SoTien) AS Phi, SUM(Cod) AS Cod FROM #Chuyen GROUP BY MaTaiXe),
              b AS (SELECT MaTaiXe, SUM(SoTien) AS DieuChinh FROM #DC GROUP BY MaTaiXe)
        INSERT INTO ChiTraTaiXe (MaKy, MaTaiXe, SoChuyen, TienPhiGiao, TienDieuChinh, TienCODChuaNop, SoTienChiTra)
        SELECT @MaKy, COALESCE(a.MaTaiXe, b.MaTaiXe), ISNULL(a.SoChuyen, 0), ISNULL(a.Phi, 0), ISNULL(b.DieuChinh, 0),
               ISNULL(a.Cod, 0), ISNULL(a.Phi, 0) + ISNULL(b.DieuChinh, 0)
        FROM a FULL JOIN b ON a.MaTaiXe = b.MaTaiXe;

        INSERT INTO ChiTietChiTraTaiXe (Loai, MaThamChieu, MaChiTraTX, SoTien)
        SELECT N'Chuyen', c.MaGiaoHang, t.MaChiTraTX, c.SoTien
        FROM #Chuyen c JOIN ChiTraTaiXe t ON t.MaKy = @MaKy AND t.MaTaiXe = c.MaTaiXe
        UNION ALL
        SELECT N'DieuChinh', d.MaDieuChinh, t.MaChiTraTX, d.SoTien
        FROM #DC d JOIN ChiTraTaiXe t ON t.MaKy = @MaKy AND t.MaTaiXe = d.MaTaiXe;

        UPDATE KyDoiSoat
           SET TongSoDon        = (SELECT ISNULL(SUM(SoDon), 0)        FROM ChiTraGianHang WHERE MaKy = @MaKy),
               TongTienHang     = (SELECT ISNULL(SUM(TienHang), 0)     FROM ChiTraGianHang WHERE MaKy = @MaKy),
               TongPhiNenTang   = (SELECT ISNULL(SUM(PhiNenTang), 0)   FROM ChiTraGianHang WHERE MaKy = @MaKy),
               TongPhaiTraQuan  = (SELECT ISNULL(SUM(SoTienChiTra), 0) FROM ChiTraGianHang WHERE MaKy = @MaKy),
               TongPhaiTraTaiXe = (SELECT ISNULL(SUM(SoTienChiTra), 0) FROM ChiTraTaiXe    WHERE MaKy = @MaKy)
         WHERE MaKy = @MaKy;
    COMMIT;

    SELECT * FROM KyDoiSoat WHERE MaKy = @MaKy;
END;
GO

/* ---- 9.2 Cập nhật trạng thái kỳ theo các khoản chi (nội bộ): còn khoản chờ -> DaChot/DangChi; hết -> HoanTat ---- */
CREATE OR ALTER PROCEDURE sp_CapNhatTrangThaiKyDoiSoat @MaKy INT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @con INT = (SELECT COUNT(*) FROM ChiTraGianHang WHERE MaKy = @MaKy AND TrangThai IN (N'ChoChi', N'Loi'))
                     + (SELECT COUNT(*) FROM ChiTraTaiXe    WHERE MaKy = @MaKy AND TrangThai IN (N'ChoChi', N'Loi'));
    DECLARE @daChi INT = (SELECT COUNT(*) FROM ChiTraGianHang WHERE MaKy = @MaKy AND TrangThai = N'DaChi')
                       + (SELECT COUNT(*) FROM ChiTraTaiXe    WHERE MaKy = @MaKy AND TrangThai = N'DaChi');
    UPDATE KyDoiSoat
       SET TrangThai = CASE WHEN @con = 0 THEN N'HoanTat' WHEN @daChi > 0 THEN N'DangChi' ELSE N'DaChot' END
     WHERE MaKy = @MaKy AND TrangThai IN (N'DaChot', N'DangChi');
END;
GO

/* ---- 9.3 Chốt kỳ (xem xong, không sửa nữa) -> bắt đầu được đánh dấu đã chi; kỳ không có khoản nào thì hoàn tất luôn ---- */
CREATE OR ALTER PROCEDURE sp_ChotKyDoiSoat @MaKy INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE KyDoiSoat SET TrangThai = N'DaChot', NgayChot = GETDATE() WHERE MaKy = @MaKy AND TrangThai = N'BanNhap';
    IF @@ROWCOUNT = 0 THROW 50103, N'Kỳ không tồn tại hoặc không còn ở trạng thái Bản nháp.', 1;
    EXEC sp_CapNhatTrangThaiKyDoiSoat @MaKy;
END;
GO

/* ---- 9.4 Đánh dấu đã chi cho quán (đồng bộ DonHang.QuanDaTraLuc) ---- */
CREATE OR ALTER PROCEDURE sp_DanhDauDaChiTraQuan
    @MaChiTraQuan INT, @PhuongThuc NVARCHAR(15) = N'ChuyenKhoan', @MaGiaoDichNganHang NVARCHAR(100) = NULL, @MaTK INT = NULL
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @ky INT, @tt NVARCHAR(8);
    SELECT @ky = MaKy, @tt = TrangThai FROM ChiTraGianHang WHERE MaChiTraQuan = @MaChiTraQuan;
    IF @ky IS NULL THROW 50110, N'Không tìm thấy khoản chi cho gian hàng.', 1;
    IF @tt <> N'ChoChi' AND @tt <> N'Loi' THROW 50111, N'Khoản chi này không ở trạng thái chờ chi.', 1;
    IF NOT EXISTS (SELECT 1 FROM KyDoiSoat WHERE MaKy = @ky AND TrangThai IN (N'DaChot', N'DangChi')) THROW 50112, N'Phải chốt kỳ đối soát trước khi chi.', 1;
    BEGIN TRAN;
        UPDATE ChiTraGianHang
           SET TrangThai = N'DaChi', PhuongThuc = @PhuongThuc, MaGiaoDichNganHang = @MaGiaoDichNganHang, NgayChi = GETDATE(), MaTKChi = @MaTK
         WHERE MaChiTraQuan = @MaChiTraQuan;
        UPDATE d SET d.QuanDaTraLuc = GETDATE()
          FROM DonHang d JOIN ChiTietChiTraGianHang c ON c.MaDonHang = d.MaDonHang
         WHERE c.MaChiTraQuan = @MaChiTraQuan AND d.QuanDaTraLuc IS NULL;
        EXEC sp_CapNhatTrangThaiKyDoiSoat @ky;
    COMMIT;
END;
GO

/* ---- 9.5 Đánh dấu đã chi cho tài xế (đồng bộ GiaoHang.TrangThaiThuNhap + DieuChinhThuNhap.TrangThai) ---- */
CREATE OR ALTER PROCEDURE sp_DanhDauDaChiTraTaiXe
    @MaChiTraTX INT, @PhuongThuc NVARCHAR(15) = N'ChuyenKhoan', @MaGiaoDichNganHang NVARCHAR(100) = NULL, @MaTK INT = NULL
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @ky INT, @tt NVARCHAR(8);
    SELECT @ky = MaKy, @tt = TrangThai FROM ChiTraTaiXe WHERE MaChiTraTX = @MaChiTraTX;
    IF @ky IS NULL THROW 50120, N'Không tìm thấy khoản chi cho tài xế.', 1;
    IF @tt <> N'ChoChi' AND @tt <> N'Loi' THROW 50121, N'Khoản chi này không ở trạng thái chờ chi.', 1;
    IF NOT EXISTS (SELECT 1 FROM KyDoiSoat WHERE MaKy = @ky AND TrangThai IN (N'DaChot', N'DangChi')) THROW 50122, N'Phải chốt kỳ đối soát trước khi chi.', 1;
    BEGIN TRAN;
        UPDATE ChiTraTaiXe
           SET TrangThai = N'DaChi', PhuongThuc = @PhuongThuc, MaGiaoDichNganHang = @MaGiaoDichNganHang, NgayChi = GETDATE(), MaTKChi = @MaTK
         WHERE MaChiTraTX = @MaChiTraTX;
        UPDATE g SET g.TrangThaiThuNhap = N'DaThanhToan', g.NgayThanhToanThuNhap = GETDATE()
          FROM GiaoHang g JOIN ChiTietChiTraTaiXe c ON c.Loai = N'Chuyen' AND c.MaThamChieu = g.MaGiaoHang
         WHERE c.MaChiTraTX = @MaChiTraTX AND g.TrangThaiThuNhap = N'ChoThanhToan';
        UPDATE dc SET dc.TrangThai = N'DaThanhToan', dc.NgayThanhToan = GETDATE()
          FROM DieuChinhThuNhap dc JOIN ChiTietChiTraTaiXe c ON c.Loai = N'DieuChinh' AND c.MaThamChieu = dc.MaDieuChinh
         WHERE c.MaChiTraTX = @MaChiTraTX AND dc.TrangThai = N'ChoThanhToan';
        EXEC sp_CapNhatTrangThaiKyDoiSoat @ky;
    COMMIT;
END;
GO

/* ---- 9.6 Hủy kỳ (chỉ khi chưa chi khoản nào): nhả đơn/chuyến để kỳ khác gom lại ---- */
CREATE OR ALTER PROCEDURE sp_HuyKyDoiSoat @MaKy INT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF NOT EXISTS (SELECT 1 FROM KyDoiSoat WHERE MaKy = @MaKy AND TrangThai IN (N'BanNhap', N'DaChot', N'DangChi'))
        THROW 50130, N'Kỳ không tồn tại hoặc đã hoàn tất/hủy.', 1;
    IF EXISTS (SELECT 1 FROM ChiTraGianHang WHERE MaKy = @MaKy AND TrangThai = N'DaChi')
       OR EXISTS (SELECT 1 FROM ChiTraTaiXe WHERE MaKy = @MaKy AND TrangThai = N'DaChi')
        THROW 50131, N'Kỳ đã có khoản được chi, không thể hủy.', 1;
    BEGIN TRAN;
        DELETE c FROM ChiTietChiTraGianHang c JOIN ChiTraGianHang h ON h.MaChiTraQuan = c.MaChiTraQuan WHERE h.MaKy = @MaKy;
        DELETE c FROM ChiTietChiTraTaiXe    c JOIN ChiTraTaiXe    h ON h.MaChiTraTX  = c.MaChiTraTX  WHERE h.MaKy = @MaKy;
        UPDATE ChiTraGianHang SET TrangThai = N'Huy' WHERE MaKy = @MaKy;
        UPDATE ChiTraTaiXe    SET TrangThai = N'Huy' WHERE MaKy = @MaKy;
        UPDATE KyDoiSoat      SET TrangThai = N'Huy' WHERE MaKy = @MaKy;
    COMMIT;
END;
GO

CREATE OR ALTER VIEW v_ChiTraGianHang AS
SELECT c.MaChiTraQuan, c.MaKy, k.TenKy, k.TuNgay, k.DenNgay, c.MaGianHang, g.TenCuaHang,
       c.SoDon, c.TienHang, c.TyLeChietKhau, c.PhiNenTang, c.DieuChinh, c.SoTienChiTra, c.TrangThai, c.NgayChi, c.MaGiaoDichNganHang
FROM ChiTraGianHang c JOIN KyDoiSoat k ON k.MaKy = c.MaKy JOIN GianHang g ON g.MaGianHang = c.MaGianHang;
GO

CREATE OR ALTER VIEW v_ChiTraTaiXe AS
SELECT c.MaChiTraTX, c.MaKy, k.TenKy, k.TuNgay, k.DenNgay, c.MaTaiXe, x.HoTen, x.SDT,
       c.SoChuyen, c.TienPhiGiao, c.TienDieuChinh, c.TienCODChuaNop, c.SoTienChiTra, c.TrangThai, c.NgayChi, c.MaGiaoDichNganHang
FROM ChiTraTaiXe c JOIN KyDoiSoat k ON k.MaKy = c.MaKy JOIN TaiXe x ON x.MaTaiXe = c.MaTaiXe;
GO

/* ============================================================
   10. ĐÁNH GIÁ: điểm trung bình (view) — không tạo bảng "ratings" riêng để khỏi trùng DanhGia/DanhGiaMon/GiaoHang.DiemTaiXe
   ============================================================ */
CREATE OR ALTER VIEW v_DiemDanhGiaGianHang AS       -- bỏ đánh giá đã bị ẩn (DanhGia.DaAn = 1)
SELECT d.MaGianHang, COUNT(*) AS SoDanhGia,
       CAST(AVG(CAST(d.SoSao AS FLOAT)) AS DECIMAL(3,2))            AS DiemQuan,
       CAST(AVG(CAST(d.SoSaoMon AS FLOAT)) AS DECIMAL(3,2))         AS DiemMon,
       CAST(AVG(CAST(d.SoSaoGiaoHang AS FLOAT)) AS DECIMAL(3,2))    AS DiemGiaoHang
FROM DanhGia d WHERE d.DaAn = 0 GROUP BY d.MaGianHang;
GO

CREATE OR ALTER VIEW v_DiemDanhGiaMon AS
SELECT m.MaMonAn, COUNT(*) AS SoDanhGia, CAST(AVG(CAST(m.SoSao AS FLOAT)) AS DECIMAL(3,2)) AS DiemTrungBinh
FROM DanhGiaMon m GROUP BY m.MaMonAn;
GO

CREATE OR ALTER VIEW v_DiemDanhGiaTaiXe AS
SELECT g.MaTaiXe, COUNT(*) AS SoDanhGia, CAST(AVG(CAST(g.DiemTaiXe AS FLOAT)) AS DECIMAL(3,2)) AS DiemTrungBinh
FROM GiaoHang g WHERE g.DiemTaiXe IS NOT NULL GROUP BY g.MaTaiXe;
GO

/* ============================================================
   11. ĐỒNG BỘ MỘT CHIỀU TỪ BẢN CŨ → BẢNG MỚI (chạy lại bao nhiêu lần cũng được; không ghi đè dữ liệu đã sửa ở bảng mới)
   ============================================================ */

/* 11.1 Vai trò: phản chiếu TaiKhoan.VaiTro và QuanTri.CapQuyenHan; dọn vai trò gốc/cấp quản trị không còn đúng (vai trò TuyChinh không bị đụng) */
CREATE OR ALTER PROCEDURE sp_DongBoVaiTroTaiKhoan
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO TaiKhoan_VaiTro (MaTK, MaVaiTro)
    SELECT t.MaTK, v.MaVaiTro
    FROM TaiKhoan t JOIN VaiTro v ON v.LoaiVaiTro = N'Goc' AND v.TenVaiTro = t.VaiTro
    WHERE NOT EXISTS (SELECT 1 FROM TaiKhoan_VaiTro x WHERE x.MaTK = t.MaTK AND x.MaVaiTro = v.MaVaiTro);

    INSERT INTO TaiKhoan_VaiTro (MaTK, MaVaiTro)
    SELECT q.MaTK, v.MaVaiTro
    FROM QuanTri q JOIN VaiTro v ON v.LoaiVaiTro = N'CapQuanTri' AND v.TenVaiTro = q.CapQuyenHan
    WHERE NOT EXISTS (SELECT 1 FROM TaiKhoan_VaiTro x WHERE x.MaTK = q.MaTK AND x.MaVaiTro = v.MaVaiTro);

    DELETE tv FROM TaiKhoan_VaiTro tv JOIN VaiTro v ON v.MaVaiTro = tv.MaVaiTro
    WHERE v.LoaiVaiTro = N'Goc'
      AND NOT EXISTS (SELECT 1 FROM TaiKhoan t WHERE t.MaTK = tv.MaTK AND t.VaiTro = v.TenVaiTro);

    DELETE tv FROM TaiKhoan_VaiTro tv JOIN VaiTro v ON v.MaVaiTro = tv.MaVaiTro
    WHERE v.LoaiVaiTro = N'CapQuanTri'
      AND NOT EXISTS (SELECT 1 FROM QuanTri q WHERE q.MaTK = tv.MaTK AND q.CapQuyenHan = v.TenVaiTro);
END;
GO

/* 11.2 Hồ sơ tài xế: xe chính + CCCD + GPLX từ cột cũ của TaiXe (chỉ thêm khi tài xế đó CHƯA có dòng loại đó) */
CREATE OR ALTER PROCEDURE sp_DongBoHoSoTaiXe
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO PhuongTienTaiXe (MaTaiXe, LoaiXe, BienSo, LaXeChinh)
    SELECT x.MaTaiXe, ISNULL(NULLIF(LTRIM(RTRIM(x.PhuongTien)), N''), N'Xe máy'), LTRIM(RTRIM(x.BienSo)), 1
    FROM TaiXe x
    WHERE x.BienSo IS NOT NULL AND LTRIM(RTRIM(x.BienSo)) <> ''
      AND NOT EXISTS (SELECT 1 FROM PhuongTienTaiXe p WHERE p.MaTaiXe = x.MaTaiXe);

    INSERT INTO GiayToTaiXe (MaTaiXe, LoaiGiayTo, SoGiayTo, TrangThaiDuyet, LyDoTuChoi)
    SELECT x.MaTaiXe, N'CCCD', LTRIM(RTRIM(x.SoCCCD)), x.TrangThaiDuyet, x.LyDoTuChoi
    FROM TaiXe x
    WHERE x.SoCCCD IS NOT NULL AND LTRIM(RTRIM(x.SoCCCD)) <> ''
      AND NOT EXISTS (SELECT 1 FROM GiayToTaiXe g WHERE g.MaTaiXe = x.MaTaiXe AND g.LoaiGiayTo = N'CCCD');

    INSERT INTO GiayToTaiXe (MaTaiXe, LoaiGiayTo, SoGiayTo, DuongDanAnh, TrangThaiDuyet, LyDoTuChoi)
    SELECT x.MaTaiXe, N'GPLX', NULLIF(LTRIM(RTRIM(x.SoGPLX)), ''), x.AnhGPLX, x.TrangThaiDuyet, x.LyDoTuChoi
    FROM TaiXe x
    WHERE (NULLIF(LTRIM(RTRIM(x.SoGPLX)), '') IS NOT NULL OR NULLIF(LTRIM(RTRIM(x.AnhGPLX)), N'') IS NOT NULL)
      AND NOT EXISTS (SELECT 1 FROM GiayToTaiXe g WHERE g.MaTaiXe = x.MaTaiXe AND g.LoaiGiayTo = N'GPLX');
END;
GO

/* 11.2b Bảng TaiXeTuChoiDon / DieuPhoiLog có thể đã được tạo từ bản CŨ thiếu cột LyDo / ThoiGian
   (lỗi "Invalid column name 'LyDo' / 'ThoiGian'" khi tạo sp_DongBoPhanCongGiaoHang) -> bổ sung cột còn thiếu, KHÔNG xóa dữ liệu. */
IF OBJECT_ID('TaiXeTuChoiDon', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('TaiXeTuChoiDon', 'LyDo') IS NULL     EXEC(N'ALTER TABLE TaiXeTuChoiDon ADD LyDo NVARCHAR(300) NULL');
    IF COL_LENGTH('TaiXeTuChoiDon', 'ThoiGian') IS NULL EXEC(N'ALTER TABLE TaiXeTuChoiDon ADD ThoiGian DATETIME2 NOT NULL CONSTRAINT DF_TaiXeTuChoiDon_ThoiGian DEFAULT SYSDATETIME()');
END
IF OBJECT_ID('DieuPhoiLog', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('DieuPhoiLog', 'LyDo') IS NULL     EXEC(N'ALTER TABLE DieuPhoiLog ADD LyDo NVARCHAR(300) NOT NULL CONSTRAINT DF_DieuPhoiLog_LyDo DEFAULT N''''');
    IF COL_LENGTH('DieuPhoiLog', 'ThoiGian') IS NULL EXEC(N'ALTER TABLE DieuPhoiLog ADD ThoiGian DATETIME NOT NULL CONSTRAINT DF_DieuPhoiLog_ThoiGian DEFAULT GETDATE()');
END
GO

/* 11.3 Phân công giao hàng: chuyến hiện có + lần từ chối + lần bị gỡ/đổi tài xế (DieuPhoiLog) */
CREATE OR ALTER PROCEDURE sp_DongBoPhanCongGiaoHang
AS
BEGIN
    SET NOCOUNT ON;
    /* chuyến hiện có (GiaoHang): đang làm = DaNhan, đã kết thúc = HoanThanh */
    INSERT INTO PhanCongGiaoHang (MaDonHang, MaTaiXe, HinhThuc, TrangThai, MaTKPhanCong, NgayDeNghi, NgayPhanHoi)
    SELECT g.MaDonHang, g.MaTaiXe,
           CASE WHEN EXISTS (SELECT 1 FROM DieuPhoiLog l WHERE l.MaDonHang = g.MaDonHang AND l.HanhDong IN (N'PhanCong', N'DoiTaiXe') AND l.MaTaiXeMoi = g.MaTaiXe)
                THEN N'QuanTri' ELSE N'TuNhan' END,
           CASE WHEN g.TrangThai IN (N'GiaoThanhCong', N'GiaoThatBai') THEN N'HoanThanh' ELSE N'DaNhan' END,
           NULL, ISNULL(g.ThoiGianNhan, d.NgayDat), g.ThoiGianNhan
    FROM GiaoHang g JOIN DonHang d ON d.MaDonHang = g.MaDonHang
    WHERE NOT EXISTS (SELECT 1 FROM PhanCongGiaoHang p WHERE p.MaDonHang = g.MaDonHang AND p.MaTaiXe = g.MaTaiXe AND p.TrangThai IN (N'DaNhan', N'HoanThanh'));

    /* tài xế từ chối đơn */
    INSERT INTO PhanCongGiaoHang (MaDonHang, MaTaiXe, HinhThuc, TrangThai, LyDo, NgayDeNghi, NgayPhanHoi)
    SELECT c.MaDonHang, c.MaTaiXe, N'TuNhan', N'TuChoi', c.LyDo, c.ThoiGian, c.ThoiGian
    FROM TaiXeTuChoiDon c
    WHERE NOT EXISTS (SELECT 1 FROM PhanCongGiaoHang p WHERE p.MaDonHang = c.MaDonHang AND p.MaTaiXe = c.MaTaiXe AND p.TrangThai = N'TuChoi');

    /* tài xế cũ bị đổi/gỡ khỏi đơn */
    INSERT INTO PhanCongGiaoHang (MaDonHang, MaTaiXe, HinhThuc, TrangThai, LyDo, MaTKPhanCong, NgayDeNghi, NgayPhanHoi)
    SELECT l.MaDonHang, l.MaTaiXeCu, N'QuanTri', N'DaGo', l.LyDo,
           (SELECT t.MaTK FROM TaiKhoan t WHERE t.MaTK = l.MaTK), l.ThoiGian, l.ThoiGian
    FROM DieuPhoiLog l
    JOIN TaiXe x ON x.MaTaiXe = l.MaTaiXeCu
    WHERE l.HanhDong IN (N'DoiTaiXe', N'GoTaiXe') AND l.MaTaiXeCu IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM PhanCongGiaoHang p WHERE p.MaDonHang = l.MaDonHang AND p.MaTaiXe = l.MaTaiXeCu AND p.TrangThai = N'DaGo');
END;
GO

/* 11.4 Phản hồi cũ (PhanHoi) → phiếu hỗ trợ + tin nhắn đầu (khách) + tin trả lời (quản trị) */
CREATE OR ALTER PROCEDURE sp_DongBoPhanHoiSangPhieuHoTro
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRAN;
        INSERT INTO PhieuHoTro (MaTKNguoiGui, VaiTroNguoiGui, MaDonHang, MaGianHang, PhanLoai, Loai, TieuDe, TrangThai,
                                MaTKPhuTrach, MaPhanHoi, NgayTao, NgayCapNhat, NgayDong)
        SELECT k.MaTK, N'KhachHang', p.MaDonHang, p.MaGianHang, p.PhanLoai, p.Loai, p.TieuDe, p.TrangThai,
               (SELECT t.MaTK FROM TaiKhoan t WHERE t.MaTK = p.MaTKPhuTrach),
               p.MaPhanHoi, p.NgayGui, ISNULL(p.NgayXuLy, p.NgayGui),
               CASE WHEN p.TrangThai = N'DaXuLy' THEN p.NgayXuLy END
        FROM PhanHoi p JOIN KhachHang k ON k.MaKH = p.MaKH
        WHERE NOT EXISTS (SELECT 1 FROM PhieuHoTro h WHERE h.MaPhanHoi = p.MaPhanHoi);

        INSERT INTO TinNhanHoTro (MaPhieu, MaTKGui, VaiTroGui, NoiDung, NgayGui)
        SELECT h.MaPhieu, h.MaTKNguoiGui, N'KhachHang', p.NoiDung, p.NgayGui
        FROM PhieuHoTro h JOIN PhanHoi p ON p.MaPhanHoi = h.MaPhanHoi
        WHERE NOT EXISTS (SELECT 1 FROM TinNhanHoTro m WHERE m.MaPhieu = h.MaPhieu AND m.VaiTroGui = N'KhachHang');

        INSERT INTO TinNhanHoTro (MaPhieu, MaTKGui, VaiTroGui, NoiDung, NgayGui)
        SELECT h.MaPhieu, h.MaTKPhuTrach, N'QuanTri', p.TraLoi, ISNULL(p.NgayXuLy, p.NgayGui)
        FROM PhieuHoTro h JOIN PhanHoi p ON p.MaPhanHoi = h.MaPhanHoi
        WHERE p.TraLoi IS NOT NULL AND LTRIM(RTRIM(p.TraLoi)) <> N''
          AND NOT EXISTS (SELECT 1 FROM TinNhanHoTro m WHERE m.MaPhieu = h.MaPhieu AND m.VaiTroGui = N'QuanTri');
    COMMIT;
END;
GO

CREATE OR ALTER PROCEDURE sp_DongBoThietKeMoi     -- chạy tất cả; gọi lại sau khi có tài khoản/tài xế/phản hồi mới từ app cũ
AS
BEGIN
    SET NOCOUNT ON;
    EXEC sp_DongBoVaiTroTaiKhoan;
    EXEC sp_DongBoHoSoTaiXe;
    EXEC sp_DongBoPhanCongGiaoHang;
    EXEC sp_DongBoPhanHoiSangPhieuHoTro;
END;
GO

EXEC sp_DongBoThietKeMoi;
GO

/* ============================================================
   12. ĐỐI CHIẾU 37 BẢNG CỦA ĐỀ BÀI  (cột TonTai phải toàn = 1)
   ============================================================ */
SELECT v.Nhom, v.TenDeBai, v.TenTrongCSDL, v.Nguon,
       CASE WHEN EXISTS (SELECT 1 FROM sys.tables t WHERE t.name = v.TenTrongCSDL) THEN 1 ELSE 0 END AS TonTai
FROM (VALUES
 (N'Tài khoản',   'users',                  'TaiKhoan',               N'có sẵn'),
 (N'Tài khoản',   'roles',                  'VaiTro',                 N'MỚI'),
 (N'Tài khoản',   'permissions',            'Quyen',                  N'MỚI (+VaiTro_Quyen)'),
 (N'Tài khoản',   'user_roles',             'TaiKhoan_VaiTro',        N'MỚI'),
 (N'Khách hàng',  'customers',              'KhachHang',              N'có sẵn'),
 (N'Khách hàng',  'customer_addresses',     'DiaChiKhachHang',        N'có sẵn'),
 (N'Nhà hàng',    'restaurants',            'GianHang',               N'có sẵn'),
 (N'Nhà hàng',    'restaurant_branches',    'ChiNhanhGianHang',       N'MỚI'),
 (N'Nhà hàng',    'restaurant_hours',       'GioLamViecGianHang',     N'MỚI'),
 (N'Thực đơn',    'categories',             'DanhMuc',                N'có sẵn'),
 (N'Thực đơn',    'products',               'MonAn',                  N'có sẵn'),
 (N'Thực đơn',    'product_options',        'TuyChonMon',             N'có sẵn'),
 (N'Thực đơn',    'product_images',         'HinhAnhMonAn',           N'MỚI'),
 (N'Tài xế',      'drivers',                'TaiXe',                  N'có sẵn'),
 (N'Tài xế',      'driver_vehicles',        'PhuongTienTaiXe',        N'MỚI'),
 (N'Tài xế',      'driver_documents',       'GiayToTaiXe',            N'MỚI'),
 (N'Tài xế',      'driver_locations',       'LichSuViTriTaiXe',       N'MỚI (TaiXeViTri = vị trí theo đơn, có sẵn)'),
 (N'Đơn hàng',    'orders',                 'DonHang',                N'có sẵn'),
 (N'Đơn hàng',    'order_items',            'ChiTietDonHang',         N'có sẵn'),
 (N'Đơn hàng',    'order_status_histories', 'LichSuTrangThaiDon',     N'có sẵn'),
 (N'Giao hàng',   'deliveries',             'GiaoHang',               N'có sẵn'),
 (N'Giao hàng',   'delivery_assignments',   'PhanCongGiaoHang',       N'MỚI'),
 (N'Thanh toán',  'payments',               'ThanhToan',              N'có sẵn'),
 (N'Thanh toán',  'refunds',                'YeuCauHoanTien',         N'có sẵn'),
 (N'Thanh toán',  'transactions',           'GiaoDichThanhToan',      N'có sẵn'),
 (N'Khuyến mãi',  'vouchers',               'KhuyenMai',              N'có sẵn'),
 (N'Khuyến mãi',  'voucher_usages',         'KhuyenMaiKhachDung',     N'có sẵn'),
 (N'Khuyến mãi',  'promotions',             'ChuongTrinhKhuyenMai',   N'MỚI (+ChuongTrinhKhuyenMai_Voucher)'),
 (N'Đánh giá',    'reviews',                'DanhGia',                N'có sẵn'),
 (N'Đánh giá',    'ratings',                'DanhGiaMon',             N'có sẵn (+3 view điểm TB, mục 10)'),
 (N'Thông báo',   'notifications',          'ThongBao',               N'có sẵn'),
 (N'Thông báo',   'notification_logs',      'NhatKyThongBao',         N'MỚI'),
 (N'Hỗ trợ',      'support_tickets',        'PhieuHoTro',             N'MỚI'),
 (N'Hỗ trợ',      'support_messages',       'TinNhanHoTro',           N'MỚI'),
 (N'Báo cáo',     'settlements',            'KyDoiSoat',              N'MỚI'),
 (N'Báo cáo',     'restaurant_payouts',     'ChiTraGianHang',         N'MỚI (+ChiTietChiTraGianHang)'),
 (N'Báo cáo',     'driver_payouts',         'ChiTraTaiXe',            N'MỚI (+ChiTietChiTraTaiXe)')
) v (Nhom, TenDeBai, TenTrongCSDL, Nguon);
GO

/* ===== VÍ DỤ SỬ DỤNG =====
-- Quyền của tài khoản theo vai trò
SELECT * FROM v_QuyenTaiKhoan WHERE TenDangNhap = N'admin';

-- Giờ làm việc: quán 1 mở T2–T6 hai ca, T7–CN nghỉ trưa không mở
INSERT INTO GioLamViecGianHang (MaGianHang, Thu, GioMo, GioDong) VALUES (1,1,'07:00','11:00'),(1,1,'17:00','22:00');
INSERT INTO GioLamViecGianHang (MaGianHang, Thu, NghiCaNgay) VALUES (1,7,1);
SELECT * FROM v_GioLamViecHieuLuc WHERE MaGianHang = 1 ORDER BY Thu, GioMo;

-- Vị trí tài xế
EXEC sp_GhiViTriTaiXe @MaTaiXe = 1, @ViDo = 10.8231, @KinhDo = 106.6297, @MaDonHang = NULL;
SELECT * FROM v_ViTriTaiXeMoiNhat;

-- Đối soát tháng 9/2026: tạo -> xem -> chốt -> chi từng khoản
DECLARE @ky INT;
EXEC sp_TaoKyDoiSoat @TuNgay = '2026-09-01', @DenNgay = '2026-09-30', @MaTK = 1, @MaKy = @ky OUTPUT;
SELECT * FROM v_ChiTraGianHang WHERE MaKy = @ky;
SELECT * FROM v_ChiTraTaiXe    WHERE MaKy = @ky;
EXEC sp_ChotKyDoiSoat @MaKy = @ky;
EXEC sp_DanhDauDaChiTraQuan @MaChiTraQuan = 1, @PhuongThuc = N'ChuyenKhoan', @MaGiaoDichNganHang = N'FT26273...', @MaTK = 1;
EXEC sp_DanhDauDaChiTraTaiXe @MaChiTraTX = 1, @MaTK = 1;
-- Hủy kỳ nếu chưa chi khoản nào: EXEC sp_HuyKyDoiSoat @MaKy = @ky;

-- Điểm trung bình
SELECT * FROM v_DiemDanhGiaGianHang; SELECT * FROM v_DiemDanhGiaMon; SELECT * FROM v_DiemDanhGiaTaiXe;

-- Sau khi app cũ tạo thêm tài khoản/tài xế/phản hồi: nạp lại bảng mới
EXEC sp_DongBoThietKeMoi;
*/
GO

/* ======================= [3/9] MỨC ĐƯỜNG / MỨC ĐÁ ======================= */
USE QuanLyDichVuAnUong;
GO
/* Bổ sung loại tùy chọn "Mức đường" và "Mức đá" cho TuyChonMon (chạy một lần trên CSDL đã có). An toàn khi chạy lại. */
IF OBJECT_ID('TuyChonMon', 'U') IS NOT NULL
BEGIN
    DECLARE @ten SYSNAME, @sql NVARCHAR(400);
    DECLARE c CURSOR LOCAL FAST_FORWARD FOR
        SELECT cc.name FROM sys.check_constraints cc
        WHERE cc.parent_object_id = OBJECT_ID('TuyChonMon') AND cc.definition LIKE '%Loai%' AND cc.definition LIKE '%MucCay%';
    OPEN c; FETCH NEXT FROM c INTO @ten;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @sql = N'ALTER TABLE TuyChonMon DROP CONSTRAINT ' + QUOTENAME(@ten);
        EXEC(@sql);
        FETCH NEXT FROM c INTO @ten;
    END
    CLOSE c; DEALLOCATE c;

    IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID('TuyChonMon') AND name = 'CK_TuyChonMon_Loai')
        ALTER TABLE TuyChonMon ADD CONSTRAINT CK_TuyChonMon_Loai
            CHECK (Loai IN (N'Size', N'Topping', N'MucCay', N'MucDuong', N'MucDa'));
END
GO
GO

/* ======================= [4/9] KHÁCH HÀNG MẪU (20) ======================= */
USE QuanLyDichVuAnUong;
GO
/* FoodService_ThemKhachHangMau.sql — thêm 10 tài khoản khách hàng mẫu (mật khẩu đăng nhập: 123456).
   Chạy sau FoodService_Database.sql (+ FoodService_NangCap.sql). Chạy lại nhiều lần vẫn an toàn: tài khoản đã có thì bỏ qua.
   Đăng nhập app bằng tên đăng nhập hoặc email ghi trong danh sách bên dưới (xem thêm Docs/TAI_KHOAN_KHACH_HANG_MAU.md). */
SET NOCOUNT ON;
DECLARE @Db sysname = N'QuanLyDichVuAnUong';
IF DB_ID(@Db) IS NULL
    THROW 50030, N'DỪNG: chưa có CSDL QuanLyDichVuAnUong. Chạy FoodService_Database.sql trước.', 1;
GO
USE QuanLyDichVuAnUong;
GO
SET NOCOUNT ON;
DECLARE @MatKhauHash NVARCHAR(255) = N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu';   -- BCrypt của 123456
DECLARE @coEmailXacThuc BIT = CASE WHEN COL_LENGTH('TaiKhoan', 'EmailDaXacThuc') IS NULL THEN 0 ELSE 1 END;
DECLARE @khach TABLE (TenDangNhap NVARCHAR(50), HoTen NVARCHAR(100), SDT VARCHAR(15), Email VARCHAR(100), DiaChi NVARCHAR(255));
INSERT @khach VALUES
    (N'khachlan', N'Nguyễn Thị Lan', '0901234501', 'khachlan@foodapp.vn', N'12 Nguyễn Huệ, Q.1, TP.HCM'),
    (N'khachminh', N'Trần Quang Minh', '0901234502', 'khachminh@foodapp.vn', N'45 Cách Mạng Tháng 8, Q.3, TP.HCM'),
    (N'khachhoa', N'Lê Thị Hoa', '0901234503', 'khachhoa@foodapp.vn', N'88 Nguyễn Trãi, Q.5, TP.HCM'),
    (N'khachduc', N'Phạm Văn Đức', '0901234504', 'khachduc@foodapp.vn', N'23 Lý Tự Trọng, Q.1, TP.HCM'),
    (N'khachmai', N'Võ Ngọc Mai', '0901234505', 'khachmai@foodapp.vn', N'67 Phan Đăng Lưu, Q.Phú Nhuận, TP.HCM'),
    (N'khachtuan', N'Đặng Anh Tuấn', '0901234506', 'khachtuan@foodapp.vn', N'150 Điện Biên Phủ, Q.Bình Thạnh, TP.HCM'),
    (N'khachthao', N'Bùi Thanh Thảo', '0901234507', 'khachthao@foodapp.vn', N'9 Hoàng Văn Thụ, Q.Tân Bình, TP.HCM'),
    (N'khachkhoa', N'Hoàng Minh Khoa', '0901234508', 'khachkhoa@foodapp.vn', N'31 Lê Quang Định, Q.Bình Thạnh, TP.HCM'),
    (N'khachnga', N'Ngô Thị Nga', '0901234509', 'khachnga@foodapp.vn', N'204 Võ Thị Sáu, Q.3, TP.HCM'),
    (N'khachhung', N'Đỗ Mạnh Hùng', '0901234510', 'khachhung@foodapp.vn', N'77 Trần Hưng Đạo, Q.5, TP.HCM'),
    (N'khachphuong', N'Trịnh Thu Phương', '0901234511', 'khachphuong@foodapp.vn', N'101 Nguyễn Văn Linh, Q.7, TP.HCM'),
    (N'khachlong', N'Lý Hoàng Long', '0901234512', 'khachlong@foodapp.vn', N'36 Tôn Đản, Q.4, TP.HCM'),
    (N'khachyen', N'Phan Hải Yến', '0901234513', 'khachyen@foodapp.vn', N'58 Kinh Dương Vương, Q.6, TP.HCM'),
    (N'khachbao', N'Dương Gia Bảo', '0901234514', 'khachbao@foodapp.vn', N'22 Phạm Hùng, Q.8, TP.HCM'),
    (N'khachtrang', N'Mai Thùy Trang', '0901234515', 'khachtrang@foodapp.vn', N'120 Lê Đại Hành, Q.11, TP.HCM'),
    (N'khachvinh', N'Cao Quốc Vinh', '0901234516', 'khachvinh@foodapp.vn', N'14 Nguyễn Ảnh Thủ, Q.12, TP.HCM'),
    (N'khachquynh', N'Tạ Như Quỳnh', '0901234517', 'khachquynh@foodapp.vn', N'73 Phan Văn Trị, Q.Gò Vấp, TP.HCM'),
    (N'khachdat', N'Lâm Tiến Đạt', '0901234518', 'khachdat@foodapp.vn', N'205 Trường Chinh, Q.Tân Bình, TP.HCM'),
    (N'khachchi', N'Vương Kim Chi', '0901234519', 'khachchi@foodapp.vn', N'11 Đặng Văn Bi, TP.Thủ Đức, TP.HCM'),
    (N'khachson', N'Huỳnh Thái Sơn', '0901234520', 'khachson@foodapp.vn', N'64 Nguyễn Oanh, Q.Gò Vấp, TP.HCM');

DECLARE @u NVARCHAR(50), @ten NVARCHAR(100), @sdt VARCHAR(15), @em VARCHAR(100), @dc NVARCHAR(255), @maTK INT, @tong INT = 0;
DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT TenDangNhap, HoTen, SDT, Email, DiaChi FROM @khach;
OPEN c; FETCH NEXT FROM c INTO @u, @ten, @sdt, @em, @dc;
WHILE @@FETCH_STATUS = 0
BEGIN
    IF NOT EXISTS (SELECT 1 FROM TaiKhoan WHERE TenDangNhap = @u)
    BEGIN
        INSERT INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro) VALUES (@u, @MatKhauHash, N'KhachHang');
        SET @maTK = SCOPE_IDENTITY();
        IF @coEmailXacThuc = 1 EXEC sp_executesql N'UPDATE TaiKhoan SET EmailDaXacThuc = 1 WHERE MaTK = @m', N'@m INT', @m = @maTK;
        INSERT INTO KhachHang (MaTK, HoTen, SDT, Email, DiaChiGiaoHang) VALUES (@maTK, @ten, @sdt, @em, @dc);
        SET @tong += 1; PRINT N'Đã thêm: ' + @ten + N' (' + @u + N')';
    END
    FETCH NEXT FROM c INTO @u, @ten, @sdt, @em, @dc;
END
CLOSE c; DEALLOCATE c;
PRINT N'Hoàn tất: thêm ' + CAST(@tong AS NVARCHAR(10)) + N' khách hàng mẫu (mật khẩu 123456).';
GO
GO

/* ======================= [5/9] GIAN HÀNG MẪU (20) ======================= */
USE QuanLyDichVuAnUong;
GO
/* FoodService_ThemGianHangMau.sql — thêm 10 gian hàng mẫu đã duyệt (mật khẩu đăng nhập: 123456).
   Chạy sau FoodService_Database.sql + FoodService_NangCap.sql (cần cột GianHang.Email, TaiKhoan.EmailDaXacThuc). Chạy lại nhiều lần vẫn an toàn.
   ĐÃ SỬA: trước đây 10 khối INSERT tham chiếu thẳng cột Email / EmailDaXacThuc; CSDL cũ chưa nâng cấp (hoặc chạy nhầm CSDL) sẽ báo hàng loạt lỗi
   "Invalid column name ...". Nay script kiểm tra CSDL + các cột cần thiết trước và DỪNG với hướng dẫn rõ; việc chèn chạy bằng SQL động trong
   đúng CSDL nên không còn lỗi biên dịch giả. */
SET NOCOUNT ON;
DECLARE @Db sysname = N'QuanLyDichVuAnUong';

IF DB_ID(@Db) IS NULL
    THROW 50020, N'DỪNG: chưa có CSDL QuanLyDichVuAnUong. Chạy FoodService_Database.sql (máy mới) hoặc FoodService_NangCap.sql trước.', 1;

DECLARE @can TABLE (Bang sysname, Cot sysname);
INSERT @can VALUES
    (N'TaiKhoan', N'TenDangNhap'), (N'TaiKhoan', N'MatKhau'), (N'TaiKhoan', N'VaiTro'), (N'TaiKhoan', N'EmailDaXacThuc'),
    (N'GianHang', N'MaTK'), (N'GianHang', N'TenCuaHang'), (N'GianHang', N'DiaChi'), (N'GianHang', N'SDT'), (N'GianHang', N'MoTa'),
    (N'GianHang', N'Email'), (N'GianHang', N'TrangThaiKinhDoanh'), (N'GianHang', N'TrangThaiDuyet');
DECLARE @thieu NVARCHAR(MAX) = N'';
SELECT @thieu = @thieu + N'  - ' + Bang + N'.' + Cot + NCHAR(10)
FROM @can WHERE COL_LENGTH(QUOTENAME(@Db) + N'.dbo.' + QUOTENAME(Bang), Cot) IS NULL;
IF @thieu <> N''
BEGIN
    SET @thieu = N'DỪNG: CSDL chưa nâng cấp đủ, còn thiếu:' + NCHAR(10) + LEFT(@thieu, 1300)
               + N'=> SAO LƯU CSDL rồi chạy Database/FoodService_NangCap.sql (không xóa dữ liệu), sau đó chạy lại file này.';
    THROW 50021, @thieu, 1;
END

DECLARE @MatKhauHash NVARCHAR(255) = N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu';   -- BCrypt của 123456
DECLARE @quan TABLE (TenDangNhap NVARCHAR(100), Ten NVARCHAR(200), DiaChi NVARCHAR(300), SDT VARCHAR(20), MoTa NVARCHAR(500), Email VARCHAR(150));
INSERT @quan VALUES
    (N'bunchahuonglien', N'Bún Chả Hương Liên', N'27 Lê Văn Sỹ, Q.3, TP.HCM', '0968881347', N'Bún chả, nem rán Hà Nội', 'bunchahuonglien@foodapp.vn'),
    (N'comgauthien', N'Cơm Gà Xối Mỡ Út Hiền', N'64 Lý Thường Kiệt, Q.10, TP.HCM', '0993957772', N'Cơm gà xối mỡ giòn da', 'comgauthien@foodapp.vn'),
    (N'banhxeo2lua', N'Bánh Xèo Miền Tây Hai Lúa', N'109 Võ Văn Tần, Q.3, TP.HCM', '0950322955', N'Bánh xèo, bánh khọt giòn rụm', 'banhxeo2lua@foodapp.vn'),
    (N'miquangbamua', N'Mì Quảng Bà Mua', N'31 Phan Xích Long, Q.Phú Nhuận, TP.HCM', '0971165393', N'Mì Quảng, bún mắm nêm', 'miquangbamua@foodapp.vn'),
    (N'sushikohaku', N'Sushi Kohaku', N'15 Lê Thánh Tôn, Q.1, TP.HCM', '0993934431', N'Sushi, sashimi, cơm cuộn', 'sushikohaku@foodapp.vn'),
    (N'pizzamama', N'Pizza Nhà Làm Mama', N'82 Nguyễn Thị Minh Khai, Q.3, TP.HCM', '0973185837', N'Pizza đế mỏng, mì Ý sốt bò bằm', 'pizzamama@foodapp.vn'),
    (N'caphemuoipho', N'Cà Phê Muối Phố Cổ', N'7 Pasteur, Q.1, TP.HCM', '0928133569', N'Cà phê muối, bạc xỉu, cold brew', 'caphemuoipho@foodapp.vn'),
    (N'lauthaibangkok', N'Lẩu Thái Tomyum Bangkok', N'240 Nguyễn Văn Cừ, Q.5, TP.HCM', '0951633055', N'Lẩu Thái, gà nướng sả', 'lauthaibangkok@foodapp.vn'),
    (N'xoigacotu', N'Xôi Gà Nướng Cô Tư', N'58 Tô Hiến Thành, Q.10, TP.HCM', '0936168676', N'Xôi mặn, gà nướng mật ong', 'xoigacotu@foodapp.vn'),
    (N'kemtraicay', N'Kem Trái Cây Mát Lạnh', N'9 Nguyễn Thượng Hiền, Q.3, TP.HCM', '0941547797', N'Kem, sinh tố, trái cây dĩa', 'kemtraicay@foodapp.vn'),
    (N'hutieunamvang', N'Hủ Tiếu Nam Vang Cô Ba', N'215 Nguyễn Trãi, Q.1, TP.HCM', '0930008019', N'Hủ tiếu Nam Vang, mì xá xíu', 'hutieunamvang@foodapp.vn'),
    (N'banhmihoaima', N'Bánh Mì Hòa Mã', N'53 Trần Phú, Q.4, TP.HCM', '0930015938', N'Bánh mì thịt nướng, xíu mại, pate', 'banhmihoaima@foodapp.vn'),
    (N'chegiaiphong', N'Chè Sương Sa Hạt Lựu', N'12 Hậu Giang, Q.6, TP.HCM', '0930023857', N'Chè thái, sương sa hạt lựu, chè khúc bạch', 'chegiaiphong@foodapp.vn'),
    (N'bunbohue7', N'Bún Bò Huế O Tâm', N'88 Nguyễn Thị Thập, Q.7, TP.HCM', '0930031776', N'Bún bò Huế, giò heo, chả cua', 'bunbohue7@foodapp.vn'),
    (N'comtamq8', N'Cơm Tấm Sườn Bì Chả Q8', N'141 Phạm Thế Hiển, Q.8, TP.HCM', '0930039695', N'Cơm tấm sườn nướng, bì, chả trứng', 'comtamq8@foodapp.vn'),
    (N'banhcuonq11', N'Bánh Cuốn Nóng Thanh Trì', N'30 Lạc Long Quân, Q.11, TP.HCM', '0930047614', N'Bánh cuốn nóng, chả lụa, nem chua', 'banhcuonq11@foodapp.vn'),
    (N'trasuaq12', N'Trà Sữa Mây Hồng', N'76 Quang Trung, Q.12, TP.HCM', '0930055533', N'Trà sữa, trà trái cây, hồng trà macchiato', 'trasuaq12@foodapp.vn'),
    (N'ocgovap', N'Ốc Đêm Gò Vấp', N'205 Quang Trung, Q.Gò Vấp, TP.HCM', '0930063452', N'Ốc các loại, sò điệp nướng mỡ hành', 'ocgovap@foodapp.vn'),
    (N'phobotanbinh', N'Phở Bò Tái Lăn Tân Bình', N'18 Cộng Hòa, Q.Tân Bình, TP.HCM', '0930071371', N'Phở tái lăn, phở gà, quẩy', 'phobotanbinh@foodapp.vn'),
    (N'bunthitnuongtd', N'Bún Thịt Nướng Thủ Đức', N'92 Võ Văn Ngân, TP.Thủ Đức, TP.HCM', '0930079290', N'Bún thịt nướng, chả giò, nem nướng', 'bunthitnuongtd@foodapp.vn');

DECLARE @u NVARCHAR(100), @ten NVARCHAR(200), @dc NVARCHAR(300), @sdt VARCHAR(20), @mt NVARCHAR(500), @em VARCHAR(150);
DECLARE @them NVARCHAR(MAX) = N'USE ' + QUOTENAME(@Db) + N';
IF NOT EXISTS (SELECT 1 FROM TaiKhoan WHERE TenDangNhap = @u)
BEGIN
    INSERT INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro, EmailDaXacThuc) VALUES (@u, @h, N''GianHang'', 1);
    INSERT INTO GianHang (MaTK, TenCuaHang, DiaChi, SDT, MoTa, Email, TrangThaiKinhDoanh, TrangThaiDuyet)
    VALUES (SCOPE_IDENTITY(), @ten, @dc, @sdt, @mt, @em, N''DangMo'', N''DaDuyet'');
    SET @moi = 1;
END';
DECLARE @moi INT, @tong INT = 0;
DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT TenDangNhap, Ten, DiaChi, SDT, MoTa, Email FROM @quan;
OPEN c; FETCH NEXT FROM c INTO @u, @ten, @dc, @sdt, @mt, @em;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @moi = 0;
    EXEC sp_executesql @them,
         N'@u NVARCHAR(100), @h NVARCHAR(255), @ten NVARCHAR(200), @dc NVARCHAR(300), @sdt VARCHAR(20), @mt NVARCHAR(500), @em VARCHAR(150), @moi INT OUTPUT',
         @u = @u, @h = @MatKhauHash, @ten = @ten, @dc = @dc, @sdt = @sdt, @mt = @mt, @em = @em, @moi = @moi OUTPUT;
    IF @moi = 1 BEGIN SET @tong += 1; PRINT N'Đã thêm: ' + @ten; END
    FETCH NEXT FROM c INTO @u, @ten, @dc, @sdt, @mt, @em;
END
CLOSE c; DEALLOCATE c;
PRINT N'Hoàn tất: thêm mới ' + CAST(@tong AS NVARCHAR(10)) + N' / 20 gian hàng (những quán đã có sẵn được giữ nguyên).';
GO

/* Ảnh + món mẫu cho "Bún Chả Hương Liên" (ảnh nằm ở Web/FoodServiceApp.Web/wwwroot/uploads/bun_cha.jpg). Chạy lại an toàn.
   ĐÃ SỬA (lỗi "Invalid object name 'GianHang' / 'DanhMuc' / 'MonAn'", "Invalid column name 'MaGianHang' / 'Email' / 'HinhAnh'..."):
   khối này nằm SAU lệnh GO nên chạy ở CSDL đang mở (thường là master) chứ không phải QuanLyDichVuAnUong, và vẫn chạy cả khi phần trên đã DỪNG.
   Nay nó chạy bằng SQL động trong đúng CSDL và tự bỏ qua nếu CSDL / cột Email chưa có. */
SET NOCOUNT ON;
IF DB_ID(N'QuanLyDichVuAnUong') IS NULL OR COL_LENGTH(N'QuanLyDichVuAnUong.dbo.GianHang', N'Email') IS NULL
    PRINT N'Bỏ qua ảnh + món mẫu: chưa có CSDL QuanLyDichVuAnUong hoặc chưa nâng cấp (thiếu GianHang.Email). Chạy FoodService_NangCap.sql rồi chạy lại file này.';
ELSE
BEGIN
    DECLARE @sqlMon NVARCHAR(MAX) = N'USE [QuanLyDichVuAnUong];
    DECLARE @ghBunCha INT = (SELECT MaGianHang FROM GianHang WHERE Email = ''bunchahuonglien@foodapp.vn'');
    IF @ghBunCha IS NOT NULL
    BEGIN
        UPDATE GianHang SET HinhAnh = N''/uploads/bun_cha.jpg'' WHERE MaGianHang = @ghBunCha;
        DECLARE @dmBunCha INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang = @ghBunCha AND TenDanhMuc = N''Món chính'');
        IF @dmBunCha IS NULL
        BEGIN
            INSERT INTO DanhMuc (MaGianHang, TenDanhMuc) VALUES (@ghBunCha, N''Món chính'');
            SET @dmBunCha = SCOPE_IDENTITY();
        END
        IF NOT EXISTS (SELECT 1 FROM MonAn WHERE MaDanhMuc = @dmBunCha AND TenMon = N''Bún chả nem rán'')
            INSERT INTO MonAn (MaDanhMuc, TenMon, Gia, MoTa, HinhAnh)
            VALUES (@dmBunCha, N''Bún chả nem rán'', 52000, N''Chả viên nướng than hoa, nem rán giòn, bún tươi, nước chấm chua ngọt'', N''/uploads/bun_cha.jpg'');
        IF NOT EXISTS (SELECT 1 FROM MonAn WHERE MaDanhMuc = @dmBunCha AND TenMon = N''Bún chả đặc biệt'')
            INSERT INTO MonAn (MaDanhMuc, TenMon, Gia, MoTa, HinhAnh)
            VALUES (@dmBunCha, N''Bún chả đặc biệt'', 65000, N''Chả viên + chả miếng, nem rán, rau sống đầy đủ'', N''/uploads/bun_cha.jpg'');
    END';
    EXEC sp_executesql @sqlMon;
    PRINT N'Đã kiểm tra / thêm ảnh + món mẫu cho Bún Chả Hương Liên.';
END
GO
GO

/* ======================= [6/9] SIZE CHO MÓN NƯỚC (ThemSizeNuoc) ======================= */
USE QuanLyDichVuAnUong;
GO
/* Thêm Size S/M/L cho món nước chưa có Size (chạy lặp an toàn; mở lại app để tải lại thực đơn). */
/* Thêm tùy chọn Size (S / M / L) cho các món nước chưa có Size.
   Chạy nhiều lần an toàn (bỏ qua món đã có Size). Sau khi chạy, mở lại app để tải lại thực đơn.
   Muốn đổi giá phụ thu hoặc tên size: sửa trong gian hàng (Sửa món → Size) hoặc sửa các số bên dưới. */
SET NOCOUNT ON;

;WITH MonNuoc AS (
    SELECT m.MaMonAn
    FROM MonAn m
    JOIN DanhMuc d ON d.MaDanhMuc = m.MaDanhMuc
    WHERE (d.TenDanhMuc LIKE N'%uống%' OR d.TenDanhMuc LIKE N'%Trà%' OR d.TenDanhMuc LIKE N'%Cà phê%'
           OR d.TenDanhMuc LIKE N'%Đá xay%' OR d.TenDanhMuc LIKE N'%Sinh tố%' OR d.TenDanhMuc LIKE N'%Sữa chua%'
           OR d.TenDanhMuc LIKE N'%Nước ngọt%')
      AND NOT EXISTS (SELECT 1 FROM TuyChonMon t WHERE t.MaMonAn = m.MaMonAn AND t.Loai = N'Size')
)
INSERT INTO TuyChonMon (MaMonAn, Loai, TenTuyChon, GiaThem)
SELECT n.MaMonAn, N'Size', v.Ten, v.GiaThem
FROM MonNuoc n
CROSS JOIN (VALUES (N'S', 0), (N'M', 5000), (N'L', 10000)) AS v(Ten, GiaThem);

SELECT COUNT(DISTINCT MaMonAn) AS SoMonCoSize FROM TuyChonMon WHERE Loai = N'Size';
GO
GO

/* ======================= [7/9] SỬA TÀI KHOẢN / MỞ KHÓA ======================= */
/* ============================================================
   FoodService_SuaTaiKhoan_MoKhoa.sql
   Sửa lỗi: tài khoản bị khóa hàng loạt / admin không đăng nhập được / "Mở khóa" gian hàng báo lỗi 500.
   - Đảm bảo bảng AuditLog + trigger trg_Audit_TaiKhoan chuẩn (thiếu/lệch thì UPDATE TaiKhoan lỗi 500)
   - Mở lại tài khoản mẫu từng bị BaoMat_VoHieuHoaTaiKhoanMau.sql vô hiệu hóa (trả mật khẩu mẫu theo vai trò)
   - Mở khóa mọi gian hàng, gỡ khóa tạm do nhập sai nhiều lần
   - Đặt admin app: admin@fooddelivery.vn / admin123 ; web: quantri01 / admin123
   Chạy lại nhiều lần an toàn. Không xóa dữ liệu. Lỗi nào cũng rollback và in rõ nguyên nhân.
   ============================================================ */
USE QuanLyDichVuAnUong;

IF DB_NAME() <> N'QuanLyDichVuAnUong' OR OBJECT_ID('TaiKhoan', 'U') IS NULL
BEGIN
    RAISERROR(N'DỪNG: không vào được CSDL QuanLyDichVuAnUong hoặc thiếu bảng TaiKhoan. Kiểm tra lại Server name (localdb)\MSSQLLocalDB.', 16, 1);
    RETURN;
END

BEGIN TRY
    /* 1) Bảng AuditLog */
    IF OBJECT_ID('AuditLog', 'U') IS NULL
    BEGIN
        CREATE TABLE AuditLog (
            MaAudit   BIGINT IDENTITY(1,1) PRIMARY KEY,
            ThoiGian  DATETIME2(3) NOT NULL DEFAULT SYSDATETIME(),
            MaTK      INT NULL,
            HanhDong  NVARCHAR(10) NOT NULL,
            Bang      NVARCHAR(60) NOT NULL,
            KhoaChinh NVARCHAR(50) NOT NULL,
            GiaTriCu  NVARCHAR(MAX) NULL,
            GiaTriMoi NVARCHAR(MAX) NULL
        );
        PRINT N'Đã tạo bảng AuditLog';
    END

    /* 2) Trigger audit của TaiKhoan (bản chuẩn, không ghi mật khẩu) */
    EXEC(N'CREATE OR ALTER TRIGGER trg_Audit_TaiKhoan ON TaiKhoan AFTER INSERT, UPDATE, DELETE AS
    BEGIN
        SET NOCOUNT ON;
        DECLARE @tk INT = TRY_CAST(SESSION_CONTEXT(N''MaTK'') AS INT);
        INSERT INTO AuditLog (MaTK, HanhDong, Bang, KhoaChinh, GiaTriCu, GiaTriMoi)
        SELECT @tk,
               CASE WHEN d.MaTK IS NULL THEN N''INSERT'' WHEN i.MaTK IS NULL THEN N''DELETE'' ELSE N''UPDATE'' END,
               N''TaiKhoan'', CAST(COALESCE(i.MaTK, d.MaTK) AS NVARCHAR(50)),
               CASE WHEN d.MaTK IS NULL THEN NULL
                    ELSE (SELECT d.TenDangNhap, d.VaiTro, d.TrangThai FOR JSON PATH, WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES) END,
               CASE WHEN i.MaTK IS NULL THEN NULL
                    ELSE (SELECT i.TenDangNhap, i.VaiTro, i.TrangThai,
                                 CAST(CASE WHEN d.MaTK IS NOT NULL AND i.MatKhau <> d.MatKhau THEN 1 ELSE 0 END AS BIT) AS DoiMatKhau
                          FOR JSON PATH, WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES) END
        FROM inserted i FULL OUTER JOIN deleted d ON i.MaTK = d.MaTK
        WHERE d.MaTK IS NULL OR i.MaTK IS NULL
           OR i.TrangThai <> d.TrangThai OR i.VaiTro <> d.VaiTro OR i.TenDangNhap <> d.TenDangNhap OR i.MatKhau <> d.MatKhau;
    END');

    /* 3) Khôi phục / mở khóa tài khoản */
    BEGIN TRAN;

    DECLARE @KhongDungDuoc NVARCHAR(255) = N'$2b$11$TAI.KHOAN.MAU.DA.BI.VO.HIEU.HOA.HAY.DAT.LAI.MAT.KHAU';
    DECLARE @Hash123456    NVARCHAR(255) = N'$2b$11$/kiGvUEE4J218RaDaW8cReCEE3eH53tJBuwpXN5FzQc/BPWr3MHMO'; -- = 123456
    DECLARE @HashAdmin123  NVARCHAR(255) = N'$2b$11$4W4e54I7Wm8IZICGB5WG5eJicrEVilueK2EWGeKHOeTK/8ZNZnzzW'; -- = admin123

    -- 3a) Tài khoản mẫu từng bị vô hiệu hóa: mở lại + trả mật khẩu theo vai trò
    UPDATE TaiKhoan
    SET TrangThai = 1,
        MatKhau = CASE WHEN VaiTro = N'QuanTri' THEN @HashAdmin123 ELSE @Hash123456 END
    WHERE MatKhau = @KhongDungDuoc;

    -- 3b) Mở khóa TẤT CẢ gian hàng
    UPDATE TaiKhoan SET TrangThai = 1 WHERE VaiTro = N'GianHang';

    -- 3c) Gỡ khóa tạm do nhập sai nhiều lần (chỉ khi có đủ 2 cột)
    IF COL_LENGTH('TaiKhoan', 'SoLanDangNhapSai') IS NOT NULL AND COL_LENGTH('TaiKhoan', 'KhoaDen') IS NOT NULL
        EXEC(N'UPDATE TaiKhoan SET SoLanDangNhapSai = 0, KhoaDen = NULL');

    -- 3d) Admin app: admin@fooddelivery.vn / admin123
    DECLARE @maTK INT = (SELECT MaTK FROM TaiKhoan WHERE TenDangNhap = N'quantri01');
    IF @maTK IS NOT NULL
    BEGIN
        UPDATE QuanTri SET Email = 'admin_cu_' + CAST(MaTK AS VARCHAR(10)) + '@fooddelivery.vn'
        WHERE Email = 'admin@fooddelivery.vn' AND MaTK <> @maTK;
        UPDATE QuanTri SET Email = 'admin@fooddelivery.vn' WHERE MaTK = @maTK;
        UPDATE TaiKhoan SET TrangThai = 1, MatKhau = @HashAdmin123 WHERE MaTK = @maTK;
    END
    ELSE PRINT N'Cảnh báo: không thấy tài khoản quantri01';

    COMMIT;
    PRINT N'>>> XONG phần sửa tài khoản, không có lỗi.';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    PRINT N'>>> LỖI SQL (gửi dòng này cho mình): ' + ERROR_MESSAGE()
        + N' | Dòng: ' + CAST(ERROR_LINE() AS NVARCHAR(10))
        + N' | Thủ tục/trigger: ' + ISNULL(ERROR_PROCEDURE(), N'(không có)');
    THROW;
END CATCH

/* 4) Kiểm tra kết quả */
SELECT VaiTro, COUNT(*) AS Tong,
       SUM(CASE WHEN TrangThai = 1 THEN 1 ELSE 0 END) AS DangHoatDong,
       SUM(CASE WHEN TrangThai = 0 THEN 1 ELSE 0 END) AS DangKhoa
FROM TaiKhoan GROUP BY VaiTro;

SELECT q.MaTK, tk.TenDangNhap, q.Email, q.CapQuyenHan, tk.TrangThai
FROM QuanTri q JOIN TaiKhoan tk ON tk.MaTK = q.MaTK;

IF OBJECT_ID('NhatKyHeThong', 'U') IS NOT NULL
    EXEC(N'SELECT TOP 5 ThoiGian, ThongDiep, DuongDan FROM NhatKyHeThong WHERE MucDo = ''Error'' ORDER BY ThoiGian DESC');
GO

/* ======================= [8/9] BaoMat_VoHieuHoaTaiKhoanMau (XEM TRƯỚC - không khóa gì) ======================= */
USE QuanLyDichVuAnUong;
GO
/* CHẾ ĐỘ XEM TRƯỚC: mặc định @QuanTriGiuLai và @HashMoi để TRỐNG nên script CHỈ LIỆT KÊ tài khoản mẫu (không khóa, không sửa gì).
   KHÔNG điền hai biến này khi đang dev/demo: nếu điền, tất cả tài khoản mẫu bị khóa và đổi mật khẩu (từng là nguyên nhân app báo 'Đã khóa' hàng loạt). */
/* ============================================================
   BaoMat_VoHieuHoaTaiKhoanMau.sql — CHẠY TRƯỚC KHI ĐƯA LÊN MÔI TRƯỜNG THẬT
   Dữ liệu mẫu (FoodService_Database.sql) có tài khoản dùng mật khẩu demo công khai (123456 / admin123).
   Script này, trên CSDL QuanLyDichVuAnUong đang có:
     1) Khóa (TrangThai = 0) mọi tài khoản còn mật khẩu mẫu hoặc còn mật khẩu rõ (chưa BCrypt),
        và đặt mật khẩu thành giá trị không đăng nhập được.
     2) Đặt mật khẩu mới cho MỘT quản trị để bạn còn vào hệ thống: @QuanTriGiuLai + @HashMoi.
   Tạo @HashMoi (BCrypt) bằng lệnh:   dotnet run --project Web/FoodServiceApp.Web -- --hash "MatKhauMoiManh"
   (Đã bỏ SET NOEXEC ON: dùng RETURN để dừng, tránh lỗi biên dịch giả và việc NOEXEC còn "dính" sang các script khác trong cùng cửa sổ.)
   Script KHÔNG xóa dữ liệu; chạy lại được nhiều lần. Nên SAO LƯU trước (xem FoodService_NghiemThu_SaoLuu.sql).
   ============================================================ */
USE QuanLyDichVuAnUong;
GO

DECLARE @DbHienTai sysname = DB_NAME();
IF @DbHienTai <> N'QuanLyDichVuAnUong'
BEGIN
    RAISERROR(N'DỪNG: chưa có/không vào được CSDL QuanLyDichVuAnUong (đang ở: %s).', 16, 1, @DbHienTai);
    RETURN;
END

DECLARE @QuanTriGiuLai NVARCHAR(100) = N'';     -- <<< TenDangNhap của quản trị muốn giữ lại (xem bảng TaiKhoan, VaiTro = N'QuanTri')
DECLARE @HashMoi       NVARCHAR(255) = N'';     -- <<< BCrypt hash mật khẩu mới (bắt đầu bằng $2)

IF @QuanTriGiuLai = N'' OR LEFT(@HashMoi, 2) <> N'$2'
BEGIN
    -- CHƯA điền → chỉ XEM TRƯỚC (không sửa gì, không báo lỗi đỏ): liệt kê tài khoản sẽ bị khóa và quản trị có thể giữ lại.
    PRINT N'CHẾ ĐỘ XEM TRƯỚC — chưa thay đổi gì. Để thực sự khóa tài khoản mẫu: điền @QuanTriGiuLai (xem bảng "Quản trị có thể giữ lại" bên dưới)';
    PRINT N'và @HashMoi (BCrypt, bắt đầu bằng $2; tạo bằng: dotnet run --project Web/FoodServiceApp.Web -- --hash "MatKhauMoiManh") rồi chạy lại.';
    SELECT TenDangNhap AS [Quản trị có thể giữ lại], TrangThai FROM TaiKhoan WHERE VaiTro = N'QuanTri';
    SELECT TenDangNhap AS [Tài khoản sẽ bị khóa], VaiTro FROM TaiKhoan
    WHERE MatKhau IN (N'123456', N'admin123',
                      N'$2b$11$/kiGvUEE4J218RaDaW8cReCEE3eH53tJBuwpXN5FzQc/BPWr3MHMO',
                      N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu',
                      N'$2b$11$OEARrK8p.cB1O2wFsKq.j.2mAuC/7.MsCfpubv6AXzRqwqG9QDkaS',
                      N'$2b$11$4W4e54I7Wm8IZICGB5WG5eJicrEVilueK2EWGeKHOeTK/8ZNZnzzW');
    RETURN;
END

IF NOT EXISTS (SELECT 1 FROM TaiKhoan WHERE TenDangNhap = @QuanTriGiuLai AND VaiTro = N'QuanTri')
BEGIN
    RAISERROR(N'DỪNG: không có tài khoản quản trị tên đó.', 16, 1);
    RETURN;
END

-- Mật khẩu không thể đăng nhập (không phải BCrypt hợp lệ -> so khớp luôn sai)
DECLARE @KhongDungDuoc NVARCHAR(255) = N'$2b$11$TAI.KHOAN.MAU.DA.BI.VO.HIEU.HOA.HAY.DAT.LAI.MAT.KHAU';

UPDATE TaiKhoan
SET MatKhau = @KhongDungDuoc, TrangThai = 0
WHERE TenDangNhap <> @QuanTriGiuLai
  AND (MatKhau IN (N'123456', N'admin123')                                   -- mật khẩu rõ kiểu cũ
       OR MatKhau IN (N'$2b$11$/kiGvUEE4J218RaDaW8cReCEE3eH53tJBuwpXN5FzQc/BPWr3MHMO',   -- hash của 123456 (PHẦN 6/7 của file mẫu: khách, quán, tài xế)
                      N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu',   -- hash mẫu ban đầu của PHẦN 2-4 (bị PHẦN 6 ghi đè, liệt kê cho đủ)
                      N'$2b$11$OEARrK8p.cB1O2wFsKq.j.2mAuC/7.MsCfpubv6AXzRqwqG9QDkaS',   -- hash của admin123 (quản trị)
                      N'$2b$11$4W4e54I7Wm8IZICGB5WG5eJicrEVilueK2EWGeKHOeTK/8ZNZnzzW')); -- hash quản trị ban đầu của PHẦN 2-4

UPDATE TaiKhoan SET MatKhau = @HashMoi, TrangThai = 1 WHERE TenDangNhap = @QuanTriGiuLai AND VaiTro = N'QuanTri';

SELECT N'Đã khóa' AS KetQua, COUNT(*) AS SoTaiKhoan FROM TaiKhoan WHERE MatKhau = @KhongDungDuoc
UNION ALL SELECT N'Còn hoạt động', COUNT(*) FROM TaiKhoan WHERE TrangThai = 1;
GO
GO

/* ======================= [9/9] FoodService_NghiemThu_SaoLuu (để dạng comment) ======================= */
/* Để DẠNG COMMENT có chủ ý: PHẦN A cần đặt @MaDon của đơn chạy thử và ném lỗi khi có FAIL; PHẦN B sao lưu ghi file ra ổ đĩa / cần SQL Server Agent.
   Muốn dùng: chạy riêng Database/FoodService_NghiemThu_SaoLuu.sql (Tools/NghiemThu_E2E.ps1 cũng đọc file đó). */
-- /* ============================================================
--    FoodService_NghiemThu_SaoLuu.sql — gồm 2 phần:
--    PHẦN A: NGHIỆM THU dữ liệu (dùng cùng Tools/NghiemThu_E2E.ps1 — script chỉ chạy PHẦN A, cắt ở dòng đánh dấu SAO_LUU_PHUC_HOI)
--    PHẦN B: SAO LƯU / PHỤC HỒI (SQL Server Agent) — chạy thủ công trong SSMS, KHÔNG nằm trong luồng nghiệm thu
--    ============================================================ */
--
-- /* ################ PHẦN A: NGHIỆM THU ################ */
-- /* NGHIỆM THU DỮ LIỆU sau khi chạy kịch bản end-to-end. Đặt @MaDon rồi chạy (SSMS hoặc Tools\NghiemThu_E2E.ps1).
--    Mỗi dòng trả về KetQua = PASS/FAIL. Kết thúc bằng THROW nếu có FAIL (sqlcmd -b trả mã lỗi).
--    ĐÃ SỬA (lỗi "Invalid column name 'MaDonHang' / 'TrangThai' / 'MaTaiXe' / 'MaXacNhanGiao' / 'SoLanSaiMa'"):
--      - Trước đây các câu kiểm tra được biên dịch ngay; nếu CSDL đang mở là bản CŨ (thiếu cột) hoặc đang ở sai CSDL thì báo hàng loạt lỗi cột.
--        Nay script (1) kiểm tra CSDL tồn tại, (2) kiểm tra đủ bảng/cột cần thiết bằng COL_LENGTH và DỪNG với danh sách còn thiếu
--        + hướng dẫn chạy FoodService_NangCap.sql, (3) chỉ khi đủ mới chạy các câu kiểm tra (bằng SQL động, trong đúng CSDL).
--      - Không dùng "USE" và không dùng SET NOEXEC, nên không còn lỗi biên dịch giả; chạy ở CSDL nào cũng được. */
-- SET NOCOUNT ON;
-- DECLARE @MaDon INT = NULL;   -- đặt mã đơn cần kiểm tra (NULL = đơn ĐÃ GIAO mới nhất)
-- DECLARE @Db sysname = N'QuanLyDichVuAnUong';
--
-- IF DB_ID(@Db) IS NULL
--     THROW 50010, N'DỪNG: chưa có CSDL QuanLyDichVuAnUong. Chạy FoodService_Database.sql (máy mới) hoặc FoodService_NangCap.sql trước.', 1;
--
-- -- Các bảng/cột mà PHẦN A cần (CSDL cũ chưa chạy FoodService_NangCap.sql sẽ thiếu một số cột)
-- DECLARE @can TABLE (Bang sysname, Cot sysname NULL);
-- INSERT @can (Bang, Cot) VALUES
--  (N'NhatKyHeThong', NULL),
--  (N'ChiTietDonHang', NULL),
--  (N'ChiTietDonHang', N'DonGia'),
--  (N'ChiTietDonHang', N'MaDonHang'),
--  (N'ChiTietDonHang', N'SoLuong'),
--  (N'DanhGia', NULL),
--  (N'DanhGia', N'MaDonHang'),
--  (N'DanhGia', N'MaGianHang'),
--  (N'DanhGia', N'MaKH'),
--  (N'DanhGia', N'MaTaiXe'),
--  (N'DonHang', NULL),
--  (N'DonHang', N'MaDonHang'),
--  (N'DonHang', N'MaGianHang'),
--  (N'DonHang', N'MaKH'),
--  (N'DonHang', N'MaTaiXe'),
--  (N'DonHang', N'MaXacNhanGiao'),
--  (N'DonHang', N'PhiGiaoHang'),
--  (N'DonHang', N'SoLanSaiMa'),
--  (N'DonHang', N'ThoiGianSanSang'),
--  (N'DonHang', N'TienGiam'),
--  (N'DonHang', N'TongTien'),
--  (N'DonHang', N'TrangThai'),
--  (N'DonHang', N'TrangThaiChuanBi'),
--  (N'GiaoDichThanhToan', NULL),
--  (N'GiaoDichThanhToan', N'MaDonHang'),
--  (N'GiaoHang', NULL),
--  (N'GiaoHang', N'MaDonHang'),
--  (N'GiaoHang', N'ThoiGianGiao'),
--  (N'GiaoHang', N'ThoiGianLayHang'),
--  (N'GiaoHang', N'ThoiGianNhan'),
--  (N'GiaoHang', N'TienThuCOD'),
--  (N'GiaoHang', N'TrangThai'),
--  (N'KhachHang', NULL),
--  (N'KhachHang', N'MaKH'),
--  (N'KhachHang', N'MaTK'),
--  (N'LichSuGiaoHang', NULL),
--  (N'LichSuGiaoHang', N'MaDonHang'),
--  (N'LichSuTrangThaiDon', NULL),
--  (N'LichSuTrangThaiDon', N'DenTrangThai'),
--  (N'LichSuTrangThaiDon', N'MaDonHang'),
--  (N'TaiXe', NULL),
--  (N'TaiXe', N'MaTaiXe'),
--  (N'TaiXe', N'TrangThai'),
--  (N'TaiXeViTri', NULL),
--  (N'TaiXeViTri', N'MaDonHang'),
--  (N'ThanhToan', NULL),
--  (N'ThanhToan', N'HinhThuc'),
--  (N'ThanhToan', N'MaDonHang'),
--  (N'ThanhToan', N'TrangThai'),
--  (N'ThongBao', NULL),
--  (N'ThongBao', N'MaTK'),
--  (N'ThongBao', N'MaThamChieu');
--
-- DECLARE @thieu NVARCHAR(MAX) = N'';
-- SELECT @thieu = @thieu + N'  - ' + Bang + ISNULL(N'.' + Cot, N' (bảng)') + NCHAR(10)
-- FROM @can
-- WHERE (Cot IS NULL     AND OBJECT_ID(QUOTENAME(@Db) + N'.dbo.' + QUOTENAME(Bang), N'U') IS NULL)
--    OR (Cot IS NOT NULL AND COL_LENGTH(QUOTENAME(@Db) + N'.dbo.' + QUOTENAME(Bang), Cot) IS NULL);
-- IF @thieu <> N''
-- BEGIN
--     SET @thieu = N'DỪNG: CSDL chưa nâng cấp đủ, còn thiếu:' + NCHAR(10) + LEFT(@thieu, 1300)
--                + N'=> SAO LƯU CSDL rồi chạy Database/FoodService_NangCap.sql (không xóa dữ liệu), sau đó chạy lại nghiệm thu.';
--     THROW 50011, @thieu, 1;
-- END
--
-- IF OBJECT_ID('tempdb..#kq') IS NOT NULL DROP TABLE #kq;
-- CREATE TABLE #kq (Muc NVARCHAR(120), KetQua NVARCHAR(4), ChiTiet NVARCHAR(300));
--
-- -- Các câu kiểm tra chạy bằng SQL động trong đúng CSDL (bảng tạm #kq nhìn thấy được từ bên trong)
-- DECLARE @sql NVARCHAR(MAX) = N'DECLARE @tt NVARCHAR(20), @gh NVARCHAR(20), @tx INT, @ma NVARCHAR(10), @sai INT;
-- -- Mặc định nghiệm thu đơn MỚI NHẤT ĐÃ GIAO (ưu tiên đơn có đánh giá), không lấy đơn mới nhất bất kỳ (đơn đang dở sẽ FAIL oan).
-- IF @MaDon IS NULL SET @MaDon = (SELECT MAX(d.MaDonHang) FROM DonHang d WHERE d.TrangThai = N''DaGiao'' AND EXISTS (SELECT 1 FROM DanhGia g WHERE g.MaDonHang = d.MaDonHang));
-- IF @MaDon IS NULL SET @MaDon = (SELECT MAX(MaDonHang) FROM DonHang WHERE TrangThai = N''DaGiao'');
-- IF @MaDon IS NULL AND EXISTS (SELECT 1 FROM DonHang)
-- BEGIN
--     RAISERROR(N''Chưa có đơn nào đã GIAO để nghiệm thu (các đơn hiện có đang dở). Hãy chạy hết luồng: đặt đơn → quán xác nhận → tài xế nhận → giao xong → khách đánh giá, rồi chạy lại.'', 16, 1);
--     RETURN;
-- END
-- IF @MaDon IS NULL
-- BEGIN
--     RAISERROR(N''Chưa có đơn hàng nào để nghiệm thu. Hãy chạy kịch bản end-to-end trước (đặt đơn → quán xác nhận → tài xế nhận → giao xong → khách đánh giá) rồi chạy lại.'', 16, 1);
--     RETURN;
-- END
-- PRINT N''Đang kiểm tra đơn #'' + CAST(@MaDon AS NVARCHAR(20)) + N''. Mục FAIL xem ở tab Results (nhớ: đơn phải đi hết luồng tới DaGiao + có đánh giá thì mới PASS hết).'';
-- SELECT @tt = TrangThai, @tx = MaTaiXe, @ma = MaXacNhanGiao, @sai = SoLanSaiMa FROM DonHang WHERE MaDonHang = @MaDon;
-- INSERT #kq SELECT N''Đơn tồn tại và ở trạng thái DaGiao'', IIF(@tt = N''DaGiao'',''PASS'',''FAIL''), N''TrangThai='' + ISNULL(@tt,''NULL'');
-- INSERT #kq SELECT N''Đơn có tài xế'', IIF(@tx IS NOT NULL,''PASS'',''FAIL''), CAST(@tx AS NVARCHAR(20));
--
-- SELECT @gh = TrangThai FROM GiaoHang WHERE MaDonHang = @MaDon;
-- INSERT #kq SELECT N''Đúng 1 GiaoHang, trạng thái GiaoThanhCong'', IIF((SELECT COUNT(*) FROM GiaoHang WHERE MaDonHang=@MaDon)=1 AND @gh=N''GiaoThanhCong'',''PASS'',''FAIL''), ISNULL(@gh,''NULL'');
-- INSERT #kq SELECT N''GiaoHang có đủ mốc nhận/lấy/giao theo thứ tự'', IIF(EXISTS(SELECT 1 FROM GiaoHang WHERE MaDonHang=@MaDon AND ThoiGianNhan IS NOT NULL AND ThoiGianLayHang IS NOT NULL AND ThoiGianGiao IS NOT NULL AND ThoiGianNhan<=ThoiGianLayHang AND ThoiGianLayHang<=ThoiGianGiao),''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Quán đã báo sẵn sàng giao'', IIF(EXISTS(SELECT 1 FROM DonHang WHERE MaDonHang=@MaDon AND TrangThaiChuanBi=N''SanSangGiao'' AND ThoiGianSanSang IS NOT NULL),''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Đúng 1 ThanhToan'', IIF((SELECT COUNT(*) FROM ThanhToan WHERE MaDonHang=@MaDon)=1,''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''COD đã thu: ThanhToan=DaThanhToan và TienThuCOD = TongTien'', IIF(EXISTS(SELECT 1 FROM ThanhToan t JOIN DonHang d ON d.MaDonHang=t.MaDonHang JOIN GiaoHang g ON g.MaDonHang=d.MaDonHang WHERE d.MaDonHang=@MaDon AND t.HinhThuc=N''TienMat'' AND t.TrangThai=N''DaThanhToan'' AND g.TienThuCOD=d.TongTien),''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Tổng tiền = tiền món - giảm + phí giao'', IIF(EXISTS(SELECT 1 FROM DonHang d WHERE d.MaDonHang=@MaDon AND d.TongTien = (SELECT ISNULL(SUM(SoLuong * DonGia),0) FROM ChiTietDonHang WHERE MaDonHang=@MaDon) - ISNULL(d.TienGiam,0) + d.PhiGiaoHang),''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Có chi tiết đơn'', IIF(EXISTS(SELECT 1 FROM ChiTietDonHang WHERE MaDonHang=@MaDon),''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Lịch sử trạng thái đơn ghi đủ ChoXacNhan→DaXacNhan→DangGiao→DaGiao'', IIF((SELECT COUNT(DISTINCT DenTrangThai) FROM LichSuTrangThaiDon WHERE MaDonHang=@MaDon AND DenTrangThai IN (N''ChoXacNhan'',N''DaXacNhan'',N''DangGiao'',N''DaGiao''))=4,''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Lịch sử giao hàng ghi các bước'', IIF((SELECT COUNT(*) FROM LichSuGiaoHang WHERE MaDonHang=@MaDon)>=3,''PASS'',''FAIL''), CAST((SELECT COUNT(*) FROM LichSuGiaoHang WHERE MaDonHang=@MaDon) AS NVARCHAR(10));
-- INSERT #kq SELECT N''Sổ giao dịch thanh toán có dòng cho đơn'', IIF((SELECT COUNT(*) FROM GiaoDichThanhToan WHERE MaDonHang=@MaDon)>=1,''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Vị trí tài xế đã lưu'', IIF(EXISTS(SELECT 1 FROM TaiXeViTri WHERE MaDonHang=@MaDon),''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Số lần nhập sai mã <= 5 (không bị khóa)'', IIF(@sai<=5,''PASS'',''FAIL''), CAST(@sai AS NVARCHAR(10));
-- INSERT #kq SELECT N''Đánh giá gắn đúng khách/quán/tài xế'', IIF(EXISTS(SELECT 1 FROM DanhGia d WHERE d.MaDonHang=@MaDon AND d.MaTaiXe=@tx AND d.MaGianHang=(SELECT MaGianHang FROM DonHang WHERE MaDonHang=@MaDon) AND d.MaKH=(SELECT MaKH FROM DonHang WHERE MaDonHang=@MaDon)),''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Chỉ 1 đánh giá cho đơn'', IIF((SELECT COUNT(*) FROM DanhGia WHERE MaDonHang=@MaDon)=1,''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Khách có thông báo về đơn'', IIF(EXISTS(SELECT 1 FROM ThongBao tb JOIN KhachHang k ON k.MaTK=tb.MaTK JOIN DonHang d ON d.MaKH=k.MaKH WHERE d.MaDonHang=@MaDon AND tb.MaThamChieu=CAST(@MaDon AS NVARCHAR(20))),''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Tài xế trở lại SanSang (không kẹt DangGiao)'', IIF(EXISTS(SELECT 1 FROM TaiXe WHERE MaTaiXe=@tx AND TrangThai IN (N''SanSang'',N''NgoaiTuyen'')),''PASS'',''FAIL''), ISNULL((SELECT TrangThai FROM TaiXe WHERE MaTaiXe=@tx),'''');
-- INSERT #kq SELECT N''Thu nhập: chuyến này tính vào doanh thu tài xế (GiaoThanhCong)'', IIF(EXISTS(SELECT 1 FROM GiaoHang WHERE MaDonHang=@MaDon AND TrangThai=N''GiaoThanhCong''),''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Nhật ký thao tác quản trị tồn tại (bảng NhatKyHeThong)'', IIF(OBJECT_ID(''NhatKyHeThong'',''U'') IS NOT NULL,''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Không có tài xế kẹt DangGiao mà không có chuyến'', IIF(NOT EXISTS(SELECT 1 FROM TaiXe t WHERE t.TrangThai=N''DangGiao'' AND NOT EXISTS(SELECT 1 FROM DonHang d WHERE d.MaTaiXe=t.MaTaiXe AND d.TrangThai IN (N''DaXacNhan'',N''DangGiao''))),''PASS'',''FAIL''), N'''';
-- INSERT #kq SELECT N''Không có đơn DaXacNhan/DangGiao bị 2 GiaoHang'', IIF(NOT EXISTS(SELECT MaDonHang FROM GiaoHang GROUP BY MaDonHang HAVING COUNT(*)>1),''PASS'',''FAIL''), N'''';';
-- SET @sql = N'USE ' + QUOTENAME(@Db) + N'; ' + @sql;
-- EXEC sp_executesql @sql, N'@MaDon INT OUTPUT', @MaDon = @MaDon OUTPUT;
--
-- IF NOT EXISTS (SELECT 1 FROM #kq) RETURN;      -- chưa có đơn nào để nghiệm thu (đã báo lỗi ở trên)
-- SELECT * FROM #kq;
-- IF EXISTS (SELECT 1 FROM #kq WHERE KetQua='FAIL') THROW 50001, N'Có mục kiểm tra dữ liệu KHÔNG ĐẠT', 1;
--
-- /* ---- Truy vấn kiểm tra nhanh (từ Tools/03_BoSung.sql, 04_table.sql) — bỏ "-- " để chạy ---- */
-- -- SELECT COUNT(*) FROM GianHang;
-- -- SELECT COUNT(*) FROM MonAn;
-- -- SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE
-- -- FROM INFORMATION_SCHEMA.COLUMNS
-- -- ORDER BY TABLE_NAME, ORDINAL_POSITION;
-- GO
--
-- -- @@SAO_LUU_PHUC_HOI@@
-- /* ################ PHẦN B: SAO LƯU / PHỤC HỒI ################ */
-- /* ============================================================
--    SAO LƯU / PHỤC HỒI CSDL QuanLyDichVuAnUong
--    Chiến lược: Full mỗi đêm 02:00 + Differential mỗi 6 giờ + Log mỗi 15 phút (mất tối đa ~15 phút dữ liệu)
--    + dọn dữ liệu quá hạn lúc 03:00. Mục C cần SQL Server Agent (không có trên Express/LocalDB: tự bỏ qua, xem mục B/C).
--    ĐỔI @Dir sang thư mục có quyền ghi của tài khoản chạy SQL Server, và nên là ổ đĩa/NAS khác máy DB.
--
--    CÁCH CHẠY: PHẦN B KHÔNG tự chạy khi bấm Execute cả file. Muốn chạy, trước hết chạy RIÊNG lệnh sau trong CÙNG cửa sổ truy vấn:
--         EXEC sp_set_session_context @key = N'ChayPhanB', @value = 1;
--    rồi chạy phần cần dùng (hoặc cả file). Mỗi khối dưới đây bắt đầu bằng "chốt" kiểm tra cờ đó và thoát nếu chưa bật.
--
--    ĐÃ SỬA (lỗi "Invalid object name 'msdb.dbo.sysjobs'", "Could not find stored procedure 'msdb.dbo.sp_add_job'",
--           "Invalid column name 'servicename' / 'status_desc'"): trước đây khóa PHẦN B bằng SET NOEXEC ON — chế độ này vẫn BIÊN DỊCH
--    toàn bộ lệnh nên trên LocalDB/Express (không có SQL Agent trong msdb) sinh hàng loạt lỗi giả. Nay không dùng NOEXEC; mọi lệnh
--    chạm tới msdb / sys.dm_server_services chỉ được gọi bằng SQL động / tên thủ tục trong biến SAU KHI đã kiểm tra có SQL Server Agent.
--    ============================================================ */
--
-- /* ---------- A. Thiết lập ---------- */
-- IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'ChayPhanB')), 0) <> 1
-- BEGIN
--     PRINT N'Bỏ qua PHẦN B (mục A): chưa bật cờ. Chạy trước: EXEC sp_set_session_context @key = N''ChayPhanB'', @value = 1;';
--     RETURN;
-- END
-- IF DB_ID(N'QuanLyDichVuAnUong') IS NOT NULL
--     ALTER DATABASE QuanLyDichVuAnUong SET RECOVERY FULL;     -- bắt buộc để sao lưu Log
-- GO
--
-- /* ---------- B. Sao lưu thủ công (chạy được trên mọi phiên bản, kể cả Express) ----------
--    (1) thư mục C:\Backup\FoodService chưa có → tự tạo, không được thì dùng thư mục sao lưu mặc định của SQL Server;
--    (2) bản Express không hỗ trợ COMPRESSION → chỉ dùng khi không phải Express. */
-- IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'ChayPhanB')), 0) <> 1
-- BEGIN
--     PRINT N'Bỏ qua PHẦN B (mục B): chưa bật cờ ChayPhanB.';
--     RETURN;
-- END
-- IF DB_ID(N'QuanLyDichVuAnUong') IS NULL
-- BEGIN
--     PRINT N'Bỏ qua mục B: chưa có CSDL QuanLyDichVuAnUong.';
--     RETURN;
-- END
-- DECLARE @Dir NVARCHAR(300) = N'C:\Backup\FoodService\';
-- BEGIN TRY
--     EXEC master.dbo.xp_create_subdir @Dir;
-- END TRY
-- BEGIN CATCH
--     SET @Dir = CAST(SERVERPROPERTY('InstanceDefaultBackupPath') AS NVARCHAR(300)) + N'\';
--     PRINT N'Không tạo được C:\Backup\FoodService, dùng thư mục mặc định: ' + @Dir;
-- END CATCH
-- DECLARE @nen NVARCHAR(30) = IIF(CAST(SERVERPROPERTY('EngineEdition') AS INT) = 4, N'', N'COMPRESSION, ');
-- DECLARE @f NVARCHAR(400) = @Dir + N'Full_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + N'.bak';
-- DECLARE @sql NVARCHAR(MAX) = N'BACKUP DATABASE QuanLyDichVuAnUong TO DISK = N''' + REPLACE(@f, N'''', N'''''')
--                            + N''' WITH ' + @nen + N'CHECKSUM, INIT, STATS = 10, NAME = N''FoodService Full'';';
-- EXEC(@sql);
-- RESTORE VERIFYONLY FROM DISK = @f WITH CHECKSUM;         -- kiểm tra file sao lưu đọc được
-- PRINT N'Đã sao lưu: ' + @f;
-- GO
--
-- /* Differential:
-- DECLARE @f NVARCHAR(400) = N'C:\Backup\FoodService\Diff_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + N'.bak';
-- BACKUP DATABASE QuanLyDichVuAnUong TO DISK = @f WITH DIFFERENTIAL, CHECKSUM, INIT;
--    Log:
-- DECLARE @f NVARCHAR(400) = N'C:\Backup\FoodService\Log_' + FORMAT(GETDATE(), 'yyyyMMdd_HHmmss') + N'.trn';
-- BACKUP LOG QuanLyDichVuAnUong TO DISK = @f WITH CHECKSUM, INIT;
-- */
--
-- /* ---------- C. Tạo lịch tự động bằng SQL Server Agent ----------
--    Chỉ chạy khi có SQL Server Agent đang chạy. Bản Express/LocalDB KHÔNG có Agent → mục này tự bỏ qua
--    (dùng Windows Task Scheduler + sqlcmd để sao lưu). */
-- IF ISNULL(TRY_CONVERT(INT, SESSION_CONTEXT(N'ChayPhanB')), 0) <> 1
-- BEGIN
--     PRINT N'Bỏ qua PHẦN B (mục C): chưa bật cờ ChayPhanB.';
--     RETURN;
-- END
-- IF CAST(SERVERPROPERTY('EngineEdition') AS INT) = 4
-- BEGIN
--     PRINT N'Bỏ qua mục C: bản Express/LocalDB không có SQL Server Agent.';
--     RETURN;
-- END
-- IF OBJECT_ID(N'msdb.dbo.sysjobs', N'U') IS NULL OR OBJECT_ID(N'msdb.dbo.sp_add_job', N'P') IS NULL
-- BEGIN
--     PRINT N'Bỏ qua mục C: msdb không có đối tượng SQL Server Agent (sysjobs / sp_add_job).';
--     RETURN;
-- END
--
-- -- Kiểm tra Agent đang chạy (SQL động: không biên dịch trên máy không có sys.dm_server_services)
-- DECLARE @agent INT = 0;
-- BEGIN TRY
--     EXEC sp_executesql
--         N'SELECT @n = COUNT(*) FROM sys.dm_server_services WHERE servicename LIKE N''SQL Server Agent%'' AND status_desc = N''Running'';',
--         N'@n INT OUTPUT', @n = @agent OUTPUT;
-- END TRY
-- BEGIN CATCH
--     SET @agent = 0;
-- END CATCH
-- IF @agent = 0
-- BEGIN
--     PRINT N'Bỏ qua mục C: SQL Server Agent chưa chạy (hoặc không đọc được trạng thái dịch vụ).';
--     RETURN;
-- END
--
-- DECLARE @Dir NVARCHAR(300) = N'C:\Backup\FoodService\';     -- phải trùng thư mục ở trên và đã tồn tại
-- DECLARE @DB  sysname = N'QuanLyDichVuAnUong';
--
-- DECLARE @jobs TABLE (Ten sysname, Lenh NVARCHAR(MAX), FreqType INT, FreqInterval INT, SubType INT, SubInterval INT, StartTime INT);
-- INSERT INTO @jobs VALUES
--  (N'FoodService - Full backup 02:00',
--   N'DECLARE @f NVARCHAR(400)=N''' + @Dir + N'Full_''+FORMAT(GETDATE(),''yyyyMMdd_HHmmss'')+N''.bak''; '
--   + N'BACKUP DATABASE ' + QUOTENAME(@DB) + N' TO DISK=@f WITH COMPRESSION, CHECKSUM, INIT; RESTORE VERIFYONLY FROM DISK=@f WITH CHECKSUM;',
--   4, 1, 1, 0, 020000),
--  (N'FoodService - Differential 6 gio',
--   N'DECLARE @f NVARCHAR(400)=N''' + @Dir + N'Diff_''+FORMAT(GETDATE(),''yyyyMMdd_HHmmss'')+N''.bak''; '
--   + N'BACKUP DATABASE ' + QUOTENAME(@DB) + N' TO DISK=@f WITH DIFFERENTIAL, COMPRESSION, CHECKSUM, INIT;',
--   4, 1, 8, 6, 080000),
--  (N'FoodService - Log backup 15 phut',
--   N'DECLARE @f NVARCHAR(400)=N''' + @Dir + N'Log_''+FORMAT(GETDATE(),''yyyyMMdd_HHmmss'')+N''.trn''; '
--   + N'BACKUP LOG ' + QUOTENAME(@DB) + N' TO DISK=@f WITH COMPRESSION, CHECKSUM, INIT;',
--   4, 1, 4, 15, 000500),
--  (N'FoodService - Don dep du lieu 03:00',
--   N'EXEC ' + QUOTENAME(@DB) + N'.dbo.sp_DonDepDuLieu;',
--   4, 1, 1, 0, 030000);
--
-- -- Gọi thủ tục msdb qua TÊN LƯU TRONG BIẾN: không bị ràng buộc/biên dịch khi chạy trên máy không có Agent
-- DECLARE @pJob sysname = N'msdb.dbo.sp_add_job',        @pStep sysname = N'msdb.dbo.sp_add_jobstep',
--         @pSch sysname = N'msdb.dbo.sp_add_jobschedule', @pSrv  sysname = N'msdb.dbo.sp_add_jobserver';
-- DECLARE @n sysname, @c NVARCHAR(MAX), @ft INT, @fi INT, @st INT, @si INT, @t INT, @co INT;
-- DECLARE jc CURSOR LOCAL FAST_FORWARD FOR SELECT Ten, Lenh, FreqType, FreqInterval, SubType, SubInterval, StartTime FROM @jobs;
-- OPEN jc; FETCH NEXT FROM jc INTO @n, @c, @ft, @fi, @st, @si, @t;
-- WHILE @@FETCH_STATUS = 0
-- BEGIN
--     SET @co = 0;
--     EXEC sp_executesql N'SELECT @k = COUNT(*) FROM msdb.dbo.sysjobs WHERE name = @ten;', N'@ten sysname, @k INT OUTPUT', @ten = @n, @k = @co OUTPUT;
--     IF @co = 0
--     BEGIN
--         EXEC @pJob  @job_name = @n, @enabled = 1;
--         EXEC @pStep @job_name = @n, @step_name = N'Chay', @subsystem = N'TSQL', @command = @c, @database_name = N'master';
--         EXEC @pSch  @job_name = @n, @name = N'Lich', @freq_type = @ft, @freq_interval = @fi,
--                     @freq_subday_type = @st, @freq_subday_interval = @si, @active_start_time = @t;
--         EXEC @pSrv  @job_name = @n;
--         PRINT N'Đã tạo job: ' + @n;
--     END
--     FETCH NEXT FROM jc INTO @n, @c, @ft, @fi, @st, @si, @t;
-- END
-- CLOSE jc; DEALLOCATE jc;
-- GO
--
-- /* ---------- D. Phục hồi (ví dụ) — CHẠY TỪNG BƯỚC, thay tên file cho đúng ----------
-- USE master;
-- ALTER DATABASE QuanLyDichVuAnUong SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
-- RESTORE DATABASE QuanLyDichVuAnUong FROM DISK = N'C:\Backup\FoodService\Full_20261007_020000.bak' WITH NORECOVERY, REPLACE;
-- RESTORE DATABASE QuanLyDichVuAnUong FROM DISK = N'C:\Backup\FoodService\Diff_20261007_080000.bak' WITH NORECOVERY;
-- RESTORE LOG      QuanLyDichVuAnUong FROM DISK = N'C:\Backup\FoodService\Log_20261007_081500.trn'  WITH NORECOVERY;
-- -- ... các file Log kế tiếp theo thứ tự; muốn dừng ở thời điểm cụ thể: WITH STOPAT = '2026-10-07 09:10:00', RECOVERY
-- RESTORE DATABASE QuanLyDichVuAnUong WITH RECOVERY;
-- ALTER DATABASE QuanLyDichVuAnUong SET MULTI_USER;
-- -- Nên thử phục hồi sang một DB tên khác (WITH MOVE ...) định kỳ để chắc chắn bản sao lưu dùng được.
-- -- Xóa file sao lưu cũ hơn 14 ngày: dùng Windows Task Scheduler/PowerShell (Get-ChildItem | Where LastWriteTime -lt (Get-Date).AddDays(-14) | Remove-Item).
-- */
GO

PRINT N'>>> HOÀN TẤT TOÀN BỘ. Đăng nhập app: admin@fooddelivery.vn / admin123';
GO
