﻿/* ============================================================
   BaoMat_VoHieuHoaTaiKhoanMau.sql — CHẠY TRƯỚC KHI ĐƯA LÊN MÔI TRƯỜNG THẬT
   Dữ liệu mẫu (FoodService_Database.sql) có tài khoản dùng mật khẩu demo công khai (123456 / admin123).
   Script này, trên CSDL QuanLyDichVuAnUong đang có:
     1) Khóa (TrangThai = 0) mọi tài khoản còn mật khẩu mẫu hoặc còn mật khẩu rõ (chưa BCrypt),
        và đặt mật khẩu thành giá trị không đăng nhập được.
     2) Đặt mật khẩu mới cho MỘT quản trị để bạn còn vào hệ thống: @QuanTriGiuLai + @HashMoi.
   Tạo @HashMoi (BCrypt) bằng lệnh:   dotnet run --project Web/FoodServiceApp.Web -- --hash "MatKhauMoiManh"
   (Đã bỏ SET NOEXEC ON: dùng RETURN để dừng, tránh lỗi biên dịch giả và việc NOEXEC còn "dính" sang các script khác trong cùng cửa sổ.)
   Script KHÔNG xóa dữ liệu; chạy lại được nhiều lần. Nên SAO LƯU trước (xem FoodService_NghiemThu_SaoLuu.sql).
   ============================================================ */
USE QuanLyDichVuAnUong;
GO

DECLARE @DbHienTai sysname = DB_NAME();
IF @DbHienTai <> N'QuanLyDichVuAnUong'
BEGIN
    RAISERROR(N'DỪNG: chưa có/không vào được CSDL QuanLyDichVuAnUong (đang ở: %s).', 16, 1, @DbHienTai);
    RETURN;
END

DECLARE @QuanTriGiuLai NVARCHAR(100) = N'';     -- <<< TenDangNhap của quản trị muốn giữ lại (xem bảng TaiKhoan, VaiTro = N'QuanTri')
DECLARE @HashMoi       NVARCHAR(255) = N'';     -- <<< BCrypt hash mật khẩu mới (bắt đầu bằng $2)

IF @QuanTriGiuLai = N'' OR LEFT(@HashMoi, 2) <> N'$2'
BEGIN
    -- CHƯA điền → chỉ XEM TRƯỚC (không sửa gì, không báo lỗi đỏ): liệt kê tài khoản sẽ bị khóa và quản trị có thể giữ lại.
    PRINT N'CHẾ ĐỘ XEM TRƯỚC — chưa thay đổi gì. Để thực sự khóa tài khoản mẫu: điền @QuanTriGiuLai (xem bảng "Quản trị có thể giữ lại" bên dưới)';
    PRINT N'và @HashMoi (BCrypt, bắt đầu bằng $2; tạo bằng: dotnet run --project Web/FoodServiceApp.Web -- --hash "MatKhauMoiManh") rồi chạy lại.';
    SELECT TenDangNhap AS [Quản trị có thể giữ lại], TrangThai FROM TaiKhoan WHERE VaiTro = N'QuanTri';
    SELECT TenDangNhap AS [Tài khoản sẽ bị khóa], VaiTro FROM TaiKhoan
    WHERE MatKhau IN (N'123456', N'admin123',
                      N'$2b$11$/kiGvUEE4J218RaDaW8cReCEE3eH53tJBuwpXN5FzQc/BPWr3MHMO',
                      N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu',
                      N'$2b$11$OEARrK8p.cB1O2wFsKq.j.2mAuC/7.MsCfpubv6AXzRqwqG9QDkaS',
                      N'$2b$11$4W4e54I7Wm8IZICGB5WG5eJicrEVilueK2EWGeKHOeTK/8ZNZnzzW');
    RETURN;
END

IF NOT EXISTS (SELECT 1 FROM TaiKhoan WHERE TenDangNhap = @QuanTriGiuLai AND VaiTro = N'QuanTri')
BEGIN
    RAISERROR(N'DỪNG: không có tài khoản quản trị tên đó.', 16, 1);
    RETURN;
END

-- Mật khẩu không thể đăng nhập (không phải BCrypt hợp lệ -> so khớp luôn sai)
DECLARE @KhongDungDuoc NVARCHAR(255) = N'$2b$11$TAI.KHOAN.MAU.DA.BI.VO.HIEU.HOA.HAY.DAT.LAI.MAT.KHAU';

UPDATE TaiKhoan
SET MatKhau = @KhongDungDuoc, TrangThai = 0
WHERE TenDangNhap <> @QuanTriGiuLai
  AND (MatKhau IN (N'123456', N'admin123')                                   -- mật khẩu rõ kiểu cũ
       OR MatKhau IN (N'$2b$11$/kiGvUEE4J218RaDaW8cReCEE3eH53tJBuwpXN5FzQc/BPWr3MHMO',   -- hash của 123456 (PHẦN 6/7 của file mẫu: khách, quán, tài xế)
                      N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu',   -- hash mẫu ban đầu của PHẦN 2-4 (bị PHẦN 6 ghi đè, liệt kê cho đủ)
                      N'$2b$11$OEARrK8p.cB1O2wFsKq.j.2mAuC/7.MsCfpubv6AXzRqwqG9QDkaS',   -- hash của admin123 (quản trị)
                      N'$2b$11$4W4e54I7Wm8IZICGB5WG5eJicrEVilueK2EWGeKHOeTK/8ZNZnzzW')); -- hash quản trị ban đầu của PHẦN 2-4

UPDATE TaiKhoan SET MatKhau = @HashMoi, TrangThai = 1 WHERE TenDangNhap = @QuanTriGiuLai AND VaiTro = N'QuanTri';

SELECT N'Đã khóa' AS KetQua, COUNT(*) AS SoTaiKhoan FROM TaiKhoan WHERE MatKhau = @KhongDungDuoc
UNION ALL SELECT N'Còn hoạt động', COUNT(*) FROM TaiKhoan WHERE TrangThai = 1;
GO
