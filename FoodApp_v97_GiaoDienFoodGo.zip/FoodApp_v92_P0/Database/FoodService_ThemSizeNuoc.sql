/* Thêm tùy chọn Size (S / M / L) cho các món nước chưa có Size.
   Chạy nhiều lần an toàn (bỏ qua món đã có Size). Sau khi chạy, mở lại app để tải lại thực đơn.
   Muốn đổi giá phụ thu hoặc tên size: sửa trong gian hàng (Sửa món → Size) hoặc sửa các số bên dưới. */
SET NOCOUNT ON;

;WITH MonNuoc AS (
    SELECT m.MaMonAn
    FROM MonAn m
    JOIN DanhMuc d ON d.MaDanhMuc = m.MaDanhMuc
    WHERE (d.TenDanhMuc LIKE N'%uống%' OR d.TenDanhMuc LIKE N'%Trà%' OR d.TenDanhMuc LIKE N'%Cà phê%'
           OR d.TenDanhMuc LIKE N'%Đá xay%' OR d.TenDanhMuc LIKE N'%Sinh tố%' OR d.TenDanhMuc LIKE N'%Sữa chua%'
           OR d.TenDanhMuc LIKE N'%Nước ngọt%')
      AND NOT EXISTS (SELECT 1 FROM TuyChonMon t WHERE t.MaMonAn = m.MaMonAn AND t.Loai = N'Size')
)
INSERT INTO TuyChonMon (MaMonAn, Loai, TenTuyChon, GiaThem)
SELECT n.MaMonAn, N'Size', v.Ten, v.GiaThem
FROM MonNuoc n
CROSS JOIN (VALUES (N'S', 0), (N'M', 5000), (N'L', 10000)) AS v(Ten, GiaThem);

SELECT COUNT(DISTINCT MaMonAn) AS SoMonCoSize FROM TuyChonMon WHERE Loai = N'Size';
GO
