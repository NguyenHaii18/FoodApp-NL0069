﻿/* Tách từ FoodService_DuLieuMau.sql [2/2] (bản v94: 20 khách hàng mẫu). Nội dung giữ nguyên. */
/* FoodService_ThemKhachHangMau.sql — thêm 10 tài khoản khách hàng mẫu (mật khẩu đăng nhập: 123456).
   Chạy sau FoodService_Database.sql (+ FoodService_NangCap.sql). Chạy lại nhiều lần vẫn an toàn: tài khoản đã có thì bỏ qua.
   Đăng nhập app bằng tên đăng nhập hoặc email ghi trong danh sách bên dưới (xem thêm Docs/TAI_KHOAN_KHACH_HANG_MAU.md). */
SET NOCOUNT ON;
DECLARE @Db sysname = N'QuanLyDichVuAnUong';
IF DB_ID(@Db) IS NULL
    THROW 50030, N'DỪNG: chưa có CSDL QuanLyDichVuAnUong. Chạy FoodService_Database.sql trước.', 1;
GO
USE QuanLyDichVuAnUong;
GO
SET NOCOUNT ON;
DECLARE @MatKhauHash NVARCHAR(255) = N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu';   -- BCrypt của 123456
DECLARE @coEmailXacThuc BIT = CASE WHEN COL_LENGTH('TaiKhoan', 'EmailDaXacThuc') IS NULL THEN 0 ELSE 1 END;
DECLARE @khach TABLE (TenDangNhap NVARCHAR(50), HoTen NVARCHAR(100), SDT VARCHAR(15), Email VARCHAR(100), DiaChi NVARCHAR(255));
INSERT @khach VALUES
    (N'khachlan', N'Nguyễn Thị Lan', '0901234501', 'khachlan@foodapp.vn', N'12 Nguyễn Huệ, Q.1, TP.HCM'),
    (N'khachminh', N'Trần Quang Minh', '0901234502', 'khachminh@foodapp.vn', N'45 Cách Mạng Tháng 8, Q.3, TP.HCM'),
    (N'khachhoa', N'Lê Thị Hoa', '0901234503', 'khachhoa@foodapp.vn', N'88 Nguyễn Trãi, Q.5, TP.HCM'),
    (N'khachduc', N'Phạm Văn Đức', '0901234504', 'khachduc@foodapp.vn', N'23 Lý Tự Trọng, Q.1, TP.HCM'),
    (N'khachmai', N'Võ Ngọc Mai', '0901234505', 'khachmai@foodapp.vn', N'67 Phan Đăng Lưu, Q.Phú Nhuận, TP.HCM'),
    (N'khachtuan', N'Đặng Anh Tuấn', '0901234506', 'khachtuan@foodapp.vn', N'150 Điện Biên Phủ, Q.Bình Thạnh, TP.HCM'),
    (N'khachthao', N'Bùi Thanh Thảo', '0901234507', 'khachthao@foodapp.vn', N'9 Hoàng Văn Thụ, Q.Tân Bình, TP.HCM'),
    (N'khachkhoa', N'Hoàng Minh Khoa', '0901234508', 'khachkhoa@foodapp.vn', N'31 Lê Quang Định, Q.Bình Thạnh, TP.HCM'),
    (N'khachnga', N'Ngô Thị Nga', '0901234509', 'khachnga@foodapp.vn', N'204 Võ Thị Sáu, Q.3, TP.HCM'),
    (N'khachhung', N'Đỗ Mạnh Hùng', '0901234510', 'khachhung@foodapp.vn', N'77 Trần Hưng Đạo, Q.5, TP.HCM'),
    (N'khachphuong', N'Trịnh Thu Phương', '0901234511', 'khachphuong@foodapp.vn', N'101 Nguyễn Văn Linh, Q.7, TP.HCM'),
    (N'khachlong', N'Lý Hoàng Long', '0901234512', 'khachlong@foodapp.vn', N'36 Tôn Đản, Q.4, TP.HCM'),
    (N'khachyen', N'Phan Hải Yến', '0901234513', 'khachyen@foodapp.vn', N'58 Kinh Dương Vương, Q.6, TP.HCM'),
    (N'khachbao', N'Dương Gia Bảo', '0901234514', 'khachbao@foodapp.vn', N'22 Phạm Hùng, Q.8, TP.HCM'),
    (N'khachtrang', N'Mai Thùy Trang', '0901234515', 'khachtrang@foodapp.vn', N'120 Lê Đại Hành, Q.11, TP.HCM'),
    (N'khachvinh', N'Cao Quốc Vinh', '0901234516', 'khachvinh@foodapp.vn', N'14 Nguyễn Ảnh Thủ, Q.12, TP.HCM'),
    (N'khachquynh', N'Tạ Như Quỳnh', '0901234517', 'khachquynh@foodapp.vn', N'73 Phan Văn Trị, Q.Gò Vấp, TP.HCM'),
    (N'khachdat', N'Lâm Tiến Đạt', '0901234518', 'khachdat@foodapp.vn', N'205 Trường Chinh, Q.Tân Bình, TP.HCM'),
    (N'khachchi', N'Vương Kim Chi', '0901234519', 'khachchi@foodapp.vn', N'11 Đặng Văn Bi, TP.Thủ Đức, TP.HCM'),
    (N'khachson', N'Huỳnh Thái Sơn', '0901234520', 'khachson@foodapp.vn', N'64 Nguyễn Oanh, Q.Gò Vấp, TP.HCM');

DECLARE @u NVARCHAR(50), @ten NVARCHAR(100), @sdt VARCHAR(15), @em VARCHAR(100), @dc NVARCHAR(255), @maTK INT, @tong INT = 0;
DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT TenDangNhap, HoTen, SDT, Email, DiaChi FROM @khach;
OPEN c; FETCH NEXT FROM c INTO @u, @ten, @sdt, @em, @dc;
WHILE @@FETCH_STATUS = 0
BEGIN
    IF NOT EXISTS (SELECT 1 FROM TaiKhoan WHERE TenDangNhap = @u)
    BEGIN
        INSERT INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro) VALUES (@u, @MatKhauHash, N'KhachHang');
        SET @maTK = SCOPE_IDENTITY();
        IF @coEmailXacThuc = 1 EXEC sp_executesql N'UPDATE TaiKhoan SET EmailDaXacThuc = 1 WHERE MaTK = @m', N'@m INT', @m = @maTK;
        INSERT INTO KhachHang (MaTK, HoTen, SDT, Email, DiaChiGiaoHang) VALUES (@maTK, @ten, @sdt, @em, @dc);
        SET @tong += 1; PRINT N'Đã thêm: ' + @ten + N' (' + @u + N')';
    END
    FETCH NEXT FROM c INTO @u, @ten, @sdt, @em, @dc;
END
CLOSE c; DEALLOCATE c;
PRINT N'Hoàn tất: thêm ' + CAST(@tong AS NVARCHAR(10)) + N' khách hàng mẫu (mật khẩu 123456).';
GO
