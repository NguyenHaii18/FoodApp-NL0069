﻿/* >>> BẬT Query > SQLCMD Mode trong SSMS trước khi chạy (file dùng :ON ERROR EXIT để dừng ngay khi có lỗi). <<<
   Nếu quên bật, khối dưới đây tự chặn toàn bộ file (không có gì bị thay đổi) và in hướng dẫn. */
:setvar __IsSqlCmdEnabled "True"
GO
IF N'$(__IsSqlCmdEnabled)' NOT LIKE N'True'
BEGIN
    PRINT N'>>> DỪNG: chưa bật SQLCMD Mode. Vào menu Query > SQLCMD Mode, rồi chạy lại. Chưa có gì bị thay đổi.';
    SET NOEXEC ON;
END
GO
:ON ERROR EXIT
GO
/* KIỂM TRA ĐIỀU KIỆN TRƯỚC KHI NÂNG CẤP.
   Nếu thiếu bảng gốc, dừng tại đây để tránh lỗi ALTER/FOREIGN KEY dây chuyền. */
USE master;
GO
IF DB_ID(N'QuanLyDichVuAnUong') IS NULL
    THROW 51020, N'DỪNG: Chưa có CSDL QuanLyDichVuAnUong. Hãy chạy FoodService_Database.sql trước.', 1;
GO
USE [QuanLyDichVuAnUong];
GO
DECLARE @BangCanCo TABLE (TenBang sysname NOT NULL PRIMARY KEY);
INSERT INTO @BangCanCo (TenBang) VALUES
    (N'TaiKhoan'), (N'KhachHang'), (N'GianHang'), (N'QuanTri'), (N'TaiXe'),
    (N'DanhMuc'), (N'MonAn'), (N'DonHang'), (N'ChiTietDonHang'),
    (N'KhuyenMai'), (N'DanhGia'), (N'GiaoHang'), (N'ThanhToan');
DECLARE @Thieu nvarchar(max);
SELECT @Thieu = STUFF((
    SELECT N', ' + b.TenBang
    FROM @BangCanCo AS b
    WHERE OBJECT_ID(N'dbo.' + b.TenBang, N'U') IS NULL
    ORDER BY b.TenBang
    FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 2, N'');
IF NULLIF(@Thieu, N'') IS NOT NULL
BEGIN
    DECLARE @ThongBao nvarchar(2048) =
        N'DỪNG: CSDL QuanLyDichVuAnUong đang thiếu bảng gốc: ' + @Thieu +
        N'. File nâng cấp không tạo các bảng nền này. Nếu CSDL mới/rỗng, chạy FoodService_Database.sql; nếu có dữ liệu cần giữ, không xóa DB, hãy khôi phục bản sao lưu hợp lệ hoặc gửi schema hiện tại để đối chiếu.';
    THROW 51021, @ThongBao, 1;
END;
GO

/* ============================================================
   FoodService_BoSung_ThietKe.sql
   BỔ SUNG CSDL THEO "6. Thiết kế cơ sở dữ liệu SQL"
   (Tài khoản – Khách hàng – Nhà hàng – Thực đơn – Tài xế – Đơn hàng – Giao hàng
    – Thanh toán – Khuyến mãi – Đánh giá – Thông báo – Hỗ trợ – Báo cáo)

   CÁCH CHẠY: chạy SAU FoodService_Database.sql (hoặc FoodService_NangCap.sql).
              Chạy lại nhiều lần an toàn (idempotent). KHÔNG sửa, KHÔNG xóa bảng/cột đang có.
              Chạy bằng SSMS, hoặc sqlcmd có cờ -I (bật QUOTED_IDENTIFIER cho chỉ mục có lọc).

   NGUYÊN TẮC: đề tài đã có ~55 bảng nên file này CHỈ THÊM phần còn thiếu, không tạo bảng thứ hai
   cho thứ đã có (tránh dữ liệu trùng lặp). Đối chiếu 37 bảng của đề bài ở mục 12 cuối file.

   ĐÃ CÓ SẴN (giữ nguyên, không tạo lại)          →  BẢNG MỚI TRONG FILE NÀY
   users            = TaiKhoan                         roles / permissions / user_roles
   customers        = KhachHang                          = VaiTro / Quyen (+VaiTro_Quyen) / TaiKhoan_VaiTro
   customer_addresses = DiaChiKhachHang                restaurant_branches = ChiNhanhGianHang
   restaurants      = GianHang                         restaurant_hours    = GioLamViecGianHang
   categories       = DanhMuc                          product_images      = HinhAnhMonAn
   products         = MonAn                            driver_vehicles     = PhuongTienTaiXe
   product_options  = TuyChonMon                       driver_documents    = GiayToTaiXe
   drivers          = TaiXe                            driver_locations    = LichSuViTriTaiXe
   orders / order_items = DonHang / ChiTietDonHang     delivery_assignments= PhanCongGiaoHang
   order_status_histories = LichSuTrangThaiDon         promotions          = ChuongTrinhKhuyenMai (+ _Voucher)
   deliveries       = GiaoHang                         notification_logs   = NhatKyThongBao
   payments / refunds / transactions                   support_tickets/messages = PhieuHoTro / TinNhanHoTro
     = ThanhToan / YeuCauHoanTien / GiaoDichThanhToan  settlements        = KyDoiSoat
   vouchers / voucher_usages                           restaurant_payouts  = ChiTraGianHang (+ChiTiet)
     = KhuyenMai / KhuyenMaiKhachDung                  driver_payouts      = ChiTraTaiXe (+ChiTiet)
   reviews / ratings = DanhGia / DanhGiaMon (+ 3 view điểm trung bình ở mục 10)
   notifications    = ThongBao

   LƯU Ý QUAN TRỌNG (đọc trước khi dùng):
   * Web/API hiện tại (EF Core) CHƯA biết các bảng mới. File này chỉ cung cấp lược đồ + thủ tục;
     muốn app ghi/đọc các bảng mới cần thêm entity + DbContext + sửa API (xem cuối file).
   * Vài chỗ có "bản cũ" mà app vẫn đang dùng (TaiXe.BienSo/SoCCCD/SoGPLX, PhanHoi, GianHang.GioMoCua...).
     Các thủ tục sp_DongBo... ở mục 11 nạp một chiều từ bản cũ sang bảng mới, chạy lại bao nhiêu lần cũng được.
   * KHÔNG tạo TRIGGER trên bảng đang có (EF Core lỗi khi INSERT vào bảng có trigger nếu không khai báo).
   ============================================================ */

USE QuanLyDichVuAnUong;
GO
SET NOCOUNT ON;
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

/* ============================================================
   1. TÀI KHOẢN: VaiTro, Quyen, VaiTro_Quyen, TaiKhoan_VaiTro
   Hiện trạng: TaiKhoan.VaiTro là chuỗi 1 giá trị; quyền admin là chuỗi QuanTri.QuyenChiTiet;
   quyền nhân viên quán là chuỗi NhanVienGianHang.Quyen. Bảng mới chuẩn hóa thành quan hệ nhiều-nhiều.
   (Quyền ghi đè từng người QuanTri.QuyenChiTiet vẫn do cột đó quản lý; view v_QuyenTaiKhoan là quyền theo vai trò.)
   ============================================================ */
IF OBJECT_ID('VaiTro', 'U') IS NULL
    CREATE TABLE VaiTro (
        MaVaiTro   INT IDENTITY(1,1) CONSTRAINT PK_VaiTro PRIMARY KEY,
        TenVaiTro  NVARCHAR(30)  NOT NULL CONSTRAINT UQ_VaiTro_Ten UNIQUE,
        LoaiVaiTro NVARCHAR(12)  NOT NULL CONSTRAINT DF_VaiTro_Loai DEFAULT N'TuyChinh'
                   CONSTRAINT CK_VaiTro_Loai CHECK (LoaiVaiTro IN (N'Goc', N'CapQuanTri', N'TuyChinh')),
                   -- Goc = trùng TaiKhoan.VaiTro; CapQuanTri = trùng QuanTri.CapQuyenHan; TuyChinh = tạo thêm
        MoTa       NVARCHAR(200) NULL,
        NgayTao    DATETIME      NOT NULL CONSTRAINT DF_VaiTro_NgayTao DEFAULT GETDATE()
    );
GO

IF OBJECT_ID('Quyen', 'U') IS NULL
    CREATE TABLE Quyen (
        MaQuyen   INT IDENTITY(1,1) CONSTRAINT PK_Quyen PRIMARY KEY,
        PhamVi    NVARCHAR(10)  NOT NULL CONSTRAINT CK_Quyen_PhamVi CHECK (PhamVi IN (N'QuanTri', N'GianHang')),
        KhoaQuyen NVARCHAR(40)  NOT NULL,      -- cùng khóa với code hiện tại (QuyenAdmin.cs / NhanVienGianHang.Quyen)
        TenQuyen  NVARCHAR(100) NOT NULL,
        CONSTRAINT UQ_Quyen UNIQUE (PhamVi, KhoaQuyen)
    );
GO

IF OBJECT_ID('VaiTro_Quyen', 'U') IS NULL
    CREATE TABLE VaiTro_Quyen (
        MaVaiTro INT NOT NULL CONSTRAINT FK_VaiTroQuyen_VaiTro REFERENCES VaiTro(MaVaiTro) ON DELETE CASCADE,
        MaQuyen  INT NOT NULL CONSTRAINT FK_VaiTroQuyen_Quyen  REFERENCES Quyen(MaQuyen)  ON DELETE CASCADE,
        CONSTRAINT PK_VaiTro_Quyen PRIMARY KEY (MaVaiTro, MaQuyen)
    );
GO

IF OBJECT_ID('TaiKhoan_VaiTro', 'U') IS NULL
BEGIN
    CREATE TABLE TaiKhoan_VaiTro (
        MaTK     INT NOT NULL CONSTRAINT FK_TKVaiTro_TaiKhoan REFERENCES TaiKhoan(MaTK) ON DELETE CASCADE,
        MaVaiTro INT NOT NULL CONSTRAINT FK_TKVaiTro_VaiTro   REFERENCES VaiTro(MaVaiTro),
        NgayCap  DATETIME NOT NULL CONSTRAINT DF_TKVaiTro_NgayCap DEFAULT GETDATE(),
        MaTKCap  INT NULL CONSTRAINT FK_TKVaiTro_NguoiCap REFERENCES TaiKhoan(MaTK),
        CONSTRAINT PK_TaiKhoan_VaiTro PRIMARY KEY (MaTK, MaVaiTro)
    );
    EXEC(N'CREATE INDEX IX_TKVaiTro_VaiTro ON TaiKhoan_VaiTro (MaVaiTro)');
END
GO

/* --- dữ liệu nền: vai trò + quyền (khớp code hiện tại) --- */
INSERT INTO VaiTro (TenVaiTro, LoaiVaiTro, MoTa)
SELECT v.Ten, v.Loai, v.MoTa
FROM (VALUES
    (N'KhachHang',  N'Goc',        N'Khách đặt món'),
    (N'GianHang',   N'Goc',        N'Chủ gian hàng / nhà hàng (đối tác)'),
    (N'TaiXe',      N'Goc',        N'Tài xế giao hàng'),
    (N'QuanTri',    N'Goc',        N'Quản trị viên (cấp cụ thể xem 3 vai trò bên dưới)'),
    (N'SuperAdmin', N'CapQuanTri', N'Admin tổng: mọi quyền'),
    (N'QuanLy',     N'CapQuanTri', N'Quản lý: đơn, thanh toán, hoàn tiền, đánh giá, thông báo'),
    (N'NhanVien',   N'CapQuanTri', N'Nhân viên: chỉ xem + xử lý phản hồi/sự cố (quyền thêm do Admin tổng cấp)')
) v (Ten, Loai, MoTa)
WHERE NOT EXISTS (SELECT 1 FROM VaiTro x WHERE x.TenVaiTro = v.Ten);
GO

INSERT INTO Quyen (PhamVi, KhoaQuyen, TenQuyen)
SELECT q.PhamVi, q.Khoa, q.Ten
FROM (VALUES
    (N'QuanTri',  N'DonHang',   N'Đơn hàng & điều phối'),
    (N'QuanTri',  N'ThanhToan', N'Giao dịch & đối soát'),
    (N'QuanTri',  N'HoanTien',  N'Duyệt hoàn tiền'),
    (N'QuanTri',  N'DanhGia',   N'Kiểm duyệt đánh giá'),
    (N'QuanTri',  N'ThongBao',  N'Thông báo & món ăn'),
    (N'GianHang', N'DonHang',   N'Xử lý đơn hàng'),
    (N'GianHang', N'ThucDon',   N'Quản lý thực đơn'),
    (N'GianHang', N'KhuyenMai', N'Quản lý khuyến mãi'),
    (N'GianHang', N'DanhGia',   N'Trả lời đánh giá'),
    (N'GianHang', N'TaiChinh',  N'Xem doanh thu / tài chính')
) q (PhamVi, Khoa, Ten)
WHERE NOT EXISTS (SELECT 1 FROM Quyen x WHERE x.PhamVi = q.PhamVi AND x.KhoaQuyen = q.Khoa);
GO

/* SuperAdmin + QuanLy: 5 quyền quản trị (QuyenAdmin.MacDinhQuanLy); GianHang: 5 quyền gian hàng; NhanVien: không có quyền mặc định */
INSERT INTO VaiTro_Quyen (MaVaiTro, MaQuyen)
SELECT v.MaVaiTro, q.MaQuyen
FROM VaiTro v
JOIN Quyen q ON (v.TenVaiTro IN (N'SuperAdmin', N'QuanLy') AND q.PhamVi = N'QuanTri')
             OR (v.TenVaiTro = N'GianHang' AND q.PhamVi = N'GianHang')
WHERE NOT EXISTS (SELECT 1 FROM VaiTro_Quyen x WHERE x.MaVaiTro = v.MaVaiTro AND x.MaQuyen = q.MaQuyen);
GO

/* Quyền theo vai trò của từng tài khoản (không gồm ghi đè QuanTri.QuyenChiTiet) */
CREATE OR ALTER VIEW v_QuyenTaiKhoan AS
SELECT tv.MaTK, t.TenDangNhap, v.TenVaiTro, q.PhamVi, q.KhoaQuyen, q.TenQuyen
FROM TaiKhoan_VaiTro tv
JOIN TaiKhoan  t ON t.MaTK = tv.MaTK
JOIN VaiTro    v ON v.MaVaiTro = tv.MaVaiTro
JOIN VaiTro_Quyen vq ON vq.MaVaiTro = v.MaVaiTro
JOIN Quyen     q ON q.MaQuyen = vq.MaQuyen;
GO

/* ============================================================
   2. NHÀ HÀNG: ChiNhanhGianHang (chi nhánh phụ), GioLamViecGianHang (giờ theo thứ trong tuần)
   - Trụ sở = chính bản ghi GianHang (địa chỉ, toạ độ, trạng thái đã có) -> KHÔNG chép sang bảng chi nhánh.
     View v_ChiNhanhTatCa gộp trụ sở + chi nhánh phụ.
   - Giờ mở cửa mặc định vẫn là GianHang.GioMoCua/GioDongCua; bảng mới chỉ ghi đè theo thứ/ca
     (thứ nào không có dòng nào thì dùng mặc định). View v_GioLamViecHieuLuc cho ra đủ 7 ngày/quán.
   ============================================================ */
IF OBJECT_ID('ChiNhanhGianHang', 'U') IS NULL
BEGIN
    CREATE TABLE ChiNhanhGianHang (
        MaChiNhanh  INT IDENTITY(1,1) CONSTRAINT PK_ChiNhanhGianHang PRIMARY KEY,
        MaGianHang  INT NOT NULL CONSTRAINT FK_ChiNhanh_GianHang REFERENCES GianHang(MaGianHang) ON DELETE CASCADE,
        TenChiNhanh NVARCHAR(150) NOT NULL,
        DiaChi      NVARCHAR(255) NOT NULL,
        SDT         VARCHAR(15)   NULL,
        ViDo        FLOAT NULL CONSTRAINT CK_ChiNhanh_ViDo  CHECK (ViDo  IS NULL OR ViDo  BETWEEN -90  AND 90),
        KinhDo      FLOAT NULL CONSTRAINT CK_ChiNhanh_KinhDo CHECK (KinhDo IS NULL OR KinhDo BETWEEN -180 AND 180),
        TrangThai   NVARCHAR(10)  NOT NULL CONSTRAINT DF_ChiNhanh_TrangThai DEFAULT N'DangMo'
                    CONSTRAINT CK_ChiNhanh_TrangThai CHECK (TrangThai IN (N'DangMo', N'DongCua', N'TamNgung')),
        NgayTao     DATETIME NOT NULL CONSTRAINT DF_ChiNhanh_NgayTao DEFAULT GETDATE(),
        CONSTRAINT UQ_ChiNhanh_Ten UNIQUE (MaGianHang, TenChiNhanh)
    );
    EXEC(N'CREATE INDEX IX_ChiNhanh_GianHang ON ChiNhanhGianHang (MaGianHang, TrangThai)');
END
GO

IF OBJECT_ID('GioLamViecGianHang', 'U') IS NULL
BEGIN
    CREATE TABLE GioLamViecGianHang (
        MaGio       INT IDENTITY(1,1) CONSTRAINT PK_GioLamViecGianHang PRIMARY KEY,
        MaGianHang  INT NOT NULL CONSTRAINT FK_GioLamViec_GianHang REFERENCES GianHang(MaGianHang) ON DELETE CASCADE,
        MaChiNhanh  INT NULL     CONSTRAINT FK_GioLamViec_ChiNhanh REFERENCES ChiNhanhGianHang(MaChiNhanh),
                    -- NULL = giờ của trụ sở (chính gian hàng)
        Thu         TINYINT NOT NULL CONSTRAINT CK_GioLamViec_Thu CHECK (Thu BETWEEN 1 AND 7),   -- 1 = Thứ Hai … 7 = Chủ nhật (cùng quy ước TaiXe.NgayThanhToanThu)
        GioMo       TIME(0) NULL,
        GioDong     TIME(0) NULL,                 -- GioDong < GioMo = quán qua nửa đêm (vd 18:00 → 02:00)
        NghiCaNgay  BIT NOT NULL CONSTRAINT DF_GioLamViec_Nghi DEFAULT 0,
        CONSTRAINT CK_GioLamViec_Gio CHECK (NghiCaNgay = 1 OR (GioMo IS NOT NULL AND GioDong IS NOT NULL AND GioMo <> GioDong)),
        CONSTRAINT UQ_GioLamViec UNIQUE (MaGianHang, MaChiNhanh, Thu, GioMo)
    );
    EXEC(N'CREATE INDEX IX_GioLamViec_GianHang ON GioLamViecGianHang (MaGianHang, Thu)');
END
GO

CREATE OR ALTER VIEW v_ChiNhanhTatCa AS
SELECT g.MaGianHang, CAST(NULL AS INT) AS MaChiNhanh, g.TenCuaHang AS TenChiNhanh, g.DiaChi, g.SDT,
       g.ViDo, g.KinhDo, CAST(1 AS BIT) AS LaTruSo, g.TrangThaiKinhDoanh AS TrangThai
FROM GianHang g
UNION ALL
SELECT c.MaGianHang, c.MaChiNhanh, c.TenChiNhanh, c.DiaChi, c.SDT,
       c.ViDo, c.KinhDo, CAST(0 AS BIT), c.TrangThai
FROM ChiNhanhGianHang c;
GO

CREATE OR ALTER VIEW v_GioLamViecHieuLuc AS    -- giờ của TRỤ SỞ, đủ 7 thứ cho mọi gian hàng
SELECT g.MaGianHang, d.Thu, h.GioMo, h.GioDong, h.NghiCaNgay, CAST(N'Lich' AS NVARCHAR(10)) AS Nguon
FROM GianHang g
CROSS JOIN (VALUES (1),(2),(3),(4),(5),(6),(7)) d (Thu)
JOIN GioLamViecGianHang h ON h.MaGianHang = g.MaGianHang AND h.MaChiNhanh IS NULL AND h.Thu = d.Thu
UNION ALL
SELECT g.MaGianHang, d.Thu, g.GioMoCua, g.GioDongCua, CAST(0 AS BIT), N'MacDinh'
FROM GianHang g
CROSS JOIN (VALUES (1),(2),(3),(4),(5),(6),(7)) d (Thu)
WHERE NOT EXISTS (SELECT 1 FROM GioLamViecGianHang h WHERE h.MaGianHang = g.MaGianHang AND h.MaChiNhanh IS NULL AND h.Thu = d.Thu);
GO

/* ============================================================
   3. THỰC ĐƠN: HinhAnhMonAn (thư viện ảnh phụ)
   Ảnh đại diện vẫn là MonAn.HinhAnh (không chép lại). View v_HinhAnhMon gộp cả hai.
   ============================================================ */
IF OBJECT_ID('HinhAnhMonAn', 'U') IS NULL
BEGIN
    CREATE TABLE HinhAnhMonAn (
        MaHinhAnh INT IDENTITY(1,1) CONSTRAINT PK_HinhAnhMonAn PRIMARY KEY,
        MaMonAn   INT NOT NULL CONSTRAINT FK_HinhAnhMon_MonAn REFERENCES MonAn(MaMonAn) ON DELETE CASCADE,
        DuongDan  NVARCHAR(500) NOT NULL,
        ChuThich  NVARCHAR(200) NULL,
        ThuTu     INT NOT NULL CONSTRAINT DF_HinhAnhMon_ThuTu DEFAULT 0,
        NgayTao   DATETIME NOT NULL CONSTRAINT DF_HinhAnhMon_NgayTao DEFAULT GETDATE()
    );
    EXEC(N'CREATE INDEX IX_HinhAnhMon_Mon ON HinhAnhMonAn (MaMonAn, ThuTu)');
END
GO

CREATE OR ALTER VIEW v_HinhAnhMon AS
SELECT m.MaMonAn, CAST(NULL AS INT) AS MaHinhAnh, m.HinhAnh AS DuongDan, CAST(1 AS BIT) AS LaAnhChinh, 0 AS ThuTu
FROM MonAn m WHERE m.HinhAnh IS NOT NULL AND m.HinhAnh <> N''
UNION ALL
SELECT h.MaMonAn, h.MaHinhAnh, h.DuongDan, CAST(0 AS BIT), h.ThuTu
FROM HinhAnhMonAn h;
GO

/* ============================================================
   4. TÀI XẾ: PhuongTienTaiXe, GiayToTaiXe, LichSuViTriTaiXe
   TaiXe.PhuongTien/BienSo/SoCCCD/SoGPLX/AnhGPLX là bản cũ app đang dùng; mục 11 nạp một chiều sang bảng mới.
   TaiXeViTri (có sẵn) chỉ giữ vị trí MỚI NHẤT THEO ĐƠN; LichSuViTriTaiXe giữ lịch sử theo tài xế (kể cả lúc rảnh).
   ============================================================ */
IF OBJECT_ID('PhuongTienTaiXe', 'U') IS NULL
BEGIN
    CREATE TABLE PhuongTienTaiXe (
        MaPhuongTien INT IDENTITY(1,1) CONSTRAINT PK_PhuongTienTaiXe PRIMARY KEY,
        MaTaiXe      INT NOT NULL CONSTRAINT FK_PhuongTien_TaiXe REFERENCES TaiXe(MaTaiXe) ON DELETE CASCADE,
        LoaiXe       NVARCHAR(50) NOT NULL CONSTRAINT DF_PhuongTien_Loai DEFAULT N'Xe máy',
        BienSo       VARCHAR(20)  NOT NULL,
        HangXe       NVARCHAR(50) NULL,
        DongXe       NVARCHAR(50) NULL,
        MauSac       NVARCHAR(30) NULL,
        NamSanXuat   SMALLINT NULL CONSTRAINT CK_PhuongTien_Nam CHECK (NamSanXuat IS NULL OR NamSanXuat BETWEEN 1980 AND 2100),
        LaXeChinh    BIT NOT NULL CONSTRAINT DF_PhuongTien_Chinh DEFAULT 0,
        TrangThai    NVARCHAR(12) NOT NULL CONSTRAINT DF_PhuongTien_TrangThai DEFAULT N'HoatDong'
                     CONSTRAINT CK_PhuongTien_TrangThai CHECK (TrangThai IN (N'HoatDong', N'NgungSuDung')),
        NgayTao      DATETIME NOT NULL CONSTRAINT DF_PhuongTien_NgayTao DEFAULT GETDATE()
    );
    EXEC(N'CREATE INDEX IX_PhuongTien_TaiXe  ON PhuongTienTaiXe (MaTaiXe)');
    EXEC(N'CREATE INDEX IX_PhuongTien_BienSo ON PhuongTienTaiXe (BienSo)');
    EXEC(N'CREATE UNIQUE INDEX UX_PhuongTien_XeChinh ON PhuongTienTaiXe (MaTaiXe) WHERE LaXeChinh = 1'); -- mỗi tài xế tối đa 1 xe chính
END
GO

IF OBJECT_ID('GiayToTaiXe', 'U') IS NULL
BEGIN
    CREATE TABLE GiayToTaiXe (
        MaGiayTo       INT IDENTITY(1,1) CONSTRAINT PK_GiayToTaiXe PRIMARY KEY,
        MaTaiXe        INT NOT NULL CONSTRAINT FK_GiayTo_TaiXe REFERENCES TaiXe(MaTaiXe) ON DELETE CASCADE,
        LoaiGiayTo     NVARCHAR(20) NOT NULL
                       CONSTRAINT CK_GiayTo_Loai CHECK (LoaiGiayTo IN (N'CCCD', N'GPLX', N'DangKyXe', N'BaoHiem', N'LyLichTuPhap', N'KhamSucKhoe', N'Khac')),
        SoGiayTo       VARCHAR(30)  NULL,
        NgayCap        DATE NULL,
        NgayHetHan     DATE NULL,
        DuongDanAnh    NVARCHAR(500) NULL,        -- nên là tệp RIÊNG TƯ (TepTin.RiengTu = 1)
        TrangThaiDuyet NVARCHAR(10) NOT NULL CONSTRAINT DF_GiayTo_Duyet DEFAULT N'ChoDuyet'
                       CONSTRAINT CK_GiayTo_Duyet CHECK (TrangThaiDuyet IN (N'ChoDuyet', N'DaDuyet', N'TuChoi')),
        LyDoTuChoi     NVARCHAR(255) NULL,
        MaTKDuyet      INT NULL CONSTRAINT FK_GiayTo_NguoiDuyet REFERENCES TaiKhoan(MaTK),
        NgayDuyet      DATETIME NULL,
        NgayTao        DATETIME NOT NULL CONSTRAINT DF_GiayTo_NgayTao DEFAULT GETDATE(),
        CONSTRAINT CK_GiayTo_HanDung CHECK (NgayHetHan IS NULL OR NgayCap IS NULL OR NgayHetHan >= NgayCap)
    );
    EXEC(N'CREATE INDEX IX_GiayTo_TaiXe ON GiayToTaiXe (MaTaiXe, LoaiGiayTo)');
    EXEC(N'CREATE INDEX IX_GiayTo_HetHan ON GiayToTaiXe (NgayHetHan) WHERE NgayHetHan IS NOT NULL');
END
GO

IF OBJECT_ID('LichSuViTriTaiXe', 'U') IS NULL
BEGIN
    CREATE TABLE LichSuViTriTaiXe (
        MaViTri     BIGINT IDENTITY(1,1) CONSTRAINT PK_LichSuViTriTaiXe PRIMARY KEY,
        MaTaiXe     INT NOT NULL CONSTRAINT FK_ViTriTX_TaiXe REFERENCES TaiXe(MaTaiXe) ON DELETE CASCADE,
        MaDonHang   INT NULL CONSTRAINT FK_ViTriTX_Don REFERENCES DonHang(MaDonHang) ON DELETE SET NULL,
        ViDo        FLOAT NOT NULL CONSTRAINT CK_ViTriTX_ViDo   CHECK (ViDo   BETWEEN -90  AND 90),
        KinhDo      FLOAT NOT NULL CONSTRAINT CK_ViTriTX_KinhDo CHECK (KinhDo BETWEEN -180 AND 180),
        DoChinhXacM FLOAT NULL,
        TocDoKmh    FLOAT NULL,
        ThoiGian    DATETIME2(3) NOT NULL CONSTRAINT DF_ViTriTX_ThoiGian DEFAULT SYSDATETIME()
    );
    EXEC(N'CREATE INDEX IX_ViTriTX_TaiXe ON LichSuViTriTaiXe (MaTaiXe, ThoiGian DESC) INCLUDE (ViDo, KinhDo)');
    EXEC(N'CREATE INDEX IX_ViTriTX_Don   ON LichSuViTriTaiXe (MaDonHang, ThoiGian) WHERE MaDonHang IS NOT NULL');
END
GO

CREATE OR ALTER VIEW v_ViTriTaiXeMoiNhat AS
SELECT x.MaTaiXe, x.ViDo, x.KinhDo, x.TocDoKmh, x.MaDonHang, x.ThoiGian
FROM (SELECT l.MaTaiXe, l.ViDo, l.KinhDo, l.TocDoKmh, l.MaDonHang, l.ThoiGian,
             ROW_NUMBER() OVER (PARTITION BY l.MaTaiXe ORDER BY l.ThoiGian DESC, l.MaViTri DESC) AS rn
      FROM LichSuViTriTaiXe l) x
WHERE x.rn = 1;
GO

CREATE OR ALTER PROCEDURE sp_GhiViTriTaiXe
    @MaTaiXe INT, @ViDo FLOAT, @KinhDo FLOAT,
    @MaDonHang INT = NULL, @TocDoKmh FLOAT = NULL, @DoChinhXacM FLOAT = NULL
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO LichSuViTriTaiXe (MaTaiXe, MaDonHang, ViDo, KinhDo, TocDoKmh, DoChinhXacM)
    VALUES (@MaTaiXe, @MaDonHang, @ViDo, @KinhDo, @TocDoKmh, @DoChinhXacM);
END;
GO

CREATE OR ALTER PROCEDURE sp_DonDepViTriTaiXe @GiuNgay INT = 30   -- xóa theo lô để không khóa bảng lâu; gọi trong job đêm cùng sp_DonDepDuLieu
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @han DATETIME2(3) = DATEADD(DAY, -@GiuNgay, SYSDATETIME());
    WHILE 1 = 1
    BEGIN
        DELETE TOP (5000) FROM LichSuViTriTaiXe WHERE ThoiGian < @han;
        IF @@ROWCOUNT = 0 BREAK;
    END
END;
GO

/* ============================================================
   5. GIAO HÀNG: PhanCongGiaoHang — lịch sử đề nghị/nhận/từ chối/gỡ tài xế cho từng đơn
   GiaoHang (1 dòng/đơn) vẫn là chuyến đang hiệu lực; DieuPhoiLog + TaiXeTuChoiDon được nạp sang đây ở mục 11.
   Ràng buộc: mỗi đơn chỉ có tối đa MỘT phân công đang ở trạng thái DaNhan.
   ============================================================ */
IF OBJECT_ID('PhanCongGiaoHang', 'U') IS NULL
BEGIN
    CREATE TABLE PhanCongGiaoHang (
        MaPhanCong    BIGINT IDENTITY(1,1) CONSTRAINT PK_PhanCongGiaoHang PRIMARY KEY,
        MaDonHang     INT NOT NULL CONSTRAINT FK_PhanCong_Don    REFERENCES DonHang(MaDonHang) ON DELETE CASCADE,
        MaTaiXe       INT NOT NULL CONSTRAINT FK_PhanCong_TaiXe  REFERENCES TaiXe(MaTaiXe),
        HinhThuc      NVARCHAR(10) NOT NULL CONSTRAINT DF_PhanCong_HinhThuc DEFAULT N'TuNhan'
                      CONSTRAINT CK_PhanCong_HinhThuc CHECK (HinhThuc IN (N'TuNhan', N'QuanTri', N'TuDong')),
        TrangThai     NVARCHAR(12) NOT NULL CONSTRAINT DF_PhanCong_TrangThai DEFAULT N'DeNghi'
                      CONSTRAINT CK_PhanCong_TrangThai CHECK (TrangThai IN (N'DeNghi', N'DaNhan', N'TuChoi', N'HetHan', N'DaGo', N'HoanThanh')),
        LyDo          NVARCHAR(300) NULL,
        MaTKPhanCong  INT NULL CONSTRAINT FK_PhanCong_NguoiPhanCong REFERENCES TaiKhoan(MaTK),
        NgayDeNghi    DATETIME NOT NULL CONSTRAINT DF_PhanCong_NgayDeNghi DEFAULT GETDATE(),
        HanPhanHoi    DATETIME NULL,
        NgayPhanHoi   DATETIME NULL
    );
    EXEC(N'CREATE INDEX IX_PhanCong_Don   ON PhanCongGiaoHang (MaDonHang, NgayDeNghi)');
    EXEC(N'CREATE INDEX IX_PhanCong_TaiXe ON PhanCongGiaoHang (MaTaiXe, TrangThai, NgayDeNghi)');
    EXEC(N'CREATE UNIQUE INDEX UX_PhanCong_DangGiu ON PhanCongGiaoHang (MaDonHang) WHERE TrangThai = N''DaNhan''');
END
GO

/* ============================================================
   6. KHUYẾN MÃI: ChuongTrinhKhuyenMai (chiến dịch) gom nhiều voucher (KhuyenMai)
   KhuyenMai = voucher/mã giảm giá; KhuyenMaiKhachDung = lượt dùng (đã có). Banner/ChienDichQuangCao (đã có) là quảng bá, không phải giảm giá.
   ============================================================ */
IF OBJECT_ID('ChuongTrinhKhuyenMai', 'U') IS NULL
    CREATE TABLE ChuongTrinhKhuyenMai (
        MaChuongTrinh INT IDENTITY(1,1) CONSTRAINT PK_ChuongTrinhKhuyenMai PRIMARY KEY,
        TenChuongTrinh NVARCHAR(150) NOT NULL,
        MoTa          NVARCHAR(500) NULL,
        Loai          NVARCHAR(10) NOT NULL CONSTRAINT DF_CTKM_Loai DEFAULT N'NenTang'
                      CONSTRAINT CK_CTKM_Loai CHECK (Loai IN (N'NenTang', N'GianHang', N'FlashSale', N'SuKien')),
        MaGianHang    INT NULL CONSTRAINT FK_CTKM_GianHang REFERENCES GianHang(MaGianHang),   -- bắt buộc khi Loai = GianHang
        NgayBatDau    DATETIME NOT NULL,
        NgayKetThuc   DATETIME NOT NULL,
        NganSach      DECIMAL(14,0) NULL CONSTRAINT CK_CTKM_NganSach CHECK (NganSach IS NULL OR NganSach >= 0),
        TrangThai     NVARCHAR(10) NOT NULL CONSTRAINT DF_CTKM_TrangThai DEFAULT N'BanNhap'
                      CONSTRAINT CK_CTKM_TrangThai CHECK (TrangThai IN (N'BanNhap', N'DangChay', N'TamDung', N'KetThuc')),
        HinhAnh       NVARCHAR(500) NULL,
        MaTKTao       INT NULL CONSTRAINT FK_CTKM_NguoiTao REFERENCES TaiKhoan(MaTK),
        NgayTao       DATETIME NOT NULL CONSTRAINT DF_CTKM_NgayTao DEFAULT GETDATE(),
        CONSTRAINT CK_CTKM_ThoiGian CHECK (NgayKetThuc > NgayBatDau),
        CONSTRAINT CK_CTKM_GianHang CHECK (Loai <> N'GianHang' OR MaGianHang IS NOT NULL)
    );
GO

IF OBJECT_ID('ChuongTrinhKhuyenMai_Voucher', 'U') IS NULL
    CREATE TABLE ChuongTrinhKhuyenMai_Voucher (
        MaChuongTrinh INT NOT NULL CONSTRAINT FK_CTKMV_ChuongTrinh REFERENCES ChuongTrinhKhuyenMai(MaChuongTrinh) ON DELETE CASCADE,
        MaKhuyenMai   INT NOT NULL CONSTRAINT FK_CTKMV_KhuyenMai   REFERENCES KhuyenMai(MaKhuyenMai) ON DELETE CASCADE,
        CONSTRAINT PK_CTKM_Voucher PRIMARY KEY (MaChuongTrinh, MaKhuyenMai)
    );
GO

/* ============================================================
   7. THÔNG BÁO: NhatKyThongBao — mỗi lần gửi (push/email/sms) một ThongBao và kết quả
   ThongBao (đã có) = nội dung hiển thị trong app; bảng này = nhật ký gửi qua từng kênh.
   ============================================================ */
IF OBJECT_ID('NhatKyThongBao', 'U') IS NULL
BEGIN
    CREATE TABLE NhatKyThongBao (
        MaNhatKy     BIGINT IDENTITY(1,1) CONSTRAINT PK_NhatKyThongBao PRIMARY KEY,
        MaThongBao   BIGINT NOT NULL CONSTRAINT FK_NhatKyTB_ThongBao REFERENCES ThongBao(MaThongBao) ON DELETE CASCADE,
        Kenh         VARCHAR(10) NOT NULL CONSTRAINT CK_NhatKyTB_Kenh CHECK (Kenh IN ('push', 'email', 'sms', 'inapp')),
        NguoiNhan    NVARCHAR(300) NULL,                     -- email / SĐT / token thiết bị (đã rút gọn nếu cần)
        TrangThai    NVARCHAR(10) NOT NULL CONSTRAINT DF_NhatKyTB_TrangThai DEFAULT N'ChoGui'
                     CONSTRAINT CK_NhatKyTB_TrangThai CHECK (TrangThai IN (N'ChoGui', N'DaGui', N'DaNhan', N'ThatBai')),
        SoLanThu     INT NOT NULL CONSTRAINT DF_NhatKyTB_SoLan DEFAULT 0,
        MaPhanHoiNCC NVARCHAR(100) NULL,                     -- id tin nhắn của nhà cung cấp (FCM, SMS gateway...)
        ThongDiepLoi NVARCHAR(500) NULL,
        NgayTao      DATETIME NOT NULL CONSTRAINT DF_NhatKyTB_NgayTao DEFAULT GETDATE(),
        NgayGui      DATETIME NULL
    );
    EXEC(N'CREATE INDEX IX_NhatKyTB_ThongBao ON NhatKyThongBao (MaThongBao)');
    EXEC(N'CREATE INDEX IX_NhatKyTB_TrangThai ON NhatKyThongBao (TrangThai, NgayTao) WHERE TrangThai <> N''DaGui'' AND TrangThai <> N''DaNhan'''); -- = ChoGui + ThatBai (để job gửi lại quét nhanh)
END
GO

/* ============================================================
   8. HỖ TRỢ: PhieuHoTro (phiếu) + TinNhanHoTro (hội thoại trong phiếu)
   PhanHoi (đã có) là 1 lần góp ý/khiếu nại của KHÁCH có đúng 1 câu trả lời. Phiếu mới: mọi vai trò mở được,
   nhiều lượt trao đổi, có ưu tiên + người phụ trách. Cột MaPhanHoi nối phiếu với phản hồi cũ (nạp ở mục 11).
   (Khác TinNhan: đó là chat khách–tài xế–quán theo đơn.)
   ============================================================ */
IF OBJECT_ID('PhieuHoTro', 'U') IS NULL
BEGIN
    CREATE TABLE PhieuHoTro (
        MaPhieu        INT IDENTITY(1,1) CONSTRAINT PK_PhieuHoTro PRIMARY KEY,
        MaTKNguoiGui   INT NOT NULL CONSTRAINT FK_PhieuHoTro_NguoiGui REFERENCES TaiKhoan(MaTK),
        VaiTroNguoiGui NVARCHAR(10) NOT NULL CONSTRAINT CK_PhieuHoTro_VaiTro CHECK (VaiTroNguoiGui IN (N'KhachHang', N'GianHang', N'TaiXe')),
        MaDonHang      INT NULL CONSTRAINT FK_PhieuHoTro_Don REFERENCES DonHang(MaDonHang),
        MaGianHang     INT NULL CONSTRAINT FK_PhieuHoTro_GianHang REFERENCES GianHang(MaGianHang),
        PhanLoai       NVARCHAR(30) NULL,        -- DonHang | MonAn | TaiXe | GianHang | ThanhToan | TaiKhoan | Khac (cùng PhanHoi.PhanLoai)
        Loai           NVARCHAR(10) NOT NULL CONSTRAINT DF_PhieuHoTro_Loai DEFAULT N'HoTro'
                       CONSTRAINT CK_PhieuHoTro_Loai CHECK (Loai IN (N'HoTro', N'GopY', N'KhieuNai', N'Khac')),
        TieuDe         NVARCHAR(150) NOT NULL,
        TrangThai      NVARCHAR(10) NOT NULL CONSTRAINT DF_PhieuHoTro_TrangThai DEFAULT N'ChuaXuLy'
                       CONSTRAINT CK_PhieuHoTro_TrangThai CHECK (TrangThai IN (N'ChuaXuLy', N'DangXuLy', N'DaXuLy', N'Dong')),
        UuTien         NVARCHAR(10) NOT NULL CONSTRAINT DF_PhieuHoTro_UuTien DEFAULT N'TrungBinh'
                       CONSTRAINT CK_PhieuHoTro_UuTien CHECK (UuTien IN (N'Thap', N'TrungBinh', N'Cao', N'Khan')),
        MaTKPhuTrach   INT NULL CONSTRAINT FK_PhieuHoTro_PhuTrach REFERENCES TaiKhoan(MaTK),
        MaPhanHoi      INT NULL CONSTRAINT FK_PhieuHoTro_PhanHoi REFERENCES PhanHoi(MaPhanHoi),
        NgayTao        DATETIME NOT NULL CONSTRAINT DF_PhieuHoTro_NgayTao DEFAULT GETDATE(),
        NgayCapNhat    DATETIME NOT NULL CONSTRAINT DF_PhieuHoTro_NgayCN DEFAULT GETDATE(),
        NgayDong       DATETIME NULL
    );
    EXEC(N'CREATE INDEX IX_PhieuHoTro_NguoiGui ON PhieuHoTro (MaTKNguoiGui, NgayTao DESC)');
    EXEC(N'CREATE INDEX IX_PhieuHoTro_XuLy     ON PhieuHoTro (TrangThai, UuTien, NgayTao) INCLUDE (MaTKPhuTrach)');
    EXEC(N'CREATE INDEX IX_PhieuHoTro_Don      ON PhieuHoTro (MaDonHang) WHERE MaDonHang IS NOT NULL');
    EXEC(N'CREATE UNIQUE INDEX UX_PhieuHoTro_PhanHoi ON PhieuHoTro (MaPhanHoi) WHERE MaPhanHoi IS NOT NULL');
END
GO

IF OBJECT_ID('TinNhanHoTro', 'U') IS NULL
BEGIN
    CREATE TABLE TinNhanHoTro (
        MaTinNhan      BIGINT IDENTITY(1,1) CONSTRAINT PK_TinNhanHoTro PRIMARY KEY,
        MaPhieu        INT NOT NULL CONSTRAINT FK_TinNhanHoTro_Phieu REFERENCES PhieuHoTro(MaPhieu) ON DELETE CASCADE,
        MaTKGui        INT NULL CONSTRAINT FK_TinNhanHoTro_NguoiGui REFERENCES TaiKhoan(MaTK),    -- NULL = hệ thống
        VaiTroGui      NVARCHAR(10) NOT NULL CONSTRAINT CK_TinNhanHoTro_VaiTro CHECK (VaiTroGui IN (N'KhachHang', N'GianHang', N'TaiXe', N'QuanTri', N'HeThong')),
        NoiDung        NVARCHAR(2000) NOT NULL,
        TepDinhKem     NVARCHAR(500) NULL,
        LaGhiChuNoiBo  BIT NOT NULL CONSTRAINT DF_TinNhanHoTro_NoiBo DEFAULT 0,     -- 1 = chỉ nhân viên thấy
        NgayGui        DATETIME NOT NULL CONSTRAINT DF_TinNhanHoTro_NgayGui DEFAULT GETDATE()
    );
    EXEC(N'CREATE INDEX IX_TinNhanHoTro_Phieu ON TinNhanHoTro (MaPhieu, NgayGui)');
END
GO

/* ============================================================
   9. BÁO CÁO / ĐỐI SOÁT
   KyDoiSoat 1 ─ n ChiTraGianHang 1 ─ n ChiTietChiTraGianHang (mỗi đơn chỉ thuộc MỘT khoản chi: PK = MaDonHang)
              └─ n ChiTraTaiXe    1 ─ n ChiTietChiTraTaiXe    (mỗi chuyến / điều chỉnh chỉ thuộc MỘT khoản chi)
   Công thức khớp báo cáo hiện tại (AdminMobileNoiDungApiController / DriverThuNhapApi):
     Quán:   tiền hàng = TongTien − PhiGiaoHang;  phí nền tảng = tiền hàng × GianHang.TyLeChietKhau;  phải trả = tiền hàng − phí.
     Tài xế: phí giao (DonHang.PhiGiaoHang) của chuyến GiaoThanhCong, hoặc GiaoThatBai có TinhPhiThatBai; cộng thưởng/phụ cấp/phạt
             từ DieuChinhThuNhap (đang ChoThanhToan). Tiền COD chưa nộp chỉ để THAM KHẢO, không trừ vào khoản chi.
   Khi đánh dấu đã chi, thủ tục cập nhật luôn cờ cũ (DonHang.QuanDaTraLuc, GiaoHang.TrangThaiThuNhap, DieuChinhThuNhap.TrangThai)
   để các màn hình hiện có vẫn đúng.
   ============================================================ */
IF OBJECT_ID('KyDoiSoat', 'U') IS NULL
    CREATE TABLE KyDoiSoat (
        MaKy              INT IDENTITY(1,1) CONSTRAINT PK_KyDoiSoat PRIMARY KEY,
        TenKy             NVARCHAR(100) NOT NULL,
        TuNgay            DATE NOT NULL,
        DenNgay           DATE NOT NULL,
        TrangThai         NVARCHAR(10) NOT NULL CONSTRAINT DF_KyDoiSoat_TrangThai DEFAULT N'BanNhap'
                          CONSTRAINT CK_KyDoiSoat_TrangThai CHECK (TrangThai IN (N'BanNhap', N'DaChot', N'DangChi', N'HoanTat', N'Huy')),
        TongSoDon         INT NOT NULL CONSTRAINT DF_KyDoiSoat_SoDon DEFAULT 0,
        TongTienHang      DECIMAL(14,0) NOT NULL CONSTRAINT DF_KyDoiSoat_TienHang DEFAULT 0,
        TongPhiNenTang    DECIMAL(14,0) NOT NULL CONSTRAINT DF_KyDoiSoat_Phi DEFAULT 0,
        TongPhaiTraQuan   DECIMAL(14,0) NOT NULL CONSTRAINT DF_KyDoiSoat_TraQuan DEFAULT 0,
        TongPhaiTraTaiXe  DECIMAL(14,0) NOT NULL CONSTRAINT DF_KyDoiSoat_TraTX DEFAULT 0,
        GhiChu            NVARCHAR(300) NULL,
        MaTKTao           INT NULL CONSTRAINT FK_KyDoiSoat_NguoiTao REFERENCES TaiKhoan(MaTK),
        NgayTao           DATETIME NOT NULL CONSTRAINT DF_KyDoiSoat_NgayTao DEFAULT GETDATE(),
        NgayChot          DATETIME NULL,
        CONSTRAINT CK_KyDoiSoat_Ngay CHECK (DenNgay >= TuNgay)
    );
GO

IF OBJECT_ID('ChiTraGianHang', 'U') IS NULL
BEGIN
    CREATE TABLE ChiTraGianHang (
        MaChiTraQuan       INT IDENTITY(1,1) CONSTRAINT PK_ChiTraGianHang PRIMARY KEY,
        MaKy               INT NOT NULL CONSTRAINT FK_ChiTraQuan_Ky REFERENCES KyDoiSoat(MaKy),
        MaGianHang         INT NOT NULL CONSTRAINT FK_ChiTraQuan_GianHang REFERENCES GianHang(MaGianHang),
        SoDon              INT NOT NULL CONSTRAINT DF_ChiTraQuan_SoDon DEFAULT 0,
        TienHang           DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraQuan_TienHang DEFAULT 0,
        TyLeChietKhau      DECIMAL(5,4) NOT NULL CONSTRAINT DF_ChiTraQuan_Ty DEFAULT 0,      -- tỷ lệ tại lúc chốt (lưu lại để đối chiếu sau này)
        PhiNenTang         DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraQuan_Phi DEFAULT 0,
        DieuChinh          DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraQuan_DieuChinh DEFAULT 0,   -- dương = cộng thêm, âm = trừ (sửa tay trước khi chi)
        SoTienChiTra       DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraQuan_SoTien DEFAULT 0,
        TrangThai          NVARCHAR(8) NOT NULL CONSTRAINT DF_ChiTraQuan_TrangThai DEFAULT N'ChoChi'
                           CONSTRAINT CK_ChiTraQuan_TrangThai CHECK (TrangThai IN (N'ChoChi', N'DaChi', N'Loi', N'Huy')),
        PhuongThuc         NVARCHAR(15) NULL CONSTRAINT CK_ChiTraQuan_PhuongThuc CHECK (PhuongThuc IS NULL OR PhuongThuc IN (N'ChuyenKhoan', N'TienMat', N'ViDienTu', N'Khac')),
        MaGiaoDichNganHang NVARCHAR(100) NULL,
        GhiChu             NVARCHAR(300) NULL,
        MaTKChi            INT NULL CONSTRAINT FK_ChiTraQuan_NguoiChi REFERENCES TaiKhoan(MaTK),
        NgayTao            DATETIME NOT NULL CONSTRAINT DF_ChiTraQuan_NgayTao DEFAULT GETDATE(),
        NgayChi            DATETIME NULL,
        CONSTRAINT UQ_ChiTraQuan UNIQUE (MaKy, MaGianHang)
    );
    EXEC(N'CREATE INDEX IX_ChiTraQuan_GianHang ON ChiTraGianHang (MaGianHang, TrangThai)');
END
GO

IF OBJECT_ID('ChiTietChiTraGianHang', 'U') IS NULL
    CREATE TABLE ChiTietChiTraGianHang (
        MaDonHang    INT NOT NULL CONSTRAINT PK_ChiTietChiTraGianHang PRIMARY KEY CONSTRAINT FK_CTCTQuan_Don REFERENCES DonHang(MaDonHang),
        MaChiTraQuan INT NOT NULL CONSTRAINT FK_CTCTQuan_ChiTra REFERENCES ChiTraGianHang(MaChiTraQuan) ON DELETE CASCADE,
        TienHang     DECIMAL(14,0) NOT NULL,
        PhiNenTang   DECIMAL(14,0) NOT NULL
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CTCTQuan_ChiTra' AND object_id = OBJECT_ID('ChiTietChiTraGianHang'))
    EXEC(N'CREATE INDEX IX_CTCTQuan_ChiTra ON ChiTietChiTraGianHang (MaChiTraQuan)');
GO

IF OBJECT_ID('ChiTraTaiXe', 'U') IS NULL
BEGIN
    CREATE TABLE ChiTraTaiXe (
        MaChiTraTX         INT IDENTITY(1,1) CONSTRAINT PK_ChiTraTaiXe PRIMARY KEY,
        MaKy               INT NOT NULL CONSTRAINT FK_ChiTraTX_Ky REFERENCES KyDoiSoat(MaKy),
        MaTaiXe            INT NOT NULL CONSTRAINT FK_ChiTraTX_TaiXe REFERENCES TaiXe(MaTaiXe),
        SoChuyen           INT NOT NULL CONSTRAINT DF_ChiTraTX_SoChuyen DEFAULT 0,
        TienPhiGiao        DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraTX_PhiGiao DEFAULT 0,
        TienDieuChinh      DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraTX_DieuChinh DEFAULT 0,   -- thưởng/phụ cấp (+) và phạt/khấu trừ (−) từ DieuChinhThuNhap
        TienCODChuaNop     DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraTX_COD DEFAULT 0,         -- tham khảo: COD đã thu trong kỳ nhưng chưa nộp
        SoTienChiTra       DECIMAL(14,0) NOT NULL CONSTRAINT DF_ChiTraTX_SoTien DEFAULT 0,      -- = phí giao + điều chỉnh; có thể ÂM (khấu trừ vượt thu nhập)
        TrangThai          NVARCHAR(8) NOT NULL CONSTRAINT DF_ChiTraTX_TrangThai DEFAULT N'ChoChi'
                           CONSTRAINT CK_ChiTraTX_TrangThai CHECK (TrangThai IN (N'ChoChi', N'DaChi', N'Loi', N'Huy')),
        PhuongThuc         NVARCHAR(15) NULL CONSTRAINT CK_ChiTraTX_PhuongThuc CHECK (PhuongThuc IS NULL OR PhuongThuc IN (N'ChuyenKhoan', N'TienMat', N'ViDienTu', N'Khac')),
        MaGiaoDichNganHang NVARCHAR(100) NULL,
        GhiChu             NVARCHAR(300) NULL,
        MaTKChi            INT NULL CONSTRAINT FK_ChiTraTX_NguoiChi REFERENCES TaiKhoan(MaTK),
        NgayTao            DATETIME NOT NULL CONSTRAINT DF_ChiTraTX_NgayTao DEFAULT GETDATE(),
        NgayChi            DATETIME NULL,
        CONSTRAINT UQ_ChiTraTX UNIQUE (MaKy, MaTaiXe)
    );
    EXEC(N'CREATE INDEX IX_ChiTraTX_TaiXe ON ChiTraTaiXe (MaTaiXe, TrangThai)');
END
GO

IF OBJECT_ID('ChiTietChiTraTaiXe', 'U') IS NULL
    CREATE TABLE ChiTietChiTraTaiXe (
        Loai        NVARCHAR(10) NOT NULL CONSTRAINT CK_CTCTTX_Loai CHECK (Loai IN (N'Chuyen', N'DieuChinh')),   -- Chuyen -> GiaoHang.MaGiaoHang; DieuChinh -> DieuChinhThuNhap.MaDieuChinh
        MaThamChieu INT NOT NULL,
        MaChiTraTX  INT NOT NULL CONSTRAINT FK_CTCTTX_ChiTra REFERENCES ChiTraTaiXe(MaChiTraTX) ON DELETE CASCADE,
        SoTien      DECIMAL(14,0) NOT NULL,
        CONSTRAINT PK_ChiTietChiTraTaiXe PRIMARY KEY (Loai, MaThamChieu)
    );
GO
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'IX_CTCTTX_ChiTra' AND object_id = OBJECT_ID('ChiTietChiTraTaiXe'))
    EXEC(N'CREATE INDEX IX_CTCTTX_ChiTra ON ChiTietChiTraTaiXe (MaChiTraTX)');
GO

/* ---- 9.1 Tạo kỳ đối soát: gom đơn/chuyến CHƯA chi trong khoảng ngày giao ---- */
CREATE OR ALTER PROCEDURE sp_TaoKyDoiSoat
    @TuNgay DATE, @DenNgay DATE, @MaTK INT = NULL, @TenKy NVARCHAR(100) = NULL, @MaKy INT = NULL OUTPUT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF @DenNgay < @TuNgay THROW 50101, N'Ngày kết thúc phải sau hoặc bằng ngày bắt đầu.', 1;
    IF EXISTS (SELECT 1 FROM KyDoiSoat WHERE TrangThai <> N'Huy' AND TuNgay <= @DenNgay AND DenNgay >= @TuNgay)
        THROW 50102, N'Khoảng thời gian trùng với một kỳ đối soát đã có (hủy kỳ cũ trước nếu cần tạo lại).', 1;

    DECLARE @tu DATETIME = CAST(@TuNgay AS DATETIME), @den DATETIME = DATEADD(DAY, 1, CAST(@DenNgay AS DATETIME));
    IF @TenKy IS NULL SET @TenKy = N'Đối soát ' + CONVERT(NVARCHAR(10), @TuNgay, 103) + N' - ' + CONVERT(NVARCHAR(10), @DenNgay, 103);

    CREATE TABLE #Don    (MaDonHang INT PRIMARY KEY, MaGianHang INT NOT NULL, TienHang DECIMAL(14,0) NOT NULL, Ty DECIMAL(5,4) NOT NULL, Phi DECIMAL(14,0) NOT NULL);
    CREATE TABLE #Chuyen (MaGiaoHang INT PRIMARY KEY, MaTaiXe INT NOT NULL, SoTien DECIMAL(14,0) NOT NULL, Cod DECIMAL(14,0) NOT NULL);
    CREATE TABLE #DC     (MaDieuChinh INT PRIMARY KEY, MaTaiXe INT NOT NULL, SoTien DECIMAL(14,0) NOT NULL);

    /* đơn đã giao, quán chưa được trả, chưa nằm trong khoản chi nào */
    INSERT INTO #Don (MaDonHang, MaGianHang, TienHang, Ty, Phi)
    SELECT d.MaDonHang, d.MaGianHang, d.TongTien - d.PhiGiaoHang, gh.TyLeChietKhau,
           CAST(ROUND((d.TongTien - d.PhiGiaoHang) * gh.TyLeChietKhau, 0) AS DECIMAL(14,0))
    FROM DonHang d
    JOIN GianHang gh ON gh.MaGianHang = d.MaGianHang
    LEFT JOIN GiaoHang g ON g.MaDonHang = d.MaDonHang
    WHERE d.TrangThai = N'DaGiao' AND d.QuanDaTraLuc IS NULL
      AND COALESCE(g.ThoiGianGiao, d.NgayDat) >= @tu AND COALESCE(g.ThoiGianGiao, d.NgayDat) < @den
      AND NOT EXISTS (SELECT 1 FROM ChiTietChiTraGianHang c WHERE c.MaDonHang = d.MaDonHang);

    /* chuyến giao tính thu nhập (cùng quy tắc DriverThuNhapApi), chưa trả, chưa nằm trong khoản chi nào */
    INSERT INTO #Chuyen (MaGiaoHang, MaTaiXe, SoTien, Cod)
    SELECT g.MaGiaoHang, g.MaTaiXe, d.PhiGiaoHang,
           CASE WHEN g.TrangThai = N'GiaoThanhCong' AND g.CodDaNopLuc IS NULL THEN ISNULL(g.TienThuCOD, 0) ELSE 0 END
    FROM GiaoHang g
    JOIN DonHang d ON d.MaDonHang = g.MaDonHang
    WHERE (g.TrangThai = N'GiaoThanhCong' OR (g.TrangThai = N'GiaoThatBai' AND g.TinhPhiThatBai = 1))
      AND g.TrangThaiThuNhap = N'ChoThanhToan'
      AND g.ThoiGianGiao >= @tu AND g.ThoiGianGiao < @den
      AND NOT EXISTS (SELECT 1 FROM ChiTietChiTraTaiXe c WHERE c.Loai = N'Chuyen' AND c.MaThamChieu = g.MaGiaoHang);

    INSERT INTO #DC (MaDieuChinh, MaTaiXe, SoTien)
    SELECT dc.MaDieuChinh, dc.MaTaiXe, dc.SoTien
    FROM DieuChinhThuNhap dc
    JOIN TaiXe x ON x.MaTaiXe = dc.MaTaiXe
    WHERE dc.TrangThai = N'ChoThanhToan' AND dc.NgayTao >= @tu AND dc.NgayTao < @den
      AND NOT EXISTS (SELECT 1 FROM ChiTietChiTraTaiXe c WHERE c.Loai = N'DieuChinh' AND c.MaThamChieu = dc.MaDieuChinh);

    BEGIN TRAN;
        INSERT INTO KyDoiSoat (TenKy, TuNgay, DenNgay, MaTKTao) VALUES (@TenKy, @TuNgay, @DenNgay, @MaTK);
        SET @MaKy = SCOPE_IDENTITY();

        INSERT INTO ChiTraGianHang (MaKy, MaGianHang, SoDon, TienHang, TyLeChietKhau, PhiNenTang, SoTienChiTra)
        SELECT @MaKy, MaGianHang, COUNT(*), SUM(TienHang), MAX(Ty), SUM(Phi), SUM(TienHang) - SUM(Phi)
        FROM #Don GROUP BY MaGianHang;

        INSERT INTO ChiTietChiTraGianHang (MaDonHang, MaChiTraQuan, TienHang, PhiNenTang)
        SELECT o.MaDonHang, c.MaChiTraQuan, o.TienHang, o.Phi
        FROM #Don o JOIN ChiTraGianHang c ON c.MaKy = @MaKy AND c.MaGianHang = o.MaGianHang;

        ;WITH a AS (SELECT MaTaiXe, COUNT(*) AS SoChuyen, SUM(SoTien) AS Phi, SUM(Cod) AS Cod FROM #Chuyen GROUP BY MaTaiXe),
              b AS (SELECT MaTaiXe, SUM(SoTien) AS DieuChinh FROM #DC GROUP BY MaTaiXe)
        INSERT INTO ChiTraTaiXe (MaKy, MaTaiXe, SoChuyen, TienPhiGiao, TienDieuChinh, TienCODChuaNop, SoTienChiTra)
        SELECT @MaKy, COALESCE(a.MaTaiXe, b.MaTaiXe), ISNULL(a.SoChuyen, 0), ISNULL(a.Phi, 0), ISNULL(b.DieuChinh, 0),
               ISNULL(a.Cod, 0), ISNULL(a.Phi, 0) + ISNULL(b.DieuChinh, 0)
        FROM a FULL JOIN b ON a.MaTaiXe = b.MaTaiXe;

        INSERT INTO ChiTietChiTraTaiXe (Loai, MaThamChieu, MaChiTraTX, SoTien)
        SELECT N'Chuyen', c.MaGiaoHang, t.MaChiTraTX, c.SoTien
        FROM #Chuyen c JOIN ChiTraTaiXe t ON t.MaKy = @MaKy AND t.MaTaiXe = c.MaTaiXe
        UNION ALL
        SELECT N'DieuChinh', d.MaDieuChinh, t.MaChiTraTX, d.SoTien
        FROM #DC d JOIN ChiTraTaiXe t ON t.MaKy = @MaKy AND t.MaTaiXe = d.MaTaiXe;

        UPDATE KyDoiSoat
           SET TongSoDon        = (SELECT ISNULL(SUM(SoDon), 0)        FROM ChiTraGianHang WHERE MaKy = @MaKy),
               TongTienHang     = (SELECT ISNULL(SUM(TienHang), 0)     FROM ChiTraGianHang WHERE MaKy = @MaKy),
               TongPhiNenTang   = (SELECT ISNULL(SUM(PhiNenTang), 0)   FROM ChiTraGianHang WHERE MaKy = @MaKy),
               TongPhaiTraQuan  = (SELECT ISNULL(SUM(SoTienChiTra), 0) FROM ChiTraGianHang WHERE MaKy = @MaKy),
               TongPhaiTraTaiXe = (SELECT ISNULL(SUM(SoTienChiTra), 0) FROM ChiTraTaiXe    WHERE MaKy = @MaKy)
         WHERE MaKy = @MaKy;
    COMMIT;

    SELECT * FROM KyDoiSoat WHERE MaKy = @MaKy;
END;
GO

/* ---- 9.2 Cập nhật trạng thái kỳ theo các khoản chi (nội bộ): còn khoản chờ -> DaChot/DangChi; hết -> HoanTat ---- */
CREATE OR ALTER PROCEDURE sp_CapNhatTrangThaiKyDoiSoat @MaKy INT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @con INT = (SELECT COUNT(*) FROM ChiTraGianHang WHERE MaKy = @MaKy AND TrangThai IN (N'ChoChi', N'Loi'))
                     + (SELECT COUNT(*) FROM ChiTraTaiXe    WHERE MaKy = @MaKy AND TrangThai IN (N'ChoChi', N'Loi'));
    DECLARE @daChi INT = (SELECT COUNT(*) FROM ChiTraGianHang WHERE MaKy = @MaKy AND TrangThai = N'DaChi')
                       + (SELECT COUNT(*) FROM ChiTraTaiXe    WHERE MaKy = @MaKy AND TrangThai = N'DaChi');
    UPDATE KyDoiSoat
       SET TrangThai = CASE WHEN @con = 0 THEN N'HoanTat' WHEN @daChi > 0 THEN N'DangChi' ELSE N'DaChot' END
     WHERE MaKy = @MaKy AND TrangThai IN (N'DaChot', N'DangChi');
END;
GO

/* ---- 9.3 Chốt kỳ (xem xong, không sửa nữa) -> bắt đầu được đánh dấu đã chi; kỳ không có khoản nào thì hoàn tất luôn ---- */
CREATE OR ALTER PROCEDURE sp_ChotKyDoiSoat @MaKy INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE KyDoiSoat SET TrangThai = N'DaChot', NgayChot = GETDATE() WHERE MaKy = @MaKy AND TrangThai = N'BanNhap';
    IF @@ROWCOUNT = 0 THROW 50103, N'Kỳ không tồn tại hoặc không còn ở trạng thái Bản nháp.', 1;
    EXEC sp_CapNhatTrangThaiKyDoiSoat @MaKy;
END;
GO

/* ---- 9.4 Đánh dấu đã chi cho quán (đồng bộ DonHang.QuanDaTraLuc) ---- */
CREATE OR ALTER PROCEDURE sp_DanhDauDaChiTraQuan
    @MaChiTraQuan INT, @PhuongThuc NVARCHAR(15) = N'ChuyenKhoan', @MaGiaoDichNganHang NVARCHAR(100) = NULL, @MaTK INT = NULL
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @ky INT, @tt NVARCHAR(8);
    SELECT @ky = MaKy, @tt = TrangThai FROM ChiTraGianHang WHERE MaChiTraQuan = @MaChiTraQuan;
    IF @ky IS NULL THROW 50110, N'Không tìm thấy khoản chi cho gian hàng.', 1;
    IF @tt <> N'ChoChi' AND @tt <> N'Loi' THROW 50111, N'Khoản chi này không ở trạng thái chờ chi.', 1;
    IF NOT EXISTS (SELECT 1 FROM KyDoiSoat WHERE MaKy = @ky AND TrangThai IN (N'DaChot', N'DangChi')) THROW 50112, N'Phải chốt kỳ đối soát trước khi chi.', 1;
    BEGIN TRAN;
        UPDATE ChiTraGianHang
           SET TrangThai = N'DaChi', PhuongThuc = @PhuongThuc, MaGiaoDichNganHang = @MaGiaoDichNganHang, NgayChi = GETDATE(), MaTKChi = @MaTK
         WHERE MaChiTraQuan = @MaChiTraQuan;
        UPDATE d SET d.QuanDaTraLuc = GETDATE()
          FROM DonHang d JOIN ChiTietChiTraGianHang c ON c.MaDonHang = d.MaDonHang
         WHERE c.MaChiTraQuan = @MaChiTraQuan AND d.QuanDaTraLuc IS NULL;
        EXEC sp_CapNhatTrangThaiKyDoiSoat @ky;
    COMMIT;
END;
GO

/* ---- 9.5 Đánh dấu đã chi cho tài xế (đồng bộ GiaoHang.TrangThaiThuNhap + DieuChinhThuNhap.TrangThai) ---- */
CREATE OR ALTER PROCEDURE sp_DanhDauDaChiTraTaiXe
    @MaChiTraTX INT, @PhuongThuc NVARCHAR(15) = N'ChuyenKhoan', @MaGiaoDichNganHang NVARCHAR(100) = NULL, @MaTK INT = NULL
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    DECLARE @ky INT, @tt NVARCHAR(8);
    SELECT @ky = MaKy, @tt = TrangThai FROM ChiTraTaiXe WHERE MaChiTraTX = @MaChiTraTX;
    IF @ky IS NULL THROW 50120, N'Không tìm thấy khoản chi cho tài xế.', 1;
    IF @tt <> N'ChoChi' AND @tt <> N'Loi' THROW 50121, N'Khoản chi này không ở trạng thái chờ chi.', 1;
    IF NOT EXISTS (SELECT 1 FROM KyDoiSoat WHERE MaKy = @ky AND TrangThai IN (N'DaChot', N'DangChi')) THROW 50122, N'Phải chốt kỳ đối soát trước khi chi.', 1;
    BEGIN TRAN;
        UPDATE ChiTraTaiXe
           SET TrangThai = N'DaChi', PhuongThuc = @PhuongThuc, MaGiaoDichNganHang = @MaGiaoDichNganHang, NgayChi = GETDATE(), MaTKChi = @MaTK
         WHERE MaChiTraTX = @MaChiTraTX;
        UPDATE g SET g.TrangThaiThuNhap = N'DaThanhToan', g.NgayThanhToanThuNhap = GETDATE()
          FROM GiaoHang g JOIN ChiTietChiTraTaiXe c ON c.Loai = N'Chuyen' AND c.MaThamChieu = g.MaGiaoHang
         WHERE c.MaChiTraTX = @MaChiTraTX AND g.TrangThaiThuNhap = N'ChoThanhToan';
        UPDATE dc SET dc.TrangThai = N'DaThanhToan', dc.NgayThanhToan = GETDATE()
          FROM DieuChinhThuNhap dc JOIN ChiTietChiTraTaiXe c ON c.Loai = N'DieuChinh' AND c.MaThamChieu = dc.MaDieuChinh
         WHERE c.MaChiTraTX = @MaChiTraTX AND dc.TrangThai = N'ChoThanhToan';
        EXEC sp_CapNhatTrangThaiKyDoiSoat @ky;
    COMMIT;
END;
GO

/* ---- 9.6 Hủy kỳ (chỉ khi chưa chi khoản nào): nhả đơn/chuyến để kỳ khác gom lại ---- */
CREATE OR ALTER PROCEDURE sp_HuyKyDoiSoat @MaKy INT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    IF NOT EXISTS (SELECT 1 FROM KyDoiSoat WHERE MaKy = @MaKy AND TrangThai IN (N'BanNhap', N'DaChot', N'DangChi'))
        THROW 50130, N'Kỳ không tồn tại hoặc đã hoàn tất/hủy.', 1;
    IF EXISTS (SELECT 1 FROM ChiTraGianHang WHERE MaKy = @MaKy AND TrangThai = N'DaChi')
       OR EXISTS (SELECT 1 FROM ChiTraTaiXe WHERE MaKy = @MaKy AND TrangThai = N'DaChi')
        THROW 50131, N'Kỳ đã có khoản được chi, không thể hủy.', 1;
    BEGIN TRAN;
        DELETE c FROM ChiTietChiTraGianHang c JOIN ChiTraGianHang h ON h.MaChiTraQuan = c.MaChiTraQuan WHERE h.MaKy = @MaKy;
        DELETE c FROM ChiTietChiTraTaiXe    c JOIN ChiTraTaiXe    h ON h.MaChiTraTX  = c.MaChiTraTX  WHERE h.MaKy = @MaKy;
        UPDATE ChiTraGianHang SET TrangThai = N'Huy' WHERE MaKy = @MaKy;
        UPDATE ChiTraTaiXe    SET TrangThai = N'Huy' WHERE MaKy = @MaKy;
        UPDATE KyDoiSoat      SET TrangThai = N'Huy' WHERE MaKy = @MaKy;
    COMMIT;
END;
GO

CREATE OR ALTER VIEW v_ChiTraGianHang AS
SELECT c.MaChiTraQuan, c.MaKy, k.TenKy, k.TuNgay, k.DenNgay, c.MaGianHang, g.TenCuaHang,
       c.SoDon, c.TienHang, c.TyLeChietKhau, c.PhiNenTang, c.DieuChinh, c.SoTienChiTra, c.TrangThai, c.NgayChi, c.MaGiaoDichNganHang
FROM ChiTraGianHang c JOIN KyDoiSoat k ON k.MaKy = c.MaKy JOIN GianHang g ON g.MaGianHang = c.MaGianHang;
GO

CREATE OR ALTER VIEW v_ChiTraTaiXe AS
SELECT c.MaChiTraTX, c.MaKy, k.TenKy, k.TuNgay, k.DenNgay, c.MaTaiXe, x.HoTen, x.SDT,
       c.SoChuyen, c.TienPhiGiao, c.TienDieuChinh, c.TienCODChuaNop, c.SoTienChiTra, c.TrangThai, c.NgayChi, c.MaGiaoDichNganHang
FROM ChiTraTaiXe c JOIN KyDoiSoat k ON k.MaKy = c.MaKy JOIN TaiXe x ON x.MaTaiXe = c.MaTaiXe;
GO

/* ============================================================
   10. ĐÁNH GIÁ: điểm trung bình (view) — không tạo bảng "ratings" riêng để khỏi trùng DanhGia/DanhGiaMon/GiaoHang.DiemTaiXe
   ============================================================ */
CREATE OR ALTER VIEW v_DiemDanhGiaGianHang AS       -- bỏ đánh giá đã bị ẩn (DanhGia.DaAn = 1)
SELECT d.MaGianHang, COUNT(*) AS SoDanhGia,
       CAST(AVG(CAST(d.SoSao AS FLOAT)) AS DECIMAL(3,2))            AS DiemQuan,
       CAST(AVG(CAST(d.SoSaoMon AS FLOAT)) AS DECIMAL(3,2))         AS DiemMon,
       CAST(AVG(CAST(d.SoSaoGiaoHang AS FLOAT)) AS DECIMAL(3,2))    AS DiemGiaoHang
FROM DanhGia d WHERE d.DaAn = 0 GROUP BY d.MaGianHang;
GO

CREATE OR ALTER VIEW v_DiemDanhGiaMon AS
SELECT m.MaMonAn, COUNT(*) AS SoDanhGia, CAST(AVG(CAST(m.SoSao AS FLOAT)) AS DECIMAL(3,2)) AS DiemTrungBinh
FROM DanhGiaMon m GROUP BY m.MaMonAn;
GO

CREATE OR ALTER VIEW v_DiemDanhGiaTaiXe AS
SELECT g.MaTaiXe, COUNT(*) AS SoDanhGia, CAST(AVG(CAST(g.DiemTaiXe AS FLOAT)) AS DECIMAL(3,2)) AS DiemTrungBinh
FROM GiaoHang g WHERE g.DiemTaiXe IS NOT NULL GROUP BY g.MaTaiXe;
GO

/* ============================================================
   11. ĐỒNG BỘ MỘT CHIỀU TỪ BẢN CŨ → BẢNG MỚI (chạy lại bao nhiêu lần cũng được; không ghi đè dữ liệu đã sửa ở bảng mới)
   ============================================================ */

/* 11.1 Vai trò: phản chiếu TaiKhoan.VaiTro và QuanTri.CapQuyenHan; dọn vai trò gốc/cấp quản trị không còn đúng (vai trò TuyChinh không bị đụng) */
CREATE OR ALTER PROCEDURE sp_DongBoVaiTroTaiKhoan
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO TaiKhoan_VaiTro (MaTK, MaVaiTro)
    SELECT t.MaTK, v.MaVaiTro
    FROM TaiKhoan t JOIN VaiTro v ON v.LoaiVaiTro = N'Goc' AND v.TenVaiTro = t.VaiTro
    WHERE NOT EXISTS (SELECT 1 FROM TaiKhoan_VaiTro x WHERE x.MaTK = t.MaTK AND x.MaVaiTro = v.MaVaiTro);

    INSERT INTO TaiKhoan_VaiTro (MaTK, MaVaiTro)
    SELECT q.MaTK, v.MaVaiTro
    FROM QuanTri q JOIN VaiTro v ON v.LoaiVaiTro = N'CapQuanTri' AND v.TenVaiTro = q.CapQuyenHan
    WHERE NOT EXISTS (SELECT 1 FROM TaiKhoan_VaiTro x WHERE x.MaTK = q.MaTK AND x.MaVaiTro = v.MaVaiTro);

    DELETE tv FROM TaiKhoan_VaiTro tv JOIN VaiTro v ON v.MaVaiTro = tv.MaVaiTro
    WHERE v.LoaiVaiTro = N'Goc'
      AND NOT EXISTS (SELECT 1 FROM TaiKhoan t WHERE t.MaTK = tv.MaTK AND t.VaiTro = v.TenVaiTro);

    DELETE tv FROM TaiKhoan_VaiTro tv JOIN VaiTro v ON v.MaVaiTro = tv.MaVaiTro
    WHERE v.LoaiVaiTro = N'CapQuanTri'
      AND NOT EXISTS (SELECT 1 FROM QuanTri q WHERE q.MaTK = tv.MaTK AND q.CapQuyenHan = v.TenVaiTro);
END;
GO

/* 11.2 Hồ sơ tài xế: xe chính + CCCD + GPLX từ cột cũ của TaiXe (chỉ thêm khi tài xế đó CHƯA có dòng loại đó) */
CREATE OR ALTER PROCEDURE sp_DongBoHoSoTaiXe
AS
BEGIN
    SET NOCOUNT ON;
    INSERT INTO PhuongTienTaiXe (MaTaiXe, LoaiXe, BienSo, LaXeChinh)
    SELECT x.MaTaiXe, ISNULL(NULLIF(LTRIM(RTRIM(x.PhuongTien)), N''), N'Xe máy'), LTRIM(RTRIM(x.BienSo)), 1
    FROM TaiXe x
    WHERE x.BienSo IS NOT NULL AND LTRIM(RTRIM(x.BienSo)) <> ''
      AND NOT EXISTS (SELECT 1 FROM PhuongTienTaiXe p WHERE p.MaTaiXe = x.MaTaiXe);

    INSERT INTO GiayToTaiXe (MaTaiXe, LoaiGiayTo, SoGiayTo, TrangThaiDuyet, LyDoTuChoi)
    SELECT x.MaTaiXe, N'CCCD', LTRIM(RTRIM(x.SoCCCD)), x.TrangThaiDuyet, x.LyDoTuChoi
    FROM TaiXe x
    WHERE x.SoCCCD IS NOT NULL AND LTRIM(RTRIM(x.SoCCCD)) <> ''
      AND NOT EXISTS (SELECT 1 FROM GiayToTaiXe g WHERE g.MaTaiXe = x.MaTaiXe AND g.LoaiGiayTo = N'CCCD');

    INSERT INTO GiayToTaiXe (MaTaiXe, LoaiGiayTo, SoGiayTo, DuongDanAnh, TrangThaiDuyet, LyDoTuChoi)
    SELECT x.MaTaiXe, N'GPLX', NULLIF(LTRIM(RTRIM(x.SoGPLX)), ''), x.AnhGPLX, x.TrangThaiDuyet, x.LyDoTuChoi
    FROM TaiXe x
    WHERE (NULLIF(LTRIM(RTRIM(x.SoGPLX)), '') IS NOT NULL OR NULLIF(LTRIM(RTRIM(x.AnhGPLX)), N'') IS NOT NULL)
      AND NOT EXISTS (SELECT 1 FROM GiayToTaiXe g WHERE g.MaTaiXe = x.MaTaiXe AND g.LoaiGiayTo = N'GPLX');
END;
GO

/* 11.2b Bảng TaiXeTuChoiDon / DieuPhoiLog có thể đã được tạo từ bản CŨ thiếu cột LyDo / ThoiGian
   (lỗi "Invalid column name 'LyDo' / 'ThoiGian'" khi tạo sp_DongBoPhanCongGiaoHang) -> bổ sung cột còn thiếu, KHÔNG xóa dữ liệu. */
IF OBJECT_ID('TaiXeTuChoiDon', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('TaiXeTuChoiDon', 'LyDo') IS NULL     EXEC(N'ALTER TABLE TaiXeTuChoiDon ADD LyDo NVARCHAR(300) NULL');
    IF COL_LENGTH('TaiXeTuChoiDon', 'ThoiGian') IS NULL EXEC(N'ALTER TABLE TaiXeTuChoiDon ADD ThoiGian DATETIME2 NOT NULL CONSTRAINT DF_TaiXeTuChoiDon_ThoiGian DEFAULT SYSDATETIME()');
END
IF OBJECT_ID('DieuPhoiLog', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('DieuPhoiLog', 'LyDo') IS NULL     EXEC(N'ALTER TABLE DieuPhoiLog ADD LyDo NVARCHAR(300) NOT NULL CONSTRAINT DF_DieuPhoiLog_LyDo DEFAULT N''''');
    IF COL_LENGTH('DieuPhoiLog', 'ThoiGian') IS NULL EXEC(N'ALTER TABLE DieuPhoiLog ADD ThoiGian DATETIME NOT NULL CONSTRAINT DF_DieuPhoiLog_ThoiGian DEFAULT GETDATE()');
END
GO

/* 11.3 Phân công giao hàng: chuyến hiện có + lần từ chối + lần bị gỡ/đổi tài xế (DieuPhoiLog) */
CREATE OR ALTER PROCEDURE sp_DongBoPhanCongGiaoHang
AS
BEGIN
    SET NOCOUNT ON;
    /* chuyến hiện có (GiaoHang): đang làm = DaNhan, đã kết thúc = HoanThanh */
    INSERT INTO PhanCongGiaoHang (MaDonHang, MaTaiXe, HinhThuc, TrangThai, MaTKPhanCong, NgayDeNghi, NgayPhanHoi)
    SELECT g.MaDonHang, g.MaTaiXe,
           CASE WHEN EXISTS (SELECT 1 FROM DieuPhoiLog l WHERE l.MaDonHang = g.MaDonHang AND l.HanhDong IN (N'PhanCong', N'DoiTaiXe') AND l.MaTaiXeMoi = g.MaTaiXe)
                THEN N'QuanTri' ELSE N'TuNhan' END,
           CASE WHEN g.TrangThai IN (N'GiaoThanhCong', N'GiaoThatBai') THEN N'HoanThanh' ELSE N'DaNhan' END,
           NULL, ISNULL(g.ThoiGianNhan, d.NgayDat), g.ThoiGianNhan
    FROM GiaoHang g JOIN DonHang d ON d.MaDonHang = g.MaDonHang
    WHERE NOT EXISTS (SELECT 1 FROM PhanCongGiaoHang p WHERE p.MaDonHang = g.MaDonHang AND p.MaTaiXe = g.MaTaiXe AND p.TrangThai IN (N'DaNhan', N'HoanThanh'));

    /* tài xế từ chối đơn */
    INSERT INTO PhanCongGiaoHang (MaDonHang, MaTaiXe, HinhThuc, TrangThai, LyDo, NgayDeNghi, NgayPhanHoi)
    SELECT c.MaDonHang, c.MaTaiXe, N'TuNhan', N'TuChoi', c.LyDo, c.ThoiGian, c.ThoiGian
    FROM TaiXeTuChoiDon c
    WHERE NOT EXISTS (SELECT 1 FROM PhanCongGiaoHang p WHERE p.MaDonHang = c.MaDonHang AND p.MaTaiXe = c.MaTaiXe AND p.TrangThai = N'TuChoi');

    /* tài xế cũ bị đổi/gỡ khỏi đơn */
    INSERT INTO PhanCongGiaoHang (MaDonHang, MaTaiXe, HinhThuc, TrangThai, LyDo, MaTKPhanCong, NgayDeNghi, NgayPhanHoi)
    SELECT l.MaDonHang, l.MaTaiXeCu, N'QuanTri', N'DaGo', l.LyDo,
           (SELECT t.MaTK FROM TaiKhoan t WHERE t.MaTK = l.MaTK), l.ThoiGian, l.ThoiGian
    FROM DieuPhoiLog l
    JOIN TaiXe x ON x.MaTaiXe = l.MaTaiXeCu
    WHERE l.HanhDong IN (N'DoiTaiXe', N'GoTaiXe') AND l.MaTaiXeCu IS NOT NULL
      AND NOT EXISTS (SELECT 1 FROM PhanCongGiaoHang p WHERE p.MaDonHang = l.MaDonHang AND p.MaTaiXe = l.MaTaiXeCu AND p.TrangThai = N'DaGo');
END;
GO

/* 11.4 Phản hồi cũ (PhanHoi) → phiếu hỗ trợ + tin nhắn đầu (khách) + tin trả lời (quản trị) */
CREATE OR ALTER PROCEDURE sp_DongBoPhanHoiSangPhieuHoTro
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRAN;
        INSERT INTO PhieuHoTro (MaTKNguoiGui, VaiTroNguoiGui, MaDonHang, MaGianHang, PhanLoai, Loai, TieuDe, TrangThai,
                                MaTKPhuTrach, MaPhanHoi, NgayTao, NgayCapNhat, NgayDong)
        SELECT k.MaTK, N'KhachHang', p.MaDonHang, p.MaGianHang, p.PhanLoai, p.Loai, p.TieuDe, p.TrangThai,
               (SELECT t.MaTK FROM TaiKhoan t WHERE t.MaTK = p.MaTKPhuTrach),
               p.MaPhanHoi, p.NgayGui, ISNULL(p.NgayXuLy, p.NgayGui),
               CASE WHEN p.TrangThai = N'DaXuLy' THEN p.NgayXuLy END
        FROM PhanHoi p JOIN KhachHang k ON k.MaKH = p.MaKH
        WHERE NOT EXISTS (SELECT 1 FROM PhieuHoTro h WHERE h.MaPhanHoi = p.MaPhanHoi);

        INSERT INTO TinNhanHoTro (MaPhieu, MaTKGui, VaiTroGui, NoiDung, NgayGui)
        SELECT h.MaPhieu, h.MaTKNguoiGui, N'KhachHang', p.NoiDung, p.NgayGui
        FROM PhieuHoTro h JOIN PhanHoi p ON p.MaPhanHoi = h.MaPhanHoi
        WHERE NOT EXISTS (SELECT 1 FROM TinNhanHoTro m WHERE m.MaPhieu = h.MaPhieu AND m.VaiTroGui = N'KhachHang');

        INSERT INTO TinNhanHoTro (MaPhieu, MaTKGui, VaiTroGui, NoiDung, NgayGui)
        SELECT h.MaPhieu, h.MaTKPhuTrach, N'QuanTri', p.TraLoi, ISNULL(p.NgayXuLy, p.NgayGui)
        FROM PhieuHoTro h JOIN PhanHoi p ON p.MaPhanHoi = h.MaPhanHoi
        WHERE p.TraLoi IS NOT NULL AND LTRIM(RTRIM(p.TraLoi)) <> N''
          AND NOT EXISTS (SELECT 1 FROM TinNhanHoTro m WHERE m.MaPhieu = h.MaPhieu AND m.VaiTroGui = N'QuanTri');
    COMMIT;
END;
GO

CREATE OR ALTER PROCEDURE sp_DongBoThietKeMoi     -- chạy tất cả; gọi lại sau khi có tài khoản/tài xế/phản hồi mới từ app cũ
AS
BEGIN
    SET NOCOUNT ON;
    EXEC sp_DongBoVaiTroTaiKhoan;
    EXEC sp_DongBoHoSoTaiXe;
    EXEC sp_DongBoPhanCongGiaoHang;
    EXEC sp_DongBoPhanHoiSangPhieuHoTro;
END;
GO

EXEC sp_DongBoThietKeMoi;
GO

/* ============================================================
   12. ĐỐI CHIẾU 37 BẢNG CỦA ĐỀ BÀI  (cột TonTai phải toàn = 1)
   ============================================================ */
SELECT v.Nhom, v.TenDeBai, v.TenTrongCSDL, v.Nguon,
       CASE WHEN EXISTS (SELECT 1 FROM sys.tables t WHERE t.name = v.TenTrongCSDL) THEN 1 ELSE 0 END AS TonTai
FROM (VALUES
 (N'Tài khoản',   'users',                  'TaiKhoan',               N'có sẵn'),
 (N'Tài khoản',   'roles',                  'VaiTro',                 N'MỚI'),
 (N'Tài khoản',   'permissions',            'Quyen',                  N'MỚI (+VaiTro_Quyen)'),
 (N'Tài khoản',   'user_roles',             'TaiKhoan_VaiTro',        N'MỚI'),
 (N'Khách hàng',  'customers',              'KhachHang',              N'có sẵn'),
 (N'Khách hàng',  'customer_addresses',     'DiaChiKhachHang',        N'có sẵn'),
 (N'Nhà hàng',    'restaurants',            'GianHang',               N'có sẵn'),
 (N'Nhà hàng',    'restaurant_branches',    'ChiNhanhGianHang',       N'MỚI'),
 (N'Nhà hàng',    'restaurant_hours',       'GioLamViecGianHang',     N'MỚI'),
 (N'Thực đơn',    'categories',             'DanhMuc',                N'có sẵn'),
 (N'Thực đơn',    'products',               'MonAn',                  N'có sẵn'),
 (N'Thực đơn',    'product_options',        'TuyChonMon',             N'có sẵn'),
 (N'Thực đơn',    'product_images',         'HinhAnhMonAn',           N'MỚI'),
 (N'Tài xế',      'drivers',                'TaiXe',                  N'có sẵn'),
 (N'Tài xế',      'driver_vehicles',        'PhuongTienTaiXe',        N'MỚI'),
 (N'Tài xế',      'driver_documents',       'GiayToTaiXe',            N'MỚI'),
 (N'Tài xế',      'driver_locations',       'LichSuViTriTaiXe',       N'MỚI (TaiXeViTri = vị trí theo đơn, có sẵn)'),
 (N'Đơn hàng',    'orders',                 'DonHang',                N'có sẵn'),
 (N'Đơn hàng',    'order_items',            'ChiTietDonHang',         N'có sẵn'),
 (N'Đơn hàng',    'order_status_histories', 'LichSuTrangThaiDon',     N'có sẵn'),
 (N'Giao hàng',   'deliveries',             'GiaoHang',               N'có sẵn'),
 (N'Giao hàng',   'delivery_assignments',   'PhanCongGiaoHang',       N'MỚI'),
 (N'Thanh toán',  'payments',               'ThanhToan',              N'có sẵn'),
 (N'Thanh toán',  'refunds',                'YeuCauHoanTien',         N'có sẵn'),
 (N'Thanh toán',  'transactions',           'GiaoDichThanhToan',      N'có sẵn'),
 (N'Khuyến mãi',  'vouchers',               'KhuyenMai',              N'có sẵn'),
 (N'Khuyến mãi',  'voucher_usages',         'KhuyenMaiKhachDung',     N'có sẵn'),
 (N'Khuyến mãi',  'promotions',             'ChuongTrinhKhuyenMai',   N'MỚI (+ChuongTrinhKhuyenMai_Voucher)'),
 (N'Đánh giá',    'reviews',                'DanhGia',                N'có sẵn'),
 (N'Đánh giá',    'ratings',                'DanhGiaMon',             N'có sẵn (+3 view điểm TB, mục 10)'),
 (N'Thông báo',   'notifications',          'ThongBao',               N'có sẵn'),
 (N'Thông báo',   'notification_logs',      'NhatKyThongBao',         N'MỚI'),
 (N'Hỗ trợ',      'support_tickets',        'PhieuHoTro',             N'MỚI'),
 (N'Hỗ trợ',      'support_messages',       'TinNhanHoTro',           N'MỚI'),
 (N'Báo cáo',     'settlements',            'KyDoiSoat',              N'MỚI'),
 (N'Báo cáo',     'restaurant_payouts',     'ChiTraGianHang',         N'MỚI (+ChiTietChiTraGianHang)'),
 (N'Báo cáo',     'driver_payouts',         'ChiTraTaiXe',            N'MỚI (+ChiTietChiTraTaiXe)')
) v (Nhom, TenDeBai, TenTrongCSDL, Nguon);
GO

/* ===== VÍ DỤ SỬ DỤNG =====
-- Quyền của tài khoản theo vai trò
SELECT * FROM v_QuyenTaiKhoan WHERE TenDangNhap = N'admin';

-- Giờ làm việc: quán 1 mở T2–T6 hai ca, T7–CN nghỉ trưa không mở
INSERT INTO GioLamViecGianHang (MaGianHang, Thu, GioMo, GioDong) VALUES (1,1,'07:00','11:00'),(1,1,'17:00','22:00');
INSERT INTO GioLamViecGianHang (MaGianHang, Thu, NghiCaNgay) VALUES (1,7,1);
SELECT * FROM v_GioLamViecHieuLuc WHERE MaGianHang = 1 ORDER BY Thu, GioMo;

-- Vị trí tài xế
EXEC sp_GhiViTriTaiXe @MaTaiXe = 1, @ViDo = 10.8231, @KinhDo = 106.6297, @MaDonHang = NULL;
SELECT * FROM v_ViTriTaiXeMoiNhat;

-- Đối soát tháng 9/2026: tạo -> xem -> chốt -> chi từng khoản
DECLARE @ky INT;
EXEC sp_TaoKyDoiSoat @TuNgay = '2026-09-01', @DenNgay = '2026-09-30', @MaTK = 1, @MaKy = @ky OUTPUT;
SELECT * FROM v_ChiTraGianHang WHERE MaKy = @ky;
SELECT * FROM v_ChiTraTaiXe    WHERE MaKy = @ky;
EXEC sp_ChotKyDoiSoat @MaKy = @ky;
EXEC sp_DanhDauDaChiTraQuan @MaChiTraQuan = 1, @PhuongThuc = N'ChuyenKhoan', @MaGiaoDichNganHang = N'FT26273...', @MaTK = 1;
EXEC sp_DanhDauDaChiTraTaiXe @MaChiTraTX = 1, @MaTK = 1;
-- Hủy kỳ nếu chưa chi khoản nào: EXEC sp_HuyKyDoiSoat @MaKy = @ky;

-- Điểm trung bình
SELECT * FROM v_DiemDanhGiaGianHang; SELECT * FROM v_DiemDanhGiaMon; SELECT * FROM v_DiemDanhGiaTaiXe;

-- Sau khi app cũ tạo thêm tài khoản/tài xế/phản hồi: nạp lại bảng mới
EXEC sp_DongBoThietKeMoi;
*/
