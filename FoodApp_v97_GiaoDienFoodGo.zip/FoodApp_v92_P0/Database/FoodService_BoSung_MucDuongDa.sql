﻿/* Bổ sung loại tùy chọn "Mức đường" và "Mức đá" cho TuyChonMon (chạy một lần trên CSDL đã có). An toàn khi chạy lại. */
IF OBJECT_ID('TuyChonMon', 'U') IS NOT NULL
BEGIN
    DECLARE @ten SYSNAME, @sql NVARCHAR(400);
    DECLARE c CURSOR LOCAL FAST_FORWARD FOR
        SELECT cc.name FROM sys.check_constraints cc
        WHERE cc.parent_object_id = OBJECT_ID('TuyChonMon') AND cc.definition LIKE '%Loai%' AND cc.definition LIKE '%MucCay%';
    OPEN c; FETCH NEXT FROM c INTO @ten;
    WHILE @@FETCH_STATUS = 0
    BEGIN
        SET @sql = N'ALTER TABLE TuyChonMon DROP CONSTRAINT ' + QUOTENAME(@ten);
        EXEC(@sql);
        FETCH NEXT FROM c INTO @ten;
    END
    CLOSE c; DEALLOCATE c;

    IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE parent_object_id = OBJECT_ID('TuyChonMon') AND name = 'CK_TuyChonMon_Loai')
        ALTER TABLE TuyChonMon ADD CONSTRAINT CK_TuyChonMon_Loai
            CHECK (Loai IN (N'Size', N'Topping', N'MucCay', N'MucDuong', N'MucDa'));
END
GO
