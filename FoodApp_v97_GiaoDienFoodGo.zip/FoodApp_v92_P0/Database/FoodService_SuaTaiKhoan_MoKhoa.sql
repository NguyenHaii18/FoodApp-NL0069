﻿/* ============================================================
   FoodService_SuaTaiKhoan_MoKhoa.sql
   Sửa lỗi: tài khoản bị khóa hàng loạt / admin không đăng nhập được / "Mở khóa" gian hàng báo lỗi 500.
   - Đảm bảo bảng AuditLog + trigger trg_Audit_TaiKhoan chuẩn (thiếu/lệch thì UPDATE TaiKhoan lỗi 500)
   - Mở lại tài khoản mẫu từng bị BaoMat_VoHieuHoaTaiKhoanMau.sql vô hiệu hóa (trả mật khẩu mẫu theo vai trò)
   - Mở khóa mọi gian hàng, gỡ khóa tạm do nhập sai nhiều lần
   - Đặt admin app: admin@fooddelivery.vn / admin123 ; web: quantri01 / admin123
   Chạy lại nhiều lần an toàn. Không xóa dữ liệu. Lỗi nào cũng rollback và in rõ nguyên nhân.
   ============================================================ */
USE QuanLyDichVuAnUong;

IF DB_NAME() <> N'QuanLyDichVuAnUong' OR OBJECT_ID('TaiKhoan', 'U') IS NULL
BEGIN
    RAISERROR(N'DỪNG: không vào được CSDL QuanLyDichVuAnUong hoặc thiếu bảng TaiKhoan. Kiểm tra lại Server name (localdb)\MSSQLLocalDB.', 16, 1);
    RETURN;
END

BEGIN TRY
    /* 1) Bảng AuditLog */
    IF OBJECT_ID('AuditLog', 'U') IS NULL
    BEGIN
        CREATE TABLE AuditLog (
            MaAudit   BIGINT IDENTITY(1,1) PRIMARY KEY,
            ThoiGian  DATETIME2(3) NOT NULL DEFAULT SYSDATETIME(),
            MaTK      INT NULL,
            HanhDong  NVARCHAR(10) NOT NULL,
            Bang      NVARCHAR(60) NOT NULL,
            KhoaChinh NVARCHAR(50) NOT NULL,
            GiaTriCu  NVARCHAR(MAX) NULL,
            GiaTriMoi NVARCHAR(MAX) NULL
        );
        PRINT N'Đã tạo bảng AuditLog';
    END

    /* 2) Trigger audit của TaiKhoan (bản chuẩn, không ghi mật khẩu) */
    EXEC(N'CREATE OR ALTER TRIGGER trg_Audit_TaiKhoan ON TaiKhoan AFTER INSERT, UPDATE, DELETE AS
    BEGIN
        SET NOCOUNT ON;
        DECLARE @tk INT = TRY_CAST(SESSION_CONTEXT(N''MaTK'') AS INT);
        INSERT INTO AuditLog (MaTK, HanhDong, Bang, KhoaChinh, GiaTriCu, GiaTriMoi)
        SELECT @tk,
               CASE WHEN d.MaTK IS NULL THEN N''INSERT'' WHEN i.MaTK IS NULL THEN N''DELETE'' ELSE N''UPDATE'' END,
               N''TaiKhoan'', CAST(COALESCE(i.MaTK, d.MaTK) AS NVARCHAR(50)),
               CASE WHEN d.MaTK IS NULL THEN NULL
                    ELSE (SELECT d.TenDangNhap, d.VaiTro, d.TrangThai FOR JSON PATH, WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES) END,
               CASE WHEN i.MaTK IS NULL THEN NULL
                    ELSE (SELECT i.TenDangNhap, i.VaiTro, i.TrangThai,
                                 CAST(CASE WHEN d.MaTK IS NOT NULL AND i.MatKhau <> d.MatKhau THEN 1 ELSE 0 END AS BIT) AS DoiMatKhau
                          FOR JSON PATH, WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES) END
        FROM inserted i FULL OUTER JOIN deleted d ON i.MaTK = d.MaTK
        WHERE d.MaTK IS NULL OR i.MaTK IS NULL
           OR i.TrangThai <> d.TrangThai OR i.VaiTro <> d.VaiTro OR i.TenDangNhap <> d.TenDangNhap OR i.MatKhau <> d.MatKhau;
    END');

    /* 3) Khôi phục / mở khóa tài khoản */
    BEGIN TRAN;

    DECLARE @KhongDungDuoc NVARCHAR(255) = N'$2b$11$TAI.KHOAN.MAU.DA.BI.VO.HIEU.HOA.HAY.DAT.LAI.MAT.KHAU';
    DECLARE @Hash123456    NVARCHAR(255) = N'$2b$11$/kiGvUEE4J218RaDaW8cReCEE3eH53tJBuwpXN5FzQc/BPWr3MHMO'; -- = 123456
    DECLARE @HashAdmin123  NVARCHAR(255) = N'$2b$11$4W4e54I7Wm8IZICGB5WG5eJicrEVilueK2EWGeKHOeTK/8ZNZnzzW'; -- = admin123

    -- 3a) Tài khoản mẫu từng bị vô hiệu hóa: mở lại + trả mật khẩu theo vai trò
    UPDATE TaiKhoan
    SET TrangThai = 1,
        MatKhau = CASE WHEN VaiTro = N'QuanTri' THEN @HashAdmin123 ELSE @Hash123456 END
    WHERE MatKhau = @KhongDungDuoc;

    -- 3b) Mở khóa TẤT CẢ gian hàng
    UPDATE TaiKhoan SET TrangThai = 1 WHERE VaiTro = N'GianHang';

    -- 3c) Gỡ khóa tạm do nhập sai nhiều lần (chỉ khi có đủ 2 cột)
    IF COL_LENGTH('TaiKhoan', 'SoLanDangNhapSai') IS NOT NULL AND COL_LENGTH('TaiKhoan', 'KhoaDen') IS NOT NULL
        EXEC(N'UPDATE TaiKhoan SET SoLanDangNhapSai = 0, KhoaDen = NULL');

    -- 3d) Admin app: admin@fooddelivery.vn / admin123
    DECLARE @maTK INT = (SELECT MaTK FROM TaiKhoan WHERE TenDangNhap = N'quantri01');
    IF @maTK IS NOT NULL
    BEGIN
        UPDATE QuanTri SET Email = 'admin_cu_' + CAST(MaTK AS VARCHAR(10)) + '@fooddelivery.vn'
        WHERE Email = 'admin@fooddelivery.vn' AND MaTK <> @maTK;
        UPDATE QuanTri SET Email = 'admin@fooddelivery.vn' WHERE MaTK = @maTK;
        UPDATE TaiKhoan SET TrangThai = 1, MatKhau = @HashAdmin123 WHERE MaTK = @maTK;
    END
    ELSE PRINT N'Cảnh báo: không thấy tài khoản quantri01';

    COMMIT;
    PRINT N'>>> XONG phần sửa tài khoản, không có lỗi.';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0 ROLLBACK;
    PRINT N'>>> LỖI SQL (gửi dòng này cho mình): ' + ERROR_MESSAGE()
        + N' | Dòng: ' + CAST(ERROR_LINE() AS NVARCHAR(10))
        + N' | Thủ tục/trigger: ' + ISNULL(ERROR_PROCEDURE(), N'(không có)');
END CATCH

/* 4) Kiểm tra kết quả */
SELECT VaiTro, COUNT(*) AS Tong,
       SUM(CASE WHEN TrangThai = 1 THEN 1 ELSE 0 END) AS DangHoatDong,
       SUM(CASE WHEN TrangThai = 0 THEN 1 ELSE 0 END) AS DangKhoa
FROM TaiKhoan GROUP BY VaiTro;

SELECT q.MaTK, tk.TenDangNhap, q.Email, q.CapQuyenHan, tk.TrangThai
FROM QuanTri q JOIN TaiKhoan tk ON tk.MaTK = q.MaTK;

IF OBJECT_ID('NhatKyHeThong', 'U') IS NOT NULL
    EXEC(N'SELECT TOP 5 ThoiGian, ThongDiep, DuongDan FROM NhatKyHeThong WHERE MucDo = ''Error'' ORDER BY ThoiGian DESC');
