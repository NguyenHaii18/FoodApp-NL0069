# Quy trình cơ sở dữ liệu: khởi tạo – nâng cấp – sao lưu

| Tình huống | Dùng file | Có xóa dữ liệu? |
|---|---|---|
| CSDL chưa có (máy mới) | `Database/FoodService_Database.sql` | Không |
| CSDL đã có, cần giữ dữ liệu | `Database/FoodService_NangCap.sql` (chạy lại nhiều lần an toàn) | Không |
| Cố ý xóa làm lại từ đầu | `FoodService_Database.sql` với `@CHO_PHEP_XOA_DB = 1` | Có — tự sao lưu `.bak` trước; sao lưu lỗi thì dừng |
| Bổ sung 21 bảng theo thiết kế (vai trò/quyền, chi nhánh, phương tiện, phân công, hỗ trợ, đối soát...) | `Database/FoodService_NangCap.sql` (đã gộp trong file nâng cấp) | Không |
| Sao lưu / phục hồi / nghiệm thu | `Database/FoodService_NghiemThu_SaoLuu.sql` | Không |
| Khóa tài khoản mẫu trước khi chạy thật | `Database/BaoMat_VoHieuHoaTaiKhoanMau.sql` | Không (chỉ khóa/đổi mật khẩu) |

## Quy tắc
1. Trước mọi lần thử: sao lưu (`BACKUP DATABASE QuanLyDichVuAnUong TO DISK = 'D:\\backup\\truoc_khi_thu.bak' WITH INIT, CHECKSUM;`).
2. `FoodService_Database.sql` mặc định DỪNG nếu CSDL đã tồn tại (`@CHO_PHEP_XOA_DB = 0`). Không đổi cờ này trên dữ liệu cần giữ.
3. Mỗi thay đổi schema: sửa entity → thêm vào `FoodService_Database.sql` (khởi tạo) VÀ `FoodService_NangCap.sql` (nâng cấp, kiểu `IF COL_LENGTH(...) IS NULL ALTER TABLE ...`).
4. Web gọi `EnsureCreated()` khi khởi động: chỉ tạo CSDL nếu CHƯA có, không cập nhật schema CSDL đã có — vì vậy nguồn sự thật schema là hai file SQL ở trên, không phải EF Migrations. Để lệch schema không âm thầm gây lỗi lúc chạy, Web có `Services/KiemTraSchema.cs`: khi khởi động so sánh mô hình EF với CSDL thật (chỉ đọc), in cảnh báo thiếu bảng/cột ở console, hiện thanh đỏ ở trang quản trị và liệt kê ở "Hệ thống & phiên"; đặt `Database:DungKhiLechSchema=true` để Web từ chối khởi động khi lệch.
5. Kiểm thử schema: (a) CSDL sạch: chạy `FoodService_Database.sql`; (b) CSDL cũ có dữ liệu: khôi phục bản sao lưu cũ rồi chạy `FoodService_NangCap.sql`; sau đó chạy `Database/FoodService_NghiemThu_SaoLuu.sql` phần A để đối chiếu cột, rồi `Tools/NghiemThu_E2E.ps1`.

## EF Core Migrations
Chưa dùng. Chuyển sang Migrations chỉ nên làm một lần, trên máy có .NET SDK: `dotnet ef migrations add Baseline` từ CSDL hiện có, đánh dấu đã áp dụng, rồi bỏ `EnsureCreated()`. Không trộn hai quy trình.

## Các file SQL đầy đủ trong `Database/` (bổ sung v94)
| Tình huống | Dùng file |
|---|---|
| CSDL đã có — chạy MỘT file gộp mọi thứ (khuyên dùng) | `FoodService_GOP_TATCA.sql` |
| Máy mới — tạo CSDL + chạy mọi thứ | `FoodService_GOP_DB_MOI.sql` |
| Chỉ mở khóa tài khoản / sửa admin / sửa AuditLog | `FoodService_SuaTaiKhoan_MoKhoa.sql` |
| Chạy riêng từng phần của NangCap | `FoodService_BoSung_ThietKe.sql`, `FoodService_BoSung_MucDuongDa.sql` |
| Dữ liệu mẫu (20 gian hàng + 20 khách) | `FoodService_DuLieuMau.sql` hoặc từng file `FoodService_ThemGianHangMau.sql` / `FoodService_ThemKhachHangMau.sql` |
| Size S/M/L cho món nước | `FoodService_ThemSizeNuoc.sql` |

Các file gộp bật `Query > SQLCMD Mode`; quên bật thì file tự chặn, không thay đổi gì. `BaoMat_VoHieuHoaTaiKhoanMau.sql` trong file gộp chỉ ở chế độ xem trước (2 biến để trống).
