﻿/* Tách từ FoodService_DuLieuMau.sql [1/2] (bản v94: 20 gian hàng mẫu + ảnh/món Bún Chả). Nội dung giữ nguyên. */
/* FoodService_ThemGianHangMau.sql — thêm 10 gian hàng mẫu đã duyệt (mật khẩu đăng nhập: 123456).
   Chạy sau FoodService_Database.sql + FoodService_NangCap.sql (cần cột GianHang.Email, TaiKhoan.EmailDaXacThuc). Chạy lại nhiều lần vẫn an toàn.
   ĐÃ SỬA: trước đây 10 khối INSERT tham chiếu thẳng cột Email / EmailDaXacThuc; CSDL cũ chưa nâng cấp (hoặc chạy nhầm CSDL) sẽ báo hàng loạt lỗi
   "Invalid column name ...". Nay script kiểm tra CSDL + các cột cần thiết trước và DỪNG với hướng dẫn rõ; việc chèn chạy bằng SQL động trong
   đúng CSDL nên không còn lỗi biên dịch giả. */
SET NOCOUNT ON;
DECLARE @Db sysname = N'QuanLyDichVuAnUong';

IF DB_ID(@Db) IS NULL
    THROW 50020, N'DỪNG: chưa có CSDL QuanLyDichVuAnUong. Chạy FoodService_Database.sql (máy mới) hoặc FoodService_NangCap.sql trước.', 1;

DECLARE @can TABLE (Bang sysname, Cot sysname);
INSERT @can VALUES
    (N'TaiKhoan', N'TenDangNhap'), (N'TaiKhoan', N'MatKhau'), (N'TaiKhoan', N'VaiTro'), (N'TaiKhoan', N'EmailDaXacThuc'),
    (N'GianHang', N'MaTK'), (N'GianHang', N'TenCuaHang'), (N'GianHang', N'DiaChi'), (N'GianHang', N'SDT'), (N'GianHang', N'MoTa'),
    (N'GianHang', N'Email'), (N'GianHang', N'TrangThaiKinhDoanh'), (N'GianHang', N'TrangThaiDuyet');
DECLARE @thieu NVARCHAR(MAX) = N'';
SELECT @thieu = @thieu + N'  - ' + Bang + N'.' + Cot + NCHAR(10)
FROM @can WHERE COL_LENGTH(QUOTENAME(@Db) + N'.dbo.' + QUOTENAME(Bang), Cot) IS NULL;
IF @thieu <> N''
BEGIN
    SET @thieu = N'DỪNG: CSDL chưa nâng cấp đủ, còn thiếu:' + NCHAR(10) + LEFT(@thieu, 1300)
               + N'=> SAO LƯU CSDL rồi chạy Database/FoodService_NangCap.sql (không xóa dữ liệu), sau đó chạy lại file này.';
    THROW 50021, @thieu, 1;
END

DECLARE @MatKhauHash NVARCHAR(255) = N'$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu';   -- BCrypt của 123456
DECLARE @quan TABLE (TenDangNhap NVARCHAR(100), Ten NVARCHAR(200), DiaChi NVARCHAR(300), SDT VARCHAR(20), MoTa NVARCHAR(500), Email VARCHAR(150));
INSERT @quan VALUES
    (N'bunchahuonglien', N'Bún Chả Hương Liên', N'27 Lê Văn Sỹ, Q.3, TP.HCM', '0968881347', N'Bún chả, nem rán Hà Nội', 'bunchahuonglien@foodapp.vn'),
    (N'comgauthien', N'Cơm Gà Xối Mỡ Út Hiền', N'64 Lý Thường Kiệt, Q.10, TP.HCM', '0993957772', N'Cơm gà xối mỡ giòn da', 'comgauthien@foodapp.vn'),
    (N'banhxeo2lua', N'Bánh Xèo Miền Tây Hai Lúa', N'109 Võ Văn Tần, Q.3, TP.HCM', '0950322955', N'Bánh xèo, bánh khọt giòn rụm', 'banhxeo2lua@foodapp.vn'),
    (N'miquangbamua', N'Mì Quảng Bà Mua', N'31 Phan Xích Long, Q.Phú Nhuận, TP.HCM', '0971165393', N'Mì Quảng, bún mắm nêm', 'miquangbamua@foodapp.vn'),
    (N'sushikohaku', N'Sushi Kohaku', N'15 Lê Thánh Tôn, Q.1, TP.HCM', '0993934431', N'Sushi, sashimi, cơm cuộn', 'sushikohaku@foodapp.vn'),
    (N'pizzamama', N'Pizza Nhà Làm Mama', N'82 Nguyễn Thị Minh Khai, Q.3, TP.HCM', '0973185837', N'Pizza đế mỏng, mì Ý sốt bò bằm', 'pizzamama@foodapp.vn'),
    (N'caphemuoipho', N'Cà Phê Muối Phố Cổ', N'7 Pasteur, Q.1, TP.HCM', '0928133569', N'Cà phê muối, bạc xỉu, cold brew', 'caphemuoipho@foodapp.vn'),
    (N'lauthaibangkok', N'Lẩu Thái Tomyum Bangkok', N'240 Nguyễn Văn Cừ, Q.5, TP.HCM', '0951633055', N'Lẩu Thái, gà nướng sả', 'lauthaibangkok@foodapp.vn'),
    (N'xoigacotu', N'Xôi Gà Nướng Cô Tư', N'58 Tô Hiến Thành, Q.10, TP.HCM', '0936168676', N'Xôi mặn, gà nướng mật ong', 'xoigacotu@foodapp.vn'),
    (N'kemtraicay', N'Kem Trái Cây Mát Lạnh', N'9 Nguyễn Thượng Hiền, Q.3, TP.HCM', '0941547797', N'Kem, sinh tố, trái cây dĩa', 'kemtraicay@foodapp.vn'),
    (N'hutieunamvang', N'Hủ Tiếu Nam Vang Cô Ba', N'215 Nguyễn Trãi, Q.1, TP.HCM', '0930008019', N'Hủ tiếu Nam Vang, mì xá xíu', 'hutieunamvang@foodapp.vn'),
    (N'banhmihoaima', N'Bánh Mì Hòa Mã', N'53 Trần Phú, Q.4, TP.HCM', '0930015938', N'Bánh mì thịt nướng, xíu mại, pate', 'banhmihoaima@foodapp.vn'),
    (N'chegiaiphong', N'Chè Sương Sa Hạt Lựu', N'12 Hậu Giang, Q.6, TP.HCM', '0930023857', N'Chè thái, sương sa hạt lựu, chè khúc bạch', 'chegiaiphong@foodapp.vn'),
    (N'bunbohue7', N'Bún Bò Huế O Tâm', N'88 Nguyễn Thị Thập, Q.7, TP.HCM', '0930031776', N'Bún bò Huế, giò heo, chả cua', 'bunbohue7@foodapp.vn'),
    (N'comtamq8', N'Cơm Tấm Sườn Bì Chả Q8', N'141 Phạm Thế Hiển, Q.8, TP.HCM', '0930039695', N'Cơm tấm sườn nướng, bì, chả trứng', 'comtamq8@foodapp.vn'),
    (N'banhcuonq11', N'Bánh Cuốn Nóng Thanh Trì', N'30 Lạc Long Quân, Q.11, TP.HCM', '0930047614', N'Bánh cuốn nóng, chả lụa, nem chua', 'banhcuonq11@foodapp.vn'),
    (N'trasuaq12', N'Trà Sữa Mây Hồng', N'76 Quang Trung, Q.12, TP.HCM', '0930055533', N'Trà sữa, trà trái cây, hồng trà macchiato', 'trasuaq12@foodapp.vn'),
    (N'ocgovap', N'Ốc Đêm Gò Vấp', N'205 Quang Trung, Q.Gò Vấp, TP.HCM', '0930063452', N'Ốc các loại, sò điệp nướng mỡ hành', 'ocgovap@foodapp.vn'),
    (N'phobotanbinh', N'Phở Bò Tái Lăn Tân Bình', N'18 Cộng Hòa, Q.Tân Bình, TP.HCM', '0930071371', N'Phở tái lăn, phở gà, quẩy', 'phobotanbinh@foodapp.vn'),
    (N'bunthitnuongtd', N'Bún Thịt Nướng Thủ Đức', N'92 Võ Văn Ngân, TP.Thủ Đức, TP.HCM', '0930079290', N'Bún thịt nướng, chả giò, nem nướng', 'bunthitnuongtd@foodapp.vn');

DECLARE @u NVARCHAR(100), @ten NVARCHAR(200), @dc NVARCHAR(300), @sdt VARCHAR(20), @mt NVARCHAR(500), @em VARCHAR(150);
DECLARE @them NVARCHAR(MAX) = N'USE ' + QUOTENAME(@Db) + N';
IF NOT EXISTS (SELECT 1 FROM TaiKhoan WHERE TenDangNhap = @u)
BEGIN
    INSERT INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro, EmailDaXacThuc) VALUES (@u, @h, N''GianHang'', 1);
    INSERT INTO GianHang (MaTK, TenCuaHang, DiaChi, SDT, MoTa, Email, TrangThaiKinhDoanh, TrangThaiDuyet)
    VALUES (SCOPE_IDENTITY(), @ten, @dc, @sdt, @mt, @em, N''DangMo'', N''DaDuyet'');
    SET @moi = 1;
END';
DECLARE @moi INT, @tong INT = 0;
DECLARE c CURSOR LOCAL FAST_FORWARD FOR SELECT TenDangNhap, Ten, DiaChi, SDT, MoTa, Email FROM @quan;
OPEN c; FETCH NEXT FROM c INTO @u, @ten, @dc, @sdt, @mt, @em;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @moi = 0;
    EXEC sp_executesql @them,
         N'@u NVARCHAR(100), @h NVARCHAR(255), @ten NVARCHAR(200), @dc NVARCHAR(300), @sdt VARCHAR(20), @mt NVARCHAR(500), @em VARCHAR(150), @moi INT OUTPUT',
         @u = @u, @h = @MatKhauHash, @ten = @ten, @dc = @dc, @sdt = @sdt, @mt = @mt, @em = @em, @moi = @moi OUTPUT;
    IF @moi = 1 BEGIN SET @tong += 1; PRINT N'Đã thêm: ' + @ten; END
    FETCH NEXT FROM c INTO @u, @ten, @dc, @sdt, @mt, @em;
END
CLOSE c; DEALLOCATE c;
PRINT N'Hoàn tất: thêm mới ' + CAST(@tong AS NVARCHAR(10)) + N' / 20 gian hàng (những quán đã có sẵn được giữ nguyên).';
GO

/* Ảnh + món mẫu cho "Bún Chả Hương Liên" (ảnh nằm ở Web/FoodServiceApp.Web/wwwroot/uploads/bun_cha.jpg). Chạy lại an toàn.
   ĐÃ SỬA (lỗi "Invalid object name 'GianHang' / 'DanhMuc' / 'MonAn'", "Invalid column name 'MaGianHang' / 'Email' / 'HinhAnh'..."):
   khối này nằm SAU lệnh GO nên chạy ở CSDL đang mở (thường là master) chứ không phải QuanLyDichVuAnUong, và vẫn chạy cả khi phần trên đã DỪNG.
   Nay nó chạy bằng SQL động trong đúng CSDL và tự bỏ qua nếu CSDL / cột Email chưa có. */
SET NOCOUNT ON;
IF DB_ID(N'QuanLyDichVuAnUong') IS NULL OR COL_LENGTH(N'QuanLyDichVuAnUong.dbo.GianHang', N'Email') IS NULL
    PRINT N'Bỏ qua ảnh + món mẫu: chưa có CSDL QuanLyDichVuAnUong hoặc chưa nâng cấp (thiếu GianHang.Email). Chạy FoodService_NangCap.sql rồi chạy lại file này.';
ELSE
BEGIN
    DECLARE @sqlMon NVARCHAR(MAX) = N'USE [QuanLyDichVuAnUong];
    DECLARE @ghBunCha INT = (SELECT MaGianHang FROM GianHang WHERE Email = ''bunchahuonglien@foodapp.vn'');
    IF @ghBunCha IS NOT NULL
    BEGIN
        UPDATE GianHang SET HinhAnh = N''/uploads/bun_cha.jpg'' WHERE MaGianHang = @ghBunCha;
        DECLARE @dmBunCha INT = (SELECT TOP 1 MaDanhMuc FROM DanhMuc WHERE MaGianHang = @ghBunCha AND TenDanhMuc = N''Món chính'');
        IF @dmBunCha IS NULL
        BEGIN
            INSERT INTO DanhMuc (MaGianHang, TenDanhMuc) VALUES (@ghBunCha, N''Món chính'');
            SET @dmBunCha = SCOPE_IDENTITY();
        END
        IF NOT EXISTS (SELECT 1 FROM MonAn WHERE MaDanhMuc = @dmBunCha AND TenMon = N''Bún chả nem rán'')
            INSERT INTO MonAn (MaDanhMuc, TenMon, Gia, MoTa, HinhAnh)
            VALUES (@dmBunCha, N''Bún chả nem rán'', 52000, N''Chả viên nướng than hoa, nem rán giòn, bún tươi, nước chấm chua ngọt'', N''/uploads/bun_cha.jpg'');
        IF NOT EXISTS (SELECT 1 FROM MonAn WHERE MaDanhMuc = @dmBunCha AND TenMon = N''Bún chả đặc biệt'')
            INSERT INTO MonAn (MaDanhMuc, TenMon, Gia, MoTa, HinhAnh)
            VALUES (@dmBunCha, N''Bún chả đặc biệt'', 65000, N''Chả viên + chả miếng, nem rán, rau sống đầy đủ'', N''/uploads/bun_cha.jpg'');
    END';
    EXEC sp_executesql @sqlMon;
    PRINT N'Đã kiểm tra / thêm ảnh + món mẫu cho Bún Chả Hương Liên.';
END
GO
