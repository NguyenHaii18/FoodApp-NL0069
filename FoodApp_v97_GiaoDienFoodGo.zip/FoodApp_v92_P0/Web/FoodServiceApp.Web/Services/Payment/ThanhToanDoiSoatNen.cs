using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;

namespace FoodServiceApp.Web.Services.Payment
{
    /// <summary>
    /// v51 — tiến trình nền: cứ vài phút hỏi lại cổng VNPay các giao dịch còn "ChoThanhToan" (đã tạo link, quá 3 phút, trong 24 giờ)
    /// để bắt các trường hợp khách đã bị trừ tiền nhưng IPN/return không về (mất mạng, tắt app, IPN không tới được máy chủ local).
    /// Chưa cấu hình VNPay thật thì tự bỏ qua. Mỗi lượt tối đa 10 đơn.
    /// </summary>
    public class ThanhToanDoiSoatNen : BackgroundService
    {
        private readonly IServiceScopeFactory _scopes;
        private readonly ILogger<ThanhToanDoiSoatNen> _log;
        public ThanhToanDoiSoatNen(IServiceScopeFactory scopes, ILogger<ThanhToanDoiSoatNen> log) { _scopes = scopes; _log = log; }

        protected override async Task ExecuteAsync(CancellationToken stop)
        {
            try { await Task.Delay(TimeSpan.FromMinutes(2), stop); } catch (OperationCanceledException) { return; }
            while (!stop.IsCancellationRequested)
            {
                try
                {
                    using var scope = _scopes.CreateScope();
                    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                    var svc = scope.ServiceProvider.GetRequiredService<IVnPayService>();
                    var tu = DateTime.Now.AddHours(-24); var den = DateTime.Now.AddMinutes(-3);
                    var ma = await db.ThanhToans.AsNoTracking()
                        .Where(t => t.HinhThuc == "VNPay" && t.TrangThai == "ChoThanhToan" && t.NgayTaoLinkCong != null
                                    && db.DonHangs.Any(d => d.MaDonHang == t.MaDonHang && d.NgayDat >= tu && d.NgayDat <= den))
                        .OrderBy(t => t.MaThanhToan).Select(t => t.MaDonHang).Take(10).ToListAsync(stop);
                    foreach (var m in ma)
                    {
                        var kq = await VnPayXuLy.DoiSoatLaiAsync(db, svc, m, "127.0.0.1");
                        if (kq.TrangThai == "DaThanhToan") _log.LogInformation("Đối soát nền: đơn #{Ma} đã được cổng xác nhận thanh toán.", m);
                    }
                }
                catch (OperationCanceledException) { return; }
                catch (Exception ex) { _log.LogWarning(ex, "Đối soát thanh toán nền gặp lỗi (sẽ thử lại)."); }
                try { await Task.Delay(TimeSpan.FromMinutes(5), stop); } catch (OperationCanceledException) { return; }
            }
        }
    }
}
