using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;

namespace FoodServiceApp.Web.Services.Payment
{
    /// <summary>Kết quả xử lý callback VNPay. RspCode theo chuẩn IPN: 00 ok, 01 không thấy đơn, 02 đã xử lý, 04 sai số tiền, 97 sai chữ ký.</summary>
    public record VnPayGhiKetQua(string RspCode, string Message, bool ThanhCong);

    /// <summary>Một nơi duy nhất ghi kết quả VNPay vào CSDL (dùng cho return Web, return API và IPN) — kiểm tra chữ ký, số tiền, trạng thái, idempotent.</summary>
    public record DoiSoatLaiKetQua(bool Ok, string ThongDiep, string? TrangThai = null);

    public static class VnPayXuLy
    {
        /// <summary>v51: tạo link thanh toán và LƯU ngày tạo link (vnp_CreateDate) để sau này hỏi lại cổng nếu mất phản hồi.</summary>
        public static async Task<string> TaoLinkAsync(AppDbContext db, IVnPayService svc, VnPayCreateRequest req)
        {
            var ngay = DateTime.Now;
            var url = svc.CreatePaymentUrl(req with { CreateDate = ngay });
            var chuoi = ngay.ToString("yyyyMMddHHmmss");
            await db.ThanhToans.Where(t => t.MaDonHang == req.OrderId).ExecuteUpdateAsync(s => s.SetProperty(t => t.NgayTaoLinkCong, chuoi));
            return url;
        }

        /// <summary>
        /// v51 — Thanh toán thành công nhưng app/IPN chưa báo về: hỏi lại cổng (querydr). Nếu cổng xác nhận đã thu đúng số tiền thì ghi nhận
        /// qua đúng đường GhiKetQuaAsync (kiểm tra số tiền, idempotent, đơn đã hủy → tự tạo yêu cầu hoàn tiền). An toàn khi gọi lặp.
        /// </summary>
        public static async Task<DoiSoatLaiKetQua> DoiSoatLaiAsync(AppDbContext db, IVnPayService svc, int maDon, string ip)
        {
            var tt = await db.ThanhToans.AsNoTracking().FirstOrDefaultAsync(t => t.MaDonHang == maDon);
            if (tt == null || tt.HinhThuc != "VNPay") return new(false, "Đơn này không thanh toán qua VNPay.");
            if (tt.TrangThai == "DaThanhToan") return new(true, "Hệ thống đã ghi nhận thanh toán cho đơn này.", tt.TrangThai);
            if (tt.TrangThai != "ChoThanhToan" && tt.TrangThai != "ThatBai") return new(false, "Giao dịch đã được xử lý (" + tt.TrangThai + ").", tt.TrangThai);
            if (string.IsNullOrEmpty(tt.NgayTaoLinkCong)) return new(false, "Chưa có thông tin lần tạo link thanh toán để hỏi cổng. Nếu bạn đã bị trừ tiền, hãy liên hệ hỗ trợ kèm mã đơn.", tt.TrangThai);
            var q = await svc.QueryAsync(maDon, tt.NgayTaoLinkCong, ip);
            if (!q.Ok) return new(false, q.ThongDiep, tt.TrangThai);
            if (!q.DaThanhToan) return new(true, "Cổng chưa ghi nhận thanh toán thành công cho đơn này. Nếu bạn đã bị trừ tiền, vui lòng đợi vài phút rồi kiểm tra lại.", tt.TrangThai);
            var kq = await GhiKetQuaAsync(db, new VnPayCallbackResult(true, true, maDon, q.MaGiaoDich ?? "", q.SoTien, q.PayDate ?? ""));
            return kq.ThanhCong
                ? new(true, "Cổng đã xác nhận thanh toán — hệ thống đã cập nhật đơn của bạn.", "DaThanhToan")
                : new(false, "Cổng báo đã thanh toán nhưng chưa cập nhật được đơn: " + kq.Message + ". Quản trị sẽ kiểm tra.", tt.TrangThai);
        }

        public static async Task<VnPayGhiKetQua> GhiKetQuaAsync(AppDbContext db, VnPayCallbackResult r)
        {
            if (!r.IsValidSignature) return new("97", "Invalid signature", false);

            var tt = await db.ThanhToans.FirstOrDefaultAsync(t => t.MaDonHang == r.OrderId);
            var don = await db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == r.OrderId);
            if (tt == null || don == null || tt.HinhThuc != "VNPay") return new("01", "Order not found", false);

            // Số tiền VNPay ghi nhận phải đúng bằng tổng đơn (chống sửa số tiền ở phía client)
            if (r.Amount != (long)don.TongTien) return new("04", "Invalid amount", false);

            if (tt.TrangThai == "DaThanhToan") return new("02", "Order already confirmed", true);
            // Giao dịch đã hoàn tiền/đối soát thì không cho callback muộn ghi đè
            if (tt.TrangThai != "ChoThanhToan" && tt.TrangThai != "ThatBai") return new("02", "Order already processed", false);

            if (r.IsSuccess)
            {
                tt.TrangThai = "DaThanhToan";
                tt.MaGiaoDich = r.TransactionId;
                tt.NgayThanhToan = DateTime.Now;
                tt.NgayGiaoDichCong = string.IsNullOrEmpty(r.PayDate) ? null : r.PayDate;
                // Đơn đã bị hủy trong lúc khách đang thanh toán -> tạo yêu cầu hoàn tiền (không tự xác nhận đơn: quán vẫn phải xác nhận)
                if (don.TrangThai == "DaHuy")
                    await HoanTienXuLy.TaoYeuCauKhiHuyAsync(db, don, "TuDong", "Thanh toán thành công sau khi đơn đã bị hủy");
            }
            else tt.TrangThai = "ThatBai";

            await db.SaveChangesAsync();
            return new("00", "Confirm Success", r.IsSuccess);
        }
    }
}
