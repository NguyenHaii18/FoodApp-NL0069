using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Services
{
    public sealed record UngVienTaiXe(int MaTaiXe, string HoTen, string? PhuongTien, string TrangThai, int SoDon, double? KmDenQuan, bool KmUocTinh,
        double Sao, double TyLeThanhCong, double Diem, string LyDo);

    /// <summary>
    /// v55 — Tự động chọn tài xế phù hợp cho đơn (luật chấm điểm có trọng số, giải thích được):
    ///   45% gần quán (vị trí GPS mới nhất ≤ 20 phút; không có GPS thì ước tính theo khu vực hoạt động) ·
    ///   25% ít đơn đang giữ · 15% điểm đánh giá giao hàng (làm mượt) · 15% tỷ lệ giao thành công 30 ngày (làm mượt).
    /// Chỉ xét shipper của nền tảng đã duyệt, tài khoản đang mở, đang rảnh (SanSang) hoặc đang giữ ít đơn CÙNG QUÁN (ghép đơn, tối đa
    /// <see cref="ToiDaDon"/> đơn); bỏ tài xế đã từ chối đơn này. Đơn quán tự giao (NguonGiao = Quan) không tự động chọn.
    /// </summary>
    public static class TuDongChonTaiXeXuLy
    {
        public const int ToiDaDon = 2;
        public const string KhoaBat = "Don.TuDongPhanCong";
        public const string KhoaSauGiay = "Don.TuDongSauGiay";

        public static double Haversine(double la1, double lo1, double la2, double lo2)
        {
            const double R = 6371;
            double dLa = (la2 - la1) * Math.PI / 180, dLo = (lo2 - lo1) * Math.PI / 180;
            var a = Math.Sin(dLa / 2) * Math.Sin(dLa / 2) + Math.Cos(la1 * Math.PI / 180) * Math.Cos(la2 * Math.PI / 180) * Math.Sin(dLo / 2) * Math.Sin(dLo / 2);
            return 2 * R * Math.Asin(Math.Sqrt(a));
        }

        public static async Task<List<UngVienTaiXe>> XepHangAsync(AppDbContext db, DonHang don)
        {
            if (don.NguonGiao == "Quan") return new();
            var shop = await db.GianHangs.AsNoTracking().Where(g => g.MaGianHang == don.MaGianHang).Select(g => new { g.ViDo, g.KinhDo, g.DiaChi }).FirstOrDefaultAsync();
            var tuChoi = await db.TaiXeTuChoiDons.AsNoTracking().Where(r => r.MaDonHang == don.MaDonHang).Select(r => r.MaTaiXe).ToListAsync();
            var tx = await db.TaiXes.AsNoTracking()
                .Where(t => t.MaGianHang == null && t.TrangThaiDuyet == "DaDuyet" && (t.TrangThai == "SanSang" || t.TrangThai == "DangGiao")
                    && db.TaiKhoans.Any(k => k.MaTK == t.MaTK && k.TrangThai) && !tuChoi.Contains(t.MaTaiXe))
                .ToListAsync();
            if (tx.Count == 0) return new();
            var ids = tx.Select(t => t.MaTaiXe).ToList();

            var dang = await db.DonHangs.AsNoTracking().Where(d => d.MaTaiXe != null && ids.Contains(d.MaTaiXe!.Value) && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao"))
                .Select(d => new { MaTx = d.MaTaiXe!.Value, d.MaGianHang }).ToListAsync();
            var viTri = await db.TaiXeViTris.AsNoTracking().Where(v => ids.Contains(v.MaTaiXe) && v.CapNhatLuc >= DateTime.Now.AddMinutes(-20))
                .OrderByDescending(v => v.CapNhatLuc).ToListAsync();
            var tu30 = DateTime.Now.AddDays(-30);
            var gh = await db.GiaoHangs.AsNoTracking().Where(g => ids.Contains(g.MaTaiXe) && g.ThoiGianNhan >= tu30 && (g.TrangThai == "GiaoThanhCong" || g.TrangThai == "GiaoThatBai"))
                .GroupBy(g => g.MaTaiXe).Select(g => new { g.Key, Ok = g.Count(x => x.TrangThai == "GiaoThanhCong"), Tong = g.Count() }).ToDictionaryAsync(x => x.Key);
            var sao = await db.DanhGias.AsNoTracking().Where(x => x.MaTaiXe != null && ids.Contains(x.MaTaiXe!.Value) && x.SoSaoGiaoHang != null)
                .GroupBy(x => x.MaTaiXe!.Value).Select(g => new { g.Key, Tb = g.Average(x => (double)x.SoSaoGiaoHang!.Value), So = g.Count() }).ToDictionaryAsync(x => x.Key);

            var kq = new List<UngVienTaiXe>();
            foreach (var t in tx)
            {
                var cacDon = dang.Where(d => d.MaTx == t.MaTaiXe).ToList();
                if (t.TrangThai == "DangGiao" && (cacDon.Count == 0 || cacDon.Count >= ToiDaDon || cacDon.Any(d => d.MaGianHang != don.MaGianHang))) continue;   // đang bận chuyến khác
                if (cacDon.Count >= ToiDaDon) continue;

                double? km = null; var uocTinh = false;
                var vt = viTri.FirstOrDefault(v => v.MaTaiXe == t.MaTaiXe);
                if (vt != null && shop?.ViDo != null && shop.KinhDo != null) km = Haversine(vt.ViDo, vt.KinhDo, shop.ViDo.Value, shop.KinhDo.Value);
                else
                {
                    uocTinh = true;
                    km = KhuVucHelper.DoKhop(t.KhuVucHoatDong, shop?.DiaChi, don.DiaChiGiaoHang) != 0 ? 3.0 : 6.0;
                }
                var diemKm = 1 / (1 + km.Value / 2);
                var diemTai = 1 - cacDon.Count / 3.0;
                var tb = sao.TryGetValue(t.MaTaiXe, out var s) ? (s.Tb * s.So + 4.5 * 3) / (s.So + 3) : 4.5;
                var tl = gh.TryGetValue(t.MaTaiXe, out var g) ? (g.Ok + 0.9 * 5) / (g.Tong + 5) : 0.9;
                var diem = 0.45 * diemKm + 0.25 * diemTai + 0.15 * (tb / 5) + 0.15 * tl;
                var ly = new List<string> { uocTinh ? $"~{km:0.#} km (ước tính theo khu vực)" : $"cách quán {km:0.#} km" };
                ly.Add(cacDon.Count == 0 ? "đang rảnh" : $"đang giữ {cacDon.Count} đơn cùng quán (ghép đơn)");
                ly.Add($"⭐ {tb:0.0}");
                ly.Add($"giao thành công {tl * 100:0}%");
                kq.Add(new UngVienTaiXe(t.MaTaiXe, t.HoTen, t.PhuongTien, t.TrangThai, cacDon.Count, Math.Round(km.Value, 1), uocTinh, Math.Round(tb, 1), Math.Round(tl, 3), Math.Round(diem, 3), string.Join(" · ", ly)));
            }
            return kq.OrderByDescending(x => x.Diem).ToList();
        }

        /// <summary>Gán đơn cho tài xế. Dùng UPDATE có điều kiện nên an toàn khi tài xế/quản trị khác vừa nhận đơn.</summary>
        public static async Task<(bool Ok, string ThongDiep)> GanAsync(AppDbContext db, DonHang don, UngVienTaiXe uv, string lyDo, int? maTKQuanTri)
        {
            var tx = await db.TaiXes.FirstOrDefaultAsync(t => t.MaTaiXe == uv.MaTaiXe);
            if (tx == null) return (false, "Không tìm thấy tài xế.");
            var chiem = await db.DonHangs.Where(d => d.MaDonHang == don.MaDonHang && d.MaTaiXe == null && d.TrangThai == "DaXacNhan")
                .ExecuteUpdateAsync(s => s.SetProperty(d => d.MaTaiXe, (int?)tx.MaTaiXe));
            if (chiem == 0) return (false, "Đơn vừa được nhận hoặc không còn ở trạng thái chờ tài xế.");
            var gh = await db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == don.MaDonHang);
            if (gh == null) db.GiaoHangs.Add(new GiaoHang { MaDonHang = don.MaDonHang, MaTaiXe = tx.MaTaiXe, TrangThai = "DaNhan", ThoiGianNhan = DateTime.Now, TrangThaiThuNhap = "ChoThanhToan" });
            else { gh.MaTaiXe = tx.MaTaiXe; gh.TrangThai = "DaNhan"; gh.ThoiGianNhan = DateTime.Now; gh.TrangThaiThuNhap = "ChoThanhToan"; }
            tx.TrangThai = "DangGiao";
            db.DieuPhoiLogs.Add(new DieuPhoiLog { MaDonHang = don.MaDonHang, HanhDong = "TuDongPhanCong", MaTaiXeMoi = tx.MaTaiXe, LyDo = lyDo, MaTK = maTKQuanTri });
            db.ThongBaos.Add(new ThongBao { MaTK = tx.MaTK, Loai = "DonHang", TieuDe = "Bạn được hệ thống phân công đơn mới", NoiDung = $"Đơn #{don.MaDonHang} được tự động phân công cho bạn ({uv.LyDo}).", MaThamChieu = don.MaDonHang.ToString() });
            await db.SaveChangesAsync();
            return (true, $"Đã tự động giao đơn #{don.MaDonHang} cho {tx.HoTen}.");
        }

        /// <summary>Tự chọn người tốt nhất (điểm ≥ ngưỡng) và gán. Trả (false, lý do) nếu không có ứng viên.</summary>
        public static async Task<(bool Ok, string ThongDiep)> TuDongAsync(AppDbContext db, int maDon, int? maTKQuanTri)
        {
            var don = await db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == maDon);
            if (don == null) return (false, "Không tìm thấy đơn.");
            if (don.TrangThai != "DaXacNhan" || don.MaTaiXe != null) return (false, "Đơn không còn ở trạng thái chờ tài xế.");
            if (don.NguonGiao == "Quan") return (false, "Đơn do quán tự giao, không phân công shipper nền tảng.");
            var ds = await XepHangAsync(db, don);
            if (ds.Count == 0) return (false, "Chưa có tài xế phù hợp (đang bận, offline hoặc đã từ chối đơn).");
            return await GanAsync(db, don, ds[0], $"Tự động chọn: {ds[0].LyDo}", maTKQuanTri);
        }
    }
}
