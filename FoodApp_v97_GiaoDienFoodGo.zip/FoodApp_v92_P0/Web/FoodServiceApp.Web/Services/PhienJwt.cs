using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Services
{
    /// <summary>
    /// Quản lý phiên JWT phía máy chủ: mỗi request kiểm tra tài khoản còn tồn tại, còn hoạt động (chưa bị khóa) và token chưa bị thu hồi.
    /// Thu hồi = đặt <see cref="TaiKhoan.PhienHopLeTu"/>; mọi token cấp trước mốc đó (claim nbf) bị từ chối.
    /// Trạng thái tài khoản được cache 20 giây để không truy vấn CSDL ở mọi request.
    /// </summary>
    public static class PhienJwt
    {
        private sealed record ThongTin(bool HoatDong, DateTime? HopLeTu);

        public static void ThuHoi(TaiKhoan tk) => tk.PhienHopLeTu = DateTime.UtcNow;

        public static async Task KiemTraAsync(TokenValidatedContext ctx)
        {
            if (!int.TryParse(ctx.Principal?.FindFirstValue(ClaimTypes.NameIdentifier), out var maTk))
            { ctx.Fail("Token không hợp lệ."); return; }

            var sp = ctx.HttpContext.RequestServices;
            var cache = sp.GetRequiredService<IMemoryCache>();
            var tt = await cache.GetOrCreateAsync($"phien:{maTk}", async e =>
            {
                e.AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(20);
                var db = sp.GetRequiredService<AppDbContext>();
                var r = await db.TaiKhoans.AsNoTracking().Where(t => t.MaTK == maTk)
                    .Select(t => new { t.TrangThai, t.PhienHopLeTu }).FirstOrDefaultAsync();
                return r == null ? null : new ThongTin(r.TrangThai, r.PhienHopLeTu);
            });

            if (tt == null || !tt.HoatDong) { ctx.Fail("Tài khoản không còn hiệu lực."); return; }
            if (tt.HopLeTu is DateTime tu && ctx.SecurityToken is JwtSecurityToken jwt && jwt.ValidFrom.AddSeconds(1) < tu)
                ctx.Fail("Phiên đăng nhập đã bị thu hồi. Vui lòng đăng nhập lại.");
            if (ctx.Result != null || ctx.Principal == null) return;

            // Phiên theo thiết bị (v69): token có claim MaPhien thì phiên đó phải còn hiệu lực (chưa bị thu hồi từ màn "Phiên đăng nhập").
            if (Guid.TryParse(ctx.Principal.FindFirstValue("MaPhien"), out var maPhien))
            {
                var conHan = await cache.GetOrCreateAsync($"phien-sid:{maPhien}", async e =>
                {
                    e.AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(20);
                    var db = sp.GetRequiredService<AppDbContext>();
                    var p = await db.PhienDangNhaps.AsNoTracking().Where(x => x.MaPhien == maPhien)
                        .Select(x => new { x.ThuHoiLuc }).FirstOrDefaultAsync();
                    return p == null || p.ThuHoiLuc == null;   // không thấy dòng phiên (dữ liệu cũ) → vẫn cho qua
                });
                if (!conHan) ctx.Fail("Phiên đăng nhập này đã bị đăng xuất từ thiết bị khác. Vui lòng đăng nhập lại.");
            }
        }

        public static void XoaCachePhien(IMemoryCache cache, Guid maPhien) => cache.Remove($"phien-sid:{maPhien}");

        /// <summary>Xóa cache trạng thái của tài khoản (gọi sau khi thu hồi/khóa để có hiệu lực ngay).</summary>
        public static void XoaCache(IMemoryCache cache, int maTk) => cache.Remove($"phien:{maTk}");
    }
}
