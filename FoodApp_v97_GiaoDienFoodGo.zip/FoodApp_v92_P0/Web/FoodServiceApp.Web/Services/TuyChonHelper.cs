using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Services
{
    /// <summary>Đọc và kiểm tra tùy chọn món (size / mức cay / topping) từ form — dùng chung cho Thêm vào giỏ và Sửa món trong giỏ.</summary>
    public static class TuyChonHelper
    {
        // Mỗi nhóm có tên field riêng để trình duyệt cho chọn ĐỒNG THỜI 1 size + 1 mức cay (radio cùng name thì chỉ chọn được 1 trong cả hai).
        // "tuyChon" giữ lại để tương thích form cũ.
        private static readonly string[] Keys = { "tuyChon", "tuyChonSize", "tuyChonCay", "tuyChonDuong", "tuyChonDa", "tuyChonTopping" };

        public static List<int> DocTuForm(HttpRequest req)
        {
            var ds = new List<int>();
            if (!req.HasFormContentType) return ds;
            foreach (var k in Keys)
                foreach (var v in req.Form[k])
                    if (int.TryParse(v, out var id) && !ds.Contains(id)) ds.Add(id);
            return ds;
        }

        /// <summary>Trả về các tùy chọn hợp lệ của món; loi != null nếu lựa chọn sai quy tắc (nhiều hơn 1 size/mức cay, hoặc món có size mà chưa chọn).</summary>
        public static async Task<(List<TuyChonMon> chon, string? loi)> KiemTraAsync(AppDbContext db, int maMonAn, IEnumerable<int> ids)
        {
            var idList = ids.ToList();
            var tatCa = await db.TuyChonMons.Where(t => t.MaMonAn == maMonAn).ToListAsync();
            var chon = tatCa.Where(t => idList.Contains(t.MaTuyChon)).ToList();

            if (chon.Count(t => t.Loai == "Size") > 1 || chon.Count(t => t.Loai == "MucCay") > 1
                || chon.Count(t => t.Loai == "MucDuong") > 1 || chon.Count(t => t.Loai == "MucDa") > 1)
                return (chon, "Chỉ được chọn một kích cỡ, một mức cay, một mức đường và một mức đá.");
            if (tatCa.Any(t => t.Loai == "Size") && !chon.Any(t => t.Loai == "Size"))
                return (chon, "Vui lòng chọn kích cỡ / khẩu phần.");
            return (chon, null);
        }
    }
}
