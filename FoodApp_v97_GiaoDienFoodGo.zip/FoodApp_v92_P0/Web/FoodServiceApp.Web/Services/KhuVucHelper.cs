using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace FoodServiceApp.Web.Services;

/// <summary>
/// Khu vực chạy thường xuyên của tài xế ↔ quận/huyện trong địa chỉ quán và địa chỉ giao.
/// Hiểu mọi cách viết: "Quận 1", "Q1", "Q.1", "q 1", "District 1", "Bình Thạnh", "binh thanh"…
/// (TP Thủ Đức gộp cả Q.2, Q.9 và Thủ Đức).
/// </summary>
public static class KhuVucHelper
{
    /// <summary>Danh sách khu vực tài xế được chọn (TP.HCM): khóa chuẩn → tên hiển thị.</summary>
    public static readonly (string Khoa, string Ten)[] DanhSach =
    {
        ("Q1", "Quận 1"), ("Q3", "Quận 3"), ("Q4", "Quận 4"), ("Q5", "Quận 5"), ("Q6", "Quận 6"), ("Q7", "Quận 7"),
        ("Q8", "Quận 8"), ("Q10", "Quận 10"), ("Q11", "Quận 11"), ("Q12", "Quận 12"),
        ("BINHTHANH", "Bình Thạnh"), ("GOVAP", "Gò Vấp"), ("PHUNHUAN", "Phú Nhuận"), ("TANBINH", "Tân Bình"),
        ("TANPHU", "Tân Phú"), ("BINHTAN", "Bình Tân"), ("THUDUC", "TP Thủ Đức"),
        ("HOCMON", "Hóc Môn"), ("CUCHI", "Củ Chi"), ("NHABE", "Nhà Bè"), ("BINHCHANH", "Bình Chánh"), ("CANGIO", "Cần Giờ"),
    };

    private static readonly (string Mau, string Khoa)[] TheoTen =
    {
        ("binh thanh", "BINHTHANH"), ("go vap", "GOVAP"), ("phu nhuan", "PHUNHUAN"), ("tan binh", "TANBINH"),
        ("tan phu", "TANPHU"), ("binh tan", "BINHTAN"), ("thu duc", "THUDUC"), ("hoc mon", "HOCMON"),
        ("cu chi", "CUCHI"), ("nha be", "NHABE"), ("binh chanh", "BINHCHANH"), ("can gio", "CANGIO"),
    };

    private static readonly Regex SoQuan = new(@"(?<![a-z0-9])(?:quan|district|dist|q)\s*\.?\s*0?(\d{1,2})(?![0-9])", RegexOptions.Compiled);
    private static readonly string[] NhomThuDuc = { "Q2", "Q9", "THUDUC" };

    /// <summary>Bỏ dấu, hạ chữ thường, đổi dấu câu thành khoảng trắng.</summary>
    public static string BoDau(string? s)
    {
        if (string.IsNullOrWhiteSpace(s)) return "";
        var d = s.Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder(d.Length);
        foreach (var c in d)
        {
            var cat = CharUnicodeInfo.GetUnicodeCategory(c);
            if (cat == UnicodeCategory.NonSpacingMark) continue;
            sb.Append(c == 'đ' || c == 'Đ' ? 'd' : char.ToLowerInvariant(c));
        }
        return Regex.Replace(sb.ToString(), @"[,;/|]+", " , ").Trim();
    }

    /// <summary>Các quận/huyện (khóa chuẩn) xuất hiện trong một chuỗi địa chỉ hoặc danh sách khu vực.</summary>
    public static HashSet<string> TrichQuan(string? text)
    {
        var kq = new HashSet<string>();
        var t = BoDau(text);
        if (t.Length == 0) return kq;
        foreach (Match m in SoQuan.Matches(t))
            if (int.TryParse(m.Groups[1].Value, out var n) && n is >= 1 and <= 12) kq.Add("Q" + n);
        foreach (var (mau, khoa) in TheoTen)
            if (Regex.IsMatch(t, @"(?<![a-z])" + mau + @"(?![a-z])")) kq.Add(khoa);
        if (kq.Overlaps(NhomThuDuc)) kq.UnionWith(NhomThuDuc);   // TP Thủ Đức = Q.2 + Q.9 + Thủ Đức
        return kq;
    }

    public static string Ten(string khoa)
    {
        foreach (var (k, ten) in DanhSach) if (k == khoa) return ten;
        return khoa == "Q2" ? "Quận 2" : khoa == "Q9" ? "Quận 9" : khoa;
    }

    /// <summary>Chuẩn hóa chuỗi khu vực tài xế nhập tay: "q1, Q.3; binh thanh" → "Quận 1, Quận 3, Bình Thạnh". Cụm không nhận ra được giữ nguyên. Tối đa 150 ký tự.</summary>
    public static string? ChuanHoa(string? khuVuc)
    {
        if (string.IsNullOrWhiteSpace(khuVuc)) return null;
        var ra = new List<string>();
        foreach (var tok in khuVuc.Split(new[] { ',', ';', '/', '|', '\n' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            var quan = TrichQuan(tok);
            if (quan.Count > 0)
            {
                foreach (var k in DanhSach.Select(x => x.Khoa).Concat(new[] { "Q2", "Q9" }).Where(quan.Contains))
                {
                    if (k is "Q2" or "Q9") { if (!ra.Contains("TP Thủ Đức")) ra.Add("TP Thủ Đức"); continue; }
                    var ten = Ten(k);
                    if (!ra.Contains(ten)) ra.Add(ten);
                }
            }
            else if (!ra.Contains(tok, StringComparer.OrdinalIgnoreCase)) ra.Add(tok);
        }
        var s = ""; 
        foreach (var r in ra) { var n = s.Length == 0 ? r : s + ", " + r; if (n.Length > 150) break; s = n; }
        return s.Length == 0 ? null : s;
    }

    /// <summary>
    /// Mức khớp giữa khu vực đăng ký của tài xế với địa chỉ quán / địa chỉ giao: bit 1 = khớp địa chỉ quán, bit 2 = khớp địa chỉ giao
    /// (0 = không khớp, 3 = khớp cả hai). Quận nhận ra được thì so theo khóa chuẩn; cụm khác (vd "Sân bay") so theo chuỗi con không dấu.
    /// </summary>
    public static int DoKhop(string? khuVucTaiXe, string? diaChiQuan, string? diaChiGiao)
    {
        if (string.IsNullOrWhiteSpace(khuVucTaiXe)) return 0;
        var dang = TrichQuan(khuVucTaiXe);
        var khac = khuVucTaiXe.Split(new[] { ',', ';', '/', '|' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Where(k => TrichQuan(k).Count == 0 && k.Length >= 3).Select(k => BoDau(k)).ToList();
        bool Khop(string? diaChi)
        {
            if (string.IsNullOrWhiteSpace(diaChi)) return false;
            if (dang.Overlaps(TrichQuan(diaChi))) return true;
            var d = BoDau(diaChi);
            return khac.Any(k => d.Contains(k, StringComparison.Ordinal));
        }
        return (Khop(diaChiQuan) ? 1 : 0) | (Khop(diaChiGiao) ? 2 : 0);
    }

    /// <summary>Khu vực của tài xế có khớp địa chỉ này không.</summary>
    public static bool Trung(string? khuVuc, string? diaChi) => DoKhop(khuVuc, null, diaChi) != 0;
}
