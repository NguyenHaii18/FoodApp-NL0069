using System.Globalization;

namespace FoodServiceApp.Web.Services
{
    public enum KieuCauHinh { Tien, SoNguyen, Phut, Km, TyLe, Bat, VanBan }

    /// <summary>Mô tả một mục cấu hình: nhãn, kiểu, khoảng hợp lệ, giá trị mặc định. Dùng cho trang quản trị + kiểm tra giá trị.</summary>
    public record MucCauHinh(string Khoa, string Nhan, KieuCauHinh Kieu, string MacDinh, string MoTa, decimal Min = 0, decimal Max = 100000000)
    {
        public const int VanBanToiDa = 1000;

        public string DonVi => Kieu switch { KieuCauHinh.Tien => "đ", KieuCauHinh.Phut => "phút", KieuCauHinh.Km => "km", KieuCauHinh.TyLe => "0 – 1", _ => "" };

        /// <summary>Kiểm tra + chuẩn hóa giá trị người nhập. Trả về lỗi (null nếu hợp lệ).</summary>
        public string? KiemTra(string? nhap, out string chuan)
        {
            chuan = (nhap ?? "").Trim();
            if (chuan.Length == 0) return "Giá trị không được để trống.";
            switch (Kieu)
            {
                case KieuCauHinh.VanBan:
                    if (chuan.Length > VanBanToiDa) return $"Tối đa {VanBanToiDa} ký tự.";
                    return null;
                case KieuCauHinh.Bat:
                    if (chuan != "0" && chuan != "1") return "Chỉ nhận 0 (tắt) hoặc 1 (bật).";
                    return null;
                case KieuCauHinh.Tien:
                case KieuCauHinh.SoNguyen:
                case KieuCauHinh.Phut:
                {
                    var s = chuan.Replace(".", "").Replace(",", "").Replace(" ", "");   // 15.000 / 15,000 -> 15000
                    if (!long.TryParse(s, NumberStyles.None, CultureInfo.InvariantCulture, out var n)) return "Giá trị phải là số nguyên không âm.";
                    if (n < Min || n > Max) return $"Giá trị phải trong khoảng {Min:N0} – {Max:N0}.";
                    chuan = n.ToString(CultureInfo.InvariantCulture);
                    return null;
                }
                case KieuCauHinh.Km:
                case KieuCauHinh.TyLe:
                {
                    var s = chuan.Replace(',', '.');
                    var phanTram = s.EndsWith("%");
                    if (phanTram) s = s.TrimEnd('%').Trim();
                    if (!decimal.TryParse(s, NumberStyles.Number, CultureInfo.InvariantCulture, out var v)) return "Giá trị phải là số (dùng dấu chấm cho số thập phân).";
                    if (phanTram) v /= 100m;
                    if (v < Min || v > Max) return $"Giá trị phải trong khoảng {Min.ToString(CultureInfo.InvariantCulture)} – {Max.ToString(CultureInfo.InvariantCulture)}.";
                    chuan = v.ToString("0.####", CultureInfo.InvariantCulture);
                    return null;
                }
            }
            return null;
        }
    }

    public record NhomCauHinh(string Id, string Icon, string Ten, string GhiChu, MucCauHinh[] Muc);

    /// <summary>Danh mục toàn bộ cấu hình phí & chính sách (khóa trong bảng CauHinhHeThong).</summary>
    public static class ChinhSachMeta
    {
        public static readonly NhomCauHinh[] Nhom =
        {
            new("phi-giao", "🚚", "Phí giao hàng & chia tiền tài xế / ứng dụng",
                "Phí giao = max(tối thiểu, cơ bản + phí km vượt + ngoại thành + % giờ cao điểm + % mưa), làm tròn lên, không vượt mức tối đa. Không xác định được quãng đường (Goong Maps) thì dùng phí mặc định. Tỉ lệ chia chỉ áp dụng cho đơn đặt SAU khi đổi.",
                new[]
                {
                    new MucCauHinh("Giao.PhiCoBan", "Phí cơ bản (cho số km đầu)", KieuCauHinh.Tien, "12000", "Phí cho những km đầu tiên (đ)", 0, 1000000),
                    new MucCauHinh("Giao.KmCoBan", "Số km đầu tính phí cơ bản", KieuCauHinh.Km, "2", "Quãng đường nằm trong phí cơ bản (km)", 0, 50),
                    new MucCauHinh("Giao.PhiMoiKm", "Phí mỗi km vượt", KieuCauHinh.Tien, "4000", "Mỗi km vượt quá số km cơ bản, làm tròn lên từng km (đ)", 0, 1000000),
                    new MucCauHinh("Giao.PhuPhiNgoaiThanh", "Phụ phí ngoại thành", KieuCauHinh.Tien, "10000", "Cộng thêm khi giao ra Củ Chi, Hóc Môn, Bình Chánh, Nhà Bè, Cần Giờ (đ)", 0, 1000000),
                    new MucCauHinh("Giao.CaoDiemPhanTram", "Phụ phí giờ cao điểm", KieuCauHinh.TyLe, "0.2", "Tỉ lệ 0–1 (0.2 = 20%) trên phí cơ bản + km vượt", 0, 1),
                    new MucCauHinh("Giao.CaoDiemKhungGio", "Khung giờ cao điểm", KieuCauHinh.VanBan, "10:30-13:00;17:00-20:00", "Dạng HH:mm-HH:mm, nhiều khung cách nhau dấu ;", 0, 0),
                    new MucCauHinh("Giao.MuaPhanTram", "Phụ phí khi mưa lớn", KieuCauHinh.TyLe, "0.15", "Tỉ lệ 0–1 (0.15 = 15%) trên phí cơ bản + km vượt", 0, 1),
                    new MucCauHinh("Giao.DangMua", "Đang mưa lớn (bật tay)", KieuCauHinh.Bat, "0", "1 = đang mưa lớn, áp phụ phí mưa; 0 = tắt (chưa nối API thời tiết)", 0, 1),
                    new MucCauHinh("Giao.PhiToiThieu", "Phí giao tối thiểu", KieuCauHinh.Tien, "12000", "Phí không thấp hơn mức này (đ)", 0, 1000000),
                    new MucCauHinh("Giao.PhiToiDa", "Phí giao tối đa", KieuCauHinh.Tien, "70000", "Phí không vượt mức này (đ)", 0, 10000000),
                    new MucCauHinh("Giao.PhiMacDinh", "Phí giao mặc định", KieuCauHinh.Tien, "15000", "Áp dụng khi không xác định được khoảng cách (đ)", 0, 1000000),
                    new MucCauHinh("Giao.LamTron", "Làm tròn phí lên bội số", KieuCauHinh.Tien, "1000", "Làm tròn LÊN tới bội số này (0 hoặc 1 = không làm tròn)", 0, 10000),
                    new MucCauHinh("Giao.BanKinhKm", "Bán kính phục vụ tối đa", KieuCauHinh.Km, "20", "Khách ngoài bán kính này không đặt được (km)", 0.5m, 500m),
                    new MucCauHinh("ChiaTien.TyLeTaiXe", "Tỉ lệ phí giao tài xế nhận", KieuCauHinh.TyLe, "0.8", "Tỉ lệ 0–1 (0.8 = 80%); phần còn lại ứng dụng giữ lại. Chỉ áp dụng cho đơn đặt sau khi đổi", 0, 1),
                }),
            new("hoa-hong", "💼", "Phí nền tảng / hoa hồng gian hàng",
                "Chỉ là mức mặc định cho gian hàng mới đăng ký. Mức riêng của từng gian hàng chỉnh trong hồ sơ gian hàng (TyLeChietKhau). Nhập 0.15 hoặc 15% đều được.",
                new[]
                {
                    new MucCauHinh("HoaHong.MacDinh", "Hoa hồng mặc định", KieuCauHinh.TyLe, "0.15", "Tỷ lệ 0–1 (0.15 = 15%) trên doanh thu món của gian hàng", 0, 1),
                }),
            new("huy-don", "🚫", "Quy định hủy đơn",
                "Khách chỉ tự hủy được khi đơn còn ở trạng thái Chờ xác nhận và chưa quá thời gian cho phép.",
                new[]
                {
                    new MucCauHinh("Don.TuHuyPhut", "Thời gian khách được tự hủy", KieuCauHinh.Phut, "15", "Số phút kể từ lúc đặt; 0 = không giới hạn thời gian", 0, 1440),
                    new MucCauHinh("QuyDinh.HuyDon", "Nội dung quy định hủy đơn", KieuCauHinh.VanBan, "Khách được tự hủy khi đơn còn Chờ xác nhận trong thời gian cho phép. Sau khi gian hàng đã xác nhận, vui lòng liên hệ hỗ trợ để được xem xét.", "Hiển thị cho khách trên trang Chính sách"),
                }),
            new("hoan-tien", "💸", "Chính sách hoàn tiền",
                "Yêu cầu hoàn tiền dưới ngưỡng do Quản lý duyệt; vượt ngưỡng cần Admin tổng.",
                new[]
                {
                    new MucCauHinh("HoanTien.NguongQuanLy", "Ngưỡng Quản lý được duyệt", KieuCauHinh.Tien, "200000", "Quản lý duyệt hoàn tiền tới mức này (đ)", 0, 100000000),
                    new MucCauHinh("HoanTien.ChinhSach", "Nội dung chính sách hoàn tiền", KieuCauHinh.VanBan, "Hoàn tiền khi đơn đã thanh toán online bị hủy hoặc giao thất bại do lỗi gian hàng/tài xế; xét theo từng trường hợp với khiếu nại.", "Hiển thị cho khách trên trang Chính sách"),
                }),
            new("voucher", "🎟️", "Giới hạn voucher",
                "Áp dụng cho mọi mã khuyến mãi, ngoài các giới hạn riêng của từng mã (tổng lượt, mỗi khách một lần...).",
                new[]
                {
                    new MucCauHinh("Voucher.ToiDaMoiKhach", "Số lần một khách dùng cùng một mã / 30 ngày", KieuCauHinh.SoNguyen, "5", "0 = không giới hạn", 0, 1000),
                }),
            new("phan-phoi", "🛵", "Phân phối đơn cho tài xế",
                "Hệ thống tự lọc tài xế đủ điều kiện, xếp hạng rồi đề nghị đơn cho từng người trong thời hạn ngắn; không ai nhận thì chuyển người kế tiếp.",
                new[]
                {
                    new MucCauHinh("PhanPhoi.TuDong", "Tự động đề nghị đơn cho tài xế", KieuCauHinh.Bat, "1", "1 = máy chủ tự tìm tài xế (chỉ khi đang ở chế độ Quản trị điều phối); 0 = chỉ phân công tay", 0, 1),
                    new MucCauHinh("PhanPhoi.GiayPhanHoi", "Thời hạn tài xế phản hồi một đề nghị", KieuCauHinh.SoNguyen, "30", "Giây. Quá hạn coi như không phản hồi và đề nghị cho người kế tiếp", 10, 180),
                    new MucCauHinh("PhanPhoi.BanKinhKm", "Bán kính tìm tài xế (vòng 1)", KieuCauHinh.Km, "5", "Km từ tài xế tới quán. Vòng 2 gấp đôi, vòng 3 không giới hạn", 1, 50),
                    new MucCauHinh("PhanPhoi.SoVongToiDa", "Số vòng mở rộng trước khi báo quản trị", KieuCauHinh.SoNguyen, "3", "Hết số vòng mà chưa ai nhận: báo quản trị phân công tay (hệ thống vẫn tiếp tục thử lại)", 1, 10),
                    new MucCauHinh("PhanPhoi.ToiDaDon", "Số đơn tối đa một tài xế giữ cùng lúc", KieuCauHinh.SoNguyen, "2", "Chỉ ghép thêm đơn CÙNG QUÁN và chưa lấy hàng", 1, 5),
                    new MucCauHinh("PhanPhoi.SoMonXeMayToiDa", "Số món tối đa cho xe máy", KieuCauHinh.SoNguyen, "12", "Đơn nhiều món hơn chỉ giao cho tài xế đi ô tô. Xe đạp chỉ nhận đơn ≤ 3 km và ≤ 4 món", 1, 200),
                    new MucCauHinh("PhanPhoi.ViTriCuPhut", "Coi là mất tín hiệu khi không có nhịp quá", KieuCauHinh.Phut, "3", "Phút. Tài xế mất GPS/mạng quá mức này không được đề nghị đơn mới", 1, 60),
                    new MucCauHinh("PhanPhoi.PhutDenQuan", "Thời hạn tài xế đến quán sau khi nhận", KieuCauHinh.Phut, "15", "Quá mức này mà chưa bấm \"Đã đến quán\" → thu hồi đơn và tìm người khác", 3, 120),
                    new MucCauHinh("PhanPhoi.PhutMatLienLac", "Thu hồi đơn khi tài xế mất liên lạc quá", KieuCauHinh.Phut, "8", "Phút, chỉ áp dụng khi chưa lấy hàng. Đã lấy hàng thì báo quản trị, không thu hồi", 2, 120),
                    new MucCauHinh("PhanPhoi.SoLanBoLoToiDa", "Số lần bỏ lỡ liên tiếp trước khi tạm ngừng đề nghị", KieuCauHinh.SoNguyen, "3", "Tài xế không phản hồi liên tiếp quá số lần này bị tạm ngừng nhận đề nghị tự động", 1, 20),
                    new MucCauHinh("PhanPhoi.PhutTamNgung", "Thời gian tạm ngừng đề nghị tự động", KieuCauHinh.Phut, "15", "Phút", 1, 1440),
                }),
            new("thoi-gian", "⏱️", "Thời gian xử lý đơn",
                "Các mốc dùng để dự kiến giao, cảnh báo đơn trễ/kẹt và tự điều phối lại khi chưa có tài xế nhận.",
                new[]
                {
                    new MucCauHinh("Don.DuKienPhut", "Thời gian dự kiến xử lý + giao", KieuCauHinh.Phut, "45", "Phút", 1, 600),
                    new MucCauHinh("Don.TreSauPhut", "Coi là trễ khi quá dự kiến thêm", KieuCauHinh.Phut, "30", "Phút", 0, 600),
                    new MucCauHinh("Don.KetTrangThaiPhut", "Coi là kẹt khi đứng yên một trạng thái quá", KieuCauHinh.Phut, "60", "Phút", 1, 1440),
                    new MucCauHinh("Don.QuanTriDieuPhoi", "Quản trị điều phối giao hàng", KieuCauHinh.Bat, "1", "1 = đơn quán xác nhận chuyển lên Quản trị phân công tài xế, tài xế không tự nhận; 0 = hàng chờ chung, tài xế tự nhận", 0, 1),
                    new MucCauHinh("Don.TaiXePhanHoiPhut", "Thời gian chờ tài xế nhận đơn", KieuCauHinh.Phut, "5", "Quá số phút này chưa ai nhận thì điều phối lại + báo quản trị", 1, 120),
                    new MucCauHinh("Don.BatBuocSanSangGiao", "Bắt buộc quán báo \"Sẵn sàng giao\"", KieuCauHinh.Bat, "1", "1 = tài xế chỉ bấm \"Đã lấy hàng\" sau khi quán báo sẵn sàng", 0, 1),
                    new MucCauHinh("Don.BatBuocMaDonKhiLayHang", "Bắt buộc nhập mã đơn khi lấy hàng", KieuCauHinh.Bat, "0", "1 = bắt buộc (app mobile cũ chưa gửi mã đơn nên mặc định 0)", 0, 1),
                }),
            new("quy-dinh", "📜", "Quy định áp dụng",
                "Hiển thị trên trang Chính sách của khách, gian hàng và tài xế.",
                new[]
                {
                    new MucCauHinh("QuyDinh.KhachHang", "Quy định cho khách hàng", KieuCauHinh.VanBan, "Khách hàng cung cấp thông tin đúng, không đặt đơn ảo, không lạm dụng khuyến mãi.", "Áp dụng cho khách hàng"),
                    new MucCauHinh("QuyDinh.GianHang", "Quy định cho gian hàng", KieuCauHinh.VanBan, "Gian hàng đăng thông tin món/giá đúng thực tế, không đăng nội dung vi phạm, xử lý đơn đúng thời hạn.", "Áp dụng cho gian hàng"),
                    new MucCauHinh("QuyDinh.TaiXe", "Quy định cho tài xế", KieuCauHinh.VanBan, "Tài xế giao đúng đơn, giữ thái độ phục vụ, không từ chối đơn đã nhận vô cớ.", "Áp dụng cho tài xế"),
                }),
            new("thuong-hieu", "🎨", "Thương hiệu ứng dụng",
                "Tên, khẩu hiệu, logo và màu chủ đạo. Ứng dụng đọc qua api/mobile/thong-tin-ung-dung.",
                new[]
                {
                    new MucCauHinh("App.Ten", "Tên ứng dụng", KieuCauHinh.VanBan, "FoodApp", "Hiển thị ở đầu trang và trang giới thiệu"),
                    new MucCauHinh("App.KhauHieu", "Khẩu hiệu", KieuCauHinh.VanBan, "Giao đồ ăn", "Dòng chữ nhỏ dưới tên ứng dụng"),
                    new MucCauHinh("App.LogoUrl", "Địa chỉ ảnh logo", KieuCauHinh.VanBan, "logo.png", "Đường dẫn ảnh logo (https://… hoặc tên tệp trong ứng dụng)"),
                    new MucCauHinh("App.MauChinh", "Màu thương hiệu", KieuCauHinh.VanBan, "#5B3FD9", "Mã màu dạng #RRGGBB"),
                }),
            new("doanh-nghiep", "🏢", "Thông tin doanh nghiệp",
                "Đơn vị vận hành FoodApp.",
                new[]
                {
                    new MucCauHinh("DoanhNghiep.Ten", "Tên doanh nghiệp", KieuCauHinh.VanBan, "Chưa cập nhật", "Tên pháp lý của đơn vị vận hành"),
                    new MucCauHinh("DoanhNghiep.MaSoThue", "Mã số thuế", KieuCauHinh.VanBan, "Chưa cập nhật", "10 hoặc 13 chữ số"),
                    new MucCauHinh("DoanhNghiep.DiaChi", "Địa chỉ trụ sở", KieuCauHinh.VanBan, "Chưa cập nhật", "Địa chỉ đăng ký kinh doanh"),
                }),
            new("lien-he", "☎️", "Thông tin liên hệ",
                "Hiển thị ở trang Liên hệ trong ứng dụng.",
                new[]
                {
                    new MucCauHinh("LienHe.SoDienThoai", "Hotline", KieuCauHinh.VanBan, "Chưa cập nhật", "Số điện thoại hỗ trợ"),
                    new MucCauHinh("LienHe.Email", "Email hỗ trợ", KieuCauHinh.VanBan, "Chưa cập nhật", "Địa chỉ email hỗ trợ khách hàng"),
                    new MucCauHinh("LienHe.GioHoTro", "Giờ hỗ trợ", KieuCauHinh.VanBan, "08:00 - 22:00 hằng ngày", "Khung giờ tiếp nhận hỗ trợ"),
                }),
            new("noi-dung", "📄", "Nội dung ứng dụng",
                "Chính sách và hướng dẫn hiển thị cho người dùng.",
                new[]
                {
                    new MucCauHinh("NoiDung.ChinhSachSuDung", "Chính sách sử dụng", KieuCauHinh.VanBan, "Vui lòng sử dụng ứng dụng đúng mục đích đặt và giao đồ ăn, không gian lận khuyến mãi, không đăng nội dung vi phạm pháp luật.", "Nội dung trang Chính sách sử dụng (tối đa 1000 ký tự)"),
                    new MucCauHinh("NoiDung.HuongDan", "Hướng dẫn sử dụng", KieuCauHinh.VanBan, "Chọn quán, thêm món vào giỏ, đặt hàng và theo dõi đơn trong mục Đơn hàng. Cần hỗ trợ: vào Hồ sơ → Hỗ trợ.", "Nội dung hướng dẫn người dùng mới"),
                }),
            new("nen-tang", "👑", "Gói dịch vụ & giới hạn sử dụng (Super Admin)",
                "Gói đang dùng, phí phần mềm và hạn mức người dùng / đơn / dung lượng. Dùng chung cho mọi thiết bị quản trị.",
                new[]
                {
                    new MucCauHinh("NenTang.Goi", "Tên gói dịch vụ", KieuCauHinh.VanBan, "Chưa đặt", "Tên gói đang sử dụng"),
                    new MucCauHinh("NenTang.PhiThang", "Phí sử dụng phần mềm mỗi tháng", KieuCauHinh.Tien, "0", "Số tiền mỗi tháng (đ)", 0, 1000000000),
                    new MucCauHinh("NenTang.NgayThanhToan", "Ngày thanh toán hằng tháng", KieuCauHinh.SoNguyen, "0", "1–28; 0 = chưa đặt", 0, 28),
                    new MucCauHinh("GioiHan.NguoiDung", "Giới hạn số người dùng", KieuCauHinh.SoNguyen, "1000", "Khách + tài xế + gian hàng + quản trị", 1, 100000000),
                    new MucCauHinh("GioiHan.DonThang", "Giới hạn số đơn mỗi tháng", KieuCauHinh.SoNguyen, "5000", "Tính theo tháng dương lịch", 1, 100000000),
                    new MucCauHinh("GioiHan.DungLuongMB", "Giới hạn dung lượng (MB)", KieuCauHinh.SoNguyen, "5120", "Dung lượng ảnh và tài liệu", 1, 100000000),
                }),
            new("thanh-toan", "🏦", "Thanh toán chuyển khoản",
                "Thông tin tài khoản hiển thị cho khách khi chọn chuyển khoản.",
                new[]
                {
                    new MucCauHinh("ThanhToan.ThongTinChuyenKhoan", "Thông tin chuyển khoản", KieuCauHinh.VanBan, "Ngân hàng ... - STK ... - Chủ TK ...", "Sửa lại cho đúng tài khoản nhận tiền"),
                }),
        };

        public static IEnumerable<MucCauHinh> TatCa => Nhom.SelectMany(n => n.Muc);
        public static MucCauHinh? Tim(string khoa) => TatCa.FirstOrDefault(m => m.Khoa == khoa);
    }
}
