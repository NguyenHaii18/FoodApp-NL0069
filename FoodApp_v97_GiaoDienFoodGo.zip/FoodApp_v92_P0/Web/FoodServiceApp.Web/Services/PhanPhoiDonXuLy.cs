using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Realtime;

namespace FoodServiceApp.Web.Services
{
    /// <summary>Tham số vận hành của bộ máy phân phối (đọc từ CauHinhHeThong, nhóm "Phân phối đơn cho tài xế").</summary>
    public sealed record CauHinhPhanPhoi(bool TuDong, int GiayPhanHoi, double BanKinhKm, int SoVongToiDa, int ToiDaDon, int SoMonXeMay,
        int ViTriCuPhut, int PhutDenQuan, int PhutMatLienLac, int SoLanBoLo, int PhutTamNgung);

    /// <summary>Kết quả phân tích MỘT tài xế đối với MỘT đơn: có nhận được không và vì sao (dùng cho xếp hạng và cho màn hình điều phối).</summary>
    public sealed record PhanTichTaiXe(int MaTaiXe, int MaTK, string HoTen, string? PhuongTien, string TrangThai, double? Km, bool KmUocTinh,
        int SoDonDangGiu, int PhutDenQuan, bool CoThe, string LyDo, double Diem);

    /// <summary>Thông tin đơn cần cho việc chọn tài xế.</summary>
    public sealed record DonPhanPhoi(int MaDonHang, int MaGianHang, string DiaChiGiaoHang, double? KhoangCachKm, int SoMon);

    /// <summary>
    /// v86 — HỆ THỐNG PHÂN PHỐI ĐƠN CHO TÀI XẾ.
    ///
    /// 1) LỌC: tài xế phải online + bật nhận đơn, còn kết nối (nhịp ≤ N phút) và có GPS, tài khoản mở/đã duyệt, chưa bị tạm ngừng,
    ///    chưa vượt giới hạn đơn (chỉ ghép đơn cùng quán và chưa lấy hàng), phương tiện phù hợp, trong khu vực được phép, trong bán kính của vòng,
    ///    chưa từ chối đơn này và chưa có đề nghị khác đang chờ.
    /// 2) XẾP HẠNG: 45% gần quán · 25% ít đơn đang giữ · 15% điểm đánh giá · 15% tỷ lệ giao thành công 30 ngày.
    /// 3) ĐỀ NGHỊ có thời hạn cho MỘT người tốt nhất (DeNghiGiaoDon). Nhận → gán nguyên tử; từ chối/hết hạn → người kế tiếp;
    ///    hết ứng viên → mở rộng bán kính (vòng 2, 3); vẫn không có → báo quản trị và thử lại theo chu kỳ.
    /// 4) NGUYÊN TỬ: mọi lần gán đều là UPDATE có điều kiện (MaTaiXe IS NULL / đúng tài xế cũ) + chỉ mục duy nhất có điều kiện cho đề nghị đang chờ,
    ///    nên một đơn không thể cùng thuộc hai tài xế, và nhiều tài xế bấm cùng lúc chỉ một người thắng.
    /// 5) GIÁM SÁT: đề nghị hết hạn · tài xế không đến quán · mất kết nối trước khi lấy hàng · tài xế hủy sau khi nhận · khách/quán hủy đơn.
    /// </summary>
    public static class PhanPhoiDonXuLy
    {
        public const string KhoaTuDong = "PhanPhoi.TuDong";
        private static readonly SemaphoreSlim _khoa = new(1, 1);
        private static readonly SemaphoreSlim _danhThuc = new(0, int.MaxValue);

        public static DateTime? LanChayCuoi { get; private set; }
        public static string KetQuaCuoi { get; private set; } = "Chưa chạy lần nào.";
        public static int TongDeNghi { get; private set; }

        /// <summary>Đánh thức vòng lặp nền ngay (sau khi tài xế từ chối/hủy, đơn mới…) thay vì chờ tới nhịp kế.</summary>
        public static void DanhThucNgay() { if (_danhThuc.CurrentCount == 0) { try { _danhThuc.Release(); } catch { } } }
        public static Task<bool> ChoNhipAsync(TimeSpan toiDa, CancellationToken ct) => _danhThuc.WaitAsync(toiDa, ct);

        // ------------------------------------------------------------------------------------------------ cấu hình
        public static async Task<CauHinhPhanPhoi> DocCauHinhAsync(AppDbContext db)
        {
            Dictionary<string, string> kv;
            try
            {
                kv = await db.CauHinhHeThongs.AsNoTracking().Where(c => c.Khoa.StartsWith("PhanPhoi.")).ToDictionaryAsync(c => c.Khoa, c => c.GiaTri);
            }
            catch { kv = new(); }
            double D(string k, double mac, double min, double max) => kv.TryGetValue(k, out var s) && double.TryParse(s, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out var v) && v >= min && v <= max ? v : mac;
            return new CauHinhPhanPhoi(
                TuDong: !kv.TryGetValue(KhoaTuDong, out var td) || td != "0",
                GiayPhanHoi: (int)D("PhanPhoi.GiayPhanHoi", 30, 10, 180),
                BanKinhKm: D("PhanPhoi.BanKinhKm", 5, 1, 50),
                SoVongToiDa: (int)D("PhanPhoi.SoVongToiDa", 3, 1, 10),
                ToiDaDon: (int)D("PhanPhoi.ToiDaDon", 2, 1, 5),
                SoMonXeMay: (int)D("PhanPhoi.SoMonXeMayToiDa", 12, 1, 200),
                ViTriCuPhut: (int)D("PhanPhoi.ViTriCuPhut", 3, 1, 60),
                PhutDenQuan: (int)D("PhanPhoi.PhutDenQuan", 15, 3, 120),
                PhutMatLienLac: (int)D("PhanPhoi.PhutMatLienLac", 8, 2, 120),
                SoLanBoLo: (int)D("PhanPhoi.SoLanBoLoToiDa", 3, 1, 20),
                PhutTamNgung: (int)D("PhanPhoi.PhutTamNgung", 15, 1, 1440));
        }

        public static async Task<bool> DangBatAsync(AppDbContext db) => (await DocCauHinhAsync(db)).TuDong;

        // ------------------------------------------------------------------------------------------------ phân tích / xếp hạng
        private sealed class TaiNguyen
        {
            public List<TaiXe> TaiXes = new();
            public HashSet<int> BiKhoa = new();
            public Dictionary<int, List<(int MaGianHang, string TrangThai)>> DangGiu = new();
            public HashSet<int> CoDeNghiCho = new();
            public Dictionary<int, (double Tb, int So)> Sao = new();
            public Dictionary<int, (int Ok, int Tong)> TyLe = new();
        }

        private static async Task<TaiNguyen> TaiTaiNguyenAsync(AppDbContext db)
        {
            var tn = new TaiNguyen();
            tn.TaiXes = await db.TaiXes.AsNoTracking().Where(t => t.MaGianHang == null && t.TrangThaiDuyet == "DaDuyet").ToListAsync();
            var ids = tn.TaiXes.Select(t => t.MaTaiXe).ToList();
            var maTk = tn.TaiXes.Select(t => t.MaTK).ToList();
            tn.BiKhoa = (await db.TaiKhoans.AsNoTracking().Where(k => maTk.Contains(k.MaTK) && !k.TrangThai).Select(k => k.MaTK).ToListAsync()).ToHashSet();
            var dang = await db.DonHangs.AsNoTracking()
                .Where(d => d.MaTaiXe != null && ids.Contains(d.MaTaiXe!.Value) && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao"))
                .Select(d => new { MaTx = d.MaTaiXe!.Value, d.MaGianHang, d.TrangThai }).ToListAsync();
            foreach (var g in dang.GroupBy(x => x.MaTx)) tn.DangGiu[g.Key] = g.Select(x => (x.MaGianHang, x.TrangThai)).ToList();
            tn.CoDeNghiCho = (await db.DeNghiGiaoDons.AsNoTracking().Where(o => o.TrangThai == "ChoPhanHoi").Select(o => o.MaTaiXe).ToListAsync()).ToHashSet();
            var tu30 = DateTime.Now.AddDays(-30);
            var gh = await db.GiaoHangs.AsNoTracking().Where(g => ids.Contains(g.MaTaiXe) && g.ThoiGianNhan >= tu30 && (g.TrangThai == "GiaoThanhCong" || g.TrangThai == "GiaoThatBai"))
                .GroupBy(g => g.MaTaiXe).Select(g => new { g.Key, Ok = g.Count(x => x.TrangThai == "GiaoThanhCong"), Tong = g.Count() }).ToListAsync();
            foreach (var x in gh) tn.TyLe[x.Key] = (x.Ok, x.Tong);
            var sao = await db.DanhGias.AsNoTracking().Where(x => x.MaTaiXe != null && ids.Contains(x.MaTaiXe!.Value) && x.SoSaoGiaoHang != null)
                .GroupBy(x => x.MaTaiXe!.Value).Select(g => new { g.Key, Tb = g.Average(x => (double)x.SoSaoGiaoHang!.Value), So = g.Count() }).ToListAsync();
            foreach (var x in sao) tn.Sao[x.Key] = (x.Tb, x.So);
            return tn;
        }

        /// <summary>Phương tiện có phù hợp với đơn không (ô tô: mọi đơn · xe đạp: ≤ 3 km và ≤ 4 món · xe máy: ≤ số món cấu hình).</summary>
        public static (bool Ok, string LyDo) PhuongTienPhuHop(string? phuongTien, int soMon, double kmGiao, CauHinhPhanPhoi cfg)
        {
            var x = (phuongTien ?? "").ToLowerInvariant();
            if (x.Contains("ô tô") || x.Contains("oto") || x.Contains("xe hơi") || x.Contains("bán tải") || x.Contains("car")) return (true, "");
            if (x.Contains("đạp") || x.Contains("dap") || x.Contains("bicycle"))
                return kmGiao > 3 || soMon > 4 ? (false, "Xe đạp không phù hợp (đơn > 3 km hoặc > 4 món)") : (true, "");
            return soMon > cfg.SoMonXeMay ? (false, $"Đơn {soMon} món vượt sức chứa xe máy ({cfg.SoMonXeMay} món)") : (true, "");
        }

        /// <summary>Khu vực hoạt động của tài xế (ngăn bởi , ; / |) có xuất hiện trong địa chỉ không (không phân biệt hoa thường).</summary>
        private static bool TrungKhuVuc(string? khuVuc, string diaChi) => KhuVucHelper.Trung(khuVuc, diaChi);

        private static List<PhanTichTaiXe> PhanTich(DonPhanPhoi don, GianHang? shop, TaiNguyen tn, CauHinhPhanPhoi cfg, int vong,
            HashSet<int> loaiTruVinhVien, HashSet<int> loaiTruChuKy)
        {
            var now = DateTime.Now;
            var banKinh = vong >= cfg.SoVongToiDa ? double.MaxValue : cfg.BanKinhKm * vong;
            var kq = new List<PhanTichTaiXe>();
            foreach (var t in tn.TaiXes)
            {
                var ly = new List<string>();
                var giu = tn.DangGiu.TryGetValue(t.MaTaiXe, out var g) ? g : new List<(int MaGianHang, string TrangThai)>();

                if (tn.BiKhoa.Contains(t.MaTK)) ly.Add("Tài khoản đang bị khóa");
                if (t.TamKhoaNhanDenLuc != null && t.TamKhoaNhanDenLuc > now) ly.Add($"Tạm ngừng đề nghị tự động tới {t.TamKhoaNhanDenLuc:HH:mm} (bỏ lỡ nhiều lần)");
                switch (t.TrangThai)
                {
                    case "NgoaiTuyen": ly.Add("Đang offline"); break;
                    case "TamNghi": ly.Add("Đã tắt nhận đơn"); break;
                    case "SanSang": break;
                    case "DangGiao": if (giu.Count == 0) ly.Add("Đang ở trạng thái giao hàng nhưng chưa có đơn"); break;
                    default: ly.Add("Trạng thái " + t.TrangThai); break;
                }

                // tải đơn
                if (giu.Count >= cfg.ToiDaDon) ly.Add($"Đang giữ {giu.Count} đơn (tối đa {cfg.ToiDaDon})");
                else if (giu.Count > 0 && (giu.Any(x => x.MaGianHang != don.MaGianHang) || giu.Any(x => x.TrangThai == "DangGiao")))
                    ly.Add("Đang bận chuyến khác (chỉ ghép đơn cùng quán và chưa lấy hàng)");

                // kết nối / GPS
                var gpsCu = false;
                if (t.NhipLuc != null && (now - t.NhipLuc.Value).TotalMinutes > cfg.ViTriCuPhut)
                { ly.Add($"Mất kết nối {Math.Round((now - t.NhipLuc.Value).TotalMinutes)} phút"); gpsCu = true; }
                else if (t.NhipLuc != null && (t.ViTriLuc == null || (now - t.ViTriLuc.Value).TotalMinutes > cfg.ViTriCuPhut))
                { gpsCu = true; }   // còn kết nối nhưng chưa có/mất GPS: KHÔNG loại tài xế, chỉ ước tính khoảng cách theo khu vực.

                // khu vực chạy thường xuyên đã đăng ký: bit 1 = khớp địa chỉ quán, bit 2 = khớp địa chỉ giao ("q1" ≈ "Quận 1" ≈ "Q.1")
                var kvKhop = string.IsNullOrWhiteSpace(t.KhuVucHoatDong) ? 0 : KhuVucHelper.DoKhop(t.KhuVucHoatDong, shop?.DiaChi, don.DiaChiGiaoHang);

                // khoảng cách tới quán
                double? km; var uoc = false;
                if (!gpsCu && t.ViDo != null && t.KinhDo != null && t.ViTriLuc != null && shop?.ViDo != null && shop.KinhDo != null)
                    km = TuDongChonTaiXeXuLy.Haversine(t.ViDo.Value, t.KinhDo.Value, shop.ViDo.Value, shop.KinhDo.Value);
                else
                {
                    uoc = true;
                    km = kvKhop != 0 ? 3.0 : 6.0;   // chưa có GPS: tài xế đăng ký đúng khu vực coi như ở gần
                }
                if (km > banKinh) ly.Add($"Xa quán {km:0.#} km (bán kính vòng này {banKinh:0.#} km)");

                // phương tiện, khu vực
                var (okPt, lyPt) = PhuongTienPhuHop(t.PhuongTien, don.SoMon, don.KhoangCachKm ?? 0, cfg);
                if (!okPt) ly.Add(lyPt);
                if (!string.IsNullOrWhiteSpace(t.KhuVucHoatDong) && kvKhop == 0)
                    ly.Add("Ngoài khu vực đã đăng ký (" + t.KhuVucHoatDong + ")");

                // loại trừ theo đơn
                if (loaiTruVinhVien.Contains(t.MaTaiXe)) ly.Add("Đã từ chối hoặc hủy đơn này");
                if (loaiTruChuKy.Contains(t.MaTaiXe)) ly.Add("Đã được đề nghị đơn này nhưng không phản hồi");
                if (tn.CoDeNghiCho.Contains(t.MaTaiXe)) ly.Add("Đang có một đề nghị khác chờ phản hồi");

                var coThe = ly.Count == 0;
                double diem = 0;
                if (coThe)
                {
                    var diemKm = 1 / (1 + km!.Value / 2);
                    var diemTai = 1 - giu.Count / 3.0;
                    var tb = tn.Sao.TryGetValue(t.MaTaiXe, out var s) ? (s.Tb * s.So + 4.5 * 3) / (s.So + 3) : 4.5;
                    var tl = tn.TyLe.TryGetValue(t.MaTaiXe, out var r) ? (r.Ok + 0.9 * 5) / (r.Tong + 5) : 0.9;
                    // ưu tiên tài xế đăng ký đúng khu vực: khớp quận của khách +0.6, khớp quận của quán +0.4 (khớp cả hai +1.0)
                    var diemKv = ((kvKhop & 2) != 0 ? 0.6 : 0) + ((kvKhop & 1) != 0 ? 0.4 : 0);
                    diem = Math.Round(0.45 * diemKm + 0.25 * diemTai + 0.15 * (tb / 5) + 0.15 * tl + diemKv, 3);
                    ly.Add((uoc ? $"~{km:0.#} km (ước tính theo khu vực{(t.NhipLuc != null && gpsCu ? ", chưa có GPS — hãy bật định vị để được ưu tiên đơn gần" : "")})" : $"cách quán {km:0.#} km") + (kvKhop != 0 ? " · 📍 đúng khu vực đăng ký (" + t.KhuVucHoatDong + ")" : "") + " · " + (giu.Count == 0 ? "đang rảnh" : $"đang giữ {giu.Count} đơn cùng quán") + $" · ⭐ {tb:0.0} · giao thành công {tl * 100:0}%");
                }
                var phut = km == null ? 0 : (int)Math.Ceiling(km.Value / 22.0 * 60) + 1;
                kq.Add(new PhanTichTaiXe(t.MaTaiXe, t.MaTK, t.HoTen, t.PhuongTien, t.TrangThai, km == null ? null : Math.Round(km.Value, 1), uoc,
                    giu.Count, phut, coThe, string.Join("; ", ly), diem));
            }
            return kq.OrderByDescending(x => x.CoThe).ThenByDescending(x => x.Diem).ThenBy(x => x.Km ?? 99).ToList();
        }

        private static async Task<(DonPhanPhoi? Don, GianHang? Shop)> TaiDonAsync(AppDbContext db, int maDon)
        {
            var d = await db.DonHangs.AsNoTracking().Where(x => x.MaDonHang == maDon)
                .Select(x => new DonPhanPhoi(x.MaDonHang, x.MaGianHang, x.DiaChiGiaoHang, x.KhoangCachKm, x.ChiTiets.Sum(c => (int?)c.SoLuong) ?? 0)).FirstOrDefaultAsync();
            if (d == null) return (null, null);
            var shop = await db.GianHangs.AsNoTracking().FirstOrDefaultAsync(g => g.MaGianHang == d.MaGianHang);
            return (d, shop);
        }

        /// <summary>Bảng phân tích tài xế cho một đơn (cả người đủ điều kiện lẫn người bị loại kèm lý do) — dùng cho quản trị.</summary>
        public static async Task<List<PhanTichTaiXe>> PhanTichChoDonAsync(AppDbContext db, int maDon)
        {
            var (don, shop) = await TaiDonAsync(db, maDon);
            if (don == null) return new();
            var cfg = await DocCauHinhAsync(db);
            var tn = await TaiTaiNguyenAsync(db);
            var (vinhVien, chuKy) = await LoaiTruAsync(db, maDon);
            return PhanTich(don, shop, tn, cfg, cfg.SoVongToiDa, vinhVien, chuKy);
        }

        private static async Task<(HashSet<int> VinhVien, HashSet<int> ChuKy)> LoaiTruAsync(AppDbContext db, int maDon)
        {
            var tuChoi = await db.TaiXeTuChoiDons.AsNoTracking().Where(r => r.MaDonHang == maDon).Select(r => r.MaTaiXe).ToListAsync();
            var dn = await db.DeNghiGiaoDons.AsNoTracking().Where(o => o.MaDonHang == maDon && (o.TrangThai == "TuChoi" || o.TrangThai == "HetHan")).Select(o => new { o.MaTaiXe, o.TrangThai }).ToListAsync();
            var vinhVien = tuChoi.Concat(dn.Where(x => x.TrangThai == "TuChoi").Select(x => x.MaTaiXe)).ToHashSet();
            var chuKy = dn.Where(x => x.TrangThai == "HetHan").Select(x => x.MaTaiXe).ToHashSet();
            return (vinhVien, chuKy);
        }

        // ------------------------------------------------------------------------------------------------ vòng lặp chính
        public static async Task<string> ChayAsync(AppDbContext db)
        {
            if (!await _khoa.WaitAsync(0)) return "Đang có lượt chạy khác.";
            try
            {
                var cfg = await DocCauHinhAsync(db);
                var chiQuanTri = await GiaoHangXuLy.QuanTriDieuPhoiAsync(db);
                var nhat = new List<string>();
                async Task Buoc(string ten, Func<Task<int>> f)
                {
                    try { var n = await f(); if (n > 0) nhat.Add($"{ten}: {n}"); }
                    catch (Exception ex) { db.ChangeTracker.Clear(); nhat.Add($"{ten}: lỗi {ex.Message}"); }
                }

                await Buoc("đề nghị hết hạn", () => XuLyHetHanAsync(db, cfg));
                await Buoc("thu hồi đề nghị không còn hợp lệ", () => HuyDeNghiMoCoiAsync(db));
                await Buoc("sửa đơn thiếu chuyến giao", () => SuaDonThieuGiaoHangAsync(db));
                await Buoc("thu hồi/cảnh báo không đến quán", () => XuLyKhongDenQuanAsync(db, cfg, cfg.TuDong && chiQuanTri));
                await Buoc("thu hồi/cảnh báo mất liên lạc", () => XuLyMatLienLacAsync(db, cfg, cfg.TuDong && chiQuanTri));
                if (cfg.TuDong && chiQuanTri) await Buoc("đề nghị mới", () => PhanPhoiDonChoAsync(db, cfg));

                LanChayCuoi = DateTime.Now;
                KetQuaCuoi = !cfg.TuDong ? "Đang tắt (PhanPhoi.TuDong = 0) — chỉ phân công tay." : !chiQuanTri ? "Đang ở chế độ hàng chờ chung (tài xế tự nhận)." : nhat.Count == 0 ? "Không có việc cần xử lý." : string.Join(" · ", nhat);
                return KetQuaCuoi;
            }
            finally { _khoa.Release(); }
        }

        private static void PhatTaiXe(int maTK, string suKien, object noiDung) => RealtimeBus.Phat(new[] { RealtimeBus.NhomTK(maTK) }, suKien, noiDung);

        // ---- đề nghị hết hạn: tài xế không phản hồi
        private static async Task<int> XuLyHetHanAsync(AppDbContext db, CauHinhPhanPhoi cfg)
        {
            var now = DateTime.Now;
            var ds = await db.DeNghiGiaoDons.AsNoTracking().Where(o => o.TrangThai == "ChoPhanHoi" && o.HetHanLuc < now).ToListAsync();
            var xuLy = 0;
            foreach (var o in ds)
            {
                var n = await db.DeNghiGiaoDons.Where(x => x.MaDeNghi == o.MaDeNghi && x.TrangThai == "ChoPhanHoi")
                    .ExecuteUpdateAsync(s => s.SetProperty(x => x.TrangThai, "HetHan").SetProperty(x => x.PhanHoiLuc, (DateTime?)now).SetProperty(x => x.LyDoPhanHoi, "Không phản hồi"));
                if (n == 0) continue;   // vừa được nhận/từ chối
                var tx = await db.TaiXes.FirstOrDefaultAsync(t => t.MaTaiXe == o.MaTaiXe);
                if (tx != null)
                {
                    tx.SoLanKhongPhanHoi++;
                    if (tx.SoLanKhongPhanHoi >= cfg.SoLanBoLo)
                    {
                        tx.TamKhoaNhanDenLuc = now.AddMinutes(cfg.PhutTamNgung);
                        tx.SoLanKhongPhanHoi = 0;
                        db.ThongBaos.Add(new ThongBao { MaTK = tx.MaTK, Loai = "HeThong", TieuDe = "Tạm ngừng nhận đề nghị tự động", NoiDung = $"Bạn bỏ lỡ {cfg.SoLanBoLo} đề nghị liên tiếp nên được tạm ngừng nhận đơn tự động {cfg.PhutTamNgung} phút. Hãy giữ app mở và bật nhận đơn khi sẵn sàng." });
                    }
                    else
                        db.ThongBaos.Add(new ThongBao { MaTK = tx.MaTK, Loai = "DonHang", MaThamChieu = o.MaDonHang.ToString(), TieuDe = "Bạn đã bỏ lỡ một đề nghị đơn", NoiDung = $"Đơn #{o.MaDonHang} đã chuyển cho tài xế khác vì bạn không phản hồi trong {cfg.GiayPhanHoi} giây." });
                    PhatTaiXe(tx.MaTK, "DriverOfferEnd", new { maDeNghi = o.MaDeNghi, maDon = o.MaDonHang, ketQua = "HetHan" });
                }
                db.DieuPhoiLogs.Add(new DieuPhoiLog { MaDonHang = o.MaDonHang, HanhDong = "DeNghiHetHan", MaTaiXeCu = o.MaTaiXe, LyDo = $"Tài xế không phản hồi trong {cfg.GiayPhanHoi}s (vòng {o.Vong})" });
                xuLy++;
            }
            if (xuLy > 0) await db.SaveChangesAsync();
            return xuLy;
        }

        // ---- đề nghị còn "chờ" nhưng đơn đã có người nhận / bị hủy / không còn cần tài xế
        private static async Task<int> HuyDeNghiMoCoiAsync(AppDbContext db)
        {
            var ds = await db.DeNghiGiaoDons.AsNoTracking()
                .Where(o => o.TrangThai == "ChoPhanHoi" && !db.DonHangs.Any(d => d.MaDonHang == o.MaDonHang && d.TrangThai == "DaXacNhan" && d.MaTaiXe == null))
                .ToListAsync();
            var xuLy = 0;
            foreach (var o in ds)
            {
                var n = await db.DeNghiGiaoDons.Where(x => x.MaDeNghi == o.MaDeNghi && x.TrangThai == "ChoPhanHoi")
                    .ExecuteUpdateAsync(s => s.SetProperty(x => x.TrangThai, "Huy").SetProperty(x => x.PhanHoiLuc, (DateTime?)DateTime.Now).SetProperty(x => x.LyDoPhanHoi, "Đơn không còn chờ tài xế"));
                if (n == 0) continue;
                var maTk = await db.TaiXes.Where(t => t.MaTaiXe == o.MaTaiXe).Select(t => (int?)t.MaTK).FirstOrDefaultAsync();
                if (maTk != null)
                {
                    db.ThongBaos.Add(new ThongBao { MaTK = maTk.Value, Loai = "DonHang", MaThamChieu = o.MaDonHang.ToString(), TieuDe = "Đề nghị đơn đã được thu hồi", NoiDung = $"Đơn #{o.MaDonHang} không còn cần tài xế (đã có người nhận hoặc đã hủy)." });
                    PhatTaiXe(maTk.Value, "DriverOfferEnd", new { maDeNghi = o.MaDeNghi, maDon = o.MaDonHang, ketQua = "Huy" });
                }
                xuLy++;
            }
            if (xuLy > 0) await db.SaveChangesAsync();
            return xuLy;
        }

        /// <summary>Phòng trường hợp máy chủ dừng giữa chừng sau khi đã chiếm đơn nhưng chưa ghi chuyến giao: bổ sung bản ghi còn thiếu.</summary>
        private static async Task<int> SuaDonThieuGiaoHangAsync(AppDbContext db)
        {
            var thieu = await db.DonHangs.Where(d => d.MaTaiXe != null && d.TrangThai == "DaXacNhan" && !db.GiaoHangs.Any(g => g.MaDonHang == d.MaDonHang)).Select(d => new { d.MaDonHang, MaTx = d.MaTaiXe!.Value }).Take(20).ToListAsync();
            foreach (var d in thieu)
            {
                db.GiaoHangs.Add(new GiaoHang { MaDonHang = d.MaDonHang, MaTaiXe = d.MaTx, TrangThai = "DaNhan", ThoiGianNhan = DateTime.Now, TrangThaiThuNhap = "ChoThanhToan" });
                var tx = await db.TaiXes.FirstOrDefaultAsync(t => t.MaTaiXe == d.MaTx);
                if (tx != null && tx.TrangThai != "DangGiao") tx.TrangThai = "DangGiao";
            }
            if (thieu.Count > 0) await db.SaveChangesAsync();
            return thieu.Count;
        }

        // ---- tìm tài xế cho đơn đang chờ
        private static async Task<int> PhanPhoiDonChoAsync(AppDbContext db, CauHinhPhanPhoi cfg)
        {
            var now = DateTime.Now;
            var coDeNghi = (await db.DeNghiGiaoDons.AsNoTracking().Where(o => o.TrangThai == "ChoPhanHoi").Select(o => o.MaDonHang).ToListAsync()).ToHashSet();
            var donCho = await db.DonHangs.AsNoTracking()
                .Where(d => d.TrangThai == "DaXacNhan" && d.MaTaiXe == null && d.NguonGiao != "Quan" && (d.HenGiaoLuc == null || d.HenGiaoLuc <= now.AddMinutes(30)))
                .OrderByDescending(d => d.SanSangGiao).ThenBy(d => d.NgayDat).Take(30)
                .Select(d => new DonPhanPhoi(d.MaDonHang, d.MaGianHang, d.DiaChiGiaoHang, d.KhoangCachKm, d.ChiTiets.Sum(c => (int?)c.SoLuong) ?? 0)).ToListAsync();
            donCho = donCho.Where(d => !coDeNghi.Contains(d.MaDonHang)).ToList();
            if (donCho.Count == 0) return 0;

            var tn = await TaiTaiNguyenAsync(db);
            var tao = 0;
            foreach (var don in donCho)
            {
                var shop = await db.GianHangs.AsNoTracking().FirstOrDefaultAsync(g => g.MaGianHang == don.MaGianHang);
                var (vinhVien, chuKy) = await LoaiTruAsync(db, don.MaDonHang);
                PhanTichTaiXe? chon = null; var vongChon = 1;
                for (var vong = 1; vong <= cfg.SoVongToiDa && chon == null; vong++)
                {
                    var ds = PhanTich(don, shop, tn, cfg, vong, vinhVien, chuKy);
                    chon = ds.FirstOrDefault(x => x.CoThe);
                    vongChon = vong;
                }
                if (chon != null)
                {
                    if (await TaoDeNghiAsync(db, cfg, don, chon, vongChon))
                    {
                        tn.CoDeNghiCho.Add(chon.MaTaiXe);   // người này không nhận thêm đề nghị khác trong cùng lượt
                        tao++;
                    }
                    continue;
                }
                await XuLyKhongCoUngVienAsync(db, don, chuKy);
            }
            TongDeNghi += tao;
            return tao;
        }

        private static async Task<bool> TaoDeNghiAsync(AppDbContext db, CauHinhPhanPhoi cfg, DonPhanPhoi don, PhanTichTaiXe uv, int vong)
        {
            var o = new DeNghiGiaoDon
            {
                MaDonHang = don.MaDonHang, MaTaiXe = uv.MaTaiXe, Vong = vong, Diem = uv.Diem, KmDenQuan = uv.Km, LyDoChon = uv.LyDo.Length > 400 ? uv.LyDo[..400] : uv.LyDo,
                TaoLuc = DateTime.Now, HetHanLuc = DateTime.Now.AddSeconds(cfg.GiayPhanHoi),
            };
            db.DeNghiGiaoDons.Add(o);
            db.ThongBaos.Add(new ThongBao { MaTK = uv.MaTK, Loai = "DonHang", MaThamChieu = don.MaDonHang.ToString(), TieuDe = "Đơn mới cần bạn nhận", NoiDung = $"Đơn #{don.MaDonHang} ({don.SoMon} món) cách bạn khoảng {uv.Km:0.#} km. Nhận trong {cfg.GiayPhanHoi} giây." });
            db.DieuPhoiLogs.Add(new DieuPhoiLog { MaDonHang = don.MaDonHang, HanhDong = "DeNghi", MaTaiXeMoi = uv.MaTaiXe, LyDo = $"Vòng {vong} · điểm {uv.Diem:0.###} · {uv.LyDo}" });
            try { await db.SaveChangesAsync(); }
            catch (DbUpdateException) { db.ChangeTracker.Clear(); return false; }   // đã có đề nghị khác (chỉ mục duy nhất): bỏ qua, lượt sau thử lại
            PhatTaiXe(uv.MaTK, "DriverOffer", new { maDeNghi = o.MaDeNghi, maDon = don.MaDonHang, hetHanLuc = o.HetHanLuc, giay = cfg.GiayPhanHoi });
            return true;
        }

        /// <summary>Các đơn (trong danh sách đã cho) mà hệ thống đã thử hết mọi vòng nhưng không tài xế nào nhận
        /// (log "KhongCoTaiXe" mới hơn đề nghị cuối cùng) → quản trị cần PHÂN CÔNG TAY.</summary>
        public static async Task<HashSet<int>> DonCanPhanCongTayAsync(AppDbContext db, IReadOnlyCollection<int> maDons)
        {
            if (maDons.Count == 0) return new HashSet<int>();
            var ids = maDons.ToList();
            var log = await db.DieuPhoiLogs.AsNoTracking().Where(l => l.HanhDong == "KhongCoTaiXe" && ids.Contains(l.MaDonHang))
                .GroupBy(l => l.MaDonHang).Select(g => new { Ma = g.Key, Luc = g.Max(l => l.ThoiGian) }).ToListAsync();
            var denghi = await db.DeNghiGiaoDons.AsNoTracking().Where(o => ids.Contains(o.MaDonHang))
                .GroupBy(o => o.MaDonHang).Select(g => new { Ma = g.Key, Luc = g.Max(o => o.TaoLuc) }).ToListAsync();
            var cuoi = denghi.ToDictionary(x => x.Ma, x => x.Luc);
            return log.Where(l => !cuoi.TryGetValue(l.Ma, out var luc) || luc < l.Luc).Select(l => l.Ma).ToHashSet();
        }

        /// <summary>Hết ứng viên ở mọi vòng: báo quản trị (một lần / 10 phút) và, sau một khoảng nghỉ, mở lượt tìm mới (những người bỏ lỡ được đề nghị lại).</summary>
        private static async Task<int> XuLyKhongCoUngVienAsync(AppDbContext db, DonPhanPhoi don, HashSet<int> chuKy)
        {
            var thamChieu = don.MaDonHang.ToString();
            const string tieuDe = "Chưa có tài xế nhận đơn — cần bạn phân công";
            var moc = DateTime.Now.AddMinutes(-10);
            if (!await db.ThongBaos.AnyAsync(t => t.MaThamChieu == thamChieu && t.TieuDe == tieuDe && t.NgayTao > moc))
            {
                var admins = await db.TaiKhoans.Where(k => k.VaiTro == "QuanTri" && k.TrangThai).Select(k => k.MaTK).ToListAsync();
                foreach (var maTk in admins)
                    db.ThongBaos.Add(new ThongBao { MaTK = maTk, Loai = "DonHang", MaThamChieu = thamChieu, TieuDe = tieuDe, NoiDung = $"Đơn #{don.MaDonHang}: hệ thống đã tự tìm tài xế nhưng không ai nhận được (offline, quá tải, xa quán, từ chối, không phản hồi…). Hãy vào Điều phối → Đơn cần giao và PHÂN CÔNG TAY cho một tài xế." });
                db.DieuPhoiLogs.Add(new DieuPhoiLog { MaDonHang = don.MaDonHang, HanhDong = "KhongCoTaiXe", LyDo = "Không có tài xế nhận đơn ở mọi vòng — đã báo quản trị phân công tay" });
                await db.SaveChangesAsync();
            }
            if (chuKy.Count > 0)
            {
                var cu = DateTime.Now.AddSeconds(-60);
                var lanCuoi = await db.DeNghiGiaoDons.AsNoTracking().Where(o => o.MaDonHang == don.MaDonHang).MaxAsync(o => (DateTime?)o.PhanHoiLuc);
                if (lanCuoi == null || lanCuoi < cu)
                    await db.DeNghiGiaoDons.Where(o => o.MaDonHang == don.MaDonHang && o.TrangThai == "HetHan")
                        .ExecuteUpdateAsync(s => s.SetProperty(o => o.TrangThai, "Huy").SetProperty(o => o.LyDoPhanHoi, "Mở lượt tìm mới"));
            }
            return 1;
        }

        // ------------------------------------------------------------------------------------------------ tài xế phản hồi
        /// <summary>Đề nghị đang chờ của tài xế (nếu có).</summary>
        public static Task<DeNghiGiaoDon?> DeNghiHienTaiAsync(AppDbContext db, int maTaiXe) =>
            db.DeNghiGiaoDons.AsNoTracking().Where(o => o.MaTaiXe == maTaiXe && o.TrangThai == "ChoPhanHoi" && o.HetHanLuc > DateTime.Now).OrderByDescending(o => o.TaoLuc).FirstOrDefaultAsync();

        /// <summary>Tài xế bấm Nhận: chiếm đề nghị rồi chiếm đơn bằng UPDATE có điều kiện (an toàn khi nhiều bên cùng tác động).</summary>
        public static async Task<KetQuaGiao> NhanDeNghiAsync(AppDbContext db, TaiXe tx, long maDeNghi)
        {
            var now = DateTime.Now;
            if (tx.TrangThaiDuyet != "DaDuyet") return new(false, "Hồ sơ tài xế chưa được duyệt.");
            if (!await db.TaiKhoans.AnyAsync(k => k.MaTK == tx.MaTK && k.TrangThai)) return new(false, "Tài khoản tài xế đang bị khóa.");
            var o = await db.DeNghiGiaoDons.AsNoTracking().FirstOrDefaultAsync(x => x.MaDeNghi == maDeNghi && x.MaTaiXe == tx.MaTaiXe);
            if (o == null) return new(false, "Không tìm thấy đề nghị.");
            if (o.TrangThai == "DaNhan") return new(true, "Bạn đã nhận đơn này rồi.");
            if (o.TrangThai != "ChoPhanHoi" || o.HetHanLuc < now) return new(false, "Đề nghị đã hết hạn hoặc đã được xử lý — đơn có thể đã chuyển cho tài xế khác.");

            var cfg = await DocCauHinhAsync(db);
            var giu = await db.DonHangs.AsNoTracking().Where(d => d.MaTaiXe == tx.MaTaiXe && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao")).Select(d => new { d.MaGianHang, d.TrangThai }).ToListAsync();
            var maGh = await db.DonHangs.AsNoTracking().Where(d => d.MaDonHang == o.MaDonHang).Select(d => d.MaGianHang).FirstOrDefaultAsync();
            if (giu.Count >= cfg.ToiDaDon || giu.Any(x => x.MaGianHang != maGh || x.TrangThai == "DangGiao"))
            {
                await db.DeNghiGiaoDons.Where(x => x.MaDeNghi == maDeNghi && x.TrangThai == "ChoPhanHoi").ExecuteUpdateAsync(s => s.SetProperty(x => x.TrangThai, "Huy").SetProperty(x => x.LyDoPhanHoi, "Tài xế đang giữ đơn khác"));
                return new(false, "Bạn đang giữ đơn khác nên không nhận thêm được.");
            }

            // 1) chiếm đề nghị
            var n1 = await db.DeNghiGiaoDons.Where(x => x.MaDeNghi == maDeNghi && x.MaTaiXe == tx.MaTaiXe && x.TrangThai == "ChoPhanHoi" && x.HetHanLuc >= now)
                .ExecuteUpdateAsync(s => s.SetProperty(x => x.TrangThai, "DaNhan").SetProperty(x => x.PhanHoiLuc, (DateTime?)now));
            if (n1 == 0) return new(false, "Đề nghị vừa hết hạn hoặc đã được xử lý.");

            // 2) chiếm đơn: chỉ thành công nếu đơn vẫn chưa có tài xế
            var maTx = (int?)tx.MaTaiXe;
            var n2 = await db.DonHangs.Where(d => d.MaDonHang == o.MaDonHang && d.MaTaiXe == null && d.TrangThai == "DaXacNhan" && d.NguonGiao != "Quan")
                .ExecuteUpdateAsync(s => s.SetProperty(d => d.MaTaiXe, maTx).SetProperty(d => d.NguonGiao, "Ngoai"));
            if (n2 == 0)
            {
                await db.DeNghiGiaoDons.Where(x => x.MaDeNghi == maDeNghi).ExecuteUpdateAsync(s => s.SetProperty(x => x.TrangThai, "Huy").SetProperty(x => x.LyDoPhanHoi, "Đơn không còn chờ tài xế"));
                return new(false, "Đơn đã có người nhận hoặc đã bị hủy.");
            }

            // 3) hoàn tất ghi nhận
            await HoanTatGanAsync(db, o.MaDonHang, tx, "NhanDeNghi", $"Tài xế nhận đề nghị (vòng {o.Vong}): {o.LyDoChon}", null);
            return new(true, "Đã nhận đơn. Hãy đến quán lấy món.");
        }

        public static async Task<KetQuaGiao> TuChoiDeNghiAsync(AppDbContext db, TaiXe tx, long maDeNghi, string? lyDo)
        {
            var ghi = string.IsNullOrWhiteSpace(lyDo) ? "Tài xế từ chối" : lyDo.Trim();
            if (ghi.Length > 200) ghi = ghi[..200];
            var o = await db.DeNghiGiaoDons.AsNoTracking().FirstOrDefaultAsync(x => x.MaDeNghi == maDeNghi && x.MaTaiXe == tx.MaTaiXe);
            if (o == null) return new(false, "Không tìm thấy đề nghị.");
            var n = await db.DeNghiGiaoDons.Where(x => x.MaDeNghi == maDeNghi && x.MaTaiXe == tx.MaTaiXe && x.TrangThai == "ChoPhanHoi")
                .ExecuteUpdateAsync(s => s.SetProperty(x => x.TrangThai, "TuChoi").SetProperty(x => x.PhanHoiLuc, (DateTime?)DateTime.Now).SetProperty(x => x.LyDoPhanHoi, ghi));
            if (n == 0) return new(false, "Đề nghị đã hết hạn hoặc đã được xử lý.");
            if (!await db.TaiXeTuChoiDons.AnyAsync(r => r.MaDonHang == o.MaDonHang && r.MaTaiXe == tx.MaTaiXe))
                db.TaiXeTuChoiDons.Add(new TaiXeTuChoiDon { MaDonHang = o.MaDonHang, MaTaiXe = tx.MaTaiXe, LyDo = ghi });
            var t = await db.TaiXes.FirstOrDefaultAsync(x => x.MaTaiXe == tx.MaTaiXe);
            if (t != null) t.SoLanKhongPhanHoi = 0;     // chủ động từ chối không tính là bỏ lỡ
            db.DieuPhoiLogs.Add(new DieuPhoiLog { MaDonHang = o.MaDonHang, HanhDong = "TaiXeTuChoi", MaTaiXeCu = tx.MaTaiXe, LyDo = ghi });
            await db.SaveChangesAsync();
            DanhThucNgay();
            return new(true, "Đã từ chối. Đơn sẽ được chuyển cho tài xế khác.");
        }

        /// <summary>Ghi nhận sau khi đơn đã thuộc về tài xế: chuyến giao, trạng thái tài xế, nhật ký, thông báo.</summary>
        private static async Task HoanTatGanAsync(AppDbContext db, int maDon, TaiXe tx, string hanhDong, string lyDo, int? maTKQuanTri)
        {
            var now = DateTime.Now;
            var gh = await db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == maDon);
            if (gh == null) db.GiaoHangs.Add(new GiaoHang { MaDonHang = maDon, MaTaiXe = tx.MaTaiXe, TrangThai = "DaNhan", ThoiGianNhan = now, TrangThaiThuNhap = "ChoThanhToan" });
            else { gh.MaTaiXe = tx.MaTaiXe; gh.TrangThai = "DaNhan"; gh.ThoiGianNhan = now; gh.ThoiGianDenQuan = null; gh.TrangThaiThuNhap = "ChoThanhToan"; }
            var t = await db.TaiXes.FirstOrDefaultAsync(x => x.MaTaiXe == tx.MaTaiXe);
            if (t != null) { t.TrangThai = "DangGiao"; t.SoLanKhongPhanHoi = 0; }
            db.DieuPhoiLogs.Add(new DieuPhoiLog { MaDonHang = maDon, HanhDong = hanhDong, MaTaiXeMoi = tx.MaTaiXe, LyDo = lyDo.Length > 300 ? lyDo[..300] : lyDo, MaTK = maTKQuanTri });
            var maKH = await db.DonHangs.AsNoTracking().Where(d => d.MaDonHang == maDon).Select(d => d.MaKH).FirstAsync();
            var maTkKh = await db.KhachHangs.AsNoTracking().Where(k => k.MaKH == maKH).Select(k => (int?)k.MaTK).FirstOrDefaultAsync();
            if (maTkKh != null)
                db.ThongBaos.Add(new ThongBao { MaTK = maTkKh.Value, Loai = "DonHang", TieuDe = $"Đơn #{maDon} đã có tài xế", NoiDung = $"Tài xế {tx.HoTen} đã nhận đơn và đang đến quán lấy món.", MaThamChieu = maDon.ToString() });
            await db.SaveChangesAsync();
        }

        // ------------------------------------------------------------------------------------------------ thu hồi đơn / tài xế hủy
        /// <summary>
        /// Gỡ đơn khỏi tài xế (trước khi lấy hàng) bằng UPDATE có điều kiện rồi trả đơn về hàng chờ. Trả false nếu đơn đã đổi trạng thái / đã lấy hàng.
        /// </summary>
        private static async Task<bool> ThuHoiAsync(AppDbContext db, int maDon, int maTaiXe, string hanhDong, string lyDoNhatKy, string? thongBaoTaiXe, bool tinhPhat, int phutTamNgung)
        {
            var daLay = await db.GiaoHangs.AsNoTracking().AnyAsync(g => g.MaDonHang == maDon && g.ThoiGianLayHang != null);
            if (daLay) return false;
            var cu = (int?)maTaiXe;
            var n = await db.DonHangs.Where(d => d.MaDonHang == maDon && d.MaTaiXe == cu && d.TrangThai == "DaXacNhan")
                .ExecuteUpdateAsync(s => s.SetProperty(d => d.MaTaiXe, (int?)null));
            if (n == 0) return false;
            await db.GiaoHangs.Where(g => g.MaDonHang == maDon && g.MaTaiXe == maTaiXe).ExecuteDeleteAsync();
            if (!await db.TaiXeTuChoiDons.AnyAsync(r => r.MaDonHang == maDon && r.MaTaiXe == maTaiXe))
                db.TaiXeTuChoiDons.Add(new TaiXeTuChoiDon { MaDonHang = maDon, MaTaiXe = maTaiXe, LyDo = hanhDong });
            var tx = await db.TaiXes.FirstOrDefaultAsync(t => t.MaTaiXe == maTaiXe);
            if (tx != null)
            {
                if (tinhPhat)
                {
                    tx.SoLanHuySauNhan++;
                    if (tx.SoLanHuySauNhan % 3 == 0) tx.TamKhoaNhanDenLuc = DateTime.Now.AddMinutes(Math.Max(phutTamNgung, 15));
                }
                if (thongBaoTaiXe != null)
                    db.ThongBaos.Add(new ThongBao { MaTK = tx.MaTK, Loai = "DonHang", MaThamChieu = maDon.ToString(), TieuDe = $"Đơn #{maDon} đã được thu hồi", NoiDung = thongBaoTaiXe });
            }
            db.DieuPhoiLogs.Add(new DieuPhoiLog { MaDonHang = maDon, HanhDong = hanhDong, MaTaiXeCu = maTaiXe, LyDo = lyDoNhatKy });
            await db.SaveChangesAsync();
            await GiaoHangXuLy.GiaiPhongTaiXeAsync(db, maTaiXe, maDon);
            await db.SaveChangesAsync();
            DanhThucNgay();
            return true;
        }

        /// <summary>Tài xế tự hủy nhận đơn (chỉ trước khi lấy hàng): lý do bắt buộc, bị ghi nhận và đơn được tìm tài xế khác ngay.</summary>
        public static async Task<KetQuaGiao> TaiXeHuySauNhanAsync(AppDbContext db, TaiXe tx, int maDon, string? lyDo)
        {
            lyDo = (lyDo ?? "").Trim();
            if (lyDo.Length < 3) return new(false, "Vui lòng nhập lý do hủy nhận đơn.");
            var don = await db.DonHangs.AsNoTracking().Where(d => d.MaDonHang == maDon && d.MaTaiXe == tx.MaTaiXe).Select(d => new { d.TrangThai, d.MaKH }).FirstOrDefaultAsync();
            if (don == null) return new(false, "Đơn không thuộc về bạn.");
            if (don.TrangThai != "DaXacNhan") return new(false, "Đơn đã lấy hàng/đang giao hoặc đã kết thúc. Hãy báo sự cố giao hàng thay vì hủy nhận.");
            var cfg = await DocCauHinhAsync(db);
            if (!await ThuHoiAsync(db, maDon, tx.MaTaiXe, "TaiXeHuySauNhan", $"Tài xế {tx.HoTen} hủy nhận đơn: {lyDo}", null, true, cfg.PhutTamNgung))
                return new(false, "Không hủy nhận được: đơn đã lấy hàng hoặc vừa đổi trạng thái.");
            await BaoQuanTriAsync(db, maDon, "Tài xế hủy nhận đơn", $"Tài xế {tx.HoTen} đã hủy nhận đơn #{maDon}: {lyDo}. Hệ thống đang tìm tài xế khác.", 0);
            var maTkKh = await db.KhachHangs.AsNoTracking().Where(k => k.MaKH == don.MaKH).Select(k => (int?)k.MaTK).FirstOrDefaultAsync();
            if (maTkKh != null) db.ThongBaos.Add(new ThongBao { MaTK = maTkKh.Value, Loai = "DonHang", MaThamChieu = maDon.ToString(), TieuDe = $"Đơn #{maDon} đang tìm tài xế khác", NoiDung = "Tài xế trước không thể giao đơn của bạn. Chúng tôi đang chuyển cho tài xế khác." });
            await db.SaveChangesAsync();
            return new(true, "Đã hủy nhận đơn. Lưu ý: hủy nhiều lần sẽ bị tạm ngừng nhận đơn.");
        }

        /// <summary>Khách/quán/quản trị hủy đơn hoặc quản trị phân công tay: thu hồi mọi đề nghị đang chờ của đơn và báo tài xế đang được đề nghị. Chỉ thêm vào DbContext, người gọi tự SaveChanges.</summary>
        public static async Task HuyDeNghiTheoDonAsync(AppDbContext db, int maDon, string lyDo)
        {
            var ds = await db.DeNghiGiaoDons.AsNoTracking().Where(o => o.MaDonHang == maDon && o.TrangThai == "ChoPhanHoi").ToListAsync();
            foreach (var o in ds)
            {
                var n = await db.DeNghiGiaoDons.Where(x => x.MaDeNghi == o.MaDeNghi && x.TrangThai == "ChoPhanHoi")
                    .ExecuteUpdateAsync(s => s.SetProperty(x => x.TrangThai, "Huy").SetProperty(x => x.PhanHoiLuc, (DateTime?)DateTime.Now).SetProperty(x => x.LyDoPhanHoi, lyDo));
                if (n == 0) continue;
                var maTk = await db.TaiXes.Where(t => t.MaTaiXe == o.MaTaiXe).Select(t => (int?)t.MaTK).FirstOrDefaultAsync();
                if (maTk == null) continue;
                db.ThongBaos.Add(new ThongBao { MaTK = maTk.Value, Loai = "DonHang", MaThamChieu = maDon.ToString(), TieuDe = "Đề nghị đơn đã được thu hồi", NoiDung = $"Đơn #{maDon}: {lyDo}" });
                PhatTaiXe(maTk.Value, "DriverOfferEnd", new { maDeNghi = o.MaDeNghi, maDon, ketQua = "Huy" });
            }
        }

        /// <summary>Quản trị phân công/đổi tài xế: so sánh-và-thay (compare-and-set) để hai người cùng thao tác không ghi đè nhau. true = giành được đơn.</summary>
        public static async Task<bool> ChiemDonChoQuanTriAsync(AppDbContext db, int maDon, int maTaiXeMoi, int? maTaiXeCuKyVong)
        {
            var moi = (int?)maTaiXeMoi;
            var n = await db.DonHangs.Where(d => d.MaDonHang == maDon && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao") && d.MaTaiXe == maTaiXeCuKyVong)
                .ExecuteUpdateAsync(s => s.SetProperty(d => d.MaTaiXe, moi));
            if (n > 0) await HuyDeNghiTheoDonAsync(db, maDon, "Quản trị đã phân công tay cho tài xế khác");
            return n > 0;
        }

        // ------------------------------------------------------------------------------------------------ giám sát tài xế đã nhận đơn
        private static async Task BaoQuanTriAsync(AppDbContext db, int maDon, string tieuDe, string noiDung, int dedupePhut)
        {
            var tc = maDon.ToString();
            if (dedupePhut > 0)
            {
                var moc = DateTime.Now.AddMinutes(-dedupePhut);
                if (await db.ThongBaos.AnyAsync(t => t.MaThamChieu == tc && t.TieuDe == tieuDe && t.NgayTao > moc)) return;
            }
            var admins = await db.TaiKhoans.Where(k => k.VaiTro == "QuanTri" && k.TrangThai).Select(k => k.MaTK).ToListAsync();
            foreach (var maTk in admins) db.ThongBaos.Add(new ThongBao { MaTK = maTk, Loai = "DonHang", MaThamChieu = tc, TieuDe = tieuDe, NoiDung = noiDung });
        }

        /// <summary>Tài xế đã nhận nhưng quá hạn mà chưa bấm "Đã đến quán": thu hồi (khi bật tự động) hoặc chỉ cảnh báo quản trị.</summary>
        private static async Task<int> XuLyKhongDenQuanAsync(AppDbContext db, CauHinhPhanPhoi cfg, bool tuThuHoi)
        {
            var han = DateTime.Now.AddMinutes(-cfg.PhutDenQuan);
            var ds = await db.GiaoHangs.AsNoTracking()
                .Where(g => g.TrangThai == "DaNhan" && g.ThoiGianNhan != null && g.ThoiGianNhan < han && g.ThoiGianDenQuan == null && g.ThoiGianLayHang == null
                    && db.DonHangs.Any(d => d.MaDonHang == g.MaDonHang && d.MaTaiXe == g.MaTaiXe && d.TrangThai == "DaXacNhan"))
                .Select(g => new { g.MaDonHang, g.MaTaiXe }).Take(20).ToListAsync();
            var xuLy = 0;
            foreach (var g in ds)
            {
                if (tuThuHoi)
                {
                    var ok = await ThuHoiAsync(db, g.MaDonHang, g.MaTaiXe, "KhongDenQuan", $"Tài xế không đến quán sau {cfg.PhutDenQuan} phút — thu hồi và tìm người khác",
                        $"Bạn chưa đến quán sau {cfg.PhutDenQuan} phút kể từ lúc nhận nên đơn #{g.MaDonHang} được chuyển cho tài xế khác.", true, cfg.PhutTamNgung);
                    if (ok) { await BaoQuanTriAsync(db, g.MaDonHang, "Đơn bị thu hồi: tài xế không đến quán", $"Đơn #{g.MaDonHang} được thu hồi vì tài xế chưa đến quán sau {cfg.PhutDenQuan} phút. Hệ thống đang tìm tài xế khác.", 0); await db.SaveChangesAsync(); xuLy++; }
                }
                else
                {
                    await BaoQuanTriAsync(db, g.MaDonHang, "Tài xế chưa đến quán", $"Đơn #{g.MaDonHang}: tài xế đã nhận hơn {cfg.PhutDenQuan} phút nhưng chưa báo đến quán. Hãy liên hệ hoặc đổi tài xế.", 20);
                    await db.SaveChangesAsync(); xuLy++;
                }
            }
            return xuLy;
        }

        /// <summary>
        /// Mất GPS/mạng: tài xế đã nhận nhưng chưa lấy hàng và mất nhịp quá N phút → thu hồi; đã lấy hàng (đang giao) → KHÔNG thu hồi, chỉ báo quản trị liên lạc.
        /// </summary>
        private static async Task<int> XuLyMatLienLacAsync(AppDbContext db, CauHinhPhanPhoi cfg, bool tuThuHoi)
        {
            var moc = DateTime.Now.AddMinutes(-cfg.PhutMatLienLac);
            var ds = await db.DonHangs.AsNoTracking()
                .Where(d => d.MaTaiXe != null && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao")
                    && db.TaiXes.Any(t => t.MaTaiXe == d.MaTaiXe && t.NhipLuc != null && t.NhipLuc < moc))
                .Select(d => new { d.MaDonHang, d.TrangThai, MaTx = d.MaTaiXe!.Value }).Take(20).ToListAsync();
            var xuLy = 0;
            foreach (var d in ds)
            {
                var daLay = d.TrangThai == "DangGiao" || await db.GiaoHangs.AsNoTracking().AnyAsync(g => g.MaDonHang == d.MaDonHang && g.ThoiGianLayHang != null);
                if (daLay)
                {
                    await BaoQuanTriAsync(db, d.MaDonHang, "Mất liên lạc với tài xế đang giao", $"Đơn #{d.MaDonHang}: tài xế mất kết nối quá {cfg.PhutMatLienLac} phút khi đang giao. Hãy gọi điện xác minh (hệ thống không tự thu hồi đơn đã lấy hàng).", 15);
                    await db.SaveChangesAsync(); xuLy++;
                }
                else if (tuThuHoi)
                {
                    var ok = await ThuHoiAsync(db, d.MaDonHang, d.MaTx, "MatLienLac", $"Tài xế mất kết nối quá {cfg.PhutMatLienLac} phút trước khi lấy hàng — thu hồi",
                        $"Ứng dụng của bạn mất kết nối quá {cfg.PhutMatLienLac} phút nên đơn #{d.MaDonHang} được chuyển cho tài xế khác.", false, cfg.PhutTamNgung);
                    if (ok) { await BaoQuanTriAsync(db, d.MaDonHang, "Đơn bị thu hồi: tài xế mất kết nối", $"Đơn #{d.MaDonHang} được thu hồi vì tài xế mất GPS/mạng quá {cfg.PhutMatLienLac} phút trước khi lấy hàng.", 0); await db.SaveChangesAsync(); xuLy++; }
                }
                else
                {
                    await BaoQuanTriAsync(db, d.MaDonHang, "Tài xế mất kết nối", $"Đơn #{d.MaDonHang}: tài xế mất kết nối quá {cfg.PhutMatLienLac} phút trước khi lấy hàng. Cân nhắc đổi tài xế.", 20);
                    await db.SaveChangesAsync(); xuLy++;
                }
            }
            return xuLy;
        }

        // ------------------------------------------------------------------------------------------------ nhịp kết nối của app tài xế
        /// <summary>App tài xế báo "còn kết nối" kèm vị trí (tuỳ chọn). Cập nhật nhanh bằng một câu UPDATE.</summary>
        public static async Task NhipAsync(AppDbContext db, int maTaiXe, double? lat, double? lng)
        {
            var now = DateTime.Now;
            var coToaDo = lat is >= -90 and <= 90 && lng is >= -180 and <= 180 && !(lat == 0 && lng == 0);
            if (coToaDo)
            {
                var la = lat; var lo = lng; var luc = (DateTime?)now;
                await db.TaiXes.Where(t => t.MaTaiXe == maTaiXe).ExecuteUpdateAsync(s => s.SetProperty(t => t.NhipLuc, luc).SetProperty(t => t.ViDo, la).SetProperty(t => t.KinhDo, lo).SetProperty(t => t.ViTriLuc, luc));
            }
            else
                await db.TaiXes.Where(t => t.MaTaiXe == maTaiXe).ExecuteUpdateAsync(s => s.SetProperty(t => t.NhipLuc, (DateTime?)now));
        }
    }

    /// <summary>Vòng lặp nền: mỗi ~5 giây (hoặc ngay khi được đánh thức) chạy bộ máy phân phối đơn.</summary>
    public class PhanPhoiNen : BackgroundService
    {
        private readonly IServiceScopeFactory _scopes;
        private readonly ILogger<PhanPhoiNen> _log;
        public PhanPhoiNen(IServiceScopeFactory scopes, ILogger<PhanPhoiNen> log) { _scopes = scopes; _log = log; }

        protected override async Task ExecuteAsync(CancellationToken ct)
        {
            try { await Task.Delay(TimeSpan.FromSeconds(15), ct); } catch (OperationCanceledException) { return; }
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    using var scope = _scopes.CreateScope();
                    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                    await PhanPhoiDonXuLy.ChayAsync(db);
                }
                catch (Exception ex) { _log.LogWarning(ex, "Phân phối đơn lỗi"); }
                try { await PhanPhoiDonXuLy.ChoNhipAsync(TimeSpan.FromSeconds(5), ct); } catch (OperationCanceledException) { break; }
            }
        }
    }
}
