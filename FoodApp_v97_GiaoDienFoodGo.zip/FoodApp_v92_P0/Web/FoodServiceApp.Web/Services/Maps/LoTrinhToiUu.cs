namespace FoodServiceApp.Web.Services.Maps
{
    public record DiemLoTrinh(int MaDon, bool LaLayHang, bool DaLayTruoc);

    /// <summary>Sắp thứ tự nhiều điểm lấy/giao: láng giềng gần nhất (lấy trước giao) rồi cải thiện bằng 2-opt, theo ma trận quãng đường THẬT.
    /// Ràng buộc: điểm giao của một đơn chỉ đứng sau điểm lấy của đơn đó (trừ khi đã lấy hàng từ trước).</summary>
    public static class LoTrinhToiUu
    {
        /// <param name="kc">kc[i,j] = quãng đường (km) từ điểm i đến điểm j.</param>
        /// <param name="tuDau">tuDau[i] = quãng đường từ vị trí hiện tại đến điểm i (null nếu không biết vị trí).</param>
        public static (List<int> ThuTu, double TongKm) Giai(IReadOnlyList<DiemLoTrinh> diem, double[,] kc, double[]? tuDau)
        {
            int n = diem.Count;
            var daLayBanDau = diem.Where(d => d.DaLayTruoc).Select(d => d.MaDon).ToHashSet();

            bool HopLe(IReadOnlyList<int> t)
            {
                var da = new HashSet<int>(daLayBanDau);
                foreach (var i in t)
                {
                    if (diem[i].LaLayHang) da.Add(diem[i].MaDon);
                    else if (!da.Contains(diem[i].MaDon)) return false;
                }
                return true;
            }
            double Dai(IReadOnlyList<int> t)
            {
                if (t.Count == 0) return 0;
                double s = tuDau != null ? tuDau[t[0]] : 0;
                for (int i = 1; i < t.Count; i++) s += kc[t[i - 1], t[i]];
                return s;
            }

            // láng giềng gần nhất có ràng buộc
            var con = Enumerable.Range(0, n).ToList();
            var kq = new List<int>();
            var da0 = new HashSet<int>(daLayBanDau);
            int? hienTai = null;
            while (con.Count > 0)
            {
                var uv = con.Where(i => diem[i].LaLayHang || da0.Contains(diem[i].MaDon)).ToList();
                if (uv.Count == 0) uv = con;
                int chon = uv.OrderBy(i => hienTai is int h ? kc[h, i] : (tuDau != null ? tuDau[i] : 0)).First();
                kq.Add(chon); con.Remove(chon);
                if (diem[chon].LaLayHang) da0.Add(diem[chon].MaDon);
                hienTai = chon;
            }

            // 2-opt (chỉ nhận hoán vị hợp lệ)
            bool tot = true; int vong = 0;
            while (tot && vong++ < 60)
            {
                tot = false;
                for (int i = 0; i < kq.Count - 1; i++)
                    for (int j = i + 1; j < kq.Count; j++)
                    {
                        var thu = kq.Take(i).Concat(kq.Skip(i).Take(j - i + 1).Reverse()).Concat(kq.Skip(j + 1)).ToList();
                        if (HopLe(thu) && Dai(thu) + 0.01 < Dai(kq)) { kq = thu; tot = true; }
                    }
            }
            return (kq, Dai(kq));
        }

        public static double TongTheoThuTu(IReadOnlyList<int> t, double[,] kc, double[]? tuDau)
        {
            if (t.Count == 0) return 0;
            double s = tuDau != null ? tuDau[t[0]] : 0;
            for (int i = 1; i < t.Count; i++) s += kc[t[i - 1], t[i]];
            return s;
        }
    }
}
