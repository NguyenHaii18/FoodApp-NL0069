using FoodServiceApp.Web.Services.Configs;

namespace FoodServiceApp.Web.Services.Maps
{
    /// <summary>Khóa Goong dùng chung. Ưu tiên khóa quản trị nhập trong ứng dụng (lưu ở CauHinhHeThong "Goong.ApiKey"), nếu không có thì dùng appsettings.</summary>
    public static class GoongKhoa
    {
        public const string KhoaCauHinh = "Goong.ApiKey";
        private static volatile string _ghiDe = "";

        public static void DatGhiDe(string? khoa) => _ghiDe = (khoa ?? "").Trim();

        public static string Lay(GoongMapsSettings s) => _ghiDe.Length > 0 ? _ghiDe : (s.ApiKey ?? "");

        public static bool Hop(string? k) => !string.IsNullOrWhiteSpace(k) && !k.StartsWith("DIEN_API_KEY", StringComparison.OrdinalIgnoreCase);

        public static bool Co(GoongMapsSettings s) => Hop(Lay(s));

        public static string Nguon(GoongMapsSettings s) => Hop(_ghiDe) ? "Nhập trong ứng dụng (CSDL)" : Hop(s.ApiKey) ? "appsettings.json" : "Chưa cấu hình";

        public static string Che(string? k) => string.IsNullOrEmpty(k) ? "" : k.Length <= 8 ? new string('•', k.Length) : k[..4] + new string('•', 6) + k[^4..];
    }

    /// <summary>Hệ số kẹt xe ước tính theo khung giờ (Goong DistanceMatrix không có dữ liệu giao thông thời gian thực).</summary>
    public static class GiaoThongTheoGio
    {
        public static (double HeSo, string Nhan) Lay(DateTime luc)
        {
            double gio = luc.Hour + luc.Minute / 60.0;
            bool cuoiTuan = luc.DayOfWeek is DayOfWeek.Saturday or DayOfWeek.Sunday;
            if (gio >= 7 && gio < 9) return (cuoiTuan ? 1.1 : 1.4, "giờ cao điểm sáng");
            if (gio >= 11 && gio < 13) return (1.25, "giờ ăn trưa");
            if (gio >= 16.5 && gio < 19.5) return (cuoiTuan ? 1.3 : 1.5, "giờ cao điểm chiều");
            if (gio >= 22 || gio < 5) return (0.85, "đêm khuya, đường vắng");
            return (1.0, "giờ bình thường");
        }
    }
}
