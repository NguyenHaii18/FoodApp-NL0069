using System.Text.Json;
using Microsoft.Extensions.Options;
using FoodServiceApp.Web.Services.Configs;

namespace FoodServiceApp.Web.Services.Maps
{
    public class GoongMapsService : IGoongMapsService
    {
        private readonly HttpClient _httpClient;
        private readonly GoongMapsSettings _settings;

        public GoongMapsService(HttpClient httpClient, IOptions<GoongMapsSettings> options)
        {
            _httpClient = httpClient;
            _settings = options.Value;
        }

        public async Task<GeoPoint?> GeocodeAsync(string address)
        {
            var url = $"{_settings.BaseUrl}/Geocode?address={Uri.EscapeDataString(address)}&api_key={GoongKhoa.Lay(_settings)}";
            using var response = await _httpClient.GetAsync(url);
            if (!response.IsSuccessStatusCode)
                return null;

            using var stream = await response.Content.ReadAsStreamAsync();
            using var doc = await JsonDocument.ParseAsync(stream);

            var results = doc.RootElement.GetProperty("results");
            if (results.GetArrayLength() == 0)
                return null;

            var location = results[0].GetProperty("geometry").GetProperty("location");
            var lat = location.GetProperty("lat").GetDouble();
            var lng = location.GetProperty("lng").GetDouble();
            return new GeoPoint(lat, lng);
        }

        /// <summary>Goong Direction (xe máy): lấy polyline của tuyến để vẽ bản đồ.</summary>
        public async Task<RouteResult?> GetRouteAsync(GeoPoint origin, GeoPoint destination)
        {
            var url = $"{_settings.BaseUrl}/Direction?origin={origin.Lat},{origin.Lng}&destination={destination.Lat},{destination.Lng}" +
                      $"&vehicle=bike&api_key={GoongKhoa.Lay(_settings)}";
            using var response = await _httpClient.GetAsync(url);
            if (!response.IsSuccessStatusCode) return null;
            using var stream = await response.Content.ReadAsStreamAsync();
            using var doc = await JsonDocument.ParseAsync(stream);
            if (!doc.RootElement.TryGetProperty("routes", out var routes) || routes.GetArrayLength() == 0) return null;
            var route = routes[0];
            var points = route.TryGetProperty("overview_polyline", out var op) && op.TryGetProperty("points", out var pt) ? pt.GetString() : null;
            if (string.IsNullOrEmpty(points)) return null;
            double met = 0, giay = 0;
            if (route.TryGetProperty("legs", out var legs))
                foreach (var leg in legs.EnumerateArray())
                {
                    if (leg.TryGetProperty("distance", out var d) && d.TryGetProperty("value", out var dv)) met += dv.GetDouble();
                    if (leg.TryGetProperty("duration", out var t) && t.TryGetProperty("value", out var tv)) giay += tv.GetDouble();
                }
            return new RouteResult(Math.Round(met / 1000.0, 2), (int)Math.Ceiling(giay / 60.0), GiaiMaPolyline(points));
        }

        /// <summary>Giải mã Google/Goong encoded polyline (độ chính xác 5 chữ số thập phân).</summary>
        public static List<GeoPoint> GiaiMaPolyline(string ma)
        {
            var kq = new List<GeoPoint>(); int i = 0, lat = 0, lng = 0;
            while (i < ma.Length)
            {
                int Doc()
                {
                    int shift = 0, res = 0, b;
                    do { b = ma[i++] - 63; res |= (b & 0x1f) << shift; shift += 5; } while (b >= 0x20 && i < ma.Length);
                    return (res & 1) != 0 ? ~(res >> 1) : res >> 1;
                }
                lat += Doc(); lng += Doc();
                kq.Add(new GeoPoint(lat / 1e5, lng / 1e5));
            }
            return kq;
        }

        public async Task<DistanceResult?> GetDistanceAsync(GeoPoint origin, GeoPoint destination)
        {
            var origins = $"{origin.Lat},{origin.Lng}";
            var destinations = $"{destination.Lat},{destination.Lng}";
            // vehicle=bike phù hợp với giao hàng bằng xe máy trong đô thị
            var url = $"{_settings.BaseUrl}/DistanceMatrix?origins={origins}&destinations={destinations}" +
                      $"&vehicle=bike&api_key={GoongKhoa.Lay(_settings)}";

            using var response = await _httpClient.GetAsync(url);
            if (!response.IsSuccessStatusCode)
                return null;

            using var stream = await response.Content.ReadAsStreamAsync();
            using var doc = await JsonDocument.ParseAsync(stream);

            var element = doc.RootElement
                .GetProperty("rows")[0]
                .GetProperty("elements")[0];

            if (element.GetProperty("status").GetString() != "OK")
                return null;

            var distanceMeters = element.GetProperty("distance").GetProperty("value").GetDouble();
            var durationSeconds = element.GetProperty("duration").GetProperty("value").GetDouble();

            return new DistanceResult(
                DistanceKm: Math.Round(distanceMeters / 1000.0, 2),
                DurationMinutes: (int)Math.Ceiling(durationSeconds / 60.0)
            );
        }
    }
}
