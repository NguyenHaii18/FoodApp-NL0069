using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;

namespace FoodServiceApp.Web.Services
{
    /// <summary>
    /// Lưu file cục bộ.
    ///  - Ảnh công khai (món, quán, banner, đánh giá, avatar...): wwwroot/uploads/{sub} (phục vụ tĩnh).
    ///  - Tài liệu riêng tư (giấy phép kinh doanh, ATTP, GPLX...): {ContentRoot}/App_Data/private/{sub} — NẰM NGOÀI wwwroot,
    ///    không có đường truy cập tĩnh; chỉ đọc được qua <c>PrivateFileController</c>.
    /// Nội dung file được kiểm tra bằng "chữ ký" (magic bytes) chứ không tin phần mở rộng/Content-Type do máy khách gửi;
    /// phần mở rộng lưu xuống luôn lấy theo định dạng thật phát hiện được.
    /// </summary>
    public class LocalFileStorageService : IFileStorageService
    {
        public const string TienToRiengTu = "/files/private/";
        public static readonly string[] ThuMucRiengTu = { "giayto", "taixe-giayto" };

        private readonly IWebHostEnvironment _env;
        private const long MaxFileSizeBytes = 5 * 1024 * 1024; // 5MB

        public LocalFileStorageService(IWebHostEnvironment env) { _env = env; }

        public static bool LaRiengTu(string sub) => ThuMucRiengTu.Contains(sub, StringComparer.OrdinalIgnoreCase);

        public string GocRiengTu => Path.Combine(_env.ContentRootPath, "App_Data", "private");

        /// <summary>Nhận dạng định dạng thật của file: trả về phần mở rộng (.jpg/.png/.webp/.pdf) hoặc null nếu không hợp lệ.</summary>
        public static string? NhanDang(byte[] d, int n)
        {
            if (n >= 3 && d[0] == 0xFF && d[1] == 0xD8 && d[2] == 0xFF) return ".jpg";
            if (n >= 8 && d[0] == 0x89 && d[1] == 0x50 && d[2] == 0x4E && d[3] == 0x47 && d[4] == 0x0D && d[5] == 0x0A && d[6] == 0x1A && d[7] == 0x0A) return ".png";
            if (n >= 12 && d[0] == 'R' && d[1] == 'I' && d[2] == 'F' && d[3] == 'F' && d[8] == 'W' && d[9] == 'E' && d[10] == 'B' && d[11] == 'P') return ".webp";
            if (n >= 5 && d[0] == '%' && d[1] == 'P' && d[2] == 'D' && d[3] == 'F' && d[4] == '-') return ".pdf";
            return null;
        }

        public async Task<string> SaveFileAsync(IFormFile file, string subFolder)
        {
            if (file == null || file.Length == 0)
                throw new ArgumentException("File không hợp lệ hoặc rỗng.");
            if (file.Length > MaxFileSizeBytes)
                throw new ArgumentException("File vượt quá dung lượng cho phép (5MB).");
            if (string.IsNullOrWhiteSpace(subFolder) || subFolder.Any(c => !(char.IsLetterOrDigit(c) || c == '-' || c == '_')))
                throw new ArgumentException("Thư mục lưu không hợp lệ.");

            var riengTu = LaRiengTu(subFolder);

            // Đọc phần đầu file để nhận dạng định dạng thật.
            var dau = new byte[16];
            int n;
            await using (var doc = file.OpenReadStream()) n = await doc.ReadAsync(dau.AsMemory(0, dau.Length));
            var duoi = NhanDang(dau, n);
            if (duoi == null)
                throw new ArgumentException(riengTu ? "Chỉ chấp nhận ảnh JPG/PNG/WebP hoặc PDF hợp lệ." : "Chỉ chấp nhận ảnh JPG, PNG hoặc WebP hợp lệ.");
            if (duoi == ".pdf" && !riengTu)
                throw new ArgumentException("Chỉ chấp nhận ảnh JPG, PNG hoặc WebP hợp lệ.");

            var thuMuc = riengTu
                ? Path.Combine(GocRiengTu, subFolder)
                : Path.Combine(_env.WebRootPath ?? "wwwroot", "uploads", subFolder);
            Directory.CreateDirectory(thuMuc);

            var fileName = $"{Guid.NewGuid():N}{duoi}";
            var fullPath = Path.Combine(thuMuc, fileName);
            await using (var stream = new FileStream(fullPath, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                await file.CopyToAsync(stream);

            return riengTu ? $"{TienToRiengTu}{subFolder}/{fileName}" : $"/uploads/{subFolder}/{fileName}";
        }

        public string? TimFileRiengTu(string subFolder, string fileName)
        {
            if (!LaRiengTu(subFolder)) return null;
            // Chỉ nhận tên file dạng guid + đuôi cho phép; chặn ../ và đường dẫn tuyệt đối.
            if (string.IsNullOrWhiteSpace(fileName) || fileName != Path.GetFileName(fileName) || fileName.Length > 80) return null;
            var duoi = Path.GetExtension(fileName).ToLowerInvariant();
            if (duoi is not (".jpg" or ".png" or ".webp" or ".pdf")) return null;
            var sub = ThuMucRiengTu.First(x => x.Equals(subFolder, StringComparison.OrdinalIgnoreCase));
            var full = Path.GetFullPath(Path.Combine(GocRiengTu, sub, fileName));
            if (!full.StartsWith(Path.GetFullPath(GocRiengTu) + Path.DirectorySeparatorChar, StringComparison.Ordinal)) return null;
            return File.Exists(full) ? full : null;
        }

        public void DeleteFile(string relativeUrl)
        {
            if (string.IsNullOrWhiteSpace(relativeUrl)) return;
            try
            {
                if (relativeUrl.StartsWith(TienToRiengTu, StringComparison.OrdinalIgnoreCase))
                {
                    var phan = relativeUrl.Substring(TienToRiengTu.Length).Split('/', 2);
                    if (phan.Length == 2 && TimFileRiengTu(phan[0], phan[1]) is { } p) File.Delete(p);
                    return;
                }
                if (!relativeUrl.StartsWith("/uploads/", StringComparison.OrdinalIgnoreCase)) return;
                var goc = Path.GetFullPath(Path.Combine(_env.WebRootPath ?? "wwwroot", "uploads"));
                var fullPath = Path.GetFullPath(Path.Combine(_env.WebRootPath ?? "wwwroot", relativeUrl.TrimStart('/')));
                if (fullPath.StartsWith(goc + Path.DirectorySeparatorChar, StringComparison.Ordinal) && File.Exists(fullPath))
                    File.Delete(fullPath);
            }
            catch (IOException) { /* file đang bị khóa: bỏ qua */ }
        }
    }
}
