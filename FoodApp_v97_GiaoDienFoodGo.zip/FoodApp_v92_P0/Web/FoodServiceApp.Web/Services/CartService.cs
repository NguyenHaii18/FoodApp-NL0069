using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Models.ViewModels;

namespace FoodServiceApp.Web.Services
{
    /// <summary>
    /// Giỏ hàng — mỗi giỏ chỉ chứa món của MỘT gian hàng tại một thời điểm.
    /// • Khách CHƯA đăng nhập: lưu trong Session.
    /// • Khách ĐÃ đăng nhập (vai trò KhachHang): lưu trong CSDL (bảng GioHang / GioHangChiTiet — dùng chung với app Mobile),
    ///   nên không mất khi đăng xuất / đổi thiết bị và đồng bộ với app. Giá KHÔNG lưu: luôn dựng lại theo giá hiện tại.
    /// • Đăng nhập khi đang có giỏ ở Session: giỏ đó được gộp vào giỏ trên tài khoản (cùng gian hàng -> cộng dồn;
    ///   khác gian hàng -> giỏ vừa tạo thay giỏ cũ).
    /// </summary>
    public class CartService
    {
        private const string SessionKey = "GioHang";
        public const int SoLuongToiDa = 50;

        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly AppDbContext _db;

        public CartService(IHttpContextAccessor httpContextAccessor, AppDbContext db)
        {
            _httpContextAccessor = httpContextAccessor;
            _db = db;
        }

        private HttpContext Http => _httpContextAccessor.HttpContext!;
        private ISession Session => Http.Session;

        private int? MaKhDangNhap()
        {
            var u = Http.User;
            if (u?.Identity?.IsAuthenticated != true || !u.IsInRole("KhachHang")) return null;
            return int.TryParse(u.FindFirst("MaKH")?.Value, out var id) ? id : null;
        }

        // ------------------------------------------------------------ Session (khách vãng lai)
        private Cart DocSession()
        {
            var json = Session.GetString(SessionKey);
            if (string.IsNullOrEmpty(json)) return new Cart();
            try { return JsonSerializer.Deserialize<Cart>(json) ?? new Cart(); }
            catch (JsonException) { return new Cart(); }
        }

        // ------------------------------------------------------------ CSDL (khách đã đăng nhập)
        private static List<string> DocTenTuyChon(string? json)
        {
            if (string.IsNullOrWhiteSpace(json)) return new List<string>();
            try { return JsonSerializer.Deserialize<List<string>>(json) ?? new List<string>(); }
            catch (JsonException) { return new List<string>(); }
        }

        private Cart DocDb(int maKh)
        {
            var g = _db.GioHangs.AsNoTracking().Include(x => x.ChiTiet).FirstOrDefault(x => x.MaKH == maKh);
            if (g == null || !g.ChiTiet.Any()) return new Cart();

            var ids = g.ChiTiet.Select(c => c.MaMonAn).Distinct().ToList();
            var mons = _db.MonAns.AsNoTracking().Where(m => ids.Contains(m.MaMonAn)).ToDictionary(m => m.MaMonAn);
            var tuyChons = _db.TuyChonMons.AsNoTracking().Where(t => ids.Contains(t.MaMonAn)).ToList();
            var tenGianHang = _db.GianHangs.AsNoTracking().Where(x => x.MaGianHang == g.MaGianHang).Select(x => x.TenCuaHang).FirstOrDefault() ?? "";

            var cart = new Cart { MaGianHang = g.MaGianHang, TenGianHang = tenGianHang };
            foreach (var c in g.ChiTiet.OrderBy(c => c.MaChiTiet))
            {
                if (!mons.TryGetValue(c.MaMonAn, out var m)) continue;   // món đã bị xóa khỏi hệ thống
                var ten = DocTenTuyChon(c.TuyChon);
                var chon = tuyChons.Where(t => t.MaMonAn == m.MaMonAn && ten.Contains(t.TenTuyChon)).ToList();
                var item = new CartItem
                {
                    MaMonAn = m.MaMonAn,
                    TenMon = m.TenMon,
                    Gia = m.Gia + chon.Sum(t => t.GiaThem),   // luôn theo giá hiện tại
                    SoLuong = Math.Clamp(c.SoLuong, 1, SoLuongToiDa),
                    HinhAnh = m.HinhAnh,
                    GhiChu = c.GhiChu,
                    TuyChonIds = chon.Select(t => t.MaTuyChon).ToList(),
                    TuyChonText = chon.Count == 0 ? null : string.Join("; ", chon.Select(t => t.TenTuyChon)),
                };
                var trung = cart.Items.FirstOrDefault(i => i.Khoa == item.Khoa);
                if (trung != null) trung.SoLuong = Math.Min(SoLuongToiDa, trung.SoLuong + item.SoLuong);
                else cart.Items.Add(item);
            }
            return cart;
        }

        private void GhiDb(int maKh, Cart cart)
        {
            var g = _db.GioHangs.Include(x => x.ChiTiet).FirstOrDefault(x => x.MaKH == maKh);
            if (!cart.Items.Any())
            {
                if (g != null) { _db.GioHangs.Remove(g); _db.SaveChanges(); }
                return;
            }
            if (g == null) { g = new GioHang { MaKH = maKh }; _db.GioHangs.Add(g); }
            else { _db.GioHangChiTiets.RemoveRange(g.ChiTiet); g.ChiTiet.Clear(); }

            g.MaGianHang = cart.MaGianHang;
            g.NgayCapNhat = DateTime.Now;
            foreach (var i in cart.Items)
            {
                var ten = string.IsNullOrEmpty(i.TuyChonText)
                    ? null
                    : i.TuyChonText.Split("; ", StringSplitOptions.RemoveEmptyEntries).ToList();
                g.ChiTiet.Add(new GioHangChiTiet
                {
                    MaMonAn = i.MaMonAn,
                    SoLuong = Math.Clamp(i.SoLuong, 1, SoLuongToiDa),
                    GhiChu = string.IsNullOrWhiteSpace(i.GhiChu) ? null : i.GhiChu.Trim(),
                    TuyChon = ten is { Count: > 0 } ? JsonSerializer.Serialize(ten) : null,
                });
            }
            _db.SaveChanges();
        }

        // ------------------------------------------------------------ API dùng chung
        public Cart LayGioHang()
        {
            var maKh = MaKhDangNhap();
            if (maKh == null) return DocSession();

            var guest = DocSession();
            var daLuu = DocDb(maKh.Value);
            if (!guest.Items.Any()) return daLuu;

            // Vừa đăng nhập khi đang có giỏ ở Session -> gộp vào giỏ trên tài khoản
            Cart gop;
            if (daLuu.Items.Any() && daLuu.MaGianHang == guest.MaGianHang)
            {
                gop = daLuu;
                foreach (var it in guest.Items)
                {
                    var t = gop.Items.FirstOrDefault(i => i.Khoa == it.Khoa);
                    if (t != null) t.SoLuong = Math.Min(SoLuongToiDa, t.SoLuong + it.SoLuong);
                    else gop.Items.Add(it);
                }
            }
            else gop = guest;

            Session.Remove(SessionKey);
            GhiDb(maKh.Value, gop);
            return gop;
        }

        private void Luu(Cart cart)
        {
            var maKh = MaKhDangNhap();
            if (maKh != null) GhiDb(maKh.Value, cart);
            else Session.SetString(SessionKey, JsonSerializer.Serialize(cart));
        }

        public void XoaGioHang()
        {
            Session.Remove(SessionKey);
            var maKh = MaKhDangNhap();
            if (maKh != null) GhiDb(maKh.Value, new Cart());
        }

        /// <returns>null nếu thêm thành công; ngược lại trả về thông báo lỗi (khác gian hàng)</returns>
        public string? ThemMon(int maGianHang, string tenGianHang, CartItem monMoi)
        {
            var cart = LayGioHang();

            if (cart.Items.Any() && cart.MaGianHang != maGianHang)
                return "Giỏ hàng đang có món của gian hàng khác. Vui lòng đặt xong hoặc xoá giỏ hàng hiện tại trước khi thêm món từ gian hàng mới.";

            cart.MaGianHang = maGianHang;
            cart.TenGianHang = tenGianHang;

            var monCu = cart.Items.FirstOrDefault(i => i.Khoa == monMoi.Khoa);
            if (monCu != null)
                monCu.SoLuong = Math.Min(SoLuongToiDa, monCu.SoLuong + monMoi.SoLuong);
            else
                cart.Items.Add(monMoi);

            Luu(cart);
            return null;
        }

        /// <summary>Ghi đè giỏ (dùng sau khi đối chiếu lại giá/tình trạng món với CSDL).</summary>
        public void Thay(Cart cart)
        {
            if (!cart.Items.Any()) XoaGioHang(); else Luu(cart);
        }

        public void CapNhatTheoKhoa(string khoa, int soLuong)
        {
            var cart = LayGioHang();
            var mon = cart.Items.FirstOrDefault(i => i.Khoa == khoa);
            if (mon == null) return;
            if (soLuong <= 0) cart.Items.Remove(mon); else mon.SoLuong = Math.Min(soLuong, SoLuongToiDa);
            Thay(cart);
        }

        public void CapNhatSoLuong(int maMonAn, int soLuong)
        {
            var cart = LayGioHang();
            var mon = cart.Items.FirstOrDefault(i => i.MaMonAn == maMonAn);
            if (mon == null) return;

            if (soLuong <= 0) cart.Items.Remove(mon);
            else mon.SoLuong = Math.Min(soLuong, SoLuongToiDa);
            Thay(cart);
        }

        /// <summary>Thay một dòng trong giỏ bằng dòng mới (đổi size/topping/ghi chú/số lượng).
        /// Nếu dòng mới trùng một dòng khác trong giỏ thì gộp số lượng. Trả null nếu thành công, ngược lại là thông báo lỗi.</summary>
        public string? ThayDong(string khoaCu, CartItem moi)
        {
            var cart = LayGioHang();
            var idx = cart.Items.FindIndex(i => i.Khoa == khoaCu);
            if (idx < 0) return "Không tìm thấy món này trong giỏ (có thể đã bị xóa).";

            var trung = cart.Items.FirstOrDefault(i => i.Khoa == moi.Khoa && i.Khoa != khoaCu);
            if (trung != null)
            {
                trung.SoLuong = Math.Min(SoLuongToiDa, trung.SoLuong + moi.SoLuong);
                cart.Items.RemoveAt(idx);
            }
            else cart.Items[idx] = moi;

            Thay(cart);
            return null;
        }
    }
}
