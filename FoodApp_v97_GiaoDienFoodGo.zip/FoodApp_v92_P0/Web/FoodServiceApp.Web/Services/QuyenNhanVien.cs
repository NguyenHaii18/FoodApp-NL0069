namespace FoodServiceApp.Web.Services
{
    /// <summary>Các quyền của nhân viên gian hàng và bảng ánh xạ đường dẫn API → quyền cần có.</summary>
    public static class QuyenNhanVien
    {
        public const string DonHang = "DonHang";       // xem/xác nhận/chuẩn bị/bàn giao đơn, mở-đóng nhận đơn, thông báo
        public const string ThucDon = "ThucDon";       // món, danh mục, tùy chọn, ảnh món
        public const string KhuyenMai = "KhuyenMai";   // mã khuyến mãi, chiến dịch
        public const string DanhGia = "DanhGia";       // xem và phản hồi đánh giá
        public const string TaiChinh = "TaiChinh";     // doanh thu, đối soát

        public static readonly string[] TatCa = { DonHang, ThucDon, KhuyenMai, DanhGia, TaiChinh };

        public static string Nhan(string quyen) => quyen switch
        {
            DonHang => "Đơn hàng", ThucDon => "Thực đơn", KhuyenMai => "Khuyến mãi", DanhGia => "Đánh giá", TaiChinh => "Tài chính",
            _ => quyen
        };

        /// <summary>Chuẩn hóa danh sách quyền gửi lên: bỏ quyền lạ, bỏ trùng, giữ thứ tự chuẩn.</summary>
        public static List<string> ChuanHoa(IEnumerable<string>? ds) =>
            TatCa.Where(q => ds?.Contains(q, StringComparer.OrdinalIgnoreCase) == true).ToList();

        public static List<string> Tach(string? csv) =>
            ChuanHoa((csv ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries));

        public static string Gop(IEnumerable<string> ds) => string.Join(",", ChuanHoa(ds));

        /// <summary>
        /// Quyền cần có để gọi đường dẫn này bằng tài khoản NHÂN VIÊN.
        /// "" = ai là nhân viên cũng gọi được (xem hồ sơ/đổi mật khẩu của chính mình); null = chỉ chủ quán
        /// (hồ sơ quán, giấy tờ, quản lý nhân viên, tài khoản, mọi đường dẫn chưa được liệt kê → mặc định từ chối).
        /// </summary>
        public static string? CanQuyen(string? duongDan)
        {
            var p = (duongDan ?? "").ToLowerInvariant();
            if (p.StartsWith("/api/mobile/nhan-vien/")) return "";
            if (p.StartsWith("/api/upload/")) return ThucDon;
            if (p.Contains("/nhan-vien")) return null;
            if (p.Contains("/don-hang") || p.Contains("/orders") || p.Contains("/thong-bao") || p.Contains("/trang-thai-kinh-doanh") ||
                p.Contains("/gio-hoat-dong") || p.Contains("/toggle-mo-cua") || p == "/api/vendor/home") return DonHang;
            if (p.Contains("/danh-gia")) return DanhGia;
            if (p.Contains("/khuyen-mai") || p.Contains("/chien-dich")) return KhuyenMai;
            if (p.Contains("/tai-chinh") || p.Contains("/doanh-thu")) return TaiChinh;
            if (p.Contains("/mon-an") || p.Contains("/menu") || p.Contains("/danh-muc") || p.Contains("/tuy-chon") || p.Contains("/thuc-don")) return ThucDon;
            return null;
        }
    }
}
