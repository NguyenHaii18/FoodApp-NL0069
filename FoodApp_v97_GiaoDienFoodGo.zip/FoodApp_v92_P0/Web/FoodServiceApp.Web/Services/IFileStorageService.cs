using Microsoft.AspNetCore.Http;

namespace FoodServiceApp.Web.Services
{
    public interface IFileStorageService
    {
        /// <summary>
        /// Lưu file vào thư mục con chỉ định (vd: "monan", "gianhang").
        /// Trả về đường dẫn URL tương đối để lưu vào CSDL.
        /// Thư mục "giayto" và "taixe-giayto" là TÀI LIỆU RIÊNG TƯ: lưu ngoài wwwroot, URL trả về dạng /files/private/...
        /// và chỉ tải được qua PrivateFileController (đã kiểm tra quyền) hoặc liên kết ký có thời hạn.
        /// </summary>
        Task<string> SaveFileAsync(IFormFile file, string subFolder);

        /// <summary>
        /// Xóa file theo đường dẫn URL tương đối đã lưu trong CSDL.
        /// </summary>
        void DeleteFile(string relativeUrl);

        /// <summary>Đường dẫn vật lý của tài liệu riêng tư (null nếu tên/thư mục không hợp lệ hoặc file không tồn tại).</summary>
        string? TimFileRiengTu(string subFolder, string fileName);
    }
}
