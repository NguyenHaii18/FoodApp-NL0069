using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Services
{
    public record KetQuaGiao(bool Ok, string ThongDiep);

    /// <summary>
    /// Luồng giao hàng dùng chung cho Web + API: xác nhận nhận hàng bằng mã 4 số, bằng chứng giao hàng,
    /// giao thất bại -> yêu cầu hoàn tiền thống nhất, và vị trí tài xế lưu bền.
    /// </summary>
    public static class GiaoHangXuLy
    {
        public const int ToiDaSaiMa = 5;
        public const int ViTriCuGiay = 90;            // quá ngưỡng này coi là vị trí "cũ"

        // Lý do lỗi do khách -> tài xế vẫn nhận phí giao, hoàn tiền trừ phí giao. Lý do khác: hoàn đủ, tài xế không nhận phí.
        private static readonly string[] LoiDoKhach = { "không liên lạc", "từ chối", "hẹn lại", "sai địa chỉ", "sai hoặc không tìm thấy địa chỉ", "không tìm thấy địa chỉ", "không có nhà", "không nghe máy" };

        // ------------------------------------------------------------------ luồng trạng thái DÙNG CHUNG (Web + API + Mobile)
        // Nhận đơn:   Đơn "DaXacNhan" (quán đang chuẩn bị) + MaTaiXe gán + GiaoHang "DaNhan"  (tài xế đang đến quán)
        // Đã lấy hàng: Đơn "DangGiao" + GiaoHang "DangGiao"                                   (đang giao cho khách)
        // Hoàn thành:  Đơn "DaGiao"  + GiaoHang "GiaoThanhCong"  |  Thất bại: Đơn "DaHuy" + GiaoHang "GiaoThatBai"

        /// <summary>Tài xế còn chuyến chưa xong (đã nhận nhưng chưa lấy hàng, hoặc đang giao).</summary>
        public static Task<bool> DangCoChuyenAsync(AppDbContext db, int maTaiXe) =>
            db.DonHangs.AnyAsync(d => d.MaTaiXe == maTaiXe && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao"));

        /// <summary>Thời hạn (phút) tài xế phản hồi đơn mới; quá hạn mà chưa ai nhận -> điều phối lại + báo quản trị.</summary>
        public const int PhutPhanHoiTaiXe = 5;

        /// <summary>Khóa cấu hình: 1 (mặc định) = đơn do QUẢN TRỊ điều phối, tài xế không tự nhận; 0 = hàng chờ chung, tài xế tự nhận.</summary>
        public const string KhoaQuanTriDieuPhoi = "Don.QuanTriDieuPhoi";

        /// <summary>Quản trị đang điều phối giao hàng? (không có cấu hình = có).</summary>
        public static async Task<bool> QuanTriDieuPhoiAsync(AppDbContext db)
        {
            try
            {
                var s = await db.CauHinhHeThongs.AsNoTracking().Where(c => c.Khoa == KhoaQuanTriDieuPhoi).Select(c => c.GiaTri).FirstOrDefaultAsync();
                return s != "0";
            }
            catch { return true; }
        }

        /// <summary>Đơn đang chờ tài xế tự nhận, đã loại các đơn tài xế này từ chối. Chỉ có dữ liệu khi quản trị TẮT chế độ điều phối (Don.QuanTriDieuPhoi = 0).</summary>
        public static IQueryable<DonHang> DonChoNhan(AppDbContext db, int maTaiXe) =>
            db.DonHangs.Where(d => d.TrangThai == "DaXacNhan" && d.MaTaiXe == null
                && db.CauHinhHeThongs.Any(c => c.Khoa == KhoaQuanTriDieuPhoi && c.GiaTri == "0")   // mặc định: quản trị điều phối, hàng chờ chung đóng
                && d.NguonGiao != "Quan"                                                  // đơn quán tự giao: không vào hàng chờ chung
                && db.TaiXes.Any(t => t.MaTaiXe == maTaiXe && t.MaGianHang == null)       // tài xế của quán không thấy hàng chờ chung
                && !db.TaiXeTuChoiDons.Any(r => r.MaDonHang == d.MaDonHang && r.MaTaiXe == maTaiXe));

        /// <summary>Tài xế từ chối đơn chờ nhận (không ảnh hưởng đơn đã nhận).</summary>
        public static async Task<KetQuaGiao> TuChoiDonAsync(AppDbContext db, TaiXe tx, int maDon, string? lyDo)
        {
            if (tx.TrangThaiDuyet != "DaDuyet") return new(false, "Hồ sơ tài xế chưa được duyệt.");
            var conCho = await db.DonHangs.AnyAsync(d => d.MaDonHang == maDon && d.TrangThai == "DaXacNhan" && d.MaTaiXe == null);
            if (!conCho) return new(false, "Đơn không còn ở trạng thái chờ tài xế nhận.");
            if (!await db.TaiXeTuChoiDons.AnyAsync(r => r.MaDonHang == maDon && r.MaTaiXe == tx.MaTaiXe))
                db.TaiXeTuChoiDons.Add(new TaiXeTuChoiDon { MaDonHang = maDon, MaTaiXe = tx.MaTaiXe, LyDo = string.IsNullOrWhiteSpace(lyDo) ? null : lyDo.Trim() });
            await db.SaveChangesAsync();
            return new(true, "Đã từ chối đơn. Đơn sẽ được chuyển cho tài xế khác.");
        }

        /// <summary>Báo đơn mới cho các tài xế đang sẵn sàng (đã duyệt, tài khoản hoạt động). Chỉ thêm vào DbContext, người gọi tự SaveChanges.</summary>
        public static async Task ThongBaoDonMoiAsync(AppDbContext db, DonHang don)
        {
            if (don.NguonGiao == "Quan") return;   // quán tự giao -> không báo shipper ngoài
            if (await QuanTriDieuPhoiAsync(db)) { await BaoQuanTriDonCanDieuPhoiAsync(db, don, true); return; }   // quản trị điều phối: báo admin, không báo shipper
            var dsTk = await db.TaiXes
                .Where(t => t.TrangThai == "SanSang" && t.TrangThaiDuyet == "DaDuyet" && t.MaGianHang == null
                    && db.TaiKhoans.Any(k => k.MaTK == t.MaTK && k.TrangThai)
                    && !db.TaiXeTuChoiDons.Any(r => r.MaDonHang == don.MaDonHang && r.MaTaiXe == t.MaTaiXe))
                .Select(t => t.MaTK).Take(50).ToListAsync();
            foreach (var maTk in dsTk)
                db.ThongBaos.Add(new ThongBao { MaTK = maTk, Loai = "DonHang", MaThamChieu = don.MaDonHang.ToString(),
                    TieuDe = "Có đơn mới chờ nhận", NoiDung = $"Đơn #{don.MaDonHang} đã sẵn sàng giao, phí giao {don.PhiGiaoHang:N0}đ. Hãy xem và nhận đơn." });
        }

        /// <summary>
        /// Chuyển đơn lên Quản trị để điều phối: báo mọi quản trị viên đang hoạt động (một lần cho mỗi đơn và mỗi loại báo).
        /// <paramref name="daSanSang"/> = quán đã báo món sẵn sàng (khẩn hơn). Chỉ thêm vào DbContext, người gọi tự SaveChanges.
        /// </summary>
        public static async Task BaoQuanTriDonCanDieuPhoiAsync(AppDbContext db, DonHang don, bool daSanSang)
        {
            if (don.NguonGiao == "Quan" || don.MaTaiXe != null) return;
            if (!await QuanTriDieuPhoiAsync(db)) return;
            var tieuDe = daSanSang ? "Đơn sẵn sàng, cần phân công tài xế" : "Đơn mới cần điều phối";
            var tc = don.MaDonHang.ToString();
            if (await db.ThongBaos.AnyAsync(t => t.MaThamChieu == tc && t.TieuDe == tieuDe)) return;
            var quan = await db.GianHangs.Where(g => g.MaGianHang == don.MaGianHang).Select(g => g.TenCuaHang).FirstOrDefaultAsync();
            var noiDung = daSanSang
                ? $"Quán {quan} đã báo đơn #{don.MaDonHang} sẵn sàng giao. Vào Điều phối để phân công tài xế."
                : $"Quán {quan} đã xác nhận đơn #{don.MaDonHang}. Vào Điều phối để phân công tài xế (tài xế không tự nhận đơn).";
            var admins = await db.TaiKhoans.Where(k => k.VaiTro == "QuanTri" && k.TrangThai).Select(k => k.MaTK).ToListAsync();
            foreach (var maTk in admins)
                db.ThongBaos.Add(new ThongBao { MaTK = maTk, Loai = "DonHang", MaThamChieu = tc, TieuDe = tieuDe, NoiDung = noiDung });
        }

        /// <summary>Số phút tài xế được chờ/phản hồi một đơn (cấu hình Don.TaiXePhanHoiPhut, mặc định 5).</summary>
        public static async Task<int> LayPhutPhanHoiAsync(AppDbContext db)
        {
            try
            {
                var s = (await db.CauHinhHeThongs.AsNoTracking().FirstOrDefaultAsync(c => c.Khoa == "Don.TaiXePhanHoiPhut"))?.GiaTri;
                return int.TryParse(s, out var v) && v >= 1 && v <= 120 ? v : PhutPhanHoiTaiXe;
            }
            catch { return PhutPhanHoiTaiXe; }
        }

        /// <summary>Đơn sẵn sàng giao quá hạn mà chưa có tài xế nhận: xóa danh sách từ chối (điều phối lại cho mọi tài xế) và báo quản trị một lần.</summary>
        public static async Task<int> XuLyQuaHanNhanDonAsync(AppDbContext db, int phut = PhutPhanHoiTaiXe)
        {
            var han = DateTime.Now.AddMinutes(-phut);
            var quaHan = await db.DonHangs
                .Where(d => d.TrangThai == "DaXacNhan" && d.MaTaiXe == null && d.NguonGiao != "Quan" && d.SanSangGiao && d.ThoiGianSanSang != null && d.ThoiGianSanSang < han)
                .Select(d => d.MaDonHang).Take(50).ToListAsync();
            if (quaHan.Count == 0) return 0;

            var quanTri = await QuanTriDieuPhoiAsync(db);
            var tieuDe = quanTri ? "Đơn quá hạn chưa được phân công tài xế" : "Đơn quá hạn chưa có tài xế nhận";
            var admins = await db.TaiKhoans.Where(k => k.VaiTro == "QuanTri" && k.TrangThai).Select(k => k.MaTK).ToListAsync();
            var xuLy = 0;
            foreach (var ma in quaHan)
            {
                var thamChieu = ma.ToString();
                if (await db.ThongBaos.AnyAsync(t => t.MaThamChieu == thamChieu && t.TieuDe == tieuDe)) continue;
                await db.TaiXeTuChoiDons.Where(r => r.MaDonHang == ma).ExecuteDeleteAsync();
                foreach (var maTk in admins)
                    db.ThongBaos.Add(new ThongBao { MaTK = maTk, Loai = "DonHang", MaThamChieu = thamChieu, TieuDe = tieuDe,
                        NoiDung = quanTri ? $"Đơn #{ma} đã sẵn sàng giao quá {phut} phút mà chưa có tài xế. Vui lòng phân công ngay." : $"Đơn #{ma} chờ tài xế quá {phut} phút. Vui lòng phân công tài xế thủ công." });
                db.DieuPhoiLogs.Add(new DieuPhoiLog { MaDonHang = ma, HanhDong = "QuaHanNhanDon", LyDo = quanTri ? $"Chưa được phân công tài xế sau {phut} phút" : $"Không có tài xế nhận trong {phut} phút" });
                xuLy++;
            }
            if (xuLy > 0) await db.SaveChangesAsync();
            return xuLy;
        }

        /// <summary>Nhận đơn: chiếm đơn bằng một câu UPDATE có điều kiện (an toàn khi 2 tài xế bấm cùng lúc).</summary>
        public static async Task<KetQuaGiao> NhanDonAsync(AppDbContext db, TaiXe tx, int maDon)
        {
            if (tx.TrangThaiDuyet != "DaDuyet") return new(false, "Hồ sơ tài xế chưa được duyệt.");
            if (tx.MaGianHang != null) return new(false, "Bạn là tài xế của quán: chỉ giao các đơn do quán gán cho bạn.");
            if (await QuanTriDieuPhoiAsync(db)) return new(false, "Đơn do Quản trị điều phối: bạn không tự nhận được. Khi được phân công, bạn sẽ nhận thông báo và đơn hiện trong chuyến hiện tại.");
            if (!await db.TaiKhoans.AnyAsync(k => k.MaTK == tx.MaTK && k.TrangThai)) return new(false, "Tài khoản tài xế đang bị khóa, không thể nhận đơn.");
            if (await DangCoChuyenAsync(db, tx.MaTaiXe)) return new(false, "Bạn đang có một chuyến giao chưa hoàn thành.");
            var maTx = (int?)tx.MaTaiXe;
            var n = await db.DonHangs.Where(d => d.MaDonHang == maDon && d.TrangThai == "DaXacNhan" && d.MaTaiXe == null && d.NguonGiao != "Quan")
                .ExecuteUpdateAsync(s => s.SetProperty(d => d.MaTaiXe, maTx));
            if (n == 0) return new(false, "Đơn đã có tài xế khác nhận hoặc không còn sẵn sàng.");

            var now = DateTime.Now;
            var gh = await db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == maDon);
            if (gh == null) db.GiaoHangs.Add(new GiaoHang { MaDonHang = maDon, MaTaiXe = tx.MaTaiXe, TrangThai = "DaNhan", ThoiGianNhan = now });
            else { gh.MaTaiXe = tx.MaTaiXe; gh.TrangThai = "DaNhan"; gh.ThoiGianNhan = now; }
            tx.TrangThai = "DangGiao";

            var maKH = await db.DonHangs.Where(d => d.MaDonHang == maDon).Select(d => d.MaKH).FirstAsync();
            var maTK = await db.KhachHangs.Where(k => k.MaKH == maKH).Select(k => (int?)k.MaTK).FirstOrDefaultAsync();
            if (maTK != null)
                db.ThongBaos.Add(new ThongBao { MaTK = maTK.Value, Loai = "DonHang", TieuDe = $"Đơn #{maDon} đã có tài xế",
                    NoiDung = $"Tài xế {tx.HoTen} đã nhận đơn và đang đến quán lấy món.", MaThamChieu = maDon.ToString() });
            await db.SaveChangesAsync();
            return new(true, "Đã nhận đơn.");
        }

        /// <summary>Quán báo tiến độ: DangChuanBi -> SanSangGiao (chỉ khi đơn DaXacNhan). Thông báo cho tài xế (nếu đã nhận) và khách.</summary>
        public static async Task<KetQuaGiao> DoiChuanBiAsync(AppDbContext db, DonHang don, string buoc)
        {
            if (don.TrangThai != "DaXacNhan") return new(false, "Chỉ báo chuẩn bị khi đơn đã xác nhận và chưa giao.");
            if (buoc == "DangChuanBi")
            {
                if (don.TrangThaiChuanBi != null) return new(false, "Đơn đã ở bước chuẩn bị hoặc sẵn sàng.");
                don.TrangThaiChuanBi = "DangChuanBi";
            }
            else if (buoc == "SanSangGiao")
            {
                if (don.TrangThaiChuanBi == "SanSangGiao") return new(true, "Đơn đã báo sẵn sàng giao.");
                don.TrangThaiChuanBi = "SanSangGiao"; don.SanSangGiao = true; don.ThoiGianSanSang = DateTime.Now;
            }
            else return new(false, "Bước không hợp lệ.");

            var maTkKhach = await db.KhachHangs.Where(k => k.MaKH == don.MaKH).Select(k => (int?)k.MaTK).FirstOrDefaultAsync();
            if (maTkKhach != null)
                db.ThongBaos.Add(new ThongBao { MaTK = maTkKhach.Value, Loai = "DonHang", MaThamChieu = don.MaDonHang.ToString(),
                    TieuDe = buoc == "DangChuanBi" ? "Quán đang chuẩn bị món" : "Món đã sẵn sàng",
                    NoiDung = buoc == "DangChuanBi" ? $"Quán đang chuẩn bị đơn #{don.MaDonHang}." : $"Đơn #{don.MaDonHang} đã xong, đang chờ tài xế lấy." });
            if (buoc == "SanSangGiao" && don.MaTaiXe != null)
            {
                var maTkTx = await db.TaiXes.Where(t => t.MaTaiXe == don.MaTaiXe).Select(t => (int?)t.MaTK).FirstOrDefaultAsync();
                if (maTkTx != null)
                    db.ThongBaos.Add(new ThongBao { MaTK = maTkTx.Value, Loai = "DonHang", MaThamChieu = don.MaDonHang.ToString(), TieuDe = "Món đã sẵn sàng", NoiDung = $"Quán báo đơn #{don.MaDonHang} đã sẵn sàng, bạn có thể lấy hàng." });
            }
            if (buoc == "SanSangGiao" && don.MaTaiXe == null) await ThongBaoDonMoiAsync(db, don);
            await db.SaveChangesAsync();
            return new(true, buoc == "DangChuanBi" ? "Đã báo đang chuẩn bị món." : "Đã báo sẵn sàng giao.");
        }

        /// <summary>Quán xác nhận đã bàn giao món cho tài xế (đồng thời coi như món đã sẵn sàng).</summary>
        public static async Task<KetQuaGiao> BanGiaoAsync(AppDbContext db, DonHang don)
        {
            if (don.TrangThai != "DaXacNhan" || don.MaTaiXe == null) return new(false, "Đơn chưa có tài xế nhận hoặc không ở bước chờ lấy hàng.");
            var gh = await db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == don.MaDonHang && g.MaTaiXe == don.MaTaiXe);
            if (gh == null) return new(false, "Không tìm thấy chuyến giao.");
            if (don.TrangThaiChuanBi != "SanSangGiao") { don.TrangThaiChuanBi = "SanSangGiao"; don.SanSangGiao = true; don.ThoiGianSanSang = DateTime.Now; }
            gh.QuanBanGiaoLuc ??= DateTime.Now;
            var maTkTx = await db.TaiXes.Where(t => t.MaTaiXe == don.MaTaiXe).Select(t => (int?)t.MaTK).FirstOrDefaultAsync();
            if (maTkTx != null)
                db.ThongBaos.Add(new ThongBao { MaTK = maTkTx.Value, Loai = "DonHang", MaThamChieu = don.MaDonHang.ToString(), TieuDe = "Quán đã bàn giao món", NoiDung = $"Quán xác nhận bàn giao đơn #{don.MaDonHang}. Hãy kiểm tra món rồi bấm \"Đã lấy hàng\"." });
            await db.SaveChangesAsync();
            return new(true, "Đã xác nhận bàn giao món cho tài xế.");
        }

        /// <summary>Tài xế báo đã đến quán (chỉ ghi nhận mốc thời gian).</summary>
        public static async Task<KetQuaGiao> DenQuanAsync(AppDbContext db, DonHang don, GiaoHang gh)
        {
            if (don.TrangThai != "DaXacNhan" || gh.TrangThai != "DaNhan") return new(false, "Đơn không ở bước đến quán.");
            gh.ThoiGianDenQuan ??= DateTime.Now;
            await db.SaveChangesAsync();
            return new(true, "Đã ghi nhận bạn đến quán.");
        }

        /// <summary>Đã lấy hàng -> bắt đầu giao (đơn chuyển sang DangGiao; khách thấy mã xác nhận nhận hàng).</summary>
        public static async Task<KetQuaGiao> DaLayHangAsync(AppDbContext db, DonHang don, GiaoHang gh, string? maDonNhap = null)
        {
            if (don.TrangThai == "DangGiao" && gh.TrangThai == "DangGiao") return new(true, "Đơn đã ở trạng thái đang giao.");
            if (don.TrangThai != "DaXacNhan" || gh.TrangThai != "DaNhan")
                return new(false, "Đơn không ở bước chờ lấy hàng.");
            // Điều kiện nhận món: quán đã báo "Sẵn sàng giao" hoặc đã bấm "Đã bàn giao". Mặc định BẬT (v16);
            // đặt cấu hình "Don.BatBuocSanSangGiao" = 0 để tắt (tương thích app quán cũ không báo sẵn sàng).
            var batBuoc = await db.CauHinhHeThongs.AsNoTracking().Where(c => c.Khoa == "Don.BatBuocSanSangGiao").Select(c => c.GiaTri).FirstOrDefaultAsync();
            if (batBuoc != "0" && don.TrangThaiChuanBi != "SanSangGiao" && gh.QuanBanGiaoLuc == null)
                return new(false, "Gian hàng chưa báo món sẵn sàng giao, vui lòng chờ hoặc báo quán chuẩn bị chậm.");
            // Kiểm tra mã đơn khi nhận món: nếu có nhập thì phải khớp; cấu hình "Don.BatBuocMaDonKhiLayHang" = 1 thì bắt buộc nhập.
            if (!string.IsNullOrWhiteSpace(maDonNhap))
            {
                if (maDonNhap.Trim().TrimStart('#') != don.MaDonHang.ToString())
                    return new(false, "Mã đơn không khớp, hãy kiểm tra lại túi/hóa đơn tại quán (có thể bạn đang nhận nhầm đơn).");
            }
            else
            {
                var batMa = await db.CauHinhHeThongs.AsNoTracking().Where(c => c.Khoa == "Don.BatBuocMaDonKhiLayHang").Select(c => c.GiaTri).FirstOrDefaultAsync();
                if (batMa == "1") return new(false, "Vui lòng nhập mã đơn trên túi/hóa đơn để xác nhận đã nhận món.");
            }
            don.TrangThai = "DangGiao"; gh.TrangThai = "DangGiao"; gh.ThoiGianLayHang = DateTime.Now;
            gh.ThoiGianDenQuan ??= gh.ThoiGianLayHang;
            if (string.IsNullOrEmpty(don.MaXacNhanGiao)) don.MaXacNhanGiao = TaoMa();
            await db.SaveChangesAsync();
            return new(true, "Đã lấy hàng, bắt đầu giao.");
        }

        /// <summary>Trả đơn về hàng chờ khi tài xế bị gỡ/đổi: giải phóng tài xế cũ nếu không còn chuyến khác.</summary>
        public static async Task GiaiPhongTaiXeAsync(AppDbContext db, int? maTaiXeCu, int boQuaDon)
        {
            if (maTaiXeCu == null) return;
            var con = await db.DonHangs.AnyAsync(d => d.MaTaiXe == maTaiXeCu && d.MaDonHang != boQuaDon && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao"));
            if (con) return;
            var tx = await db.TaiXes.FirstOrDefaultAsync(t => t.MaTaiXe == maTaiXeCu);
            if (tx != null && tx.TrangThai == "DangGiao") tx.TrangThai = "SanSang";
        }

        public static string TaoMa() => RandomNumberGenerator.GetInt32(1000, 10000).ToString();

        public static bool LoiDoKhachHang(string lyDo) =>
            LoiDoKhach.Any(k => (lyDo ?? "").Contains(k, StringComparison.OrdinalIgnoreCase));

        private static bool BangNhau(string a, string b) =>
            CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(a), Encoding.UTF8.GetBytes(b));

        /// <summary>Hoàn thành giao hàng: bắt buộc đúng mã khách đọc (đơn cũ không có mã thì bắt buộc có ảnh bằng chứng).</summary>
        public static async Task<KetQuaGiao> HoanThanhAsync(AppDbContext db, DonHang don, GiaoHang gh, TaiXe tx, string? maNhap, double? lat, double? lng)
        {
            if (don.TrangThai != "DangGiao" || gh.TrangThai != "DangGiao")
                return new(false, "Đơn chưa ở trạng thái đang giao (hãy bấm đã lấy hàng trước) hoặc đã được xử lý.");

            if (!string.IsNullOrEmpty(don.MaXacNhanGiao))
            {
                if (don.SoLanSaiMa >= ToiDaSaiMa)
                    return new(false, "Nhập sai mã quá nhiều lần, đơn bị khóa xác nhận. Liên hệ Quản trị để được hỗ trợ.");
                if (string.IsNullOrWhiteSpace(maNhap) || !BangNhau(maNhap.Trim(), don.MaXacNhanGiao))
                {
                    don.SoLanSaiMa++;
                    await db.SaveChangesAsync();
                    var con = ToiDaSaiMa - don.SoLanSaiMa;
                    return new(false, con > 0 ? $"Mã xác nhận không đúng (còn {con} lần thử)." : "Nhập sai mã quá nhiều lần, đơn bị khóa xác nhận. Liên hệ Quản trị.");
                }
            }
            else if (string.IsNullOrEmpty(gh.AnhBangChung))
                return new(false, "Đơn này không có mã xác nhận: cần chụp ảnh bằng chứng giao hàng trước khi hoàn thành.");

            var now = DateTime.Now;
            don.TrangThai = "DaGiao";
            gh.TrangThai = "GiaoThanhCong"; gh.ThoiGianGiao = now; gh.ViDoGiao = lat; gh.KinhDoGiao = lng;
            if (don.ThanhToan != null && don.ThanhToan.TrangThai != "DaThanhToan" && don.ThanhToan.HinhThuc == "TienMat")
            {
                don.ThanhToan.TrangThai = "DaThanhToan"; don.ThanhToan.NgayThanhToan = now;
                gh.TienThuCOD = don.TongTien;
            }
            tx.TrangThai = "SanSang";
            await db.SaveChangesAsync();
            return new(true, "Đã xác nhận giao thành công.");
        }

        /// <summary>
        /// Giao thất bại thống nhất: đơn -> DaHuy; phí tài xế theo lý do (server tự phân loại, không tin cờ từ client);
        /// đơn đã trả online -> tạo YeuCauHoanTien (ChoDuyet) để đi qua quy trình duyệt + hoàn tiền thật qua cổng.
        /// </summary>
        public static async Task<KetQuaGiao> ThatBaiAsync(AppDbContext db, DonHang don, GiaoHang gh, TaiXe tx, string? lyDo, double? lat, double? lng)
        {
            lyDo = (lyDo ?? "").Trim();
            if (lyDo.Length < 3) return new(false, "Nhập lý do giao thất bại.");
            if (don.TrangThai is not ("DaXacNhan" or "DangGiao") || gh.TrangThai is not ("DangGiao" or "DaNhan"))
                return new(false, "Đơn không ở trạng thái có thể báo giao thất bại.");

            var loiKhach = LoiDoKhachHang(lyDo);
            gh.TrangThai = "GiaoThatBai"; gh.ThoiGianGiao = DateTime.Now; gh.ViDoGiao = lat; gh.KinhDoGiao = lng;
            gh.LyDoThatBai = lyDo; gh.TinhPhiThatBai = loiKhach; gh.NguoiGayLoi = loiKhach ? "KhachHang" : "Khac";
            don.TrangThai = "DaHuy";
            don.GhiChu = string.IsNullOrWhiteSpace(don.GhiChu) ? $"Giao thất bại: {lyDo}" : $"{don.GhiChu} | Giao thất bại: {lyDo}";
            tx.TrangThai = "SanSang";

            string tbHoan = "";
            var tt = don.ThanhToan;
            if (tt != null && tt.HinhThuc != "TienMat" && tt.TrangThai == "DaThanhToan")
            {
                var soTien = loiKhach ? Math.Max(0, don.TongTien - don.PhiGiaoHang) : don.TongTien;
                var daCo = await db.YeuCauHoanTiens.AnyAsync(y => y.MaDonHang == don.MaDonHang && (y.TrangThai == "ChoDuyet" || y.TrangThai == "DaDuyet"));
                if (soTien > 0 && !daCo)
                {
                    db.YeuCauHoanTiens.Add(new YeuCauHoanTien
                    {
                        MaDonHang = don.MaDonHang, MaKH = don.MaKH, SoTien = soTien, Nguon = "GiaoThatBai",
                        LyDo = "Giao thất bại: " + lyDo + (loiKhach ? " (lỗi phía khách: giữ lại phí giao)" : ""),
                    });
                    tbHoan = $" Yêu cầu hoàn {soTien:N0}đ đã được tạo và đang chờ duyệt.";
                }
            }
            var maTK = await db.KhachHangs.Where(k => k.MaKH == don.MaKH).Select(k => (int?)k.MaTK).FirstOrDefaultAsync();
            if (maTK != null)
                db.ThongBaos.Add(new ThongBao { MaTK = maTK.Value, Loai = "DonHang", TieuDe = $"Đơn #{don.MaDonHang} giao không thành công",
                    NoiDung = $"Lý do: {lyDo}." + tbHoan, MaThamChieu = don.MaDonHang.ToString() });
            await db.SaveChangesAsync();
            return new(true, "Đã ghi nhận giao thất bại." + tbHoan);
        }

        // ------------------------------------------------------------------ vị trí tài xế
        /// <summary>Lưu vị trí (chặn cập nhật dồn dập và bước nhảy phi thực tế > 150 km/h).</summary>
        public static async Task<KetQuaGiao> LuuViTriAsync(AppDbContext db, int maDon, int maTaiXe, double lat, double lng)
        {
            var now = DateTime.Now;
            var cu = await db.TaiXeViTris.FirstOrDefaultAsync(v => v.MaDonHang == maDon);
            if (cu != null)
            {
                var giay = (now - cu.CapNhatLuc).TotalSeconds;
                if (giay < 2) return new(true, "Bỏ qua (cập nhật quá dày).");
                var km = KhoangCachKm(cu.ViDo, cu.KinhDo, lat, lng);
                if (giay < 120 && km / (giay / 3600.0) > 150) return new(false, "Vị trí nhảy bất thường, bỏ qua.");
                cu.ViDo = lat; cu.KinhDo = lng; cu.CapNhatLuc = now; cu.MaTaiXe = maTaiXe;
            }
            else db.TaiXeViTris.Add(new TaiXeViTri { MaDonHang = maDon, MaTaiXe = maTaiXe, ViDo = lat, KinhDo = lng, CapNhatLuc = now });
            await db.SaveChangesAsync();
            return new(true, "OK");
        }

        public static double KhoangCachKm(double la1, double lo1, double la2, double lo2)
        {
            const double R = 6371;
            double d(double x) => x * Math.PI / 180;
            var a = Math.Pow(Math.Sin(d(la2 - la1) / 2), 2) + Math.Cos(d(la1)) * Math.Cos(d(la2)) * Math.Pow(Math.Sin(d(lo2 - lo1) / 2), 2);
            return 2 * R * Math.Asin(Math.Sqrt(a));
        }
    }
}
