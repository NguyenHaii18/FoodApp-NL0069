using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace FoodServiceApp.Web.Services
{
    /// <summary>
    /// Suy ra loại gian hàng (com, ga, bun, tra, pizza, banh, nhat, cafe, che) từ tên quán, tên danh mục và tên món.
    /// Khớp với bộ lọc danh mục ở trang chủ app MAUI. Một quán có thể thuộc nhiều loại nên kết quả là chuỗi
    /// "com,tra"; quán không khớp loại nào trả "" (vẫn hiện ở "Tất cả"). Không cần thêm cột vào CSDL.
    /// </summary>
    public static class PhanLoaiGianHang
    {
        // Từ khóa đã bỏ dấu, viết thường; so khớp theo ranh giới từ.
        private static readonly (string Ma, Regex Re)[] Luat = new[]
        {
            ("com",   "com|com tam|suon|bo luc lac|thit kho"),
            ("ga",    "ga|ga ran|chicken|canh ga|dui ga"),
            ("bun",   "bun|pho|hu tieu|mien|banh canh|mi quang|mi|nui"),
            ("tra",   "tra sua|tra|tran chau|sinh to|nuoc ep|matcha"),
            ("pizza", "pizza|pasta|burger|hamburger|spaghetti"),
            ("banh",  "banhmi|sandwich|bread"),
            ("nhat",  "sushi|sashimi|ramen|udon|nhat|bento|takoyaki|tempura"),
            ("cafe",  "ca phe|cafe|coffee|espresso|cappuccino|latte"),
            ("che",   "che|kem|sua chua|rau cau|flan|trang mieng"),
        }.Select(x => (x.Item1, new Regex($@"(?<![a-z0-9])({x.Item2})(?![a-z0-9])", RegexOptions.Compiled))).ToArray();

        public static string BoDau(string? s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "";
            var d = s.Trim().ToLowerInvariant().Replace('đ', 'd').Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder(d.Length);
            foreach (var c in d)
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                    sb.Append(char.IsLetterOrDigit(c) ? c : ' ');
            return Regex.Replace(sb.ToString(), @"\s+", " ").Trim();
        }

        public static string Tinh(string? tenQuan, IEnumerable<string?> tenDanhMucVaMon)
        {
            // "banh mi" gộp thành một từ để không bị tính là "mi" (nhóm bún/phở/mì)
            var van = (BoDau(tenQuan) + " " + string.Join(' ', tenDanhMucVaMon.Select(BoDau))).Replace("banh mi", "banhmi");
            var ra = Luat.Where(l => l.Re.IsMatch(van)).Select(l => l.Ma);
            return string.Join(',', ra);
        }
    }
}
