namespace FoodServiceApp.Web.Services
{
    /// <summary>
    /// Hash và kiểm tra mật khẩu bằng BCrypt. <see cref="Khop"/> chỉ chấp nhận hash BCrypt (tiền tố "$2");
    /// mật khẩu lưu dạng rõ KHÔNG còn được chấp nhận — Program.cs tự chuyển chúng sang BCrypt khi khởi động.
    /// </summary>
    public static class MatKhauHelper
    {
        public static string Hash(string matKhauGoc) => BCrypt.Net.BCrypt.HashPassword(matKhauGoc);

        public static bool Khop(string matKhauNhap, string matKhauLuu)
        {
            if (string.IsNullOrEmpty(matKhauLuu)) return false;

            // Hash BCrypt luôn có dạng "$2a$", "$2b$" hoặc "$2y$" ở đầu.
            if (matKhauLuu.StartsWith("$2"))
            {
                try { return BCrypt.Net.BCrypt.Verify(matKhauNhap, matKhauLuu); }
                catch { return false; } // hash lỗi định dạng -> coi như không khớp thay vì crash
            }

            // Không chấp nhận mật khẩu lưu dạng rõ. Tài khoản cũ được tự chuyển sang BCrypt lúc khởi động (Program.cs);
            // dòng nào vẫn còn plaintext (vừa chèn tay vào SQL) sẽ không đăng nhập được cho đến khi khởi động lại ứng dụng.
            return false;
        }
    }
}
