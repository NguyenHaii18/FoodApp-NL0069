using System.Data.Common;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using FoodServiceApp.Web.Data;

namespace FoodServiceApp.Web.Services
{
    /// <summary>
    /// <c>Database.EnsureCreated()</c> chỉ tạo CSDL khi CHƯA tồn tại; nó KHÔNG bổ sung bảng/cột vào CSDL cũ và dự án chưa dùng EF Migrations.
    /// Khi mã nguồn thêm cột/bảng mà CSDL cũ chưa có, website vẫn khởi động nhưng truy vấn lỗi lúc chạy.
    /// Lớp này so sánh mô hình EF với CSDL thật (chỉ ĐỌC, không sửa gì) và trả về danh sách bảng/cột còn thiếu
    /// để hiện cảnh báo rõ ràng (log lúc khởi động + thanh đỏ ở trang quản trị) thay vì để lỗi xuất hiện rải rác.
    /// Cách sửa: sao lưu CSDL rồi chạy Database/FoodService_NangCap.sql (chạy lại nhiều lần được, không xóa dữ liệu).
    /// </summary>
    public static class KiemTraSchema
    {
        private static IReadOnlyList<string> _loi = Array.Empty<string>();

        /// <summary>Các bảng/cột mô hình EF cần nhưng CSDL chưa có (rỗng = khớp, hoặc chưa kiểm tra được).</summary>
        public static IReadOnlyList<string> Loi => _loi;
        public static DateTime? LucKiemTra { get; private set; }
        /// <summary>Thông báo nếu không kiểm tra được (vd. không kết nối SQL Server); null nếu kiểm tra bình thường.</summary>
        public static string? KhongKiemTraDuoc { get; private set; }

        public static async Task<IReadOnlyList<string>> KiemTraAsync(AppDbContext db)
        {
            var loi = new List<string>();
            try
            {
                // Bảng -> tập tên cột đang có trong CSDL thật
                var coSan = new Dictionary<string, HashSet<string>>(StringComparer.OrdinalIgnoreCase);
                await db.Database.OpenConnectionAsync();
                try
                {
                    using DbCommand cmd = db.Database.GetDbConnection().CreateCommand();
                    cmd.CommandText = "SELECT TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS";
                    using var rd = await cmd.ExecuteReaderAsync();
                    while (await rd.ReadAsync())
                    {
                        var khoa = rd.GetString(0) + "." + rd.GetString(1);
                        if (!coSan.TryGetValue(khoa, out var cot)) coSan[khoa] = cot = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                        cot.Add(rd.GetString(2));
                    }
                }
                finally { await db.Database.CloseConnectionAsync(); }

                foreach (var et in db.Model.GetEntityTypes())
                {
                    var bang = et.GetTableName();
                    if (bang == null) continue;                       // thực thể không ánh xạ ra bảng
                    var schema = et.GetSchema() ?? "dbo";
                    if (!coSan.TryGetValue(schema + "." + bang, out var cot))
                    {
                        loi.Add($"Thiếu bảng {bang}");
                        continue;
                    }
                    var id = StoreObjectIdentifier.Table(bang, et.GetSchema());
                    foreach (var p in et.GetProperties())
                    {
                        var tenCot = p.GetColumnName(id);
                        if (tenCot != null && !cot.Contains(tenCot)) loi.Add($"Thiếu cột {bang}.{tenCot}");
                    }
                }
                KhongKiemTraDuoc = null;
            }
            catch (Exception ex)
            {
                // Không để việc kiểm tra làm hỏng khởi động (vd. SQL Server chưa chạy)
                KhongKiemTraDuoc = ex.Message;
            }
            _loi = loi.Distinct().OrderBy(x => x).ToList();
            LucKiemTra = DateTime.Now;
            return _loi;
        }
    }
}
