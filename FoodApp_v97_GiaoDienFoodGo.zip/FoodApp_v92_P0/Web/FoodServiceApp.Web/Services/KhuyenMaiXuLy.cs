using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Services
{
    public record DongGioKm(int MaMonAn, int MaDanhMuc, decimal Gia, int SoLuong);
    public record KetQuaKhuyenMai(KhuyenMai? Km, decimal Giam, string? Loi);

    /// <summary>
    /// Điểm duy nhất kiểm tra + tính mã khuyến mãi cho API (MobileApi, CustomerApi). Cùng luật với giỏ hàng Web:
    /// thời hạn, bật/tắt, gian hàng/món/danh mục áp dụng, đơn tối thiểu, tổng lượt dùng, mỗi khách một lần,
    /// giảm tối đa; loại GiamPhiVanChuyen chỉ giảm vào phí giao. Mã sai -> trả lỗi (không im lặng bỏ qua).
    /// </summary>
    public static class KhuyenMaiXuLy
    {
        /// <summary>Mã đổi từ điểm thưởng là mã CÁ NHÂN: MoTa = "DOIDIEM|{maKH}|{điểm đã đổi}". Trả mã khách sở hữu, null nếu là mã thường.</summary>
        public const string TienToDoiDiem = "DOIDIEM|";
        public static int? ChuMaDoiDiem(KhuyenMai km)
        {
            if (km.MoTa == null || !km.MoTa.StartsWith(TienToDoiDiem, StringComparison.Ordinal)) return null;
            var p = km.MoTa.Split('|');
            return p.Length >= 2 && int.TryParse(p[1], out var ma) ? ma : -1;
        }

        public static async Task<KetQuaKhuyenMai> TinhAsync(AppDbContext db, string? ma, int maGianHang, int maKH, IReadOnlyList<DongGioKm> dong, decimal phiGiao)
        {
            if (string.IsNullOrWhiteSpace(ma)) return new(null, 0, null);
            var maCode = ma.Trim().ToUpper();
            var now = DateTime.Now;
            var km = await db.KhuyenMais.FirstOrDefaultAsync(k =>
                k.MaCode == maCode && k.TrangThai && (k.MaGianHang == null || k.MaGianHang == maGianHang) &&
                now >= k.NgayBatDau && now <= k.NgayKetThuc);
            if (km == null) return new(null, 0, "Mã khuyến mãi không hợp lệ, đã hết hạn, hoặc không áp dụng cho gian hàng này.");

            var chu = ChuMaDoiDiem(km);
            if (chu != null && chu != maKH) return new(null, 0, "Mã khuyến mãi không hợp lệ, đã hết hạn, hoặc không áp dụng cho gian hàng này.");   // mã đổi điểm của khách khác: không lộ là có tồn tại

            var dsQuan = await db.KhuyenMaiGianHangs.Where(x => x.MaKhuyenMai == km.MaKhuyenMai).Select(x => x.MaGianHang).ToListAsync();
            if (dsQuan.Count > 0 && !dsQuan.Contains(maGianHang)) return new(null, 0, "Mã này không áp dụng cho gian hàng đã chọn.");

            var tongMon = dong.Sum(x => x.Gia * x.SoLuong);
            if (tongMon < km.GiaTriDonToiThieu) return new(null, 0, $"Đơn tối thiểu {km.GiaTriDonToiThieu:N0}đ mới dùng được mã này.");
            if (km.SoLuongToiDa != null && km.SoLuongDaDung >= km.SoLuongToiDa) return new(null, 0, "Mã khuyến mãi đã hết lượt sử dụng.");
            if (km.MoiKhachMotLan && await db.KhuyenMaiKhachDungs.AnyAsync(x => x.MaKhuyenMai == km.MaKhuyenMai && x.MaKH == maKH))
                return new(null, 0, "Bạn đã dùng mã này rồi (mỗi khách chỉ dùng một lần).");

            var loiGioiHan = await KiemTraGioiHanKhachAsync(db, km, maKH);
            if (loiGioiHan != null) return new(null, 0, loiGioiHan);

            var dsMon = await db.KhuyenMaiMonAns.Where(x => x.MaKhuyenMai == km.MaKhuyenMai).Select(x => x.MaMonAn).ToListAsync();
            var dsDm = await db.KhuyenMaiDanhMucs.Where(x => x.MaKhuyenMai == km.MaKhuyenMai).Select(x => x.MaDanhMuc).ToListAsync();
            var coSo = tongMon;
            if (dsMon.Count > 0 || dsDm.Count > 0)
            {
                coSo = dong.Where(x => dsMon.Contains(x.MaMonAn) || dsDm.Contains(x.MaDanhMuc)).Sum(x => x.Gia * x.SoLuong);
                if (coSo <= 0) return new(null, 0, "Giỏ hàng không có món nào thuộc diện áp dụng của mã này.");
            }

            decimal giam;
            if (km.LoaiGiam == "GiamPhiVanChuyen")
                giam = Math.Min(km.SoTienGiam is null or 0 ? phiGiao : km.SoTienGiam.Value, phiGiao);
            else
            {
                giam = km.PhanTramGiam != null ? Math.Round(coSo * km.PhanTramGiam.Value / 100) : (km.SoTienGiam ?? 0);
                if (km.GiamToiDa != null) giam = Math.Min(giam, km.GiamToiDa.Value);
                giam = Math.Min(giam, coSo);
            }
            return new(km, Math.Max(0, giam), null);
        }

        public const int NgayTinhGioiHanKhach = 30;

        /// <summary>
        /// Giới hạn "Voucher.ToiDaMoiKhach" (trang Cài đặt phí & chính sách): một khách dùng cùng một mã tối đa N lần trong 30 ngày.
        /// 0 = không giới hạn. Trả về thông báo lỗi, hoặc null nếu còn được dùng.
        /// </summary>
        public static async Task<string?> KiemTraGioiHanKhachAsync(AppDbContext db, KhuyenMai km, int maKH)
        {
            var toiDa = (int)await new CauHinhService(db).LaySoAsync("Voucher.ToiDaMoiKhach", 5);
            if (toiDa <= 0) return null;
            var tu = DateTime.Now.AddDays(-NgayTinhGioiHanKhach);
            var daDung = await db.KhuyenMaiKhachDungs.CountAsync(x => x.MaKhuyenMai == km.MaKhuyenMai && x.MaKH == maKH && x.NgaySuDung >= tu);
            return daDung >= toiDa ? $"Bạn đã dùng mã này {daDung} lần trong {NgayTinhGioiHanKhach} ngày (tối đa {toiDa} lần)." : null;
        }

        /// <summary>Giữ chỗ 1 lượt dùng một cách nguyên tử (không vượt SoLuongToiDa dù nhiều người đặt cùng lúc). false = đã hết lượt.</summary>
        public static async Task<bool> GiuLuotAsync(AppDbContext db, KhuyenMai km)
        {
            var n = await db.KhuyenMais
                .Where(k => k.MaKhuyenMai == km.MaKhuyenMai && (k.SoLuongToiDa == null || k.SoLuongDaDung < k.SoLuongToiDa))
                .ExecuteUpdateAsync(s => s.SetProperty(k => k.SoLuongDaDung, k => k.SoLuongDaDung + 1));
            return n > 0;
        }

        /// <summary>v51: trả lại lượt đã giữ khi đơn không được tạo (yêu cầu gửi lặp chạy song song) — mã giảm giá không bị trừ hai lần cho cùng một yêu cầu.</summary>
        public static Task<int> TraLuotAsync(AppDbContext db, KhuyenMai km) =>
            db.KhuyenMais.Where(k => k.MaKhuyenMai == km.MaKhuyenMai && k.SoLuongDaDung > 0)
                .ExecuteUpdateAsync(s => s.SetProperty(k => k.SoLuongDaDung, k => k.SoLuongDaDung - 1));

        /// <summary>Ghi nhận khách đã dùng mã cho đơn (chưa SaveChanges).</summary>
        public static void GhiNhan(AppDbContext db, KhuyenMai km, int maKH, int maDon) =>
            db.KhuyenMaiKhachDungs.Add(new KhuyenMaiKhachDung { MaKhuyenMai = km.MaKhuyenMai, MaKH = maKH, MaDonHang = maDon });
    }
}
