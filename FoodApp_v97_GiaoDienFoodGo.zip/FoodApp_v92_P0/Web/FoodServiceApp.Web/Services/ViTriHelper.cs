namespace FoodServiceApp.Web.Services
{
    /// <summary>Khoảng cách theo đường chim bay (Haversine) + ước tính đường đi, phí và thời gian giao cho màn tìm kiếm.</summary>
    public static class ViTriHelper
    {
        private const double HeSoDuongDi = 1.25; // đường thực tế dài hơn đường chim bay ~25% trong đô thị

        public static bool HopLe(double? lat, double? lng) =>
            lat is >= -90 and <= 90 && lng is >= -180 and <= 180 && !(lat == 0 && lng == 0);

        public static double KmChimBay(double lat1, double lng1, double lat2, double lng2)
        {
            const double R = 6371.0;
            double Rad(double d) => d * Math.PI / 180.0;
            var dLat = Rad(lat2 - lat1); var dLng = Rad(lng2 - lng1);
            var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                    Math.Cos(Rad(lat1)) * Math.Cos(Rad(lat2)) * Math.Sin(dLng / 2) * Math.Sin(dLng / 2);
            return R * 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
        }

        /// <summary>Km ước tính theo đường đi (làm tròn 0,1).</summary>
        public static double KmDuongDi(double lat1, double lng1, double lat2, double lng2) =>
            Math.Round(KmChimBay(lat1, lng1, lat2, lng2) * HeSoDuongDi, 1);

        /// <summary>Phí giao ước tính — cùng công thức với giỏ hàng: làm tròn lên km × phí mỗi km.</summary>
        public static decimal PhiUocTinh(double km, decimal phiMoiKm) => Math.Max(1, (decimal)Math.Ceiling(km)) * phiMoiKm;

        /// <summary>Thời gian dự kiến: ~12 phút chuẩn bị + ~4 phút/km; trả về khoảng "x–y phút".</summary>
        public static string ThoiGianUocTinh(double km)
        {
            var tb = 12 + km * 4;
            var tu = (int)(Math.Round(tb / 5.0) * 5);
            return $"{Math.Max(15, tu)}–{Math.Max(15, tu) + 10} phút";
        }
    }
}
