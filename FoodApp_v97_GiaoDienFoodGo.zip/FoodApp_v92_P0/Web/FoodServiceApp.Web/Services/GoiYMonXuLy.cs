using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Services
{
    public sealed record GoiYMonDto(int MaMonAn, string TenMon, decimal Gia, string? HinhAnh, int MaGianHang, string TenGianHang, string LyDo, double Diem, string NhomGio);

    /// <summary>
    /// v55 — Gợi ý món cá nhân hóa (mô hình gợi ý lai, giải thích được; KHÔNG phải mạng nơ-ron):
    ///  • sở thích của khách: nhóm món và quán đã đặt, giảm dần theo thời gian (bán rã 30 ngày), mức giá quen dùng;
    ///  • lọc cộng tác theo món: "người đặt món bạn từng đặt cũng đặt món này" (độ tương đồng cosine trên các đơn của toàn hệ thống);
    ///  • bối cảnh: món được đặt nhiều gần đây, hợp khung giờ hiện tại (sáng / trưa / chiều / tối / khuya);
    ///  • chất lượng: điểm đánh giá quán và món.
    /// Khách chưa có lịch sử → dùng bộ trọng số "khởi đầu lạnh" (phổ biến + khung giờ + đánh giá).
    /// Chỉ gợi ý món còn bán của quán đã duyệt, đang mở và nhận đơn; tối đa 2 món / quán và 3 món / nhóm để danh sách đa dạng.
    /// </summary>
    public static class GoiYMonXuLy
    {
        private const double BanRaNgay = 30;
        private const int CuaSoNgay = 180;

        public static string NhomGio(int gio) => gio switch
        {
            >= 5 and < 10 => "sáng",
            >= 10 and < 14 => "trưa",
            >= 14 and < 17 => "chiều",
            >= 17 and < 22 => "tối",
            _ => "khuya",
        };

        private sealed record Dong(int MaKH, int MaDon, int MaMon, string Nhom, int MaQuan, DateTime Ngay, int SoLuong, decimal Gia);

        public static async Task<List<GoiYMonDto>> TinhAsync(AppDbContext db, int? maKH, DateTime bayGio, int top = 8)
        {
            var tu = bayGio.AddDays(-CuaSoNgay);
            var dong = await (from c in db.ChiTietDonHangs.AsNoTracking()
                              join d in db.DonHangs.AsNoTracking() on c.MaDonHang equals d.MaDonHang
                              join m in db.MonAns.AsNoTracking() on c.MaMonAn equals m.MaMonAn
                              where d.TrangThai == "DaGiao" && d.NgayDat >= tu
                              select new Dong(d.MaKH, d.MaDonHang, c.MaMonAn, m.DanhMuc!.TenDanhMuc, d.MaGianHang, d.NgayDat, c.SoLuong, c.DonGia)).ToListAsync();

            var quanTot = await db.GianHangs.AsNoTracking()
                .Where(g => g.TrangThaiDuyet == "DaDuyet" && g.TrangThaiKinhDoanh == "DangMo" && g.DangNhanDon)
                .Select(g => new { g.MaGianHang, g.TenCuaHang }).ToDictionaryAsync(g => g.MaGianHang, g => g.TenCuaHang);
            var idQuan = quanTot.Keys.ToList();
            var ungVien = await db.MonAns.AsNoTracking().Include(m => m.DanhMuc)
                .Where(m => m.TinhTrang == "ConHang" && (m.LyDoAn == null || m.LyDoAn == "") && m.DanhMuc != null && !m.DanhMuc.DaAn && idQuan.Contains(m.DanhMuc.MaGianHang))
                .ToListAsync();
            if (ungVien.Count == 0) return new();

            var saoQuan = await db.DanhGias.AsNoTracking().Where(x => !x.DaAn).GroupBy(x => x.MaGianHang)
                .Select(g => new { g.Key, Tb = g.Average(x => (double)x.SoSao), So = g.Count() }).ToDictionaryAsync(x => x.Key, x => (x.Tb, x.So));
            var saoMon = await db.DanhGiaMons.AsNoTracking().GroupBy(x => x.MaMonAn)
                .Select(g => new { g.Key, Tb = g.Average(x => (double)x.SoSao), So = g.Count() }).ToDictionaryAsync(x => x.Key, x => (x.Tb, x.So));

            // ---- thống kê toàn hệ thống
            var gio = NhomGio(bayGio.Hour);
            var moc30 = bayGio.AddDays(-30);
            var soDonMon = dong.GroupBy(x => x.MaMon).ToDictionary(g => g.Key, g => g.Select(x => x.MaDon).Distinct().Count());
            var pho30 = dong.Where(x => x.Ngay >= moc30).GroupBy(x => x.MaMon).ToDictionary(g => g.Key, g => g.Select(x => x.MaDon).Distinct().Count());
            var trongGio = dong.Where(x => NhomGio(x.Ngay.Hour) == gio).GroupBy(x => x.MaMon).ToDictionary(g => g.Key, g => g.Select(x => x.MaDon).Distinct().Count());
            var maxPho = Math.Max(1, pho30.Values.DefaultIfEmpty(0).Max());

            // ---- sở thích khách
            var nhomKh = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
            var quanKh = new Dictionary<int, double>();
            var daDat = new Dictionary<int, int>();
            var giaKh = new List<decimal>();
            var monKh = new Dictionary<int, double>();
            if (maKH != null)
                foreach (var x in dong.Where(x => x.MaKH == maKH.Value))
                {
                    var w = x.SoLuong * Math.Pow(0.5, (bayGio - x.Ngay).TotalDays / BanRaNgay);
                    nhomKh[x.Nhom] = nhomKh.GetValueOrDefault(x.Nhom) + w;
                    quanKh[x.MaQuan] = quanKh.GetValueOrDefault(x.MaQuan) + w;
                    monKh[x.MaMon] = monKh.GetValueOrDefault(x.MaMon) + w;
                    daDat[x.MaMon] = daDat.GetValueOrDefault(x.MaMon) + 1;
                    giaKh.Add(x.Gia);
                }
            var coLichSu = monKh.Count > 0;
            var maxNhom = Math.Max(1e-9, nhomKh.Values.DefaultIfEmpty(0).Max());
            var maxQuan = Math.Max(1e-9, quanKh.Values.DefaultIfEmpty(0).Max());
            var giaTrungVi = giaKh.Count == 0 ? 0m : giaKh.OrderBy(x => x).ElementAt(giaKh.Count / 2);

            // ---- đồng xuất hiện (cosine) giữa món khách đã đặt và món ứng viên: mỗi "giỏ" = các món cùng khách đã đặt (toàn lịch sử khách)
            var gio2 = dong.GroupBy(x => x.MaKH).Select(g => g.Select(x => x.MaMon).Distinct().ToList()).ToList();
            var dem = new Dictionary<int, int>();
            var cap = new Dictionary<(int, int), int>();
            foreach (var gioHang in gio2)
            {
                foreach (var a in gioHang) dem[a] = dem.GetValueOrDefault(a) + 1;
                if (gioHang.Count > 40) continue;
                for (var i = 0; i < gioHang.Count; i++)
                    for (var j = 0; j < gioHang.Count; j++)
                        if (i != j) cap[(gioHang[i], gioHang[j])] = cap.GetValueOrDefault((gioHang[i], gioHang[j])) + 1;
            }
            double Cosine(int a, int b) => cap.TryGetValue((a, b), out var n) && dem.TryGetValue(a, out var da) && dem.TryGetValue(b, out var db2) ? n / Math.Sqrt((double)da * db2) : 0;

            var diem = new List<(MonAn M, double D, List<(double V, string Ly)> Phan)>();
            foreach (var m in ungVien)
            {
                var maQuan = m.DanhMuc!.MaGianHang;
                var nhom = m.DanhMuc.TenDanhMuc;
                var pho = pho30.GetValueOrDefault(m.MaMonAn) / (double)maxPho;
                var tong = soDonMon.GetValueOrDefault(m.MaMonAn);
                var hopGio = (trongGio.GetValueOrDefault(m.MaMonAn) + 0.2) / (tong + 1.0);      // làm mượt để món ít đơn không bị nhiễu
                var sq = saoQuan.TryGetValue(maQuan, out var q) ? (q.Tb * q.So + 4.0 * 3) / (q.So + 3) / 5.0 : 0.8;
                var sm = saoMon.TryGetValue(m.MaMonAn, out var s) ? (s.Tb * s.So + 4.0 * 3) / (s.So + 3) / 5.0 : 0.8;

                var phan = new List<(double V, string Ly)>();
                double d;
                if (coLichSu)
                {
                    var cn = nhomKh.TryGetValue(nhom, out var vn) ? vn / maxNhom : 0;
                    var cq = quanKh.TryGetValue(maQuan, out var vq) ? vq / maxQuan : 0;
                    double cs = 0, tongW = 0;
                    foreach (var (mk, w) in monKh.OrderByDescending(x => x.Value).Take(12)) { if (mk == m.MaMonAn) continue; cs += w * Cosine(mk, m.MaMonAn); tongW += w; }
                    cs = tongW > 0 ? Math.Min(1, cs / tongW * 3) : 0;
                    var gia = giaTrungVi > 0 && m.Gia > 0 ? Math.Clamp(1 - Math.Abs(Math.Log((double)(m.Gia / giaTrungVi))) / Math.Log(3), 0, 1) : 0.5;
                    d = 0.22 * cn + 0.12 * cq + 0.22 * cs + 0.12 * pho + 0.10 * hopGio + 0.07 * gia + 0.10 * sq + 0.05 * sm;
                    var nd = daDat.GetValueOrDefault(m.MaMonAn);
                    if (nd >= 3) { d += 0.05; phan.Add((0.9, "Món bạn hay đặt")); }
                    else if (nd >= 1) d -= 0.08;          // đã thử rồi: hạ nhẹ để có món mới
                    else d += 0.03;                       // món chưa thử
                    phan.Add((cn * 0.22, $"Bạn hay chọn nhóm “{nhom}”"));
                    phan.Add((cq * 0.12, "Từ quán bạn hay đặt"));
                    phan.Add((cs * 0.22, "Người đặt món giống bạn cũng chọn"));
                    phan.Add((gia * 0.07, "Giá hợp mức bạn hay chi"));
                }
                else d = 0.40 * pho + 0.25 * hopGio + 0.25 * sq + 0.10 * sm;
                phan.Add((pho * 0.12, "Đang được đặt nhiều"));
                phan.Add((hopGio * 0.10, $"Hợp bữa {gio}"));
                phan.Add((sq * 0.10, "Quán được đánh giá cao"));
                diem.Add((m, d, phan));
            }

            // ---- chọn top có đa dạng
            var kq = new List<GoiYMonDto>();
            var theoQuan = new Dictionary<int, int>();
            var theoNhom = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var (m, d, phan) in diem.OrderByDescending(x => x.D))
            {
                var maQuan = m.DanhMuc!.MaGianHang; var nhom = m.DanhMuc.TenDanhMuc;
                if (theoQuan.GetValueOrDefault(maQuan) >= 2 || theoNhom.GetValueOrDefault(nhom) >= 3) continue;
                theoQuan[maQuan] = theoQuan.GetValueOrDefault(maQuan) + 1; theoNhom[nhom] = theoNhom.GetValueOrDefault(nhom) + 1;
                var ly = string.Join(" · ", phan.Where(p => p.V > 0.03).OrderByDescending(p => p.V).Take(2).Select(p => p.Ly));
                kq.Add(new GoiYMonDto(m.MaMonAn, m.TenMon, m.Gia, m.HinhAnh, maQuan, quanTot[maQuan], ly == "" ? "Quán được đánh giá cao" : ly, Math.Round(d, 3), gio));
                if (kq.Count >= top) break;
            }
            return kq;
        }
    }
}
