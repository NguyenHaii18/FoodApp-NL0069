using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Services
{
    /// <summary>
    /// Điểm duy nhất tạo yêu cầu hoàn tiền khi một đơn đã thanh toán online bị hủy.
    /// KHÔNG tự đổi ThanhToan sang "DaHoanTien": chỉ Quản trị duyệt (gọi API VNPay hoặc nhập mã hoàn thủ công) mới được làm việc đó.
    /// </summary>
    public static class HoanTienXuLy
    {
        /// <summary>Tạo yêu cầu (chưa SaveChanges). Trả về câu thông báo cho người dùng, hoặc null nếu không cần hoàn.</summary>
        public static async Task<string?> TaoYeuCauKhiHuyAsync(AppDbContext db, DonHang don, string nguon, string lyDo, decimal? soTien = null)
        {
            var tt = don.ThanhToan ?? await db.ThanhToans.FirstOrDefaultAsync(t => t.MaDonHang == don.MaDonHang);
            if (tt == null || tt.TrangThai != "DaThanhToan" || tt.HinhThuc == "TienMat") return null;
            var tien = soTien ?? don.TongTien;
            if (tien <= 0) return null;
            var daCo = await db.YeuCauHoanTiens.AnyAsync(y => y.MaDonHang == don.MaDonHang && (y.TrangThai == "ChoDuyet" || y.TrangThai == "DaDuyet"))
                       || db.ChangeTracker.Entries<YeuCauHoanTien>().Any(e => e.State == EntityState.Added && e.Entity.MaDonHang == don.MaDonHang);
            if (daCo) return null;
            db.YeuCauHoanTiens.Add(new YeuCauHoanTien
            {
                MaDonHang = don.MaDonHang, MaKH = don.MaKH, SoTien = tien, Nguon = nguon,
                LyDo = lyDo.Length > 400 ? lyDo[..400] : lyDo
            });
            return $"Đã tạo yêu cầu hoàn {tien:N0}đ, đang chờ quản trị duyệt.";
        }
    }
}
