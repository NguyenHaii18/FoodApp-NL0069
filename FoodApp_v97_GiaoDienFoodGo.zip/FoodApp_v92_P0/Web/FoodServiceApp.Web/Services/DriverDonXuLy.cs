using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Dtos;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Services
{
    /// <summary>Quản lý đơn giao của tài xế: danh sách theo nhóm + chi tiết đơn (dùng chung Web, API, Mobile).</summary>
    public static class DriverDonXuLy
    {
        /// <summary>Nhóm: nhan (đã nhận, đang đến quán) | dang-giao | hoan-thanh | that-bai (giao thất bại hoặc đơn bị hủy).</summary>
        public static IQueryable<DonHang> Tab(AppDbContext db, int maTaiXe, string? tab)
        {
            var q = db.DonHangs.Where(d => d.GiaoHang != null && d.GiaoHang.MaTaiXe == maTaiXe);
            return tab switch
            {
                "dang-giao" => q.Where(d => d.GiaoHang!.TrangThai == "DangGiao"),
                "hoan-thanh" => q.Where(d => d.GiaoHang!.TrangThai == "GiaoThanhCong"),
                "that-bai" => q.Where(d => d.GiaoHang!.TrangThai == "GiaoThatBai"),
                _ => q.Where(d => d.GiaoHang!.TrangThai == "DaNhan"),
            };
        }

        /// <summary>Sự cố tại quán khi lấy món.</summary>
        public static readonly Dictionary<string, string> LoaiLayMon = new()
        {
            ["QuanChuanBiCham"] = "Quán chuẩn bị chậm",
            ["KhongTimThayDon"] = "Không tìm thấy đơn tại quán",
            ["SaiMon"] = "Sai món",
            ["ThieuMon"] = "Thiếu món",
            ["VanDeBanGiao"] = "Vấn đề bàn giao tại quán",
        };

        /// <summary>Tài xế báo sự cố khi lấy món (API/Mobile): lưu sự cố, báo gian hàng và quản trị.</summary>
        public static async Task<KetQuaGiao> BaoSuCoLayMonAsync(AppDbContext db, TaiXe tx, int maDon, string? loai, string? moTa)
        {
            if (loai == null || !LoaiLayMon.ContainsKey(loai)) return new(false, "Loại sự cố không hợp lệ.");
            var don = await db.DonHangs.Include(d => d.GianHang)
                .FirstOrDefaultAsync(d => d.MaDonHang == maDon && d.MaTaiXe == tx.MaTaiXe && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao"));
            if (don == null) return new(false, "Đơn không thuộc chuyến đang thực hiện của bạn.");

            var mo = string.IsNullOrWhiteSpace(moTa) ? LoaiLayMon[loai] : moTa.Trim();
            db.SuCoGiaoHangs.Add(new SuCoGiaoHang { MaTaiXe = tx.MaTaiXe, MaDonHang = maDon, Loai = loai, MoTa = mo });
            var tieuDe = "Tài xế báo: " + LoaiLayMon[loai];
            var noiDung = $"{tx.HoTen} báo đơn #{maDon}: {mo}";
            if (don.GianHang != null)
                db.ThongBaos.Add(new ThongBao { MaTK = don.GianHang.MaTK, Loai = "DonHang", MaThamChieu = maDon.ToString(), TieuDe = tieuDe, NoiDung = noiDung });
            var admins = await db.QuanTris.AsNoTracking().Select(q => q.MaTK).Take(50).ToListAsync();
            foreach (var maTk in admins)
                db.ThongBaos.Add(new ThongBao { MaTK = maTk, Loai = "HeThong", MaThamChieu = maDon.ToString(), TieuDe = tieuDe, NoiDung = noiDung });
            await db.SaveChangesAsync();
            return new(true, "Đã gửi báo cáo cho gian hàng và quản trị.");
        }

        /// <summary>Tài xế tạo báo cáo sự cố / sai lệch bất kỳ (Web + Mobile): lưu, báo quản trị (và gian hàng nếu là sự cố lấy món).</summary>
        public static async Task<KetQuaGiao> TaoSuCoAsync(AppDbContext db, TaiXe tx, string? loai, string? moTa, int? maDon, string? anh = null)
        {
            var loais = FoodServiceApp.Web.Controllers.DriverSuCoController.Loais;
            if (loai == null || !loais.ContainsKey(loai)) return new(false, "Loại sự cố không hợp lệ.");
            moTa = (moTa ?? "").Trim();
            if (moTa.Length < 5) return new(false, "Vui lòng mô tả sự cố (ít nhất 5 ký tự).");
            if (maDon != null && !await db.GiaoHangs.AnyAsync(g => g.MaDonHang == maDon && g.MaTaiXe == tx.MaTaiXe))
                return new(false, "Đơn này không thuộc về bạn.");

            db.SuCoGiaoHangs.Add(new SuCoGiaoHang { MaTaiXe = tx.MaTaiXe, MaDonHang = maDon, Loai = loai, MoTa = moTa, AnhMinhChung = anh });
            var tieuDe = "Tài xế báo sự cố: " + loais[loai];
            var noiDung = $"{tx.HoTen} báo{(maDon != null ? $" (đơn #{maDon})" : "")}: {moTa}";
            var admins = await db.QuanTris.AsNoTracking().Select(q => q.MaTK).Take(50).ToListAsync();
            foreach (var maTk in admins)
                db.ThongBaos.Add(new ThongBao { MaTK = maTk, Loai = "HeThong", TieuDe = tieuDe, NoiDung = noiDung, MaThamChieu = maDon?.ToString() });
            if (maDon != null && LoaiLayMon.ContainsKey(loai))
            {
                var maTkQuan = await db.DonHangs.Where(d => d.MaDonHang == maDon).Select(d => (int?)d.GianHang!.MaTK).FirstOrDefaultAsync();
                if (maTkQuan != null)
                    db.ThongBaos.Add(new ThongBao { MaTK = maTkQuan.Value, Loai = "DonHang", MaThamChieu = maDon.ToString(), TieuDe = "Tài xế báo: " + loais[loai], NoiDung = $"{tx.HoTen} báo đơn #{maDon}: {moTa}" });
            }
            await db.SaveChangesAsync();
            return new(true, "Đã gửi báo cáo. Quản trị sẽ xử lý và phản hồi trong mục Sự cố.");
        }

        /// <summary>Tài xế đổi CCCD / GPLX / ảnh GPLX: báo quản trị xem lại (chưa SaveChanges — người gọi lưu).</summary>
        public static async Task BaoQuanTriDoiGiayToAsync(AppDbContext db, TaiXe tx)
        {
            var admins = await db.QuanTris.AsNoTracking().Select(q => q.MaTK).Take(50).ToListAsync();
            foreach (var maTk in admins)
                db.ThongBaos.Add(new ThongBao { MaTK = maTk, Loai = "HeThong", TieuDe = "Tài xế cập nhật giấy tờ", NoiDung = $"{tx.HoTen} (#{tx.MaTaiXe}) vừa cập nhật CCCD/GPLX. Vui lòng kiểm tra lại hồ sơ.", MaThamChieu = tx.MaTaiXe.ToString() });
        }

        public record CodChoNopDong(int MaDonHang, DateTime? ThoiGianGiao, decimal SoTien);

        /// <summary>Các đơn tài xế đã thu COD nhưng quản trị chưa xác nhận nhận tiền nộp lại (mới nhất trước).</summary>
        public static async Task<List<CodChoNopDong>> CodChuaNopAsync(AppDbContext db, int maTaiXe)
        {
            var ds = await db.GiaoHangs.AsNoTracking()
                .Where(g => g.MaTaiXe == maTaiXe && g.TienThuCOD > 0 && g.CodDaNopLuc == null)
                .OrderByDescending(g => g.ThoiGianGiao).Take(200)
                .Select(g => new { g.MaDonHang, g.ThoiGianGiao, g.TienThuCOD }).ToListAsync();
            return ds.Select(g => new CodChoNopDong(g.MaDonHang, g.ThoiGianGiao, g.TienThuCOD ?? 0)).ToList();
        }

        public static string NhanThanhToan(string? trangThai) => trangThai switch
        {
            "DaThanhToan" => "Đã thanh toán",
            "ChoThanhToan" => "Chưa thanh toán",
            null or "" => "—",
            _ => trangThai,
        };

        public static string AnSdt(string? sdt)
        {
            if (string.IsNullOrWhiteSpace(sdt)) return "";
            var s = sdt.Trim();
            return s.Length <= 3 ? "***" : new string('*', s.Length - 3) + s.Substring(s.Length - 3);
        }

        /// <summary>Đơn thu hộ: thanh toán tiền mặt và chưa ghi nhận đã thanh toán.</summary>
        public static bool LaCod(DonHang d) => d.ThanhToan != null && d.ThanhToan.HinhThuc == "TienMat" && d.ThanhToan.TrangThai != "DaThanhToan";

        public static async Task<List<DriverOrderListItemDto>> DanhSachAsync(AppDbContext db, int maTaiXe, string? tab)
        {
            var ds = await Tab(db, maTaiXe, tab).AsNoTracking()
                .Include(d => d.GianHang).Include(d => d.ThanhToan).Include(d => d.GiaoHang)
                .OrderByDescending(d => d.NgayDat).Take(100).ToListAsync();
            return ds.Select(d => new DriverOrderListItemDto(
                d.MaDonHang, d.TrangThai, d.GiaoHang?.TrangThai ?? "", d.NgayDat,
                d.GianHang?.TenCuaHang ?? "", d.GianHang?.DiaChi ?? "", d.DiaChiGiaoHang,
                d.TongTien, d.PhiGiaoHang, LaCod(d), NhanThanhToan(d.ThanhToan?.TrangThai))).ToList();
        }

        /// <summary>Chi tiết đơn; chỉ trả về nếu đơn thuộc chuyến của tài xế này.</summary>
        public static async Task<DriverOrderDetailDto?> ChiTietAsync(AppDbContext db, int maTaiXe, int maDon)
        {
            var d = await db.DonHangs.AsNoTracking()
                .Include(x => x.GianHang).Include(x => x.KhachHang).Include(x => x.ThanhToan)
                .Include(x => x.ChiTiets).ThenInclude(c => c.MonAn).Include(x => x.GiaoHang)
                .FirstOrDefaultAsync(x => x.MaDonHang == maDon && x.GiaoHang != null && x.GiaoHang.MaTaiXe == maTaiXe);
            if (d == null) return null;

            var gh = d.GiaoHang!;
            var dangThucHien = gh.TrangThai == "DaNhan" || gh.TrangThai == "DangGiao";
            var cod = LaCod(d);
            var sdtKhach = d.KhachHang?.SDT;
            var hinhThuc = d.ThanhToan == null ? "—" : d.ThanhToan.HinhThuc == "TienMat" ? "Tiền mặt (COD)" : d.ThanhToan.HinhThuc;
            var lyDo = !string.IsNullOrWhiteSpace(gh.LyDoThatBai) ? gh.LyDoThatBai : (d.TrangThai == "DaHuy" ? d.LyDoTuChoi : null);

            return new DriverOrderDetailDto(
                d.MaDonHang, d.TrangThai, gh.TrangThai, d.NgayDat,
                d.GianHang?.TenCuaHang ?? "", d.GianHang?.DiaChi ?? "", d.GianHang?.SDT,
                d.KhachHang?.HoTen ?? "", dangThucHien ? sdtKhach : AnSdt(sdtKhach), dangThucHien,
                d.DiaChiGiaoHang, d.GhiChu,
                d.TongTien, d.PhiGiaoHang,
                hinhThuc, NhanThanhToan(d.ThanhToan?.TrangThai), cod, cod && dangThucHien ? d.TongTien : 0, gh.TienThuCOD,
                lyDo,
                d.ChiTiets.Select(c => new ChiTietDonHangDto(c.MonAn?.TenMon ?? "", c.SoLuong, c.DonGia, c.ThanhTien)).ToList());
        }
    }
}
