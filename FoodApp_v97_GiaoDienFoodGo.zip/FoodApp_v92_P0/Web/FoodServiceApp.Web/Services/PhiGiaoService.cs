using System.Globalization;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Services
{
    /// <summary>Bộ tham số tính phí giao hàng + tỷ lệ chia tiền, đọc từ bảng CauHinhHeThong (admin chỉnh được).</summary>
    public sealed record CauHinhPhiGiao(
        decimal PhiCoBan,            // phí cho KmCoBan km đầu
        double KmCoBan,              // số km đầu tính theo phí cơ bản
        decimal PhiMoiKm,            // mỗi km vượt (làm tròn lên từng km)
        decimal PhuPhiNgoaiThanh,    // cộng thêm khi giao ra vùng ngoại thành
        decimal CaoDiemPhanTram,     // 0..1, phụ phí giờ cao điểm trên (cơ bản + vượt km)
        string KhungCaoDiem,         // "10:30-13:00;17:00-20:00"
        decimal MuaPhanTram,         // 0..1, phụ phí khi mưa lớn
        bool DangMua,                // admin bật tay khi trời mưa lớn (chưa nối API thời tiết)
        decimal PhiToiThieu,
        decimal PhiToiDa,
        decimal PhiMacDinh,          // dùng khi không xác định được khoảng cách
        decimal LamTron,             // làm tròn LÊN tới bội số này (0 hoặc 1 = không làm tròn)
        decimal TyLeTaiXe);          // 0..1 phần phí giao tài xế nhận; phần còn lại là của ứng dụng

    /// <summary>Chi tiết một lần tính phí (để hiển thị cho admin/khách và để đối chiếu với bảng tính).</summary>
    public sealed record KetQuaPhiGiao(
        decimal PhiCoBan, decimal PhiVuotKm, decimal PhuPhiNgoaiThanh,
        decimal PhuPhiCaoDiem, decimal PhuPhiMua, decimal PhiGoc, decimal Phi,
        bool CaoDiem, bool Mua, bool ChamToiThieu, bool ChamToiDa);

    public static class PhiGiaoService
    {
        public static readonly CauHinhPhiGiao MacDinh = new(
            PhiCoBan: 12000m, KmCoBan: 2, PhiMoiKm: 4000m, PhuPhiNgoaiThanh: 10000m,
            CaoDiemPhanTram: 0.20m, KhungCaoDiem: "10:30-13:00;17:00-20:00", MuaPhanTram: 0.15m, DangMua: false,
            PhiToiThieu: 12000m, PhiToiDa: 70000m, PhiMacDinh: 15000m, LamTron: 1000m, TyLeTaiXe: 0.80m);

        private static decimal So(Dictionary<string, string> d, string khoa, decimal macDinh, decimal min, decimal max)
        {
            if (d.TryGetValue(khoa, out var s)
                && decimal.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out var v) && v >= min && v <= max) return v;
            return macDinh;
        }

        /// <summary>Đọc cấu hình từ CSDL. Lỗi/thiếu khóa/giá trị sai → dùng mặc định (không bao giờ ném lỗi, để đặt đơn không bị chặn).</summary>
        public static async Task<CauHinhPhiGiao> DocAsync(AppDbContext db)
        {
            try
            {
                var ds = await db.CauHinhHeThongs.AsNoTracking()
                    .Where(c => c.Khoa.StartsWith("Giao.") || c.Khoa.StartsWith("ChiaTien."))
                    .ToDictionaryAsync(c => c.Khoa, c => c.GiaTri);
                var m = MacDinh;
                var toiThieu = So(ds, "Giao.PhiToiThieu", m.PhiToiThieu, 0, 1000000);
                var toiDa = So(ds, "Giao.PhiToiDa", m.PhiToiDa, 0, 10000000);
                if (toiDa < toiThieu) toiDa = toiThieu;
                return new CauHinhPhiGiao(
                    PhiCoBan: So(ds, "Giao.PhiCoBan", m.PhiCoBan, 0, 1000000),
                    KmCoBan: (double)So(ds, "Giao.KmCoBan", (decimal)m.KmCoBan, 0, 50),
                    PhiMoiKm: So(ds, "Giao.PhiMoiKm", m.PhiMoiKm, 0, 1000000),
                    PhuPhiNgoaiThanh: So(ds, "Giao.PhuPhiNgoaiThanh", m.PhuPhiNgoaiThanh, 0, 1000000),
                    CaoDiemPhanTram: So(ds, "Giao.CaoDiemPhanTram", m.CaoDiemPhanTram, 0, 1),
                    KhungCaoDiem: ds.TryGetValue("Giao.CaoDiemKhungGio", out var kg) && KiemTraKhungGio(kg) == null ? kg : m.KhungCaoDiem,
                    MuaPhanTram: So(ds, "Giao.MuaPhanTram", m.MuaPhanTram, 0, 1),
                    DangMua: So(ds, "Giao.DangMua", 0, 0, 1) == 1,
                    PhiToiThieu: toiThieu,
                    PhiToiDa: toiDa,
                    PhiMacDinh: So(ds, "Giao.PhiMacDinh", m.PhiMacDinh, 0, 1000000),
                    LamTron: So(ds, "Giao.LamTron", m.LamTron, 0, 10000),
                    TyLeTaiXe: So(ds, "ChiaTien.TyLeTaiXe", m.TyLeTaiXe, 0, 1));
            }
            catch { return MacDinh; }
        }

        /// <summary>Phân tích khung giờ "HH:mm-HH:mm;HH:mm-HH:mm" (dấu ; hoặc , phân cách). Trả null nếu hợp lệ, ngược lại là thông báo lỗi.</summary>
        public static string? KiemTraKhungGio(string? s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "Khung giờ không được để trống (vd 10:30-13:00;17:00-20:00).";
            return TachKhung(s, out _) ? null : "Sai định dạng. Dùng HH:mm-HH:mm, nhiều khung cách nhau dấu ; (vd 10:30-13:00;17:00-20:00).";
        }

        private static bool TachKhung(string s, out List<(TimeSpan Tu, TimeSpan Den)> ds)
        {
            ds = new List<(TimeSpan, TimeSpan)>();
            foreach (var phan in s.Split(new[] { ';', ',' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            {
                var hai = phan.Split('-', StringSplitOptions.TrimEntries);
                if (hai.Length != 2
                    || !TimeSpan.TryParseExact(hai[0], new[] { "h\\:mm", "hh\\:mm" }, CultureInfo.InvariantCulture, out var tu)
                    || !TimeSpan.TryParseExact(hai[1], new[] { "h\\:mm", "hh\\:mm" }, CultureInfo.InvariantCulture, out var den)
                    || tu >= TimeSpan.FromHours(24) || den > TimeSpan.FromHours(24)) return false;
                ds.Add((tu, den));
            }
            return ds.Count > 0;
        }

        /// <summary>Thời điểm <paramref name="luc"/> có nằm trong khung giờ cao điểm không (hỗ trợ khung qua nửa đêm, vd 22:00-02:00).</summary>
        public static bool LaCaoDiem(string khung, DateTime luc)
        {
            if (!TachKhung(khung, out var ds)) return false;
            var t = luc.TimeOfDay;
            foreach (var (tu, den) in ds)
                if (tu <= den ? t >= tu && t <= den : t >= tu || t <= den) return true;
            return false;
        }

        /// <summary>Công thức phí giao: max(tối thiểu, cơ bản + vượt km + ngoại thành + %cao điểm + %mưa), làm tròn lên, không vượt tối đa.</summary>
        public static KetQuaPhiGiao Tinh(CauHinhPhiGiao c, double km, DateTime luc, bool ngoaiThanh, bool? mua = null)
        {
            var vuot = km <= c.KmCoBan ? 0m : (decimal)Math.Ceiling(km - c.KmCoBan) * c.PhiMoiKm;
            var goc = c.PhiCoBan + vuot;
            var caoDiem = c.CaoDiemPhanTram > 0 && LaCaoDiem(c.KhungCaoDiem, luc);
            var coMua = mua ?? c.DangMua;
            var pCaoDiem = caoDiem ? Math.Round(goc * c.CaoDiemPhanTram, 0, MidpointRounding.AwayFromZero) : 0m;
            var pMua = coMua ? Math.Round(goc * c.MuaPhanTram, 0, MidpointRounding.AwayFromZero) : 0m;
            var pNgoai = ngoaiThanh ? c.PhuPhiNgoaiThanh : 0m;
            var tong = goc + pNgoai + pCaoDiem + pMua;
            var chamThieu = tong < c.PhiToiThieu;
            if (chamThieu) tong = c.PhiToiThieu;
            if (c.LamTron > 1) tong = Math.Ceiling(tong / c.LamTron) * c.LamTron;
            var chamDa = tong > c.PhiToiDa;
            if (chamDa) tong = c.PhiToiDa;
            return new KetQuaPhiGiao(c.PhiCoBan, vuot, pNgoai, pCaoDiem, pMua, goc + pNgoai + pCaoDiem + pMua, tong, caoDiem, coMua, chamThieu, chamDa);
        }


        /// <summary>Kết quả tính phí cho một đơn: phí khách trả + dữ liệu để lưu vào đơn.</summary>
        public sealed record PhiDon(decimal Phi, double Km, int Phut, bool NgoaiThanh, bool CoKhoangCach, decimal TyLeTaiXe, KetQuaPhiGiao? ChiTiet);

        /// <summary>Tính phí theo địa chỉ thật (Goong) bằng cấu hình admin. Không xác định được khoảng cách → phí mặc định (Giao.PhiMacDinh). Không bao giờ ném lỗi.</summary>
        public static async Task<PhiDon> TinhTheoDiaChiAsync(AppDbContext db, Maps.IGoongMapsService maps, string diaChiLay, string diaChiGiao, DateTime? luc = null)
        {
            var c = await DocAsync(db);
            try
            {
                var a = await maps.GeocodeAsync(diaChiLay);
                var b = await maps.GeocodeAsync(diaChiGiao);
                var kc = (a == null || b == null) ? null : await maps.GetDistanceAsync(a, b);
                if (kc == null) return new PhiDon(c.PhiMacDinh, 0, 0, false, false, c.TyLeTaiXe, null);
                var ngoai = LaNgoaiThanh(diaChiGiao);
                var kq = Tinh(c, kc.DistanceKm, luc ?? DateTime.Now, ngoai);
                return new PhiDon(kq.Phi, kc.DistanceKm, kc.DurationMinutes, ngoai, true, c.TyLeTaiXe, kq);
            }
            catch { return new PhiDon(c.PhiMacDinh, 0, 0, false, false, c.TyLeTaiXe, null); }
        }

        /// <summary>Địa chỉ thuộc vùng ngoại thành (cộng phụ phí khu vực).</summary>
        public static bool LaNgoaiThanh(string diaChi)
        {
            var s = BoDau(diaChi ?? "").ToLowerInvariant();
            return s.Contains("cu chi") || s.Contains("hoc mon") || s.Contains("binh chanh") || s.Contains("nha be") || s.Contains("can gio");
        }

        private static string BoDau(string text)
        {
            var n = text.Normalize(System.Text.NormalizationForm.FormD);
            var sb = new System.Text.StringBuilder(n.Length);
            foreach (var ch in n)
                if (CharUnicodeInfo.GetUnicodeCategory(ch) != UnicodeCategory.NonSpacingMark) sb.Append(ch);
            return sb.ToString().Normalize(System.Text.NormalizationForm.FormC).Replace('đ', 'd').Replace('Đ', 'D');
        }

        /// <summary>Danh sách khóa cấu hình phí giao + chia tiền (admin chỉnh).</summary>
        public static readonly string[] CacKhoa =
        {
            "Giao.PhiCoBan", "Giao.KmCoBan", "Giao.PhiMoiKm", "Giao.PhuPhiNgoaiThanh", "Giao.CaoDiemPhanTram", "Giao.CaoDiemKhungGio",
            "Giao.MuaPhanTram", "Giao.DangMua", "Giao.PhiToiThieu", "Giao.PhiToiDa", "Giao.PhiMacDinh", "Giao.LamTron", "ChiaTien.TyLeTaiXe"
        };

        /// <summary>Phí giao tài xế nhận theo tỷ lệ chốt trên đơn (NULL = đơn cũ: nhận 100%).</summary>
        public static decimal TienTaiXe(decimal phiGiao, decimal? tyLeTaiXe)
            => Math.Round(phiGiao * Math.Clamp(tyLeTaiXe ?? 1m, 0m, 1m), 0, MidpointRounding.AwayFromZero);

        /// <summary>Phần phí giao ứng dụng giữ lại.</summary>
        public static decimal TienApp(decimal phiGiao, decimal? tyLeTaiXe) => phiGiao - TienTaiXe(phiGiao, tyLeTaiXe);
    }
}
