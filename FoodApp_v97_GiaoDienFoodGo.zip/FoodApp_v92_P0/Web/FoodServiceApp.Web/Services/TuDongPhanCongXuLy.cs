using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Services
{
    /// <summary>
    /// Tự động phân công tài xế CHẠY NỀN trên máy chủ (không cần app quản trị đang mở).
    /// Điều kiện: bật cấu hình "DieuPhoi.TuDong" = 1 và hệ thống đang ở chế độ quản trị điều phối.
    /// Đơn: quán đã xác nhận + báo sẵn sàng + chưa có tài xế + không phải quán tự giao.
    /// Tài xế: đã duyệt, tài khoản mở, trạng thái "SanSang", không thuộc riêng quán nào; ưu tiên đúng khu vực hoạt động, rồi ít đơn đang giữ nhất.
    /// Mỗi tài xế nhận tối đa 1 đơn mỗi lượt (như phân công tay: nhận đơn xong chuyển sang "DangGiao"). Ghi DieuPhoiLog + thông báo như thao tác tay.
    /// </summary>
    public static class TuDongPhanCongXuLy
    {
        public const string KhoaCauHinh = "DieuPhoi.TuDong";
        public static DateTime? LanChayCuoi { get; private set; }
        public static int TongDaPhanCong { get; private set; }
        public static string KetQuaCuoi { get; private set; } = "Chưa chạy lần nào.";
        private static readonly SemaphoreSlim _khoa = new(1, 1);

        public static async Task<bool> DangBatAsync(CauHinhService cauHinh) => await cauHinh.LayChuoiAsync(KhoaCauHinh, "0") == "1";

        public static async Task<(int DaPhanCong, string TomTat)> ChayAsync(AppDbContext db, int? maTK, string lyDoGoc = "Tự động phân công (máy chủ)")
        {
            if (!await _khoa.WaitAsync(0)) return (0, "Đang có lượt chạy khác.");
            try
            {
                if (!await GiaoHangXuLy.QuanTriDieuPhoiAsync(db)) return Ghi(0, "Hệ thống đang ở chế độ hàng chờ chung (tài xế tự nhận) nên không cần phân công.");
                if (await PhanPhoiDonXuLy.DangBatAsync(db)) return Ghi(0, "Đang dùng bộ máy phân phối đề nghị có thời hạn (PhanPhoi.TuDong = 1) nên không chạy phân công tức thì kiểu cũ.");

                var donCho = await db.DonHangs.Include(d => d.GianHang)
                    .Where(d => d.TrangThai == "DaXacNhan" && d.MaTaiXe == null && d.SanSangGiao && d.NguonGiao != "Quan"
                        && (d.HenGiaoLuc == null || d.HenGiaoLuc <= DateTime.Now.AddMinutes(30)))   // v66: đơn hẹn giờ chỉ phân công khi gần tới giờ
                    .OrderBy(d => d.NgayDat).Take(10).ToListAsync();
                if (donCho.Count == 0) return Ghi(0, "Không có đơn nào chờ phân công.");

                var taiXe = await db.TaiXes
                    .Where(t => t.MaGianHang == null && t.TrangThaiDuyet == "DaDuyet" && t.TrangThai == "SanSang"
                        && db.TaiKhoans.Any(k => k.MaTK == t.MaTK && k.TrangThai)).ToListAsync();
                if (taiXe.Count == 0) return Ghi(0, $"{donCho.Count} đơn đang chờ nhưng chưa có tài xế sẵn sàng.");

                var dangGiu = await db.DonHangs.Where(d => d.MaTaiXe != null && (d.TrangThai == "DangGiao" || d.TrangThai == "DaXacNhan"))
                    .GroupBy(d => d.MaTaiXe!.Value).Select(g => new { Ma = g.Key, So = g.Count() }).ToDictionaryAsync(x => x.Ma, x => x.So);

                int ok = 0;
                foreach (var don in donCho)
                {
                    if (taiXe.Count == 0) break;
                    var tx = taiXe
                        .OrderBy(t => TrungKhuVuc(t.KhuVucHoatDong, don.DiaChiGiaoHang) ? 0 : 1)
                        .ThenBy(t => dangGiu.GetValueOrDefault(t.MaTaiXe))
                        .ThenBy(t => t.MaTaiXe).First();
                    taiXe.Remove(tx);

                    var giaoHang = await db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == don.MaDonHang);
                    if (giaoHang != null) { giaoHang.MaTaiXe = tx.MaTaiXe; giaoHang.TrangThai = "DaNhan"; giaoHang.ThoiGianNhan = DateTime.Now; giaoHang.TrangThaiThuNhap = "ChoThanhToan"; }
                    else db.GiaoHangs.Add(new GiaoHang { MaDonHang = don.MaDonHang, MaTaiXe = tx.MaTaiXe, TrangThai = "DaNhan", ThoiGianNhan = DateTime.Now, TrangThaiThuNhap = "ChoThanhToan" });
                    don.NguonGiao = "Ngoai";
                    don.MaTaiXe = tx.MaTaiXe;
                    don.TrangThai = "DaXacNhan";      // tài xế đang đến quán; bấm "Đã lấy hàng" mới sang DangGiao
                    tx.TrangThai = "DangGiao";

                    var lyDo = lyDoGoc + (TrungKhuVuc(tx.KhuVucHoatDong, don.DiaChiGiaoHang) ? " · đúng khu vực" : "") + $" · đang giữ {dangGiu.GetValueOrDefault(tx.MaTaiXe)} đơn";
                    db.DieuPhoiLogs.Add(new DieuPhoiLog { MaDonHang = don.MaDonHang, HanhDong = "PhanCong", MaTaiXeMoi = tx.MaTaiXe, LyDo = lyDo, MaTK = maTK });
                    db.ThongBaos.Add(new ThongBao { MaTK = tx.MaTK, Loai = "DonHang", TieuDe = "Bạn được phân công đơn mới", NoiDung = $"Đơn #{don.MaDonHang} được hệ thống tự động phân công cho bạn.", MaThamChieu = don.MaDonHang.ToString() });
                    ok++;
                }
                await db.SaveChangesAsync();
                TongDaPhanCong += ok;
                return Ghi(ok, ok == 0 ? "Không phân công được đơn nào." : $"Đã tự động phân công {ok} đơn.");
            }
            catch (Exception ex)
            {
                db.ChangeTracker.Clear();
                return Ghi(0, "Lỗi: " + ex.Message);
            }
            finally { _khoa.Release(); }
        }

        private static (int, string) Ghi(int ok, string tomTat) { LanChayCuoi = DateTime.Now; KetQuaCuoi = tomTat; return (ok, tomTat); }

        /// <summary>Khu vực hoạt động của tài xế (ngăn bởi , ; /) có xuất hiện trong địa chỉ giao hay không (không phân biệt hoa thường).</summary>
        private static bool TrungKhuVuc(string? khuVuc, string diaChi) => KhuVucHelper.Trung(khuVuc, diaChi);
    }

    /// <summary>Vòng lặp nền: mỗi 30 giây, nếu bật "DieuPhoi.TuDong" thì chạy tự động phân công.</summary>
    public class TuDongPhanCongNen : BackgroundService
    {
        private readonly IServiceScopeFactory _scopes;
        private readonly ILogger<TuDongPhanCongNen> _log;
        public TuDongPhanCongNen(IServiceScopeFactory scopes, ILogger<TuDongPhanCongNen> log) { _scopes = scopes; _log = log; }

        protected override async Task ExecuteAsync(CancellationToken ct)
        {
            try { await Task.Delay(TimeSpan.FromSeconds(20), ct); } catch (OperationCanceledException) { return; }
            while (!ct.IsCancellationRequested)
            {
                try
                {
                    using var scope = _scopes.CreateScope();
                    var cauHinh = scope.ServiceProvider.GetRequiredService<CauHinhService>();
                    if (await TuDongPhanCongXuLy.DangBatAsync(cauHinh))
                    {
                        var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                        var (ok, tom) = await TuDongPhanCongXuLy.ChayAsync(db, null);
                        if (ok > 0) _log.LogInformation("Tự động phân công: {Tom}", tom);
                    }
                }
                catch (Exception ex) { _log.LogWarning(ex, "Tự động phân công lỗi"); }
                try { await Task.Delay(TimeSpan.FromSeconds(30), ct); } catch (OperationCanceledException) { break; }
            }
        }
    }
}
