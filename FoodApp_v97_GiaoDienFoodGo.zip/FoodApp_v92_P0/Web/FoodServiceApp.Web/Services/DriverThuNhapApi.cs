using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;

namespace FoodServiceApp.Web.Services
{
    /// <summary>
    /// Thu nhập tài xế cho app mobile (cùng quy tắc với trang web "Thu nhập &amp; COD"): phí giao từng chuyến, thưởng/phụ cấp/điều chỉnh/khấu trừ,
    /// tổng theo ngày/tuần/tháng, tiền mặt (COD), khoản nền tảng đã trả hay chưa và lịch thanh toán.
    /// Đơn bị hủy không tính; giao thất bại do khách (TinhPhiThatBai) vẫn được phí giao theo quy định và hiển thị riêng.
    /// </summary>
    public static class DriverThuNhapApi
    {
        private record Dong(DateTime ThoiGian, int? MaDon, decimal SoTien, string Loai, string? GhiChu, string TrangThai, decimal? CodThu, int? MaDieuChinh);
        private static readonly string[] TenThu = { "Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ nhật" };

        public static async Task<object> TaoAsync(AppDbContext db, CauHinhService cauHinh, int maTaiXe, string? ky, DateTime now)
        {
            var homNay = now.Date;
            var dauTuan = homNay.AddDays(-(((int)homNay.DayOfWeek + 6) % 7));       // tuần bắt đầu thứ Hai
            var dauThang = new DateTime(homNay.Year, homNay.Month, 1);
            var tu30 = homNay.AddDays(-29);
            ky = ky is "ngay" or "tuan" or "thang" ? ky : "tuan";
            var tuKy = ky == "ngay" ? homNay : ky == "tuan" ? dauTuan : dauThang;
            var batDau = new[] { tu30, dauThang, dauTuan }.Min();

            var gh = await db.GiaoHangs.AsNoTracking().Include(g => g.DonHang)
                .Where(g => g.MaTaiXe == maTaiXe && g.ThoiGianGiao >= batDau
                            && (g.TrangThai == "GiaoThanhCong" || (g.TrangThai == "GiaoThatBai" && g.TinhPhiThatBai)))
                .ToListAsync();
            var dc = await db.DieuChinhThuNhaps.AsNoTracking().Where(x => x.MaTaiXe == maTaiXe && x.NgayTao >= batDau).ToListAsync();

            var dong = new List<Dong>();
            foreach (var g in gh)
                dong.Add(new Dong(g.ThoiGianGiao!.Value, g.MaDonHang, PhiGiaoService.TienTaiXe(g.DonHang!.PhiGiaoHang, g.DonHang.TyLeTaiXe),
                    g.TrangThai == "GiaoThanhCong" ? "PhiGiao" : "PhiGiaoThatBai",
                    g.TrangThai == "GiaoThatBai" ? "Giao thất bại do khách: " + g.LyDoThatBai : null,
                    g.TrangThaiThuNhap, g.TienThuCOD, null));
            foreach (var x in dc)
                dong.Add(new Dong(x.NgayTao, x.MaDonHang, x.SoTien, x.Loai, x.LyDo, x.TrangThai, null, x.MaDieuChinh));

            decimal Tong(DateTime tu) => dong.Where(d => d.ThoiGian >= tu).Sum(d => d.SoTien);
            int Chuyen(DateTime tu) => dong.Count(d => d.ThoiGian >= tu && d.Loai == "PhiGiao");
            var trongKy = dong.Where(d => d.ThoiGian >= tuKy).ToList();
            var d30 = dong.Where(d => d.ThoiGian >= tu30).ToList();
            decimal CongKy(Func<Dong, bool> f) => trongKy.Where(f).Sum(d => d.SoTien);
            bool LaPhiGiao(Dong d) => d.Loai is "PhiGiao" or "PhiGiaoThatBai";

            // Tiền mặt
            var codDangCam = await db.DonHangs.AsNoTracking()
                .Where(d => d.MaTaiXe == maTaiXe && d.TrangThai == "DangGiao" && d.ThanhToan != null && d.ThanhToan.HinhThuc == "TienMat" && d.ThanhToan.TrangThai != "DaThanhToan")
                .SumAsync(d => (decimal?)d.TongTien) ?? 0;
            var codChoNop = await DriverDonXuLy.CodChuaNopAsync(db, maTaiXe);

            // Lịch thanh toán (cấu hình: TaiXe.NgayThanhToanThu, 1 = Thứ Hai ... 7 = Chủ nhật; mặc định Thứ Hai hằng tuần)
            var thu = Math.Clamp((int)await cauHinh.LaySoAsync("TaiXe.NgayThanhToanThu", 1), 1, 7);
            var homNayThu = ((int)homNay.DayOfWeek + 6) % 7 + 1;
            var ngayTiep = homNay.AddDays((thu - homNayThu + 7) % 7);

            return new
            {
                ky, tuNgay = tuKy, denNgay = homNay,
                homNay = new { thuNhap = Tong(homNay), soChuyen = Chuyen(homNay) },
                tuanNay = new { thuNhap = Tong(dauTuan), soChuyen = Chuyen(dauTuan) },
                thangNay = new { thuNhap = Tong(dauThang), soChuyen = Chuyen(dauThang) },
                tong = new
                {
                    thuNhap = trongKy.Sum(d => d.SoTien),
                    soChuyen = trongKy.Count(d => d.Loai == "PhiGiao"),
                    phiGiao = CongKy(LaPhiGiao),
                    thuong = CongKy(d => d.Loai == "Thuong" && d.SoTien > 0),
                    phuCap = CongKy(d => d.Loai == "PhuCap" && d.SoTien > 0),
                    dieuChinhCong = CongKy(d => d.Loai == "DieuChinh" && d.SoTien > 0),
                    khauTru = CongKy(d => d.SoTien < 0 && !LaPhiGiao(d)),
                },
                tienMat = new { daThu30Ngay = d30.Sum(d => d.CodThu ?? 0), dangCam = codDangCam, canNop = codChoNop.Sum(c => c.SoTien), soDonChuaNop = codChoNop.Count },
                thanhToan = new
                {
                    choNenTangTra = d30.Where(d => d.TrangThai != "DaThanhToan").Sum(d => d.SoTien),
                    daDuocTra = d30.Where(d => d.TrangThai == "DaThanhToan").Sum(d => d.SoTien),
                    chuKy = $"{TenThu[thu - 1]} hằng tuần",
                    ngayThanhToanTiepTheo = ngayTiep,
                    ghiChu = "Thu nhập các chuyến đã hoàn thành được nền tảng thanh toán theo chu kỳ trên; các khoản khấu trừ/điều chỉnh được cấn trừ khi thanh toán. Thấy sai lệch hãy gửi yêu cầu để được kiểm tra.",
                },
                chuyen = trongKy.Where(LaPhiGiao).OrderByDescending(d => d.ThoiGian).Take(100)
                    .Select(d => new { maDon = d.MaDon, thoiGian = d.ThoiGian, soTien = d.SoTien, loai = d.Loai, ghiChu = d.GhiChu, trangThai = d.TrangThai, codThu = d.CodThu }).ToList(),
                dieuChinh = trongKy.Where(d => !LaPhiGiao(d)).OrderByDescending(d => d.ThoiGian).Take(100)
                    .Select(d => new { id = d.MaDieuChinh, maDon = d.MaDon, thoiGian = d.ThoiGian, soTien = d.SoTien, loai = d.Loai, lyDo = d.GhiChu, trangThai = d.TrangThai }).ToList(),
            };
        }
    }
}
