using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;

namespace FoodServiceApp.Web.Services
{
    /// <summary>
    /// Chạy một lần mỗi lần khởi động (idempotent): chuyển giấy tờ cũ đang nằm trong wwwroot/uploads sang kho riêng tư
    /// (App_Data/private) và cập nhật đường dẫn trong CSDL. Áp dụng cho GPLX tài xế, giấy phép kinh doanh và ATTP.
    /// File cũ được XÓA khỏi wwwroot sau khi sao chép thành công.
    /// </summary>
    public static class FileRiengTuMigration
    {
        public static async Task ChayAsync(IServiceProvider sp, ILogger log)
        {
            try
            {
                using var scope = sp.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
                var env = scope.ServiceProvider.GetRequiredService<IWebHostEnvironment>();
                var luuTru = scope.ServiceProvider.GetRequiredService<IFileStorageService>() as LocalFileStorageService;
                if (luuTru == null) return;

                string? Chuyen(string? url, string subDich)
                {
                    if (string.IsNullOrWhiteSpace(url) || !url.StartsWith("/uploads/", StringComparison.OrdinalIgnoreCase)) return url;
                    var goc = Path.GetFullPath(Path.Combine(env.WebRootPath ?? "wwwroot", "uploads"));
                    var nguon = Path.GetFullPath(Path.Combine(env.WebRootPath ?? "wwwroot", url.TrimStart('/')));
                    if (!nguon.StartsWith(goc + Path.DirectorySeparatorChar, StringComparison.Ordinal) || !File.Exists(nguon)) return url;
                    var duoi = Path.GetExtension(nguon).ToLowerInvariant();
                    if (duoi is not (".jpg" or ".jpeg" or ".png" or ".webp" or ".pdf")) return url;
                    if (duoi == ".jpeg") duoi = ".jpg";
                    var thuMuc = Path.Combine(luuTru.GocRiengTu, subDich);
                    Directory.CreateDirectory(thuMuc);
                    var ten = Guid.NewGuid().ToString("N") + duoi;
                    File.Copy(nguon, Path.Combine(thuMuc, ten), overwrite: false);
                    File.Delete(nguon);
                    return $"{LocalFileStorageService.TienToRiengTu}{subDich}/{ten}";
                }

                var dem = 0;
                foreach (var t in await db.TaiXes.Where(t => t.AnhGPLX != null && t.AnhGPLX.StartsWith("/uploads/")).ToListAsync())
                { var moi = Chuyen(t.AnhGPLX, "taixe-giayto"); if (moi != t.AnhGPLX) { t.AnhGPLX = moi; dem++; } }
                foreach (var g in await db.GianHangs.Where(g => (g.GiayPhepKinhDoanh != null && g.GiayPhepKinhDoanh.StartsWith("/uploads/"))
                                                               || (g.GiayChungNhanATTP != null && g.GiayChungNhanATTP.StartsWith("/uploads/"))).ToListAsync())
                {
                    var a = Chuyen(g.GiayPhepKinhDoanh, "giayto"); if (a != g.GiayPhepKinhDoanh) { g.GiayPhepKinhDoanh = a; dem++; }
                    var b = Chuyen(g.GiayChungNhanATTP, "giayto"); if (b != g.GiayChungNhanATTP) { g.GiayChungNhanATTP = b; dem++; }
                }
                if (dem > 0) { await db.SaveChangesAsync(); log.LogInformation("Đã chuyển {N} giấy tờ sang kho riêng tư (App_Data/private).", dem); }

                // Dọn thư mục giấy tờ cũ còn sót (không còn được tham chiếu): đưa vào kho riêng tư luôn, không để trong wwwroot.
                var cu = Path.Combine(env.WebRootPath ?? "wwwroot", "uploads", "giayto");
                if (Directory.Exists(cu))
                {
                    var dich = Path.Combine(luuTru.GocRiengTu, "giayto");
                    Directory.CreateDirectory(dich);
                    foreach (var f in Directory.GetFiles(cu))
                    {
                        var d = Path.Combine(dich, Path.GetFileName(f));
                        if (!File.Exists(d)) File.Move(f, d); else File.Delete(f);
                    }
                }
            }
            catch (Exception ex) { log.LogError(ex, "Chuyển giấy tờ sang kho riêng tư thất bại — kiểm tra quyền ghi App_Data/private."); }
        }
    }
}
