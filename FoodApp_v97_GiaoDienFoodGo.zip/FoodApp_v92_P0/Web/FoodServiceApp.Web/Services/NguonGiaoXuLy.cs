using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Services
{
    /// <summary>
    /// v31 — Quán chọn cách giao: "Quan" (tài xế nội bộ của quán, do quán gán trực tiếp) hay "Ngoai" (shipper ngoài/nền tảng nhận ở hàng chờ).
    /// Dùng chung cho Web (DonHangController, TaiXeQuanController) và API (VendorApiController, MobileApiController).
    /// </summary>
    public static class NguonGiaoXuLy
    {
        public const string Quan = "Quan";
        public const string Ngoai = "Ngoai";
        public const string ThuNhapNoiBo = "NoiBo";   // GiaoHang.TrangThaiThuNhap: phí giao thuộc quán, nền tảng không trả thu nhập

        public static string ChuanHoa(string? v) => string.Equals(v?.Trim(), Quan, StringComparison.OrdinalIgnoreCase) ? Quan : Ngoai;

        /// <summary>Cách giao mặc định của quán cho các đơn mới (áp khi quán xác nhận đơn).</summary>
        public static async Task<KetQuaGiao> DatCheDoMacDinhAsync(AppDbContext db, int maGianHang, string? che)
        {
            var gh = await db.GianHangs.FirstOrDefaultAsync(g => g.MaGianHang == maGianHang);
            if (gh == null) return new(false, "Không tìm thấy gian hàng.");
            var moi = ChuanHoa(che);
            if (moi == Quan && !await db.TaiXes.AnyAsync(t => t.MaGianHang == maGianHang && t.TrangThaiDuyet == "DaDuyet"))
                return new(false, "Quán chưa có tài xế riêng. Hãy thêm tài xế của quán trước khi chọn \"Tài xế của quán\".");
            gh.CheDoGiao = moi;
            await db.SaveChangesAsync();
            return new(true, moi == Quan ? "Đơn mới sẽ giao bằng tài xế của quán." : "Đơn mới sẽ chuyển cho shipper ngoài.");
        }

        /// <summary>Tài xế của quán đang rảnh/được phép nhận (đã duyệt, tài khoản hoạt động).</summary>
        public static IQueryable<TaiXe> TaiXeCuaQuan(AppDbContext db, int maGianHang) =>
            db.TaiXes.Where(t => t.MaGianHang == maGianHang && t.TrangThaiDuyet == "DaDuyet"
                && db.TaiKhoans.Any(k => k.MaTK == t.MaTK && k.TrangThai));

        /// <summary>Quán gán một tài xế của quán cho đơn (đơn phải đã xác nhận, chưa lấy hàng, chưa có shipper ngoài nhận).</summary>
        public static async Task<KetQuaGiao> GanTaiXeQuanAsync(AppDbContext db, DonHang don, int maTaiXe)
        {
            if (don.TrangThai != "DaXacNhan") return new(false, "Chỉ chọn người giao khi đơn đã xác nhận và chưa giao.");
            var tx = await TaiXeCuaQuan(db, don.MaGianHang).FirstOrDefaultAsync(t => t.MaTaiXe == maTaiXe);
            if (tx == null) return new(false, "Không tìm thấy tài xế này trong danh sách tài xế của quán (hoặc tài khoản đang bị khóa).");

            var gh = await db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == don.MaDonHang);
            int? cu = don.MaTaiXe;
            if (cu == maTaiXe && gh != null) return new(true, $"Đơn đã được gán cho {tx.HoTen}.");
            if (cu != null)
            {
                var cuLaQuan = await db.TaiXes.AnyAsync(t => t.MaTaiXe == cu && t.MaGianHang == don.MaGianHang);
                if (!cuLaQuan) return new(false, "Shipper ngoài đã nhận đơn này, không thể đổi sang tài xế của quán. Hãy liên hệ Quản trị nếu cần.");
                if (gh != null && gh.TrangThai != "DaNhan") return new(false, "Tài xế đã lấy hàng, không thể đổi người giao.");
            }
            if (await db.DonHangs.AnyAsync(d => d.MaTaiXe == maTaiXe && d.MaDonHang != don.MaDonHang && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao")))
                return new(false, $"{tx.HoTen} đang có một chuyến giao chưa xong.");

            var now = DateTime.Now;
            don.NguonGiao = Quan; don.MaTaiXe = maTaiXe;
            if (gh == null) db.GiaoHangs.Add(new GiaoHang { MaDonHang = don.MaDonHang, MaTaiXe = maTaiXe, TrangThai = "DaNhan", ThoiGianNhan = now, TrangThaiThuNhap = ThuNhapNoiBo });
            else { gh.MaTaiXe = maTaiXe; gh.TrangThai = "DaNhan"; gh.ThoiGianNhan = now; gh.TrangThaiThuNhap = ThuNhapNoiBo; }
            tx.TrangThai = "DangGiao";

            db.ThongBaos.Add(new ThongBao { MaTK = tx.MaTK, Loai = "DonHang", MaThamChieu = don.MaDonHang.ToString(), TieuDe = "Quán giao đơn cho bạn",
                NoiDung = $"Đơn #{don.MaDonHang} do quán gán cho bạn. Hãy đến quán lấy món và giao cho khách." });
            var maTkKhach = await db.KhachHangs.Where(k => k.MaKH == don.MaKH).Select(k => (int?)k.MaTK).FirstOrDefaultAsync();
            if (maTkKhach != null)
                db.ThongBaos.Add(new ThongBao { MaTK = maTkKhach.Value, Loai = "DonHang", MaThamChieu = don.MaDonHang.ToString(), TieuDe = $"Đơn #{don.MaDonHang} đã có người giao",
                    NoiDung = $"Tài xế {tx.HoTen} của quán sẽ giao đơn cho bạn." });
            if (cu != null && cu != maTaiXe)
            {
                var maTkCu = await db.TaiXes.Where(t => t.MaTaiXe == cu).Select(t => (int?)t.MaTK).FirstOrDefaultAsync();
                if (maTkCu != null) db.ThongBaos.Add(new ThongBao { MaTK = maTkCu.Value, Loai = "DonHang", MaThamChieu = don.MaDonHang.ToString(), TieuDe = "Đơn đã chuyển cho người khác", NoiDung = $"Quán đã đổi người giao đơn #{don.MaDonHang}." });
            }
            await db.SaveChangesAsync();
            if (cu != null && cu != maTaiXe) { await GiaoHangXuLy.GiaiPhongTaiXeAsync(db, cu, don.MaDonHang); await db.SaveChangesAsync(); }
            return new(true, $"Đã giao đơn #{don.MaDonHang} cho tài xế {tx.HoTen} của quán.");
        }

        /// <summary>Quán chuyển đơn cho shipper ngoài: bỏ gán tài xế quán (nếu chưa lấy hàng), đơn vào hàng chờ chung.</summary>
        public static async Task<KetQuaGiao> ChuyenShipperNgoaiAsync(AppDbContext db, DonHang don)
        {
            if (don.TrangThai != "DaXacNhan") return new(false, "Chỉ chọn người giao khi đơn đã xác nhận và chưa giao.");
            if (don.MaTaiXe != null)
            {
                var cuLaQuan = await db.TaiXes.AnyAsync(t => t.MaTaiXe == don.MaTaiXe && t.MaGianHang == don.MaGianHang);
                if (!cuLaQuan) return new(true, "Đơn đã có shipper ngoài nhận.");
                var gh = await db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == don.MaDonHang);
                if (gh != null && gh.TrangThai != "DaNhan") return new(false, "Tài xế của quán đã lấy hàng, không thể chuyển sang shipper ngoài.");
                var cu = don.MaTaiXe;
                if (gh != null) db.GiaoHangs.Remove(gh);
                don.MaTaiXe = null;
                var maTkCu = await db.TaiXes.Where(t => t.MaTaiXe == cu).Select(t => (int?)t.MaTK).FirstOrDefaultAsync();
                if (maTkCu != null) db.ThongBaos.Add(new ThongBao { MaTK = maTkCu.Value, Loai = "DonHang", MaThamChieu = don.MaDonHang.ToString(), TieuDe = "Đơn đã chuyển cho shipper ngoài", NoiDung = $"Quán đã chuyển đơn #{don.MaDonHang} cho shipper ngoài." });
                don.NguonGiao = Ngoai;
                await db.SaveChangesAsync();
                await GiaoHangXuLy.GiaiPhongTaiXeAsync(db, cu, don.MaDonHang);
            }
            else don.NguonGiao = Ngoai;

            var quanTri = await GiaoHangXuLy.QuanTriDieuPhoiAsync(db);
            if (don.SanSangGiao) await GiaoHangXuLy.ThongBaoDonMoiAsync(db, don);   // đã sẵn sàng thì báo ngay (admin nếu quản trị điều phối, ngược lại shipper ngoài)
            else await GiaoHangXuLy.BaoQuanTriDonCanDieuPhoiAsync(db, don, false);
            await db.SaveChangesAsync();
            return new(true, quanTri ? $"Đơn #{don.MaDonHang} đã chuyển lên Quản trị để điều phối tài xế." : $"Đơn #{don.MaDonHang} đã chuyển cho shipper ngoài (hiện ở hàng chờ nhận).");
        }

        /// <summary>Tạo tài xế nội bộ cho quán (tài khoản đăng nhập app tài xế). Trả về (kết quả, mã tài xế).</summary>
        public static async Task<(KetQuaGiao kq, int? maTaiXe)> TaoTaiXeQuanAsync(AppDbContext db, int maGianHang, string tenDangNhap, string matKhau, string hoTen, string sdt, string? phuongTien, string? bienSo)
        {
            tenDangNhap = (tenDangNhap ?? "").Trim(); hoTen = (hoTen ?? "").Trim(); sdt = (sdt ?? "").Trim();
            if (tenDangNhap.Length < 3) return (new KetQuaGiao(false, "Tên đăng nhập tối thiểu 3 ký tự."), null);
            if (hoTen.Length < 2) return (new KetQuaGiao(false, "Nhập họ tên tài xế."), null);
            if (sdt.Length < 9) return (new KetQuaGiao(false, "Nhập số điện thoại hợp lệ."), null);
            if ((matKhau ?? "").Length < 6) return (new KetQuaGiao(false, "Mật khẩu tối thiểu 6 ký tự."), null);
            if (await db.TaiKhoans.AnyAsync(t => t.TenDangNhap == tenDangNhap)) return (new KetQuaGiao(false, "Tên đăng nhập đã tồn tại."), null);

            var tk = new TaiKhoan { TenDangNhap = tenDangNhap, MatKhau = MatKhauHelper.Hash(matKhau!), VaiTro = "TaiXe" };
            db.TaiKhoans.Add(tk);
            await db.SaveChangesAsync();
            var tx = new TaiXe
            {
                MaTK = tk.MaTK, HoTen = hoTen, SDT = sdt, PhuongTien = string.IsNullOrWhiteSpace(phuongTien) ? null : phuongTien.Trim(),
                BienSo = string.IsNullOrWhiteSpace(bienSo) ? null : bienSo.Trim(), TrangThai = "SanSang", TrangThaiDuyet = "DaDuyet", MaGianHang = maGianHang,
            };
            db.TaiXes.Add(tx);
            await db.SaveChangesAsync();
            return (new KetQuaGiao(true, $"Đã thêm tài xế {hoTen} (đăng nhập app tài xế bằng tên \"{tenDangNhap}\")."), tx.MaTaiXe);
        }

        /// <summary>Khóa/mở khóa tài xế của quán (không xóa vì còn lịch sử giao hàng). Khóa bị từ chối nếu đang có chuyến.</summary>
        public static async Task<KetQuaGiao> DatHoatDongAsync(AppDbContext db, int maGianHang, int maTaiXe, bool hoatDong)
        {
            var tx = await db.TaiXes.FirstOrDefaultAsync(t => t.MaTaiXe == maTaiXe && t.MaGianHang == maGianHang);
            if (tx == null) return new(false, "Không tìm thấy tài xế của quán.");
            var tk = await db.TaiKhoans.FirstOrDefaultAsync(k => k.MaTK == tx.MaTK);
            if (tk == null) return new(false, "Không tìm thấy tài khoản.");
            if (!hoatDong && await GiaoHangXuLy.DangCoChuyenAsync(db, maTaiXe)) return new(false, "Tài xế đang có chuyến giao chưa xong, chưa thể khóa.");
            tk.TrangThai = hoatDong;
            if (!hoatDong) tx.TrangThai = "NgoaiTuyen";
            await db.SaveChangesAsync();
            return new(true, hoatDong ? "Đã mở khóa tài xế." : "Đã khóa tài xế.");
        }
    }
}
