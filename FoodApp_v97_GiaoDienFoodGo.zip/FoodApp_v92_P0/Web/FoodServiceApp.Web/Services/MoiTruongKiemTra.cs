using System.Text.RegularExpressions;

namespace FoodServiceApp.Web.Services
{
    /// <summary>
    /// v84 — Kiểm tra cấu hình theo môi trường (Development / Staging / Production) lúc khởi động, để dữ liệu thử nghiệm
    /// và dữ liệu khách thật không bị trộn lẫn. Lỗi nghiêm trọng (Production trỏ vào CSDL staging/test, lộ mã OTP) → dừng ứng dụng;
    /// còn lại chỉ ghi cảnh báo ra log. Development không bị kiểm tra.
    /// </summary>
    public static class MoiTruongKiemTra
    {
        /// <summary>Số cảnh báo còn tồn tại (chỉ để hiện con số ở /health, không lộ chi tiết).</summary>
        public static int SoCanhBao { get; private set; }

        public static string? TenCsdl(string? connectionString)
        {
            if (string.IsNullOrWhiteSpace(connectionString)) return null;
            var m = Regex.Match(connectionString, @"(?:^|;)\s*(?:Database|Initial\s+Catalog)\s*=\s*([^;]+)", RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value.Trim() : null;
        }

        private static bool TenGiongThuNghiem(string? ten) =>
            ten != null && Regex.IsMatch(ten, @"(staging|stage|test|dev|demo|thu)", RegexOptions.IgnoreCase);

        public static (List<string> Loi, List<string> CanhBao) Kiem(IConfiguration cfg, IHostEnvironment env, string? connectionString)
        {
            var loi = new List<string>();
            var canhBao = new List<string>();
            if (env.IsDevelopment()) return (loi, canhBao);

            var sanXuat = env.IsProduction();
            var staging = env.IsStaging();
            var tenDb = TenCsdl(connectionString);

            if (sanXuat && TenGiongThuNghiem(tenDb))
                loi.Add($"Production đang trỏ vào CSDL '{tenDb}' (tên giống staging/test/demo). Dùng CSDL riêng cho khách thật, không dùng chung dữ liệu thử nghiệm.");
            if (staging && tenDb != null && string.Equals(tenDb, "QuanLyDichVuAnUong", StringComparison.OrdinalIgnoreCase))
                canhBao.Add("Staging đang dùng CSDL 'QuanLyDichVuAnUong' (tên mặc định của production). Hãy dùng CSDL riêng, ví dụ QuanLyDichVuAnUong_Staging.");
            if (!string.IsNullOrEmpty(connectionString) && connectionString.Contains("(localdb)", StringComparison.OrdinalIgnoreCase))
                canhBao.Add("Chuỗi kết nối đang dùng LocalDB — không phù hợp máy chủ thật. Đặt biến môi trường FOOD_DB_CONNECTION.");

            if (sanXuat && cfg.GetValue<bool>("Otp:HienMaDev"))
                loi.Add("Otp:HienMaDev đang bật trên Production — mã OTP sẽ lộ ra ngoài. Tắt (false) rồi chạy lại.");

            var vnpBase = cfg["VnPay:BaseUrl"] ?? "";
            var vnpReturn = cfg["VnPay:ReturnUrl"] ?? "";
            if (sanXuat && vnpBase.Contains("sandbox", StringComparison.OrdinalIgnoreCase))
                canhBao.Add("Production đang dùng cổng VNPay sandbox — thanh toán thật sẽ không hoạt động.");
            if (staging && !string.IsNullOrWhiteSpace(vnpBase) && !vnpBase.Contains("sandbox", StringComparison.OrdinalIgnoreCase))
                canhBao.Add("Staging đang trỏ cổng VNPay thật — hãy dùng sandbox để thử.");
            if (vnpReturn.Contains("localhost", StringComparison.OrdinalIgnoreCase))
                canhBao.Add("VnPay:ReturnUrl đang là localhost — VNPay không gọi về được. Đặt https://<tên miền>/api/payment/vnpay/return.");

            if ((cfg["AllowedHosts"] ?? "*") == "*")
                canhBao.Add("AllowedHosts đang là '*'. Nên đặt đúng tên miền (biến môi trường AllowedHosts).");
            if (!(cfg.GetSection("Cors:AllowedOrigins").Get<string[]>() ?? Array.Empty<string>()).Any(o => !string.IsNullOrWhiteSpace(o)))
                canhBao.Add("Cors:AllowedOrigins trống: trình duyệt từ origin khác sẽ bị chặn (app mobile không bị ảnh hưởng). Điền nếu có website riêng gọi API.");
            if (string.IsNullOrWhiteSpace(cfg["GoongMaps:ApiKey"]))
                canhBao.Add("Chưa có GoongMaps:ApiKey — phí giao sẽ dùng mức mặc định (không tính theo km). Đặt biến môi trường GoongMaps__ApiKey.");

            // ---- v92 P0: tài khoản SQL, chứng chỉ, khóa tích hợp, kênh OTP ----
            var cs = connectionString ?? "";
            if (sanXuat && Regex.IsMatch(cs, @"(?:^|;)\s*(?:User\s*Id|Uid|User)\s*=\s*sa\s*(?:;|$)", RegexOptions.IgnoreCase))
                loi.Add("Chuỗi kết nối dùng tài khoản 'sa' (quyền quản trị toàn máy chủ). Tạo tài khoản riêng chỉ có quyền trên CSDL ứng dụng (xem deploy/sql-tao-tai-khoan-ung-dung.sql).");
            if (Regex.IsMatch(cs, @"TrustServerCertificate\s*=\s*True", RegexOptions.IgnoreCase))
            {
                var may = Regex.Match(cs, @"(?:^|;)\s*(?:Server|Data\s+Source)\s*=\s*([^;,]+)", RegexOptions.IgnoreCase).Groups[1].Value.Trim().ToLowerInvariant();
                var noiBo = may is "db" or "localhost" or "127.0.0.1" or "." or "(local)" || may.StartsWith("(localdb)");
                var msg = "Chuỗi kết nối có TrustServerCertificate=True (không xác minh chứng chỉ SQL). Dùng Encrypt=True;TrustServerCertificate=False với chứng chỉ hợp lệ, hoặc Encrypt=False khi SQL chạy trong mạng nội bộ không mở cổng ra ngoài.";
                if (sanXuat && !noiBo) loi.Add(msg); else canhBao.Add(msg);
            }
            bool GiaMau(string? v) => !string.IsNullOrWhiteSpace(v) && (v.StartsWith("DIEN_") || v.StartsWith("DOI_"));
            foreach (var (khoa, ten) in new[] { ("VnPay:TmnCode", "VnPay:TmnCode"), ("VnPay:HashSecret", "VnPay:HashSecret"), ("GoongMaps:ApiKey", "GoongMaps:ApiKey") })
                if (GiaMau(cfg[khoa]))
                {
                    var m = $"{ten} vẫn là giá trị mẫu — chức năng liên quan không hoạt động. Đặt biến môi trường {khoa.Replace(":", "__")}.";
                    if (sanXuat) loi.Add(m); else canhBao.Add(m);
                }
            if (sanXuat && string.IsNullOrWhiteSpace(cfg["VnPay:HashSecret"])) canhBao.Add("Chưa có VnPay:HashSecret — thanh toán VNPay không dùng được (chỉ COD).");
            var coSmtp = !string.IsNullOrWhiteSpace(cfg["Smtp:Host"]);
            var coSms = !string.IsNullOrWhiteSpace(cfg["Sms:Endpoint"]);
            if (!coSmtp && !coSms)
                canhBao.Add("Chưa cấu hình SMTP và SMS — không gửi được OTP. Điền Smtp__* hoặc Sms__* (xem Docs/CAU_HINH_PRODUCTION_P0.md).");
            else if (!coSms)
                canhBao.Add("Chưa cấu hình Sms:Endpoint — OTP chỉ gửi được qua email, không xác minh được số điện thoại bằng SMS.");

            SoCanhBao = canhBao.Count;
            return (loi, canhBao);
        }

        /// <summary>Chạy kiểm tra, in kết quả ra console; có lỗi nghiêm trọng thì ném InvalidOperationException (ứng dụng không khởi động).</summary>
        public static void Chay(IConfiguration cfg, IHostEnvironment env, string? connectionString)
        {
            var (loi, canhBao) = Kiem(cfg, env, connectionString);
            foreach (var c in canhBao) Console.WriteLine("[Triển khai] Cảnh báo: " + c);
            if (loi.Count > 0)
                throw new InvalidOperationException("[Triển khai] Cấu hình môi trường " + env.EnvironmentName + " không an toàn:\n - " + string.Join("\n - ", loi));
        }
    }
}
