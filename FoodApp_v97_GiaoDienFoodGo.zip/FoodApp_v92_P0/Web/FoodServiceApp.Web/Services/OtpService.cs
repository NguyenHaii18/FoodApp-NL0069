using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Services
{
    /// <summary>
    /// Sinh/kiểm tra OTP 6 số (hiệu lực 5 phút, tối đa 5 lần nhập sai, tối thiểu 30 giây giữa 2 lần gửi).
    /// Gửi email qua SMTP nếu cấu hình mục "Smtp" trong appsettings.json; nếu chưa cấu hình thì ghi mã ra log
    /// và (khi Otp:HienMaDev = true) trả mã về để demo không cần mail server.
    /// </summary>
    public class OtpService
    {
        private readonly AppDbContext _db;
        private readonly IConfiguration _cfg;
        private readonly ILogger<OtpService> _log;
        private readonly IHostEnvironment _env;

        public OtpService(AppDbContext db, IConfiguration cfg, ILogger<OtpService> log, IHostEnvironment env)
        {
            _db = db; _cfg = cfg; _log = log; _env = env;
        }

        /// <summary>Hiện mã OTP trên màn hình để demo: mặc định TẮT, và chỉ có tác dụng ở môi trường Development.</summary>
        public bool HienMaDev => _env.IsDevelopment() && (_cfg.GetValue<bool?>("Otp:HienMaDev") ?? false);

        private string Bam(string nguoiNhan, string mucDich, string otp)
        {
            var key = Encoding.UTF8.GetBytes(_cfg["Jwt:Key"] ?? "otp-key");
            using var h = new HMACSHA256(key);
            return Convert.ToHexString(h.ComputeHash(Encoding.UTF8.GetBytes($"{nguoiNhan}|{mucDich}|{otp}"))).ToLowerInvariant();
        }

        /// <summary>Tạo OTP và gửi. Trả (thanhCong, thongDiep, maDev).</summary>
        public async Task<(bool ok, string msg, string? maDev)> GuiAsync(string mucDich, string kenh, string nguoiNhan, int? maTK)
        {
            var gan = await _db.OtpXacThucs
                .Where(o => o.NguoiNhan == nguoiNhan && o.MucDich == mucDich)
                .OrderByDescending(o => o.NgayTao).FirstOrDefaultAsync();
            if (gan != null && (DateTime.Now - gan.NgayTao).TotalSeconds < 30)
                return (false, "Vui lòng đợi 30 giây trước khi gửi lại mã.", null);

            var otp = RandomNumberGenerator.GetInt32(0, 1000000).ToString("D6");
            _db.OtpXacThucs.Add(new OtpXacThuc
            {
                MucDich = mucDich, Kenh = kenh, NguoiNhan = nguoiNhan, MaTK = maTK,
                OtpHash = Bam(nguoiNhan, mucDich, otp),
                NgayTao = DateTime.Now, HetHan = DateTime.Now.AddMinutes(5),
            });
            await _db.SaveChangesAsync();

            var daGui = kenh == "sms" || kenh == "sdt" ? await GuiSmsAsync(nguoiNhan, otp) : await GuiMailAsync(kenh, nguoiNhan, otp);
            if (!daGui && !HienMaDev)
            {
                // Không gửi được và không ở chế độ demo: không để lộ mã; báo lỗi để người dùng/quản trị xử lý.
                _log.LogError("Không gửi được OTP ({Kenh}) tới {NguoiNhan}: chưa cấu hình/ lỗi SMTP.", kenh, nguoiNhan);
                return (false, "Hệ thống chưa gửi được mã xác thực (email/SMS chưa được cấu hình). Vui lòng liên hệ quản trị.", null);
            }
            if (!daGui && _env.IsDevelopment()) _log.LogWarning("[OTP DEMO] {Kenh} {NguoiNhan} -> {Otp} ({MucDich})", kenh, nguoiNhan, otp, mucDich);
            return (true, daGui ? "Đã gửi mã xác thực." : "Đã tạo mã xác thực (chưa cấu hình SMTP/SMS nên mã được hiển thị để demo).",
                    daGui || !HienMaDev ? null : otp);
        }

        /// <summary>Kiểm tra mã; đúng thì đánh dấu đã dùng.</summary>
        public async Task<(bool ok, string msg)> KiemTraAsync(string mucDich, string nguoiNhan, string? otp)
        {
            var o = await _db.OtpXacThucs
                .Where(x => x.NguoiNhan == nguoiNhan && x.MucDich == mucDich && !x.DaDung)
                .OrderByDescending(x => x.NgayTao).FirstOrDefaultAsync();
            if (o == null) return (false, "Chưa có mã xác thực, hãy yêu cầu gửi mã.");
            if (o.HetHan < DateTime.Now) return (false, "Mã đã hết hạn, hãy gửi lại.");
            if (o.SoLanSai >= 5) return (false, "Nhập sai quá 5 lần, hãy gửi lại mã mới.");
            if (!CryptographicOperations.FixedTimeEquals(
                    Encoding.ASCII.GetBytes(o.OtpHash), Encoding.ASCII.GetBytes(Bam(nguoiNhan, mucDich, (otp ?? "").Trim()))))
            {
                o.SoLanSai++;
                await _db.SaveChangesAsync();
                return (false, "Mã xác thực không đúng.");
            }
            o.DaDung = true;
            await _db.SaveChangesAsync();
            return (true, "OK");
        }

        private static readonly HttpClient _httpSms = new() { Timeout = TimeSpan.FromSeconds(15) };

        /// <summary>
        /// Gửi OTP qua SMS bằng một cổng HTTP bất kỳ (eSMS, SpeedSMS, Twilio, nhà mạng...) — cấu hình, không cần sửa mã:
        ///   Sms:Endpoint (URL), Sms:Method (POST mặc định), Sms:ContentType (application/json mặc định),
        ///   Sms:AuthHeader + Sms:AuthValue (vd Authorization / "Bearer xxx" hoặc "Basic ..."), Sms:BodyTemplate với {to} {to84} {message} {brand}.
        /// Phản hồi 2xx = gửi thành công. Chuỗi trong BodyTemplate được tự thoát đúng chuẩn JSON/URL.
        /// </summary>
        private async Task<bool> GuiSmsAsync(string soDienThoai, string otp)
        {
            var url = _cfg["Sms:Endpoint"];
            if (string.IsNullOrWhiteSpace(url)) return false;
            try
            {
                var so = new string((soDienThoai ?? "").Where(char.IsDigit).ToArray());
                if (so.Length < 9) return false;
                var to84 = so.StartsWith("84") ? so : "84" + so.TrimStart('0');
                var noiDung = $"{_cfg["Sms:Brand"] ?? "FoodApp"}: Ma xac thuc cua ban la {otp}. Hieu luc 5 phut, khong chia se cho bat ky ai.";
                var loai = _cfg["Sms:ContentType"] ?? "application/json";
                var mau = _cfg["Sms:BodyTemplate"] ?? "{\"to\":\"{to84}\",\"content\":\"{message}\"}";
                string Thoat(string v) => loai.Contains("json") ? System.Text.Json.JsonEncodedText.Encode(v).ToString() : Uri.EscapeDataString(v);
                var body = mau.Replace("{to84}", Thoat(to84)).Replace("{to}", Thoat(so)).Replace("{message}", Thoat(noiDung)).Replace("{brand}", Thoat(_cfg["Sms:Brand"] ?? "FoodApp"));
                using var req = new HttpRequestMessage(new HttpMethod(_cfg["Sms:Method"] ?? "POST"), url)
                { Content = new StringContent(body, Encoding.UTF8, loai) };
                if (!string.IsNullOrWhiteSpace(_cfg["Sms:AuthHeader"]))
                    req.Headers.TryAddWithoutValidation(_cfg["Sms:AuthHeader"]!, _cfg["Sms:AuthValue"] ?? "");
                using var res = await _httpSms.SendAsync(req);
                if (!res.IsSuccessStatusCode) _log.LogError("Cổng SMS trả {Code} khi gửi OTP tới ***{Duoi}", (int)res.StatusCode, so[^3..]);
                return res.IsSuccessStatusCode;
            }
            catch (Exception ex) { _log.LogError(ex, "Gửi SMS OTP thất bại"); return false; }
        }

        private async Task<bool> GuiMailAsync(string kenh, string nguoiNhan, string otp)
        {
            var host = _cfg["Smtp:Host"];
            if (kenh != "email" || string.IsNullOrWhiteSpace(host) || !nguoiNhan.Contains('@')) return false;
            try
            {
                using var client = new System.Net.Mail.SmtpClient(host, _cfg.GetValue<int?>("Smtp:Port") ?? 587)
                {
                    EnableSsl = _cfg.GetValue<bool?>("Smtp:Ssl") ?? true,
                    Credentials = new System.Net.NetworkCredential(_cfg["Smtp:User"], _cfg["Smtp:Password"]),
                };
                var from = _cfg["Smtp:From"] ?? _cfg["Smtp:User"] ?? "no-reply@foodservice.local";
                using var msg = new System.Net.Mail.MailMessage(from, nguoiNhan, "Mã xác thực FoodService",
                    $"Mã xác thực của bạn là {otp}. Mã có hiệu lực 5 phút, không chia sẻ mã này cho bất kỳ ai.");
                await client.SendMailAsync(msg);
                return true;
            }
            catch (Exception ex) { _log.LogError(ex, "Gửi email OTP thất bại"); return false; }
        }
    }
}
