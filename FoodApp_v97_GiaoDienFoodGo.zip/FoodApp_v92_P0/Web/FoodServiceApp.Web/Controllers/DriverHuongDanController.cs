using Microsoft.AspNetCore.Mvc;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>Hướng dẫn và quy định giao hàng cho tài xế (quy trình, thời hạn phản hồi, COD, sự cố).</summary>
    [Route("TaiXe/HuongDan")]
    public class DriverHuongDanController : TaiXeBaseController
    {
        private readonly AppDbContext _db;
        public DriverHuongDanController(AppDbContext db) { _db = db; }

        [HttpGet("")]
        public async Task<IActionResult> Index()
        {
            ViewBag.PhutPhanHoi = await GiaoHangXuLy.LayPhutPhanHoiAsync(_db);
            return View();
        }
    }
}
