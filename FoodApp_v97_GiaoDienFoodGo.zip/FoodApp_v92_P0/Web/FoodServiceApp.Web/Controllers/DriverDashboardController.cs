using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;

namespace FoodServiceApp.Web.Controllers
{
    [Route("TaiXe")]
    public class DriverDashboardController : TaiXeBaseController
    {
        private readonly AppDbContext _db;

        public DriverDashboardController(AppDbContext db)
        {
            _db = db;
        }

        [HttpGet("")]
        [HttpGet("Dashboard")]
        public async Task<IActionResult> Index()
        {
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == CurrentTaiXeId);
            var homNay = DateTime.Today;

            ViewBag.TaiXe = taiXe;
            ViewBag.SoDonHomNay = await _db.GiaoHangs.CountAsync(g =>
                g.MaTaiXe == CurrentTaiXeId && g.TrangThai == "GiaoThanhCong" && g.ThoiGianGiao >= homNay);
            ViewBag.ThuNhapHomNay = await _db.GiaoHangs
                .Include(g => g.DonHang)
                .Where(g => g.MaTaiXe == CurrentTaiXeId && g.TrangThai == "GiaoThanhCong" && g.ThoiGianGiao >= homNay)
                .SumAsync(g => Math.Round(g.DonHang!.PhiGiaoHang * (g.DonHang.TyLeTaiXe ?? 1m), 0));   // v83: tài xế nhận theo tỉ lệ chia

            ViewBag.DonDangGiao = await _db.DonHangs
                .Include(d => d.GianHang)
                .Include(d => d.ChiTiets)
                .Where(d => d.MaTaiXe == CurrentTaiXeId && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao"))
                .Include(d => d.GiaoHang)
                .FirstOrDefaultAsync();

            ViewBag.SoDonChoNhan = await _db.DonHangs.CountAsync(d =>
                d.TrangThai == "DaXacNhan" && d.MaTaiXe == null && d.NguonGiao != "Quan"
                && _db.CauHinhHeThongs.Any(c => c.Khoa == FoodServiceApp.Web.Services.GiaoHangXuLy.KhoaQuanTriDieuPhoi && c.GiaTri == "0"));
            ViewBag.QuanTriDieuPhoi = await FoodServiceApp.Web.Services.GiaoHangXuLy.QuanTriDieuPhoiAsync(_db);

            return View();
        }

        [HttpPost("ToggleSanSang")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ToggleSanSang()
        {
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == CurrentTaiXeId);

            if (taiXe.TrangThaiDuyet != "DaDuyet")
            {
                TempData["LoiThongBao"] = "Hồ sơ tài xế chưa được duyệt, chưa thể bật trạng thái nhận đơn.";
                return RedirectToAction("Index");
            }

            if (taiXe.TrangThai == "DangGiao")
            {
                TempData["LoiThongBao"] = "Bạn đang trong chuyến giao, không thể chuyển trạng thái.";
                return RedirectToAction("Index");
            }

            // Công tắc Online/Offline: Offline -> Online (sẵn sàng); đang online (sẵn sàng hoặc tạm nghỉ) -> Offline
            taiXe.TrangThai = taiXe.TrangThai == "NgoaiTuyen" ? "SanSang" : "NgoaiTuyen";
            await _db.SaveChangesAsync();
            return RedirectToAction("Index");
        }

        /// <summary>Công tắc "Sẵn sàng nhận đơn" (chỉ khi đang online): SanSang &lt;-&gt; TamNghi.</summary>
        [HttpPost("ToggleNhanDon")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ToggleNhanDon()
        {
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == CurrentTaiXeId);
            if (taiXe.TrangThaiDuyet != "DaDuyet") { TempData["LoiThongBao"] = "Hồ sơ tài xế chưa được duyệt, chưa thể bật trạng thái nhận đơn."; return RedirectToAction("Index"); }
            if (taiXe.TrangThai == "DangGiao") { TempData["LoiThongBao"] = "Bạn đang trong chuyến giao, không thể chuyển trạng thái."; return RedirectToAction("Index"); }
            if (taiXe.TrangThai == "NgoaiTuyen") { TempData["LoiThongBao"] = "Hãy bật Online trước khi bật nhận đơn."; return RedirectToAction("Index"); }
            taiXe.TrangThai = taiXe.TrangThai == "SanSang" ? "TamNghi" : "SanSang";
            await _db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
    }
}
