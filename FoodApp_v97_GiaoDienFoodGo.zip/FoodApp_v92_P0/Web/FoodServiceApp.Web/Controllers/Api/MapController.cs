using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Concurrent;
using Microsoft.Extensions.Options;
using FoodServiceApp.Web.Services.Configs;
using FoodServiceApp.Web.Services.Maps;

namespace FoodServiceApp.Web.Controllers.Api
{
    public record DeliveryFeeRequest(string DiaChiGianHang, string DiaChiKhachHang);
    public record DiemLoTrinhReq(int MaDon, string Loai, string DiaChi, bool? DaLayTruoc);
    public record ViTriReq(double Lat, double Lng);
    public record LoTrinhReq(List<DiemLoTrinhReq>? Diem, ViTriReq? BatDau);
    public record DuongDiReq(ViTriReq Tu, ViTriReq Den);
    public record GeocodeReq(string DiaChi);

    [ApiController]
    [Route("api/map")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class MapController : ControllerBase
    {
        private readonly IGoongMapsService _mapsService;
        private const decimal PhiMoiKm = 5000m; // VNĐ/km, có thể đưa vào appsettings

        private readonly GoongMapsSettings _goong;
        private const int ToiDaDiem = 8;                      // 8 điểm → tối đa 56 + 8 lượt gọi DistanceMatrix (có nhớ đệm)
        private static readonly ConcurrentDictionary<string, GeoPoint> _toaDo = new();
        private static readonly ConcurrentDictionary<string, DistanceResult> _quangDuong = new();

        public MapController(IGoongMapsService mapsService, IOptions<GoongMapsSettings> goong)
        {
            _mapsService = mapsService;
            _goong = goong.Value;
        }

        private bool CoKhoaGoong => GoongKhoa.Co(_goong);
        private static string KhoaDiem(GeoPoint p) => $"{p.Lat:0.00005},{p.Lng:0.00005}";

        /// <summary>
        /// POST /api/map/lo-trinh — tối ưu thứ tự lấy/giao nhiều đơn theo ĐƯỜNG THẬT (Goong DistanceMatrix, xe máy).
        /// Địa chỉ được geocode (nhớ đệm); không có khóa Goong hoặc địa chỉ không tìm được tọa độ → trả lỗi để app dùng bản ước tính.
        /// </summary>
        [HttpPost("lo-trinh")]
        public async Task<IActionResult> LoTrinh(LoTrinhReq r)
        {
            var ds = (r.Diem ?? new()).Where(d => !string.IsNullOrWhiteSpace(d.DiaChi)).ToList();
            if (ds.Count < 2) return BadRequest(new { duongThat = false, message = "Cần ít nhất 2 điểm." });
            if (ds.Count > ToiDaDiem) return BadRequest(new { duongThat = false, message = $"Tối đa {ToiDaDiem} điểm mỗi lần." });
            if (!CoKhoaGoong) return StatusCode(503, new { duongThat = false, message = "Máy chủ chưa cấu hình khóa Goong Maps (GoongMaps:ApiKey)." });

            try
            {
                var diem = new List<GeoPoint>();
                foreach (var d in ds)
                {
                    var key = d.DiaChi.Trim().ToLowerInvariant();
                    if (!_toaDo.TryGetValue(key, out var p))
                    {
                        var g = await _mapsService.GeocodeAsync(d.DiaChi);
                        if (g == null) return UnprocessableEntity(new { duongThat = false, message = $"Không tìm thấy tọa độ cho: {d.DiaChi}" });
                        _toaDo[key] = p = g;
                    }
                    diem.Add(p);
                }

                int n = diem.Count;
                var kc = new double[n, n]; var phut = new int[n, n];
                var viec = new List<Task>();
                var cong = new SemaphoreSlim(4);
                for (int i = 0; i < n; i++)
                    for (int j = 0; j < n; j++)
                    {
                        if (i == j) continue;
                        int a = i, b = j;
                        viec.Add(Task.Run(async () =>
                        {
                            var k = KhoaDiem(diem[a]) + ">" + KhoaDiem(diem[b]);
                            if (!_quangDuong.TryGetValue(k, out var kq))
                            {
                                await cong.WaitAsync();
                                try { kq = await _mapsService.GetDistanceAsync(diem[a], diem[b]) ?? throw new InvalidOperationException("Goong không trả khoảng cách."); }
                                finally { cong.Release(); }
                                _quangDuong[k] = kq;
                            }
                            kc[a, b] = kq.DistanceKm; phut[a, b] = kq.DurationMinutes;
                        }));
                    }
                await Task.WhenAll(viec);

                double[]? tuDau = null; int[]? phutDau = null;
                if (r.BatDau is { } bd)
                {
                    var goc = new GeoPoint(bd.Lat, bd.Lng);
                    tuDau = new double[n]; phutDau = new int[n];
                    for (int i = 0; i < n; i++)
                    {
                        var k = KhoaDiem(goc) + ">" + KhoaDiem(diem[i]);
                        if (!_quangDuong.TryGetValue(k, out var kq))
                        {
                            kq = await _mapsService.GetDistanceAsync(goc, diem[i]) ?? throw new InvalidOperationException("Goong không trả khoảng cách.");
                            _quangDuong[k] = kq;
                        }
                        tuDau[i] = kq.DistanceKm; phutDau[i] = kq.DurationMinutes;
                    }
                }

                var cacDiem = ds.Select(d => new DiemLoTrinh(d.MaDon, !string.Equals(d.Loai, "giao", StringComparison.OrdinalIgnoreCase), d.DaLayTruoc == true)).ToList();
                var (thuTu, tongKm) = LoTrinhToiUu.Giai(cacDiem, kc, tuDau);
                var goc2 = Enumerable.Range(0, n).ToList();     // thứ tự người gửi cung cấp (để so sánh)
                var kmGoc = LoTrinhToiUu.TongTheoThuTu(goc2, kc, tuDau);

                var (heSo, nhanGio) = GiaoThongTheoGio.Lay(DateTime.Now);
                int tongPhut = 0; var buoc = new List<object>();
                for (int s = 0; s < thuTu.Count; s++)
                {
                    int i = thuTu[s];
                    double km = s == 0 ? (tuDau?[i] ?? 0) : kc[thuTu[s - 1], i];
                    int ph = s == 0 ? (phutDau?[i] ?? 0) : phut[thuTu[s - 1], i];
                    tongPhut += ph;
                    buoc.Add(new { maDon = ds[i].MaDon, loai = cacDiem[i].LaLayHang ? "lay" : "giao", diaChi = ds[i].DiaChi, km = Math.Round(km, 1), phut = (int)Math.Ceiling(ph * heSo), phutKhongKetXe = ph });
                }
                // Kẹt xe: Goong không có dữ liệu thời gian thực → nhân hệ số theo khung giờ (cao điểm sáng/trưa/chiều, đêm vắng)
                int tongPhutKetXe = (int)Math.Ceiling(tongPhut * heSo);

                // Đường đi chi tiết để vẽ bản đồ (từng chặng; lỗi một chặng thì bỏ qua, app vẽ đường thẳng)
                var cacChang = new List<List<double[]>>();
                var thuTuDiem = thuTu.Select(i => diem[i]).ToList();
                var diemDi = new List<GeoPoint>();
                if (r.BatDau is { } bd0) diemDi.Add(new GeoPoint(bd0.Lat, bd0.Lng));
                diemDi.AddRange(thuTuDiem);
                for (int c = 1; c < diemDi.Count; c++)
                {
                    try
                    {
                        var ct = await _mapsService.GetRouteAsync(diemDi[c - 1], diemDi[c]);
                        cacChang.Add(ct?.Path.Select(p => new[] { p.Lat, p.Lng }).ToList() ?? new List<double[]>());
                    }
                    catch { cacChang.Add(new List<double[]>()); }
                }

                // Chỉ so sánh với thứ tự gốc khi thứ tự gốc hợp lệ (lấy trước giao)
                bool gocHopLe = LoTrinhHopLe(cacDiem, goc2);
                return Ok(new
                {
                    duongThat = true,
                    nguon = "Goong DistanceMatrix (xe máy)",
                    tongKm = Math.Round(tongKm, 1),
                    tongPhut = tongPhutKetXe,
                    tongPhutKhongKetXe = tongPhut,
                    heSoKetXe = heSo,
                    ghiChuKetXe = $"Đã nhân hệ số {heSo:0.##} cho {nhanGio} (ước tính theo khung giờ, không phải dữ liệu giao thông thời gian thực).",
                    kmThuTuGoc = gocHopLe ? Math.Round(kmGoc, 1) : (double?)null,
                    buoc,
                    diem = thuTuDiem.Select((p, i) => new { lat = p.Lat, lng = p.Lng, maDon = ds[thuTu[i]].MaDon, loai = cacDiem[thuTu[i]].LaLayHang ? "lay" : "giao" }).ToList(),
                    batDau = r.BatDau is { } b0 ? new { lat = b0.Lat, lng = b0.Lng } : null,
                    chang = cacChang,
                });
            }
            catch (Exception ex) when (ex is HttpRequestException or InvalidOperationException or TaskCanceledException)
            {
                return StatusCode(502, new { duongThat = false, message = "Không lấy được quãng đường từ dịch vụ bản đồ: " + ex.Message });
            }
        }

        private static bool LoTrinhHopLe(List<DiemLoTrinh> d, List<int> t)
        {
            var da = d.Where(x => x.DaLayTruoc).Select(x => x.MaDon).ToHashSet();
            foreach (var i in t) { if (d[i].LaLayHang) da.Add(d[i].MaDon); else if (!da.Contains(d[i].MaDon)) return false; }
            return true;
        }

        /// <summary>
        /// POST /api/map/duong-di — đường đi THẬT (Goong Direction, xe máy) giữa 2 tọa độ để app vẽ lên bản đồ.
        /// Trả duongThat=false + lyDo khi chưa có khóa Goong / Goong không trả đường (app tự dùng đường thẳng ước tính và báo rõ cho người dùng).
        /// </summary>
        [HttpPost("duong-di")]
        public async Task<IActionResult> DuongDi(DuongDiReq r)
        {
            if (r?.Tu == null || r.Den == null) return BadRequest(new { message = "Thiếu tọa độ." });
            if (!CoKhoangCachHopLe(r.Tu) || !CoKhoangCachHopLe(r.Den)) return BadRequest(new { message = "Tọa độ không hợp lệ." });
            if (!CoKhoaGoong) return Ok(new { duongThat = false, lyDo = "Máy chủ chưa cấu hình khóa Goong (Admin → Kỹ thuật → Khóa bản đồ Goong)." });
            try
            {
                var kq = await _mapsService.GetRouteAsync(new GeoPoint(r.Tu.Lat, r.Tu.Lng), new GeoPoint(r.Den.Lat, r.Den.Lng));
                if (kq == null || kq.Path.Count < 2)
                    return Ok(new { duongThat = false, lyDo = "Goong không tìm được tuyến đường giữa hai điểm này (đường bị chặn, ngoài vùng hỗ trợ hoặc tọa độ không nằm trên đường)." });
                var (heSo, nhan) = GiaoThongTheoGio.Lay(DateTime.Now);
                return Ok(new
                {
                    duongThat = true,
                    km = kq.DistanceKm,
                    phut = (int)Math.Ceiling(kq.DurationMinutes * heSo),
                    phutDuongThoang = kq.DurationMinutes,
                    heSoKetXe = heSo,
                    khungGio = nhan,
                    polyline = MaHoaPolyline(kq.Path),
                });
            }
            catch (Exception ex) { return Ok(new { duongThat = false, lyDo = "Lỗi khi hỏi Goong: " + ex.Message }); }
        }

        /// <summary>POST /api/map/geocode — đổi địa chỉ thành tọa độ (Goong). Dùng cho màn hình kiểm thử bản đồ của quản trị.</summary>
        [HttpPost("geocode")]
        public async Task<IActionResult> Geocode(GeocodeReq r)
        {
            if (string.IsNullOrWhiteSpace(r?.DiaChi)) return BadRequest(new { message = "Thiếu địa chỉ." });
            if (!CoKhoaGoong) return Ok(new { timThay = false, lyDo = "Máy chủ chưa cấu hình khóa Goong." });
            try
            {
                var p = await _mapsService.GeocodeAsync(r.DiaChi.Trim());
                return p == null ? Ok(new { timThay = false, lyDo = "Goong không tìm thấy địa chỉ này." }) : Ok(new { timThay = true, lat = p.Lat, lng = p.Lng });
            }
            catch (Exception ex) { return Ok(new { timThay = false, lyDo = "Lỗi khi hỏi Goong: " + ex.Message }); }
        }

        private static bool CoKhoangCachHopLe(ViTriReq p) => p.Lat is >= -90 and <= 90 && p.Lng is >= -180 and <= 180;

        /// <summary>Mã hóa danh sách điểm thành Google/Goong encoded polyline (5 chữ số) — cùng định dạng app giải mã.</summary>
        private static string MaHoaPolyline(IEnumerable<GeoPoint> pts)
        {
            var sb = new System.Text.StringBuilder(); long pLat = 0, pLng = 0;
            void Ghi(long v)
            {
                v = v < 0 ? ~(v << 1) : v << 1;
                while (v >= 0x20) { sb.Append((char)((0x20 | (int)(v & 0x1f)) + 63)); v >>= 5; }
                sb.Append((char)((int)v + 63));
            }
            foreach (var p in pts)
            {
                long la = (long)Math.Round(p.Lat * 1e5), ln = (long)Math.Round(p.Lng * 1e5);
                Ghi(la - pLat); Ghi(ln - pLng); pLat = la; pLng = ln;
            }
            return sb.ToString();
        }

        // POST /api/map/phi-giao-hang — dùng chung cho mobile Khách hàng (ước tính phí trước khi đặt)
        [HttpPost("phi-giao-hang")]
        public async Task<IActionResult> TinhPhiGiaoHang(DeliveryFeeRequest request)
        {
            var diemGian = await _mapsService.GeocodeAsync(request.DiaChiGianHang);
            var diemKhach = await _mapsService.GeocodeAsync(request.DiaChiKhachHang);

            if (diemGian == null || diemKhach == null)
                return BadRequest(new { message = "Không tìm thấy tọa độ cho địa chỉ đã nhập." });

            var ketQua = await _mapsService.GetDistanceAsync(diemGian, diemKhach);
            if (ketQua == null)
                return BadRequest(new { message = "Không tính được khoảng cách giữa hai địa điểm." });

            var phiGiaoHang = Math.Ceiling((decimal)ketQua.DistanceKm) * PhiMoiKm;

            return Ok(new
            {
                khoangCachKm = ketQua.DistanceKm,
                thoiGianPhutDuKien = ketQua.DurationMinutes,
                phiGiaoHang
            });
        }
    }
}
