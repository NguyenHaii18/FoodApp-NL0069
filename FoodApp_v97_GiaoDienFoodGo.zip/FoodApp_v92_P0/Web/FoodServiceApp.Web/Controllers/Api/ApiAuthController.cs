using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Dtos;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    [ApiController]
    [Route("api/auth")]
    public class ApiAuthController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly IConfiguration _config;

        public ApiAuthController(AppDbContext db, IConfiguration config)
        {
            _db = db;
            _config = config;
        }

        // Dùng chung 1 endpoint cho cả KhachHang / GianHang / QuanTri / TaiXe —
        // MAUI truyền lên đúng vai trò đang đăng nhập ở màn hình tương ứng.
        [HttpPost("login/{vaiTro}")]
        public async Task<IActionResult> Login(string vaiTro, LoginRequest request)
        {
            var vaiTroHopLe = new[] { "KhachHang", "GianHang", "QuanTri", "TaiXe" };
            if (!vaiTroHopLe.Contains(vaiTro))
                return BadRequest(new { message = "Vai trò không hợp lệ." });

            var taiKhoan = await _db.TaiKhoans.FirstOrDefaultAsync(t =>
                t.TenDangNhap == request.TenDangNhap && t.VaiTro == vaiTro);

            // Kiểm tra mật khẩu BCrypt (tương thích dữ liệu cũ) + khóa tạm khi nhập sai nhiều lần (BaoMat.KhopAsync).
            if (taiKhoan == null || !await BaoMat.KhopAsync(_db, HttpContext, request.MatKhau, taiKhoan))
                return Unauthorized(new { message = "Tên đăng nhập hoặc mật khẩu không đúng." });

            if (!taiKhoan.TrangThai)
                return Unauthorized(new { message = "Tài khoản đã bị khoá." });

            string hoTenHienThi = vaiTro switch
            {
                "GianHang" => (await _db.GianHangs.FirstAsync(g => g.MaTK == taiKhoan.MaTK)).TenCuaHang,
                "QuanTri" => (await _db.QuanTris.FirstAsync(q => q.MaTK == taiKhoan.MaTK)).HoTen,
                "TaiXe" => (await _db.TaiXes.FirstAsync(t => t.MaTK == taiKhoan.MaTK)).HoTen,
                "KhachHang" => (await _db.KhachHangs.FirstAsync(k => k.MaTK == taiKhoan.MaTK)).HoTen,
                _ => taiKhoan.TenDangNhap,
            };

            var token = TaoJwtToken(taiKhoan.MaTK, taiKhoan.TenDangNhap, vaiTro);
            return Ok(new LoginResponse(token, vaiTro, taiKhoan.MaTK, hoTenHienThi));
        }

        /// <summary>
        /// POST api/auth/login — đăng nhập không cần chọn vai trò: tìm tài khoản theo tên đăng nhập rồi chạy đúng luồng của vai trò đó
        /// (kiểm tra mật khẩu BCrypt, khóa tạm khi sai nhiều lần, tài khoản bị khóa). Sai tên hoặc mật khẩu đều trả cùng một thông báo.
        /// </summary>
        [HttpPost("login")]
        public async Task<IActionResult> LoginTuDong(LoginRequest request)
        {
            var vaiTro = await _db.TaiKhoans.AsNoTracking()
                .Where(t => t.TenDangNhap == request.TenDangNhap)
                .Select(t => t.VaiTro).FirstOrDefaultAsync();
            if (vaiTro == null) return Unauthorized(new { message = "Tên đăng nhập hoặc mật khẩu không đúng." });
            return await Login(vaiTro, request);
        }

        /// <summary>Đăng xuất khỏi MỌI thiết bị: thu hồi toàn bộ token đã cấp cho tài khoản này (token cấp sau lúc này vẫn dùng được).</summary>
        [HttpPost("dang-xuat-tat-ca")]
        [Microsoft.AspNetCore.Authorization.Authorize(AuthenticationSchemes = Microsoft.AspNetCore.Authentication.JwtBearer.JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DangXuatTatCa()
        {
            if (!int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var maTk)) return Unauthorized();
            var tk = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == maTk);
            if (tk == null) return Unauthorized();
            PhienJwt.ThuHoi(tk);
            await _db.SaveChangesAsync();
            PhienJwt.XoaCache(HttpContext.RequestServices.GetRequiredService<Microsoft.Extensions.Caching.Memory.IMemoryCache>(), maTk);
            return Ok(new { message = "Đã đăng xuất khỏi mọi thiết bị." });
        }

        private string TaoJwtToken(int maTK, string tenDangNhap, string vaiTro)
        {
            var jwtSection = _config.GetSection("Jwt");
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSection["Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, maTK.ToString()),
                new Claim(ClaimTypes.Name, tenDangNhap),
                new Claim(ClaimTypes.Role, vaiTro),
            };

            var token = new JwtSecurityToken(
                issuer: jwtSection["Issuer"],
                audience: jwtSection["Audience"],
                claims: claims,
                notBefore: DateTime.UtcNow,
                expires: DateTime.UtcNow.AddHours(double.Parse(jwtSection["ExpireHours"]!)),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
