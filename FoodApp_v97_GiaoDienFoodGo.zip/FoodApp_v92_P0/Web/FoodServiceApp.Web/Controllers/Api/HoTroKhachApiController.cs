using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// Hỗ trợ khách hàng trên app: báo thiếu món, giao sai, giao trễ, yêu cầu hoàn tiền, khiếu nại, góp ý (bảng PhanHoi — quản trị xử lý ở mục Khiếu nại).
    /// Khách chỉ thấy và bổ sung phản hồi của chính mình; đơn gắn kèm phải là đơn của khách.
    /// </summary>
    [ApiController]
    [Route("api/mobile/khach-hang/ho-tro")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
    public class HoTroKhachApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        public HoTroKhachApiController(AppDbContext db) { _db = db; }

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static IActionResult Loi(string thongDiep, int status = 400) => new ObjectResult(new { thongDiep }) { StatusCode = status };

        // mã loại vấn đề → (nhãn, Loai, PhanLoai khớp bộ phân loại của quản trị)
        private static readonly Dictionary<string, (string Nhan, string Loai, string PhanLoai, bool CanDon)> LoaiVanDe = new()
        {
            ["ThieuMon"] = ("Thiếu món", "KhieuNai", "MonAn", true),
            ["GiaoSai"] = ("Giao sai món", "KhieuNai", "DonHang", true),
            ["GiaoTre"] = ("Giao trễ", "KhieuNai", "TaiXe", true),
            ["NhaHangHuy"] = ("Nhà hàng hủy đơn", "KhieuNai", "GianHang", true),
            ["HoanTien"] = ("Yêu cầu hoàn tiền", "KhieuNai", "ThanhToan", true),
            ["ChatLuong"] = ("Chất lượng món", "KhieuNai", "MonAn", true),
            ["KhieuNai"] = ("Khiếu nại khác", "KhieuNai", "Khac", false),
            ["GopY"] = ("Góp ý", "GopY", "Khac", false),
        };

        public record TaoHoTroReq(string? LoaiVanDe, int? MaDonHang, string? NoiDung, List<string>? Anh);
        public record BoSungReq(string? NoiDung);

        private static string Cat(string s, int n) => s.Length > n ? s[..n] : s;

        [HttpGet("")]
        public async Task<IActionResult> DanhSach()
        {
            var kh = await _db.KhachHangs.AsNoTracking().FirstOrDefaultAsync(k => k.MaTK == MaTK);
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            var ds = await _db.PhanHois.AsNoTracking().Where(p => p.MaKH == kh.MaKH)
                .OrderByDescending(p => p.NgayGui).Take(50)
                .Select(p => new
                {
                    id = p.MaPhanHoi, maDonHang = p.MaDonHang, loai = p.Loai, tieuDe = p.TieuDe, noiDung = p.NoiDung,
                    trangThai = p.TrangThai, traLoi = p.TraLoi ?? "", yeuCauBoSung = p.YeuCauBoSung ?? "",
                    ngayGui = p.NgayGui, ngayXuLy = p.NgayXuLy
                }).ToListAsync();
            return Ok(ds);
        }

        [HttpPost("")]
        public async Task<IActionResult> Tao(TaoHoTroReq r)
        {
            var kh = await _db.KhachHangs.FirstOrDefaultAsync(k => k.MaTK == MaTK);
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            if (r.LoaiVanDe == null || !LoaiVanDe.TryGetValue(r.LoaiVanDe, out var lv)) return Loi("Loại vấn đề không hợp lệ.");
            var nd = (r.NoiDung ?? "").Trim();
            if (nd.Length < 5) return Loi("Hãy mô tả vấn đề (ít nhất 5 ký tự).");

            int? maGianHang = null;
            if (r.MaDonHang is int maDon)
            {
                var don = await _db.DonHangs.AsNoTracking().FirstOrDefaultAsync(d => d.MaDonHang == maDon && d.MaKH == kh.MaKH);
                if (don == null) return Loi("Đơn hàng không hợp lệ.", 404);
                maGianHang = don.MaGianHang;
            }
            else if (lv.CanDon) return Loi("Hãy chọn đơn hàng liên quan.");

            var homNay = DateTime.Now.Date;
            if (await _db.PhanHois.CountAsync(p => p.MaKH == kh.MaKH && p.NgayGui >= homNay) >= 10)
                return Loi("Bạn đã gửi quá nhiều yêu cầu hôm nay. Vui lòng thử lại vào ngày mai.", 429);
            if (r.MaDonHang != null && await _db.PhanHois.AnyAsync(p => p.MaKH == kh.MaKH && p.MaDonHang == r.MaDonHang && p.TieuDe.StartsWith(lv.Nhan) && p.TrangThai == "ChuaXuLy"))
                return Loi("Bạn đã gửi yêu cầu này cho đơn đó và đang chờ xử lý. Hãy dùng nút Bổ sung trong danh sách.", 409);

            var anh = (r.Anh ?? new List<string>()).Select(a => (a ?? "").Trim()).Where(a => a.Length > 0).Distinct().Take(3).ToList();
            var noiDung = anh.Count == 0 ? nd : nd + "\n📷 " + string.Join("\n📷 ", anh);
            var ph = new PhanHoi
            {
                MaKH = kh.MaKH, MaDonHang = r.MaDonHang, MaGianHang = maGianHang, Loai = lv.Loai, PhanLoai = lv.PhanLoai,
                TieuDe = r.MaDonHang != null ? $"{lv.Nhan} — đơn #{r.MaDonHang}" : lv.Nhan,
                NoiDung = Cat(noiDung, 1000), TrangThai = "ChuaXuLy"
            };
            _db.PhanHois.Add(ph);
            await _db.SaveChangesAsync();
            return Ok(new { id = ph.MaPhanHoi, thongDiep = "Đã gửi tới bộ phận hỗ trợ. Chúng tôi sẽ phản hồi sớm." });
        }

        [HttpPost("{id:int}/bo-sung")]
        public async Task<IActionResult> BoSung(int id, BoSungReq r)
        {
            var kh = await _db.KhachHangs.AsNoTracking().FirstOrDefaultAsync(k => k.MaTK == MaTK);
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            var ph = await _db.PhanHois.FirstOrDefaultAsync(p => p.MaPhanHoi == id && p.MaKH == kh.MaKH);
            if (ph == null) return Loi("Không tìm thấy yêu cầu.", 404);
            var nd = (r.NoiDung ?? "").Trim();
            if (nd.Length < 3) return Loi("Nội dung bổ sung quá ngắn.");
            ph.NoiDung = Cat($"{ph.NoiDung}\n[Bổ sung {DateTime.Now:dd/MM HH:mm}] {nd}", 1000);
            ph.YeuCauBoSung = null;
            ph.TrangThai = "ChuaXuLy";
            ph.TraLoi = null; ph.NgayXuLy = null;
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã gửi bổ sung cho bộ phận hỗ trợ." });
        }
    }
}
