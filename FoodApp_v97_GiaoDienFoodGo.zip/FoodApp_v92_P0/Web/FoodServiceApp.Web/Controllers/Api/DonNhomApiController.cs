using System.Collections.Concurrent;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// Đơn hàng nhóm: một người (chủ nhóm) tạo nhóm cho một gian hàng và chia sẻ mã; những người khác vào nhóm bằng mã
    /// và tự chọn món. Chủ nhóm gom món vào giỏ rồi đặt đơn bằng luồng đặt hàng thường (nên giá, khuyến mãi và thanh toán
    /// vẫn do máy chủ kiểm tra như mọi đơn).
    /// LƯU Ý: nhóm lưu TRONG BỘ NHỚ máy chủ (tự hết hạn sau 2 giờ) nên mất khi máy chủ khởi động lại — đủ cho một bữa ăn chung,
    /// chưa phải dữ liệu lâu dài.
    /// </summary>
    [ApiController]
    [Route("api/mobile/don-nhom")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
    public class DonNhomApiController : ControllerBase
    {
        public sealed class MonNhom { public int MonAnId { get; set; } public int SoLuong { get; set; } }
        public sealed class ThanhVienNhom { public int MaTK { get; set; } public string Ten { get; set; } = ""; public List<MonNhom> Mon { get; set; } = new(); public bool Xong { get; set; } }
        public sealed class Nhom
        {
            public string Ma { get; set; } = "";
            public string GianHangId { get; set; } = "";
            public string TenGianHang { get; set; } = "";
            public int ChuNhom { get; set; }
            public bool DaChot { get; set; }
            public DateTime TaoLuc { get; set; } = DateTime.Now;
            public List<ThanhVienNhom> ThanhVien { get; set; } = new();
            public readonly object Khoa = new();
        }

        private static readonly ConcurrentDictionary<string, Nhom> Ds = new();
        private const int HetHanGio = 2;
        private const int ToiDaThanhVien = 10;
        private const int ToiDaMon = 30;

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static ObjectResult Loi(string m, int status = 400) => new(new { thongDiep = m }) { StatusCode = status };

        private static void Don()
        {
            foreach (var k in Ds.Where(x => (DateTime.Now - x.Value.TaoLuc).TotalHours > HetHanGio).Select(x => x.Key).ToList()) Ds.TryRemove(k, out _);
        }

        private static string TaoMa()
        {
            const string kyTu = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";   // bỏ ký tự dễ nhầm (I, O, 0, 1)
            for (int i = 0; i < 20; i++)
            {
                var ma = new string(Enumerable.Range(0, 5).Select(_ => kyTu[Random.Shared.Next(kyTu.Length)]).ToArray());
                if (!Ds.ContainsKey(ma)) return ma;
            }
            return Guid.NewGuid().ToString("N")[..8].ToUpperInvariant();
        }

        private object Dang(Nhom n) => new
        {
            n.Ma, n.GianHangId, n.TenGianHang, laChuNhom = n.ChuNhom == MaTK, n.DaChot, n.TaoLuc,
            thanhVien = n.ThanhVien.Select(t => new { t.Ten, laToi = t.MaTK == MaTK, laChuNhom = t.MaTK == n.ChuNhom, t.Xong, mon = t.Mon }).ToList(),
        };

        public record TaoReq(string GianHangId, string? TenGianHang, string? Ten);
        public record VaoReq(string? Ten);
        public record MonReq(List<MonNhom>? Mon, bool Xong);

        [HttpPost("")]
        public IActionResult Tao(TaoReq r)
        {
            Don();
            if (string.IsNullOrWhiteSpace(r.GianHangId)) return Loi("Thiếu gian hàng.");
            var n = new Nhom { Ma = TaoMa(), GianHangId = r.GianHangId.Trim(), TenGianHang = (r.TenGianHang ?? "").Trim(), ChuNhom = MaTK };
            n.ThanhVien.Add(new ThanhVienNhom { MaTK = MaTK, Ten = string.IsNullOrWhiteSpace(r.Ten) ? "Chủ nhóm" : r.Ten.Trim() });
            Ds[n.Ma] = n;
            return Ok(Dang(n));
        }

        [HttpPost("{ma}/vao")]
        public IActionResult Vao(string ma, VaoReq r)
        {
            Don();
            if (!Ds.TryGetValue(ma.Trim().ToUpperInvariant(), out var n)) return Loi("Không tìm thấy nhóm hoặc nhóm đã hết hạn.", 404);
            lock (n.Khoa)
            {
                if (n.DaChot) return Loi("Nhóm đã chốt đơn, không thể tham gia.");
                if (n.ThanhVien.All(t => t.MaTK != MaTK))
                {
                    if (n.ThanhVien.Count >= ToiDaThanhVien) return Loi($"Nhóm đã đủ {ToiDaThanhVien} người.");
                    n.ThanhVien.Add(new ThanhVienNhom { MaTK = MaTK, Ten = string.IsNullOrWhiteSpace(r.Ten) ? "Thành viên" : r.Ten.Trim() });
                }
                return Ok(Dang(n));
            }
        }

        [HttpGet("{ma}")]
        public IActionResult Xem(string ma)
        {
            Don();
            if (!Ds.TryGetValue(ma.Trim().ToUpperInvariant(), out var n)) return Loi("Không tìm thấy nhóm hoặc nhóm đã hết hạn.", 404);
            lock (n.Khoa)
            {
                if (n.ThanhVien.All(t => t.MaTK != MaTK)) return Loi("Bạn chưa tham gia nhóm này.", 403);
                return Ok(Dang(n));
            }
        }

        /// <summary>Thành viên gửi toàn bộ phần món của mình (thay thế phần cũ). xong = true: đánh dấu đã chọn xong.</summary>
        [HttpPut("{ma}/mon")]
        public IActionResult DatMon(string ma, MonReq r)
        {
            if (!Ds.TryGetValue(ma.Trim().ToUpperInvariant(), out var n)) return Loi("Không tìm thấy nhóm hoặc nhóm đã hết hạn.", 404);
            lock (n.Khoa)
            {
                if (n.DaChot) return Loi("Nhóm đã chốt đơn.");
                var tv = n.ThanhVien.FirstOrDefault(t => t.MaTK == MaTK);
                if (tv == null) return Loi("Bạn chưa tham gia nhóm này.", 403);
                var mon = (r.Mon ?? new()).Where(m => m.MonAnId > 0 && m.SoLuong > 0).GroupBy(m => m.MonAnId)
                    .Select(g => new MonNhom { MonAnId = g.Key, SoLuong = Math.Min(20, g.Sum(x => x.SoLuong)) }).Take(ToiDaMon).ToList();
                tv.Mon = mon; tv.Xong = r.Xong;
                return Ok(Dang(n));
            }
        }

        /// <summary>Chủ nhóm chốt nhóm (không ai thêm/sửa món nữa). Đơn thật được tạo bằng POST api/mobile/don-hang như bình thường.</summary>
        [HttpPut("{ma}/chot")]
        public IActionResult Chot(string ma)
        {
            if (!Ds.TryGetValue(ma.Trim().ToUpperInvariant(), out var n)) return Loi("Không tìm thấy nhóm hoặc nhóm đã hết hạn.", 404);
            lock (n.Khoa)
            {
                if (n.ChuNhom != MaTK) return Loi("Chỉ chủ nhóm mới được chốt.", 403);
                n.DaChot = true;
                return Ok(Dang(n));
            }
        }

        [HttpDelete("{ma}")]
        public IActionResult RoiHoacXoa(string ma)
        {
            if (!Ds.TryGetValue(ma.Trim().ToUpperInvariant(), out var n)) return Ok(new { thongDiep = "Nhóm không còn." });
            lock (n.Khoa)
            {
                if (n.ChuNhom == MaTK) { Ds.TryRemove(n.Ma, out _); return Ok(new { thongDiep = "Đã giải tán nhóm." }); }
                n.ThanhVien.RemoveAll(t => t.MaTK == MaTK);
                return Ok(new { thongDiep = "Đã rời nhóm." });
            }
        }
    }
}
