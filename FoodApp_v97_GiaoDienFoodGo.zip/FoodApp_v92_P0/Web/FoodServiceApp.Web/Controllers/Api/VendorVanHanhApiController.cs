using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// v80 — Vận hành quán nâng cao cho app Đối tác:
    ///   GET  gian-hang/{id}/don-hang/van-hanh        số đơn chờ / đang nấu / sẵn sàng giao, ngưỡng quá tải, mã đơn mới nhất (app dùng để rung/chuông)
    ///   PUT  gian-hang/{id}/cau-hinh-cao-diem        {toiDaDonDong} — chỉ chủ quán
    ///   GET  gian-hang/{id}/mon-an/van-hanh          thời gian chuẩn bị / khung giờ bán / món kèm của từng món
    ///   PUT  gian-hang/{id}/mon-an/{maMon}/van-hanh  cập nhật các trường trên
    ///   GET  gian-hang/{id}/tai-chinh/mon-ban-chay   món bán chạy theo kỳ
    ///   GET  gian-hang/{id}/tai-chinh/doi-soat       lịch sử đối soát theo tháng
    ///   GET  gian-hang/{id}/tai-chinh/xuat-csv       báo cáo đơn hoàn thành (CSV, mở được bằng Excel)
    /// </summary>
    [ApiController]
    [Route("api/mobile")]
    public class VendorVanHanhApiController : ControllerBase
    {
        private const string Jwt = JwtBearerDefaults.AuthenticationScheme;
        private readonly AppDbContext _db;
        public VendorVanHanhApiController(AppDbContext db) => _db = db;

        private int CurrentMaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static IActionResult Loi(string thongDiep, int status = 400) =>
            new ObjectResult(new { thongDiep }) { StatusCode = status };
        private Task<GianHang?> OwnStoreAsync(int id) =>
            _db.GianHangs.FirstOrDefaultAsync(g => g.MaGianHang == id && g.MaTK == CurrentMaTK);

        // ------------------------------------------------------------------ giờ cao điểm
        [HttpGet("gian-hang/{id:int}/don-hang/van-hanh")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> VanHanh(int id)
        {
            var store = await OwnStoreAsync(id);
            if (store == null) return Loi("Không tìm thấy gian hàng.", 403);
            var don = _db.DonHangs.AsNoTracking().Where(d => d.MaGianHang == id);
            var choXacNhan = await don.CountAsync(d => d.TrangThai == "ChoXacNhan");
            var dangNau = await don.CountAsync(d => d.TrangThai == "DaXacNhan" && !d.SanSangGiao);
            var sanSang = await don.CountAsync(d => d.TrangThai == "DaXacNhan" && d.SanSangGiao);
            var maMoiNhat = await don.Where(d => d.TrangThai == "ChoXacNhan").Select(d => (int?)d.MaDonHang).MaxAsync() ?? 0;
            return Ok(new
            {
                choXacNhan, dangNau, sanSangGiao = sanSang, maDonChoMoiNhat = maMoiNhat,
                toiDaDonDong = store.ToiDaDonDong,
                quaTai = store.ToiDaDonDong > 0 && dangNau >= store.ToiDaDonDong
            });
        }

        public record CaoDiemRequest(int ToiDaDonDong);

        [HttpPut("gian-hang/{id:int}/cau-hinh-cao-diem")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> DatCaoDiem(int id, CaoDiemRequest request)
        {
            var store = await OwnStoreAsync(id);
            if (store == null) return Loi("Không tìm thấy gian hàng.", 403);
            if (request.ToiDaDonDong is < 0 or > 200) return Loi("Số đơn tối đa phải từ 0 đến 200 (0 = không giới hạn).");
            store.ToiDaDonDong = request.ToiDaDonDong;
            await _db.SaveChangesAsync();
            return Ok(new { toiDaDonDong = store.ToiDaDonDong });
        }

        // ------------------------------------------------------------------ thông số vận hành của món
        [HttpGet("gian-hang/{id:int}/mon-an/van-hanh")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> DanhSachVanHanhMon(int id)
        {
            if (await OwnStoreAsync(id) == null) return Loi("Không tìm thấy gian hàng.", 403);
            var ds = await _db.MonAns.AsNoTracking().Where(m => m.DanhMuc!.MaGianHang == id)
                .Select(m => new { maMon = m.MaMonAn, m.ThoiGianChuanBiPhut, m.BanTuGio, m.BanDenGio, m.MonAnKem }).ToListAsync();
            return Ok(ds.Select(m => new
            {
                m.maMon,
                thoiGianChuanBiPhut = m.ThoiGianChuanBiPhut,
                banTuGio = m.BanTuGio == null ? null : $"{m.BanTuGio:hh\\:mm}",
                banDenGio = m.BanDenGio == null ? null : $"{m.BanDenGio:hh\\:mm}",
                monAnKem = m.MonAnKem
            }));
        }

        public record MonVanHanhRequest(int? ThoiGianChuanBiPhut, string? BanTuGio, string? BanDenGio, string? MonAnKem);

        [HttpPut("gian-hang/{id:int}/mon-an/{maMon:int}/van-hanh")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> CapNhatVanHanhMon(int id, int maMon, MonVanHanhRequest request)
        {
            if (await OwnStoreAsync(id) == null) return Loi("Không tìm thấy gian hàng.", 403);
            var mon = await _db.MonAns.FirstOrDefaultAsync(m => m.MaMonAn == maMon && m.DanhMuc!.MaGianHang == id);
            if (mon == null) return Loi("Không tìm thấy món.", 404);
            if (request.ThoiGianChuanBiPhut is < 1 or > 180) return Loi("Thời gian chuẩn bị phải từ 1 đến 180 phút.");

            TimeSpan? tu = null, den = null;
            var coTu = !string.IsNullOrWhiteSpace(request.BanTuGio);
            var coDen = !string.IsNullOrWhiteSpace(request.BanDenGio);
            if (coTu != coDen) return Loi("Cần nhập đủ cả giờ bắt đầu và giờ kết thúc bán (hoặc để trống cả hai).");
            if (coTu)
            {
                if (!TimeSpan.TryParse(request.BanTuGio, out var t) || !TimeSpan.TryParse(request.BanDenGio, out var d))
                    return Loi("Khung giờ bán không hợp lệ (định dạng HH:mm).");
                tu = t; den = d;
            }
            var kem = request.MonAnKem?.Trim();
            if (kem != null && kem.Length > 500) return Loi("Danh sách món ăn kèm quá dài (tối đa 500 ký tự).");

            mon.ThoiGianChuanBiPhut = request.ThoiGianChuanBiPhut;
            mon.BanTuGio = tu;
            mon.BanDenGio = den;
            mon.MonAnKem = string.IsNullOrEmpty(kem) ? null : kem;
            await _db.SaveChangesAsync();
            return NoContent();
        }

        // ------------------------------------------------------------------ báo cáo
        private static (DateTime Tu, DateTime Den) Ky(DateTime? tu, DateTime? den)
        {
            var t = (tu ?? DateTime.Today.AddDays(-29)).Date;
            var d = (den ?? DateTime.Today).Date.AddDays(1);
            return (t, d);
        }

        [HttpGet("gian-hang/{id:int}/tai-chinh/mon-ban-chay")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> MonBanChay(int id, DateTime? tu, DateTime? den, int top = 10)
        {
            if (await OwnStoreAsync(id) == null) return Loi("Không tìm thấy gian hàng.", 403);
            var (t, d) = Ky(tu, den);
            top = Math.Clamp(top, 1, 50);
            var ds = await (from c in _db.ChiTietDonHangs
                            join dh in _db.DonHangs on c.MaDonHang equals dh.MaDonHang
                            join m in _db.MonAns on c.MaMonAn equals m.MaMonAn
                            where dh.MaGianHang == id && dh.TrangThai == "DaGiao" && dh.NgayDat >= t && dh.NgayDat < d
                            group c by new { m.MaMonAn, m.TenMon } into g
                            orderby g.Sum(x => x.SoLuong) descending
                            select new { maMon = g.Key.MaMonAn, tenMon = g.Key.TenMon, soLuong = g.Sum(x => x.SoLuong), doanhThu = g.Sum(x => x.SoLuong * x.DonGia) })
                           .Take(top).ToListAsync();
            return Ok(ds);
        }

        [HttpGet("gian-hang/{id:int}/tai-chinh/doi-soat")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> DoiSoat(int id, int soThang = 6)
        {
            var store = await OwnStoreAsync(id);
            if (store == null) return Loi("Không tìm thấy gian hàng.", 403);
            soThang = Math.Clamp(soThang, 1, 24);
            var dauKy = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-(soThang - 1));
            var dong = await (from c in _db.ChiTietDonHangs
                              join dh in _db.DonHangs on c.MaDonHang equals dh.MaDonHang
                              where dh.MaGianHang == id && dh.TrangThai == "DaGiao" && dh.NgayDat >= dauKy
                              select new { dh.MaDonHang, dh.NgayDat, Tien = c.DonGia * c.SoLuong }).ToListAsync();
            var kq = Enumerable.Range(0, soThang).Select(i =>
            {
                var thang = dauKy.AddMonths(i);
                var tuThang = dong.Where(x => x.NgayDat.Year == thang.Year && x.NgayDat.Month == thang.Month).ToList();
                var doanhThu = tuThang.Sum(x => x.Tien);
                var phi = Math.Round(doanhThu * store.TyLeChietKhau, 0);
                return new
                {
                    thang = $"{thang:MM/yyyy}",
                    soDon = tuThang.Select(x => x.MaDonHang).Distinct().Count(),
                    doanhThuMon = doanhThu, phiNenTang = phi, thucNhan = doanhThu - phi
                };
            }).Reverse().ToList();
            return Ok(new { tyLeChietKhau = store.TyLeChietKhau, cacKy = kq });
        }

        [HttpGet("gian-hang/{id:int}/tai-chinh/xuat-csv")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> XuatCsv(int id, DateTime? tu, DateTime? den)
        {
            var store = await OwnStoreAsync(id);
            if (store == null) return Loi("Không tìm thấy gian hàng.", 403);
            var (t, d) = Ky(tu, den);
            var don = await _db.DonHangs.AsNoTracking().Include(x => x.ChiTiets)
                .Where(x => x.MaGianHang == id && x.NgayDat >= t && x.NgayDat < d)
                .OrderBy(x => x.NgayDat).ToListAsync();

            static string O(string? s)
            {
                s ??= "";
                if (s.Length > 0 && "=+-@".Contains(s[0])) s = "'" + s;   // chống chèn công thức khi mở bằng Excel
                return "\"" + s.Replace("\"", "\"\"") + "\"";
            }
            var sb = new StringBuilder();
            sb.Append('﻿');
            sb.AppendLine("Mã đơn,Ngày đặt,Trạng thái,Tiền món,Phí nền tảng,Thực nhận,Lý do hủy/từ chối");
            foreach (var x in don)
            {
                var tien = x.ChiTiets.Sum(c => c.DonGia * c.SoLuong);
                var hoanThanh = x.TrangThai == "DaGiao";
                var phi = hoanThanh ? Math.Round(tien * store.TyLeChietKhau, 0) : 0;
                sb.AppendLine(string.Join(",", x.MaDonHang, x.NgayDat.ToString("yyyy-MM-dd HH:mm"), O(x.TrangThai),
                    hoanThanh ? tien : 0, phi, hoanThanh ? tien - phi : 0, O(x.LyDoTuChoi)));
            }
            return File(Encoding.UTF8.GetBytes(sb.ToString()), "text/csv; charset=utf-8", $"BaoCao_{t:yyyyMMdd}_{d.AddDays(-1):yyyyMMdd}.csv");
        }
    }
}
