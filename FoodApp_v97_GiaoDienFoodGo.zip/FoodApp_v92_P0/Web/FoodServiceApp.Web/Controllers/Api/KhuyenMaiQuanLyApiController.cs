using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// CRUD khuyến mãi cho app MAUI.
    ///  - Gian hàng (JWT, vai trò GianHang): chỉ thấy/sửa mã của CHÍNH gian hàng mình (api/mobile/gian-hang/khuyen-mai).
    ///  - Quản trị (JWT, vai trò QuanTri): xem/sửa mọi mã, tạo mã toàn hệ thống hoặc theo gian hàng (api/mobile/admin/khuyen-mai).
    /// Mọi kiểm tra hợp lệ làm ở máy chủ (app chỉ hiển thị thông điệp lỗi).
    /// </summary>
    [ApiController]
    [Route("api/mobile")]
    public class KhuyenMaiQuanLyApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        public KhuyenMaiQuanLyApiController(AppDbContext db) => _db = db;

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static IActionResult Loi(string thongDiep, int status = 400) => new ObjectResult(new { thongDiep }) { StatusCode = status };
        private const string Jwt = JwtBearerDefaults.AuthenticationScheme;

        public class KhuyenMaiLuuRequest
        {
            public string? MaCode { get; set; }
            public string? TenChuongTrinh { get; set; }
            public string? MoTa { get; set; }
            public string? LoaiGiam { get; set; }                 // PhanTram | SoTien | GiamPhiVanChuyen
            public decimal GiaTriGiam { get; set; }
            public decimal GiaTriDonToiThieu { get; set; }
            public decimal? GiamToiDa { get; set; }
            public DateTime NgayBatDau { get; set; }
            public DateTime NgayKetThuc { get; set; }
            public int? SoLuongToiDa { get; set; }
            public bool MoiKhachMotLan { get; set; }
            public bool DangHoatDong { get; set; } = true;
            public int? GianHangId { get; set; }                  // chỉ Quản trị: null = toàn hệ thống
            public List<string>? MonApDung { get; set; }          // mã món (chuỗi số)
            public List<string>? DanhMucApDung { get; set; }      // tên danh mục
            public List<string>? GianHangApDung { get; set; }     // chỉ Quản trị: giới hạn mã hệ thống cho một số quán
        }
        public record TinhTrangRequest(bool DangHoatDong);

        // ------------------------------------------------------------------ Gian hàng
        private Task<GianHang?> QuanCuaToiAsync() => _db.GianHangs.FirstOrDefaultAsync(g => g.MaTK == MaTK);

        [HttpGet("gian-hang/khuyen-mai")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> DsGianHang()
        {
            var quan = await QuanCuaToiAsync();
            if (quan == null) return Loi("Không tìm thấy gian hàng.", 404);
            return Ok(await DocDsAsync(k => k.MaGianHang == quan.MaGianHang));
        }

        [HttpPost("gian-hang/khuyen-mai")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> TaoGianHang(KhuyenMaiLuuRequest rq)
        {
            var quan = await QuanCuaToiAsync();
            if (quan == null) return Loi("Không tìm thấy gian hàng.", 404);
            if (quan.TrangThaiDuyet != "DaDuyet") return Loi("Gian hàng chưa được duyệt nên chưa tạo được khuyến mãi.", 403);
            return await LuuAsync(null, rq, quan.MaGianHang, vaiTroQuanTri: false);
        }

        [HttpPut("gian-hang/khuyen-mai/{id:int}")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> SuaGianHang(int id, KhuyenMaiLuuRequest rq)
        {
            var quan = await QuanCuaToiAsync();
            if (quan == null) return Loi("Không tìm thấy gian hàng.", 404);
            return await LuuAsync(id, rq, quan.MaGianHang, vaiTroQuanTri: false);
        }

        [HttpPut("gian-hang/khuyen-mai/{id:int}/tinh-trang")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> BatTatGianHang(int id, TinhTrangRequest rq)
        {
            var quan = await QuanCuaToiAsync();
            if (quan == null) return Loi("Không tìm thấy gian hàng.", 404);
            return await BatTatAsync(id, rq.DangHoatDong, quan.MaGianHang);
        }

        [HttpDelete("gian-hang/khuyen-mai/{id:int}")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> XoaGianHang(int id)
        {
            var quan = await QuanCuaToiAsync();
            if (quan == null) return Loi("Không tìm thấy gian hàng.", 404);
            return await XoaAsync(id, quan.MaGianHang);
        }

        // ------------------------------------------------------------------ Quản trị
        [HttpGet("admin/khuyen-mai")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "QuanTri")]
        public async Task<IActionResult> DsQuanTri([FromQuery] int? gianHangId = null)
            => Ok(await DocDsAsync(k => gianHangId == null || k.MaGianHang == gianHangId || k.MaGianHang == null));

        [HttpPost("admin/khuyen-mai")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "QuanTri")]
        public Task<IActionResult> TaoQuanTri(KhuyenMaiLuuRequest rq) => LuuAsync(null, rq, rq.GianHangId, vaiTroQuanTri: true);

        [HttpPut("admin/khuyen-mai/{id:int}")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "QuanTri")]
        public Task<IActionResult> SuaQuanTri(int id, KhuyenMaiLuuRequest rq) => LuuAsync(id, rq, rq.GianHangId, vaiTroQuanTri: true);

        [HttpPut("admin/khuyen-mai/{id:int}/tinh-trang")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "QuanTri")]
        public Task<IActionResult> BatTatQuanTri(int id, TinhTrangRequest rq) => BatTatAsync(id, rq.DangHoatDong, null);

        [HttpDelete("admin/khuyen-mai/{id:int}")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "QuanTri")]
        public Task<IActionResult> XoaQuanTri(int id) => XoaAsync(id, null);

        // ------------------------------------------------------------------ dùng chung
        /// <summary>maGianHangGioiHan != null: chỉ được thao tác mã thuộc gian hàng đó (vai trò Gian hàng).</summary>
        private async Task<KhuyenMai?> TimAsync(int id, int? maGianHangGioiHan)
        {
            var km = await _db.KhuyenMais.FirstOrDefaultAsync(k => k.MaKhuyenMai == id);
            if (km == null) return null;
            if (maGianHangGioiHan != null && km.MaGianHang != maGianHangGioiHan) return null;
            return km;
        }

        private async Task<IActionResult> BatTatAsync(int id, bool bat, int? maGianHangGioiHan)
        {
            var km = await TimAsync(id, maGianHangGioiHan);
            if (km == null) return Loi("Không tìm thấy khuyến mãi.", 404);
            km.TrangThai = bat;
            await _db.SaveChangesAsync();
            return Ok(new { id = km.MaKhuyenMai, dangHoatDong = km.TrangThai });
        }

        private async Task<IActionResult> XoaAsync(int id, int? maGianHangGioiHan)
        {
            var km = await TimAsync(id, maGianHangGioiHan);
            if (km == null) return Loi("Không tìm thấy khuyến mãi.", 404);
            // Mã đã có đơn dùng: giữ lại để đối soát (đơn/đối soát còn tham chiếu), chỉ cho tắt.
            if (km.SoLuongDaDung > 0 || await _db.KhuyenMaiKhachDungs.AnyAsync(x => x.MaKhuyenMai == id))
                return Loi("Mã này đã được khách sử dụng nên không xóa được (để đối soát). Hãy tắt mã thay vì xóa.", 409);
            _db.KhuyenMaiMonAns.RemoveRange(_db.KhuyenMaiMonAns.Where(x => x.MaKhuyenMai == id));
            _db.KhuyenMaiDanhMucs.RemoveRange(_db.KhuyenMaiDanhMucs.Where(x => x.MaKhuyenMai == id));
            _db.KhuyenMaiGianHangs.RemoveRange(_db.KhuyenMaiGianHangs.Where(x => x.MaKhuyenMai == id));
            _db.KhuyenMais.Remove(km);
            try { await _db.SaveChangesAsync(); }
            catch (DbUpdateException) { return Loi("Không xóa được vì mã đang được dữ liệu khác tham chiếu. Hãy tắt mã thay vì xóa.", 409); }
            return Ok(new { id, daXoa = true });
        }

        /// <summary>Tạo (id == null) hoặc cập nhật. maGianHang: gian hàng chủ mã (null = toàn hệ thống, chỉ Quản trị).</summary>
        private async Task<IActionResult> LuuAsync(int? id, KhuyenMaiLuuRequest rq, int? maGianHang, bool vaiTroQuanTri)
        {
            KhuyenMai? km = null;
            if (id != null)
            {
                km = await TimAsync(id.Value, vaiTroQuanTri ? null : maGianHang);
                if (km == null) return Loi("Không tìm thấy khuyến mãi.", 404);
                if (!vaiTroQuanTri) maGianHang = km.MaGianHang;   // gian hàng không đổi được chủ mã
            }

            var code = (rq.MaCode ?? "").Trim().ToUpperInvariant();
            if (id != null && string.IsNullOrEmpty(code)) code = km!.MaCode;
            if (!Regex.IsMatch(code, "^[A-Z0-9_-]{3,30}$")) return Loi("Mã khuyến mãi gồm 3–30 ký tự chữ hoa, số, gạch ngang hoặc gạch dưới.");
            if (await _db.KhuyenMais.AnyAsync(k => k.MaCode == code && (id == null || k.MaKhuyenMai != id)))
                return Loi("Mã khuyến mãi này đã tồn tại.", 409);

            var loai = rq.LoaiGiam is "SoTien" or "GiamPhiVanChuyen" ? rq.LoaiGiam : "PhanTram";
            if (loai == "PhanTram" && (rq.GiaTriGiam <= 0 || rq.GiaTriGiam > 100)) return Loi("Phần trăm giảm phải trong khoảng (0, 100].");
            if (loai == "SoTien" && rq.GiaTriGiam <= 0) return Loi("Số tiền giảm phải lớn hơn 0.");
            if (loai == "GiamPhiVanChuyen" && rq.GiaTriGiam < 0) return Loi("Mức giảm phí giao không hợp lệ (0 = miễn phí giao).");
            if (rq.GiamToiDa is <= 0) return Loi("Mức giảm tối đa không hợp lệ.");
            if (rq.GiaTriDonToiThieu < 0) return Loi("Giá trị đơn tối thiểu không hợp lệ.");
            if (rq.SoLuongToiDa is <= 0) return Loi("Số lượt sử dụng tối đa phải lớn hơn 0.");
            if (rq.NgayKetThuc <= rq.NgayBatDau) return Loi("Ngày kết thúc phải sau ngày bắt đầu.");
            if (km != null && rq.SoLuongToiDa != null && rq.SoLuongToiDa < km.SoLuongDaDung)
                return Loi($"Số lượt tối đa không được nhỏ hơn số lượt đã dùng ({km.SoLuongDaDung}).");

            if (maGianHang != null && !await _db.GianHangs.AnyAsync(g => g.MaGianHang == maGianHang))
                return Loi("Gian hàng không tồn tại.", 404);

            // Món / danh mục áp dụng: chỉ nhận món & danh mục thuộc gian hàng chủ mã (mã hệ thống: mọi gian hàng).
            var monIds = (rq.MonApDung ?? new()).Select(s => int.TryParse(s, out var n) ? n : -1).Where(n => n > 0).Distinct().ToList();
            if (monIds.Count > 0)
            {
                var hopLe = await _db.MonAns.Where(m => monIds.Contains(m.MaMonAn) && (maGianHang == null || m.DanhMuc!.MaGianHang == maGianHang))
                    .Select(m => m.MaMonAn).ToListAsync();
                if (hopLe.Count != monIds.Count) return Loi("Có món áp dụng không thuộc gian hàng của mã này.");
            }
            var tenDm = (rq.DanhMucApDung ?? new()).Select(s => s.Trim()).Where(s => s != "").Distinct().ToList();
            var dmIds = new List<int>();
            if (tenDm.Count > 0)
            {
                var dms = await _db.DanhMucs.Where(d => tenDm.Contains(d.TenDanhMuc) && (maGianHang == null || d.MaGianHang == maGianHang)).ToListAsync();
                var thieu = tenDm.Where(t => !dms.Any(d => d.TenDanhMuc == t)).ToList();
                if (thieu.Count > 0) return Loi("Không tìm thấy danh mục: " + string.Join(", ", thieu));
                dmIds = dms.Select(d => d.MaDanhMuc).Distinct().ToList();
            }
            var quanIds = new List<int>();
            if (vaiTroQuanTri && maGianHang == null)
            {
                quanIds = (rq.GianHangApDung ?? new()).Select(s => int.TryParse(s, out var n) ? n : -1).Where(n => n > 0).Distinct().ToList();
                if (quanIds.Count > 0 && await _db.GianHangs.CountAsync(g => quanIds.Contains(g.MaGianHang)) != quanIds.Count)
                    return Loi("Có gian hàng áp dụng không tồn tại.");
            }

            if (km == null) { km = new KhuyenMai { MaCode = code }; _db.KhuyenMais.Add(km); }
            km.MaCode = code;
            km.MaGianHang = maGianHang;
            km.TenChuongTrinh = string.IsNullOrWhiteSpace(rq.TenChuongTrinh) ? null : rq.TenChuongTrinh.Trim();
            km.MoTa = string.IsNullOrWhiteSpace(rq.MoTa) ? null : rq.MoTa.Trim();
            km.LoaiGiam = loai;
            km.PhanTramGiam = loai == "PhanTram" ? rq.GiaTriGiam : null;
            km.SoTienGiam = loai != "PhanTram" ? rq.GiaTriGiam : null;
            km.GiamToiDa = loai == "PhanTram" ? rq.GiamToiDa : null;
            km.GiaTriDonToiThieu = rq.GiaTriDonToiThieu;
            km.SoLuongToiDa = rq.SoLuongToiDa;
            km.MoiKhachMotLan = rq.MoiKhachMotLan;
            km.NgayBatDau = rq.NgayBatDau;
            km.NgayKetThuc = rq.NgayKetThuc;
            km.TrangThai = rq.DangHoatDong;
            await _db.SaveChangesAsync();   // có MaKhuyenMai để ghi bảng phạm vi

            _db.KhuyenMaiMonAns.RemoveRange(_db.KhuyenMaiMonAns.Where(x => x.MaKhuyenMai == km.MaKhuyenMai));
            _db.KhuyenMaiDanhMucs.RemoveRange(_db.KhuyenMaiDanhMucs.Where(x => x.MaKhuyenMai == km.MaKhuyenMai));
            _db.KhuyenMaiGianHangs.RemoveRange(_db.KhuyenMaiGianHangs.Where(x => x.MaKhuyenMai == km.MaKhuyenMai));
            await _db.SaveChangesAsync();
            foreach (var m in monIds) _db.KhuyenMaiMonAns.Add(new KhuyenMaiMonAn { MaKhuyenMai = km.MaKhuyenMai, MaMonAn = m });
            foreach (var d in dmIds) _db.KhuyenMaiDanhMucs.Add(new KhuyenMaiDanhMuc { MaKhuyenMai = km.MaKhuyenMai, MaDanhMuc = d });
            foreach (var q in quanIds) _db.KhuyenMaiGianHangs.Add(new KhuyenMaiGianHang { MaKhuyenMai = km.MaKhuyenMai, MaGianHang = q });
            await _db.SaveChangesAsync();

            return Ok((await DocDsAsync(k => k.MaKhuyenMai == km.MaKhuyenMai)).First());
        }

        /// <summary>Trả đủ mọi mã (kể cả đã tắt/hết hạn) — khác GET api/mobile/khuyen-mai chỉ trả mã khách đang dùng được.</summary>
        private async Task<List<object>> DocDsAsync(System.Linq.Expressions.Expression<Func<KhuyenMai, bool>> dieuKien)
        {
            var ds = await _db.KhuyenMais.Where(dieuKien).Where(k => (k.MoTa == null || !k.MoTa.StartsWith("DOIDIEM|"))).OrderByDescending(k => k.NgayBatDau).ToListAsync();
            var ids = ds.Select(k => k.MaKhuyenMai).ToList();
            var mons = (await _db.KhuyenMaiMonAns.Where(x => ids.Contains(x.MaKhuyenMai)).ToListAsync()).ToLookup(x => x.MaKhuyenMai, x => x.MaMonAn.ToString());
            var dmRows = await _db.KhuyenMaiDanhMucs.Where(x => ids.Contains(x.MaKhuyenMai)).ToListAsync();
            var dmIds = dmRows.Select(x => x.MaDanhMuc).Distinct().ToList();
            var tenDm = await _db.DanhMucs.Where(d => dmIds.Contains(d.MaDanhMuc)).ToDictionaryAsync(d => d.MaDanhMuc, d => d.TenDanhMuc);
            var quans = (await _db.KhuyenMaiGianHangs.Where(x => ids.Contains(x.MaKhuyenMai)).ToListAsync()).ToLookup(x => x.MaKhuyenMai, x => x.MaGianHang.ToString());

            return ds.Select(k => (object)new
            {
                id = k.MaKhuyenMai,
                maCode = k.MaCode,
                tenChuongTrinh = string.IsNullOrWhiteSpace(k.TenChuongTrinh) ? (k.MoTa ?? k.MaCode) : k.TenChuongTrinh,
                moTa = k.MoTa ?? "",
                loaiGiam = k.LoaiGiam == "GiamPhiVanChuyen" ? "GiamPhiVanChuyen" : (k.PhanTramGiam != null ? "PhanTram" : "SoTien"),
                giaTriGiam = k.PhanTramGiam ?? k.SoTienGiam ?? 0,
                giaTriDonToiThieu = k.GiaTriDonToiThieu,
                giamToiDa = k.GiamToiDa,
                ngayBatDau = k.NgayBatDau,
                ngayKetThuc = k.NgayKetThuc,
                gianHangId = k.MaGianHang,
                soLuongToiDa = k.SoLuongToiDa ?? int.MaxValue,
                soLuongDaDung = k.SoLuongDaDung,
                moiKhachMotLan = k.MoiKhachMotLan,
                monApDung = mons[k.MaKhuyenMai].ToList(),
                danhMucApDung = dmRows.Where(x => x.MaKhuyenMai == k.MaKhuyenMai).Select(x => tenDm.GetValueOrDefault(x.MaDanhMuc, "")).Where(t => t != "").ToList(),
                gianHangApDung = quans[k.MaKhuyenMai].ToList(),
                dangHoatDong = k.TrangThai
            }).ToList();
        }
    }
}
