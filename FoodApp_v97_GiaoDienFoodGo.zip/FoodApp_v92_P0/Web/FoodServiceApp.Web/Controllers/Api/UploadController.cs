using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    [ApiController]
    [Route("api/upload")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)] // JWT — không dùng Cookie của web
    public class UploadController : ControllerBase
    {
        private readonly IFileStorageService _storageService;

        public UploadController(IFileStorageService storageService)
        {
            _storageService = storageService;
        }

        [HttpPost("monan")]
        public async Task<IActionResult> UploadMonAnImage(IFormFile file)
        {
            try
            {
                var url = await _storageService.SaveFileAsync(file, "monan");
                return Ok(new { imageUrl = url });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost("taixe")]
        public async Task<IActionResult> UploadTaiXeImage(IFormFile file)
        {
            try
            {
                var url = await _storageService.SaveFileAsync(file, "taixe");
                return Ok(new { imageUrl = url });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>Ảnh đính kèm đánh giá của khách (tối đa 5MB/ảnh; app gửi từng ảnh một, tối đa 3 ảnh mỗi đánh giá).</summary>
        [HttpPost("danhgia")]
        public async Task<IActionResult> UploadDanhGiaImage(IFormFile file)
        {
            try
            {
                var url = await _storageService.SaveFileAsync(file, "danhgia");
                return Ok(new { imageUrl = url });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        /// <summary>GPLX của tài xế — tài liệu RIÊNG TƯ (lưu ngoài wwwroot, xem qua /files/private hoặc liên kết ký).</summary>
        [HttpPost("giayto-taixe")]
        [Authorize(Roles = "TaiXe")]
        public async Task<IActionResult> UploadGiayToTaiXe(IFormFile file)
        {
            try { return Ok(new { imageUrl = await _storageService.SaveFileAsync(file, "taixe-giayto") }); }
            catch (ArgumentException ex) { return BadRequest(new { message = ex.Message }); }
        }

        /// <summary>Giấy phép kinh doanh / ATTP của gian hàng — tài liệu RIÊNG TƯ.</summary>
        [HttpPost("giayto-gianhang")]
        [Authorize(Roles = "GianHang")]
        public async Task<IActionResult> UploadGiayToGianHang(IFormFile file)
        {
            try { return Ok(new { imageUrl = await _storageService.SaveFileAsync(file, "giayto") }); }
            catch (ArgumentException ex) { return BadRequest(new { message = ex.Message }); }
        }

        [HttpPost("gianhang")]
        public async Task<IActionResult> UploadGianHangImage(IFormFile file)
        {
            try
            {
                var url = await _storageService.SaveFileAsync(file, "gianhang");
                return Ok(new { imageUrl = url });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}
