using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// Bổ sung cho AdminMobileApiController (v44): sự cố tài xế báo lên quản trị và thông báo hệ thống.
    /// Quy tắc giống các trang Web QuanTri/SuCoTaiXe và QuanTri/ThongBao; mọi quản trị viên được xem, gửi thông báo cần quyền "ThongBao".
    /// </summary>
    [ApiController]
    [Route("api/mobile/admin")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
    public class AdminMobileExtraApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        public AdminMobileExtraApiController(AppDbContext db) { _db = db; }

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static ObjectResult Loi(string m, int status = 400) => new(new { thongDiep = m }) { StatusCode = status };

        // ------------------------------------------------------------------ sự cố tài xế
        [HttpGet("su-co-tai-xe")]
        public async Task<IActionResult> DanhSachSuCoTaiXe(string? trangThai, string? loai)
        {
            var q = _db.SuCoGiaoHangs.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(trangThai)) q = q.Where(x => x.TrangThai == trangThai);
            if (!string.IsNullOrWhiteSpace(loai)) q = q.Where(x => x.Loai == loai);
            var ds = await q.OrderBy(x => x.TrangThai == "DaXuLy" ? 1 : 0).ThenByDescending(x => x.NgayTao).Take(150).ToListAsync();
            var ids = ds.Select(x => x.MaTaiXe).Distinct().ToList();
            var ten = await _db.TaiXes.AsNoTracking().Where(t => ids.Contains(t.MaTaiXe)).ToDictionaryAsync(t => t.MaTaiXe, t => t.HoTen);
            return Ok(ds.Select(s => new
            {
                s.MaSuCo, s.MaTaiXe, taiXe = ten.GetValueOrDefault(s.MaTaiXe) ?? "", s.MaDonHang, s.Loai, s.MoTa,
                s.TrangThai, s.PhanHoiQuanTri, s.NgayTao, s.NgayXuLy,
            }));
        }

        public record XuLySuCoReq(string? TrangThai, string? PhanHoi);

        [HttpPut("su-co-tai-xe/{id:int}/xu-ly")]
        public async Task<IActionResult> XuLySuCoTaiXe(int id, XuLySuCoReq r)
        {
            var sc = await _db.SuCoGiaoHangs.FirstOrDefaultAsync(x => x.MaSuCo == id);
            if (sc == null) return Loi("Không tìm thấy sự cố.", 404);
            if (r.TrangThai is not ("DangXuLy" or "DaXuLy")) return Loi("Trạng thái không hợp lệ.");
            var phanHoi = r.PhanHoi?.Trim();
            if (r.TrangThai == "DaXuLy" && string.IsNullOrWhiteSpace(phanHoi)) return Loi("Nhập kết quả / lý do giải quyết trước khi đóng sự cố.");
            if (sc.TrangThai == "DaXuLy") return Loi("Sự cố này đã được xử lý xong.");
            sc.TrangThai = r.TrangThai;
            if (!string.IsNullOrWhiteSpace(phanHoi)) sc.PhanHoiQuanTri = phanHoi.Length > 1000 ? phanHoi[..1000] : phanHoi;
            sc.MaTKXuLy = MaTK;
            if (r.TrangThai == "DaXuLy") sc.NgayXuLy = DateTime.Now;
            var tx = await _db.TaiXes.FirstOrDefaultAsync(t => t.MaTaiXe == sc.MaTaiXe);
            if (tx != null)
                _db.ThongBaos.Add(new ThongBao
                {
                    MaTK = tx.MaTK, Loai = "HeThong",
                    TieuDe = r.TrangThai == "DaXuLy" ? "Phản ánh của bạn đã được giải quyết" : "Phản ánh của bạn đang được xử lý",
                    NoiDung = string.IsNullOrWhiteSpace(sc.PhanHoiQuanTri) ? $"Sự cố #{sc.MaSuCo}" : $"Sự cố #{sc.MaSuCo}: {sc.PhanHoiQuanTri}",
                });
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = r.TrangThai == "DaXuLy" ? $"Đã đóng sự cố #{sc.MaSuCo}." : $"Đã chuyển sự cố #{sc.MaSuCo} sang đang xử lý." });
        }

        // ------------------------------------------------------------------ thông báo hệ thống
        [HttpGet("thong-bao/gan-day")]
        public async Task<IActionResult> ThongBaoGanDay()
        {
            var ds = await _db.ThongBaos.AsNoTracking().Where(t => t.Loai == "HeThong").OrderByDescending(t => t.NgayTao).Take(400)
                .GroupBy(t => new { t.TieuDe, t.NoiDung })
                .Select(g => new { g.Key.TieuDe, g.Key.NoiDung, Ngay = g.Max(x => x.NgayTao), SoNguoi = g.Count() })
                .OrderByDescending(x => x.Ngay).Take(20).ToListAsync();
            return Ok(ds);
        }

        public record GuiThongBaoReq(string? DoiTuong, string? DsTaiKhoan, string? TieuDe, string? NoiDung);

        [HttpPost("thong-bao")]
        public async Task<IActionResult> GuiThongBao(GuiThongBaoReq r)
        {
            if (!await QuyenAdmin.CoAsync(_db, MaTK, "ThongBao")) return Loi("Bạn không có quyền gửi thông báo.", 403);
            var tieuDe = (r.TieuDe ?? "").Trim(); var noiDung = (r.NoiDung ?? "").Trim();
            if (tieuDe.Length < 3 || noiDung.Length < 3) return Loi("Nhập tiêu đề và nội dung (tối thiểu 3 ký tự).");
            if (tieuDe.Length > 150) tieuDe = tieuDe[..150];
            if (noiDung.Length > 1000) noiDung = noiDung[..1000];
            List<int> maTKs;
            switch (r.DoiTuong)
            {
                case "TatCa":
                    maTKs = await _db.TaiKhoans.Where(t => t.TrangThai && t.VaiTro != "QuanTri").Select(t => t.MaTK).ToListAsync(); break;
                case "KhachHang": case "GianHang": case "TaiXe":
                    maTKs = await _db.TaiKhoans.Where(t => t.TrangThai && t.VaiTro == r.DoiTuong).Select(t => t.MaTK).ToListAsync(); break;
                case "Nhom":
                    var tokens = (r.DsTaiKhoan ?? "").Split(new[] { ',', '\n', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Distinct().Take(500).ToList();
                    if (tokens.Count == 0) return Loi("Nhập ít nhất một tên đăng nhập.");
                    maTKs = await _db.TaiKhoans.Where(t => t.TrangThai && tokens.Contains(t.TenDangNhap)).Select(t => t.MaTK).ToListAsync();
                    break;
                default: return Loi("Đối tượng nhận không hợp lệ.");
            }
            if (maTKs.Count == 0) return Loi("Không tìm thấy tài khoản nhận nào.");
            foreach (var m in maTKs) _db.ThongBaos.Add(new ThongBao { MaTK = m, Loai = "HeThong", TieuDe = tieuDe, NoiDung = noiDung });
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = $"Đã gửi thông báo tới {maTKs.Count} tài khoản." });
        }
    }
}
