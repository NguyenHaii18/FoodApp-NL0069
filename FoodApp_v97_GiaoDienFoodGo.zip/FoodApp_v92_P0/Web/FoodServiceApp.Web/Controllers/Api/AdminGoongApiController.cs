using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;
using FoodServiceApp.Web.Services.Configs;
using FoodServiceApp.Web.Services.Maps;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>Quản lý khóa Goong từ ứng dụng quản trị. Chỉ Admin tổng. Không bao giờ trả khóa đầy đủ về client.</summary>
    [ApiController]
    [Route("api/mobile/admin/goong")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
    public class AdminGoongApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly CauHinhService _cauHinh;
        private readonly GoongMapsSettings _settings;
        private readonly IGoongMapsService _goong;
        public AdminGoongApiController(AppDbContext db, CauHinhService cauHinh, IOptions<GoongMapsSettings> settings, IGoongMapsService goong)
        { _db = db; _cauHinh = cauHinh; _settings = settings.Value; _goong = goong; }

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private Task<bool> LaSuperAdminAsync() => _db.QuanTris.AnyAsync(q => q.MaTK == MaTK && q.CapQuyenHan == "SuperAdmin");
        public record KhoaReq(string? Khoa);

        private object TrangThai() => new
        {
            daCauHinh = GoongKhoa.Co(_settings),
            khoaDaAn = GoongKhoa.Co(_settings) ? GoongKhoa.Che(GoongKhoa.Lay(_settings)) : "",
            nguon = GoongKhoa.Nguon(_settings),
        };

        [HttpGet("")]
        public async Task<IActionResult> Xem()
        {
            if (!await LaSuperAdminAsync()) return StatusCode(403, new { thongDiep = "Chỉ Admin tổng được xem cấu hình khóa bản đồ." });
            return Ok(TrangThai());
        }

        /// <summary>Lưu khóa mới (chuỗi rỗng = xóa khóa trong CSDL, quay lại dùng appsettings).</summary>
        [HttpPut("")]
        public async Task<IActionResult> Luu(KhoaReq r)
        {
            if (!await LaSuperAdminAsync()) return StatusCode(403, new { thongDiep = "Chỉ Admin tổng được đổi khóa bản đồ." });
            var khoa = (r.Khoa ?? "").Trim();
            if (khoa.Length > 0 && (!GoongKhoa.Hop(khoa) || khoa.Length < 16 || khoa.Length > 200 || khoa.Any(char.IsWhiteSpace)))
                return BadRequest(new { thongDiep = "Khóa không hợp lệ (cần chuỗi liền, tối thiểu 16 ký tự, không phải chuỗi mẫu)." });
            await _cauHinh.DatAsync(GoongKhoa.KhoaCauHinh, khoa, MaTK);
            GoongKhoa.DatGhiDe(khoa);
            return Ok(new { thongDiep = khoa.Length == 0 ? "Đã xóa khóa trong ứng dụng; hệ thống dùng lại khóa trong appsettings (nếu có)." : "Đã lưu khóa Goong.", trangThai = TrangThai() });
        }

        /// <summary>Gọi thử Goong bằng khóa hiện hành (geocode một địa chỉ mẫu).</summary>
        [HttpPost("kiem-tra")]
        public async Task<IActionResult> KiemTra()
        {
            if (!await LaSuperAdminAsync()) return StatusCode(403, new { thongDiep = "Chỉ Admin tổng được kiểm tra khóa bản đồ." });
            if (!GoongKhoa.Co(_settings)) return Ok(new { ok = false, thongDiep = "Chưa có khóa Goong hợp lệ." });
            try
            {
                var p = await _goong.GeocodeAsync("Nhà hát Lớn, Hà Nội");
                return p == null
                    ? Ok(new { ok = false, thongDiep = "Goong không trả tọa độ — khóa có thể sai, hết hạn hoặc chưa bật dịch vụ Geocode/Direction." })
                    : Ok(new { ok = true, thongDiep = $"Khóa hoạt động (tọa độ thử: {p.Lat:0.0000}, {p.Lng:0.0000}).", lat = p.Lat, lng = p.Lng });
            }
            catch (Exception ex) { return Ok(new { ok = false, thongDiep = "Không gọi được Goong: " + ex.Message }); }
        }
    }
}
