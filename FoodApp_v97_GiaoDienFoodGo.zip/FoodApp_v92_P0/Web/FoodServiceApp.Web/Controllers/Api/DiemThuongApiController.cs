using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// Điểm thưởng của khách và đổi điểm lấy voucher.
    ///   GET  api/mobile/khach-hang/diem        → điểm tích lũy / đã đổi / còn lại, các mức đổi, voucher đã đổi
    ///   POST api/mobile/khach-hang/diem/doi    { diem }  → phát một voucher cá nhân (mã ngẫu nhiên, dùng một lần, hạn 30 ngày)
    /// Quy ước điểm (khớp app): 1 điểm cho mỗi 1.000đ của đơn đã giao. Điểm đã đổi lấy từ chính các voucher đã phát
    /// (KhuyenMai.MoTa = "DOIDIEM|{maKH}|{điểm}") nên không cần thêm bảng.
    /// </summary>
    [ApiController]
    [Route("api/mobile/khach-hang/diem")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
    public class DiemThuongApiController : ControllerBase
    {
        public const decimal TienMotDiem = 1000m;
        public const int HanNgay = 30;
        /// <summary>Các mức đổi: điểm → số tiền giảm. Đơn tối thiểu = 4 lần số tiền giảm.</summary>
        public static readonly (int Diem, decimal Giam)[] MucDoi = { (50, 10_000m), (100, 25_000m), (200, 60_000m) };

        private static readonly SemaphoreSlim _khoa = new(1, 1);   // không cho hai lần đổi chạy song song (tránh đổi lố điểm)
        private readonly AppDbContext _db;
        public DiemThuongApiController(AppDbContext db) { _db = db; }

        private static IActionResult Loi(string m, int status = 400) => new ObjectResult(new { thongDiep = m }) { StatusCode = status };
        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

        private async Task<(int Tong, int DaDoi)> TinhAsync(int maKH)
        {
            var tong = await _db.DonHangs.Where(d => d.MaKH == maKH && d.TrangThai == "DaGiao").SumAsync(d => (decimal?)d.TongTien) ?? 0m;
            var tienTo = $"{KhuyenMaiXuLy.TienToDoiDiem}{maKH}|";
            var moTa = await _db.KhuyenMais.Where(k => k.MoTa != null && k.MoTa.StartsWith(tienTo)).Select(k => k.MoTa!).ToListAsync();
            var daDoi = moTa.Sum(m => int.TryParse(m.Split('|').ElementAtOrDefault(2), out var d) ? d : 0);
            return ((int)Math.Floor(tong / TienMotDiem), daDoi);
        }

        [HttpGet("")]
        public async Task<IActionResult> Lay()
        {
            var maKH = await _db.KhachHangs.Where(k => k.MaTK == MaTK).Select(k => (int?)k.MaKH).FirstOrDefaultAsync();
            if (maKH == null) return Loi("Không tìm thấy khách hàng.", 404);
            var (tong, daDoi) = await TinhAsync(maKH.Value);
            var tienTo = $"{KhuyenMaiXuLy.TienToDoiDiem}{maKH}|";
            var vouchers = await _db.KhuyenMais.AsNoTracking()
                .Where(k => k.MoTa != null && k.MoTa.StartsWith(tienTo))
                .OrderByDescending(k => k.NgayBatDau)
                .Select(k => new { maCode = k.MaCode, soTienGiam = k.SoTienGiam ?? 0, donToiThieu = k.GiaTriDonToiThieu, hetHan = k.NgayKetThuc, daDung = k.SoLuongDaDung > 0, ngayDoi = k.NgayBatDau })
                .Take(30).ToListAsync();
            return Ok(new
            {
                tongDiem = tong, daDoi, conLai = Math.Max(0, tong - daDoi),
                tienMotDiem = TienMotDiem, hanNgay = HanNgay,
                mucDoi = MucDoi.Select(m => new { diem = m.Diem, soTienGiam = m.Giam, donToiThieu = m.Giam * 4 }),
                vouchers,
            });
        }

        public record DoiRequest(int Diem);

        [HttpPost("doi")]
        public async Task<IActionResult> Doi(DoiRequest r)
        {
            var muc = MucDoi.FirstOrDefault(m => m.Diem == r.Diem);
            if (muc.Diem == 0) return Loi("Mức đổi điểm không hợp lệ.");
            var maKH = await _db.KhachHangs.Where(k => k.MaTK == MaTK).Select(k => (int?)k.MaKH).FirstOrDefaultAsync();
            if (maKH == null) return Loi("Không tìm thấy khách hàng.", 404);

            await _khoa.WaitAsync();
            try
            {
                var (tong, daDoi) = await TinhAsync(maKH.Value);
                var conLai = tong - daDoi;
                if (conLai < muc.Diem) return Loi($"Bạn còn {Math.Max(0, conLai)} điểm, cần {muc.Diem} điểm để đổi mức này.");

                // Mã ngẫu nhiên, bỏ ký tự dễ nhầm (0/O, 1/I)
                const string kyTu = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
                string ma;
                do { ma = "DIEM" + new string(Enumerable.Range(0, 6).Select(_ => kyTu[Random.Shared.Next(kyTu.Length)]).ToArray()); }
                while (await _db.KhuyenMais.AnyAsync(k => k.MaCode == ma));

                var now = DateTime.Now;
                var km = new KhuyenMai
                {
                    MaCode = ma,
                    TenChuongTrinh = "Đổi điểm thưởng",
                    MoTa = $"{KhuyenMaiXuLy.TienToDoiDiem}{maKH}|{muc.Diem}",
                    LoaiGiam = "SoTien",
                    SoTienGiam = muc.Giam,
                    GiaTriDonToiThieu = muc.Giam * 4,
                    SoLuongToiDa = 1,
                    MoiKhachMotLan = true,
                    MaGianHang = null,          // dùng được ở mọi quán
                    NgayBatDau = now,
                    NgayKetThuc = now.AddDays(HanNgay),
                    TrangThai = true,
                };
                _db.KhuyenMais.Add(km);
                await _db.SaveChangesAsync();
                return Ok(new
                {
                    maCode = ma, soTienGiam = muc.Giam, donToiThieu = km.GiaTriDonToiThieu, hetHan = km.NgayKetThuc,
                    conLai = conLai - muc.Diem,
                    thongDiep = $"Đã đổi {muc.Diem} điểm lấy voucher giảm {muc.Giam:N0}đ (đơn từ {km.GiaTriDonToiThieu:N0}đ, hạn {HanNgay} ngày).",
                });
            }
            finally { _khoa.Release(); }
        }
    }
}
