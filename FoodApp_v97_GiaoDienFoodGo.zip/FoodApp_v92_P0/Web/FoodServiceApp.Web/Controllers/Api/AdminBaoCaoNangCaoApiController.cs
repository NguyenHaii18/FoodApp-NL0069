using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>Báo cáo kinh doanh nâng cao: so sánh với kỳ trước, giá trị đơn trung bình, giờ/thứ cao điểm, khách quay lại, doanh thu theo danh mục, lý do hủy.
    /// Chỉ ĐỌC dữ liệu đơn hàng sẵn có (đơn đã giao = doanh thu).</summary>
    [ApiController]
    [Route("api/mobile/admin/bao-cao-nang-cao")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
    public class AdminBaoCaoNangCaoApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        public AdminBaoCaoNangCaoApiController(AppDbContext db) { _db = db; }

        private static readonly string[] Thu = { "CN", "T2", "T3", "T4", "T5", "T6", "T7" };

        private static double? TangTruong(decimal nay, decimal truoc) => truoc == 0 ? null : Math.Round((double)((nay - truoc) / truoc * 100m), 1);

        // GET api/mobile/admin/bao-cao-nang-cao?ngay=30  (7 | 30 | 90)
        [HttpGet("")]
        public async Task<IActionResult> Xem(int ngay = 30)
        {
            if (ngay != 7 && ngay != 90) ngay = 30;
            var den = DateTime.Today.AddDays(1);
            var tu = den.AddDays(-ngay);
            var tuTruoc = tu.AddDays(-ngay);

            var don = await _db.DonHangs.AsNoTracking().Where(d => d.NgayDat >= tuTruoc && d.NgayDat < den)
                .Select(d => new { d.MaDonHang, d.MaKH, d.MaGianHang, d.NgayDat, d.TrangThai, d.TongTien, d.PhiGiaoHang, d.LyDoTuChoi }).ToListAsync();

            var nay = don.Where(d => d.NgayDat >= tu).ToList();
            var truoc = don.Where(d => d.NgayDat < tu).ToList();
            var xongNay = nay.Where(d => d.TrangThai == "DaGiao").ToList();
            var xongTruoc = truoc.Where(d => d.TrangThai == "DaGiao").ToList();

            decimal gmvNay = xongNay.Sum(d => d.TongTien), gmvTruoc = xongTruoc.Sum(d => d.TongTien);
            decimal aovNay = xongNay.Count == 0 ? 0 : Math.Round(gmvNay / xongNay.Count, 0);
            decimal aovTruoc = xongTruoc.Count == 0 ? 0 : Math.Round(gmvTruoc / xongTruoc.Count, 0);
            int huyNay = nay.Count(d => d.TrangThai == "DaHuy"), huyTruoc = truoc.Count(d => d.TrangThai == "DaHuy");

            // Khách quay lại: trong kỳ có từ 2 đơn đã giao trở lên
            var theoKhach = xongNay.GroupBy(d => d.MaKH).Select(g => g.Count()).ToList();
            int khachCoDon = theoKhach.Count, khachQuayLai = theoKhach.Count(c => c >= 2);

            var theoGio = Enumerable.Range(0, 24).Select(h => new { gio = h, soDon = xongNay.Count(d => d.NgayDat.Hour == h), doanhThu = xongNay.Where(d => d.NgayDat.Hour == h).Sum(d => d.TongTien) }).ToList();
            var theoThu = Enumerable.Range(0, 7).Select(t => new { thu = Thu[t], soDon = xongNay.Count(d => (int)d.NgayDat.DayOfWeek == t), doanhThu = xongNay.Where(d => (int)d.NgayDat.DayOfWeek == t).Sum(d => d.TongTien) }).ToList();

            var lyDoHuy = nay.Where(d => d.TrangThai == "DaHuy").GroupBy(d => string.IsNullOrWhiteSpace(d.LyDoTuChoi) ? "Không ghi lý do" : d.LyDoTuChoi!.Trim())
                .Select(g => new { lyDo = g.Key.Length > 60 ? g.Key[..60] + "…" : g.Key, soDon = g.Count() }).OrderByDescending(x => x.soDon).Take(6).ToList();

            var maXong = xongNay.Select(d => d.MaDonHang).ToList();
            var theoDanhMuc = await _db.ChiTietDonHangs.AsNoTracking().Where(c => maXong.Contains(c.MaDonHang))
                .GroupBy(c => c.MonAn!.DanhMuc!.TenDanhMuc)
                .Select(g => new { ten = g.Key, soLuong = g.Sum(c => c.SoLuong), doanhThu = g.Sum(c => c.SoLuong * c.DonGia) })
                .OrderByDescending(x => x.doanhThu).Take(8).ToListAsync();

            // Quán tăng/giảm mạnh nhất so với kỳ trước (chỉ quán có doanh thu kỳ trước ≥ 1 đơn)
            var tenQuan = await _db.GianHangs.AsNoTracking().Select(g => new { g.MaGianHang, g.TenCuaHang }).ToDictionaryAsync(g => g.MaGianHang, g => g.TenCuaHang);
            var dtNay = xongNay.GroupBy(d => d.MaGianHang).ToDictionary(g => g.Key, g => g.Sum(d => d.TongTien));
            var dtTruoc = xongTruoc.GroupBy(d => d.MaGianHang).ToDictionary(g => g.Key, g => g.Sum(d => d.TongTien));
            var bienDong = dtTruoc.Where(kv => kv.Value > 0).Select(kv =>
            {
                var n = dtNay.TryGetValue(kv.Key, out var v) ? v : 0m;
                return new { ten = tenQuan.TryGetValue(kv.Key, out var t) ? t : "?", doanhThuNay = n, doanhThuTruoc = kv.Value, tangTruongPhanTram = Math.Round((double)((n - kv.Value) / kv.Value * 100m), 1) };
            }).ToList();

            return Ok(new
            {
                ngay,
                tuNgay = tu, denNgay = den.AddDays(-1),
                gmv = gmvNay, gmvTruoc, gmvTangTruong = TangTruong(gmvNay, gmvTruoc),
                soDon = xongNay.Count, soDonTruoc = xongTruoc.Count, soDonTangTruong = TangTruong(xongNay.Count, xongTruoc.Count),
                aov = aovNay, aovTruoc, aovTangTruong = TangTruong(aovNay, aovTruoc),
                donHuy = huyNay, donHuyTruoc = huyTruoc,
                tyLeHuy = nay.Count == 0 ? 0 : Math.Round(huyNay * 100.0 / nay.Count, 1),
                khachCoDon, khachQuayLai, tyLeQuayLai = khachCoDon == 0 ? 0 : Math.Round(khachQuayLai * 100.0 / khachCoDon, 1),
                theoGio, theoThu, lyDoHuy, theoDanhMuc,
                quanTangManh = bienDong.OrderByDescending(x => x.tangTruongPhanTram).Take(5).ToList(),
                quanGiamManh = bienDong.OrderBy(x => x.tangTruongPhanTram).Take(5).ToList(),
                ghiChu = "Doanh thu = tổng giá trị đơn đã giao (GMV). Khách quay lại = có từ 2 đơn đã giao trong kỳ. So sánh với kỳ liền trước cùng độ dài.",
            });
        }
    }
}
