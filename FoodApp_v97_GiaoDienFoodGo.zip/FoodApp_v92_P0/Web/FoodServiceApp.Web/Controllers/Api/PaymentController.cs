using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using System.Security.Claims;
using FoodServiceApp.Web.Services.Payment;

namespace FoodServiceApp.Web.Controllers.Api
{
    public record TaoThanhToanRequest(int MaDonHang, long SoTien, string NoiDung);

    [ApiController]
    [Route("api/payment")]
    public class PaymentController : ControllerBase
    {
        private readonly IVnPayService _vnPayService;
        private readonly AppDbContext _db;

        public PaymentController(IVnPayService vnPayService, AppDbContext db)
        {
            _vnPayService = vnPayService;
            _db = db;
        }

        // POST /api/payment/vnpay/tao-url
        // Số tiền do SERVER lấy từ đơn (không tin số tiền client gửi); chỉ chủ đơn mới tạo được link.
        [HttpPost("vnpay/tao-url")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> TaoUrlThanhToan(TaoThanhToanRequest request)
        {
            var maTK = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
            var don = await _db.DonHangs.Include(d => d.ThanhToan).Include(d => d.KhachHang)
                .FirstOrDefaultAsync(d => d.MaDonHang == request.MaDonHang && d.KhachHang!.MaTK == maTK);
            if (don == null) return NotFound(new { message = "Không tìm thấy đơn hàng." });
            if (don.ThanhToan?.HinhThuc != "VNPay") return BadRequest(new { message = "Đơn hàng không dùng VNPay." });
            if (don.ThanhToan.TrangThai == "DaThanhToan") return BadRequest(new { message = "Đơn đã được thanh toán." });
            if (don.TrangThai == "DaHuy") return BadRequest(new { message = "Đơn đã bị hủy." });

            var ipAddress = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1";
            var url = await FoodServiceApp.Web.Services.Payment.VnPayXuLy.TaoLinkAsync(_db, _vnPayService, new VnPayCreateRequest(
                OrderId: don.MaDonHang,
                AmountVnd: (long)don.TongTien,
                OrderInfo: $"Thanh toan don hang #{don.MaDonHang} - FoodServiceApp",
                IpAddress: ipAddress
            ));
            return Ok(new { paymentUrl = url, soTien = don.TongTien });
        }

        // GET /api/payment/vnpay/return — VNPay redirect trình duyệt/WebView người dùng về đây.
        // Ghi kết quả vào CSDL ngay (an toàn vì đã kiểm tra chữ ký + số tiền + idempotent), để chạy local không cần IPN công khai.
        [HttpGet("vnpay/return")]
        public async Task<IActionResult> VnPayReturn()
        {
            var result = _vnPayService.ValidateCallback(Request.Query);
            if (!result.IsValidSignature)
                return BadRequest(new { message = "Chữ ký không hợp lệ, có thể dữ liệu đã bị thay đổi." });

            var ghi = await VnPayXuLy.GhiKetQuaAsync(_db, result);
            var okTT = result.IsSuccess && (ghi.RspCode is "00" or "02") && ghi.ThanhCong;
            // Trình duyệt điện thoại (app MAUI mở bằng Launcher): trả trang HTML đơn giản thay vì JSON thô
            if ((Request.Headers.Accept.ToString()).Contains("text/html"))
            {
                var tieuDe = okTT ? "Thanh toán thành công" : "Thanh toán chưa thành công";
                var nd = okTT ? $"Đơn #{result.OrderId} đã được ghi nhận thanh toán. Bạn có thể quay lại ứng dụng." : ghi.RspCode == "04" ? "Số tiền không khớp tổng đơn." : "Giao dịch không thành công hoặc đã bị hủy. Bạn có thể thử lại trong mục Đơn hàng.";
                return Content($"<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{tieuDe}</title></head><body style='font-family:sans-serif;text-align:center;padding:40px 16px'><h2>{(okTT ? "✅" : "⚠️")} {tieuDe}</h2><p>{System.Net.WebUtility.HtmlEncode(nd)}</p></body></html>", "text/html; charset=utf-8");
            }
            return Ok(new
            {
                thanhCong = okTT,
                maDonHang = result.OrderId,
                maGiaoDich = result.TransactionId,
                soTien = result.Amount,
                thongDiep = ghi.RspCode == "04" ? "Số tiền không khớp tổng đơn." : null
            });
        }

        // GET /api/payment/vnpay/ipn — VNPay server-to-server gọi ngầm để xác nhận giao dịch
        // (nguồn xác nhận chính thức — dùng cái này để cập nhật CSDL, KHÔNG dùng return ở trên,
        // vì return có thể bị người dùng đóng trình duyệt giữa chừng).
        [HttpGet("vnpay/ipn")]
        public async Task<IActionResult> VnPayIpn()
        {
            var result = _vnPayService.ValidateCallback(Request.Query);
            var ghi = await VnPayXuLy.GhiKetQuaAsync(_db, result);
            return Ok(new { RspCode = ghi.RspCode, Message = ghi.Message });
        }
    }
}
