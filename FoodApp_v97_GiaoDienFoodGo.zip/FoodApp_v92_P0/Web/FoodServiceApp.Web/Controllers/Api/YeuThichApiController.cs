using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// v64: quán / món yêu thích của khách trên máy chủ (bảng YeuThich dùng chung với web) để đổi máy hoặc cài lại app vẫn còn.
    /// Thao tác thêm/bỏ là idempotent nên app có thể gửi lại an toàn khi mất mạng.
    /// </summary>
    [ApiController]
    [Route("api/mobile/khach-hang/yeu-thich")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
    public class YeuThichApiController : ControllerBase
    {
        private const int ToiDa = 300;
        private readonly AppDbContext _db;
        public YeuThichApiController(AppDbContext db) => _db = db;

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static IActionResult Loi(string thongDiep, int status = 400) => new ObjectResult(new { thongDiep }) { StatusCode = status };
        private async Task<int?> MaKhAsync() =>
            await _db.KhachHangs.Where(k => k.MaTK == MaTK).Select(k => (int?)k.MaKH).FirstOrDefaultAsync();

        private static string? Loai(string? route) => route?.ToLowerInvariant() switch
        {
            "gian-hang" => "GianHang",
            "mon-an" => "MonAn",
            _ => null
        };

        [HttpGet("")]
        public async Task<IActionResult> Lay()
        {
            var maKh = await MaKhAsync();
            if (maKh == null) return Loi("Không tìm thấy khách hàng.", 404);
            var ds = await _db.YeuThichs.AsNoTracking().Where(y => y.MaKH == maKh).OrderByDescending(y => y.NgayTao).ToListAsync();
            return Ok(new
            {
                gianHang = ds.Where(y => y.Loai == "GianHang").Select(y => y.MaThamChieu).ToList(),
                monAn = ds.Where(y => y.Loai == "MonAn").Select(y => y.MaThamChieu).ToList(),
            });
        }

        /// <summary>PUT .../yeu-thich/gian-hang/{id} hoặc .../mon-an/{id}: thêm vào yêu thích (đã có thì vẫn trả OK).</summary>
        [HttpPut("{loai}/{id:int}")]
        public async Task<IActionResult> Them(string loai, int id)
        {
            var l = Loai(loai);
            if (l == null) return Loi("Loại yêu thích không hợp lệ.");
            var maKh = await MaKhAsync();
            if (maKh == null) return Loi("Không tìm thấy khách hàng.", 404);
            if (await _db.YeuThichs.AnyAsync(y => y.MaKH == maKh && y.Loai == l && y.MaThamChieu == id)) return Ok(new { thongDiep = "Đã có trong yêu thích." });

            var tonTai = l == "GianHang" ? await _db.GianHangs.AnyAsync(g => g.MaGianHang == id) : await _db.MonAns.AnyAsync(m => m.MaMonAn == id);
            if (!tonTai) return Loi("Quán hoặc món không còn tồn tại.", 404);
            if (await _db.YeuThichs.CountAsync(y => y.MaKH == maKh) >= ToiDa) return Loi($"Tối đa {ToiDa} mục yêu thích.");

            _db.YeuThichs.Add(new YeuThich { MaKH = maKh.Value, Loai = l, MaThamChieu = id });
            try { await _db.SaveChangesAsync(); }
            catch (DbUpdateException) { /* hai yêu cầu trùng nhau chạm ràng buộc UQ_YeuThich: coi như đã có */ }
            return Ok(new { thongDiep = "Đã thêm vào yêu thích." });
        }

        /// <summary>DELETE .../yeu-thich/gian-hang/{id} hoặc .../mon-an/{id}: bỏ khỏi yêu thích (không có thì vẫn trả OK).</summary>
        [HttpDelete("{loai}/{id:int}")]
        public async Task<IActionResult> Bo(string loai, int id)
        {
            var l = Loai(loai);
            if (l == null) return Loi("Loại yêu thích không hợp lệ.");
            var maKh = await MaKhAsync();
            if (maKh == null) return Loi("Không tìm thấy khách hàng.", 404);
            var co = await _db.YeuThichs.FirstOrDefaultAsync(y => y.MaKH == maKh && y.Loai == l && y.MaThamChieu == id);
            if (co != null) { _db.YeuThichs.Remove(co); await _db.SaveChangesAsync(); }
            return Ok(new { thongDiep = "Đã bỏ khỏi yêu thích." });
        }
    }
}
