using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.IdentityModel.Tokens;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Filters;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// Nhân viên gian hàng.
    ///   Chủ quán:  GET/POST api/mobile/gian-hang/{id}/nhan-vien, PUT/DELETE .../{maNV}, PUT .../{maNV}/mat-khau
    ///   Nhân viên: POST api/mobile/gian-hang/nhan-vien/dang-nhap, GET api/mobile/nhan-vien/toi, PUT api/mobile/nhan-vien/mat-khau
    /// Token nhân viên mang MaTK của chủ quán (để các API quán dùng chung) cùng claim "nv"; <see cref="NhanVienQuyenFilter"/>
    /// chặn mọi chức năng ngoài quyền được cấp, và chặn hẳn các chức năng chỉ dành cho chủ quán (hồ sơ, giấy tờ, nhân viên, tài khoản).
    /// </summary>
    [ApiController]
    [Route("api/mobile")]
    public class NhanVienGianHangApiController : ControllerBase
    {
        private const string Jwt = JwtBearerDefaults.AuthenticationScheme;
        private const int ToiDaNhanVien = 20;
        private static readonly Regex TenHopLe = new("^[a-z0-9._]{4,30}$", RegexOptions.Compiled);

        private readonly AppDbContext _db;
        private readonly IConfiguration _config;
        private readonly IMemoryCache _cache;

        public NhanVienGianHangApiController(AppDbContext db, IConfiguration config, IMemoryCache cache)
        { _db = db; _config = config; _cache = cache; }

        private static IActionResult Loi(string m, int status = 400) => new ObjectResult(new { thongDiep = m }) { StatusCode = status };
        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private Task<GianHang?> QuanCuaToiAsync(int id) => _db.GianHangs.FirstOrDefaultAsync(g => g.MaGianHang == id && g.MaTK == MaTK);

        private static object Map(NhanVienGianHang n) => new
        {
            maNV = n.MaNV, tenDangNhap = n.TenDangNhap, hoTen = n.HoTen, quyen = QuyenNhanVien.Tach(n.Quyen),
            trangThai = n.TrangThai, ngayTao = n.NgayTao, lanDangNhapCuoi = n.LanDangNhapCuoi
        };

        // =================================================================== CHỦ QUÁN
        [HttpGet("gian-hang/{id:int}/nhan-vien")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> DanhSach(int id)
        {
            if (await QuanCuaToiAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var ds = await _db.NhanVienGianHangs.AsNoTracking().Where(n => n.MaGianHang == id).OrderBy(n => n.HoTen).ToListAsync();
            return Ok(new
            {
                nhanVien = ds.Select(Map),
                quyenCoSan = QuyenNhanVien.TatCa.Select(q => new { ma = q, ten = QuyenNhanVien.Nhan(q) }),
                toiDa = ToiDaNhanVien,
            });
        }

        public record TaoNhanVienRequest(string? TenDangNhap, string? HoTen, string? MatKhau, List<string>? Quyen);

        [HttpPost("gian-hang/{id:int}/nhan-vien")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> Tao(int id, TaoNhanVienRequest r)
        {
            if (await QuanCuaToiAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var ten = (r.TenDangNhap ?? "").Trim().ToLowerInvariant();
            if (!TenHopLe.IsMatch(ten)) return Loi("Tên đăng nhập 4–30 ký tự, chỉ gồm chữ thường không dấu, số, dấu chấm và gạch dưới.");
            var hoTen = (r.HoTen ?? "").Trim();
            if (hoTen.Length < 2 || hoTen.Length > 100) return Loi("Vui lòng nhập họ tên nhân viên.");
            if ((r.MatKhau ?? "").Length < 6) return Loi("Mật khẩu tối thiểu 6 ký tự.");
            var quyen = QuyenNhanVien.ChuanHoa(r.Quyen);
            if (quyen.Count == 0) return Loi("Hãy chọn ít nhất một quyền cho nhân viên.");
            if (await _db.NhanVienGianHangs.CountAsync(n => n.MaGianHang == id) >= ToiDaNhanVien) return Loi($"Mỗi quán tối đa {ToiDaNhanVien} nhân viên.");
            if (await _db.NhanVienGianHangs.AnyAsync(n => n.TenDangNhap == ten) || await _db.TaiKhoans.AnyAsync(t => t.TenDangNhap == ten))
                return Loi("Tên đăng nhập này đã được dùng.", 409);

            var nv = new NhanVienGianHang
            {
                MaGianHang = id, TenDangNhap = ten, HoTen = hoTen, MatKhau = MatKhauHelper.Hash(r.MatKhau!),
                Quyen = QuyenNhanVien.Gop(quyen), TrangThai = true, NgayTao = DateTime.Now,
            };
            _db.NhanVienGianHangs.Add(nv);
            await _db.SaveChangesAsync();
            return Ok(Map(nv));
        }

        public record SuaNhanVienRequest(string? HoTen, List<string>? Quyen, bool? TrangThai);

        [HttpPut("gian-hang/{id:int}/nhan-vien/{maNV:int}")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> Sua(int id, int maNV, SuaNhanVienRequest r)
        {
            if (await QuanCuaToiAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var nv = await _db.NhanVienGianHangs.FirstOrDefaultAsync(n => n.MaNV == maNV && n.MaGianHang == id);
            if (nv == null) return Loi("Không tìm thấy nhân viên.", 404);
            if (r.HoTen != null)
            {
                var ht = r.HoTen.Trim();
                if (ht.Length < 2 || ht.Length > 100) return Loi("Họ tên không hợp lệ.");
                nv.HoTen = ht;
            }
            if (r.Quyen != null)
            {
                var q = QuyenNhanVien.ChuanHoa(r.Quyen);
                if (q.Count == 0) return Loi("Hãy chọn ít nhất một quyền cho nhân viên.");
                nv.Quyen = QuyenNhanVien.Gop(q);
            }
            if (r.TrangThai != null) nv.TrangThai = r.TrangThai.Value;
            await _db.SaveChangesAsync();
            _cache.Remove(NhanVienQuyenFilter.KhoaCache(nv.MaNV));      // quyền/khóa có hiệu lực ngay
            return Ok(Map(nv));
        }

        public record DatMatKhauRequest(string? MatKhau);

        [HttpPut("gian-hang/{id:int}/nhan-vien/{maNV:int}/mat-khau")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> DatLaiMatKhau(int id, int maNV, DatMatKhauRequest r)
        {
            if (await QuanCuaToiAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var nv = await _db.NhanVienGianHangs.FirstOrDefaultAsync(n => n.MaNV == maNV && n.MaGianHang == id);
            if (nv == null) return Loi("Không tìm thấy nhân viên.", 404);
            if ((r.MatKhau ?? "").Length < 6) return Loi("Mật khẩu tối thiểu 6 ký tự.");
            nv.MatKhau = MatKhauHelper.Hash(r.MatKhau!);
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã đặt lại mật khẩu cho nhân viên." });
        }

        [HttpDelete("gian-hang/{id:int}/nhan-vien/{maNV:int}")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> Xoa(int id, int maNV)
        {
            if (await QuanCuaToiAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var nv = await _db.NhanVienGianHangs.FirstOrDefaultAsync(n => n.MaNV == maNV && n.MaGianHang == id);
            if (nv == null) return Loi("Không tìm thấy nhân viên.", 404);
            _db.NhanVienGianHangs.Remove(nv);
            await _db.SaveChangesAsync();
            _cache.Remove(NhanVienQuyenFilter.KhoaCache(maNV));
            return Ok(new { thongDiep = "Đã xóa nhân viên." });
        }

        // =================================================================== NHÂN VIÊN
        public record DangNhapNvRequest(string? TenDangNhap, string? MatKhau);

        [HttpPost("gian-hang/nhan-vien/dang-nhap")]
        [AllowAnonymous]
        public async Task<IActionResult> DangNhap(DangNhapNvRequest r)
        {
            var ten = (r.TenDangNhap ?? "").Trim().ToLowerInvariant();
            const string chung = "Tên đăng nhập hoặc mật khẩu không đúng.";
            if (ten.Length == 0 || string.IsNullOrEmpty(r.MatKhau)) return Loi(chung, 401);

            // Chống dò mật khẩu: 5 lần sai liên tiếp → khóa đăng nhập tên này 10 phút
            var khoaSai = $"nvsai:{ten}";
            var soSai = _cache.TryGetValue<int>(khoaSai, out var n0) ? n0 : 0;
            if (soSai >= 5) return Loi("Đăng nhập sai quá nhiều lần. Vui lòng thử lại sau 10 phút.", 429);

            var nv = await _db.NhanVienGianHangs.FirstOrDefaultAsync(n => n.TenDangNhap == ten);
            if (nv == null || !MatKhauHelper.Khop(r.MatKhau, nv.MatKhau))
            {
                _cache.Set(khoaSai, soSai + 1, TimeSpan.FromMinutes(10));
                return Loi(chung, 401);
            }
            _cache.Remove(khoaSai);
            if (!nv.TrangThai) return Loi("Tài khoản nhân viên đã bị khóa. Hãy liên hệ chủ quán.", 401);

            var store = await _db.GianHangs.FirstOrDefaultAsync(g => g.MaGianHang == nv.MaGianHang);
            var tk = store == null ? null : await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == store.MaTK);
            if (store == null || tk == null) return Loi("Quán của nhân viên không còn tồn tại.", 401);
            if (!tk.TrangThai) return Loi("Tài khoản gian hàng đang bị khoá.", 401);
            if (store.TrangThaiDuyet != "DaDuyet") return Loi("Gian hàng chưa được duyệt hoặc đã bị từ chối.", 403);

            nv.LanDangNhapCuoi = DateTime.Now;
            await _db.SaveChangesAsync();
            return Ok(new
            {
                token = TaoToken(tk.MaTK, nv),
                gianHang = MobileApiController.MapGianHang(store, tk),
                nhanVien = Map(nv),
            });
        }

        private string TaoToken(int maTKChu, NhanVienGianHang nv)
        {
            var jwt = _config.GetSection("Jwt");
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt["Key"]!));
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, maTKChu.ToString()),     // MaTK chủ quán → API quán nhận ra quán này
                new Claim(ClaimTypes.Name, nv.TenDangNhap),
                new Claim(ClaimTypes.Role, "GianHang"),
                new Claim("nv", nv.MaNV.ToString()),                          // đánh dấu token nhân viên → bị lọc theo quyền
            };
            var token = new JwtSecurityToken(
                issuer: jwt["Issuer"], audience: jwt["Audience"], claims: claims,
                notBefore: DateTime.UtcNow,
                expires: DateTime.UtcNow.AddHours(Math.Min(12, double.Parse(jwt["ExpireHours"] ?? "8"))),
                signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private async Task<NhanVienGianHang?> NhanVienHienTaiAsync()
        {
            if (!int.TryParse(User.FindFirstValue("nv"), out var ma)) return null;
            return await _db.NhanVienGianHangs.FirstOrDefaultAsync(n => n.MaNV == ma);
        }

        /// <summary>Thông tin + quyền hiện tại của nhân viên đang đăng nhập (app gọi để cập nhật khi chủ quán đổi quyền).</summary>
        [HttpGet("nhan-vien/toi")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> Toi()
        {
            var nv = await NhanVienHienTaiAsync();
            if (nv == null) return Loi("Chỉ tài khoản nhân viên mới dùng được chức năng này.", 403);
            return Ok(Map(nv));
        }

        public record DoiMatKhauRequest(string? MatKhauCu, string? MatKhauMoi);

        [HttpPut("nhan-vien/mat-khau")]
        [Authorize(AuthenticationSchemes = Jwt, Roles = "GianHang")]
        public async Task<IActionResult> DoiMatKhau(DoiMatKhauRequest r)
        {
            var nv = await NhanVienHienTaiAsync();
            if (nv == null) return Loi("Chỉ tài khoản nhân viên mới dùng được chức năng này.", 403);
            if (!MatKhauHelper.Khop(r.MatKhauCu ?? "", nv.MatKhau)) return Loi("Mật khẩu hiện tại không đúng.");
            if ((r.MatKhauMoi ?? "").Length < 6) return Loi("Mật khẩu mới tối thiểu 6 ký tự.");
            nv.MatKhau = MatKhauHelper.Hash(r.MatKhauMoi!);
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã đổi mật khẩu." });
        }
    }
}
