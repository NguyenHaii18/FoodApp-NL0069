using System.Collections.Concurrent;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Services;
using FoodServiceApp.Web.Services.Maps;
using FoodServiceApp.Web.Services.Payment;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// Compatibility API dành riêng cho FoodApp.Maui.
    /// Giữ nguyên contract /api/mobile/* mà app đang gọi.
    /// </summary>
    [ApiController]
    [Route("api/mobile")]
    public class MobileApiController : ControllerBase
    {
        private const decimal PhiCoBan = 15000m;
        private const double KmMienPhi = 2.0;
        private const decimal PhiMoiKmThem = 5000m;
        private const decimal PhuPhiNgoaiThanh = 10000m;
        private const decimal PhiToiDa = 70000m;

        // App cần vị trí tài xế cập nhật theo chu kỳ. DB hiện chưa có bảng vị trí,
        // nên lưu phiên hiện tại trong memory; dữ liệu vẫn được trả về cho app trong
        // cùng thời gian server đang chạy. Khi cần lưu bền vững, thêm bảng TaiXeViTri.
        private static readonly ConcurrentDictionary<int, ViTriNho> DriverPositions = new();

        private readonly AppDbContext _db;
        private readonly IConfiguration _config;
        private readonly IGoongMapsService _maps;
        private readonly IVnPayService _vnpay;

        public MobileApiController(AppDbContext db, IConfiguration config, IGoongMapsService maps, IVnPayService vnpay)
        {
            _db = db;
            _config = config;
            _maps = maps;
            _vnpay = vnpay;
        }

        private int CurrentMaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private string CurrentRole => User.FindFirstValue(ClaimTypes.Role) ?? "";

        private static IActionResult Loi(string thongDiep, int status = 400) =>
            new ObjectResult(new { thongDiep }) { StatusCode = status };

        private string CreateToken(int maTK, string tenDangNhap, string vaiTro)
        {
            var jwt = _config.GetSection("Jwt");
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt["Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
            // v69: mỗi lần đăng nhập trên app ghi một "phiên" (PhienDangNhap) để người dùng xem / đăng xuất từng thiết bị.
            var phien = new PhienDangNhap
            {
                MaPhien = Guid.NewGuid(), MaTK = maTK, Kenh = "mobile",
                ThietBi = TenThietBi(), DiaChiIP = HttpContext.Connection.RemoteIpAddress?.ToString(),
            };
            _db.PhienDangNhaps.Add(phien);
            try { _db.SaveChanges(); } catch { /* không ghi được phiên thì vẫn cho đăng nhập */ }
            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, maTK.ToString()),
                new Claim(ClaimTypes.Name, tenDangNhap),
                new Claim(ClaimTypes.Role, vaiTro),
                new Claim("MaPhien", phien.MaPhien.ToString()),
            };
            var token = new JwtSecurityToken(
                issuer: jwt["Issuer"],
                audience: jwt["Audience"],
                claims: claims,
                notBefore: DateTime.UtcNow,
                expires: DateTime.UtcNow.AddHours(double.Parse(jwt["ExpireHours"] ?? "8")),
                signingCredentials: creds);
            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        /// <summary>Tên thiết bị cho danh sách phiên: header X-Thiet-Bi do app gửi, nếu không có thì User-Agent.</summary>
        private string TenThietBi()
        {
            var t = Request.Headers["X-Thiet-Bi"].ToString();
            if (string.IsNullOrWhiteSpace(t)) t = Request.Headers.UserAgent.ToString();
            t = t.Trim();
            return t.Length == 0 ? "Thiết bị không rõ" : (t.Length > 200 ? t[..200] : t);
        }

        /// <summary>Chuẩn hóa SĐT: bỏ ký tự không phải số, +84/84 → 0. Trả "" nếu không phải SĐT hợp lệ (9–11 số).</summary>
        private static string ChuanHoaSdt(string? s)
        {
            var d = new string((s ?? "").Where(char.IsDigit).ToArray());
            if (d.StartsWith("84") && d.Length >= 11) d = "0" + d[2..];
            return d.Length is >= 9 and <= 11 && d.StartsWith('0') ? d : "";
        }

        /// <summary>Trong giờ hoạt động? Hỗ trợ ca qua đêm (vd 18:00 → 02:00). 00:00–23:59 = cả ngày.</summary>
        private static bool StoreOpenNow(GianHang g)
        {
            var now = DateTime.Now.TimeOfDay;
            if (g.GioMoCua == g.GioDongCua) return true;
            return g.GioMoCua < g.GioDongCua ? now >= g.GioMoCua && now <= g.GioDongCua : now >= g.GioMoCua || now <= g.GioDongCua;
        }

        private static bool IsPaymentCash(string hinhThuc) => string.Equals(hinhThuc, "TienMat", StringComparison.OrdinalIgnoreCase);

        // Chỉ hai hình thức đã triển khai đầy đủ. Chuyển khoản / ví điện tử sẽ thêm khi có cổng tương ứng.
        private static bool IsValidPayment(string hinhThuc) =>
            string.Equals(hinhThuc, "TienMat", StringComparison.OrdinalIgnoreCase) ||
            string.Equals(hinhThuc, "VNPay", StringComparison.OrdinalIgnoreCase);

        // ============================== Catalog ==============================

        /// <summary>Phí & chính sách đang áp dụng (do quản trị thiết lập) — cho app hiển thị cho khách / gian hàng / tài xế.</summary>
        [HttpGet("chinh-sach")]
        [AllowAnonymous]
        public async Task<IActionResult> ChinhSach() =>
            Ok(await FoodServiceApp.Web.Controllers.ChinhSachCongKhai.LayAsync(new CauHinhService(_db)));

        [HttpGet("gian-hang")]
        [HttpGet("~/api/restaurants")]
        [AllowAnonymous]
        public async Task<IActionResult> GianHang()
        {
            var stores = await _db.GianHangs
                .Include(g => g.TaiKhoan)
                .Where(g => g.TrangThaiDuyet == "DaDuyet" && g.TrangThaiKinhDoanh == "DangMo")
                .OrderBy(g => g.MaGianHang)
                .ToListAsync();

            // Tên danh mục + tên món của từng quán (1 truy vấn) để suy ra loại quán cho bộ lọc danh mục ở app
            var storeIds = stores.Select(g => g.MaGianHang).ToList();
            var tenMonTheoQuan = (await _db.MonAns.AsNoTracking()
                    .Where(m => m.DanhMuc != null && storeIds.Contains(m.DanhMuc.MaGianHang))
                    .Select(m => new { m.DanhMuc!.MaGianHang, DanhMuc = m.DanhMuc.TenDanhMuc, m.TenMon })
                    .ToListAsync())
                .GroupBy(x => x.MaGianHang)
                .ToDictionary(x => x.Key, x => x.SelectMany(i => new[] { i.DanhMuc, i.TenMon }).Distinct().ToList());

            var results = new List<object>();
            foreach (var g in stores)
            {
                var ratings = await _db.DanhGias.Where(x => !x.DaAn && x.MaGianHang == g.MaGianHang).Select(x => x.SoSao).ToListAsync();
                var phanLoai = FoodServiceApp.Web.Services.PhanLoaiGianHang.Tinh(g.TenCuaHang,
                    tenMonTheoQuan.TryGetValue(g.MaGianHang, out var tm) ? tm : new List<string>());
                results.Add(new
                {
                    id = g.MaGianHang,
                    tenGianHang = g.TenCuaHang,
                    diaChi = g.DiaChi,
                    hinhAnh = g.HinhAnh ?? "🍽️",
                    anhBia = g.AnhBia,
                    phanLoai,
                    danhGia = ratings.Count == 0 ? 0d : ratings.Average(),
                    thoiGianGiaoPhut = 30,
                    soDienThoai = g.SDT,
                    email = g.TaiKhoan == null ? "" : (g.TaiKhoan.TenDangNhap.Contains("@") ? g.TaiKhoan.TenDangNhap : $"{g.TaiKhoan.TenDangNhap}@gianhang.vn"),
                    moTa = g.MoTa ?? "",
                    dangMoCua = g.TrangThaiKinhDoanh == "DangMo",
                    taiKhoanBiKhoa = g.TaiKhoan != null && !g.TaiKhoan.TrangThai,
                    ngayDangKy = g.NgayDangKy,
                    trangThaiDangKy = g.TrangThaiDuyet
                });
            }
            return Ok(results);
        }

        [HttpGet("mon-an")]
        [AllowAnonymous]
        public async Task<IActionResult> MonAn()
        {
            var foods = await _db.MonAns
                .Include(m => m.DanhMuc)
                .Where(m => m.DanhMuc != null &&
                            m.DanhMuc.GianHang != null &&
                            m.DanhMuc.GianHang.TrangThaiDuyet == "DaDuyet" &&
                            m.DanhMuc.GianHang.TrangThaiKinhDoanh == "DangMo")
                .OrderBy(m => m.MaMonAn)
                .Select(m => new
                {
                    id = m.MaMonAn,
                    tenMon = m.TenMon,
                    gia = m.Gia,
                    hinhAnh = m.HinhAnh ?? "🍲",
                noiBat = m.NoiBat,
                    danhMuc = m.DanhMuc!.TenDanhMuc,
                    gianHangId = m.DanhMuc.MaGianHang,
                    conHang = m.TinhTrang == "ConHang",
                    tonKho = m.SoLuongTon,
                    tamNgungBan = m.TinhTrang == "TamNgung",
                    choGhiChu = m.ChoGhiChu,
                    moTa = m.MoTa ?? "",
                    tuyChon = _db.TuyChonMons.Where(t => t.MaMonAn == m.MaMonAn)
                        .OrderBy(t => t.Loai).ThenBy(t => t.MaTuyChon)
                        .Select(t => new { id = t.MaTuyChon, loai = t.Loai, ten = t.TenTuyChon, giaThem = t.GiaThem })
                        .ToList()
                })
                .ToListAsync();
            return Ok(foods);
        }

        [HttpGet("chien-dich")]
        [AllowAnonymous]
        public async Task<IActionResult> ChienDichDangChay([FromQuery] string? viTri)
        {
            var now = DateTime.Now;
            var query = _db.ChienDichQuangCaos.Where(x => x.TrangThai == "DangChay" &&
                x.NgayBatDau <= now && x.NgayKetThuc > now &&
                x.GianHang!.TrangThaiDuyet == "DaDuyet" &&
                x.GianHang.TrangThaiKinhDoanh == "DangMo" && x.GianHang.TaiKhoan!.TrangThai);
            if (!string.IsNullOrWhiteSpace(viTri)) query = query.Where(x => x.LoaiViTri == viTri);
            return Ok(await query.OrderByDescending(x => x.NganSach).Select(x => new
            {
                x.MaChienDich,
                x.MaGianHang,
                x.TieuDe,
                x.NoiDung,
                x.HinhAnh,
                x.LoaiViTri,
                TenGianHang = x.GianHang!.TenCuaHang
            }).ToListAsync());
        }

        [HttpPost("chien-dich/{id:int}/tuong-tac")]
        [AllowAnonymous]
        public async Task<IActionResult> GhiNhanTuongTacChienDich(int id)
        {
            var now = DateTime.Now;
            var campaign = await _db.ChienDichQuangCaos.SingleOrDefaultAsync(x => x.MaChienDich == id &&
                x.TrangThai == "DangChay" && x.NgayBatDau <= now && x.NgayKetThuc > now);
            if (campaign == null) return NotFound();
            campaign.LuotTuongTac++;
            await _db.SaveChangesAsync();
            return NoContent();
        }

        /// <summary>Banner đang hiển thị (đã bật, trong khoảng ngày), theo thứ tự.</summary>
        [HttpGet("banner")]
        [AllowAnonymous]
        public async Task<IActionResult> Banner()
        {
            var now = DateTime.Now;
            var ds = await _db.Banners.AsNoTracking()
                .Where(b => b.TrangThai && (b.NgayBatDau == null || b.NgayBatDau <= now) && (b.NgayKetThuc == null || b.NgayKetThuc >= now.Date))
                .OrderBy(b => b.ThuTu).ThenByDescending(b => b.NgayTao).Take(10)
                .Select(b => new { id = b.MaBanner, tieuDe = b.TieuDe, hinhAnh = b.HinhAnh, lienKet = b.LienKet }).ToListAsync();
            return Ok(ds);
        }

        [HttpGet("khuyen-mai")]
        [AllowAnonymous]
        public async Task<IActionResult> KhuyenMai()
        {
            var now = DateTime.Now;
            var promotions = await _db.KhuyenMais
                .Where(k => k.TrangThai && k.NgayBatDau <= now && k.NgayKetThuc >= now && (k.MoTa == null || !k.MoTa.StartsWith("DOIDIEM|")))
                .OrderByDescending(k => k.NgayKetThuc)
                .ToListAsync();
            var ids = promotions.Select(k => k.MaKhuyenMai).ToList();
            var mons = (await _db.KhuyenMaiMonAns.Where(x => ids.Contains(x.MaKhuyenMai)).ToListAsync()).ToLookup(x => x.MaKhuyenMai, x => x.MaMonAn.ToString());
            var dmIds = await _db.KhuyenMaiDanhMucs.Where(x => ids.Contains(x.MaKhuyenMai)).ToListAsync();
            var tenDm = await _db.DanhMucs.Where(d => dmIds.Select(x => x.MaDanhMuc).Contains(d.MaDanhMuc)).ToDictionaryAsync(d => d.MaDanhMuc, d => d.TenDanhMuc);
            var quans = (await _db.KhuyenMaiGianHangs.Where(x => ids.Contains(x.MaKhuyenMai)).ToListAsync()).ToLookup(x => x.MaKhuyenMai, x => x.MaGianHang.ToString());

            return Ok(promotions.Select(k => new
            {
                id = k.MaKhuyenMai,
                maCode = k.MaCode,
                tenChuongTrinh = string.IsNullOrWhiteSpace(k.TenChuongTrinh) ? (k.MoTa ?? k.MaCode) : k.TenChuongTrinh,
                moTa = k.MoTa ?? "",
                loaiGiam = k.LoaiGiam == "GiamPhiVanChuyen" ? "GiamPhiVanChuyen" : (k.PhanTramGiam != null ? "PhanTram" : "SoTien"),
                giaTriGiam = k.PhanTramGiam ?? k.SoTienGiam ?? 0,
                giaTriDonToiThieu = k.GiaTriDonToiThieu,
                giamToiDa = k.GiamToiDa,
                ngayBatDau = k.NgayBatDau,
                ngayKetThuc = k.NgayKetThuc,
                gianHangId = k.MaGianHang,
                soLuongToiDa = k.SoLuongToiDa ?? int.MaxValue,
                soLuongDaDung = k.SoLuongDaDung,
                moiKhachMotLan = k.MoiKhachMotLan,
                monApDung = mons[k.MaKhuyenMai].ToList(),
                danhMucApDung = dmIds.Where(x => x.MaKhuyenMai == k.MaKhuyenMai).Select(x => tenDm.GetValueOrDefault(x.MaDanhMuc, "")).Where(t => t != "").ToList(),
                gianHangApDung = quans[k.MaKhuyenMai].ToList(),
                dangHoatDong = k.TrangThai
            }));
        }

        // ============================== Auth ==============================

        public record CustomerLoginRequest(string Email, string MatKhau);
        public record CustomerRegisterRequest(string HoTen, string Sdt, string Email, string MatKhau, string? DiaChi, bool DongYDieuKhoan = false);
        public record VendorLoginRequest(string Email, string MatKhau);
        public record DriverLoginRequest(string Sdt, string MatKhau);
        public record AdminLoginRequest(string Email, string MatKhau);

        [HttpPost("khach-hang/dang-nhap")]
        [AllowAnonymous]
        public async Task<IActionResult> CustomerLogin(CustomerLoginRequest request)
        {
            var email = request.Email?.Trim() ?? "";
            // v69: ô đăng nhập nhận email HOẶC số điện thoại.
            var sdtDn = email.Contains('@') ? "" : ChuanHoaSdt(email);
            var kh = await _db.KhachHangs.FirstOrDefaultAsync(k => k.Email == email || (sdtDn != "" && k.SDT == sdtDn));
            if (kh == null) return Loi("Tài khoản hoặc mật khẩu không đúng.", 401);

            var tk = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == kh.MaTK && t.VaiTro == "KhachHang");
            if (tk == null || !await BaoMat.KhopAsync(_db, HttpContext, request.MatKhau, tk)) return Loi("Email hoặc mật khẩu không đúng.", 401);
            if (!tk.TrangThai) return Loi("Tài khoản đã bị khoá.", 401);

            return Ok(new
            {
                token = CreateToken(tk.MaTK, tk.TenDangNhap, "KhachHang"),
                khachHang = MapKhachHang(kh, tk)
            });
        }

        [HttpPost("khach-hang/dang-ky")]
        [HttpPost("~/api/auth/register")]
        [HttpPost("~/api/auth/register/khach-hang")]
        [AllowAnonymous]
        public async Task<IActionResult> CustomerRegister(CustomerRegisterRequest request)
        {
            // v69: đăng ký bằng email HOẶC số điện thoại (cần ít nhất một), bắt buộc đồng ý điều khoản.
            var email = request.Email?.Trim() ?? "";
            var sdt = ChuanHoaSdt(request.Sdt);
            if (!request.DongYDieuKhoan) return Loi("Bạn cần đồng ý Điều khoản sử dụng và Chính sách quyền riêng tư để đăng ký.");
            if (email != "" && !email.Contains('@')) return Loi("Email không hợp lệ.");
            if (email == "" && sdt == "") return Loi("Vui lòng nhập email hoặc số điện thoại hợp lệ.");
            if (email == "" && !string.IsNullOrWhiteSpace(request.Sdt) && sdt == "") return Loi("Số điện thoại không hợp lệ.");
            if (string.IsNullOrWhiteSpace(request.HoTen)) return Loi("Vui lòng nhập họ tên.");
            if (string.IsNullOrWhiteSpace(request.MatKhau) || request.MatKhau.Length < 6) return Loi("Mật khẩu tối thiểu 6 ký tự.");
            if (email != "" && await _db.KhachHangs.AnyAsync(k => k.Email == email)) return Loi("Email này đã được đăng ký.", 409);
            if (sdt != "" && await _db.KhachHangs.AnyAsync(k => k.SDT == sdt)) return Loi("Số điện thoại này đã được đăng ký.", 409);
            var tenDn = email != "" ? email : sdt;
            if (await _db.TaiKhoans.AnyAsync(t => t.TenDangNhap == tenDn)) return Loi("Tài khoản đã tồn tại.", 409);

            var tk = new TaiKhoan
            {
                TenDangNhap = tenDn,
                DongYDieuKhoanLuc = DateTime.Now,
                MatKhau = MatKhauHelper.Hash(request.MatKhau),
                VaiTro = "KhachHang",
                TrangThai = true,
            };
            _db.TaiKhoans.Add(tk);
            await _db.SaveChangesAsync();

            var kh = new KhachHang
            {
                MaTK = tk.MaTK,
                HoTen = request.HoTen.Trim(),
                SDT = sdt != "" ? sdt : (request.Sdt?.Trim() ?? ""),
                Email = email == "" ? null : email,
                DiaChiGiaoHang = string.IsNullOrWhiteSpace(request.DiaChi) ? null : request.DiaChi.Trim()
            };
            _db.KhachHangs.Add(kh);
            await _db.SaveChangesAsync();

            if (!string.IsNullOrWhiteSpace(kh.DiaChiGiaoHang))
            {
                _db.DiaChiKhachHangs.Add(new DiaChiKhachHang
                {
                    MaKH = kh.MaKH,
                    Nhan = "Nhà",
                    DiaChi = kh.DiaChiGiaoHang,
                    MacDinh = true
                });
                await _db.SaveChangesAsync();
            }

            return Ok(new
            {
                token = CreateToken(tk.MaTK, tk.TenDangNhap, "KhachHang"),
                khachHang = MapKhachHang(kh, tk)
            });
        }

        [HttpPost("gian-hang/dang-nhap")]
        [AllowAnonymous]
        public async Task<IActionResult> VendorLogin(VendorLoginRequest request)
        {
            var email = request.Email?.Trim() ?? "";
            var loginName = email.EndsWith("@gianhang.vn", StringComparison.OrdinalIgnoreCase)
                ? email[..email.IndexOf('@')]
                : email;
            // Tài khoản mẫu (FoodService_DuLieuMau.sql) lưu TenDangNhap = "bunchahuonglien" còn email nằm ở GianHang.Email,
            // nên ngoài khớp TenDangNhap còn phải tra theo GianHang.Email (không phân biệt hoa/thường).
            var emailThuong = email.ToLower();
            var tk = await _db.TaiKhoans.FirstOrDefaultAsync(t =>
                (t.TenDangNhap == email || t.TenDangNhap == loginName) && t.VaiTro == "GianHang");
            GianHang? store = null;
            if (tk == null && emailThuong.Length > 0)
            {
                store = await _db.GianHangs.FirstOrDefaultAsync(g => g.Email != null && g.Email.ToLower() == emailThuong);
                if (store != null) tk = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == store.MaTK && t.VaiTro == "GianHang");
            }
            if (tk == null) return Loi("Email hoặc mật khẩu không đúng.", 401);
            store ??= await _db.GianHangs.FirstOrDefaultAsync(g => g.MaTK == tk.MaTK);
            if (store == null) return Loi("Email hoặc mật khẩu không đúng.", 401);
            if (tk == null || !await BaoMat.KhopAsync(_db, HttpContext, request.MatKhau, tk)) return Loi("Email hoặc mật khẩu không đúng.", 401);
            if (!tk.TrangThai) return Loi("Tài khoản gian hàng đang bị khoá.", 401);
            if (store.TrangThaiDuyet == "ChoDuyet") return Loi("Hồ sơ gian hàng đang chờ quản trị viên duyệt.", 403);
            if (store.TrangThaiDuyet == "TuChoi") return Loi("Hồ sơ gian hàng đã bị từ chối.", 403);

            return Ok(new
            {
                token = CreateToken(tk.MaTK, tk.TenDangNhap, "GianHang"),
                gianHang = MapGianHang(store, tk)
            });
        }

        [HttpPost("gian-hang/dang-ky")]
        [HttpPost("~/api/auth/register/gian-hang")]
        [AllowAnonymous]
        public async Task<IActionResult> VendorRegister(MobileVendorRegisterRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.TenGianHang) || string.IsNullOrWhiteSpace(request.DiaChi)) return Loi("Tên và địa chỉ gian hàng không được để trống.");
            if (string.IsNullOrWhiteSpace(request.Email) || !request.Email.Contains('@')) return Loi("Email không hợp lệ.");
            if (request.MatKhau?.Length < 6) return Loi("Mật khẩu tối thiểu 6 ký tự.");
            if (await _db.TaiKhoans.AnyAsync(t => t.TenDangNhap == request.Email.Trim())) return Loi("Email này đã được đăng ký.", 409);

            var tk = new TaiKhoan
            {
                TenDangNhap = request.Email.Trim(),
                MatKhau = MatKhauHelper.Hash(request.MatKhau),
                VaiTro = "GianHang",
                TrangThai = true,
            };
            _db.TaiKhoans.Add(tk);
            await _db.SaveChangesAsync();

            var gh = new GianHang
            {
                MaTK = tk.MaTK,
                TenCuaHang = request.TenGianHang.Trim(),
                DiaChi = request.DiaChi.Trim(),
                SDT = request.Sdt?.Trim() ?? "",
                MoTa = request.MoTa?.Trim(),
                HinhAnh = request.HinhAnh,
                TrangThaiKinhDoanh = "DongCua",
                TrangThaiDuyet = "ChoDuyet",
                NgayDangKy = DateTime.Now,
                TyLeChietKhau = await FoodServiceApp.Web.Services.CauHinhService.HoaHongMacDinhAsync(_db),
            };
            _db.GianHangs.Add(gh);
            await _db.SaveChangesAsync();

            return Ok(new { id = gh.MaGianHang, trangThaiDangKy = gh.TrangThaiDuyet });
        }

        public record MobileDriverRegisterRequest(string HoTen, string SoDienThoai, string? SoCccd, string? LoaiXe, string? BienSoXe, string? SoGplx, string MatKhau);
        public record MobileLyDoRequest(string? LyDo);

        /// <summary>Tài xế tự đăng ký -> hồ sơ ở trạng thái ChoDuyet, quản trị viên duyệt rồi mới đăng nhập được.</summary>
        [HttpPost("tai-xe/dang-ky")]
        [HttpPost("~/api/auth/register/tai-xe")]
        [AllowAnonymous]
        public async Task<IActionResult> DriverRegister(MobileDriverRegisterRequest request)
        {
            var sdt = NormalizePhone(request.SoDienThoai ?? "");
            if (string.IsNullOrWhiteSpace(request.HoTen)) return Loi("Họ tên không được để trống.");
            if (string.IsNullOrWhiteSpace(sdt) || sdt.Length < 9) return Loi("Số điện thoại không hợp lệ.");
            if (request.MatKhau == null || request.MatKhau.Length < 6) return Loi("Mật khẩu tối thiểu 6 ký tự.");
            if (await _db.TaiXes.AnyAsync(t => t.SDT == sdt) || await _db.TaiKhoans.AnyAsync(t => t.TenDangNhap == sdt))
                return Loi("Số điện thoại này đã được đăng ký.", 409);

            var tk = new TaiKhoan { TenDangNhap = sdt, MatKhau = MatKhauHelper.Hash(request.MatKhau), VaiTro = "TaiXe", TrangThai = true };
            _db.TaiKhoans.Add(tk);
            await _db.SaveChangesAsync();

            var tx = new TaiXe
            {
                MaTK = tk.MaTK,
                HoTen = request.HoTen.Trim(),
                SDT = sdt,
                PhuongTien = request.LoaiXe?.Trim(),
                BienSo = request.BienSoXe?.Trim(),
                SoCCCD = request.SoCccd?.Trim(),
                SoGPLX = request.SoGplx?.Trim(),
                TrangThai = "NgoaiTuyen",
                TrangThaiDuyet = "ChoDuyet",
                NgayDangKy = DateTime.Now,
            };
            _db.TaiXes.Add(tx);
            await _db.SaveChangesAsync();
            return Ok(new { id = tx.MaTaiXe, trangThaiDangKy = tx.TrangThaiDuyet });
        }

        [HttpPost("tai-xe/dang-nhap")]
        [AllowAnonymous]
        public async Task<IActionResult> DriverLogin(DriverLoginRequest request)
        {
            // Ô "Sdt" nhận số điện thoại HOẶC tên đăng nhập (tài khoản mẫu taixe01... chỉ có tên đăng nhập trên web).
            var raw = request.Sdt?.Trim() ?? "";
            var sdt = NormalizePhone(raw);
            var tx = sdt.Length > 0 ? await _db.TaiXes.FirstOrDefaultAsync(t => t.SDT == sdt || t.SDT == raw) : null;
            if (tx == null && raw.Length > 0)
            {
                var ten = raw.ToLower();
                var tkTen = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.VaiTro == "TaiXe" && t.TenDangNhap.ToLower() == ten);
                if (tkTen != null) tx = await _db.TaiXes.FirstOrDefaultAsync(t => t.MaTK == tkTen.MaTK);
            }
            if (tx == null) return Loi("Sai số điện thoại hoặc mật khẩu.", 401);
            var tk = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == tx.MaTK && t.VaiTro == "TaiXe");
            if (tk == null || !await BaoMat.KhopAsync(_db, HttpContext, request.MatKhau, tk)) return Loi("Sai số điện thoại hoặc mật khẩu.", 401);
            if (!tk.TrangThai) return Loi("Tài khoản tài xế đã bị khoá. Vui lòng liên hệ quản trị viên.", 403);
            if (tx.TrangThaiDuyet == "TuChoi")
                return Loi("Hồ sơ tài xế bị từ chối. Lý do: " + (string.IsNullOrWhiteSpace(tx.LyDoTuChoi) ? "hồ sơ không đạt yêu cầu" : tx.LyDoTuChoi), 403);
            if (tx.TrangThaiDuyet != "DaDuyet")
                return Loi("Hồ sơ tài xế đang chờ duyệt." + (string.IsNullOrWhiteSpace(tx.YeuCauBoSung) ? "" : " Yêu cầu bổ sung: " + tx.YeuCauBoSung), 403);
            return Ok(new { token = CreateToken(tk.MaTK, tk.TenDangNhap, "TaiXe"), soDienThoai = tx.SDT, hoTen = tx.HoTen });
        }

        [HttpPost("admin/dang-nhap")]
        [AllowAnonymous]
        public async Task<IActionResult> AdminLogin(AdminLoginRequest request)
        {
            var email = request.Email?.Trim() ?? "";
            var admin = await _db.QuanTris.FirstOrDefaultAsync(q => q.Email == email);
            if (admin == null) return Loi("Email hoặc mật khẩu không đúng.", 401);
            var tk = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == admin.MaTK && t.VaiTro == "QuanTri");
            // Báo RÕ khi đang bị khóa tạm do nhập sai nhiều lần (trước đây vẫn hiện "Email hoặc mật khẩu không đúng" nên không biết vì sao).
            var thongBaoKhoa = BaoMat.ThongBaoKhoa(tk);
            if (thongBaoKhoa != null) return Loi(thongBaoKhoa, 429);
            if (tk == null || !await BaoMat.KhopAsync(_db, HttpContext, request.MatKhau, tk)) return Loi("Email hoặc mật khẩu không đúng.", 401);
            if (!tk.TrangThai) return Loi("Tài khoản đã bị khoá.", 401);
            // vaiTro: SuperAdmin | QuanLy | NhanVien — app MAUI dùng để ẩn/khóa chức năng theo quyền (server vẫn kiểm tra lại)
            // quyen = các khóa quyền chi tiết của Web (QuyenAdmin: DonHang, ThanhToan, HoanTien, DanhGia, ThongBao) để app ẩn/khóa đúng như Web.
            var quyen = FoodServiceApp.Web.Services.QuyenAdmin.Hieu(admin.CapQuyenHan, admin.QuyenChiTiet).OrderBy(x => x).ToArray();
            return Ok(new { token = CreateToken(tk.MaTK, tk.TenDangNhap, "QuanTri"), vaiTro = admin.CapQuyenHan, capQuyenHan = admin.CapQuyenHan, quyen, hoTen = admin.HoTen });
        }

        // ============================== Customer ==============================

        [HttpGet("khach-hang/don-hang")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> CustomerOrders()
        {
            var kh = await CurrentCustomerAsync();
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            var orders = await _db.DonHangs
                .Include(d => d.GianHang)
                .Include(d => d.KhachHang)
                .Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .Include(d => d.GiaoHang).ThenInclude(g => g!.TaiXe)
                .Include(d => d.ThanhToan)
                .Include(d => d.KhuyenMaiApDung)
                .Where(d => d.MaKH == kh.MaKH)
                .OrderByDescending(d => d.NgayDat)
                .ToListAsync();
            await HydratePositionsAsync(orders.Where(o => o.TrangThai == "DangGiao").Select(o => o.MaDonHang).ToList());
            return Ok(orders.Select(o => MapMobileOrder(o, true)));
        }

        [HttpPost("don-hang")]
        [HttpPost("~/api/orders")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> PlaceOrder(MobilePlaceOrderRequest request)
        {
            var kh = await CurrentCustomerAsync();
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            if (request.ChiTiet is null || request.ChiTiet.Count == 0) return Loi("Giỏ hàng đang trống.");
            if (string.IsNullOrWhiteSpace(request.DiaChiGiao)) return Loi("Vui lòng nhập địa chỉ giao hàng.");
            if (!IsValidPayment(request.HinhThucThanhToan)) return Loi("Hình thức thanh toán không hợp lệ.");
            // v66: đặt theo lịch — giờ nhận phải sau hiện tại ít nhất 30 phút và không quá 7 ngày; giờ client gửi là giờ địa phương của khách (cùng múi giờ máy chủ)
            DateTime? henGiao = null;
            if (request.HenGiaoLuc is { } hg)
            {
                if (hg < DateTime.Now.AddMinutes(30) || hg > DateTime.Now.AddDays(7)) return Loi("Giờ hẹn giao phải sau hiện tại ít nhất 30 phút và trong vòng 7 ngày.");
                henGiao = new DateTime(hg.Year, hg.Month, hg.Day, hg.Hour, hg.Minute, 0);
            }

            // Chống tạo đơn trùng (bấm đúp / app gửi lại sau khi mất mạng): cùng token của cùng khách chỉ tạo một đơn.
            // Kiểm tra TRƯỚC khi giữ lượt khuyến mãi để lần gửi lại không trừ mã thêm lần nữa.
            var maYeuCau = string.IsNullOrWhiteSpace(request.MaYeuCauDat) ? null : request.MaYeuCauDat.Trim();
            if (maYeuCau is { Length: > 64 }) return Loi("Mã yêu cầu đặt hàng không hợp lệ.");
            if (maYeuCau != null)
            {
                var daCo = await _db.DonHangs.AsNoTracking().Where(d => d.MaKH == kh.MaKH && d.MaYeuCauDat == maYeuCau)
                    .Select(d => new { d.MaDonHang, d.TongTien, d.PhiGiaoHang, d.TienGiam, d.KhoangCachKm, d.ThoiGianDuKienPhut, d.MaXacNhanGiao })
                    .FirstOrDefaultAsync();
                if (daCo != null)
                    return Ok(new
                    {
                        id = daCo.MaDonHang, maDonHang = daCo.MaDonHang,
                        tongTienMon = daCo.TongTien + daCo.TienGiam - daCo.PhiGiaoHang, giamGia = daCo.TienGiam,
                        phiGiaoHang = daCo.PhiGiaoHang, khoangCachKm = daCo.KhoangCachKm, thoiGianDuKienPhut = daCo.ThoiGianDuKienPhut,
                        tongTien = daCo.TongTien, maXacNhanGiao = daCo.MaXacNhanGiao, paymentUrl = (string?)null, daTonTai = true
                    });
            }

            var store = await _db.GianHangs.FirstOrDefaultAsync(g =>
                g.MaGianHang == request.GianHangId && g.TrangThaiDuyet == "DaDuyet" && g.TrangThaiKinhDoanh == "DangMo");
            if (store == null) return Loi("Gian hàng không còn hoạt động.", 404);
            if (!store.DangNhanDon) return Loi("Gian hàng đang tạm dừng nhận đơn.");
            if (!StoreOpenNow(store)) return Loi($"Gian hàng ngoài giờ hoạt động ({store.GioMoCua:hh\\:mm} – {store.GioDongCua:hh\\:mm}).");

            if (request.ChiTiet.Any(x => x.SoLuong <= 0)) return Loi("Số lượng món phải lớn hơn 0.");
            var ids = request.ChiTiet.Select(x => x.MonAnId).Distinct().ToList();
            var foods = await _db.MonAns.Include(m => m.DanhMuc).Where(m => ids.Contains(m.MaMonAn)).ToListAsync();
            if (foods.Count != ids.Count || foods.Any(m => m.DanhMuc?.MaGianHang != store.MaGianHang)) return Loi("Có món ăn không thuộc gian hàng đã chọn.");
            if (foods.Any(m => m.TinhTrang != "ConHang")) return Loi("Có món ăn hiện đã hết hàng.");
            // v95: tồn kho do Server quyết định (cộng dồn các dòng cùng món); trừ ngay trong lần lưu đơn, có token đồng thời chống bán lố
            foreach (var f in foods.Where(m => m.SoLuongTon != null))
            {
                var can = request.ChiTiet.Where(x => x.MonAnId == f.MaMonAn).Sum(x => x.SoLuong);
                if (f.SoLuongTon < can) return Loi(f.SoLuongTon <= 0 ? $"{f.TenMon} đã hết hàng." : $"{f.TenMon} chỉ còn {f.SoLuongTon} phần.");
            }

            // Tính từng dòng: đơn giá = giá món + phụ thu các tùy chọn đã chọn (size/mức cay/topping) — kiểm tra hợp lệ trên server
            var dong = new List<(MobilePlaceOrderItem Item, MonAn Mon, decimal DonGia, string? TuyChonText)>();
            foreach (var i in request.ChiTiet)
            {
                var f = foods.First(x => x.MaMonAn == i.MonAnId);
                var (chon, loiTc) = await TuyChonHelper.KiemTraAsync(_db, f.MaMonAn, i.TuyChonIds ?? new List<int>());
                if (loiTc != null) return Loi($"{f.TenMon}: {loiTc}");
                if ((i.TuyChonIds?.Distinct().Count() ?? 0) != chon.Count) return Loi($"{f.TenMon}: có tùy chọn không hợp lệ.");
                var text = chon.Count == 0 ? null : string.Join("; ", chon.Select(c => c.TenTuyChon));
                dong.Add((i, f, f.Gia + chon.Sum(c => c.GiaThem), text));
            }
            var tongTienMon = dong.Sum(d => d.DonGia * d.Item.SoLuong);
            var route = await CalculateDeliveryAsync(store.DiaChi, request.DiaChiGiao);
            var dongKm = dong.Select(d => new DongGioKm(d.Mon.MaMonAn, d.Mon.MaDanhMuc, d.DonGia, d.Item.SoLuong)).ToList();
            var kmKq = await KhuyenMaiXuLy.TinhAsync(_db, request.MaKhuyenMai, store.MaGianHang, kh.MaKH, dongKm, route.Phi);
            if (kmKq.Loi != null) return Loi(kmKq.Loi);
            var giamGia = kmKq.Giam;
            int? maKm = kmKq.Km?.MaKhuyenMai;
            var tongThanhToan = Math.Max(0, tongTienMon + route.Phi - giamGia);
            if (kmKq.Km != null && !await KhuyenMaiXuLy.GiuLuotAsync(_db, kmKq.Km)) return Loi("Mã khuyến mãi vừa hết lượt sử dụng.");

            var maXacNhan = FoodServiceApp.Web.Services.GiaoHangXuLy.TaoMa();   // lưu cột riêng, KHÔNG để trong ghi chú (tài xế đọc được ghi chú)
            var ghiChu = string.IsNullOrWhiteSpace(request.GhiChu) ? null : request.GhiChu.Trim();

            var don = new DonHang
            {
                MaKH = kh.MaKH,
                MaGianHang = store.MaGianHang,
                TrangThai = "ChoXacNhan",
                TongTien = tongThanhToan,
                PhiGiaoHang = route.Phi,
                TyLeTaiXe = (await FoodServiceApp.Web.Services.PhiGiaoService.DocAsync(_db)).TyLeTaiXe,
                DiaChiGiaoHang = request.DiaChiGiao.Trim(),
                GhiChu = ghiChu,
                MaXacNhanGiao = maXacNhan,
                MaKhuyenMaiApDung = maKm,
                TienGiam = giamGia,
                MaYeuCauDat = maYeuCau,
                HenGiaoLuc = henGiao,
            };
            _db.DonHangs.Add(don);
            foreach (var f in foods.Where(m => m.SoLuongTon != null))
            {
                f.SoLuongTon -= request.ChiTiet.Where(x => x.MonAnId == f.MaMonAn).Sum(x => x.SoLuong);
                if (f.SoLuongTon <= 0) f.TinhTrang = "HetHang";
            }
            try { await _db.SaveChangesAsync(); }
            catch (DbUpdateConcurrencyException)
            {
                _db.Entry(don).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                if (kmKq.Km != null) await KhuyenMaiXuLy.TraLuotAsync(_db, kmKq.Km);
                return Loi("Số lượng món vừa thay đổi (có người đặt trước). Vui lòng kiểm tra lại giỏ hàng.", 409);
            }
            catch (DbUpdateException) when (maYeuCau != null)
            {
                // Hai request cùng token chạy song song: request đến sau vi phạm chỉ mục duy nhất -> đơn đã được tạo bởi request trước
                _db.Entry(don).State = Microsoft.EntityFrameworkCore.EntityState.Detached;
                if (kmKq.Km != null) await KhuyenMaiXuLy.TraLuotAsync(_db, kmKq.Km);   // v51: không trừ lượt mã giảm giá hai lần
                return Loi("Yêu cầu đặt hàng này đang được xử lý. Vui lòng kiểm tra Lịch sử đơn hàng trước khi đặt lại.", 409);
            }

            foreach (var d in dong)
            {
                var gcDong = string.IsNullOrWhiteSpace(d.Item.GhiChu) ? null : d.Item.GhiChu.Trim();
                if (gcDong is { Length: > 300 }) gcDong = gcDong[..300];
                _db.ChiTietDonHangs.Add(new ChiTietDonHang
                {
                    MaDonHang = don.MaDonHang,
                    MaMonAn = d.Mon.MaMonAn,
                    SoLuong = d.Item.SoLuong,
                    DonGia = d.DonGia,
                    TuyChon = d.TuyChonText,
                    GhiChu = gcDong,
                });
            }

            _db.ThanhToans.Add(new ThanhToan
            {
                MaDonHang = don.MaDonHang,
                HinhThuc = request.HinhThucThanhToan,
                TrangThai = "ChoThanhToan"
            });
            if (kmKq.Km != null) KhuyenMaiXuLy.GhiNhan(_db, kmKq.Km, kh.MaKH, don.MaDonHang);
            don.KhoangCachKm = route.Km; don.ThoiGianDuKienPhut = route.Phut; don.NgoaiThanh = route.NgoaiThanh;
            await _db.SaveChangesAsync();

            // Đặt xong thì giỏ lưu trên server không còn ý nghĩa (tránh khôi phục lại giỏ cũ khi mở app)
            var gioCu = await _db.GioHangs.FirstOrDefaultAsync(x => x.MaKH == kh.MaKH);
            if (gioCu != null) { _db.GioHangs.Remove(gioCu); await _db.SaveChangesAsync(); }

            string? paymentUrl = null;
            if (string.Equals(request.HinhThucThanhToan, "VNPay", StringComparison.OrdinalIgnoreCase))
            {
                paymentUrl = await FoodServiceApp.Web.Services.Payment.VnPayXuLy.TaoLinkAsync(_db, _vnpay, new VnPayCreateRequest(
                    don.MaDonHang,
                    (long)tongThanhToan,
                    $"Thanh toan don hang #{don.MaDonHang} - FoodServiceApp",
                    HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                    Url.Action("VnPayReturn", "Payment", null, Request.Scheme)!));
            }

            return Ok(new
            {
                id = don.MaDonHang,
                maDonHang = don.MaDonHang,
                tongTienMon,
                giamGia,
                phiGiaoHang = route.Phi,
                khoangCachKm = route.Km,
                thoiGianDuKienPhut = route.Phut,
                daXacMinhTuyen = route.DaXacMinh,
                tongTien = tongThanhToan,
                maXacNhanGiao = maXacNhan,
                paymentUrl
            });
        }

        [HttpPut("khach-hang/ho-so")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> UpdateCustomerProfile(MobileCustomerProfileRequest request)
        {
            var kh = await CurrentCustomerAsync();
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            if (string.IsNullOrWhiteSpace(request.HoTen)) return Loi("Vui lòng nhập họ tên.");
            kh.HoTen = request.HoTen.Trim();
            if (request.Sdt != null) kh.SDT = NormalizePhone(request.Sdt);
            if (request.DiaChi != null) kh.DiaChiGiaoHang = request.DiaChi.Trim();
            await _db.SaveChangesAsync();
            return Ok(new { message = "Đã cập nhật hồ sơ." });
        }

        [HttpPost("van-de")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> CreateIssue(MobileIssueRequest request)
        {
            var kh = await CurrentCustomerAsync();
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            if (string.IsNullOrWhiteSpace(request.TieuDe) || string.IsNullOrWhiteSpace(request.MoTa)) return Loi("Tiêu đề và nội dung không được để trống.");

            int? orderId = request.DonHangId;
            int? storeId = null;
            if (orderId is int id)
            {
                var order = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaKH == kh.MaKH);
                if (order == null) return Loi("Đơn hàng không hợp lệ.", 404);
                storeId = order.MaGianHang;
            }

            var ph = new PhanHoi
            {
                MaKH = kh.MaKH,
                MaDonHang = orderId,
                MaGianHang = storeId,
                Loai = "KhieuNai",
                TieuDe = request.TieuDe.Trim(),
                NoiDung = request.MoTa.Trim(),
                TrangThai = "ChuaXuLy"
            };
            _db.PhanHois.Add(ph);
            await _db.SaveChangesAsync();
            return Ok(new { id = ph.MaPhanHoi });
        }

        [HttpPost("danh-gia")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> Review(MobileReviewRequest request)
        {
            var kh = await CurrentCustomerAsync();
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            if (request.SoSaoMonAn < 1 || request.SoSaoMonAn > 5) return Loi("Số sao món ăn phải từ 1 đến 5.");
            if (request.SoSaoGiaoHang < 0 || request.SoSaoGiaoHang > 5) return Loi("Số sao giao hàng phải từ 0 đến 5.");

            var order = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == request.DonHangId && d.MaKH == kh.MaKH);
            if (order == null) return Loi("Không tìm thấy đơn hàng.", 404);
            if (order.TrangThai != "DaGiao") return Loi("Chỉ được đánh giá sau khi đơn đã giao.");
            if (await _db.DanhGias.AnyAsync(x => x.MaKH == kh.MaKH && x.MaDonHang == order.MaDonHang)) return Loi("Đơn hàng này đã được đánh giá.");

            if (request.SoSaoQuan < 0 || request.SoSaoQuan > 5) return Loi("Số sao quán phải từ 0 đến 5.");
            // Ảnh đánh giá: chỉ nhận đường dẫn do chính máy chủ cấp qua api/upload/danhgia, tối đa 3 ảnh
            var anh = (request.Anh ?? new List<string>()).Select(a => a?.Trim() ?? "").Where(a => a.Length > 0).Distinct().ToList();
            if (anh.Count > 3) return Loi("Mỗi đánh giá tối đa 3 ảnh.");
            if (anh.Any(a => !a.StartsWith("/uploads/danhgia/", StringComparison.Ordinal) || a.Contains("..") || a.Length > 200)) return Loi("Ảnh đánh giá không hợp lệ.");
            var the = string.IsNullOrWhiteSpace(request.TheNhanXet) ? null : request.TheNhanXet.Trim();
            if (the is { Length: > 300 }) the = the[..300];
            _db.DanhGias.Add(new DanhGia
            {
                MaKH = kh.MaKH,
                MaGianHang = order.MaGianHang,
                MaDonHang = order.MaDonHang,
                SoSao = request.SoSaoQuan > 0 ? request.SoSaoQuan : request.SoSaoMonAn,   // điểm QUÁN (dùng cho điểm trung bình của quán); app cũ chỉ gửi một điểm
                SoSaoMon = request.SoSaoQuan > 0 ? request.SoSaoMonAn : null,            // điểm riêng cho MÓN ĂN
                SoSaoGiaoHang = request.SoSaoGiaoHang > 0 && order.MaTaiXe.HasValue ? request.SoSaoGiaoHang : null,   // lưu vào cột riêng (không nhét vào GhiChu đơn)
                NoiDung = request.NoiDung?.Trim(),
                TheNhanXet = the,
                AnhDanhGia = anh.Count == 0 ? null : string.Join("|", anh),
            });

            await _db.SaveChangesAsync();
            return Ok(new { message = "Cảm ơn bạn đã đánh giá." });
        }

        // ============================== Vendor ==============================

        [HttpGet("gian-hang/{id:int}/don-hang")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> VendorOrders(int id)
        {
            var owner = await _db.GianHangs.FirstOrDefaultAsync(g => g.MaGianHang == id && g.MaTK == CurrentMaTK);
            if (owner == null) return Loi("Bạn không có quyền xem gian hàng này.", 403);
            var orders = await _db.DonHangs
                .Include(d => d.GianHang)
                .Include(d => d.KhachHang)
                .Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .Include(d => d.GiaoHang).ThenInclude(g => g!.TaiXe)
                .Include(d => d.KhuyenMaiApDung)
                .Where(d => d.MaGianHang == id)
                .OrderByDescending(d => d.NgayDat)
                .ToListAsync();
            return Ok(orders.Select(MapMobileOrder));
        }

        [HttpPut("gian-hang/{id:int}/trang-thai-kinh-doanh")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> VendorBusinessStatus(int id, MobileVendorBusinessStatusRequest request)
        {
            var store = await _db.GianHangs.FirstOrDefaultAsync(g => g.MaGianHang == id && g.MaTK == CurrentMaTK);
            if (store == null) return Loi("Không tìm thấy gian hàng.", 404);
            if (store.TrangThaiDuyet != "DaDuyet") return Loi("Gian hàng chưa được duyệt.", 403);
            store.TrangThaiKinhDoanh = request.DangMoCua ? "DangMo" : "DongCua";
            await _db.SaveChangesAsync();
            return Ok(new { dangMoCua = request.DangMoCua, trangThaiKinhDoanh = store.TrangThaiKinhDoanh });
        }

        [HttpPut("don-hang/{id:int}/xac-nhan")]
        [HttpPost("~/api/restaurant/orders/{id:int}/confirm")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> VendorConfirm(int id, [FromBody] MobileConfirmOrderRequest? request = null)
        {
            return await UpdateVendorOrderStatus(id, "DaXacNhan", null, request?.ChuanBiPhut);
        }

        [HttpPut("don-hang/{id:int}/tu-choi")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> VendorReject(int id, [FromBody] MobileRejectOrderRequest? request)
        {
            var lyDo = request?.LyDo?.Trim();
            if (string.IsNullOrWhiteSpace(lyDo)) return Loi("Từ chối đơn phải kèm lý do.");   // NV04
            return await UpdateVendorOrderStatus(id, "DaHuy", lyDo);
        }

        /// <summary>Quán báo tiến độ chuẩn bị (dùng chung GiaoHangXuLy với Web và api/vendor): DangChuanBi | SanSangGiao.</summary>
        private async Task<IActionResult> DoiChuanBi(int id, string buoc)
        {
            var order = await GetOrderForVendorAsync(id);
            if (order == null) return Loi("Không tìm thấy đơn hàng hoặc bạn không có quyền.", 404);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.DoiChuanBiAsync(_db, order, buoc);
            return kq.Ok ? Ok(new { trangThaiChuanBi = order.TrangThaiChuanBi, thongDiep = kq.ThongDiep }) : Loi(kq.ThongDiep, 409);
        }

        [HttpPut("don-hang/{id:int}/bat-dau-chuan-bi")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public Task<IActionResult> VendorPreparing(int id) => DoiChuanBi(id, "DangChuanBi");

        [HttpPut("don-hang/{id:int}/san-sang-giao")]
        [HttpPost("~/api/restaurant/orders/{id:int}/ready")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public Task<IActionResult> VendorReadyToDeliver(int id) => DoiChuanBi(id, "SanSangGiao");

        /// <summary>Quán xác nhận đã trao món cho tài xế (chỉ khi đã có tài xế nhận).</summary>
        [HttpPut("don-hang/{id:int}/ban-giao")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> VendorHandover(int id)
        {
            var order = await GetOrderForVendorAsync(id);
            if (order == null) return Loi("Không tìm thấy đơn hàng hoặc bạn không có quyền.", 404);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.BanGiaoAsync(_db, order);
            return kq.Ok ? Ok(new { thongDiep = kq.ThongDiep }) : Loi(kq.ThongDiep, 409);
        }

        // ---- v48: gian hàng xử lý yêu cầu HỦY / HOÀN TIỀN của khách ----
        // Khách gửi "Yêu cầu hủy/hoàn tiền đơn #…" (POST van-de) khi quán đã nhận đơn. Gian hàng thấy yêu cầu của mình, đồng ý hủy
        // (chỉ khi đơn còn trước lúc tài xế lấy hàng — đúng ma trận TrangThaiDon) hoặc từ chối kèm lý do; Quản trị vẫn quyết định cuối cùng với hoàn tiền.
        private const string TieuDeYeuCauHuy = "Yêu cầu hủy/hoàn tiền đơn";

        [HttpGet("gian-hang/{id:int}/yeu-cau-huy")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> VendorCancelRequests(int id)
        {
            if (!await _db.GianHangs.AnyAsync(g => g.MaGianHang == id && g.MaTK == CurrentMaTK)) return Loi("Bạn không có quyền xem gian hàng này.", 403);
            var tieuDe = TieuDeYeuCauHuy;
            var ds = await _db.PhanHois.AsNoTracking()
                .Where(p => p.MaGianHang == id && p.MaDonHang != null && p.TieuDe.StartsWith(tieuDe))
                .OrderBy(p => p.TrangThai == "ChuaXuLy" ? 0 : 1).ThenByDescending(p => p.NgayGui).Take(60).ToListAsync();
            var ids = ds.Select(p => p.MaDonHang!.Value).ToList();
            var don = await _db.DonHangs.AsNoTracking().Where(d => ids.Contains(d.MaDonHang))
                .Select(d => new
                {
                    d.MaDonHang, d.TrangThai, d.TongTien,
                    khach = d.KhachHang != null ? d.KhachHang.HoTen : "",
                    hinhThuc = d.ThanhToan != null ? d.ThanhToan.HinhThuc : "",
                    trangThaiTT = d.ThanhToan != null ? d.ThanhToan.TrangThai : "",
                }).ToDictionaryAsync(x => x.MaDonHang);
            return Ok(ds.Select(p =>
            {
                don.TryGetValue(p.MaDonHang!.Value, out var d);
                var trangThaiDon = d?.TrangThai ?? "";
                var daTuChoi = p.PhanLoai == "GianHangTuChoi";
                return new
                {
                    p.MaPhanHoi, maDonHang = p.MaDonHang, p.TieuDe, p.NoiDung, p.NgayGui, p.NgayXuLy, p.TraLoi,
                    trangThai = p.TrangThai == "DaXuLy" ? "DaXuLy" : daTuChoi ? "DaTuChoi" : "ChoXuLy",
                    trangThaiDon, tongTien = d?.TongTien ?? 0, khach = d?.khach ?? "",
                    hinhThucTT = d?.hinhThuc ?? "", trangThaiTT = d?.trangThaiTT ?? "",
                    coTheDongY = p.TrangThai == "ChuaXuLy" && !daTuChoi && FoodServiceApp.Web.Services.TrangThaiDon.ChoPhep(trangThaiDon, "DaHuy", FoodServiceApp.Web.Services.TrangThaiDon.GianHang),
                };
            }));
        }

        [HttpPut("gian-hang/{id:int}/yeu-cau-huy/{maPhanHoi:int}/dong-y")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> VendorApproveCancel(int id, int maPhanHoi)
        {
            if (!await _db.GianHangs.AnyAsync(g => g.MaGianHang == id && g.MaTK == CurrentMaTK)) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var tieuDe = TieuDeYeuCauHuy;
            var ph = await _db.PhanHois.FirstOrDefaultAsync(p => p.MaPhanHoi == maPhanHoi && p.MaGianHang == id && p.MaDonHang != null && p.TieuDe.StartsWith(tieuDe));
            if (ph == null) return Loi("Không tìm thấy yêu cầu.", 404);
            if (ph.TrangThai != "ChuaXuLy") return Loi("Yêu cầu này đã được xử lý.", 409);
            var order = await _db.DonHangs.Include(d => d.ThanhToan).Include(d => d.KhachHang).FirstOrDefaultAsync(d => d.MaDonHang == ph.MaDonHang && d.MaGianHang == id);
            if (order == null) return Loi("Không tìm thấy đơn hàng.", 404);
            if (!FoodServiceApp.Web.Services.TrangThaiDon.ChoPhep(order.TrangThai, "DaHuy", FoodServiceApp.Web.Services.TrangThaiDon.GianHang))
                return Loi("Đơn đã giao cho tài xế hoặc đã kết thúc nên gian hàng không tự hủy được; yêu cầu sẽ do Quản trị xử lý.", 409);

            order.TrangThai = "DaHuy";
            order.LyDoTuChoi = "Khách yêu cầu hủy — gian hàng đồng ý";
            var tbHoan = await FoodServiceApp.Web.Services.HoanTienXuLy.TaoYeuCauKhiHuyAsync(_db, order, "GianHang", $"Khách yêu cầu hủy đơn #{order.MaDonHang}, gian hàng đồng ý");
            ph.TrangThai = "DaXuLy"; ph.NgayXuLy = DateTime.Now;
            ph.TraLoi = "Gian hàng đồng ý hủy đơn." + (tbHoan != null ? " " + tbHoan : "");
            if (order.KhachHang != null)
                _db.ThongBaos.Add(new ThongBao { MaTK = order.KhachHang.MaTK, Loai = "DonHang", MaThamChieu = order.MaDonHang.ToString(), TieuDe = "Đơn đã được hủy theo yêu cầu", NoiDung = $"Gian hàng đã đồng ý hủy đơn #{order.MaDonHang}." + (tbHoan != null ? " Yêu cầu hoàn tiền đang chờ quản trị duyệt." : "") });
            await _db.SaveChangesAsync();
            await FoodServiceApp.Web.Services.TrangThaiDon.SauKhiHuyAsync(_db, order, "Khách yêu cầu hủy, gian hàng đồng ý");
            return Ok(new { thongDiep = $"Đã hủy đơn #{order.MaDonHang}." + (tbHoan != null ? " " + tbHoan : "") });
        }

        [HttpPut("gian-hang/{id:int}/yeu-cau-huy/{maPhanHoi:int}/tu-choi")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> VendorRejectCancel(int id, int maPhanHoi, [FromBody] MobileRejectOrderRequest? request)
        {
            if (!await _db.GianHangs.AnyAsync(g => g.MaGianHang == id && g.MaTK == CurrentMaTK)) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var lyDo = request?.LyDo?.Trim();
            if (string.IsNullOrWhiteSpace(lyDo)) return Loi("Từ chối yêu cầu hủy phải kèm lý do.");
            var tieuDe = TieuDeYeuCauHuy;
            var ph = await _db.PhanHois.Include(p => p.KhachHang).FirstOrDefaultAsync(p => p.MaPhanHoi == maPhanHoi && p.MaGianHang == id && p.MaDonHang != null && p.TieuDe.StartsWith(tieuDe));
            if (ph == null) return Loi("Không tìm thấy yêu cầu.", 404);
            if (ph.TrangThai != "ChuaXuLy") return Loi("Yêu cầu này đã được xử lý.", 409);
            ph.PhanLoai = "GianHangTuChoi";                      // vẫn mở cho Quản trị quyết định cuối cùng
            ph.TraLoi = "Gian hàng chưa đồng ý hủy: " + lyDo;
            if (ph.KhachHang != null)
                _db.ThongBaos.Add(new ThongBao { MaTK = ph.KhachHang.MaTK, Loai = "DonHang", MaThamChieu = ph.MaDonHang.ToString(), TieuDe = "Gian hàng chưa đồng ý hủy đơn", NoiDung = $"Đơn #{ph.MaDonHang}: {lyDo}. Quản trị viên sẽ xem xét yêu cầu của bạn." });
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã gửi phản hồi; Quản trị viên sẽ quyết định cuối cùng." });
        }

        /// <summary>Các yêu cầu hoàn tiền thuộc đơn của gian hàng (do quản trị duyệt) — gian hàng chỉ xem để đối chiếu doanh thu.</summary>
        [HttpGet("gian-hang/{id:int}/hoan-tien")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> VendorRefunds(int id)
        {
            if (!await _db.GianHangs.AnyAsync(g => g.MaGianHang == id && g.MaTK == CurrentMaTK)) return Loi("Bạn không có quyền xem gian hàng này.", 403);
            var ds = await _db.YeuCauHoanTiens.AsNoTracking()
                .Where(y => _db.DonHangs.Any(d => d.MaDonHang == y.MaDonHang && d.MaGianHang == id))
                .OrderByDescending(y => y.NgayTao).Take(60)
                .Select(y => new { y.MaYeuCau, y.MaDonHang, y.SoTien, y.LyDo, y.Nguon, y.TrangThai, y.KetQua, y.NgayTao, y.NgayXuLy }).ToListAsync();
            return Ok(ds);
        }

        // ---- Khách xác nhận nhận hàng / báo chưa nhận được (cùng quy tắc với Web: CustomerOrderController) ----

        [HttpPut("don-hang/{id:int}/xac-nhan-nhan")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> CustomerConfirmReceived(int id)
        {
            var kh = await CurrentCustomerAsync();
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            var don = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaKH == kh.MaKH);
            if (don == null) return Loi("Không tìm thấy đơn hàng.", 404);
            if (don.TrangThai != "DaGiao") return Loi("Chỉ xác nhận được khi đơn đã giao.", 409);
            if (don.KhachXacNhanLuc == null)
            {
                don.KhachXacNhanLuc = DateTime.Now;
                await _db.SaveChangesAsync();
            }
            return Ok(new { khachXacNhanLuc = don.KhachXacNhanLuc });
        }

        [HttpPost("don-hang/{id:int}/chua-nhan")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> CustomerNotReceived(int id)
        {
            var kh = await CurrentCustomerAsync();
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            var don = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaKH == kh.MaKH);
            if (don == null) return Loi("Không tìm thấy đơn hàng.", 404);
            if (don.TrangThai != "DaGiao" || don.KhachXacNhanLuc != null) return Loi("Không thể gửi báo cáo cho đơn này.", 409);
            if (!await _db.PhanHois.AnyAsync(p => p.MaDonHang == id && p.MaKH == kh.MaKH && p.PhanLoai == "ChuaNhanHang"))
            {
                _db.PhanHois.Add(new PhanHoi { MaKH = kh.MaKH, MaDonHang = id, MaGianHang = don.MaGianHang, Loai = "KhieuNai", PhanLoai = "ChuaNhanHang",
                    TieuDe = $"Chưa nhận được hàng đơn #{id}",
                    NoiDung = "Hệ thống ghi nhận đơn đã giao nhưng khách báo chưa nhận được hàng. Vui lòng kiểm tra bằng chứng giao hàng và liên hệ khách." });
                await _db.SaveChangesAsync();
            }
            return Ok(new { daGuiKhieuNai = true });
        }


        // ============================== Admin ==============================

        /// <summary>Toàn bộ đơn hệ thống (2000 đơn mới nhất) cho màn hình thống kê của quản trị trên app.</summary>
        [HttpGet("admin/don-hang")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminOrders()
        {
            var orders = await _db.DonHangs.AsNoTracking()
                .Include(d => d.GianHang).Include(d => d.KhachHang)
                .Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .Include(d => d.GiaoHang).ThenInclude(g => g!.TaiXe)
                .Include(d => d.ThanhToan).Include(d => d.KhuyenMaiApDung)
                .OrderByDescending(d => d.NgayDat).Take(2000).ToListAsync();
            return Ok(orders.Select(MapMobileOrder));
        }

        [HttpGet("admin/khach-hang")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminCustomers()
        {
            var data = await _db.KhachHangs
                .Include(k => k.TaiKhoan)
                .Select(k => new
                {
                    id = k.MaKH,
                    hoTen = k.HoTen,
                    email = k.Email ?? "",
                    matKhau = "",
                    soDienThoai = k.SDT,
                    diaChi = k.DiaChiGiaoHang ?? "",
                    ngayDangKy = k.TaiKhoan != null ? k.TaiKhoan.NgayTao : DateTime.Now,
                    tongSoDon = _db.DonHangs.Count(d => d.MaKH == k.MaKH),
                    taiKhoanBiKhoa = k.TaiKhoan != null && !k.TaiKhoan.TrangThai
                })
                .OrderByDescending(k => k.id)
                .ToListAsync();
            return Ok(data);
        }

        [HttpGet("admin/van-de")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminIssues()
        {
            var issues = await _db.PhanHois.Include(p => p.KhachHang).OrderByDescending(p => p.NgayGui).ToListAsync();
            return Ok(issues.Select(MapIssue));
        }

        [FoodServiceApp.Web.Filters.ChiSuperAdminGhi]

        [HttpPut("admin/gian-hang/{id:int}/duyet")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminApproveVendor(int id) => await SetVendorApproval(id, "DaDuyet");

        [FoodServiceApp.Web.Filters.ChiSuperAdminGhi]

        [HttpPut("admin/gian-hang/{id:int}/tu-choi")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminRejectVendor(int id) => await SetVendorApproval(id, "TuChoi");

        [FoodServiceApp.Web.Filters.ChiSuperAdminGhi]

        [HttpPut("admin/gian-hang/{id:int}/khoa")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminLockVendor(int id) => await ToggleVendorLock(id, false);

        [FoodServiceApp.Web.Filters.ChiSuperAdminGhi]

        [HttpPut("admin/gian-hang/{id:int}/mo-khoa")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminUnlockVendor(int id) => await ToggleVendorLock(id, true);

        [FoodServiceApp.Web.Filters.ChiSuperAdminGhi]

        [HttpPut("admin/khach-hang/{id:int}/khoa")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminLockCustomer(int id) => await ToggleCustomerLock(id, false);

        [FoodServiceApp.Web.Filters.ChiSuperAdminGhi]

        [HttpPut("admin/khach-hang/{id:int}/mo-khoa")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminUnlockCustomer(int id) => await ToggleCustomerLock(id, true);

        

        [HttpPut("admin/van-de/{id:int}/dang-xu-ly")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminIssueInProgress(int id)
        {
            var exists = await _db.PhanHois.AnyAsync(p => p.MaPhanHoi == id);
            if (!exists) return Loi("Không tìm thấy vấn đề.", 404);
            var phDangXuLy = await _db.PhanHois.FirstAsync(p => p.MaPhanHoi == id);
            if (phDangXuLy.TrangThai != "DaXuLy") { phDangXuLy.TrangThai = "DangXuLy"; await _db.SaveChangesAsync(); }
            return Ok(new { trangThai = "DangXuLy" });
        }

        

        [HttpPut("admin/van-de/{id:int}/giai-quyet")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminResolveIssue(int id)
        {
            var ph = await _db.PhanHois.FirstOrDefaultAsync(p => p.MaPhanHoi == id);
            if (ph == null) return Loi("Không tìm thấy vấn đề.", 404);
            ph.TrangThai = "DaXuLy";
            ph.NgayXuLy = DateTime.Now;
            await _db.SaveChangesAsync();
            return Ok(new { trangThai = "DaGiaiQuyet" });
        }

        [HttpGet("admin/tai-xe")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminDrivers()
        {
            var data = await (from t in _db.TaiXes
                              join k in _db.TaiKhoans on t.MaTK equals k.MaTK
                              orderby t.MaTaiXe descending
                              select new
                              {
                                  id = t.MaTaiXe.ToString(),
                                  hoTen = t.HoTen,
                                  loaiXe = t.PhuongTien ?? "Xe máy",
                                  soDienThoai = t.SDT,
                                  bienSoXe = t.BienSo ?? "",
                                  soCccd = t.SoCCCD ?? "",
                                  soGplx = t.SoGPLX ?? "",
                                  trangThaiDangKy = t.TrangThaiDuyet,
                                  lyDoTuChoi = t.LyDoTuChoi ?? "",
                                  ngayDangKy = t.NgayDangKy,
                                  taiKhoanBiKhoa = !k.TrangThai,
                                  dangHoatDong = t.TrangThai != "NgoaiTuyen"
                              }).ToListAsync();
            return Ok(data);
        }

        [FoodServiceApp.Web.Filters.ChiSuperAdminGhi]

        [HttpPut("admin/tai-xe/{id:int}/duyet")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminApproveDriver(int id)
        {
            var tx = await _db.TaiXes.FirstOrDefaultAsync(t => t.MaTaiXe == id);
            if (tx == null) return Loi("Không tìm thấy tài xế.", 404);
            tx.TrangThaiDuyet = "DaDuyet";
            tx.LyDoTuChoi = null;
            tx.YeuCauBoSung = null;
            if (tx.TrangThai == "NgoaiTuyen") tx.TrangThai = "SanSang";
            _db.ThongBaos.Add(new ThongBao { MaTK = tx.MaTK, Loai = "HeThong", TieuDe = "Hồ sơ tài xế đã được duyệt", NoiDung = "Tài khoản của bạn đã được kích hoạt, bạn có thể bắt đầu nhận đơn." });
            await _db.SaveChangesAsync();
            return Ok(new { trangThaiDangKy = tx.TrangThaiDuyet });
        }

        [FoodServiceApp.Web.Filters.ChiSuperAdminGhi]

        [HttpPut("admin/tai-xe/{id:int}/tu-choi")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminRejectDriver(int id, [FromBody] MobileLyDoRequest? body)
        {
            var tx = await _db.TaiXes.FirstOrDefaultAsync(t => t.MaTaiXe == id);
            if (tx == null) return Loi("Không tìm thấy tài xế.", 404);
            tx.TrangThaiDuyet = "TuChoi";
            tx.LyDoTuChoi = string.IsNullOrWhiteSpace(body?.LyDo) ? "Hồ sơ không đạt yêu cầu" : body!.LyDo!.Trim();
            tx.TrangThai = "NgoaiTuyen";
            _db.ThongBaos.Add(new ThongBao { MaTK = tx.MaTK, Loai = "HeThong", TieuDe = "Hồ sơ tài xế bị từ chối", NoiDung = "Lý do: " + tx.LyDoTuChoi });
            await _db.SaveChangesAsync();
            return Ok(new { trangThaiDangKy = tx.TrangThaiDuyet });
        }

        [FoodServiceApp.Web.Filters.ChiSuperAdminGhi]

        [HttpPut("admin/tai-xe/{id:int}/khoa")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminLockDriver(int id) => await ToggleDriverLock(id, false);

        [FoodServiceApp.Web.Filters.ChiSuperAdminGhi]

        [HttpPut("admin/tai-xe/{id:int}/mo-khoa")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
        public async Task<IActionResult> AdminUnlockDriver(int id) => await ToggleDriverLock(id, true);

        private async Task<IActionResult> ToggleDriverLock(int id, bool active)
        {
            var tx = await _db.TaiXes.FirstOrDefaultAsync(t => t.MaTaiXe == id);
            if (tx == null) return Loi("Không tìm thấy tài xế.", 404);
            var tk = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == tx.MaTK);
            if (tk == null) return Loi("Không tìm thấy tài khoản tài xế.", 404);
            tk.TrangThai = active;
            if (!active) tx.TrangThai = "NgoaiTuyen";
            await _db.SaveChangesAsync();
            return Ok(new { taiKhoanBiKhoa = !tk.TrangThai });
        }

        // ============================== Driver ==============================

        [HttpPut("tai-xe/ho-so")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> UpdateDriverProfile(MobileDriverProfileRequest request)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            if (!string.IsNullOrWhiteSpace(request.HoTen)) tx.HoTen = request.HoTen.Trim();
            if (!string.IsNullOrWhiteSpace(request.SoDienThoai)) tx.SDT = NormalizePhone(request.SoDienThoai);
            if (!string.IsNullOrWhiteSpace(request.BienSoXe)) tx.BienSo = request.BienSoXe.Trim();
            if (!string.IsNullOrWhiteSpace(request.LoaiXe)) tx.PhuongTien = request.LoaiXe.Trim();
            if (request.KhuVucHoatDong != null) tx.KhuVucHoatDong = FoodServiceApp.Web.Services.KhuVucHelper.ChuanHoa(request.KhuVucHoatDong);   // "" = nhận ở mọi khu vực
            if (!string.IsNullOrWhiteSpace(request.AnhDaiDien)) tx.AnhDaiDien = request.AnhDaiDien.Trim();
            var doiGiayTo = false;
            if (!string.IsNullOrWhiteSpace(request.SoCccd) && request.SoCccd.Trim() != (tx.SoCCCD ?? "")) { tx.SoCCCD = request.SoCccd.Trim(); doiGiayTo = true; }
            if (!string.IsNullOrWhiteSpace(request.SoGplx) && request.SoGplx.Trim() != (tx.SoGPLX ?? "")) { tx.SoGPLX = request.SoGplx.Trim(); doiGiayTo = true; }
            if (!string.IsNullOrWhiteSpace(request.AnhGplx) && request.AnhGplx.Trim() != (tx.AnhGPLX ?? ""))
            {
                // Chỉ nhận đường dẫn do máy chủ cấp từ api/upload/giayto-taixe (tài liệu riêng tư) — không nhận URL tùy ý.
                if (!request.AnhGplx.Trim().StartsWith("/files/private/taixe-giayto/", StringComparison.OrdinalIgnoreCase))
                    return BadRequest(new { message = "Ảnh GPLX phải được tải lên qua chức năng tải giấy tờ." });
            }
            if (!string.IsNullOrWhiteSpace(request.AnhGplx) && request.AnhGplx.Trim() != (tx.AnhGPLX ?? "")) { tx.AnhGPLX = request.AnhGplx.Trim(); doiGiayTo = true; }
            if (doiGiayTo) await DriverDonXuLy.BaoQuanTriDoiGiayToAsync(_db, tx);
            await _db.SaveChangesAsync();
            return Ok(new { message = "Đã cập nhật hồ sơ tài xế." });
        }

        /// <summary>Hồ sơ tài xế + trạng thái duyệt, lý do từ chối, yêu cầu bổ sung.</summary>
        [HttpGet("tai-xe/ho-so")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverProfile()
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            return Ok(new
            {
                hoTen = tx.HoTen, soDienThoai = tx.SDT, loaiXe = tx.PhuongTien, bienSoXe = tx.BienSo, khuVucHoatDong = tx.KhuVucHoatDong,
                anhDaiDien = tx.AnhDaiDien, soCccd = tx.SoCCCD, soGplx = tx.SoGPLX, anhGplx = tx.AnhGPLX,
                trangThaiDuyet = tx.TrangThaiDuyet, lyDoTuChoi = tx.LyDoTuChoi, yeuCauBoSung = tx.YeuCauBoSung
            });
        }

        /// <summary>Thu nhập tài xế theo kỳ (ky = ngay | tuan | thang): từng chuyến, thưởng/phụ cấp, điều chỉnh/khấu trừ, tiền mặt, lịch thanh toán.</summary>
        [HttpGet("tai-xe/thu-nhap")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverThuNhap([FromQuery] string? ky)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            return Ok(await DriverThuNhapApi.TaoAsync(_db, new CauHinhService(_db), tx.MaTaiXe, ky, DateTime.Now));
        }

        /// <summary>Đối soát COD: khoản tài xế đã thu nhưng chưa nộp lại cho nền tảng + COD đã nộp 30 ngày.</summary>
        [HttpGet("tai-xe/cod")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverCod()
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var chuaNop = await DriverDonXuLy.CodChuaNopAsync(_db, tx.MaTaiXe);
            var tu = DateTime.Now.AddDays(-30);
            var daNop = await _db.GiaoHangs.AsNoTracking()
                .Where(g => g.MaTaiXe == tx.MaTaiXe && g.TienThuCOD > 0 && g.CodDaNopLuc != null && g.CodDaNopLuc >= tu)
                .SumAsync(g => (decimal?)g.TienThuCOD) ?? 0;
            return Ok(new
            {
                canNop = chuaNop.Sum(c => c.SoTien), daNop30Ngay = daNop,
                don = chuaNop.Select(c => new { maDonHang = c.MaDonHang, thoiGianGiao = c.ThoiGianGiao, soTien = c.SoTien })
            });
        }

        public record MobileSuCoRequest(string? Loai, string? MoTa, int? MaDonHang = null, string? AnhMinhChung = null);

        /// <summary>Danh sách loại sự cố + các báo cáo của tài xế (kèm trạng thái xử lý, phản hồi quản trị).</summary>
        [HttpGet("tai-xe/su-co")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverIncidents()
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var items = await _db.SuCoGiaoHangs.AsNoTracking().Where(x => x.MaTaiXe == tx.MaTaiXe)
                .OrderByDescending(x => x.NgayTao).Take(50)
                .Select(x => new { id = x.MaSuCo, loai = x.Loai, moTa = x.MoTa, maDonHang = x.MaDonHang, trangThai = x.TrangThai, phanHoiQuanTri = x.PhanHoiQuanTri, ngayTao = x.NgayTao, ngayXuLy = x.NgayXuLy })
                .ToListAsync();
            var loais = DriverSuCoController.Loais.Select(kv => new { ma = kv.Key, ten = kv.Value }).ToList();
            return Ok(new { loais, items });
        }

        /// <summary>Tài xế gửi báo cáo sự cố / sai lệch thu nhập, COD (mọi loại trong DriverSuCoController.Loais).</summary>
        [HttpPost("tai-xe/su-co")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverCreateIncident(MobileSuCoRequest request)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var kq = await DriverDonXuLy.TaoSuCoAsync(_db, tx, request?.Loai, request?.MoTa, request?.MaDonHang, request?.AnhMinhChung);
            if (!kq.Ok) return Loi(kq.ThongDiep, 400);
            return Ok(new { message = kq.ThongDiep });
        }

        [HttpGet("tai-xe/don-cho-nhan")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverAvailableOrders()
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            if (tx.TrangThaiDuyet != "DaDuyet") return Loi("Hồ sơ tài xế chưa được duyệt, chưa thể xem và nhận đơn.", 403);
            var phutPhanHoi = await FoodServiceApp.Web.Services.GiaoHangXuLy.LayPhutPhanHoiAsync(_db);
            await FoodServiceApp.Web.Services.GiaoHangXuLy.XuLyQuaHanNhanDonAsync(_db, phutPhanHoi);
            var orders = await FoodServiceApp.Web.Services.GiaoHangXuLy.DonChoNhan(_db, tx.MaTaiXe)
                .Include(d => d.GianHang)
                .Include(d => d.KhachHang)
                .Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .Include(d => d.GiaoHang).ThenInclude(g => g!.TaiXe)
                .Include(d => d.KhuyenMaiApDung)
                .OrderBy(d => d.NgayDat)
                .ToListAsync();
            var jsonOpt = new System.Text.Json.JsonSerializerOptions(System.Text.Json.JsonSerializerDefaults.Web);
            return Ok(orders.Select(o =>
            {
                var node = System.Text.Json.JsonSerializer.SerializeToNode(MapMobileOrder(o), jsonOpt)!.AsObject();
                node["phutPhanHoi"] = phutPhanHoi;
                node["hanPhanHoiLuc"] = System.Text.Json.Nodes.JsonValue.Create(o.ThoiGianSanSang?.AddMinutes(phutPhanHoi));
                return node;
            }));
        }

        [HttpGet("tai-xe/don-hang")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverMyOrders([FromQuery] string? tab)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            return Ok(await DriverDonXuLy.DanhSachAsync(_db, tx.MaTaiXe, tab));
        }

        [HttpGet("tai-xe/don-hang/{id:int}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverOrderDetail(int id)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var dto = await DriverDonXuLy.ChiTietAsync(_db, tx.MaTaiXe, id);
            return dto == null ? Loi("Không tìm thấy đơn trong chuyến của bạn.", 404) : Ok(dto);
        }

        [HttpPut("tai-xe/don-hang/{id:int}/tu-choi")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverReject(int id, [FromBody] MobileLyDoRequest? body)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.TuChoiDonAsync(_db, tx, id, body?.LyDo);
            if (!kq.Ok) return Loi(kq.ThongDiep, 400);
            return Ok(new { id, message = kq.ThongDiep });
        }

        [HttpPut("tai-xe/don-hang/{id:int}/nhan")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverAccept(int id)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.NhanDonAsync(_db, tx, id);
            if (!kq.Ok) return Loi(kq.ThongDiep, kq.ThongDiep.Contains("tài xế khác") ? 409 : 400);
            return Ok(new { id, taiXeId = tx.MaTaiXe });
        }

        /// <summary>Lịch sử chuyến đã xong (thành công/thất bại) của tài xế: nguồn cho màn thu nhập, đánh giá.</summary>
        [HttpGet("tai-xe/don-da-giao")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverFinished()
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var orders = await _db.DonHangs.AsNoTracking()
                .Include(d => d.KhachHang).Include(d => d.GianHang)
                .Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .Include(d => d.GiaoHang).ThenInclude(g => g!.TaiXe)
                .Include(d => d.ThanhToan).Include(d => d.KhuyenMaiApDung)
                .Where(d => d.GiaoHang != null && d.GiaoHang.MaTaiXe == tx.MaTaiXe && (d.GiaoHang.TrangThai == "GiaoThanhCong" || d.GiaoHang.TrangThai == "GiaoThatBai"))
                .OrderByDescending(d => d.GiaoHang!.ThoiGianGiao).Take(500).ToListAsync();
            var ids = orders.Select(o => o.MaDonHang).ToList();
            var sao = await _db.DanhGias.AsNoTracking().Where(x => ids.Contains(x.MaDonHang) && !x.DaAn && x.SoSaoGiaoHang != null)
                .ToDictionaryAsync(x => x.MaDonHang, x => x.SoSaoGiaoHang!.Value);
            // Thêm diemTaiXe (số sao khách chấm cho phần giao hàng) vào dữ liệu đơn
            var ketQua = orders.Select(o =>
            {
                var node = System.Text.Json.JsonSerializer.SerializeToNode(MapMobileOrder(o), new System.Text.Json.JsonSerializerOptions(System.Text.Json.JsonSerializerDefaults.Web))!.AsObject();
                node["diemTaiXe"] = sao.TryGetValue(o.MaDonHang, out var s) ? s : 0;
                return node;
            }).ToList();
            return Ok(ketQua);
        }

        [HttpGet("tai-xe/dang-giao")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverCurrent()
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var order = await _db.DonHangs
                .Include(d => d.KhachHang)
                .Include(d => d.GianHang)
                .Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .Include(d => d.GiaoHang).ThenInclude(g => g!.TaiXe)
                .Include(d => d.ThanhToan)
                .Include(d => d.KhuyenMaiApDung)
                .FirstOrDefaultAsync(d => d.MaTaiXe == tx.MaTaiXe && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao"));
            return Ok(order == null ? null : MapMobileOrder(order));
        }

        [HttpPut("tai-xe/vi-tri")]
        [HttpPost("~/api/driver/location")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverPosition(MobileDriverPositionRequest request)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var donHangId = request.DonHangId;
            var order = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == donHangId && d.MaTaiXe == tx.MaTaiXe);
            if (order == null) return Loi("Đơn hàng không thuộc tài xế hiện tại.", 404);
            if (request.ViDo is < -90 or > 90 || request.KinhDo is < -180 or > 180) return Loi("Tọa độ không hợp lệ.");
            if (order.TrangThai is not ("DaXacNhan" or "DangGiao")) return Loi("Đơn không còn ở trạng thái giao, không nhận vị trí.", 409);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.LuuViTriAsync(_db, donHangId, tx.MaTaiXe, request.ViDo, request.KinhDo);
            if (!kq.Ok) return Loi(kq.ThongDiep, 422);
            DriverPositions[donHangId] = new ViTriNho(request.ViDo, request.KinhDo, DateTime.Now);
            return Ok(new { viDo = request.ViDo, kinhDo = request.KinhDo, viTriCapNhatLuc = DateTime.Now });
        }

        [HttpPut("don-hang/{id:int}/tai-xe-den-quan")]
        [HttpPut("don-hang/{id:int}/den-quan")]   // tên route cũ của app (v15) — giữ để tương thích
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverArrived(int id)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var order = await _db.DonHangs.Include(d => d.GiaoHang).FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe == tx.MaTaiXe);
            if (order == null) return Loi("Không tìm thấy đơn giao.", 404);
            if (order.GiaoHang == null) return Loi("Đơn chưa được nhận hợp lệ.", 409);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.DenQuanAsync(_db, order, order.GiaoHang);
            if (!kq.Ok) return Loi(kq.ThongDiep, 409);
            return Ok(new { trangThai = order.TrangThai, denQuanLuc = order.GiaoHang.ThoiGianDenQuan });
        }

        public record MobilePickupIssueRequest(string? Loai, string? MoTa);

        /// <summary>Báo sự cố khi lấy món: QuanChuanBiCham | KhongTimThayDon | SaiMon | ThieuMon | VanDeBanGiao.</summary>
        [HttpPost("tai-xe/don-hang/{id:int}/su-co")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverPickupIssue(int id, MobilePickupIssueRequest request)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var kq = await DriverDonXuLy.BaoSuCoLayMonAsync(_db, tx, id, request?.Loai, request?.MoTa);
            if (!kq.Ok) return Loi(kq.ThongDiep, 400);
            return Ok(new { message = kq.ThongDiep });
        }

        [HttpPut("don-hang/{id:int}/da-lay-hang")]
        [HttpPost("~/api/driver/orders/{id:int}/pickup")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverPickedUp(int id, [FromQuery] string? maDon)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var order = await _db.DonHangs.Include(d => d.GiaoHang).FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe == tx.MaTaiXe);
            if (order == null) return Loi("Không tìm thấy đơn giao.", 404);
            if (order.GiaoHang == null) return Loi("Đơn chưa được nhận hợp lệ.", 409);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.DaLayHangAsync(_db, order, order.GiaoHang, maDon);
            if (!kq.Ok) return Loi(kq.ThongDiep, 409);
            return Ok(new { trangThai = order.TrangThai, daLayHang = true, coMaXacNhan = !string.IsNullOrEmpty(order.MaXacNhanGiao) });
        }

        [HttpPut("don-hang/{id:int}/hoan-thanh")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverComplete(int id, MobileCompleteOrderRequest request)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var order = await _db.DonHangs.Include(d => d.GiaoHang).Include(d => d.ThanhToan)
                .FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe == tx.MaTaiXe);
            if (order == null || order.GiaoHang == null) return Loi("Không tìm thấy đơn giao.", 404);

            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.HoanThanhAsync(_db, order, order.GiaoHang, tx, request.MaXacNhan, request.ViDo, request.KinhDo);
            if (!kq.Ok) return Loi(kq.ThongDiep, 400);
            return Ok(new { trangThai = order.TrangThai, giaoLuc = order.GiaoHang.ThoiGianGiao });
        }

        [HttpPut("don-hang/{id:int}/giao-that-bai")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> DriverFailed(int id, MobileFailedDeliveryRequest request)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var order = await _db.DonHangs.Include(d => d.GiaoHang).Include(d => d.ThanhToan)
                .FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe == tx.MaTaiXe);
            if (order == null || order.GiaoHang == null) return Loi("Không tìm thấy đơn giao.", 404);

            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.ThatBaiAsync(_db, order, order.GiaoHang, tx, request.LyDo, request.ViDo, request.KinhDo);
            if (!kq.Ok) return Loi(kq.ThongDiep, 400);
            return Ok(new { trangThai = order.TrangThai, tinhPhi = order.GiaoHang.TinhPhiThatBai, thongDiep = kq.ThongDiep });
        }

        [HttpPut("don-hang/{id:int}/phi-giao-hang")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "TaiXe")]
        public async Task<IActionResult> AdjustDeliveryFee(int id, MobileAdjustedFeeRequest request)
        {
            var tx = await CurrentDriverAsync();
            if (tx == null) return Loi("Tài khoản tài xế không hợp lệ.", 401);
            var order = await _db.DonHangs
                .Include(d => d.ThanhToan)
                .Include(d => d.ChiTiets)
                .FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe == tx.MaTaiXe);
            if (order == null) return Loi("Không tìm thấy đơn giao.", 404);
            if (order.TrangThai is not ("DaXacNhan" or "DangGiao")) return Loi("Chỉ điều chỉnh phí khi đơn đang trong chuyến giao.", 409);
            if (request.KhoangCachKm <= 0 || request.PhiGiaoHang < 0 || request.PhiGiaoHang > PhiToiDa) return Loi("Khoảng cách hoặc phí giao hàng không hợp lệ.");
            if (order.ThanhToan != null && order.ThanhToan.HinhThuc != "TienMat" && request.PhiGiaoHang > order.PhiGiaoHang)
                return Loi("Đơn đã thanh toán trước (VNPay/chuyển khoản), không thể tăng phí giao hàng.");
            var oldFee = order.PhiGiaoHang;
            order.PhiGiaoHang = request.PhiGiaoHang;
            var foodTotal = order.ChiTiets.Count > 0 ? order.ChiTiets.Sum(c => c.DonGia * c.SoLuong) : 0m;
            var discount = Math.Max(0m, foodTotal + oldFee - order.TongTien);
            order.TongTien = Math.Max(0m, foodTotal - discount) + request.PhiGiaoHang;
            order.KhoangCachThucTeKm = request.KhoangCachKm;
            order.PhiDaDieuChinh = true;
            await _db.SaveChangesAsync();
            return Ok(new { phiGiaoHang = order.PhiGiaoHang, khoangCachKm = request.KhoangCachKm, phiDaDieuChinh = true });
        }

        // ============================== Thông báo (mọi vai trò) ==============================

        /// <summary>Thông báo của tài khoản đang đăng nhập (bảng ThongBao), mới nhất trước. ?chiChuaDoc=true để lọc chưa đọc.</summary>
        [HttpGet("thong-bao")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> MyNotifications(bool chiChuaDoc = false, int soLuong = 50)
        {
            var q = _db.ThongBaos.AsNoTracking().Where(t => t.MaTK == CurrentMaTK);
            if (chiChuaDoc) q = q.Where(t => !t.DaDoc);
            var ds = await q.OrderByDescending(t => t.NgayTao).Take(Math.Clamp(soLuong, 1, 200)).ToListAsync();
            var chuaDoc = await _db.ThongBaos.CountAsync(t => t.MaTK == CurrentMaTK && !t.DaDoc);
            return Ok(new { chuaDoc, items = ds.Select(t => new { id = t.MaThongBao, loai = t.Loai, tieuDe = t.TieuDe, noiDung = t.NoiDung, maThamChieu = t.MaThamChieu, daDoc = t.DaDoc, ngay = t.NgayTao }) });
        }

        [HttpPut("thong-bao/{id:long}/da-doc")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> MarkNotificationRead(long id)
        {
            var tb = await _db.ThongBaos.FirstOrDefaultAsync(t => t.MaThongBao == id && t.MaTK == CurrentMaTK);
            if (tb == null) return Loi("Không tìm thấy thông báo.", 404);
            tb.DaDoc = true; await _db.SaveChangesAsync();
            return Ok(new { id });
        }

        [HttpPut("thong-bao/doc-tat-ca")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> MarkAllNotificationsRead()
        {
            var ds = await _db.ThongBaos.Where(t => t.MaTK == CurrentMaTK && !t.DaDoc).ToListAsync();
            foreach (var t in ds) t.DaDoc = true;
            await _db.SaveChangesAsync();
            return Ok(new { daDoc = ds.Count });
        }

        // ============================== Common order ==============================

        [HttpPut("don-hang/{id:int}/huy")]
        [HttpPost("~/api/orders/{id:int}/cancel")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> CustomerCancel(int id)
        {
            var kh = await CurrentCustomerAsync();
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            var order = await _db.DonHangs.Include(d => d.ThanhToan).FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaKH == kh.MaKH);
            if (order == null) return Loi("Không tìm thấy đơn hàng.", 404);
            if (order.TrangThai != "ChoXacNhan") return Loi("Đơn đã được gian hàng xác nhận, không thể tự hủy.");
            order.TrangThai = "DaHuy";
            order.LyDoTuChoi ??= "Khách hàng tự hủy đơn";
            var tbHoan = await FoodServiceApp.Web.Services.HoanTienXuLy.TaoYeuCauKhiHuyAsync(_db, order, "KhachHang", "Khách tự hủy đơn khi chờ xác nhận");
            await _db.SaveChangesAsync();
            return Ok(new { trangThai = order.TrangThai, daTaoYeuCauHoanTien = tbHoan != null, thongDiep = tbHoan });
        }

        [HttpPut("doi-mat-khau")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> ChangePassword(MobileChangePasswordRequest request)
        {
            if (request.VaiTro != CurrentRole) return Loi("Vai trò không khớp phiên đăng nhập.", 403);
            var tk = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == CurrentMaTK && t.VaiTro == CurrentRole);
            if (tk == null) return Loi("Tài khoản không hợp lệ.", 401);
            if (!MatKhauHelper.Khop(request.MatKhauCu, tk.MatKhau)) return Loi("Mật khẩu hiện tại không đúng.");
            if (string.IsNullOrWhiteSpace(request.MatKhauMoi) || request.MatKhauMoi.Length < 6) return Loi("Mật khẩu mới tối thiểu 6 ký tự.");
            tk.MatKhau = MatKhauHelper.Hash(request.MatKhauMoi);
            tk.PhienHopLeTu = DateTime.UtcNow;   // thu hồi các token đã cấp (phải đăng nhập lại)
            await _db.SaveChangesAsync();
            return Ok(new { message = "Đã đổi mật khẩu." });
        }

        // ============================== Map/payment ==============================

        [HttpPost("map/phi-giao-hang")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        public async Task<IActionResult> DeliveryFeePreview(MobileDeliveryPreviewRequest request)
        {
            if (string.IsNullOrWhiteSpace(request.DiaChiLay) || string.IsNullOrWhiteSpace(request.DiaChiGiao)) return Loi("Thiếu địa chỉ lấy/giao.");
            var route = await CalculateDeliveryAsync(request.DiaChiLay, request.DiaChiGiao);
            // daXacMinh = false: máy chủ KHÔNG có khoảng cách thật (chưa có khóa Goong / không geocode được) nên đang trả phí mặc định, không phải phí theo tuyến.
            return Ok(new
            {
                phiGiaoHang = route.Phi, khoangCachKm = route.Km, thoiGianDuKienPhut = route.Phut, ngoaiThanh = route.NgoaiThanh,
                daXacMinh = route.DaXacMinh,
                nguon = route.DaXacMinh ? "TuyenDuong" : "PhiMacDinh",
                ghiChu = route.DaXacMinh ? "Phí tính theo quãng đường thật." : "Chưa đo được quãng đường thật nên dùng phí mặc định; phí chính thức có thể khác."
            });
        }

        /// <summary>App hỏi kết quả thanh toán của đơn (sau khi khách quay lại từ trang VNPay). Server là nguồn sự thật, ghi bởi return/IPN.</summary>
        [HttpGet("don-hang/{id:int}/thanh-toan")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> TrangThaiThanhToan(int id)
        {
            var kh = await CurrentCustomerAsync();
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            var d = await _db.DonHangs.AsNoTracking().Include(x => x.ThanhToan).FirstOrDefaultAsync(x => x.MaDonHang == id && x.MaKH == kh.MaKH);
            if (d == null) return Loi("Không tìm thấy đơn hàng.", 404);
            var tt = d.ThanhToan?.TrangThai ?? "ChoThanhToan";
            return Ok(new
            {
                maDonHang = d.MaDonHang,
                hinhThuc = d.ThanhToan?.HinhThuc ?? "TienMat",
                trangThai = tt,                              // ChoThanhToan | DaThanhToan | ThatBai | DaHoanTien
                daThanhToan = tt == "DaThanhToan",
                thatBai = tt == "ThatBai",
                donDaHuy = d.TrangThai == "DaHuy",
                tongTien = d.TongTien
            });
        }

        /// <summary>
        /// v51 — "Đã trừ tiền nhưng app không báo": hỏi lại cổng VNPay rồi cập nhật đơn nếu cổng xác nhận đã thu đúng tiền. An toàn khi bấm nhiều lần
        /// (chỉ gọi cổng khi đơn còn chờ thanh toán; giới hạn 1 lần/20 giây/đơn).
        /// </summary>
        private static readonly System.Collections.Concurrent.ConcurrentDictionary<int, DateTime> _lanKiemTraThanhToan = new();

        [HttpPost("don-hang/{id:int}/thanh-toan/kiem-tra-lai")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> KiemTraLaiThanhToan(int id)
        {
            var kh = await CurrentCustomerAsync();
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            if (!await _db.DonHangs.AsNoTracking().AnyAsync(x => x.MaDonHang == id && x.MaKH == kh.MaKH)) return Loi("Không tìm thấy đơn hàng.", 404);
            if (_lanKiemTraThanhToan.TryGetValue(id, out var lan) && (DateTime.Now - lan).TotalSeconds < 20) return Loi("Vừa kiểm tra xong, vui lòng đợi vài giây rồi thử lại.", 429);
            _lanKiemTraThanhToan[id] = DateTime.Now;
            var kq = await FoodServiceApp.Web.Services.Payment.VnPayXuLy.DoiSoatLaiAsync(_db, _vnpay, id, HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1");
            return Ok(new { maDonHang = id, thanhCong = kq.Ok, trangThai = kq.TrangThai, daThanhToan = kq.TrangThai == "DaThanhToan", thongDiep = kq.ThongDiep });
        }

        [HttpPost("payment/vnpay/tao-url")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> VnPayUrl(MobileVnPayRequest request)
        {
            var kh = await CurrentCustomerAsync();
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            var order = await _db.DonHangs.Include(d => d.ThanhToan).FirstOrDefaultAsync(d => d.MaDonHang == request.MaDonHang && d.MaKH == kh.MaKH);
            if (order == null) return Loi("Không tìm thấy đơn hàng.", 404);
            if (order.ThanhToan?.HinhThuc != "VNPay") return Loi("Đơn hàng không dùng VNPay.");
            if (order.ThanhToan.TrangThai == "DaThanhToan") return Loi("Đơn đã được thanh toán.");
            if (order.TrangThai == "DaHuy") return Loi("Đơn đã bị hủy.");
            var url = await FoodServiceApp.Web.Services.Payment.VnPayXuLy.TaoLinkAsync(_db, _vnpay, new VnPayCreateRequest(
                order.MaDonHang,
                (long)order.TongTien,       // số tiền do server quyết định, không lấy từ client
                request.NoiDung ?? $"Thanh toan don hang #{order.MaDonHang} - FoodServiceApp",
                HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1",
                Url.Action("VnPayReturn", "Payment", null, Request.Scheme)!));
            return Ok(new { paymentUrl = url });
        }

        public record MobileThanhToanRequest(int MaDonHang, string? PhuongThuc, string? NoiDung);

        /// <summary>
        /// POST api/mobile/thanh-toan — điểm vào thanh toán theo đơn. Phương thức lấy theo đơn đã đặt (không đổi sau khi đặt):
        /// VNPay → trả paymentUrl để mở cổng thanh toán; TienMat/COD → trả trạng thái (thanh toán khi nhận hàng).
        /// Số tiền luôn do máy chủ quyết định.
        /// </summary>
        [HttpPost("thanh-toan")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> ThanhToanDon(MobileThanhToanRequest request)
        {
            var kh = await CurrentCustomerAsync();
            if (kh == null) return Loi("Tài khoản khách hàng không hợp lệ.", 401);
            var order = await _db.DonHangs.AsNoTracking().Include(d => d.ThanhToan)
                .FirstOrDefaultAsync(d => d.MaDonHang == request.MaDonHang && d.MaKH == kh.MaKH);
            if (order == null) return Loi("Không tìm thấy đơn hàng.", 404);

            var hinhThuc = order.ThanhToan?.HinhThuc ?? "TienMat";
            var chon = (request.PhuongThuc ?? "").Trim();
            var khop = chon.Length == 0 || string.Equals(chon, hinhThuc, StringComparison.OrdinalIgnoreCase)
                       || (hinhThuc == "TienMat" && string.Equals(chon, "COD", StringComparison.OrdinalIgnoreCase));
            if (!khop) return Loi($"Đơn này đã chọn thanh toán {hinhThuc}; muốn đổi phương thức hãy đặt lại đơn.", 409);

            if (hinhThuc == "VNPay") return await VnPayUrl(new MobileVnPayRequest(request.MaDonHang, 0, request.NoiDung));

            return Ok(new
            {
                maDonHang = order.MaDonHang,
                hinhThuc = "TienMat",
                trangThai = order.ThanhToan?.TrangThai ?? "ChoThanhToan",
                tongTien = order.TongTien,
                thongDiep = "Đơn thanh toán tiền mặt khi nhận hàng (COD) — không cần thanh toán trực tuyến."
            });
        }

        // ============================== Local helpers ==============================

        public record MobileVendorRegisterRequest(string TenGianHang, string DiaChi, string Sdt, string Email, string MatKhau, string? MoTa, string? HinhAnh);
        public record MobilePlaceOrderItem(int MonAnId, int SoLuong, List<int>? TuyChonIds = null, string? GhiChu = null);
        public record MobilePlaceOrderRequest(int GianHangId, string DiaChiGiao, string? GhiChu, string HinhThucThanhToan, string? MaKhuyenMai, List<MobilePlaceOrderItem> ChiTiet, string? MaYeuCauDat = null, DateTime? HenGiaoLuc = null);
        public record MobileCustomerProfileRequest(string HoTen, string? Sdt, string? DiaChi);
        public record MobileIssueRequest(int? DonHangId, string TieuDe, string MoTa);
        public record MobileReviewRequest(int DonHangId, int SoSaoMonAn, int SoSaoGiaoHang, string? NoiDung, int SoSaoQuan = 0, string? TheNhanXet = null, List<string>? Anh = null);
        public record MobileVendorBusinessStatusRequest(bool DangMoCua);
        public record MobileRejectOrderRequest(string? LyDo);
        public record MobileConfirmOrderRequest(int? ChuanBiPhut);
        public record MobileDriverProfileRequest(string? HoTen, string? SoDienThoai, string? BienSoXe, string? LoaiXe, string? AnhDaiDien = null, string? SoCccd = null, string? SoGplx = null, string? AnhGplx = null, string? KhuVucHoatDong = null);
        public record MobileDriverPositionRequest(int DonHangId, double ViDo, double KinhDo);
        public record MobileCompleteOrderRequest(string? MaXacNhan, double? ViDo = null, double? KinhDo = null);
        public record MobileFailedDeliveryRequest(string LyDo, bool TinhPhi = false, double? ViDo = null, double? KinhDo = null);   // TinhPhi do server quyết định theo lý do
        public record MobileAdjustedFeeRequest(double KhoangCachKm, decimal PhiGiaoHang);
        public record MobileChangePasswordRequest(string VaiTro, string MatKhauCu, string MatKhauMoi);
        public record MobileDeliveryPreviewRequest(string DiaChiLay, string DiaChiGiao);
        public record MobileVnPayRequest(int MaDonHang, long SoTien, string? NoiDung);
        private sealed record ViTriNho(double Lat, double Lng, DateTime UpdatedAt);
        private sealed record DeliveryRoute(double Km, int Phut, decimal Phi, bool NgoaiThanh, bool DaXacMinh = false);

        private async Task<KhachHang?> CurrentCustomerAsync() => await _db.KhachHangs.FirstOrDefaultAsync(k => k.MaTK == CurrentMaTK);
        private async Task<TaiXe?> CurrentDriverAsync() => await _db.TaiXes.FirstOrDefaultAsync(t => t.MaTK == CurrentMaTK);

        private static string NormalizePhone(string? phone) => new string((phone ?? "").Where(char.IsDigit).ToArray());

        private static object MapKhachHang(KhachHang kh, TaiKhoan tk) => new
        {
            id = kh.MaKH,
            hoTen = kh.HoTen,
            email = kh.Email ?? "",
            matKhau = "",
            soDienThoai = kh.SDT,
            diaChi = kh.DiaChiGiaoHang ?? "",
            ngayDangKy = tk.NgayTao,
            tongSoDon = 0,
            taiKhoanBiKhoa = !tk.TrangThai
        };

        internal static object MapGianHang(GianHang gh, TaiKhoan tk) => new
        {
            id = gh.MaGianHang,
            tenGianHang = gh.TenCuaHang,
            diaChi = gh.DiaChi,
            hinhAnh = gh.HinhAnh ?? "🍽️",
            anhBia = gh.AnhBia,
            phanLoai = "",
            danhGia = 0d,
            thoiGianGiaoPhut = 30,
            soDienThoai = gh.SDT,
            email = tk.TenDangNhap.Contains("@") ? tk.TenDangNhap : $"{tk.TenDangNhap}@gianhang.vn",
            matKhau = "",
            moTa = gh.MoTa ?? "",
            dangMoCua = gh.TrangThaiKinhDoanh == "DangMo",
            gioMoCua = gh.GioMoCua.ToString(@"hh\:mm"),
            gioDongCua = gh.GioDongCua.ToString(@"hh\:mm"),
            dangNhanDon = gh.DangNhanDon,
            tyLeChietKhau = gh.TyLeChietKhau,
            taiKhoanBiKhoa = !tk.TrangThai,
            ngayDangKy = gh.NgayDangKy,
            trangThaiDangKy = gh.TrangThaiDuyet
        };

        private object MapIssue(PhanHoi p)
        {
            var trangThai = p.TrangThai == "DangXuLy" ? "DangXuLy" : p.TrangThai == "DaXuLy" ? "DaGiaiQuyet" : "MoiPhatSinh";
            return new
            {
                id = p.MaPhanHoi,
                tieuDe = p.TieuDe,
                moTa = p.NoiDung,
                nguonGoc = p.KhachHang?.HoTen ?? "Khách hàng",
                ngayBaoCao = p.NgayGui,
                trangThai,
                donHangId = p.MaDonHang,
                traLoi = p.TraLoi
            };
        }

        /// <summary>Khôi phục vị trí từ CSDL khi bộ nhớ trống (server vừa khởi động lại).</summary>
        private async Task HydratePositionsAsync(List<int> ids)
        {
            var thieu = ids.Where(i => !DriverPositions.ContainsKey(i)).ToList();
            if (thieu.Count == 0) return;
            foreach (var v in await _db.TaiXeViTris.AsNoTracking().Where(x => thieu.Contains(x.MaDonHang)).ToListAsync())
                DriverPositions[v.MaDonHang] = new ViTriNho(v.ViDo, v.KinhDo, v.CapNhatLuc);
        }

        private object MapMobileOrder(DonHang d) => MapMobileOrder(d, false);

        /// <summary>choKhach = true chỉ khi người gọi là chính khách hàng của đơn: mã xác nhận giao hàng không được lộ cho tài xế/gian hàng.</summary>
        private object MapMobileOrder(DonHang d, bool choKhach)
        {
            var position = DriverPositions.TryGetValue(d.MaDonHang, out var p) ? p : null;
            var adjustedKm = d.KhoangCachThucTeKm ?? 0d;
            var adjustedFee = d.PhiGiaoHang;
            var hasAdjusted = d.PhiDaDieuChinh;
            var taiXe = d.GiaoHang?.TaiXe;

            return new
            {
                id = d.MaDonHang,
                gianHangId = d.MaGianHang,
                tenGianHang = d.GianHang?.TenCuaHang ?? "",
                chiTiet = d.ChiTiets.Select(c => new
                {
                    monAn = c.MonAn == null ? null : new
                    {
                        id = c.MonAn.MaMonAn,
                        tenMon = c.MonAn.TenMon,
                        gia = c.MonAn.Gia,
                        hinhAnh = c.MonAn.HinhAnh ?? "🍲",
                        danhMuc = c.MonAn.DanhMuc?.TenDanhMuc ?? "",
                        gianHangId = d.MaGianHang,
                        conHang = c.MonAn.TinhTrang == "ConHang"
                    },
                    soLuong = c.SoLuong,
                    donGia = c.DonGia,
                    tuyChon = c.TuyChon ?? "",
                    ghiChu = c.GhiChu ?? "",
                    thanhTien = c.ThanhTien
                }).ToList(),
                trangThai = ToMobileOrderStatus(d.TrangThai),
                diaChiGiao = d.DiaChiGiaoHang,
                ngayDat = d.NgayDat,
                khachTen = d.KhachHang?.HoTen ?? "",
                khachSdt = d.KhachHang?.SDT ?? "",
                khachEmail = d.KhachHang?.Email ?? "",
                diaChiLayHang = d.GianHang?.DiaChi ?? "",
                taiXeId = d.MaTaiXe?.ToString(),
                phiGiaoHang = hasAdjusted ? adjustedFee : d.PhiGiaoHang,
                hinhThucThanhToan = d.ThanhToan?.HinhThuc ?? "TienMat",
                trangThaiThanhToan = d.ThanhToan?.TrangThai ?? "",      // ChoThanhToan | DaThanhToan | ThatBai | DaHoanTien
                maKhuyenMai = d.KhuyenMaiApDung?.MaCode ?? "",
                giamGia = Math.Max(0, d.ChiTiets.Sum(c => c.DonGia * c.SoLuong) - (d.TongTien - d.PhiGiaoHang)),
                khoangCachKm = adjustedKm > 0 ? adjustedKm : (d.KhoangCachKm ?? 0d),
                thoiGianDuKienPhut = d.ThoiGianDuKienPhut ?? 0,
                thoiGianChuanBiPhut = d.ThoiGianChuanBiPhut,
                khuVucLay = "",
                khuVucGiao = "",
                ngoaiThanh = d.NgoaiThanh,
                phiKhoangCach = hasAdjusted ? adjustedFee : d.PhiGiaoHang,
                phuPhiKhuVuc = d.NgoaiThanh ? PhuPhiNgoaiThanh : 0m,
                phiDaDieuChinh = hasAdjusted,
                khoangCachThucTeKm = adjustedKm,
                taiXeTen = taiXe?.HoTen ?? "",
                taiXeSdt = taiXe?.SDT ?? "",
                taiXeBienSo = string.IsNullOrWhiteSpace(taiXe?.BienSo) ? "" : $"{taiXe!.PhuongTien} · {taiXe.BienSo}",
                nguonGiao = d.NguonGiao,                                     // Quan = tài xế của quán | Ngoai = shipper ngoài
                taiXeLaCuaQuan = taiXe?.MaGianHang != null,
                daLayHang = d.GiaoHang?.TrangThai is "DangGiao" or "GiaoThanhCong" or "GiaoThatBai",
                layHangLuc = d.GiaoHang?.ThoiGianLayHang ?? d.GiaoHang?.ThoiGianNhan,
                denQuanLuc = d.GiaoHang?.ThoiGianDenQuan,
                sanSangGiao = d.SanSangGiao || d.TrangThaiChuanBi == "SanSangGiao",
                sanSangGiaoLuc = d.ThoiGianSanSang,
                banGiaoLuc = d.GiaoHang?.QuanBanGiaoLuc,
                khachXacNhanLuc = d.KhachXacNhanLuc,
                taiXeLat = position?.Lat,
                taiXeLng = position?.Lng,
                viTriCapNhatLuc = position?.UpdatedAt,
                viTriCu = position != null && (DateTime.Now - position.UpdatedAt).TotalSeconds > FoodServiceApp.Web.Services.GiaoHangXuLy.ViTriCuGiay,
                maXacNhanGiao = choKhach ? GetDeliveryCode(d) : null,
                soLanSaiMa = choKhach ? d.SoLanSaiMa : 0,
                bangChungGiao = d.GiaoHang?.AnhBangChung,
                coMaXacNhan = !string.IsNullOrEmpty(GetDeliveryCode(d)),     // tài xế không nhận mã, chỉ biết đơn có yêu cầu mã hay không (không có -> phải chụp ảnh bằng chứng)
                trangThaiChuanBi = d.TrangThaiChuanBi,                       // null | DangChuanBi | SanSangGiao
                quanBanGiaoLuc = d.GiaoHang?.QuanBanGiaoLuc,
                giaoLuc = d.GiaoHang?.ThoiGianGiao,
                giaoThatBai = d.GiaoHang?.TrangThai == "GiaoThatBai",
                lyDoGiaoThatBai = d.GiaoHang?.TrangThai == "GiaoThatBai" ? ExtractFailedReason(d.GhiChu) : "",
                lyDoTuChoi = d.LyDoTuChoi ?? "",
                henGiaoLuc = d.HenGiaoLuc,
                gioHenGiao = d.HenGiaoLuc == null ? "" : d.HenGiaoLuc.Value.ToString("HH:mm dd/MM"),
                ghiChu = CleanUserNote(d.GhiChu)
            };
        }

        private static string ToMobileOrderStatus(string status) => status switch
        {
            "ChoXacNhan" => "ChoXacNhan",
            "DaXacNhan" => "DangLam",
            "DangGiao" => "DangGiao",
            "DaGiao" => "HoanThanh",
            "DaHuy" => "DaHuy",
            _ => status
        };

        private static string CleanUserNote(string? text)
        {
            if (string.IsNullOrWhiteSpace(text)) return "";
            var marker = "[MA_GIAO:";
            var start = text.IndexOf(marker, StringComparison.Ordinal);
            if (start < 0) return text;
            var end = text.IndexOf(']', start);
            if (end < 0) return text;
            return text[(end + 1)..].Trim();
        }

        private static string? GetDeliveryCode(DonHang d)
        {
            if (!string.IsNullOrEmpty(d.MaXacNhanGiao)) return d.MaXacNhanGiao;
            var marker = d.GhiChu?.IndexOf("[MA_GIAO:", StringComparison.Ordinal) ?? -1;
            if (marker < 0) return null;
            var start = marker + "[MA_GIAO:".Length;
            var end = d.GhiChu!.IndexOf(']', start);
            return end > start ? d.GhiChu[start..end] : null;
        }

        private static string? ExtractDeliveryCode(string text)
        {
            var marker = text.IndexOf("[MA_GIAO:", StringComparison.Ordinal);
            if (marker < 0) return null;
            var start = marker + "[MA_GIAO:".Length;
            var end = text.IndexOf(']', start);
            return end > start ? text[start..end] : null;
        }

        private static string ExtractFailedReason(string? text)
        {
            if (string.IsNullOrWhiteSpace(text)) return "";
            var marker = "Giao thất bại:";
            var i = text.LastIndexOf(marker, StringComparison.OrdinalIgnoreCase);
            return i >= 0 ? text[(i + marker.Length)..].Trim() : "";
        }

        private async Task<IActionResult> SetVendorApproval(int id, string state)
        {
            var store = await _db.GianHangs.FirstOrDefaultAsync(g => g.MaGianHang == id);
            if (store == null) return Loi("Không tìm thấy gian hàng.", 404);
            store.TrangThaiDuyet = state;
            if (state == "DaDuyet") store.TrangThaiKinhDoanh = "DangMo";
            if (state == "TuChoi") store.TrangThaiKinhDoanh = "DongCua";
            await _db.SaveChangesAsync();
            return Ok(new { trangThaiDangKy = store.TrangThaiDuyet });
        }

        private async Task<IActionResult> ToggleVendorLock(int id, bool active)
        {
            var store = await _db.GianHangs.FirstOrDefaultAsync(g => g.MaGianHang == id);
            if (store == null) return Loi("Không tìm thấy gian hàng.", 404);
            var tk = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == store.MaTK);
            if (tk == null) return Loi("Không tìm thấy tài khoản gian hàng.", 404);
            tk.TrangThai = active;
            if (!active) store.TrangThaiKinhDoanh = "DongCua";
            await _db.SaveChangesAsync();
            return Ok(new { taiKhoanBiKhoa = !tk.TrangThai });
        }

        private async Task<IActionResult> ToggleCustomerLock(int id, bool active)
        {
            var kh = await _db.KhachHangs.FirstOrDefaultAsync(k => k.MaKH == id);
            if (kh == null) return Loi("Không tìm thấy khách hàng.", 404);
            var tk = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == kh.MaTK);
            if (tk == null) return Loi("Không tìm thấy tài khoản.", 404);
            tk.TrangThai = active;
            await _db.SaveChangesAsync();
            return Ok(new { taiKhoanBiKhoa = !tk.TrangThai });
        }

        private async Task<DonHang?> GetOrderForVendorAsync(int id) =>
            await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaGianHang == _db.GianHangs.Where(g => g.MaTK == CurrentMaTK).Select(g => g.MaGianHang).FirstOrDefault());

        private async Task<IActionResult> UpdateVendorOrderStatus(int id, string next, string? lyDo = null, int? chuanBiPhut = null)
        {
            var order = await GetOrderForVendorAsync(id);
            if (order == null) return Loi("Không tìm thấy đơn hàng hoặc bạn không có quyền.", 404);
            if (!FoodServiceApp.Web.Services.TrangThaiDon.ChoPhep(order.TrangThai, next, FoodServiceApp.Web.Services.TrangThaiDon.GianHang))
            {
                await FoodServiceApp.Web.Services.TrangThaiDon.GhiTuChoiAsync(_db, HttpContext, order.MaDonHang, order.TrangThai, next, FoodServiceApp.Web.Services.TrangThaiDon.GianHang, "Chuyển trạng thái không nằm trong quy trình cho phép.");
                return Loi("Không thể chuyển trạng thái đơn hàng.");
            }
            order.TrangThai = next;
            if (next == "DaXacNhan" && chuanBiPhut is >= 5 and <= 120) order.ThoiGianChuanBiPhut = chuanBiPhut;
            if (next == "DaHuy")
            {
                order.LyDoTuChoi = lyDo;
                await FoodServiceApp.Web.Services.HoanTienXuLy.TaoYeuCauKhiHuyAsync(_db, order, "GianHang", "Gian hàng từ chối/hủy đơn: " + (lyDo ?? ""));
            }
            if (next == "DaXacNhan") await FoodServiceApp.Web.Services.GiaoHangXuLy.BaoQuanTriDonCanDieuPhoiAsync(_db, order, order.SanSangGiao);   // chuyển đơn lên Quản trị điều phối
            await _db.SaveChangesAsync();
            if (next == "DaXacNhan") FoodServiceApp.Web.Services.PhanPhoiDonXuLy.DanhThucNgay();   // quán vừa xác nhận → tìm tài xế đúng khu vực NGAY, không chờ chu kỳ quét
            if (next == "DaHuy") await FoodServiceApp.Web.Services.TrangThaiDon.SauKhiHuyAsync(_db, order, lyDo ?? "Gian hàng hủy đơn");
            return Ok(new { trangThai = order.TrangThai });
        }

        /// <summary>v83: phí giao theo công thức Admin cấu hình (PhiGiaoService); lỗi bản đồ → phí mặc định, không chặn đặt đơn.</summary>
        private async Task<DeliveryRoute> CalculateDeliveryAsync(string from, string to)
        {
            var pd = await FoodServiceApp.Web.Services.PhiGiaoService.TinhTheoDiaChiAsync(_db, _maps, from, to);
            return new DeliveryRoute(pd.Km, pd.Phut, pd.Phi, pd.NgoaiThanh, pd.CoKhoangCach);   // CoKhoangCach = có khoảng cách thật từ Goong
        }

        private static bool IsOutskirts(string address)
        {
            var s = RemoveDiacritics(address).ToLowerInvariant();
            return s.Contains("cu chi") || s.Contains("hoc mon") || s.Contains("binh chanh") || s.Contains("nha be") || s.Contains("can gio");
        }

        private static string RemoveDiacritics(string text)
        {
            var normalized = text.Normalize(System.Text.NormalizationForm.FormD);
            var sb = new StringBuilder(normalized.Length);
            foreach (var c in normalized)
                if (System.Globalization.CharUnicodeInfo.GetUnicodeCategory(c) != System.Globalization.UnicodeCategory.NonSpacingMark)
                    sb.Append(c);
            return sb.ToString().Normalize(System.Text.NormalizationForm.FormC).Replace('đ', 'd').Replace('Đ', 'D');
        }
    }
}
