using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.ViewModels;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// Thu nhập tài xế cho app (GET api/mobile/tai-xe/thu-nhap): cùng cách tính với trang web TaiXe/ThuNhap —
    /// số đơn đã nhận / đã giao / giao thất bại / bị hủy, thu nhập ngày-tuần-tháng, thưởng và phí giao, COD đã thu và khoản cần nộp lại,
    /// các khoản nền tảng đã trả hay chưa, lịch sử giao dịch. Đơn bị hủy không tính là hoàn thành.
    /// </summary>
    [ApiController]
    [Route("api/mobile/tai-xe")]
    public class DriverThuNhapApiController : DriverApiBaseController
    {
        private readonly AppDbContext _db;
        public DriverThuNhapApiController(AppDbContext db) { _db = db; }

        [HttpGet("thu-nhap")]
        public async Task<IActionResult> ThuNhap()
        {
            var maTaiXe = await _db.TaiXes.AsNoTracking().Where(t => t.MaTK == CurrentMaTK).Select(t => t.MaTaiXe).FirstOrDefaultAsync();
            if (maTaiXe == 0) return NotFound(new { thongDiep = "Không tìm thấy hồ sơ tài xế." });

            var homNay = DateTime.Today;
            var dauTuan = homNay.AddDays(-(((int)homNay.DayOfWeek + 6) % 7));        // tuần bắt đầu thứ Hai
            var dauThang = new DateTime(homNay.Year, homNay.Month, 1);
            var tuNgay = homNay.AddDays(-29);
            var batDau = new[] { tuNgay, dauThang, dauTuan }.Min();

            var gh = await _db.GiaoHangs.AsNoTracking().Include(g => g.DonHang)
                .Where(g => g.MaTaiXe == maTaiXe && g.ThoiGianGiao >= batDau
                            && (g.TrangThai == "GiaoThanhCong" || (g.TrangThai == "GiaoThatBai" && g.TinhPhiThatBai)))
                .ToListAsync();
            var dc = await _db.DieuChinhThuNhaps.AsNoTracking().Where(x => x.MaTaiXe == maTaiXe && x.NgayTao >= batDau).ToListAsync();

            var dong = new List<DongThuNhap>();
            foreach (var g in gh)
                dong.Add(new DongThuNhap
                {
                    ThoiGian = g.ThoiGianGiao!.Value, MaDonHang = g.MaDonHang, SoTien = FoodServiceApp.Web.Services.PhiGiaoService.TienTaiXe(g.DonHang!.PhiGiaoHang, g.DonHang.TyLeTaiXe),
                    Loai = g.TrangThai == "GiaoThanhCong" ? "PhiGiao" : "PhiGiaoThatBai",
                    GhiChu = g.TrangThai == "GiaoThatBai" ? "Giao thất bại do khách: " + g.LyDoThatBai : null,
                    TrangThai = g.TrangThaiThuNhap, CodThu = g.TienThuCOD
                });
            foreach (var x in dc)
                dong.Add(new DongThuNhap { ThoiGian = x.NgayTao, MaDonHang = x.MaDonHang, SoTien = x.SoTien, Loai = x.Loai, GhiChu = x.LyDo, TrangThai = x.TrangThai });

            decimal Tong(DateTime tu) => dong.Where(d => d.ThoiGian >= tu).Sum(d => d.SoTien);
            int Don(DateTime tu) => dong.Count(d => d.ThoiGian >= tu && d.Loai == "PhiGiao");
            var d30 = dong.Where(d => d.ThoiGian >= tuNgay).ToList();

            // Số đơn trong 30 ngày: đã nhận / đã giao / giao thất bại / bị hủy
            var nhan30 = _db.GiaoHangs.AsNoTracking().Where(g => g.MaTaiXe == maTaiXe && g.ThoiGianNhan >= tuNgay);
            var soDaNhan = await nhan30.CountAsync();
            var soDaGiao = await _db.GiaoHangs.AsNoTracking().CountAsync(g => g.MaTaiXe == maTaiXe && g.TrangThai == "GiaoThanhCong" && g.ThoiGianGiao >= tuNgay);
            var soThatBai = await _db.GiaoHangs.AsNoTracking().CountAsync(g => g.MaTaiXe == maTaiXe && g.TrangThai == "GiaoThatBai" && g.ThoiGianGiao >= tuNgay);
            var soBiHuy = await nhan30.CountAsync(g => g.DonHang!.TrangThai == "DaHuy");

            var codDangCam = await _db.DonHangs.AsNoTracking()
                .Where(d => d.MaTaiXe == maTaiXe && d.TrangThai == "DangGiao" && d.ThanhToan != null && d.ThanhToan.HinhThuc == "TienMat" && d.ThanhToan.TrangThai != "DaThanhToan")
                .SumAsync(d => (decimal?)d.TongTien) ?? 0;
            var codChoNop = await DriverDonXuLy.CodChuaNopAsync(_db, maTaiXe);

            return Ok(new
            {
                soDonDaNhan30Ngay = soDaNhan,
                soDonDaGiao30Ngay = soDaGiao,
                soDonGiaoThatBai30Ngay = soThatBai,
                soDonBiHuy30Ngay = soBiHuy,

                homNay = Tong(homNay), tuanNay = Tong(dauTuan), thangNay = Tong(dauThang),
                donHomNay = Don(homNay), donTuanNay = Don(dauTuan), donThangNay = Don(dauThang),

                tongPhiGiao30Ngay = d30.Where(d => d.Loai is "PhiGiao" or "PhiGiaoThatBai").Sum(d => d.SoTien),
                tongThuongPhuCap30Ngay = d30.Where(d => (d.Loai is "Thuong" or "PhuCap" or "DieuChinh") && d.SoTien > 0).Sum(d => d.SoTien),
                tongTru30Ngay = d30.Where(d => d.Loai == "Phat" || (d.Loai == "DieuChinh" && d.SoTien < 0)).Sum(d => d.SoTien),
                tongThuNhap30Ngay = d30.Sum(d => d.SoTien),

                codPhaiThuDangGiao = codDangCam,
                codDaThu30Ngay = d30.Sum(d => d.CodThu ?? 0),
                codCanNopLai = codChoNop.Sum(c => c.SoTien),
                soDonCodChoNop = codChoNop.Count(),
                choNenTangTra = d30.Where(d => d.TrangThai != "DaThanhToan").Sum(d => d.SoTien),
                daDuocTra = d30.Where(d => d.TrangThai == "DaThanhToan").Sum(d => d.SoTien),

                theoNgay = d30.GroupBy(d => d.ThoiGian.Date).OrderBy(g => g.Key).Select(g => new { ngay = g.Key, soTien = g.Sum(x => x.SoTien) }),
                giaoDich = d30.OrderByDescending(d => d.ThoiGian).Take(100).Select(d => new
                {
                    thoiGian = d.ThoiGian, loai = d.Loai, maDonHang = d.MaDonHang, soTien = d.SoTien, ghiChu = d.GhiChu, trangThai = d.TrangThai, codThu = d.CodThu
                }),
            });
        }
    }
}
