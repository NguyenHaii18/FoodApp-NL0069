using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>Tiếp nhận và PHÂN CÔNG xử lý khiếu nại / phản hồi của khách (bảng PhanHoi) cho app quản trị — cùng quy tắc với trang web AdminPhanHoi:
    /// ai cũng nhận xử lý được; phân công cho người khác và chuyển hoàn tiền chỉ Admin tổng / Quản lý.</summary>
    [ApiController]
    [Route("api/mobile/admin/khieu-nai")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
    public class AdminKhieuNaiApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        public AdminKhieuNaiApiController(AppDbContext db) { _db = db; }

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static ObjectResult Loi(string m, int status = 400) => new(new { thongDiep = m }) { StatusCode = status };
        private Task<bool> LaQuanLyAsync() => _db.QuanTris.AnyAsync(q => q.MaTK == MaTK && (q.CapQuyenHan == "SuperAdmin" || q.CapQuyenHan == "QuanLy"));

        private static readonly string[] PhanLoaiHopLe = { "DonHang", "MonAn", "TaiXe", "GianHang", "ThanhToan", "Khac" };

        // GET api/mobile/admin/khieu-nai?tab=cho|cua-toi|da-xu-ly|tat-ca&q=
        [HttpGet("")]
        public async Task<IActionResult> Ds(string tab = "cho", string? q = null)
        {
            var qr = _db.PhanHois.AsNoTracking().Include(p => p.KhachHang).AsQueryable();
            qr = tab switch
            {
                "cua-toi" => qr.Where(p => p.MaTKPhuTrach == MaTK && p.TrangThai == "ChuaXuLy"),
                "da-xu-ly" => qr.Where(p => p.TrangThai == "DaXuLy"),
                "tat-ca" => qr,
                _ => qr.Where(p => p.TrangThai == "ChuaXuLy"),
            };
            if (!string.IsNullOrWhiteSpace(q))
            {
                var k = q.Trim();
                qr = qr.Where(p => p.TieuDe.Contains(k) || p.NoiDung.Contains(k) || (p.KhachHang != null && (p.KhachHang.HoTen.Contains(k) || p.KhachHang.SDT.Contains(k)))
                    || (p.MaDonHang != null && p.MaDonHang.ToString() == k));
            }
            var ds = await qr.OrderBy(p => p.TrangThai == "DaXuLy").ThenBy(p => p.TrangThai == "ChuaXuLy" ? p.NgayGui : DateTime.MaxValue)
                .ThenByDescending(p => p.NgayGui).Take(100).ToListAsync();

            var nhanVien = await _db.QuanTris.AsNoTracking().OrderBy(x => x.HoTen).Select(x => new { maTK = x.MaTK, hoTen = x.HoTen, cap = x.CapQuyenHan }).ToListAsync();
            var ten = nhanVien.ToDictionary(x => x.maTK, x => x.hoTen);
            var quanLy = await LaQuanLyAsync();

            return Ok(new
            {
                laQuanLy = quanLy,
                maTKToi = MaTK,
                soChoXuLy = await _db.PhanHois.CountAsync(p => p.TrangThai == "ChuaXuLy"),
                soChuaPhanCong = await _db.PhanHois.CountAsync(p => p.TrangThai == "ChuaXuLy" && p.MaTKPhuTrach == null),
                nhanVien,
                ds = ds.Select(p => new
                {
                    maPhanHoi = p.MaPhanHoi, loai = p.Loai, tieuDe = p.TieuDe, noiDung = p.NoiDung, trangThai = p.TrangThai,
                    phanLoai = p.PhanLoai, yeuCauBoSung = p.YeuCauBoSung, traLoi = p.TraLoi,
                    maDonHang = p.MaDonHang, ngayGui = p.NgayGui, ngayXuLy = p.NgayXuLy,
                    tenKhach = p.KhachHang?.HoTen ?? "", sdtKhach = p.KhachHang?.SDT ?? "",
                    maTKPhuTrach = p.MaTKPhuTrach, tenPhuTrach = p.MaTKPhuTrach != null && ten.TryGetValue(p.MaTKPhuTrach.Value, out var t) ? t : "",
                    laCuaToi = p.MaTKPhuTrach == MaTK,
                    choGio = p.TrangThai == "ChuaXuLy" ? Math.Round((DateTime.Now - p.NgayGui).TotalHours, 1) : (double?)null,
                }),
            });
        }

        public record NhanReq(string? GhiChu);
        public record PhanCongReq(int MaTK);
        public record PhanLoaiReq(string? PhanLoai);
        public record BoSungReq(string? YeuCau);
        public record TraLoiReq(string? TraLoi);
        public record HoanTienReq(decimal SoTien);

        private Task<PhanHoi?> LayAsync(int id) => _db.PhanHois.FirstOrDefaultAsync(p => p.MaPhanHoi == id);

        // Tự nhận xử lý. Đã có người phụ trách khác thì chỉ Quản lý mới giành lại được.
        [HttpPut("{id:int}/nhan-xu-ly")]
        public async Task<IActionResult> NhanXuLy(int id)
        {
            var ph = await LayAsync(id); if (ph == null) return Loi("Không tìm thấy phản hồi.", 404);
            if (ph.TrangThai == "DaXuLy") return Loi("Phản hồi này đã xử lý xong.", 409);
            if (ph.MaTKPhuTrach != null && ph.MaTKPhuTrach != MaTK && !await LaQuanLyAsync())
                return Loi("Phản hồi đã có người phụ trách. Hãy nhờ Quản lý phân công lại.", 409);
            ph.MaTKPhuTrach = MaTK;
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = $"Bạn đã nhận xử lý phản hồi #{id}." });
        }

        [HttpPut("{id:int}/phan-cong")]
        public async Task<IActionResult> PhanCong(int id, PhanCongReq r)
        {
            if (!await LaQuanLyAsync()) return Loi("Chỉ Admin tổng / Quản lý được phân công xử lý.", 403);
            var ph = await LayAsync(id); if (ph == null) return Loi("Không tìm thấy phản hồi.", 404);
            if (ph.TrangThai == "DaXuLy") return Loi("Phản hồi này đã xử lý xong.", 409);
            if (!await _db.QuanTris.AnyAsync(q => q.MaTK == r.MaTK)) return Loi("Không tìm thấy nhân viên.", 404);
            ph.MaTKPhuTrach = r.MaTK;
            if (r.MaTK != MaTK)
                _db.ThongBaos.Add(new ThongBao { MaTK = r.MaTK, Loai = "HeThong", MaThamChieu = id.ToString(), TieuDe = "Bạn được phân công xử lý khiếu nại", NoiDung = $"Phản hồi #{id}: {ph.TieuDe}" });
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = $"Đã phân công xử lý phản hồi #{id}." });
        }

        [HttpPut("{id:int}/phan-loai")]
        public async Task<IActionResult> PhanLoai(int id, PhanLoaiReq r)
        {
            var ph = await LayAsync(id); if (ph == null) return Loi("Không tìm thấy phản hồi.", 404);
            if (r.PhanLoai == null || !PhanLoaiHopLe.Contains(r.PhanLoai)) return Loi("Phân loại không hợp lệ.");
            ph.PhanLoai = r.PhanLoai;
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã cập nhật phân loại." });
        }

        [HttpPut("{id:int}/bo-sung")]
        public async Task<IActionResult> BoSung(int id, BoSungReq r)
        {
            var ph = await LayAsync(id); if (ph == null) return Loi("Không tìm thấy phản hồi.", 404);
            var yc = (r.YeuCau ?? "").Trim();
            if (yc.Length < 3 || yc.Length > 500) return Loi("Nội dung cần khách bổ sung dài 3–500 ký tự.");
            ph.YeuCauBoSung = yc;
            ph.MaTKPhuTrach ??= MaTK;
            var kh = await _db.KhachHangs.AsNoTracking().FirstOrDefaultAsync(k => k.MaKH == ph.MaKH);
            if (kh != null)
                _db.ThongBaos.Add(new ThongBao { MaTK = kh.MaTK, Loai = "HeThong", MaThamChieu = id.ToString(), TieuDe = "Cần bổ sung thông tin cho yêu cầu hỗ trợ", NoiDung = $"Yêu cầu \"{ph.TieuDe}\": {yc}" });
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã gửi yêu cầu bổ sung tới khách." });
        }

        [HttpPut("{id:int}/tra-loi")]
        public async Task<IActionResult> TraLoi(int id, TraLoiReq r)
        {
            var ph = await LayAsync(id); if (ph == null) return Loi("Không tìm thấy phản hồi.", 404);
            if (ph.TrangThai == "DaXuLy") return Loi("Phản hồi này đã xử lý xong.", 409);
            if (ph.MaTKPhuTrach != null && ph.MaTKPhuTrach != MaTK && !await LaQuanLyAsync())
                return Loi("Phản hồi đang do người khác phụ trách.", 403);
            var nd = (r.TraLoi ?? "").Trim();
            if (nd.Length < 3 || nd.Length > 2000) return Loi("Nội dung trả lời dài 3–2000 ký tự.");
            ph.TraLoi = nd; ph.MaTKPhuTrach ??= MaTK; ph.TrangThai = "DaXuLy"; ph.NgayXuLy = DateTime.Now;
            var kh = await _db.KhachHangs.AsNoTracking().FirstOrDefaultAsync(k => k.MaKH == ph.MaKH);
            if (kh != null)
                _db.ThongBaos.Add(new ThongBao { MaTK = kh.MaTK, Loai = "HeThong", MaThamChieu = id.ToString(), TieuDe = "Yêu cầu hỗ trợ của bạn đã được phản hồi", NoiDung = nd.Length > 120 ? nd[..120] + "…" : nd });
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = $"Đã trả lời và đóng phản hồi #{id}." });
        }

        // Khiếu nại đủ điều kiện -> yêu cầu hoàn tiền (duyệt ở mục Thanh toán & hoàn tiền, như trang web)
        [HttpPost("{id:int}/chuyen-hoan-tien")]
        public async Task<IActionResult> ChuyenHoanTien(int id, HoanTienReq r)
        {
            if (!await LaQuanLyAsync()) return Loi("Chỉ Admin tổng / Quản lý được chuyển hoàn tiền.", 403);
            var ph = await LayAsync(id); if (ph == null) return Loi("Không tìm thấy phản hồi.", 404);
            if (ph.MaDonHang == null) return Loi("Phản hồi này không gắn với đơn hàng.");
            var don = await _db.DonHangs.Include(d => d.ThanhToan).FirstOrDefaultAsync(d => d.MaDonHang == ph.MaDonHang);
            if (don == null) return Loi("Không tìm thấy đơn hàng.", 404);
            if (don.ThanhToan?.TrangThai != "DaThanhToan") return Loi("Đơn chưa có thanh toán thành công nên chưa thể hoàn tiền.");
            if (await _db.YeuCauHoanTiens.AnyAsync(y => y.MaDonHang == don.MaDonHang && y.TrangThai == "ChoDuyet")) return Loi("Đơn này đã có yêu cầu hoàn tiền đang chờ duyệt.", 409);
            var tien = r.SoTien <= 0 || r.SoTien > don.TongTien ? don.TongTien : r.SoTien;
            _db.YeuCauHoanTiens.Add(new YeuCauHoanTien { MaDonHang = don.MaDonHang, MaKH = don.MaKH, SoTien = tien, LyDo = $"Khiếu nại #{ph.MaPhanHoi}: {ph.TieuDe}", Nguon = "KhieuNai" });
            ph.MaTKPhuTrach ??= MaTK;
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = $"Đã chuyển sang hoàn tiền {tien:N0}đ (chờ duyệt)." });
        }
    }
}
