using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>v55 — GET api/mobile/khach/goi-y-mon?top=8: món gợi ý cá nhân hóa cho khách đang đăng nhập (xem GoiYMonXuLy).</summary>
    [ApiController]
    [Route("api/mobile/khach")]
    public class GoiYMonApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        public GoiYMonApiController(AppDbContext db) { _db = db; }

        [HttpGet("goi-y-mon")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
        public async Task<IActionResult> GoiY(int top = 8)
        {
            var maTK = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
            var maKH = await _db.KhachHangs.AsNoTracking().Where(k => k.MaTK == maTK).Select(k => (int?)k.MaKH).FirstOrDefaultAsync();
            var ds = await GoiYMonXuLy.TinhAsync(_db, maKH, DateTime.Now, Math.Clamp(top, 1, 20));
            return Ok(new { caNhanHoa = maKH != null && ds.Count > 0, nhomGio = GoiYMonXuLy.NhomGio(DateTime.Now.Hour), ds });
        }
    }
}
