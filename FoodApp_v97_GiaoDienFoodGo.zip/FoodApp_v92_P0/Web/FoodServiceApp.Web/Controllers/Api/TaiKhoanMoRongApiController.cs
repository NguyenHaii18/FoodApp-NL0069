using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// v69 — Quản lý tài khoản trên app (mục "Đăng ký, đăng nhập và tài khoản"):
    ///   GET  tai-khoan/phien · DELETE tai-khoan/phien/{id} · POST tai-khoan/phien/dang-xuat-khac   (phiên đăng nhập theo thiết bị)
    ///   POST tai-khoan/yeu-cau-khoa                                                                 (tự khóa tài khoản, cần mật khẩu)
    ///   GET  dieu-khoan (công khai) · GET tai-khoan/dieu-khoan · POST tai-khoan/dieu-khoan/dong-y  (điều khoản & quyền riêng tư)
    /// Không cần bảng mới: dùng PhienDangNhap, TaiKhoan.TrangThai và TaiKhoan.DongYDieuKhoanLuc có sẵn.
    /// </summary>
    [ApiController]
    [Route("api/mobile")]
    public class TaiKhoanMoRongApiController : ControllerBase
    {
        public const string PhienBanDieuKhoan = "2026-10";
        private const string Jwt = JwtBearerDefaults.AuthenticationScheme;
        private readonly AppDbContext _db;
        private readonly IMemoryCache _cache;
        public TaiKhoanMoRongApiController(AppDbContext db, IMemoryCache cache) { _db = db; _cache = cache; }

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private Guid? PhienHienTai => Guid.TryParse(User.FindFirstValue("MaPhien"), out var g) ? g : null;
        private static IActionResult Loi(string m, int status = 400) => new ObjectResult(new { thongDiep = m }) { StatusCode = status };

        // ------------------------------------------------------------------ phiên đăng nhập theo thiết bị
        [HttpGet("tai-khoan/phien")]
        [Authorize(AuthenticationSchemes = Jwt)]
        public async Task<IActionResult> DanhSachPhien()
        {
            var tu = DateTime.Now.AddDays(-30);
            var hienTai = PhienHienTai;
            var ds = await _db.PhienDangNhaps.AsNoTracking()
                .Where(p => p.MaTK == MaTK && p.ThuHoiLuc == null && p.NgayTao >= tu)
                .OrderByDescending(p => p.NgayTao).Take(30).ToListAsync();
            return Ok(ds.Select(p => new
            {
                id = p.MaPhien, kenh = p.Kenh, thietBi = p.ThietBi, diaChiIp = p.DiaChiIP,
                ngayTao = p.NgayTao, lanCuoi = p.LanCuoi, hienTai = hienTai == p.MaPhien,
            }));
        }

        [HttpDelete("tai-khoan/phien/{id:guid}")]
        [Authorize(AuthenticationSchemes = Jwt)]
        public async Task<IActionResult> ThuHoiPhien(Guid id)
        {
            var p = await _db.PhienDangNhaps.FirstOrDefaultAsync(x => x.MaPhien == id && x.MaTK == MaTK && x.ThuHoiLuc == null);
            if (p == null) return Loi("Không tìm thấy phiên đăng nhập (có thể đã đăng xuất).", 404);
            p.ThuHoiLuc = DateTime.Now;
            await _db.SaveChangesAsync();
            PhienJwt.XoaCachePhien(_cache, id);
            return Ok(new { thongDiep = id == PhienHienTai ? "Đã đăng xuất phiên này." : "Đã đăng xuất thiết bị đó." });
        }

        [HttpPost("tai-khoan/phien/dang-xuat-khac")]
        [Authorize(AuthenticationSchemes = Jwt)]
        public async Task<IActionResult> DangXuatThietBiKhac()
        {
            var hienTai = PhienHienTai;
            var ds = await _db.PhienDangNhaps.Where(p => p.MaTK == MaTK && p.ThuHoiLuc == null && p.MaPhien != hienTai).ToListAsync();
            foreach (var ph in ds) { ph.ThuHoiLuc = DateTime.Now; PhienJwt.XoaCachePhien(_cache, ph.MaPhien); }
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = ds.Count == 0 ? "Không có thiết bị nào khác đang đăng nhập." : $"Đã đăng xuất {ds.Count} thiết bị khác." });
        }

        // ------------------------------------------------------------------ yêu cầu khóa tài khoản
        public record KhoaRequest(string? MatKhau, string? LyDo);

        /// <summary>Tự khóa tài khoản (tạm ngưng sử dụng). Khác "xóa": dữ liệu giữ nguyên, muốn mở lại phải liên hệ hỗ trợ/quản trị viên.</summary>
        [HttpPost("tai-khoan/yeu-cau-khoa")]
        [Authorize(AuthenticationSchemes = Jwt)]
        public async Task<IActionResult> YeuCauKhoa(KhoaRequest r)
        {
            var tk = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == MaTK);
            if (tk == null) return Loi("Không tìm thấy tài khoản.", 404);
            if (tk.VaiTro == "QuanTri") return Loi("Tài khoản quản trị không thể tự khóa.");
            if (!MatKhauHelper.Khop(r.MatKhau ?? "", tk.MatKhau)) return Loi("Mật khẩu xác nhận không đúng.");

            var dangXuLy = new[] { "ChoXacNhan", "DaXacNhan", "DangGiao" };
            if (tk.VaiTro == "KhachHang")
            {
                var maKh = await _db.KhachHangs.Where(k => k.MaTK == tk.MaTK).Select(k => (int?)k.MaKH).FirstOrDefaultAsync();
                if (maKh != null && await _db.DonHangs.AnyAsync(d => d.MaKH == maKh && dangXuLy.Contains(d.TrangThai)))
                    return Loi("Bạn còn đơn hàng đang xử lý, hãy đợi hoàn tất hoặc hủy đơn trước khi khóa tài khoản.");
            }

            tk.TrangThai = false;
            PhienJwt.ThuHoi(tk);
            var conMo = await _db.PhienDangNhaps.Where(x => x.MaTK == tk.MaTK && x.ThuHoiLuc == null).ToListAsync();
            foreach (var ph in conMo) ph.ThuHoiLuc = DateTime.Now;
            var lyDo = (r.LyDo ?? "").Trim();
            _db.NhatKyHeThongs.Add(new NhatKyHeThong
            {
                MucDo = "Warn", Nguon = "TaiKhoan", MaTK = tk.MaTK,
                ThongDiep = "Người dùng tự khóa tài khoản trên app",
                ChiTiet = lyDo.Length > 300 ? lyDo[..300] : lyDo,
                DiaChiIP = HttpContext.Connection.RemoteIpAddress?.ToString(),
            });
            await _db.SaveChangesAsync();
            PhienJwt.XoaCache(_cache, tk.MaTK);
            return Ok(new { thongDiep = "Đã khóa tài khoản. Bạn đã được đăng xuất khỏi mọi thiết bị. Muốn mở lại, hãy liên hệ bộ phận hỗ trợ." });
        }

        // ------------------------------------------------------------------ điều khoản & quyền riêng tư
        public record MucDieuKhoan(string TieuDe, string NoiDung);

        private static readonly MucDieuKhoan[] Muc =
        {
            new("1. Điều khoản sử dụng", "Người dùng cung cấp thông tin chính xác khi đăng ký, chịu trách nhiệm về tài khoản của mình và không sử dụng hệ thống cho mục đích gian lận. Đơn hàng đã được gian hàng xác nhận chỉ được hủy theo thỏa thuận với gian hàng. Hệ thống có quyền khóa tài khoản vi phạm."),
            new("2. Chính sách bảo mật", "Hệ thống thu thập họ tên, số điện thoại, email, địa chỉ giao hàng và lịch sử đơn hàng để xử lý đơn và hỗ trợ khách hàng. Mật khẩu được mã hóa (BCrypt). Thông tin chỉ chia sẻ với gian hàng/tài xế phụ trách đơn của bạn và không bán cho bên thứ ba."),
            new("3. Quyền của bạn", "Bạn có thể chỉnh sửa hồ sơ, xem và đăng xuất các thiết bị đang đăng nhập, yêu cầu khóa hoặc xóa tài khoản ngay trong ứng dụng (Hồ sơ → Bảo mật tài khoản)."),
            new("Lưu ý", "Nội dung mang tính minh họa cho đồ án; cần bổ sung bởi bộ phận pháp lý khi triển khai thực tế."),
        };

        /// <summary>Thông tin ứng dụng công khai (thương hiệu, liên hệ, chính sách) — quản trị sửa ở Cấu hình hệ thống.</summary>
        [HttpGet("thong-tin-ung-dung")]
        [AllowAnonymous]
        public async Task<IActionResult> ThongTinUngDung()
        {
            var nhomId = new[] { "thuong-hieu", "doanh-nghiep", "lien-he", "noi-dung" };
            var muc = ChinhSachMeta.Nhom.Where(n => nhomId.Contains(n.Id)).SelectMany(n => n.Muc).ToList();
            var khoa = muc.Select(x => x.Khoa).ToList();
            var luu = await _db.CauHinhHeThongs.AsNoTracking().Where(c => khoa.Contains(c.Khoa)).ToDictionaryAsync(c => c.Khoa, c => c.GiaTri);
            return Ok(muc.ToDictionary(x => x.Khoa, x => luu.TryGetValue(x.Khoa, out var v) && !string.IsNullOrWhiteSpace(v) ? v : x.MacDinh));
        }

        [HttpGet("dieu-khoan")]
        [AllowAnonymous]
        public IActionResult DieuKhoan() => Ok(new { phienBan = PhienBanDieuKhoan, muc = Muc });

        [HttpGet("tai-khoan/dieu-khoan")]
        [Authorize(AuthenticationSchemes = Jwt)]
        public async Task<IActionResult> TrangThaiDongY()
        {
            var luc = await _db.TaiKhoans.AsNoTracking().Where(t => t.MaTK == MaTK).Select(t => t.DongYDieuKhoanLuc).FirstOrDefaultAsync();
            return Ok(new { phienBan = PhienBanDieuKhoan, dongYLuc = luc });
        }

        [HttpPost("tai-khoan/dieu-khoan/dong-y")]
        [Authorize(AuthenticationSchemes = Jwt)]
        public async Task<IActionResult> DongY()
        {
            var tk = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == MaTK);
            if (tk == null) return Loi("Không tìm thấy tài khoản.", 404);
            tk.DongYDieuKhoanLuc = DateTime.Now;
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã ghi nhận bạn đồng ý Điều khoản sử dụng và Chính sách quyền riêng tư.", dongYLuc = tk.DongYDieuKhoanLuc });
        }
    }
}
