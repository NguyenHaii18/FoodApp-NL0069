using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// Trung tâm vận hành cho app quản trị (JWT, vai trò QuanTri): cảnh báo hệ thống, theo dõi SLA, phát hiện gian lận,
    /// báo cáo lợi nhuận, kiểm duyệt đánh giá. Chỉ đọc, trừ thao tác ẩn đánh giá (cần cấp SuperAdmin/QuanLy).
    /// </summary>
    [ApiController]
    [Route("api/admin/van-hanh")]
    public class AdminVanHanhApiController : AdminApiBaseController
    {
        private readonly AppDbContext _db;
        private readonly CauHinhService _cauHinh;
        public AdminVanHanhApiController(AppDbContext db, CauHinhService cauHinh) { _db = db; _cauHinh = cauHinh; }

        public record CanhBaoDto(string Muc, string TieuDe, string MoTa, int SoLuong);
        public record DongSlaDto(int MaDonHang, string TenQuan, int Phut, string TrangThai);
        public record CanhBaoGianLanDto(string Loai, string Muc, int? MaKH, string TenKH, int SoLan, string MoTa, int? MaDonHang);
        public record DanhGiaNghiVanDto(int MaDanhGia, int? MaKH, string TenKH, string TenQuan, int SoSao, string NoiDung, string LyDo, DateTime Ngay);
        public record AnDanhGiaRequest(string? LyDo);

        // ============ 1. Cảnh báo hệ thống ============
        [HttpGet("canh-bao")]
        public async Task<IActionResult> CanhBao()
        {
            var now = DateTime.Now;
            var ds = new List<CanhBaoDto>();

            // Thanh toán online treo/thất bại quá 30 phút (đơn trong 24 giờ qua)
            var treo = await _db.ThanhToans.CountAsync(t => t.HinhThuc != "TienMat" && (t.TrangThai == "ChoThanhToan" || t.TrangThai == "ThatBai")
                && _db.DonHangs.Any(d => d.MaDonHang == t.MaDonHang && d.NgayDat < now.AddMinutes(-30) && d.NgayDat >= now.AddDays(-1)));
            if (treo > 0)
                ds.Add(new(treo >= 5 ? "Error" : "Warn", "Thanh toán online chưa hoàn tất", $"{treo} giao dịch chờ/thất bại quá 30 phút trong 24 giờ qua. Kiểm tra cổng thanh toán và callback.", treo));

            // Tỷ lệ hủy tăng bất thường: 24 giờ qua so với 7 ngày trước đó
            var tu24 = now.AddHours(-24); var tu8d = now.AddDays(-8);
            var tong24 = await _db.DonHangs.CountAsync(d => d.NgayDat >= tu24);
            var huy24 = await _db.DonHangs.CountAsync(d => d.NgayDat >= tu24 && d.TrangThai == "DaHuy");
            var tongCu = await _db.DonHangs.CountAsync(d => d.NgayDat >= tu8d && d.NgayDat < tu24);
            var huyCu = await _db.DonHangs.CountAsync(d => d.NgayDat >= tu8d && d.NgayDat < tu24 && d.TrangThai == "DaHuy");
            if (tong24 >= 10)
            {
                var t24 = huy24 / (double)tong24;
                var tCu = tongCu > 0 ? huyCu / (double)tongCu : 0;
                if (t24 >= 0.15 && t24 >= tCu * 1.5)
                    ds.Add(new(t24 >= 0.3 ? "Error" : "Warn", "Tỷ lệ đơn bị hủy tăng bất thường",
                        $"24 giờ qua: {huy24}/{tong24} đơn bị hủy ({t24:P0}); 7 ngày trước đó trung bình {tCu:P0}.", huy24));
            }

            // Đơn kẹt
            var choXn = await _db.DonHangs.CountAsync(d => d.TrangThai == "ChoXacNhan" && d.NgayDat < now.AddMinutes(-15));
            if (choXn > 0) ds.Add(new("Warn", "Đơn chờ quán xác nhận quá 15 phút", $"{choXn} đơn chưa được quán xác nhận.", choXn));
            var khongTx = await _db.DonHangs.CountAsync(d => d.TrangThai == "DaXacNhan" && d.MaTaiXe == null && d.SanSangGiao
                && d.ThoiGianSanSang != null && d.ThoiGianSanSang < now.AddMinutes(-GiaoHangXuLy.PhutPhanHoiTaiXe * 2));
            if (khongTx > 0) ds.Add(new("Error", "Đơn sẵn sàng giao nhưng chưa có tài xế", $"{khongTx} đơn chờ tài xế quá {GiaoHangXuLy.PhutPhanHoiTaiXe * 2} phút. Cần điều phối thủ công.", khongTx));

            // Hoàn tiền chờ duyệt lâu
            var hoanCho = await _db.YeuCauHoanTiens.CountAsync(r => r.TrangThai == "ChoDuyet" && r.NgayTao < now.AddDays(-1));
            if (hoanCho > 0) ds.Add(new("Warn", "Yêu cầu hoàn tiền chờ duyệt quá 24 giờ", $"{hoanCho} yêu cầu hoàn tiền cần xử lý.", hoanCho));

            // Lỗi hệ thống 1 giờ qua (nhật ký mức Error)
            var loi = await _db.NhatKyHeThongs.CountAsync(l => l.MucDo == "Error" && l.ThoiGian >= now.AddHours(-1));
            if (loi > 0) ds.Add(new(loi >= 10 ? "Error" : "Warn", "Lỗi hệ thống trong 1 giờ qua", $"{loi} bản ghi nhật ký mức Error. Xem Nhật ký hệ thống để biết chi tiết.", loi));

            var thuTu = new Dictionary<string, int> { ["Error"] = 0, ["Warn"] = 1, ["Info"] = 2 };
            return Ok(new { capNhatLuc = now, soCanhBao = ds.Count, canhBao = ds.OrderBy(x => thuTu[x.Muc]).ThenByDescending(x => x.SoLuong).ToList() });
        }

        // ============ 2. Theo dõi SLA ============
        [HttpGet("sla")]
        public async Task<IActionResult> Sla()
        {
            var now = DateTime.Now;
            var nguongXn = (int)await _cauHinh.LaySoAsync("Don.SlaXacNhanPhut", 10);
            var nguongTx = (int)await _cauHinh.LaySoAsync("Don.SlaTimTaiXePhut", GiaoHangXuLy.PhutPhanHoiTaiXe * 2);
            var nguongGiao = (int)await _cauHinh.LaySoAsync("Don.SlaGiaoPhut", 60);

            var chamXn = await _db.DonHangs.AsNoTracking()
                .Where(d => d.TrangThai == "ChoXacNhan" && d.NgayDat < now.AddMinutes(-nguongXn))
                .OrderBy(d => d.NgayDat).Take(30)
                .Select(d => new { d.MaDonHang, Quan = d.GianHang!.TenCuaHang, d.NgayDat }).ToListAsync();

            var chuaTx = await _db.DonHangs.AsNoTracking()
                .Where(d => d.TrangThai == "DaXacNhan" && d.MaTaiXe == null && d.SanSangGiao && d.ThoiGianSanSang != null && d.ThoiGianSanSang < now.AddMinutes(-nguongTx))
                .OrderBy(d => d.ThoiGianSanSang).Take(30)
                .Select(d => new { d.MaDonHang, Quan = d.GianHang!.TenCuaHang, Moc = d.ThoiGianSanSang }).ToListAsync();

            var giaoTre = await _db.DonHangs.AsNoTracking()
                .Where(d => (d.TrangThai == "DangGiao" || (d.TrangThai == "DaXacNhan" && d.MaTaiXe != null)) && d.NgayDat < now.AddMinutes(-nguongGiao))
                .OrderBy(d => d.NgayDat).Take(30)
                .Select(d => new { d.MaDonHang, Quan = d.GianHang!.TenCuaHang, d.NgayDat, d.TrangThai }).ToListAsync();

            // Tỷ lệ giao đúng hạn 7 ngày qua (đơn đã giao có thời điểm giao)
            var tu7 = now.AddDays(-7);
            var daGiao = await _db.GiaoHangs.AsNoTracking()
                .Where(g => g.TrangThai == "GiaoThanhCong" && g.ThoiGianGiao != null && g.ThoiGianGiao >= tu7)
                .Select(g => new { g.ThoiGianGiao, NgayDat = g.DonHang!.NgayDat }).ToListAsync();
            var dungHan = daGiao.Count(x => (x.ThoiGianGiao!.Value - x.NgayDat).TotalMinutes <= nguongGiao);
            double? tyLe = daGiao.Count > 0 ? dungHan / (double)daGiao.Count : null;
            double? tb = daGiao.Count > 0 ? Math.Round(daGiao.Average(x => (x.ThoiGianGiao!.Value - x.NgayDat).TotalMinutes), 1) : null;

            return Ok(new
            {
                capNhatLuc = now,
                nguong = new { xacNhanPhut = nguongXn, timTaiXePhut = nguongTx, giaoPhut = nguongGiao },
                tyLeDungHan7Ngay = tyLe, soDonDaGiao7Ngay = daGiao.Count, thoiGianGiaoTrungBinhPhut = tb,
                quanChamXacNhan = chamXn.Select(x => new DongSlaDto(x.MaDonHang, x.Quan, (int)(now - x.NgayDat).TotalMinutes, "ChoXacNhan")).ToList(),
                chuaCoTaiXe = chuaTx.Select(x => new DongSlaDto(x.MaDonHang, x.Quan, (int)(now - x.Moc!.Value).TotalMinutes, "ChoTaiXe")).ToList(),
                giaoTre = giaoTre.Select(x => new DongSlaDto(x.MaDonHang, x.Quan, (int)(now - x.NgayDat).TotalMinutes, x.TrangThai)).ToList(),
            });
        }

        // ============ 3. Phát hiện gian lận ============
        [HttpGet("gian-lan")]
        public async Task<IActionResult> GianLan()
        {
            var now = DateTime.Now; var tu30 = now.AddDays(-30);
            var kq = new List<CanhBaoGianLanDto>();

            // (a) Khách hủy đơn nhiều
            var huy = await _db.DonHangs.AsNoTracking().Where(d => d.NgayDat >= tu30 && d.TrangThai == "DaHuy")
                .GroupBy(d => d.MaKH).Select(g => new { MaKH = g.Key, N = g.Count() }).Where(x => x.N >= 4).ToListAsync();
            // (b) Lạm dụng voucher: cùng khách dùng cùng chương trình >= 3 lần / 30 ngày
            var vc = await _db.KhuyenMaiKhachDungs.AsNoTracking().Where(k => k.NgaySuDung >= tu30)
                .GroupBy(k => new { k.MaKH, k.MaKhuyenMai }).Select(g => new { g.Key.MaKH, g.Key.MaKhuyenMai, N = g.Count() }).Where(x => x.N >= 3).ToListAsync();
            // (c) Hoàn tiền đáng ngờ: >= 3 yêu cầu / 30 ngày
            var hoan = await _db.YeuCauHoanTiens.AsNoTracking().Where(r => r.NgayTao >= tu30 && r.MaKH != null)
                .GroupBy(r => r.MaKH!.Value).Select(g => new { MaKH = g.Key, N = g.Count(), Tong = g.Sum(r => r.SoTien) }).Where(x => x.N >= 3).ToListAsync();
            // (d) Nhập sai mã nhận hàng nhiều lần
            var saiMa = await _db.DonHangs.AsNoTracking().Where(d => d.NgayDat >= tu30 && d.SoLanSaiMa >= 3)
                .Select(d => new { d.MaDonHang, d.MaKH, d.SoLanSaiMa }).Take(20).ToListAsync();
            // (e) Đơn giá trị bất thường: > 3 lần trung bình đơn của chính khách (>= 3 đơn trước đó) và > 300.000đ, trong 7 ngày gần nhất
            var gan = await _db.DonHangs.AsNoTracking().Where(d => d.NgayDat >= now.AddDays(-90) && d.TrangThai != "DaHuy")
                .Select(d => new { d.MaDonHang, d.MaKH, d.TongTien, d.NgayDat }).Take(5000).ToListAsync();
            var batThuong = new List<(int Ma, int KH, decimal Tien, decimal Tb)>();
            foreach (var g in gan.GroupBy(x => x.MaKH))
            {
                var truoc = g.OrderBy(x => x.NgayDat).ToList();
                foreach (var d in truoc.Where(x => x.NgayDat >= now.AddDays(-7)))
                {
                    var cu = truoc.Where(x => x.NgayDat < d.NgayDat).ToList();
                    if (cu.Count < 3) continue;
                    var tb = cu.Average(x => x.TongTien);
                    if (d.TongTien > 300000 && d.TongTien > tb * 3) batThuong.Add((d.MaDonHang, d.MaKH, d.TongTien, tb));
                }
            }

            var ids = huy.Select(x => x.MaKH).Concat(vc.Select(x => x.MaKH)).Concat(hoan.Select(x => x.MaKH))
                .Concat(saiMa.Select(x => x.MaKH)).Concat(batThuong.Select(x => x.KH)).Distinct().ToList();
            var ten = await _db.KhachHangs.AsNoTracking().Where(k => ids.Contains(k.MaKH)).ToDictionaryAsync(k => k.MaKH, k => k.HoTen);
            string Ten(int ma) => ten.TryGetValue(ma, out var t) ? t : $"Khách #{ma}";
            var kmIds = vc.Select(v => v.MaKhuyenMai).Distinct().ToList();
            var tenKm = await _db.KhuyenMais.AsNoTracking().Where(k => kmIds.Contains(k.MaKhuyenMai))
                .ToDictionaryAsync(k => k.MaKhuyenMai, k => k.TenChuongTrinh ?? ("#" + k.MaKhuyenMai));

            kq.AddRange(huy.Select(x => new CanhBaoGianLanDto("HuyNhieu", x.N >= 8 ? "Cao" : "Trung bình", x.MaKH, Ten(x.MaKH), x.N, $"Hủy {x.N} đơn trong 30 ngày.", null)));
            kq.AddRange(vc.Select(x => new CanhBaoGianLanDto("LamDungVoucher", x.N >= 6 ? "Cao" : "Trung bình", x.MaKH, Ten(x.MaKH), x.N,
                $"Dùng chương trình “{(tenKm.TryGetValue(x.MaKhuyenMai, out var tk) ? tk : "#" + x.MaKhuyenMai)}” {x.N} lần trong 30 ngày.", null)));
            kq.AddRange(hoan.Select(x => new CanhBaoGianLanDto("HoanTienDangNgo", "Cao", x.MaKH, Ten(x.MaKH), x.N, $"{x.N} yêu cầu hoàn tiền (tổng {x.Tong:N0}đ) trong 30 ngày.", null)));
            kq.AddRange(saiMa.Select(x => new CanhBaoGianLanDto("SaiMaNhanHang", "Trung bình", x.MaKH, Ten(x.MaKH), x.SoLanSaiMa, $"Đơn #{x.MaDonHang}: nhập sai mã nhận hàng {x.SoLanSaiMa} lần.", x.MaDonHang)));
            kq.AddRange(batThuong.Select(x => new CanhBaoGianLanDto("DonBatThuong", "Trung bình", x.KH, Ten(x.KH), 1, $"Đơn #{x.Ma} giá trị {x.Tien:N0}đ, gấp {x.Tien / x.Tb:N1} lần mức trung bình {x.Tb:N0}đ của khách.", x.Ma)));

            var thuTu = new Dictionary<string, int> { ["Cao"] = 0, ["Trung bình"] = 1 };
            return Ok(new { capNhatLuc = now, kyXet = "30 ngày gần nhất", tong = kq.Count, canhBao = kq.OrderBy(x => thuTu[x.Muc]).ThenByDescending(x => x.SoLan).Take(100).ToList() });
        }

        // ============ 4. Báo cáo lợi nhuận ============
        [HttpGet("loi-nhuan")]
        public async Task<IActionResult> LoiNhuan([FromQuery] DateTime? tuNgay, [FromQuery] DateTime? denNgay)
        {
            var den = (denNgay ?? DateTime.Today).Date.AddDays(1);
            var tu = (tuNgay ?? den.AddDays(-30)).Date;
            if (tu >= den) return BadRequest(new { message = "Khoảng ngày không hợp lệ." });

            var don = await _db.DonHangs.AsNoTracking().Where(d => d.TrangThai == "DaGiao" && d.NgayDat >= tu && d.NgayDat < den)
                .Select(d => new { d.TongTien, d.PhiGiaoHang, d.TienGiam, Ty = d.GianHang != null ? d.GianHang.TyLeChietKhau : 0m }).ToListAsync();

            var doanhThu = don.Sum(x => x.TongTien);
            var phiGiao = don.Sum(x => x.PhiGiaoHang);
            var tienHang = doanhThu - phiGiao;
            var phiNen = Math.Round(don.Sum(x => (x.TongTien - x.PhiGiaoHang) * x.Ty), 0);
            var uuDai = don.Sum(x => x.TienGiam);
            var hoan = await _db.YeuCauHoanTiens.AsNoTracking()
                .Where(r => r.TrangThai == "DaDuyet" && r.NgayXuLy != null && r.NgayXuLy >= tu && r.NgayXuLy < den).SumAsync(r => (decimal?)r.SoTien) ?? 0;
            var loiNhuan = phiNen - uuDai - hoan;

            return Ok(new
            {
                tuNgay = tu, denNgay = den.AddDays(-1), soDonDaGiao = don.Count,
                doanhThu, tienHang, phiGiaoHang = phiGiao, phiNenTang = phiNen, chiPhiUuDai = uuDai, soTienHoan = hoan,
                loiNhuanUocTinh = loiNhuan,
                ghiChu = "Lợi nhuận ước tính = phí nền tảng − chi phí ưu đãi − tiền hoàn. Chi phí ưu đãi tính toàn bộ giảm giá của đơn đã giao; phí giao hàng là thu nhập của tài xế nên không tính vào lợi nhuận nền tảng."
            });
        }

        // ============ 5. Kiểm duyệt đánh giá ============
        [HttpGet("danh-gia-nghi-van")]
        public async Task<IActionResult> DanhGiaNghiVan()
        {
            var now = DateTime.Now; var tu30 = now.AddDays(-30);
            var dg = await _db.DanhGias.AsNoTracking().Where(d => !d.DaAn && d.NgayDanhGia >= tu30)
                .Select(d => new { d.MaDanhGia, d.MaKH, d.MaGianHang, d.SoSao, d.NoiDung, d.NgayDanhGia }).Take(3000).ToListAsync();
            var chon = new Dictionary<int, string>();

            foreach (var g in dg.Where(x => !string.IsNullOrWhiteSpace(x.NoiDung)).GroupBy(x => (x.MaKH, Nd: x.NoiDung!.Trim().ToLowerInvariant())).Where(g => g.Count() >= 2))
                foreach (var x in g.OrderBy(x => x.NgayDanhGia).Skip(1)) chon[x.MaDanhGia] = "Nội dung trùng lặp";
            foreach (var g in dg.Where(x => x.NgayDanhGia >= now.AddDays(-1)).GroupBy(x => x.MaKH).Where(g => g.Count() >= 3))
                foreach (var x in g) chon.TryAdd(x.MaDanhGia, "Đăng dồn dập (≥ 3 đánh giá/24 giờ)");
            var baoCao = await _db.BaoCaoDanhGias.AsNoTracking().Where(b => b.TrangThai == "ChoXuLy").Select(b => new { b.MaDanhGia, b.LyDo }).ToListAsync();
            foreach (var b in baoCao) chon.TryAdd(b.MaDanhGia, "Bị báo cáo: " + b.LyDo);

            var ma = chon.Keys.ToList();
            var ds = await _db.DanhGias.AsNoTracking().Where(d => ma.Contains(d.MaDanhGia) && !d.DaAn)
                .Select(d => new { d.MaDanhGia, d.MaKH, d.SoSao, d.NoiDung, d.NgayDanhGia, Quan = d.MaGianHang }).OrderByDescending(d => d.NgayDanhGia).Take(100).ToListAsync();
            var kh = ds.Select(d => d.MaKH).Distinct().ToList();
            var tenKh = await _db.KhachHangs.AsNoTracking().Where(k => kh.Contains(k.MaKH)).ToDictionaryAsync(k => k.MaKH, k => k.HoTen);
            var qIds = ds.Select(d => d.Quan).Distinct().ToList();
            var tenQuan = await _db.GianHangs.AsNoTracking().Where(g => qIds.Contains(g.MaGianHang)).ToDictionaryAsync(g => g.MaGianHang, g => g.TenCuaHang);

            return Ok(new
            {
                capNhatLuc = now, tong = ds.Count,
                danhGia = ds.Select(d => new DanhGiaNghiVanDto(d.MaDanhGia, d.MaKH, tenKh.TryGetValue(d.MaKH, out var t) ? t : $"Khách #{d.MaKH}",
                    tenQuan.TryGetValue(d.Quan, out var q) ? q : "", d.SoSao, d.NoiDung ?? "", chon[d.MaDanhGia], d.NgayDanhGia)).ToList()
            });
        }

        /// <summary>Ẩn đánh giá vi phạm. Chỉ SuperAdmin / QuanLy.</summary>
        [HttpPost("danh-gia/{id:int}/an")]
        public async Task<IActionResult> AnDanhGia(int id, [FromBody] AnDanhGiaRequest? body)
        {
            var cap = await _db.QuanTris.Where(q => q.MaTK == CurrentMaTK).Select(q => q.CapQuyenHan).FirstOrDefaultAsync() ?? "";
            if (cap != "SuperAdmin" && cap != "QuanLy") return StatusCode(403, new { message = "Chỉ quản lý trở lên mới được ẩn đánh giá." });
            var d = await _db.DanhGias.FirstOrDefaultAsync(x => x.MaDanhGia == id);
            if (d == null) return NotFound(new { message = "Không tìm thấy đánh giá." });
            d.DaAn = true;
            d.LyDoAn = string.IsNullOrWhiteSpace(body?.LyDo) ? "Vi phạm quy định nội dung" : body!.LyDo!.Trim();
            foreach (var b in await _db.BaoCaoDanhGias.Where(x => x.MaDanhGia == id && x.TrangThai == "ChoXuLy").ToListAsync())
            { b.TrangThai = "DaXuLy"; b.KetQua = "Đã ẩn đánh giá"; b.NgayXuLy = DateTime.Now; }
            await _db.SaveChangesAsync();
            return Ok(new { message = "Đã ẩn đánh giá." });
        }
    }
}
