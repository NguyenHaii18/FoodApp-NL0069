using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>v67 — Quản trị nội dung & dashboard cho app: sửa banner, dòng thông báo trang chủ, dashboard máy chủ.
    /// Sửa nội dung cần quyền "ThongBao"; dashboard cho mọi quản trị viên (chỉ đọc).</summary>
    [ApiController]
    [Route("api/mobile/admin")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
    public class AdminNoiDungMoRongApiController : ControllerBase
    {
        public const string KhoaThongBao = "TrangChu.ThongBao";
        public const string KhoaThongBaoLienKet = "TrangChu.ThongBaoLienKet";

        private readonly AppDbContext _db;
        private readonly CauHinhService _cauHinh;
        public AdminNoiDungMoRongApiController(AppDbContext db, CauHinhService cauHinh) { _db = db; _cauHinh = cauHinh; }

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static ObjectResult Loi(string m, int status = 400) => new(new { thongDiep = m }) { StatusCode = status };
        private async Task<IActionResult?> ChanAsync() =>
            await QuyenAdmin.CoAsync(_db, MaTK, "ThongBao") ? null : Loi("Bạn không có quyền quản lý nội dung (ThongBao).", 403);

        // ------------------------------------------------------------------ SỬA BANNER
        public record BannerSuaReq(string? TieuDe, string? LienKet, int ThuTu, DateTime? NgayBatDau, DateTime? NgayKetThuc, string? HinhAnh);

        [HttpPut("banner/{id:int}")]
        public async Task<IActionResult> SuaBanner(int id, BannerSuaReq r)
        {
            var chan = await ChanAsync(); if (chan != null) return chan;
            var b = await _db.Banners.FindAsync(id);
            if (b == null) return Loi("Không tìm thấy banner.", 404);
            var tieuDe = (r.TieuDe ?? "").Trim();
            var lienKet = string.IsNullOrWhiteSpace(r.LienKet) ? null : r.LienKet.Trim();
            if (tieuDe.Length < 3 || tieuDe.Length > 150) return Loi("Tiêu đề từ 3 đến 150 ký tự.");
            if (lienKet != null && (lienKet.Length > 300 || !(lienKet.StartsWith("/") || lienKet.StartsWith("http://") || lienKet.StartsWith("https://"))))
                return Loi("Liên kết phải bắt đầu bằng / hoặc http(s):// và tối đa 300 ký tự.");
            if (r.NgayBatDau != null && r.NgayKetThuc != null && r.NgayKetThuc < r.NgayBatDau) return Loi("Ngày kết thúc phải sau ngày bắt đầu.");
            if (r.ThuTu < 0 || r.ThuTu > 9999) return Loi("Thứ tự từ 0 đến 9999.");
            b.TieuDe = tieuDe; b.LienKet = lienKet; b.ThuTu = r.ThuTu; b.NgayBatDau = r.NgayBatDau; b.NgayKetThuc = r.NgayKetThuc;
            if (!string.IsNullOrWhiteSpace(r.HinhAnh)) b.HinhAnh = r.HinhAnh.Trim();
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã cập nhật banner." });
        }

        // ------------------------------------------------------------------ DÒNG THÔNG BÁO TRANG CHỦ
        public record ThongBaoTrangChuReq(string? NoiDung, string? LienKet);

        [HttpGet("trang-chu/thong-bao")]
        public async Task<IActionResult> XemThongBao() => Ok(new
        {
            noiDung = await _cauHinh.LayChuoiAsync(KhoaThongBao, "") ?? "",
            lienKet = await _cauHinh.LayChuoiAsync(KhoaThongBaoLienKet, "") ?? "",
        });

        /// <summary>Nội dung rỗng = tắt dòng thông báo.</summary>
        [HttpPut("trang-chu/thong-bao")]
        public async Task<IActionResult> DatThongBao(ThongBaoTrangChuReq r)
        {
            var chan = await ChanAsync(); if (chan != null) return chan;
            var nd = (r.NoiDung ?? "").Trim();
            var lk = (r.LienKet ?? "").Trim();
            if (nd.Length > 200) return Loi("Nội dung tối đa 200 ký tự.");
            if (lk.Length > 0 && (lk.Length > 300 || !(lk.StartsWith("/") || lk.StartsWith("http://") || lk.StartsWith("https://"))))
                return Loi("Liên kết phải bắt đầu bằng / hoặc http(s):// và tối đa 300 ký tự.");
            await _cauHinh.DatAsync(KhoaThongBao, nd, MaTK);
            await _cauHinh.DatAsync(KhoaThongBaoLienKet, nd.Length == 0 ? "" : lk, MaTK);
            return Ok(new { thongDiep = nd.Length == 0 ? "Đã tắt dòng thông báo trang chủ." : "Đã lưu dòng thông báo trang chủ." });
        }

        // ------------------------------------------------------------------ DASHBOARD
        [HttpGet("dashboard")]
        public async Task<IActionResult> Dashboard()
        {
            var homNay = DateTime.Today; var homQua = homNay.AddDays(-1);
            var tuan = homNay.AddDays(-6); var tuanTruoc = tuan.AddDays(-7); var tu14 = homNay.AddDays(-13);

            var don14 = await _db.DonHangs.AsNoTracking().Where(d => d.NgayDat >= (tu14 < tuanTruoc ? tu14 : tuanTruoc))
                .Select(d => new { d.NgayDat, d.TrangThai, d.TongTien }).ToListAsync();
            decimal DoanhThu(DateTime tuNgay, DateTime denNgay) => don14.Where(d => d.TrangThai == "DaGiao" && d.NgayDat >= tuNgay && d.NgayDat < denNgay).Sum(d => d.TongTien);
            var ngayMai = homNay.AddDays(1);

            var xuHuong = Enumerable.Range(0, 14).Select(i => tu14.AddDays(i)).Select(n => new
            {
                ngay = n.ToString("dd/MM"),
                soDon = don14.Count(d => d.NgayDat >= n && d.NgayDat < n.AddDays(1)),
                doanhThu = DoanhThu(n, n.AddDays(1)),
            }).ToList();

            return Ok(new
            {
                capNhatLuc = DateTime.Now,
                nguoiDung = new
                {
                    khachHang = await _db.KhachHangs.CountAsync(),
                    khachMoiHomNay = await _db.TaiKhoans.CountAsync(t => t.VaiTro == "KhachHang" && t.NgayTao >= homNay),
                    gianHangDaDuyet = await _db.GianHangs.CountAsync(g => g.TrangThaiDuyet == "DaDuyet"),
                    gianHangDangMo = await _db.GianHangs.CountAsync(g => g.TrangThaiDuyet == "DaDuyet" && g.TrangThaiKinhDoanh == "DangMo"),
                    taiXeDaDuyet = await _db.TaiXes.CountAsync(t => t.TrangThaiDuyet == "DaDuyet"),
                    taiXeSanSang = await _db.TaiXes.CountAsync(t => t.TrangThaiDuyet == "DaDuyet" && t.TrangThai == "SanSang"),
                    taiXeDangGiao = await _db.TaiXes.CountAsync(t => t.TrangThaiDuyet == "DaDuyet" && t.TrangThai == "DangGiao"),
                },
                don = new
                {
                    homNay = don14.Count(d => d.NgayDat >= homNay),
                    homQua = don14.Count(d => d.NgayDat >= homQua && d.NgayDat < homNay),
                    hoanThanhHomNay = don14.Count(d => d.NgayDat >= homNay && d.TrangThai == "DaGiao"),
                    huyHomNay = don14.Count(d => d.NgayDat >= homNay && d.TrangThai == "DaHuy"),
                    dangXuLy = await _db.DonHangs.CountAsync(d => d.TrangThai != "DaGiao" && d.TrangThai != "DaHuy"),
                    chuaCoTaiXe = await _db.DonHangs.CountAsync(d => d.TrangThai == "DaXacNhan" && d.MaTaiXe == null),
                },
                doanhThu = new
                {
                    homNay = DoanhThu(homNay, ngayMai), homQua = DoanhThu(homQua, homNay),
                    tuan = DoanhThu(tuan, ngayMai), tuanTruoc = DoanhThu(tuanTruoc, tuan),
                    tong = await _db.DonHangs.Where(d => d.TrangThai == "DaGiao").SumAsync(d => (decimal?)d.TongTien) ?? 0m,
                },
                canXuLy = new
                {
                    khieuNai = await _db.PhanHois.CountAsync(p => p.TrangThai == "ChuaXuLy"),
                    hoanTien = await _db.YeuCauHoanTiens.CountAsync(y => y.TrangThai == "ChoDuyet"),
                    gianHangChoDuyet = await _db.GianHangs.CountAsync(g => g.TrangThaiDuyet == "ChoDuyet"),
                    taiXeChoDuyet = await _db.TaiXes.CountAsync(t => t.TrangThaiDuyet == "ChoDuyet"),
                    baoCaoDanhGia = await _db.BaoCaoDanhGias.CountAsync(b => b.TrangThai == "ChoXuLy"),
                },
                xuHuong,
            });
        }
    }

    /// <summary>Công khai: dòng thông báo trang chủ khách (rỗng = không hiển thị).</summary>
    [ApiController]
    [Route("api/mobile/trang-chu")]
    public class TrangChuCongKhaiApiController : ControllerBase
    {
        private readonly CauHinhService _cauHinh;
        public TrangChuCongKhaiApiController(CauHinhService cauHinh) { _cauHinh = cauHinh; }

        [HttpGet("thong-bao")]
        [AllowAnonymous]
        public async Task<IActionResult> ThongBao() => Ok(new
        {
            noiDung = await _cauHinh.LayChuoiAsync(AdminNoiDungMoRongApiController.KhoaThongBao, "") ?? "",
            lienKet = await _cauHinh.LayChuoiAsync(AdminNoiDungMoRongApiController.KhoaThongBaoLienKet, "") ?? "",
        });
    }
}
