using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Dtos;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Controllers.Api
{
    [ApiController]
    [Route("api/driver")]
    public class DriverController : DriverApiBaseController
    {
        private readonly AppDbContext _db;

        public DriverController(AppDbContext db)
        {
            _db = db;
        }

        private async Task<int> GetMaTaiXeAsync() =>
            (await _db.TaiXes.FirstAsync(t => t.MaTK == CurrentMaTK)).MaTaiXe;

        private static DonHangDto MapDonHang(DonHang d) => new(
            d.MaDonHang, d.TrangThai, d.TongTien, d.NgayDat, d.DiaChiGiaoHang, d.GhiChu,
            d.GianHang!.TenCuaHang, d.GianHang.DiaChi,
            d.ChiTiets.Select(c => new ChiTietDonHangDto(c.MonAn!.TenMon, c.SoLuong, c.DonGia, c.ThanhTien)).ToList(),
            FoodServiceApp.Web.Services.PhiGiaoService.TienTaiXe(d.PhiGiaoHang, d.TyLeTaiXe));   // v83: phần phí giao tài xế nhận

        [HttpGet("home")]
        [HttpGet("~/api/mobile/driver/home")]
        [HttpGet("~/api/mobile/tai-xe/tong-quan")]
        public async Task<IActionResult> Home()
        {
            var maTaiXe = await GetMaTaiXeAsync();
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == maTaiXe);
            var homNay = DateTime.Today;

            var donDangGiao = await _db.DonHangs
                .Include(d => d.GianHang)
                .Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .FirstOrDefaultAsync(d => d.MaTaiXe == maTaiXe && d.TrangThai == "DangGiao");

            var thuNhapHomNay = await _db.GiaoHangs
                .Include(g => g.DonHang)
                .Where(g => g.MaTaiXe == maTaiXe && g.TrangThai == "GiaoThanhCong" && g.ThoiGianGiao >= homNay)
                .SumAsync(g => Math.Round(g.DonHang!.PhiGiaoHang * (g.DonHang.TyLeTaiXe ?? 1m), 0));   // v83: tài xế nhận theo tỉ lệ chia

            return Ok(new DriverHomeDto(
                taiXe.HoTen, taiXe.TrangThai,
                await _db.GiaoHangs.CountAsync(g => g.MaTaiXe == maTaiXe && g.TrangThai == "GiaoThanhCong" && g.ThoiGianGiao >= homNay),
                thuNhapHomNay,
                donDangGiao == null ? null : MapDonHang(donDangGiao),
                await FoodServiceApp.Web.Services.GiaoHangXuLy.DonChoNhan(_db, maTaiXe).CountAsync(),
                await _db.DonHangs.CountAsync(d => d.MaTaiXe == maTaiXe && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao"))
            ));
        }

        [HttpPost("toggle-san-sang")]
        [HttpPost("~/api/mobile/driver/toggle-san-sang")]
        [HttpPost("~/api/mobile/tai-xe/bat-tat-san-sang")]
        public async Task<IActionResult> ToggleSanSang()
        {
            var maTaiXe = await GetMaTaiXeAsync();
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == maTaiXe);
            if (taiXe.TrangThaiDuyet != "DaDuyet")
                return BadRequest(new { message = "Hồ sơ tài xế chưa được duyệt, chưa thể bật trạng thái nhận đơn." });
            if (taiXe.TrangThai == "DangGiao")
                return BadRequest(new { message = "Đang trong chuyến giao, không thể đổi trạng thái." });

            taiXe.TrangThai = taiXe.TrangThai == "NgoaiTuyen" ? "SanSang" : "NgoaiTuyen";   // Online/Offline
            await _db.SaveChangesAsync();
            return Ok(new { taiXe.TrangThai });
        }

        /// <summary>Bật/tắt "sẵn sàng nhận đơn" khi đang online: SanSang &lt;-&gt; TamNghi.</summary>
        [HttpPost("toggle-nhan-don")]
        [HttpPost("~/api/mobile/driver/toggle-nhan-don")]
        [HttpPost("~/api/mobile/tai-xe/bat-tat-nhan-don")]
        public async Task<IActionResult> ToggleNhanDon()
        {
            var maTaiXe = await GetMaTaiXeAsync();
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == maTaiXe);
            if (taiXe.TrangThaiDuyet != "DaDuyet") return BadRequest(new { message = "Hồ sơ tài xế chưa được duyệt, chưa thể bật trạng thái nhận đơn." });
            if (taiXe.TrangThai == "DangGiao") return BadRequest(new { message = "Đang trong chuyến giao, không thể đổi trạng thái." });
            if (taiXe.TrangThai == "NgoaiTuyen") return BadRequest(new { message = "Hãy bật Online trước khi bật nhận đơn." });
            taiXe.TrangThai = taiXe.TrangThai == "SanSang" ? "TamNghi" : "SanSang";
            await _db.SaveChangesAsync();
            return Ok(new { taiXe.TrangThai });
        }

        [HttpGet("available-orders")]
        [HttpGet("~/api/mobile/driver/available-orders")]
        public async Task<IActionResult> AvailableOrders()
        {
            var maTx = await GetMaTaiXeAsync();
            if (!await _db.TaiXes.AnyAsync(t => t.MaTaiXe == maTx && t.TrangThaiDuyet == "DaDuyet"))
                return StatusCode(403, new { message = "Hồ sơ tài xế chưa được duyệt, chưa thể xem và nhận đơn." });
            await FoodServiceApp.Web.Services.GiaoHangXuLy.XuLyQuaHanNhanDonAsync(_db, await FoodServiceApp.Web.Services.GiaoHangXuLy.LayPhutPhanHoiAsync(_db));
            var donHangs = await FoodServiceApp.Web.Services.GiaoHangXuLy.DonChoNhan(_db, maTx)
                .Include(d => d.GianHang)
                .Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .OrderBy(d => d.NgayDat)
                .ToListAsync();

            return Ok(donHangs.Select(MapDonHang));
        }

        /// <summary>Đơn của tôi theo nhóm: nhan | dang-giao | hoan-thanh | that-bai.</summary>
        [HttpGet("orders")]
        [HttpGet("~/api/mobile/driver/orders")]
        public async Task<IActionResult> MyOrders([FromQuery] string? tab)
        {
            var maTaiXe = await GetMaTaiXeAsync();
            return Ok(await FoodServiceApp.Web.Services.DriverDonXuLy.DanhSachAsync(_db, maTaiXe, tab));
        }

        [HttpGet("orders/{id:int}")]
        [HttpGet("~/api/mobile/driver/orders/{id:int}")]
        public async Task<IActionResult> OrderDetail(int id)
        {
            var maTaiXe = await GetMaTaiXeAsync();
            var dto = await FoodServiceApp.Web.Services.DriverDonXuLy.ChiTietAsync(_db, maTaiXe, id);
            return dto == null ? NotFound(new { message = "Không tìm thấy đơn trong chuyến của bạn." }) : Ok(dto);
        }

        [HttpPost("orders/{id:int}/reject")]
        [HttpPost("~/api/mobile/driver/orders/{id:int}/reject")]
        public async Task<IActionResult> RejectOrder(int id, [FromBody] RejectOrderRequest? body)
        {
            var maTaiXe = await GetMaTaiXeAsync();
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == maTaiXe);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.TuChoiDonAsync(_db, taiXe, id, body?.LyDo);
            return kq.Ok ? Ok(new { message = kq.ThongDiep }) : BadRequest(new { message = kq.ThongDiep });
        }

        public record RejectOrderRequest(string? LyDo);

        [HttpPost("orders/{id:int}/accept")]
        [HttpPost("~/api/mobile/driver/orders/{id:int}/accept")]
        public async Task<IActionResult> AcceptOrder(int id)
        {
            var maTaiXe = await GetMaTaiXeAsync();
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == maTaiXe);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.NhanDonAsync(_db, taiXe, id);
            if (!kq.Ok) return kq.ThongDiep.Contains("tài xế khác") ? Conflict(new { message = kq.ThongDiep }) : BadRequest(new { message = kq.ThongDiep });
            return Ok(new { message = kq.ThongDiep });
        }

        // =====================================================================================================
        // v86 — PHÂN PHỐI ĐƠN TỰ ĐỘNG: nhịp kết nối, đề nghị có thời hạn, hủy nhận đơn
        // =====================================================================================================
        public record NhipRequest(double? ViDo, double? KinhDo);

        /// <summary>
        /// App tài xế gọi định kỳ (~20 giây) khi đang online: báo "còn kết nối" + vị trí GPS (nếu có). Server dùng để biết tài xế còn trực tuyến hay mất GPS/mạng.
        /// Trả về cả đề nghị đang chờ (nếu có) để app vẫn nhận được đề nghị khi kênh thời gian thực bị đứt.
        /// </summary>
        [HttpPost("nhip")]
        [HttpPost("~/api/mobile/driver/nhip")]
        [HttpPost("~/api/mobile/tai-xe/nhip")]
        public async Task<IActionResult> Nhip([FromBody] NhipRequest? body)
        {
            var maTx = await GetMaTaiXeAsync();
            await FoodServiceApp.Web.Services.PhanPhoiDonXuLy.NhipAsync(_db, maTx, body?.ViDo, body?.KinhDo);
            var o = await FoodServiceApp.Web.Services.PhanPhoiDonXuLy.DeNghiHienTaiAsync(_db, maTx);
            return Ok(new { luc = DateTime.Now, coDeNghi = o != null, maDeNghi = o?.MaDeNghi });
        }

        /// <summary>Đề nghị đang chờ của tôi (kèm tóm tắt đơn và số giây còn lại).</summary>
        [HttpGet("de-nghi")]
        [HttpGet("~/api/mobile/driver/de-nghi")]
        [HttpGet("~/api/mobile/tai-xe/de-nghi")]
        public async Task<IActionResult> DeNghiHienTai()
        {
            var maTx = await GetMaTaiXeAsync();
            var o = await FoodServiceApp.Web.Services.PhanPhoiDonXuLy.DeNghiHienTaiAsync(_db, maTx);
            if (o == null) return Ok(new { coDeNghi = false });
            var d = await _db.DonHangs.AsNoTracking().Where(x => x.MaDonHang == o.MaDonHang).Select(x => new
            {
                maDon = x.MaDonHang, quan = x.GianHang!.TenCuaHang, diaChiQuan = x.GianHang!.DiaChi, diaChiGiao = x.DiaChiGiaoHang,
                kmGiao = x.KhoangCachKm, tongTien = x.TongTien, phiGiao = x.PhiGiaoHang,
                soMon = x.ChiTiets.Sum(c => (int?)c.SoLuong) ?? 0,
                thuHoCod = x.ThanhToan != null && x.ThanhToan.HinhThuc == "TienMat" && x.ThanhToan.TrangThai != "DaThanhToan",
                sanSang = x.SanSangGiao,
            }).FirstOrDefaultAsync();
            return Ok(new
            {
                coDeNghi = true, maDeNghi = o.MaDeNghi, maDon = o.MaDonHang, hetHanLuc = o.HetHanLuc,
                giayConLai = Math.Max(0, (int)(o.HetHanLuc - DateTime.Now).TotalSeconds), kmDenQuan = o.KmDenQuan, vong = o.Vong, don = d,
            });
        }

        /// <summary>Nhận đề nghị: chiếm bằng UPDATE có điều kiện — nếu hết hạn/đã giao cho người khác sẽ trả 409.</summary>
        [HttpPost("de-nghi/{id:long}/nhan")]
        [HttpPost("~/api/mobile/driver/de-nghi/{id:long}/nhan")]
        [HttpPost("~/api/mobile/tai-xe/de-nghi/{id:long}/nhan")]
        public async Task<IActionResult> NhanDeNghi(long id)
        {
            var maTx = await GetMaTaiXeAsync();
            var tx = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == maTx);
            var kq = await FoodServiceApp.Web.Services.PhanPhoiDonXuLy.NhanDeNghiAsync(_db, tx, id);
            if (kq.Ok) return Ok(new { message = kq.ThongDiep });
            return kq.ThongDiep.Contains("hết hạn") || kq.ThongDiep.Contains("người nhận") || kq.ThongDiep.Contains("đã bị hủy") ? Conflict(new { message = kq.ThongDiep }) : BadRequest(new { message = kq.ThongDiep });
        }

        [HttpPost("de-nghi/{id:long}/tu-choi")]
        [HttpPost("~/api/mobile/driver/de-nghi/{id:long}/tu-choi")]
        [HttpPost("~/api/mobile/tai-xe/de-nghi/{id:long}/tu-choi")]
        public async Task<IActionResult> TuChoiDeNghi(long id, [FromBody] RejectOrderRequest? body)
        {
            var maTx = await GetMaTaiXeAsync();
            var tx = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == maTx);
            var kq = await FoodServiceApp.Web.Services.PhanPhoiDonXuLy.TuChoiDeNghiAsync(_db, tx, id, body?.LyDo);
            return kq.Ok ? Ok(new { message = kq.ThongDiep }) : Conflict(new { message = kq.ThongDiep });
        }

        /// <summary>Tài xế hủy nhận đơn đã nhận (chỉ trước khi lấy hàng). Lý do bắt buộc; hủy nhiều lần sẽ bị tạm ngừng nhận đơn.</summary>
        [HttpPost("orders/{id:int}/huy-nhan")]
        [HttpPost("~/api/mobile/driver/orders/{id:int}/huy-nhan")]
        [HttpPost("~/api/mobile/tai-xe/don-hang/{id:int}/huy-nhan")]
        public async Task<IActionResult> HuyNhanDon(int id, [FromBody] RejectOrderRequest? body)
        {
            var maTx = await GetMaTaiXeAsync();
            var tx = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == maTx);
            var kq = await FoodServiceApp.Web.Services.PhanPhoiDonXuLy.TaiXeHuySauNhanAsync(_db, tx, id, body?.LyDo);
            return kq.Ok ? Ok(new { message = kq.ThongDiep }) : BadRequest(new { message = kq.ThongDiep });
        }

        /// <summary>Đã lấy hàng tại quán -> đơn chuyển sang "DangGiao" (cùng quy tắc với Website và app mobile).</summary>
        [HttpPost("orders/{id:int}/start")]
        [HttpPost("~/api/mobile/driver/orders/{id:int}/start")]
        public async Task<IActionResult> StartDelivery(int id, [FromQuery] string? maDon)
        {
            var maTaiXe = await GetMaTaiXeAsync();
            var don = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe == maTaiXe);
            var giaoHang = await _db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == id && g.MaTaiXe == maTaiXe);
            if (don == null || giaoHang == null) return NotFound();
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.DaLayHangAsync(_db, don, giaoHang, maDon);
            return kq.Ok ? Ok(new { giaoHang.TrangThai, message = kq.ThongDiep }) : BadRequest(new { message = kq.ThongDiep });
        }

        /// <summary>Xác nhận đã đến quán (ghi nhận mốc thời gian).</summary>
        [HttpPost("orders/{id:int}/arrive")]
        [HttpPost("~/api/mobile/driver/orders/{id:int}/arrive")]
        public async Task<IActionResult> ArriveAtStore(int id)
        {
            var maTaiXe = await GetMaTaiXeAsync();
            var don = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe == maTaiXe);
            var giaoHang = await _db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == id && g.MaTaiXe == maTaiXe);
            if (don == null || giaoHang == null) return NotFound();
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.DenQuanAsync(_db, don, giaoHang);
            return kq.Ok ? Ok(new { message = kq.ThongDiep, denQuanLuc = giaoHang.ThoiGianDenQuan }) : BadRequest(new { message = kq.ThongDiep });
        }

        public record PickupIssueRequest(string? Loai, string? MoTa);

        /// <summary>Báo sự cố khi lấy món: quán chuẩn bị chậm, không tìm thấy đơn, sai món, thiếu món, vấn đề bàn giao.</summary>
        [HttpPost("orders/{id:int}/pickup-issue")]
        [HttpPost("~/api/mobile/driver/orders/{id:int}/pickup-issue")]
        public async Task<IActionResult> PickupIssue(int id, [FromBody] PickupIssueRequest request)
        {
            var maTaiXe = await GetMaTaiXeAsync();
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == maTaiXe);
            var kq = await FoodServiceApp.Web.Services.DriverDonXuLy.BaoSuCoLayMonAsync(_db, taiXe, id, request?.Loai, request?.MoTa);
            return kq.Ok ? Ok(new { message = kq.ThongDiep }) : BadRequest(new { message = kq.ThongDiep });
        }

        public record DriverCompleteRequest(string? MaXacNhan, double? ViDo = null, double? KinhDo = null);
        public record DriverFailRequest(string LyDo, double? ViDo = null, double? KinhDo = null);

        [HttpPost("orders/{id:int}/complete")]
        [HttpPost("~/api/mobile/driver/orders/{id:int}/complete")]
        public async Task<IActionResult> CompleteDelivery(int id, [FromBody] DriverCompleteRequest request)
        {
            var maTaiXe = await GetMaTaiXeAsync();
            var don = await _db.DonHangs.Include(d => d.ThanhToan).FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe == maTaiXe);
            var giaoHang = await _db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == id && g.MaTaiXe == maTaiXe);
            if (don == null || giaoHang == null) return NotFound();
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == maTaiXe);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.HoanThanhAsync(_db, don, giaoHang, taiXe, request?.MaXacNhan, request?.ViDo, request?.KinhDo);
            return kq.Ok ? Ok(new { message = kq.ThongDiep }) : BadRequest(new { message = kq.ThongDiep });
        }

        [HttpPost("orders/{id:int}/fail")]
        [HttpPost("~/api/mobile/driver/orders/{id:int}/fail")]
        public async Task<IActionResult> FailDelivery(int id, [FromBody] DriverFailRequest request)
        {
            var maTaiXe = await GetMaTaiXeAsync();
            var don = await _db.DonHangs.Include(d => d.ThanhToan).FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe == maTaiXe);
            var giaoHang = await _db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == id && g.MaTaiXe == maTaiXe);
            if (don == null || giaoHang == null) return NotFound();
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == maTaiXe);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.ThatBaiAsync(_db, don, giaoHang, taiXe, request?.LyDo, request?.ViDo, request?.KinhDo);
            return kq.Ok ? Ok(new { message = kq.ThongDiep, tinhPhi = giaoHang.TinhPhiThatBai }) : BadRequest(new { message = kq.ThongDiep });
        }
    }
}
