using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// Kiểm tra voucher TRƯỚC khi đặt (app khách): dùng đúng KhuyenMaiXuLy.TinhAsync như lúc tạo đơn
    /// (hạn, lượt, đơn tối thiểu, mỗi khách một lần, giới hạn theo 30 ngày, quán/món/danh mục áp dụng).
    ///   POST api/mobile/khuyen-mai/kiem-tra  { maKhuyenMai, gianHangId, phiGiao, chiTiet:[{monAnId, soLuong, tuyChonIds?}] }
    /// Số tiền chỉ để hiển thị; khi đặt thật server tính lại.
    /// </summary>
    [ApiController]
    [Route("api/mobile")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang")]
    public class KhuyenMaiKiemTraApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        public KhuyenMaiKiemTraApiController(AppDbContext db) { _db = db; }

        public record Dong(int MonAnId, int SoLuong, List<int>? TuyChonIds = null);
        public record KiemTraRequest(string? MaKhuyenMai, int GianHangId, decimal? PhiGiao, List<Dong>? ChiTiet);

        [HttpPost("khuyen-mai/kiem-tra")]
        public async Task<IActionResult> KiemTra([FromBody] KiemTraRequest r)
        {
            var maTK = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
            var maKH = await _db.KhachHangs.Where(k => k.MaTK == maTK).Select(k => (int?)k.MaKH).FirstOrDefaultAsync();
            if (maKH == null) return StatusCode(401, new { message = "Tài khoản khách hàng không hợp lệ." });
            if (string.IsNullOrWhiteSpace(r.MaKhuyenMai)) return Ok(new { hopLe = false, giam = 0m, giamPhiShip = 0m, thongDiep = "Nhập mã khuyến mãi." });
            if (r.ChiTiet == null || r.ChiTiet.Count == 0 || r.ChiTiet.Any(x => x.SoLuong <= 0))
                return Ok(new { hopLe = false, giam = 0m, giamPhiShip = 0m, thongDiep = "Giỏ hàng trống." });

            var ids = r.ChiTiet.Select(x => x.MonAnId).Distinct().ToList();
            var foods = await _db.MonAns.Include(m => m.DanhMuc).Where(m => ids.Contains(m.MaMonAn)).ToListAsync();
            if (foods.Count != ids.Count || foods.Any(m => m.DanhMuc?.MaGianHang != r.GianHangId))
                return Ok(new { hopLe = false, giam = 0m, giamPhiShip = 0m, thongDiep = "Có món không thuộc gian hàng đã chọn." });

            var dong = new List<DongGioKm>();
            foreach (var it in r.ChiTiet)
            {
                var f = foods.First(x => x.MaMonAn == it.MonAnId);
                var (chon, loi) = await TuyChonHelper.KiemTraAsync(_db, f.MaMonAn, it.TuyChonIds ?? new List<int>());
                if (loi != null) return Ok(new { hopLe = false, giam = 0m, giamPhiShip = 0m, thongDiep = $"{f.TenMon}: {loi}" });
                dong.Add(new DongGioKm(f.MaMonAn, f.MaDanhMuc, f.Gia + chon.Sum(t => t.GiaThem), it.SoLuong));
            }

            var phi = Math.Max(0, r.PhiGiao ?? 0);
            var kq = await KhuyenMaiXuLy.TinhAsync(_db, r.MaKhuyenMai, r.GianHangId, maKH.Value, dong, phi);
            if (kq.Loi != null || kq.Km == null)
                return Ok(new { hopLe = false, giam = 0m, giamPhiShip = 0m, thongDiep = kq.Loi ?? "Mã khuyến mãi không hợp lệ." });
            var laShip = kq.Km.LoaiGiam == "GiamPhiVanChuyen";
            return Ok(new
            {
                hopLe = true,
                giam = laShip ? 0m : kq.Giam,
                giamPhiShip = laShip ? kq.Giam : 0m,
                thongDiep = laShip ? $"Giảm {kq.Giam:N0}đ phí giao" : $"Giảm {kq.Giam:N0}đ",
            });
        }
    }
}
