using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// Chat theo đơn giữa khách hàng, gian hàng và tài xế (v66: thêm gian hàng). Chỉ người trong đơn (khách đặt, chủ gian hàng của đơn, tài xế được giao) đọc/gửi được;
    /// vai trò người gửi lấy từ JWT, không tin client. Chỉ được gửi khi đơn còn đang xử lý (ChoXacNhan / DaXacNhan / DangGiao).
    /// </summary>
    [ApiController]
    [Route("api/mobile")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "KhachHang,TaiXe,GianHang")]
    public class ChatApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        public ChatApiController(AppDbContext db) { _db = db; }

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private string VaiTro => User.FindFirstValue(ClaimTypes.Role) ?? "";
        private static IActionResult Loi(string thongDiep, int status = 400) => new ObjectResult(new { thongDiep }) { StatusCode = status };

        private record BenDon(DonHang Don, string TenToi, List<int> MaTkNhan);

        private async Task<BenDon?> LayDonAsync(int maDon)
        {
            var don = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == maDon);
            if (don == null) return null;
            var tkKh = await _db.KhachHangs.AsNoTracking().Where(k => k.MaKH == don.MaKH).Select(k => k.MaTK).FirstOrDefaultAsync();
            var tkQuan = await _db.GianHangs.AsNoTracking().Where(g => g.MaGianHang == don.MaGianHang).Select(g => g.MaTK).FirstOrDefaultAsync();
            var tkTx = don.MaTaiXe == null ? 0 : await _db.TaiXes.AsNoTracking().Where(t => t.MaTaiXe == don.MaTaiXe).Select(t => t.MaTK).FirstOrDefaultAsync();

            string? ten; int toi;
            switch (VaiTro)
            {
                case "KhachHang":
                    ten = await _db.KhachHangs.AsNoTracking().Where(k => k.MaKH == don.MaKH && k.MaTK == MaTK).Select(k => k.HoTen).FirstOrDefaultAsync(); toi = tkKh; break;
                case "GianHang":
                    ten = await _db.GianHangs.AsNoTracking().Where(g => g.MaGianHang == don.MaGianHang && g.MaTK == MaTK).Select(g => g.TenCuaHang).FirstOrDefaultAsync(); toi = tkQuan; break;
                default:
                    ten = don.MaTaiXe == null ? null : await _db.TaiXes.AsNoTracking().Where(t => t.MaTaiXe == don.MaTaiXe && t.MaTK == MaTK).Select(t => t.HoTen).FirstOrDefaultAsync(); toi = tkTx; break;
            }
            if (ten == null) return null;
            var nhan = new[] { tkKh, tkQuan, tkTx }.Where(x => x != 0 && x != toi).Distinct().ToList();
            return new BenDon(don, ten, nhan);
        }

        [HttpGet("don-hang/{id:int}/tin-nhan")]
        public async Task<IActionResult> Lay(int id)
        {
            var b = await LayDonAsync(id);
            if (b == null) return Loi("Không có quyền xem tin nhắn của đơn này.", 403);
            var ds = await _db.TinNhans.AsNoTracking().Where(t => t.MaDonHang == id).OrderBy(t => t.ThoiGian).ThenBy(t => t.MaTinNhan).Take(500).ToListAsync();
            return Ok(ds.Select(t => new
            {
                id = t.MaClient ?? t.MaTinNhan.ToString(),
                donHangId = t.MaDonHang.ToString(),
                nguoiGui = t.NguoiGui, tenNguoiGui = t.TenNguoiGui ?? "", noiDung = t.NoiDung, thoiGian = t.ThoiGian,
            }));
        }

        public record GuiTinNhanRequest(string? Id, int DonHangId, string? NoiDung);

        [HttpPost("tin-nhan")]
        public async Task<IActionResult> Gui(GuiTinNhanRequest request)
        {
            var b = await LayDonAsync(request.DonHangId);
            if (b == null) return Loi("Không có quyền nhắn tin cho đơn này.", 403);
            if (b.Don.TrangThai is not ("ChoXacNhan" or "DaXacNhan" or "DangGiao")) return Loi("Đơn không còn trong chuyến giao nên không thể nhắn tin.", 409);
            var nd = (request.NoiDung ?? "").Trim();
            if (nd.Length == 0) return Loi("Nội dung trống.");
            if (nd.Length > 1000) nd = nd[..1000];
            var maClient = string.IsNullOrWhiteSpace(request.Id) ? null : (request.Id.Length > 40 ? request.Id[..40] : request.Id);
            if (maClient != null && await _db.TinNhans.AnyAsync(t => t.MaDonHang == request.DonHangId && t.MaClient == maClient))
                return Ok(new { daCo = true });

            _db.TinNhans.Add(new TinNhan { MaDonHang = request.DonHangId, NguoiGui = VaiTro, TenNguoiGui = b.TenToi, NoiDung = nd, MaClient = maClient });
            foreach (var tk in b.MaTkNhan)
                _db.ThongBaos.Add(new ThongBao { MaTK = tk, Loai = "TinNhan", MaThamChieu = request.DonHangId.ToString(),
                    TieuDe = $"Tin nhắn mới từ {b.TenToi} (đơn #{request.DonHangId})", NoiDung = nd.Length > 120 ? nd[..120] + "…" : nd });
            await _db.SaveChangesAsync();
            return Ok(new { ok = true });
        }

        public record GuiTheoDonRequest(string? Id, string? NoiDung);

        /// <summary>POST api/mobile/don-hang/{id}/tin-nhan — gửi tin nhắn theo mã đơn trên đường dẫn (cùng quy tắc với POST api/mobile/tin-nhan).</summary>
        [HttpPost("don-hang/{id:int}/tin-nhan")]
        public Task<IActionResult> GuiTheoDon(int id, GuiTheoDonRequest request) => Gui(new GuiTinNhanRequest(request.Id, id, request.NoiDung));
    }
}
