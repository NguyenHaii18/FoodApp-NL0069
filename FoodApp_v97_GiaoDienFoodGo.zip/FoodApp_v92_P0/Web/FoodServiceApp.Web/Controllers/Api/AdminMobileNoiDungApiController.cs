using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// v47f — bổ sung phần "IV. Quản trị viên" cho app MAUI: quản lý banner, câu hỏi thường gặp (FAQ) và khoản phải trả cho quán / tài xế.
    /// Xem: mọi quản trị viên. Ghi banner/FAQ cần quyền "ThongBao"; đánh dấu đã trả thu nhập tài xế cần quyền "ThanhToan".
    /// Mọi thao tác ghi tự vào nhật ký nhờ NhatKyThaoTacFilter (đăng ký toàn cục).
    /// </summary>
    [ApiController]
    [Route("api/mobile/admin")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
    public class AdminMobileNoiDungApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly IFileStorageService _luuTru;
        public AdminMobileNoiDungApiController(AppDbContext db, IFileStorageService luuTru) { _db = db; _luuTru = luuTru; }

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static ObjectResult Loi(string m, int status = 400) => new(new { thongDiep = m }) { StatusCode = status };
        private async Task<IActionResult?> ChanQuyenAsync(string khoa, string tenQuyen)
            => await QuyenAdmin.CoAsync(_db, MaTK, khoa) ? null : Loi($"Bạn không có quyền {tenQuyen}.", 403);

        // ------------------------------------------------------------------ BANNER
        [HttpGet("banner")]
        public async Task<IActionResult> Banners()
        {
            var now = DateTime.Now;
            var ds = await _db.Banners.AsNoTracking().OrderBy(b => b.ThuTu).ThenByDescending(b => b.NgayTao).Take(100).ToListAsync();
            return Ok(ds.Select(b => new
            {
                b.MaBanner, b.TieuDe, b.HinhAnh, b.LienKet, b.ThuTu, b.NgayBatDau, b.NgayKetThuc, b.TrangThai,
                dangHienThi = b.TrangThai && (b.NgayBatDau == null || b.NgayBatDau <= now) && (b.NgayKetThuc == null || b.NgayKetThuc >= now.Date),
            }));
        }

        [HttpPost("banner/anh")]
        public async Task<IActionResult> TaiAnhBanner(IFormFile file)
        {
            var chan = await ChanQuyenAsync("ThongBao", "quản lý banner"); if (chan != null) return chan;
            try { return Ok(new { imageUrl = await _luuTru.SaveFileAsync(file, "banner") }); }
            catch (ArgumentException ex) { return Loi(ex.Message); }
        }

        public record BannerReq(string? TieuDe, string? HinhAnh, string? LienKet, int ThuTu, DateTime? NgayBatDau, DateTime? NgayKetThuc);

        [HttpPost("banner")]
        public async Task<IActionResult> TaoBanner(BannerReq r)
        {
            var chan = await ChanQuyenAsync("ThongBao", "quản lý banner"); if (chan != null) return chan;
            var tieuDe = (r.TieuDe ?? "").Trim();
            var lienKet = string.IsNullOrWhiteSpace(r.LienKet) ? null : r.LienKet.Trim();
            if (tieuDe.Length < 3 || tieuDe.Length > 150) return Loi("Tiêu đề từ 3 đến 150 ký tự.");
            if (string.IsNullOrWhiteSpace(r.HinhAnh)) return Loi("Chọn ảnh banner.");
            if (lienKet != null && (lienKet.Length > 300 || !(lienKet.StartsWith("/") || lienKet.StartsWith("http://") || lienKet.StartsWith("https://"))))
                return Loi("Liên kết phải bắt đầu bằng / hoặc http(s):// và tối đa 300 ký tự.");
            if (r.NgayBatDau != null && r.NgayKetThuc != null && r.NgayKetThuc < r.NgayBatDau) return Loi("Ngày kết thúc phải sau ngày bắt đầu.");
            var b = new Banner { TieuDe = tieuDe, HinhAnh = r.HinhAnh.Trim(), LienKet = lienKet, ThuTu = r.ThuTu, NgayBatDau = r.NgayBatDau, NgayKetThuc = r.NgayKetThuc, MaTKTao = MaTK };
            _db.Banners.Add(b);
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã tạo banner.", b.MaBanner });
        }

        [HttpPut("banner/{id:int}/bat-tat")]
        public async Task<IActionResult> BatTatBanner(int id)
        {
            var chan = await ChanQuyenAsync("ThongBao", "quản lý banner"); if (chan != null) return chan;
            var b = await _db.Banners.FindAsync(id);
            if (b == null) return Loi("Không tìm thấy banner.", 404);
            b.TrangThai = !b.TrangThai;
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = b.TrangThai ? "Đã bật banner." : "Đã tắt banner." });
        }

        [HttpDelete("banner/{id:int}")]
        public async Task<IActionResult> XoaBanner(int id)
        {
            var chan = await ChanQuyenAsync("ThongBao", "quản lý banner"); if (chan != null) return chan;
            var b = await _db.Banners.FindAsync(id);
            if (b == null) return Loi("Không tìm thấy banner.", 404);
            _db.Banners.Remove(b);
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã xóa banner." });
        }

        // ------------------------------------------------------------------ CÂU HỎI THƯỜNG GẶP
        [HttpGet("faq")]
        public async Task<IActionResult> DanhSachFaq()
            => Ok(await _db.CauHoiThuongGaps.AsNoTracking().OrderBy(x => x.ThuTu).ThenBy(x => x.MaCauHoi)
                .Select(x => new { x.MaCauHoi, x.CauHoi, x.TraLoi, x.ThuTu, x.TrangThai }).ToListAsync());

        public record FaqReq(string? CauHoi, string? TraLoi, int ThuTu);

        private static string? KiemFaq(FaqReq r)
        {
            var q = (r.CauHoi ?? "").Trim(); var a = (r.TraLoi ?? "").Trim();
            if (q.Length < 5 || q.Length > 300) return "Câu hỏi từ 5 đến 300 ký tự.";
            if (a.Length < 5 || a.Length > 2000) return "Câu trả lời từ 5 đến 2000 ký tự.";
            return null;
        }

        [HttpPost("faq")]
        public async Task<IActionResult> TaoFaq(FaqReq r)
        {
            var chan = await ChanQuyenAsync("ThongBao", "quản lý câu hỏi thường gặp"); if (chan != null) return chan;
            var loi = KiemFaq(r); if (loi != null) return Loi(loi);
            _db.CauHoiThuongGaps.Add(new CauHoiThuongGap { CauHoi = r.CauHoi!.Trim(), TraLoi = r.TraLoi!.Trim(), ThuTu = r.ThuTu, MaTKTao = MaTK });
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã thêm câu hỏi." });
        }

        [HttpPut("faq/{id:int}")]
        public async Task<IActionResult> SuaFaq(int id, FaqReq r)
        {
            var chan = await ChanQuyenAsync("ThongBao", "quản lý câu hỏi thường gặp"); if (chan != null) return chan;
            var loi = KiemFaq(r); if (loi != null) return Loi(loi);
            var x = await _db.CauHoiThuongGaps.FindAsync(id);
            if (x == null) return Loi("Không tìm thấy câu hỏi.", 404);
            x.CauHoi = r.CauHoi!.Trim(); x.TraLoi = r.TraLoi!.Trim(); x.ThuTu = r.ThuTu;
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã cập nhật câu hỏi." });
        }

        [HttpPut("faq/{id:int}/bat-tat")]
        public async Task<IActionResult> BatTatFaq(int id)
        {
            var chan = await ChanQuyenAsync("ThongBao", "quản lý câu hỏi thường gặp"); if (chan != null) return chan;
            var x = await _db.CauHoiThuongGaps.FindAsync(id);
            if (x == null) return Loi("Không tìm thấy câu hỏi.", 404);
            x.TrangThai = !x.TrangThai;
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = x.TrangThai ? "Đã hiển thị câu hỏi." : "Đã ẩn câu hỏi." });
        }

        [HttpDelete("faq/{id:int}")]
        public async Task<IActionResult> XoaFaq(int id)
        {
            var chan = await ChanQuyenAsync("ThongBao", "quản lý câu hỏi thường gặp"); if (chan != null) return chan;
            var x = await _db.CauHoiThuongGaps.FindAsync(id);
            if (x == null) return Loi("Không tìm thấy câu hỏi.", 404);
            _db.CauHoiThuongGaps.Remove(x);
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã xóa câu hỏi." });
        }

        // ------------------------------------------------------------------ KHOẢN PHẢI TRẢ
        /// <summary>
        /// Phải trả cho gian hàng = (tiền hàng − phí nền tảng) của đơn đã giao CHƯA trả (DonHang.QuanDaTraLuc = null);
        /// tiền hàng = TongTien − PhiGiaoHang, phí = tiền hàng × TyLeChietKhau (cùng công thức báo cáo).
        /// Phải trả cho tài xế = phí giao của đơn đã giao có GiaoHang.TrangThaiThuNhap = ChoThanhToan
        /// (tài xế của quán — "NoiBo" — do quán tự trả nên không nằm trong danh sách này).
        /// </summary>
        [HttpGet("tai-chinh/phai-tra")]
        public async Task<IActionResult> PhaiTra()
        {
            var don = await _db.DonHangs.AsNoTracking().Include(d => d.GianHang).Include(d => d.GiaoHang).ThenInclude(g => g!.TaiXe)
                .Where(d => d.TrangThai == "DaGiao").ToListAsync();

            var quan = don.Where(d => d.QuanDaTraLuc == null)
                .GroupBy(d => new { d.MaGianHang, Ten = d.GianHang?.TenCuaHang ?? "?", Ty = d.GianHang?.TyLeChietKhau ?? 0m })
                .Select(g =>
                {
                    var tienHang = g.Sum(d => d.TongTien - d.PhiGiaoHang);
                    var phi = Math.Round(tienHang * g.Key.Ty, 0);
                    return new { maGianHang = g.Key.MaGianHang, ten = g.Key.Ten, soDon = g.Count(), tienHang, tyLe = g.Key.Ty, phiNenTang = phi, phaiTra = tienHang - phi };
                }).OrderByDescending(x => x.phaiTra).ToList();

            var taiXe = don.Where(d => d.GiaoHang?.TaiXe != null && d.GiaoHang.TrangThaiThuNhap == "ChoThanhToan")
                .GroupBy(d => new { d.GiaoHang!.MaTaiXe, d.GiaoHang.TaiXe!.HoTen })
                .Select(g => new { maTaiXe = g.Key.MaTaiXe, ten = g.Key.HoTen, soDon = g.Count(), phaiTra = g.Sum(d => FoodServiceApp.Web.Services.PhiGiaoService.TienTaiXe(d.PhiGiaoHang, d.TyLeTaiXe)) })
                .OrderByDescending(x => x.phaiTra).ToList();

            var tu = DateTime.Now.AddDays(-30);
            var daTraQuan30 = don.Where(d => d.QuanDaTraLuc != null && d.QuanDaTraLuc >= tu)
                .Sum(d => (d.TongTien - d.PhiGiaoHang) - Math.Round((d.TongTien - d.PhiGiaoHang) * (d.GianHang?.TyLeChietKhau ?? 0m), 0));
            var daTraTaiXe30 = don.Where(d => d.GiaoHang?.TrangThaiThuNhap == "DaThanhToan" && d.GiaoHang.NgayThanhToanThuNhap >= tu).Sum(d => FoodServiceApp.Web.Services.PhiGiaoService.TienTaiXe(d.PhiGiaoHang, d.TyLeTaiXe));

            return Ok(new
            {
                tongPhaiTraQuan = quan.Sum(x => x.phaiTra),
                tongPhiNenTang = quan.Sum(x => x.phiNenTang),
                tongPhaiTraTaiXe = taiXe.Sum(x => x.phaiTra),
                daTraQuan30Ngay = daTraQuan30,
                daTraTaiXe30Ngay = daTraTaiXe30,
                quan, taiXe,
            });
        }

        /// <summary>Đánh dấu đã trả cho quán: mọi đơn đã giao chưa trả của quán chuyển QuanDaTraLuc = now.</summary>
        [HttpPut("tai-chinh/gian-hang/{maGianHang:int}/da-tra")]
        public async Task<IActionResult> DaTraQuan(int maGianHang)
        {
            var chan = await ChanQuyenAsync("ThanhToan", "đối soát thanh toán"); if (chan != null) return chan;
            var gh = await _db.GianHangs.AsNoTracking().FirstOrDefaultAsync(g => g.MaGianHang == maGianHang);
            if (gh == null) return Loi("Không tìm thấy gian hàng.", 404);
            var ds = await _db.DonHangs.Where(d => d.MaGianHang == maGianHang && d.TrangThai == "DaGiao" && d.QuanDaTraLuc == null).ToListAsync();
            if (ds.Count == 0) return Loi("Quán này không còn khoản nào chưa trả.");
            var tienHang = ds.Sum(d => d.TongTien - d.PhiGiaoHang);
            var tong = tienHang - Math.Round(tienHang * gh.TyLeChietKhau, 0);
            foreach (var d in ds) d.QuanDaTraLuc = DateTime.Now;
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = $"Đã ghi nhận trả {tong:N0}đ cho \"{gh.TenCuaHang}\" ({ds.Count} đơn)." });
        }

        /// <summary>Đánh dấu đã trả thu nhập cho tài xế: mọi đơn đã giao đang ChoThanhToan của tài xế đó chuyển sang DaThanhToan.</summary>
        [HttpPut("tai-chinh/tai-xe/{maTaiXe:int}/da-tra")]
        public async Task<IActionResult> DaTraTaiXe(int maTaiXe)
        {
            var chan = await ChanQuyenAsync("ThanhToan", "đối soát thanh toán"); if (chan != null) return chan;
            var ds = await _db.GiaoHangs.Include(g => g.DonHang)
                .Where(g => g.MaTaiXe == maTaiXe && g.TrangThaiThuNhap == "ChoThanhToan" && g.DonHang != null && g.DonHang.TrangThai == "DaGiao").ToListAsync();
            if (ds.Count == 0) return Loi("Tài xế này không còn khoản nào chờ thanh toán.");
            var tong = ds.Sum(g => FoodServiceApp.Web.Services.PhiGiaoService.TienTaiXe(g.DonHang!.PhiGiaoHang, g.DonHang.TyLeTaiXe));
            foreach (var g in ds) { g.TrangThaiThuNhap = "DaThanhToan"; g.NgayThanhToanThuNhap = DateTime.Now; }
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = $"Đã ghi nhận trả {tong:N0}đ cho tài xế ({ds.Count} đơn)." });
        }

        // ------------------------------------------------------------------ KHÁCH HÀNG: tra cứu + lịch sử đơn
        /// <summary>Tìm khách theo tên, SĐT, email hoặc mã (KH/tài khoản); kèm số đơn, tổng chi, khiếu nại. Lịch sử đơn: GET don-hang/tim?maKH=.</summary>
        [HttpGet("khach-hang/tim")]
        public async Task<IActionResult> TimKhach(string? q)
        {
            var qr = _db.KhachHangs.AsNoTracking().Include(k => k.TaiKhoan).AsQueryable();
            if (!string.IsNullOrWhiteSpace(q))
            {
                q = q.Trim();
                if (int.TryParse(q.TrimStart('#'), out var ma)) qr = qr.Where(k => k.MaKH == ma || k.MaTK == ma || k.SDT.Contains(q));
                else qr = qr.Where(k => k.HoTen.Contains(q) || k.SDT.Contains(q) || (k.Email != null && k.Email.Contains(q)));
            }
            var ds = await qr.OrderByDescending(k => k.MaKH).Take(60).ToListAsync();
            var ids = ds.Select(k => k.MaKH).ToList();
            var thongKe = await _db.DonHangs.AsNoTracking().Where(d => ids.Contains(d.MaKH))
                .GroupBy(d => d.MaKH).Select(g => new
                {
                    ma = g.Key, soDon = g.Count(), daGiao = g.Count(d => d.TrangThai == "DaGiao"), daHuy = g.Count(d => d.TrangThai == "DaHuy"),
                    tongChi = g.Where(d => d.TrangThai == "DaGiao").Sum(d => (decimal?)d.TongTien) ?? 0m, lanCuoi = g.Max(d => d.NgayDat),
                }).ToDictionaryAsync(x => x.ma);
            var khieuNai = await _db.PhanHois.AsNoTracking().Where(p => p.Loai == "KhieuNai" && ids.Contains(p.MaKH))
                .GroupBy(p => p.MaKH).Select(g => new { ma = g.Key, so = g.Count() }).ToDictionaryAsync(x => x.ma, x => x.so);
            return Ok(ds.Select(k =>
            {
                thongKe.TryGetValue(k.MaKH, out var t);
                return new
                {
                    k.MaKH, k.MaTK, k.HoTen, sdt = k.SDT, k.Email,
                    biKhoa = k.TaiKhoan != null && !k.TaiKhoan.TrangThai,
                    soDon = t?.soDon ?? 0, daGiao = t?.daGiao ?? 0, daHuy = t?.daHuy ?? 0, tongChi = t?.tongChi ?? 0m, lanCuoi = t?.lanCuoi,
                    soKhieuNai = khieuNai.GetValueOrDefault(k.MaKH),
                };
            }));
        }

        // ------------------------------------------------------------------ GIAN HÀNG: hồ sơ hợp đồng + hoa hồng
        [HttpGet("gian-hang/hop-dong")]
        public async Task<IActionResult> HopDongQuan(string? q)
        {
            var qr = _db.GianHangs.AsNoTracking().Where(g => g.TrangThaiDuyet == "DaDuyet");
            if (!string.IsNullOrWhiteSpace(q)) { q = q.Trim(); qr = qr.Where(g => g.TenCuaHang.Contains(q) || g.SDT.Contains(q)); }
            var ds = await qr.OrderBy(g => g.TenCuaHang).Take(100).ToListAsync();
            var ids = ds.Select(g => g.MaGianHang).ToList();
            var tk = await _db.DonHangs.AsNoTracking().Where(d => ids.Contains(d.MaGianHang))
                .GroupBy(d => d.MaGianHang).Select(g => new
                {
                    ma = g.Key, soDon = g.Count(), daGiao = g.Count(d => d.TrangThai == "DaGiao"), daHuy = g.Count(d => d.TrangThai == "DaHuy"),
                    gmv = g.Where(d => d.TrangThai == "DaGiao").Sum(d => (decimal?)d.TongTien) ?? 0m,
                    phiGiao = g.Where(d => d.TrangThai == "DaGiao").Sum(d => (decimal?)d.PhiGiaoHang) ?? 0m,
                }).ToDictionaryAsync(x => x.ma);
            var sao = await _db.DanhGias.AsNoTracking().Where(d => ids.Contains(d.MaGianHang) && !d.DaAn)
                .GroupBy(d => d.MaGianHang).Select(g => new { ma = g.Key, tb = g.Average(d => (double)d.SoSao), so = g.Count() }).ToDictionaryAsync(x => x.ma);
            return Ok(ds.Select(g =>
            {
                tk.TryGetValue(g.MaGianHang, out var t); sao.TryGetValue(g.MaGianHang, out var s);
                var tienHang = (t?.gmv ?? 0m) - (t?.phiGiao ?? 0m);
                return new
                {
                    g.MaGianHang, ten = g.TenCuaHang, g.DiaChi, sdt = g.SDT, g.TrangThaiKinhDoanh, g.NgayDangKy, tyLe = g.TyLeChietKhau, cheDoGiao = g.CheDoGiao,
                    soDon = t?.soDon ?? 0, daGiao = t?.daGiao ?? 0, daHuy = t?.daHuy ?? 0, gmv = t?.gmv ?? 0m,
                    hoaHongDaThu = Math.Round(tienHang * g.TyLeChietKhau, 0),
                    saoTB = s == null ? (double?)null : Math.Round(s.tb, 1), soDanhGia = s?.so ?? 0,
                };
            }));
        }

        public record HoaHongReq(decimal PhanTram);

        [HttpPut("gian-hang/{id:int}/hoa-hong")]
        public async Task<IActionResult> DatHoaHong(int id, HoaHongReq r)
        {
            var q = await _db.QuanTris.AsNoTracking().Where(x => x.MaTK == MaTK).Select(x => x.CapQuyenHan).FirstOrDefaultAsync();
            if (q != "SuperAdmin") return Loi("Chỉ Admin tổng mới được đặt hoa hồng.", 403);
            if (r.PhanTram < 0 || r.PhanTram > 100) return Loi("Hoa hồng phải từ 0 đến 100%.");
            var gh = await _db.GianHangs.FindAsync(id);
            if (gh == null) return Loi("Không tìm thấy gian hàng.", 404);
            gh.TyLeChietKhau = Math.Round(r.PhanTram / 100m, 4);
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = $"Đã đặt hoa hồng của \"{gh.TenCuaHang}\" = {r.PhanTram:0.##}% (áp dụng cho báo cáo từ nay)." });
        }
    }

    /// <summary>FAQ công khai cho khách (web + app) — chỉ câu đang bật.</summary>
    [ApiController]
    [Route("api/mobile/faq")]
    [AllowAnonymous]
    public class FaqPublicApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        public FaqPublicApiController(AppDbContext db) { _db = db; }

        [HttpGet("")]
        public async Task<IActionResult> Get()
            => Ok(await _db.CauHoiThuongGaps.AsNoTracking().Where(x => x.TrangThai).OrderBy(x => x.ThuTu).ThenBy(x => x.MaCauHoi)
                .Select(x => new { cauHoi = x.CauHoi, traLoi = x.TraLoi }).ToListAsync());
    }
}
