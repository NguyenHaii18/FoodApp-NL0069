using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Filters;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Services;
using FoodServiceApp.Web.Services.Payment;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// API quản trị bổ sung cho app MAUI (v38): tổng quan, tài khoản, danh mục, món ăn, đơn hàng (điều tra/hủy),
    /// thanh toán, hoàn tiền, đánh giá, điều phối, cấu hình, báo cáo. Logic dùng lại đúng quy tắc của các trang Web QuanTri/*.
    /// Quyền: mọi quản trị viên được XEM; ghi theo quyền chi tiết (DonHang, ThanhToan, HoanTien, DanhGia, ThongBao)
    /// hoặc chỉ Admin tổng (tài khoản, cấu hình). Mọi thao tác ghi tự vào NhatKyHeThong nhờ NhatKyThaoTacFilter.
    /// </summary>
    [ApiController]
    [Route("api/mobile/admin")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
    public class AdminMobileApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly CauHinhService _cauHinh;
        private readonly IVnPayService _vnPay;

        public AdminMobileApiController(AppDbContext db, CauHinhService cauHinh, IVnPayService vnPay)
        { _db = db; _cauHinh = cauHinh; _vnPay = vnPay; }

        // ------------------------------------------------------------------ tiện ích
        public record AdminLyDoReq(string? LyDo);
        public record AdminKetQuaReq(string? KetQua, string? MaHoanThuCong);
        public record AdminDoiTenReq(string? TenMoi, string? LyDo);
        public record AdminKhachReq(string? HoTen, string? Sdt, string? Email, string? DiaChi);
        public record AdminTaiXeReq(string? HoTen, string? Sdt, string? PhuongTien, string? BienSo, string? KhuVuc);
        public record AdminPhanCongReq(int MaTaiXe, string? LyDo);
        public record AdminHoanTienReq(int MaDonHang, decimal? SoTien, string? LyDo);
        public record AdminCauHinhReq(string? Khoa, string? GiaTri);
        public record AdminMaGdReq(string? MaGiaoDich);

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static ObjectResult Loi(string m, int status = 400) => new(new { thongDiep = m }) { StatusCode = status };

        private Task<bool> LaSuperAsync() => _db.QuanTris.AnyAsync(q => q.MaTK == MaTK && q.CapQuyenHan == "SuperAdmin");
        private async Task<string> CapQuyenAsync() => await _db.QuanTris.Where(q => q.MaTK == MaTK).Select(q => q.CapQuyenHan).FirstOrDefaultAsync() ?? "";

        /// <summary>Trả lỗi 403 (JSON) nếu thiếu quyền chi tiết; null nếu đủ quyền.</summary>
        private async Task<IActionResult?> ChanAsync(string khoa) =>
            await QuyenAdmin.CoAsync(_db, MaTK, khoa) ? null : Loi("Tài khoản của bạn chưa được cấp quyền cho chức năng này.", 403);

        private async Task<IActionResult?> ChanSuperAsync() =>
            await LaSuperAsync() ? null : Loi("Chỉ Admin tổng mới được thực hiện thao tác này.", 403);

        private static readonly string[] TrangThaiCuoi = { "DaGiao", "DaHuy" };

        // ------------------------------------------------------------------ 1. TỔNG QUAN (dashboard)
        [HttpGet("tong-quan")]
        public async Task<IActionResult> TongQuan()
        {
            var homNay = DateTime.Today;
            var tuan = homNay.AddDays(-6);
            var daGiao = _db.DonHangs.Where(d => d.TrangThai == "DaGiao");
            return Ok(new
            {
                khachHang = await _db.KhachHangs.CountAsync(),
                gianHang = await _db.GianHangs.CountAsync(g => g.TrangThaiDuyet == "DaDuyet"),
                gianHangChoDuyet = await _db.GianHangs.CountAsync(g => g.TrangThaiDuyet == "ChoDuyet"),
                taiXe = await _db.TaiXes.CountAsync(t => t.TrangThaiDuyet == "DaDuyet"),
                taiXeChoDuyet = await _db.TaiXes.CountAsync(t => t.TrangThaiDuyet == "ChoDuyet"),
                tongDon = await _db.DonHangs.CountAsync(),
                donHomNay = await _db.DonHangs.CountAsync(d => d.NgayDat >= homNay),
                donDangXuLy = await _db.DonHangs.CountAsync(d => d.TrangThai != "DaGiao" && d.TrangThai != "DaHuy"),
                donChuaCoTaiXe = await _db.DonHangs.CountAsync(d => d.TrangThai == "DaXacNhan" && d.MaTaiXe == null),
                doanhThuTong = await daGiao.SumAsync(d => (decimal?)d.TongTien) ?? 0,
                doanhThuHomNay = await daGiao.Where(d => d.NgayDat >= homNay).SumAsync(d => (decimal?)d.TongTien) ?? 0,
                doanhThuTuan = await daGiao.Where(d => d.NgayDat >= tuan).SumAsync(d => (decimal?)d.TongTien) ?? 0,
                khieuNaiCho = await _db.PhanHois.CountAsync(p => p.TrangThai == "ChuaXuLy"),
                hoanTienCho = await _db.YeuCauHoanTiens.CountAsync(y => y.TrangThai == "ChoDuyet"),
                baoCaoDanhGiaCho = await _db.BaoCaoDanhGias.CountAsync(b => b.TrangThai == "ChoXuLy"),
                codChuaDoiSoat = await _db.ThanhToans.CountAsync(t => t.HinhThuc == "TienMat" && !t.DaDoiSoat
                    && _db.DonHangs.Any(d => d.MaDonHang == t.MaDonHang && d.TrangThai == "DaGiao")),
                capQuyen = await CapQuyenAsync(),
            });
        }

        // ------------------------------------------------------------------ 2. TÀI KHOẢN (toàn bộ vai trò)
        [HttpGet("tai-khoan")]
        public async Task<IActionResult> TaiKhoans(string? vaiTro, string? q, bool? biKhoa)
        {
            var query = _db.TaiKhoans.AsNoTracking().AsQueryable();
            if (!string.IsNullOrEmpty(vaiTro)) query = query.Where(t => t.VaiTro == vaiTro);
            if (biKhoa == true) query = query.Where(t => !t.TrangThai);
            if (!string.IsNullOrWhiteSpace(q))
            {
                q = q.Trim();
                var kh = _db.KhachHangs.Where(k => k.HoTen.Contains(q) || k.SDT.Contains(q)).Select(k => k.MaTK);
                var gh = _db.GianHangs.Where(g => g.TenCuaHang.Contains(q) || g.SDT.Contains(q)).Select(g => g.MaTK);
                var tx = _db.TaiXes.Where(t => t.HoTen.Contains(q) || t.SDT.Contains(q)).Select(t => t.MaTK);
                query = query.Where(t => t.TenDangNhap.Contains(q) || kh.Contains(t.MaTK) || gh.Contains(t.MaTK) || tx.Contains(t.MaTK));
            }
            var ds = await query.OrderByDescending(t => t.NgayTao).Take(300)
                .Select(t => new { t.MaTK, t.TenDangNhap, t.VaiTro, t.NgayTao, t.LanDangNhapCuoi, t.KhoaDen, t.SoLanDangNhapSai, BiKhoa = !t.TrangThai })
                .ToListAsync();
            var ids = ds.Select(x => x.MaTK).ToList();
            var ten = new Dictionary<int, string>();
            foreach (var k in await _db.KhachHangs.AsNoTracking().Where(k => ids.Contains(k.MaTK)).Select(k => new { k.MaTK, k.HoTen, k.SDT }).ToListAsync()) ten[k.MaTK] = $"{k.HoTen} · {k.SDT}";
            foreach (var g in await _db.GianHangs.AsNoTracking().Where(g => ids.Contains(g.MaTK)).Select(g => new { g.MaTK, g.TenCuaHang, g.SDT }).ToListAsync()) ten[g.MaTK] = $"{g.TenCuaHang} · {g.SDT}";
            foreach (var t in await _db.TaiXes.AsNoTracking().Where(t => ids.Contains(t.MaTK)).Select(t => new { t.MaTK, t.HoTen, t.SDT }).ToListAsync()) ten[t.MaTK] = $"{t.HoTen} · {t.SDT}";
            foreach (var a in await _db.QuanTris.AsNoTracking().Where(a => ids.Contains(a.MaTK)).Select(a => new { a.MaTK, a.HoTen, a.CapQuyenHan }).ToListAsync()) ten[a.MaTK] = $"{a.HoTen} · {a.CapQuyenHan}";
            return Ok(ds.Select(x => new
            {
                x.MaTK, x.TenDangNhap, x.VaiTro, x.NgayTao, x.LanDangNhapCuoi, x.BiKhoa,
                biKhoaTam = x.KhoaDen != null && x.KhoaDen > DateTime.Now,
                x.SoLanDangNhapSai,
                moTa = ten.TryGetValue(x.MaTK, out var s) ? s : "",
            }));
        }

        [HttpPut("tai-khoan/{maTK:int}/khoa")]
        public Task<IActionResult> KhoaTaiKhoan(int maTK) => DatKhoaTaiKhoanAsync(maTK, false);

        [HttpPut("tai-khoan/{maTK:int}/mo-khoa")]
        public Task<IActionResult> MoKhoaTaiKhoan(int maTK) => DatKhoaTaiKhoanAsync(maTK, true);

        private async Task<IActionResult> DatKhoaTaiKhoanAsync(int maTK, bool hoatDong)
        {
            var chan = await ChanSuperAsync(); if (chan != null) return chan;
            if (maTK == MaTK) return Loi("Không thể tự khóa chính mình.");
            var tk = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == maTK);
            if (tk == null) return Loi("Không tìm thấy tài khoản.", 404);
            if (!hoatDong && tk.VaiTro == "QuanTri" && await _db.QuanTris.AnyAsync(q => q.MaTK == maTK && q.CapQuyenHan == "SuperAdmin"))
                return Loi("Không khóa tài khoản Admin tổng từ ứng dụng.");
            tk.TrangThai = hoatDong;
            if (hoatDong) { tk.SoLanDangNhapSai = 0; tk.KhoaDen = null; }
            else if (tk.VaiTro == "TaiXe")
            {
                var tx = await _db.TaiXes.FirstOrDefaultAsync(t => t.MaTK == maTK);
                if (tx != null) tx.TrangThai = "NgoaiTuyen";
            }
            await _db.SaveChangesAsync();
            return Ok(new { biKhoa = !tk.TrangThai });
        }

        // ------------------------------------------------------------------ 3. KHÁCH HÀNG / TÀI XẾ: chỉnh sửa thông tin
        private static string? ChuanSdt(string? s)
        {
            var d = new string((s ?? "").Where(char.IsDigit).ToArray());
            return d.Length is >= 9 and <= 11 ? d : null;
        }

        [HttpPut("khach-hang/{id:int}")]
        public async Task<IActionResult> SuaKhach(int id, [FromBody] AdminKhachReq? b)
        {
            var chan = await ChanSuperAsync(); if (chan != null) return chan;
            var kh = await _db.KhachHangs.FirstOrDefaultAsync(k => k.MaKH == id);
            if (kh == null) return Loi("Không tìm thấy khách hàng.", 404);
            var ten = (b?.HoTen ?? "").Trim();
            if (ten.Length < 2 || ten.Length > 100) return Loi("Họ tên dài 2–100 ký tự.");
            var sdt = ChuanSdt(b?.Sdt);
            if (sdt == null) return Loi("Số điện thoại phải có 9–11 chữ số.");
            if (await _db.KhachHangs.AnyAsync(k => k.SDT == sdt && k.MaKH != id)) return Loi("Số điện thoại đã được khách khác sử dụng.", 409);
            var email = (b?.Email ?? "").Trim();
            if (email.Length > 0 && (!email.Contains('@') || email.Length > 150)) return Loi("Email không hợp lệ.");
            kh.HoTen = ten; kh.SDT = sdt; kh.Email = email.Length == 0 ? null : email;
            kh.DiaChiGiaoHang = string.IsNullOrWhiteSpace(b?.DiaChi) ? null : b!.DiaChi!.Trim();
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã cập nhật thông tin khách hàng." });
        }

        [HttpGet("tai-xe/{id:int}")]
        public async Task<IActionResult> ChiTietTaiXe(int id)
        {
            var t = await _db.TaiXes.AsNoTracking().FirstOrDefaultAsync(x => x.MaTaiXe == id);
            if (t == null) return Loi("Không tìm thấy tài xế.", 404);
            var gh = _db.GiaoHangs.AsNoTracking().Where(g => g.MaTaiXe == id);
            var sao = await _db.DanhGias.AsNoTracking().Where(d => d.MaTaiXe == id && d.SoSaoGiaoHang != null).Select(d => (double?)d.SoSaoGiaoHang).AverageAsync();
            return Ok(new
            {
                id = t.MaTaiXe, t.HoTen, sdt = t.SDT, t.PhuongTien, t.BienSo, t.KhuVucHoatDong, t.TrangThai, t.TrangThaiDuyet,
                t.SoCCCD, t.SoGPLX, t.NgayDangKy, t.LyDoTuChoi,
                tongChuyen = await gh.CountAsync(),
                daGiao = await gh.CountAsync(g => g.ThoiGianGiao != null),
                thatBai = await gh.CountAsync(g => g.TrangThai == "GiaoThatBai"),
                dangGiao = await _db.DonHangs.CountAsync(d => d.MaTaiXe == id && d.TrangThai == "DangGiao"),
                codChuaNop = await gh.Where(g => g.TienThuCOD != null && g.CodDaNopLuc == null).SumAsync(g => (decimal?)g.TienThuCOD) ?? 0,
                saoTrungBinh = sao == null ? (double?)null : Math.Round(sao.Value, 2),
            });
        }

        [HttpPut("tai-xe/{id:int}")]
        public async Task<IActionResult> SuaTaiXe(int id, [FromBody] AdminTaiXeReq? b)
        {
            var chan = await ChanSuperAsync(); if (chan != null) return chan;
            var t = await _db.TaiXes.FirstOrDefaultAsync(x => x.MaTaiXe == id);
            if (t == null) return Loi("Không tìm thấy tài xế.", 404);
            var ten = (b?.HoTen ?? "").Trim();
            if (ten.Length < 2 || ten.Length > 100) return Loi("Họ tên dài 2–100 ký tự.");
            var sdt = ChuanSdt(b?.Sdt);
            if (sdt == null) return Loi("Số điện thoại phải có 9–11 chữ số.");
            if (await _db.TaiXes.AnyAsync(x => x.SDT == sdt && x.MaTaiXe != id)) return Loi("Số điện thoại đã được tài xế khác sử dụng.", 409);
            t.HoTen = ten; t.SDT = sdt;
            t.PhuongTien = string.IsNullOrWhiteSpace(b?.PhuongTien) ? t.PhuongTien : b!.PhuongTien!.Trim();
            t.BienSo = string.IsNullOrWhiteSpace(b?.BienSo) ? null : b!.BienSo!.Trim().ToUpperInvariant();
            t.KhuVucHoatDong = FoodServiceApp.Web.Services.KhuVucHelper.ChuanHoa(b?.KhuVuc);
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã cập nhật thông tin tài xế." });
        }

        // ------------------------------------------------------------------ 4. DANH MỤC
        private void NhacGianHang(int maTKGianHang, string tieuDe, string noiDung) =>
            _db.ThongBaos.Add(new ThongBao { MaTK = maTKGianHang, Loai = "HeThong", TieuDe = tieuDe, NoiDung = noiDung });

        [HttpGet("danh-muc")]
        public async Task<IActionResult> DanhMucs(int? maGianHang, string? q, bool? daAn)
        {
            var query = _db.DanhMucs.AsNoTracking().AsQueryable();
            if (maGianHang != null) query = query.Where(d => d.MaGianHang == maGianHang);
            if (!string.IsNullOrWhiteSpace(q)) { q = q.Trim(); query = query.Where(d => d.TenDanhMuc.Contains(q) || (d.GianHang != null && d.GianHang.TenCuaHang.Contains(q))); }
            if (daAn == true) query = query.Where(d => d.DaAn);
            return Ok(await query.OrderBy(d => d.MaGianHang).ThenBy(d => d.TenDanhMuc).Take(300)
                .Select(d => new { d.MaDanhMuc, d.MaGianHang, tenGianHang = d.GianHang != null ? d.GianHang.TenCuaHang : "", d.TenDanhMuc, d.DaAn, soMon = d.MonAns.Count })
                .ToListAsync());
        }

        [HttpPut("danh-muc/{id:int}/doi-ten")]
        public async Task<IActionResult> DoiTenDanhMuc(int id, [FromBody] AdminDoiTenReq? b)
        {
            var chan = await ChanAsync("ThongBao"); if (chan != null) return chan;
            var dm = await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaDanhMuc == id);
            if (dm == null) return Loi("Không tìm thấy danh mục.", 404);
            var moi = (b?.TenMoi ?? "").Trim(); var lyDo = (b?.LyDo ?? "").Trim();
            if (moi.Length < 2 || moi.Length > 100) return Loi("Tên danh mục dài 2–100 ký tự.");
            if (lyDo.Length < 5) return Loi("Bắt buộc nhập lý do đổi tên (tối thiểu 5 ký tự).");
            if (await _db.DanhMucs.AnyAsync(d => d.MaGianHang == dm.MaGianHang && d.MaDanhMuc != id && d.TenDanhMuc == moi)) return Loi("Gian hàng này đã có danh mục trùng tên.", 409);
            var cu = dm.TenDanhMuc; dm.TenDanhMuc = moi;
            var maTk = await _db.GianHangs.Where(g => g.MaGianHang == dm.MaGianHang).Select(g => (int?)g.MaTK).FirstOrDefaultAsync();
            if (maTk != null) NhacGianHang(maTk.Value, $"Danh mục \"{cu}\" được đổi tên", $"Tên mới: \"{moi}\". Lý do: {lyDo}");
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = $"Đã đổi tên thành \"{moi}\"." });
        }

        [HttpPut("danh-muc/{id:int}/an")]
        public async Task<IActionResult> AnDanhMuc(int id, [FromBody] AdminLyDoReq? b)
        {
            var chan = await ChanAsync("ThongBao"); if (chan != null) return chan;
            var dm = await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaDanhMuc == id);
            if (dm == null) return Loi("Không tìm thấy danh mục.", 404);
            if (string.IsNullOrWhiteSpace(b?.LyDo)) return Loi("Bắt buộc nhập lý do ẩn danh mục.");
            dm.DaAn = true;
            var maTk = await _db.GianHangs.Where(g => g.MaGianHang == dm.MaGianHang).Select(g => (int?)g.MaTK).FirstOrDefaultAsync();
            if (maTk != null) NhacGianHang(maTk.Value, $"Danh mục \"{dm.TenDanhMuc}\" bị ẩn", "Lý do: " + b!.LyDo!.Trim());
            await _db.SaveChangesAsync();
            return Ok(new { daAn = true });
        }

        [HttpPut("danh-muc/{id:int}/hien")]
        public async Task<IActionResult> HienDanhMuc(int id)
        {
            var chan = await ChanAsync("ThongBao"); if (chan != null) return chan;
            var dm = await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaDanhMuc == id);
            if (dm == null) return Loi("Không tìm thấy danh mục.", 404);
            dm.DaAn = false; await _db.SaveChangesAsync();
            return Ok(new { daAn = false });
        }

        [HttpDelete("danh-muc/{id:int}")]
        public async Task<IActionResult> XoaDanhMuc(int id, [FromQuery] string? lyDo)
        {
            var chan = await ChanAsync("ThongBao"); if (chan != null) return chan;
            var dm = await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaDanhMuc == id);
            if (dm == null) return Loi("Không tìm thấy danh mục.", 404);
            if (string.IsNullOrWhiteSpace(lyDo)) return Loi("Bắt buộc nhập lý do xóa danh mục.");
            if (await _db.MonAns.AnyAsync(m => m.MaDanhMuc == id)) return Loi("Danh mục còn món ăn — hãy ẩn danh mục thay vì xóa.", 409);
            if (await _db.KhuyenMaiDanhMucs.AnyAsync(k => k.MaDanhMuc == id)) return Loi("Danh mục đang dùng trong khuyến mãi — hãy ẩn thay vì xóa.", 409);
            var maTk = await _db.GianHangs.Where(g => g.MaGianHang == dm.MaGianHang).Select(g => (int?)g.MaTK).FirstOrDefaultAsync();
            if (maTk != null) NhacGianHang(maTk.Value, $"Danh mục \"{dm.TenDanhMuc}\" đã bị xóa", "Lý do: " + lyDo.Trim());
            _db.DanhMucs.Remove(dm);
            await _db.SaveChangesAsync();
            return Ok(new { daXoa = true });
        }

        // ------------------------------------------------------------------ 5. MÓN ĂN (kiểm soát vi phạm)
        [HttpGet("mon-an")]
        public async Task<IActionResult> MonAns(int? maGianHang, string? q, bool? daAn)
        {
            var query = _db.MonAns.AsNoTracking().AsQueryable();
            if (maGianHang != null) query = query.Where(m => m.DanhMuc!.MaGianHang == maGianHang);
            if (!string.IsNullOrWhiteSpace(q)) { q = q.Trim(); query = query.Where(m => m.TenMon.Contains(q) || (m.MoTa != null && m.MoTa.Contains(q)) || m.DanhMuc!.GianHang!.TenCuaHang.Contains(q)); }
            if (daAn == true) query = query.Where(m => m.LyDoAn != null);
            return Ok(await query.OrderByDescending(m => m.MaMonAn).Take(200).Select(m => new
            {
                m.MaMonAn, m.TenMon, m.Gia, m.MoTa, m.HinhAnh, m.TinhTrang, m.LyDoAn,
                tenDanhMuc = m.DanhMuc != null ? m.DanhMuc.TenDanhMuc : "",
                maGianHang = m.DanhMuc != null ? m.DanhMuc.MaGianHang : 0,
                tenGianHang = m.DanhMuc != null && m.DanhMuc.GianHang != null ? m.DanhMuc.GianHang.TenCuaHang : "",
            }).ToListAsync());
        }

        [HttpPut("mon-an/{id:int}/an")]
        public async Task<IActionResult> AnMon(int id, [FromBody] AdminLyDoReq? b)
        {
            var chan = await ChanAsync("ThongBao"); if (chan != null) return chan;
            var m = await _db.MonAns.Include(x => x.DanhMuc).ThenInclude(d => d!.GianHang).FirstOrDefaultAsync(x => x.MaMonAn == id);
            if (m == null) return Loi("Không tìm thấy món.", 404);
            if (string.IsNullOrWhiteSpace(b?.LyDo)) return Loi("Bắt buộc nhập lý do ẩn món.");
            m.TinhTrang = "TamNgung"; m.LyDoAn = b!.LyDo!.Trim();
            if (m.DanhMuc?.GianHang != null) NhacGianHang(m.DanhMuc.GianHang.MaTK, $"Món \"{m.TenMon}\" bị ẩn", "Lý do: " + m.LyDoAn);
            await _db.SaveChangesAsync();
            return Ok(new { tinhTrang = m.TinhTrang });
        }

        [HttpPut("mon-an/{id:int}/hien")]
        public async Task<IActionResult> HienMon(int id)
        {
            var chan = await ChanAsync("ThongBao"); if (chan != null) return chan;
            var m = await _db.MonAns.FirstOrDefaultAsync(x => x.MaMonAn == id);
            if (m == null) return Loi("Không tìm thấy món.", 404);
            m.TinhTrang = "ConHang"; m.LyDoAn = null; await _db.SaveChangesAsync();
            return Ok(new { tinhTrang = m.TinhTrang });
        }

        // ------------------------------------------------------------------ 6. ĐƠN HÀNG: tìm, điều tra, can thiệp
        [HttpGet("don-hang/tim")]
        public async Task<IActionResult> TimDon(string? q, string? trangThai, string? thanhToan, DateTime? tu, DateTime? den, string? bo, int trang = 1, int? maKH = null)
        {
            var query = _db.DonHangs.AsNoTracking().AsQueryable();
            if (maKH != null) query = query.Where(d => d.MaKH == maKH.Value);   // v47f: lịch sử đơn của một khách
            if (!string.IsNullOrWhiteSpace(q))
            {
                q = q.Trim();
                if (int.TryParse(q.TrimStart('#'), out var ma)) query = query.Where(d => d.MaDonHang == ma);
                else query = query.Where(d => d.KhachHang!.HoTen.Contains(q) || d.KhachHang!.SDT.Contains(q) || d.GianHang!.TenCuaHang.Contains(q)
                    || (d.GiaoHang != null && d.GiaoHang.TaiXe!.HoTen.Contains(q)));
            }
            if (!string.IsNullOrEmpty(trangThai)) query = query.Where(d => d.TrangThai == trangThai);
            if (!string.IsNullOrEmpty(thanhToan)) query = query.Where(d => d.ThanhToan != null && d.ThanhToan.HinhThuc == thanhToan);
            if (tu != null) query = query.Where(d => d.NgayDat >= tu.Value.Date);
            if (den != null) query = query.Where(d => d.NgayDat < den.Value.Date.AddDays(1));
            var tre = (int)await _cauHinh.LaySoAsync("Don.DuKienPhut", 45) + (int)await _cauHinh.LaySoAsync("Don.TreSauPhut", 30);
            if (bo == "tre") { var moc = DateTime.Now.AddMinutes(-tre); query = query.Where(d => d.TrangThai != "DaGiao" && d.TrangThai != "DaHuy" && d.NgayDat < moc); }
            else if (bo == "that-bai") query = query.Where(d => d.GiaoHang != null && d.GiaoHang.TrangThai == "GiaoThatBai");
            else if (bo == "khieu-nai")
            { var maDons = _db.PhanHois.Where(p => p.MaDonHang != null && p.Loai == "KhieuNai").Select(p => p.MaDonHang!.Value); query = query.Where(d => maDons.Contains(d.MaDonHang)); }

            trang = Math.Max(1, trang);
            var ds = await query.OrderByDescending(d => d.NgayDat).Skip((trang - 1) * 50).Take(50).Select(d => new
            {
                d.MaDonHang, d.NgayDat, d.TrangThai, d.TongTien,
                khach = d.KhachHang != null ? d.KhachHang.HoTen : "",
                sdtKhach = d.KhachHang != null ? d.KhachHang.SDT : "",
                gianHang = d.GianHang != null ? d.GianHang.TenCuaHang : "",
                taiXe = d.GiaoHang != null && d.GiaoHang.TaiXe != null ? d.GiaoHang.TaiXe.HoTen : "",
                hinhThucTT = d.ThanhToan != null ? d.ThanhToan.HinhThuc : "",
                trangThaiTT = d.ThanhToan != null ? d.ThanhToan.TrangThai : "",
            }).ToListAsync();
            var now = DateTime.Now;
            return Ok(ds.Select(d => new
            {
                d.MaDonHang, d.NgayDat, d.TrangThai, d.TongTien, d.khach, d.sdtKhach, d.gianHang, d.taiXe, d.hinhThucTT, d.trangThaiTT,
                tre = !TrangThaiCuoi.Contains(d.TrangThai) && (now - d.NgayDat).TotalMinutes > tre,
            }));
        }

        [HttpGet("don-hang/{id:int}/chi-tiet")]
        public async Task<IActionResult> ChiTietDon(int id)
        {
            var don = await _db.DonHangs.AsNoTracking().Include(d => d.KhachHang).Include(d => d.GianHang).Include(d => d.KhuyenMaiApDung)
                .Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .Include(d => d.ThanhToan).Include(d => d.GiaoHang).ThenInclude(g => g!.TaiXe)
                .FirstOrDefaultAsync(d => d.MaDonHang == id);
            if (don == null) return Loi("Không tìm thấy đơn hàng.", 404);
            var lichSu = await _db.LichSuTrangThaiDons.AsNoTracking().Where(l => l.MaDonHang == id).OrderBy(l => l.ThoiGian).ToListAsync();
            var dieuPhoi = await _db.DieuPhoiLogs.AsNoTracking().Where(l => l.MaDonHang == id).OrderBy(l => l.ThoiGian).ToListAsync();
            var hoanTien = await _db.YeuCauHoanTiens.AsNoTracking().Where(y => y.MaDonHang == id).OrderByDescending(y => y.NgayTao).ToListAsync();
            var phanHoi = await _db.PhanHois.AsNoTracking().Where(p => p.MaDonHang == id).OrderByDescending(p => p.NgayGui).ToListAsync();
            var danhGia = await _db.DanhGias.AsNoTracking().Where(d => d.MaDonHang == id).ToListAsync();
            var g = don.GiaoHang; var t = don.ThanhToan;
            return Ok(new
            {
                don = new
                {
                    don.MaDonHang, don.NgayDat, don.TrangThai, don.TongTien, don.PhiGiaoHang, don.TienGiam, don.DiaChiGiaoHang, don.GhiChu, don.LyDoTuChoi,
                    don.SoLanSaiMa, don.KhoangCachKm, don.SanSangGiao, don.KhachXacNhanLuc,
                    khuyenMai = don.KhuyenMaiApDung != null ? don.KhuyenMaiApDung.MaCode : null,
                    khach = don.KhachHang?.HoTen, sdtKhach = don.KhachHang?.SDT,
                    gianHang = don.GianHang?.TenCuaHang, sdtGianHang = don.GianHang?.SDT,
                    taiXe = g?.TaiXe?.HoTen, sdtTaiXe = g?.TaiXe?.SDT,
                    laDonCuoi = TrangThaiCuoi.Contains(don.TrangThai),
                },
                mon = don.ChiTiets.Select(c => new { ten = c.MonAn?.TenMon ?? "(món đã xóa)", c.SoLuong, c.DonGia, c.TuyChon, c.GhiChu }),
                thanhToan = t == null ? null : new { t.HinhThuc, t.TrangThai, t.MaGiaoDich, t.NgayThanhToan, t.DaDoiSoat, t.MaGiaoDichHoan, t.NgayHoan, t.KetQuaHoan },
                giaoHang = g == null ? null : new { g.TrangThai, g.ThoiGianNhan, g.ThoiGianDenQuan, g.ThoiGianLayHang, g.ThoiGianGiao, g.LyDoThatBai, g.NguoiGayLoi, g.TienThuCOD, coAnhBangChung = !string.IsNullOrEmpty(g.AnhBangChung) },
                lichSu = lichSu.Select(l => new { l.ThoiGian, l.TuTrangThai, l.DenTrangThai, l.LyDo }),
                dieuPhoi = dieuPhoi.Select(l => new { l.ThoiGian, l.HanhDong, l.MaTaiXeCu, l.MaTaiXeMoi, l.LyDo }),
                hoanTien = hoanTien.Select(y => new { y.MaYeuCau, y.SoTien, y.TrangThai, y.LyDo, y.KetQua, y.NgayTao }),
                phanHoi = phanHoi.Select(p => new { p.MaPhanHoi, p.Loai, p.TieuDe, p.NoiDung, p.TrangThai, p.TraLoi, p.NgayGui }),
                danhGia = danhGia.Select(d => new { d.SoSao, d.NoiDung, d.SoSaoGiaoHang, d.DaAn, d.NgayDanhGia }),
            });
        }

        [HttpPut("don-hang/{id:int}/huy")]
        public async Task<IActionResult> HuyDon(int id, [FromBody] AdminLyDoReq? b)
        {
            var chan = await ChanAsync("DonHang"); if (chan != null) return chan;
            var don = await _db.DonHangs.Include(d => d.ThanhToan).FirstOrDefaultAsync(d => d.MaDonHang == id);
            if (don == null) return Loi("Không tìm thấy đơn hàng.", 404);
            var lyDo = (b?.LyDo ?? "").Trim();
            if (lyDo.Length < 5) return Loi("Bắt buộc nhập lý do can thiệp (ít nhất 5 ký tự).");
            if (TrangThaiCuoi.Contains(don.TrangThai)) return Loi("Đơn đã kết thúc, không thể hủy.", 409);

            var cu = don.TrangThai;
            don.TrangThai = "DaHuy";
            don.LyDoTuChoi = "[Quản trị] " + lyDo;
            await _db.SaveChangesAsync();
            var ls = await _db.LichSuTrangThaiDons.Where(l => l.MaDonHang == id && l.DenTrangThai == "DaHuy").OrderByDescending(l => l.ThoiGian).FirstOrDefaultAsync();
            if (ls != null) { ls.MaTK = MaTK; ls.LyDo = "[Quản trị] " + lyDo; }
            if (don.ThanhToan?.TrangThai == "DaThanhToan" && !await _db.YeuCauHoanTiens.AnyAsync(y => y.MaDonHang == id && y.TrangThai == "ChoDuyet"))
                _db.YeuCauHoanTiens.Add(new YeuCauHoanTien { MaDonHang = id, MaKH = don.MaKH, SoTien = don.TongTien, LyDo = "Quản trị hủy đơn: " + lyDo, Nguon = "QuanTri" });
            await _db.SaveChangesAsync();
            await TrangThaiDon.SauKhiHuyAsync(_db, don, lyDo);
            return Ok(new { thongDiep = $"Đã hủy đơn #{id} (từ trạng thái {cu})." });
        }

        [HttpPut("don-hang/{id:int}/mo-khoa-ma")]
        public async Task<IActionResult> MoKhoaMa(int id)
        {
            var chan = await ChanAsync("DonHang"); if (chan != null) return chan;
            var don = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == id);
            if (don == null) return Loi("Không tìm thấy đơn hàng.", 404);
            if (don.TrangThai != "DangGiao") return Loi("Chỉ đơn đang giao mới đổi mã.", 409);
            don.SoLanSaiMa = 0; don.MaXacNhanGiao = GiaoHangXuLy.TaoMa();
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã mở khóa và cấp mã xác nhận mới; khách xem mã mới trong đơn hàng." });
        }

        // ------------------------------------------------------------------ 7. THANH TOÁN & ĐỐI SOÁT
        [HttpGet("thanh-toan")]
        public async Task<IActionResult> ThanhToans(string? q, string? hinhThuc, string? trangThai, DateTime? tu, DateTime? den, bool chuaDoiSoat = false)
        {
            var query = _db.DonHangs.AsNoTracking().Where(d => d.ThanhToan != null);
            if (!string.IsNullOrWhiteSpace(q))
            {
                q = q.Trim(); var qs = q.TrimStart('#');
                query = query.Where(d => (d.ThanhToan!.MaGiaoDich != null && d.ThanhToan.MaGiaoDich.Contains(q)) || d.MaDonHang.ToString() == qs || d.KhachHang!.HoTen.Contains(q));
            }
            if (!string.IsNullOrEmpty(hinhThuc)) query = query.Where(d => d.ThanhToan!.HinhThuc == hinhThuc);
            if (!string.IsNullOrEmpty(trangThai)) query = query.Where(d => d.ThanhToan!.TrangThai == trangThai);
            if (tu != null) query = query.Where(d => d.NgayDat >= tu.Value.Date);
            if (den != null) query = query.Where(d => d.NgayDat < den.Value.Date.AddDays(1));
            if (chuaDoiSoat) query = query.Where(d => !d.ThanhToan!.DaDoiSoat && (d.ThanhToan.TrangThai == "DaThanhToan" || (d.ThanhToan.HinhThuc == "TienMat" && d.TrangThai == "DaGiao")));

            var ds = await query.OrderByDescending(d => d.NgayDat).Take(200).Select(d => new
            {
                maThanhToan = d.ThanhToan!.MaThanhToan, d.MaDonHang, d.NgayDat, d.TongTien, trangThaiDon = d.TrangThai,
                khach = d.KhachHang != null ? d.KhachHang.HoTen : "",
                gianHang = d.GianHang != null ? d.GianHang.TenCuaHang : "",
                hinhThuc = d.ThanhToan.HinhThuc, trangThai = d.ThanhToan.TrangThai, maGiaoDich = d.ThanhToan.MaGiaoDich,
                daDoiSoat = d.ThanhToan.DaDoiSoat, maGiaoDichHoan = d.ThanhToan.MaGiaoDichHoan, ngayHoan = d.ThanhToan.NgayHoan,
            }).ToListAsync();

            var cod = await _db.ThanhToans.Where(t => t.HinhThuc == "TienMat" && !t.DaDoiSoat)
                .Join(_db.DonHangs.Where(d => d.TrangThai == "DaGiao"), t => t.MaDonHang, d => d.MaDonHang, (t, d) => d.TongTien).ToListAsync();
            var choLau = await _db.ThanhToans.CountAsync(t => t.TrangThai == "ChoThanhToan" && t.HinhThuc != "TienMat"
                && _db.DonHangs.Any(d => d.MaDonHang == t.MaDonHang && d.NgayDat < DateTime.Now.AddHours(-1) && d.TrangThai != "DaHuy"));
            return Ok(new { tomTat = new { codSo = cod.Count, codTien = cod.Sum(), choThanhToanLau = choLau }, ds });
        }

        [HttpPut("thanh-toan/{maThanhToan:int}/doi-soat")]
        public async Task<IActionResult> DoiSoat(int maThanhToan)
        {
            var chan = await ChanAsync("ThanhToan"); if (chan != null) return chan;
            var t = await _db.ThanhToans.FirstOrDefaultAsync(x => x.MaThanhToan == maThanhToan);
            if (t == null) return Loi("Không tìm thấy giao dịch.", 404);
            t.DaDoiSoat = true; t.NgayDoiSoat = DateTime.Now;
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = $"Đã đối soát giao dịch của đơn #{t.MaDonHang}." });
        }

        [HttpPut("thanh-toan/doi-soat-tat-ca")]
        public async Task<IActionResult> DoiSoatTatCa()
        {
            var chan = await ChanAsync("ThanhToan"); if (chan != null) return chan;
            var ds = await _db.ThanhToans.Where(t => !t.DaDoiSoat && (t.TrangThai == "DaThanhToan" ||
                (t.HinhThuc == "TienMat" && _db.DonHangs.Any(d => d.MaDonHang == t.MaDonHang && d.TrangThai == "DaGiao")))).ToListAsync();
            foreach (var t in ds) { t.DaDoiSoat = true; t.NgayDoiSoat = DateTime.Now; }
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = $"Đã đối soát {ds.Count} giao dịch." });
        }

        [HttpPut("thanh-toan/{maThanhToan:int}/xac-nhan-chuyen-khoan")]
        public async Task<IActionResult> XacNhanChuyenKhoan(int maThanhToan, [FromBody] AdminMaGdReq? b)
        {
            var chan = await ChanAsync("ThanhToan"); if (chan != null) return chan;
            var t = await _db.ThanhToans.FirstOrDefaultAsync(x => x.MaThanhToan == maThanhToan && x.HinhThuc == "ChuyenKhoan");
            if (t == null) return Loi("Không tìm thấy giao dịch chuyển khoản.", 404);
            if (t.TrangThai != "DaThanhToan")
            {
                t.TrangThai = "DaThanhToan"; t.NgayThanhToan = DateTime.Now;
                if (!string.IsNullOrWhiteSpace(b?.MaGiaoDich)) t.MaGiaoDich = b!.MaGiaoDich!.Trim();
                await _db.SaveChangesAsync();
            }
            return Ok(new { thongDiep = $"Đã xác nhận nhận tiền chuyển khoản đơn #{t.MaDonHang}." });
        }

        // ------------------------------------------------------------------ 8. HOÀN TIỀN
        [HttpGet("hoan-tien")]
        public async Task<IActionResult> HoanTiens(string? trangThai)
        {
            var q = _db.YeuCauHoanTiens.AsNoTracking().AsQueryable();
            if (!string.IsNullOrEmpty(trangThai)) q = q.Where(y => y.TrangThai == trangThai);
            var ds = await q.OrderBy(y => y.TrangThai == "ChoDuyet" ? 0 : 1).ThenByDescending(y => y.NgayTao).Take(200).ToListAsync();
            var ids = ds.Select(y => y.MaDonHang).ToList();
            var don = await _db.DonHangs.AsNoTracking().Where(d => ids.Contains(d.MaDonHang))
                .Select(d => new { d.MaDonHang, d.TongTien, khach = d.KhachHang != null ? d.KhachHang.HoTen : "", hinhThuc = d.ThanhToan != null ? d.ThanhToan.HinhThuc : "", trangThaiTT = d.ThanhToan != null ? d.ThanhToan.TrangThai : "" })
                .ToDictionaryAsync(d => d.MaDonHang);
            var cap = await CapQuyenAsync();
            return Ok(new
            {
                nguong = await _cauHinh.LaySoAsync("HoanTien.NguongQuanLy", 200000),
                coQuyenHoan = await QuyenAdmin.CoAsync(_db, MaTK, "HoanTien"),
                laAdminTong = cap == "SuperAdmin",
                ds = ds.Select(y =>
                {
                    don.TryGetValue(y.MaDonHang, out var d);
                    return new { y.MaYeuCau, y.MaDonHang, y.SoTien, y.LyDo, y.Nguon, y.TrangThai, y.KetQua, y.NgayTao, y.NgayXuLy,
                        khach = d?.khach ?? "", tongDon = d?.TongTien ?? 0, hinhThucTT = d?.hinhThuc ?? "", trangThaiTT = d?.trangThaiTT ?? "" };
                }),
            });
        }

        [HttpPost("hoan-tien")]
        public async Task<IActionResult> TaoHoanTien([FromBody] AdminHoanTienReq b)
        {
            // Mọi quản trị viên được tiếp nhận yêu cầu; chỉ việc duyệt mới cần quyền (giống Web).
            var lyDo = (b.LyDo ?? "").Trim();
            var don = await _db.DonHangs.Include(d => d.ThanhToan).FirstOrDefaultAsync(d => d.MaDonHang == b.MaDonHang);
            if (don == null) return Loi("Không tìm thấy đơn hàng.", 404);
            if (lyDo.Length < 5) return Loi("Nhập lý do hoàn tiền (ít nhất 5 ký tự).");
            var soTien = b.SoTien ?? don.TongTien;
            if (don.ThanhToan == null || don.ThanhToan.TrangThai != "DaThanhToan") return Loi("Đơn chưa có thanh toán thành công nên không đủ điều kiện hoàn tiền.");
            if (don.ThanhToan.HinhThuc == "TienMat") return Loi("Đơn thanh toán tiền mặt không hoàn qua hệ thống.");
            if (soTien <= 0 || soTien > don.TongTien) return Loi("Số tiền hoàn phải lớn hơn 0 và không vượt tổng đơn.");
            if (await _db.YeuCauHoanTiens.AnyAsync(y => y.MaDonHang == don.MaDonHang && (y.TrangThai == "ChoDuyet" || y.TrangThai == "DaDuyet")))
                return Loi("Đơn này đã có yêu cầu hoàn tiền đang chờ hoặc đã được duyệt.", 409);
            _db.YeuCauHoanTiens.Add(new YeuCauHoanTien { MaDonHang = don.MaDonHang, MaKH = don.MaKH, SoTien = soTien, LyDo = lyDo, Nguon = "QuanTri" });
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã tạo yêu cầu hoàn tiền, chờ duyệt." });
        }

        [HttpPut("hoan-tien/{id:int}/duyet")]
        public async Task<IActionResult> DuyetHoanTien(int id, [FromBody] AdminKetQuaReq? b)
        {
            var y = await _db.YeuCauHoanTiens.FirstOrDefaultAsync(x => x.MaYeuCau == id);
            if (y == null) return Loi("Không tìm thấy yêu cầu.", 404);
            if (y.TrangThai != "ChoDuyet") return Loi("Yêu cầu đã được xử lý.", 409);

            var cap = await CapQuyenAsync();
            var nguong = await _cauHinh.LaySoAsync("HoanTien.NguongQuanLy", 200000);
            var coQuyen = cap == "SuperAdmin" || await QuyenAdmin.CoAsync(_db, MaTK, "HoanTien");
            if (!coQuyen) return Loi("Bạn không có quyền duyệt hoàn tiền.", 403);
            if (cap != "SuperAdmin" && y.SoTien > nguong) return Loi($"Hoàn tiền trên {nguong:N0}đ cần Admin tổng duyệt.", 403);

            var don = await _db.DonHangs.Include(d => d.ThanhToan).FirstAsync(d => d.MaDonHang == y.MaDonHang);
            var tt = don.ThanhToan;
            if (tt == null || tt.TrangThai != "DaThanhToan") return Loi("Giao dịch không còn ở trạng thái Đã thanh toán.", 409);

            var maTay = b?.MaHoanThuCong;
            string ghiChuCong;
            if (tt.HinhThuc == "VNPay" && string.IsNullOrWhiteSpace(maTay))
            {
                var ip = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "127.0.0.1";
                var kq = await _vnPay.RefundAsync(don.MaDonHang, (long)y.SoTien, (long)don.TongTien, tt.MaGiaoDich ?? "", tt.NgayGiaoDichCong ?? "", User.Identity?.Name ?? ("TK" + MaTK), y.LyDo, ip);
                tt.KetQuaHoan = kq.ThongDiep;
                if (!kq.Ok)
                {
                    await _db.SaveChangesAsync();
                    return Loi("Chưa hoàn được qua cổng: " + kq.ThongDiep + " Nếu đã hoàn thủ công trên cổng merchant, nhập mã giao dịch hoàn rồi duyệt lại.");
                }
                tt.MaGiaoDichHoan = kq.MaGiaoDichHoan; ghiChuCong = kq.ThongDiep;
            }
            else
            {
                if (tt.HinhThuc != "TienMat" && string.IsNullOrWhiteSpace(maTay))
                    return Loi($"Cổng {tt.HinhThuc} chưa tích hợp hoàn tiền tự động: hoàn trên cổng rồi nhập mã giao dịch hoàn.");
                tt.MaGiaoDichHoan = maTay?.Trim(); ghiChuCong = "Hoàn thủ công, mã: " + tt.MaGiaoDichHoan;
                tt.KetQuaHoan = ghiChuCong;
            }

            y.TrangThai = "DaDuyet"; y.MaTKXuLy = MaTK; y.NgayXuLy = DateTime.Now;
            y.KetQua = (string.IsNullOrWhiteSpace(b?.KetQua) ? "Đã duyệt hoàn tiền" : b!.KetQua!.Trim()) + " — " + ghiChuCong;
            tt.NgayHoan = DateTime.Now;
            tt.TrangThai = "DaHoanTien";
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = $"Đã duyệt hoàn {y.SoTien:N0}đ cho đơn #{y.MaDonHang}. {ghiChuCong}" });
        }

        [HttpPut("hoan-tien/{id:int}/tu-choi")]
        public async Task<IActionResult> TuChoiHoanTien(int id, [FromBody] AdminKetQuaReq? b)
        {
            var chan = await ChanAsync("HoanTien"); if (chan != null) return chan;
            var y = await _db.YeuCauHoanTiens.FirstOrDefaultAsync(x => x.MaYeuCau == id);
            if (y == null) return Loi("Không tìm thấy yêu cầu.", 404);
            if (string.IsNullOrWhiteSpace(b?.KetQua)) return Loi("Nhập lý do từ chối.");
            if (y.TrangThai != "ChoDuyet") return Loi("Yêu cầu đã được xử lý.", 409);
            y.TrangThai = "TuChoi"; y.MaTKXuLy = MaTK; y.NgayXuLy = DateTime.Now; y.KetQua = b!.KetQua!.Trim();
            if (y.MaKH != null)
            {
                var maTk = await _db.KhachHangs.Where(k => k.MaKH == y.MaKH).Select(k => (int?)k.MaTK).FirstOrDefaultAsync();
                if (maTk != null) _db.ThongBaos.Add(new ThongBao { MaTK = maTk.Value, Loai = "HeThong", TieuDe = "Yêu cầu hoàn tiền bị từ chối", NoiDung = $"Đơn #{y.MaDonHang}: {y.KetQua}", MaThamChieu = y.MaDonHang.ToString() });
            }
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã từ chối yêu cầu hoàn tiền." });
        }

        // ------------------------------------------------------------------ 9. ĐÁNH GIÁ: kiểm duyệt
        [HttpGet("danh-gia")]
        public async Task<IActionResult> DanhGias(string tab = "bao-cao", int? sao = null)
        {
            if (tab == "bao-cao")
            {
                var bc = await _db.BaoCaoDanhGias.AsNoTracking().Where(b => b.TrangThai == "ChoXuLy").OrderBy(b => b.NgayTao).Take(200).ToListAsync();
                var ids = bc.Select(b => b.MaDanhGia).Distinct().ToList();
                var dg = await _db.DanhGias.AsNoTracking().Where(d => ids.Contains(d.MaDanhGia)).ToDictionaryAsync(d => d.MaDanhGia);
                var ghIds = dg.Values.Select(d => d.MaGianHang).Distinct().ToList();
                var quan = await _db.GianHangs.AsNoTracking().Where(g => ghIds.Contains(g.MaGianHang)).ToDictionaryAsync(g => g.MaGianHang, g => g.TenCuaHang);
                var dem = await _db.BaoCaoDanhGias.AsNoTracking().Where(b => ids.Contains(b.MaDanhGia)).GroupBy(b => b.MaDanhGia).Select(g => new { g.Key, N = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.N);
                return Ok(bc.Select(b =>
                {
                    dg.TryGetValue(b.MaDanhGia, out var d);
                    return new { maBaoCao = (int?)b.MaBaoCao, b.MaDanhGia, lyDoBaoCao = b.LyDo, b.NgayTao, soBaoCao = dem.TryGetValue(b.MaDanhGia, out var n) ? n : 1,
                        soSao = d?.SoSao ?? 0, noiDung = d?.NoiDung ?? "", anhDanhGia = d?.AnhDanhGia ?? "", daAn = d?.DaAn ?? false, lyDoAn = d?.LyDoAn,
                        tenGianHang = d != null && quan.TryGetValue(d.MaGianHang, out var t) ? t : "", tenKhach = "" };
                }));
            }
            var q = _db.DanhGias.AsNoTracking().AsQueryable();
            if (sao != null) q = q.Where(d => d.SoSao == sao);
            var ds = await q.OrderByDescending(d => d.NgayDanhGia).Take(200).ToListAsync();
            var gs = ds.Select(d => d.MaGianHang).Distinct().ToList();
            var ks = ds.Select(d => d.MaKH).Distinct().ToList();
            var tenQuan = await _db.GianHangs.AsNoTracking().Where(g => gs.Contains(g.MaGianHang)).ToDictionaryAsync(g => g.MaGianHang, g => g.TenCuaHang);
            var tenKhach = await _db.KhachHangs.AsNoTracking().Where(k => ks.Contains(k.MaKH)).ToDictionaryAsync(k => k.MaKH, k => k.HoTen);
            return Ok(ds.Select(d => new
            {
                maBaoCao = (int?)null, d.MaDanhGia, lyDoBaoCao = (string?)null, NgayTao = d.NgayDanhGia, soBaoCao = 0,
                soSao = d.SoSao, noiDung = d.NoiDung ?? "", anhDanhGia = d.AnhDanhGia ?? "", d.DaAn, d.LyDoAn,
                tenGianHang = tenQuan.TryGetValue(d.MaGianHang, out var a) ? a : "",
                tenKhach = tenKhach.TryGetValue(d.MaKH, out var k) ? k : "",
            }));
        }

        [HttpPut("danh-gia/{maDanhGia:int}/an")]
        public async Task<IActionResult> AnDanhGia(int maDanhGia, [FromBody] AdminLyDoReq? b)
        {
            var chan = await ChanAsync("DanhGia"); if (chan != null) return chan;
            var dg = await _db.DanhGias.FirstOrDefaultAsync(d => d.MaDanhGia == maDanhGia);
            if (dg == null) return Loi("Không tìm thấy đánh giá.", 404);
            if (string.IsNullOrWhiteSpace(b?.LyDo)) return Loi("Nhập lý do ẩn đánh giá.");
            dg.DaAn = true; dg.LyDoAn = b!.LyDo!.Trim();
            foreach (var bc in await _db.BaoCaoDanhGias.Where(x => x.MaDanhGia == maDanhGia && x.TrangThai == "ChoXuLy").ToListAsync())
            { bc.TrangThai = "DaXuLy"; bc.KetQua = "Đã ẩn đánh giá: " + dg.LyDoAn; bc.NgayXuLy = DateTime.Now; }
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã ẩn đánh giá và đóng các báo cáo liên quan." });
        }

        [HttpPut("danh-gia/{maDanhGia:int}/hien")]
        public async Task<IActionResult> HienDanhGia(int maDanhGia)
        {
            var chan = await ChanAsync("DanhGia"); if (chan != null) return chan;
            var dg = await _db.DanhGias.FirstOrDefaultAsync(d => d.MaDanhGia == maDanhGia);
            if (dg == null) return Loi("Không tìm thấy đánh giá.", 404);
            dg.DaAn = false; dg.LyDoAn = null; await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã hiện lại đánh giá." });
        }

        [HttpPut("danh-gia/bao-cao/{maBaoCao:int}/giu")]
        public async Task<IActionResult> GiuDanhGia(int maBaoCao, [FromBody] AdminLyDoReq? b)
        {
            var chan = await ChanAsync("DanhGia"); if (chan != null) return chan;
            var bc = await _db.BaoCaoDanhGias.FirstOrDefaultAsync(x => x.MaBaoCao == maBaoCao);
            if (bc == null) return Loi("Không tìm thấy báo cáo.", 404);
            bc.TrangThai = "DaXuLy"; bc.NgayXuLy = DateTime.Now;
            bc.KetQua = string.IsNullOrWhiteSpace(b?.LyDo) ? "Đánh giá phù hợp, giữ nguyên" : b!.LyDo!.Trim();
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã bác báo cáo, giữ nguyên đánh giá." });
        }

        // ------------------------------------------------------------------ 10. ĐIỀU PHỐI TÀI XẾ
        [HttpGet("dieu-phoi")]
        public async Task<IActionResult> DieuPhoi()
        {
            await GiaoHangXuLy.XuLyQuaHanNhanDonAsync(_db, (int)await _cauHinh.LaySoAsync("Don.TaiXePhanHoiPhut", GiaoHangXuLy.PhutPhanHoiTaiXe));
            var canGiao = await _db.DonHangs.AsNoTracking().Where(d => d.TrangThai == "DaXacNhan" && d.MaTaiXe == null).OrderByDescending(d => d.SanSangGiao).ThenBy(d => d.NgayDat)
                .Select(d => new { d.MaDonHang, d.NgayDat, d.TongTien, d.DiaChiGiaoHang, d.TrangThai, d.SanSangGiao, d.ThoiGianSanSang, quanTuGiao = d.NguonGiao == "Quan", gianHang = d.GianHang != null ? d.GianHang.TenCuaHang : "", taiXe = "", maTaiXe = (int?)null }).Take(100).ToListAsync();
            var canTay = await PhanPhoiDonXuLy.DonCanPhanCongTayAsync(_db, canGiao.Select(d => d.MaDonHang).ToList());
            var dangGiao = await _db.DonHangs.AsNoTracking().Where(d => (d.TrangThai == "DangGiao" || d.TrangThai == "DaXacNhan") && d.MaTaiXe != null).OrderBy(d => d.NgayDat)
                .Select(d => new { d.MaDonHang, d.NgayDat, d.TongTien, d.DiaChiGiaoHang, d.TrangThai, gianHang = d.GianHang != null ? d.GianHang.TenCuaHang : "",
                    taiXe = d.GiaoHang != null && d.GiaoHang.TaiXe != null ? d.GiaoHang.TaiXe.HoTen : "", maTaiXe = d.MaTaiXe }).Take(100).ToListAsync();
            var dangBan = await _db.DonHangs.Where(d => (d.TrangThai == "DangGiao" || d.TrangThai == "DaXacNhan") && d.MaTaiXe != null)
                .GroupBy(d => d.MaTaiXe!.Value).Select(g => new { Ma = g.Key, So = g.Count() }).ToDictionaryAsync(x => x.Ma, x => x.So);
            var tx = await _db.TaiXes.AsNoTracking().Where(t => t.MaGianHang == null && t.TrangThaiDuyet == "DaDuyet" && _db.TaiKhoans.Any(k => k.MaTK == t.MaTK && k.TrangThai))
                .OrderBy(t => t.TrangThai == "SanSang" ? 0 : 1).ThenBy(t => t.HoTen)
                .Select(t => new { t.MaTaiXe, t.HoTen, t.SDT, t.PhuongTien, t.BienSo, t.TrangThai, t.KhuVucHoatDong }).ToListAsync();
            var log = await _db.DieuPhoiLogs.AsNoTracking().OrderByDescending(l => l.ThoiGian).Take(20).ToListAsync();
            return Ok(new
            {
                quanTriDieuPhoi = await GiaoHangXuLy.QuanTriDieuPhoiAsync(_db),
                phanPhoi = new { tuDong = await PhanPhoiDonXuLy.DangBatAsync(_db), lanChayCuoi = PhanPhoiDonXuLy.LanChayCuoi, ketQua = PhanPhoiDonXuLy.KetQuaCuoi, tongDeNghi = PhanPhoiDonXuLy.TongDeNghi },
                deNghi = await _db.DeNghiGiaoDons.AsNoTracking().Where(o => o.TrangThai == "ChoPhanHoi")
                    .Select(o => new { o.MaDeNghi, o.MaDonHang, o.MaTaiXe, taiXe = _db.TaiXes.Where(t => t.MaTaiXe == o.MaTaiXe).Select(t => t.HoTen).FirstOrDefault(), o.Vong, o.KmDenQuan, o.HetHanLuc }).ToListAsync(),
                canGiao = canGiao.OrderByDescending(d => canTay.Contains(d.MaDonHang)).Select(d => new { d.MaDonHang, d.NgayDat, d.TongTien, d.DiaChiGiaoHang, d.TrangThai, d.SanSangGiao, d.ThoiGianSanSang, d.quanTuGiao, d.gianHang, d.taiXe, d.maTaiXe, canPhanCongTay = canTay.Contains(d.MaDonHang) }),
                soCanPhanCongTay = canTay.Count,
                dangGiao,
                taiXes = tx.Select(t => new { t.MaTaiXe, t.HoTen, t.SDT, t.PhuongTien, t.BienSo, t.TrangThai, t.KhuVucHoatDong, soDonDangGiao = dangBan.TryGetValue(t.MaTaiXe, out var n) ? n : 0 }),
                log = log.Select(l => new { l.ThoiGian, l.MaDonHang, l.HanhDong, l.MaTaiXeCu, l.MaTaiXeMoi, l.LyDo }),
            });
        }

        [HttpPut("dieu-phoi/{id:int}/phan-cong")]
        public async Task<IActionResult> PhanCong(int id, [FromBody] AdminPhanCongReq b)
        {
            var chan = await ChanAsync("DonHang"); if (chan != null) return chan;
            var lyDo = (b.LyDo ?? "").Trim();
            if (lyDo.Length < 3) return Loi("Vui lòng nhập lý do phân công/đổi tài xế.");
            var don = await _db.DonHangs.Include(d => d.GiaoHang).FirstOrDefaultAsync(d => d.MaDonHang == id);
            var tx = await _db.TaiXes.FirstOrDefaultAsync(t => t.MaTaiXe == b.MaTaiXe && t.TrangThaiDuyet == "DaDuyet");
            if (don == null || tx == null) return Loi("Không tìm thấy đơn hàng hoặc tài xế.", 404);
            if (don.TrangThai != "DaXacNhan" && don.TrangThai != "DangGiao") return Loi("Chỉ phân công cho đơn đã xác nhận hoặc đang giao.", 409);
            if (!await _db.TaiKhoans.AnyAsync(k => k.MaTK == tx.MaTK && k.TrangThai)) return Loi("Tài xế này đang bị khóa.", 409);
            if (tx.MaGianHang != null && tx.MaGianHang != don.MaGianHang) return Loi("Tài xế này thuộc quán khác, không phân công được cho đơn của quán này.", 409);
            // v86: so sánh-và-thay — không ghi đè khi đơn vừa đổi tài xế/trạng thái
            if (!await PhanPhoiDonXuLy.ChiemDonChoQuanTriAsync(_db, id, b.MaTaiXe, don.MaTaiXe))
                return Loi("Đơn vừa thay đổi (đã có người nhận hoặc đổi trạng thái). Hãy tải lại rồi thao tác lại.", 409);
            don.NguonGiao = tx.MaGianHang != null ? "Quan" : "Ngoai";
            var ttNhap = tx.MaGianHang != null ? NguonGiaoXuLy.ThuNhapNoiBo : "ChoThanhToan";

            var cu = don.MaTaiXe;
            if (don.GiaoHang != null) { don.GiaoHang.MaTaiXe = b.MaTaiXe; don.GiaoHang.TrangThai = "DaNhan"; don.GiaoHang.ThoiGianNhan = DateTime.Now; don.GiaoHang.TrangThaiThuNhap = ttNhap; }
            else _db.GiaoHangs.Add(new GiaoHang { MaDonHang = id, MaTaiXe = b.MaTaiXe, TrangThai = "DaNhan", ThoiGianNhan = DateTime.Now, TrangThaiThuNhap = ttNhap });
            don.MaTaiXe = b.MaTaiXe;
            don.TrangThai = "DaXacNhan";
            tx.TrangThai = "DangGiao";
            _db.DieuPhoiLogs.Add(new DieuPhoiLog { MaDonHang = id, HanhDong = cu == null ? "PhanCong" : "DoiTaiXe", MaTaiXeCu = cu, MaTaiXeMoi = b.MaTaiXe, LyDo = lyDo, MaTK = MaTK });
            _db.ThongBaos.Add(new ThongBao { MaTK = tx.MaTK, Loai = "DonHang", TieuDe = "Bạn được phân công đơn mới", NoiDung = $"Đơn #{id} được quản trị phân công cho bạn. Lý do: {lyDo}", MaThamChieu = id.ToString() });
            if (cu != null && cu != b.MaTaiXe)
            {
                var maTkCu = await _db.TaiXes.Where(t => t.MaTaiXe == cu).Select(t => t.MaTK).FirstOrDefaultAsync();
                if (maTkCu != 0) _db.ThongBaos.Add(new ThongBao { MaTK = maTkCu, Loai = "DonHang", TieuDe = "Đơn đã được chuyển cho tài xế khác", NoiDung = $"Đơn #{id} đã được quản trị chuyển đi. Lý do: {lyDo}", MaThamChieu = id.ToString() });
            }
            await _db.SaveChangesAsync();
            if (cu != null && cu != b.MaTaiXe) { await GiaoHangXuLy.GiaiPhongTaiXeAsync(_db, cu, id); await _db.SaveChangesAsync(); }
            return Ok(new { thongDiep = $"Đã giao đơn #{id} cho {tx.HoTen}." });
        }

        [HttpPut("dieu-phoi/{id:int}/go-tai-xe")]
        public async Task<IActionResult> GoTaiXe(int id, [FromBody] AdminLyDoReq? b)
        {
            var chan = await ChanAsync("DonHang"); if (chan != null) return chan;
            var lyDo = (b?.LyDo ?? "").Trim();
            if (lyDo.Length < 3) return Loi("Vui lòng nhập lý do.");
            var don = await _db.DonHangs.Include(d => d.GiaoHang).FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe != null && (d.TrangThai == "DangGiao" || d.TrangThai == "DaXacNhan"));
            if (don == null) return Loi("Đơn không có tài xế để gỡ.", 404);
            var cu = don.MaTaiXe;
            if (don.GiaoHang != null) _db.GiaoHangs.Remove(don.GiaoHang);
            don.MaTaiXe = null; don.TrangThai = "DaXacNhan";
            if (cu != null && !await _db.TaiXeTuChoiDons.AnyAsync(r => r.MaDonHang == id && r.MaTaiXe == cu))
                _db.TaiXeTuChoiDons.Add(new TaiXeTuChoiDon { MaDonHang = id, MaTaiXe = cu.Value, LyDo = "Quản trị gỡ: " + lyDo });   // v86: không đề nghị lại cho tài xế vừa bị gỡ
            _db.DieuPhoiLogs.Add(new DieuPhoiLog { MaDonHang = id, HanhDong = "GoTaiXe", MaTaiXeCu = cu, LyDo = lyDo, MaTK = MaTK });
            await _db.SaveChangesAsync();
            await GiaoHangXuLy.GiaiPhongTaiXeAsync(_db, cu, id); await _db.SaveChangesAsync();
            PhanPhoiDonXuLy.DanhThucNgay();
            return Ok(new { thongDiep = $"Đã gỡ tài xế khỏi đơn #{id}, đơn trở lại danh sách chờ nhận." });
        }

        // ---- v86: phân phối đơn tự động — phân tích tài xế, tìm lại, đề nghị đang chờ ----
        /// <summary>Bảng phân tích: mọi tài xế đối với một đơn — ai đủ điều kiện (kèm điểm/khoảng cách/thời gian đến quán) và ai bị loại (kèm lý do).</summary>
        [HttpGet("dieu-phoi/{id:int}/phan-tich")]
        public async Task<IActionResult> PhanTichTaiXe(int id)
        {
            var ds = await PhanPhoiDonXuLy.PhanTichChoDonAsync(_db, id);
            var de = await _db.DeNghiGiaoDons.AsNoTracking().Where(o => o.MaDonHang == id).OrderByDescending(o => o.TaoLuc).Take(15)
                .Select(o => new { o.MaDeNghi, o.MaTaiXe, o.Vong, o.TrangThai, o.KmDenQuan, o.TaoLuc, o.PhanHoiLuc, o.LyDoPhanHoi }).ToListAsync();
            return Ok(new
            {
                ungVien = ds.Select(x => new { x.MaTaiXe, x.HoTen, x.PhuongTien, x.TrangThai, x.Km, x.KmUocTinh, x.SoDonDangGiu, x.PhutDenQuan, x.CoThe, x.LyDo, x.Diem }),
                deNghi = de,
            });
        }

        /// <summary>Quản trị bắt hệ thống tìm lại tài xế: thu hồi đề nghị đang chờ, xóa danh sách "đã bỏ lỡ" để mở lượt mới (người đã từ chối vẫn bị loại).</summary>
        [HttpPut("dieu-phoi/{id:int}/tim-lai")]
        public async Task<IActionResult> TimLaiTaiXe(int id)
        {
            var chan = await ChanAsync("DonHang"); if (chan != null) return chan;
            await PhanPhoiDonXuLy.HuyDeNghiTheoDonAsync(_db, id, "Quản trị yêu cầu tìm lại tài xế");
            await _db.DeNghiGiaoDons.Where(o => o.MaDonHang == id && o.TrangThai == "HetHan").ExecuteUpdateAsync(s => s.SetProperty(o => o.TrangThai, "Huy"));
            await _db.SaveChangesAsync();
            PhanPhoiDonXuLy.DanhThucNgay();
            return Ok(new { thongDiep = $"Đã yêu cầu hệ thống tìm lại tài xế cho đơn #{id}." });
        }

        // ------------------------------------------------------------------ 11. CẤU HÌNH hệ thống
        [HttpGet("cau-hinh")]
        public async Task<IActionResult> CauHinh()
        {
            await _cauHinh.DamBaoMacDinhAsync();
            var db = await _db.CauHinhHeThongs.AsNoTracking().ToDictionaryAsync(c => c.Khoa);
            return Ok(new
            {
                coQuyenSua = await LaSuperAsync(),
                nhom = ChinhSachMeta.Nhom.Select(n => new
                {
                    n.Id, n.Icon, n.Ten, n.GhiChu,
                    muc = n.Muc.Select(m => new
                    {
                        m.Khoa, m.Nhan, nhom = n.Ten, icon = n.Icon, kieu = m.Kieu.ToString(), donVi = m.DonVi, m.MoTa, macDinh = m.MacDinh,
                        giaTri = db.TryGetValue(m.Khoa, out var c) ? c.GiaTri : m.MacDinh,
                        ngaySua = db.TryGetValue(m.Khoa, out var c2) ? (DateTime?)c2.NgaySua : null,
                    }),
                }),
            });
        }

        [HttpPut("cau-hinh")]
        public async Task<IActionResult> LuuCauHinh([FromBody] AdminCauHinhReq b)
        {
            var chan = await ChanSuperAsync(); if (chan != null) return chan;
            var khoa = b.Khoa ?? "";
            var meta = ChinhSachMeta.Tim(khoa);
            if (meta == null) return Loi("Khóa cấu hình không hợp lệ.", 404);
            var loi = meta.KiemTra(b.GiaTri, out var chuan);
            if (loi != null) return Loi($"{meta.Nhan}: {loi}");
            var cu = await _db.CauHinhHeThongs.AsNoTracking().FirstOrDefaultAsync(c => c.Khoa == khoa);
            if (cu != null && cu.GiaTri == chuan) return Ok(new { thongDiep = "Giá trị không thay đổi.", giaTri = chuan });
            await _cauHinh.DatAsync(khoa, chuan, MaTK);
            return Ok(new { thongDiep = $"Đã cập nhật «{meta.Nhan}».", giaTri = chuan });
        }

        [HttpGet("cau-hinh/lich-su")]
        public async Task<IActionResult> LichSuCauHinh(string? khoa)
        {
            var q = _db.CauHinhHeThongLichSus.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(khoa)) q = q.Where(l => l.Khoa == khoa);
            var ls = await q.OrderByDescending(l => l.ThoiGian).Take(60).ToListAsync();
            var ids = ls.Where(l => l.MaTK != null).Select(l => l.MaTK!.Value).Distinct().ToList();
            var ten = await _db.TaiKhoans.AsNoTracking().Where(t => ids.Contains(t.MaTK)).ToDictionaryAsync(t => t.MaTK, t => t.TenDangNhap);
            return Ok(ls.Select(l => new { l.ThoiGian, l.Khoa, l.GiaTriCu, l.GiaTriMoi, nguoiSua = l.MaTK != null && ten.TryGetValue(l.MaTK.Value, out var t) ? t : "" }));
        }

        // ------------------------------------------------------------------ 12. BÁO CÁO & THỐNG KÊ
        [HttpGet("bao-cao")]
        [HttpGet("~/api/admin/reports/revenue")]
        public async Task<IActionResult> BaoCao(string ky = "Ngay")
        {
            if (ky != "Thang" && ky != "Nam") ky = "Ngay";
            var tuNgay = ky switch
            {
                "Thang" => DateTime.Today.AddMonths(-11).AddDays(1 - DateTime.Today.Day),
                "Nam" => new DateTime(DateTime.Today.Year - 4, 1, 1),
                _ => DateTime.Today.AddDays(-29),
            };
            var don = await _db.DonHangs.AsNoTracking().Include(d => d.GianHang).Include(d => d.ThanhToan)
                .Include(d => d.GiaoHang).ThenInclude(g => g!.TaiXe).Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .Where(d => d.NgayDat >= tuNgay).ToListAsync();
            var xong = don.Where(d => d.TrangThai == "DaGiao").ToList();
            var huy = don.Count(d => d.TrangThai == "DaHuy");

            object[] theoKy = ky switch
            {
                "Thang" => xong.GroupBy(d => new DateTime(d.NgayDat.Year, d.NgayDat.Month, 1)).OrderBy(g => g.Key).Select(g => (object)new { nhan = g.Key.ToString("MM/yyyy"), doanhThu = g.Sum(d => d.TongTien), soDon = g.Count() }).ToArray(),
                "Nam" => xong.GroupBy(d => d.NgayDat.Year).OrderBy(g => g.Key).Select(g => (object)new { nhan = g.Key.ToString(), doanhThu = g.Sum(d => d.TongTien), soDon = g.Count() }).ToArray(),
                _ => xong.GroupBy(d => d.NgayDat.Date).OrderBy(g => g.Key).Select(g => (object)new { nhan = g.Key.ToString("dd/MM"), doanhThu = g.Sum(d => d.TongTien), soDon = g.Count() }).ToArray(),
            };
            var phiNenTang = Math.Round(xong.Sum(d => (d.TongTien - d.PhiGiaoHang) * (d.GianHang?.TyLeChietKhau ?? 0)), 0);
            var thoiGianGiao = xong.Where(d => d.GiaoHang?.ThoiGianGiao != null).Select(d => (d.GiaoHang!.ThoiGianGiao!.Value - d.NgayDat).TotalMinutes)
                .Where(m => m > 0 && m < 600).ToList();

            var khuVuc = xong.Select(d => (d.DiaChiGiaoHang ?? "").Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries))
                .Where(p => p.Length > 0).Select(p => p.Length >= 3 ? p[^2] : p[^1])
                .GroupBy(x => x).Select(g => new { ten = g.Key, soDon = g.Count() }).OrderByDescending(x => x.soDon).Take(8).ToList();

            return Ok(new
            {
                ky,
                tongDoanhThu = xong.Sum(d => d.TongTien),
                tongDonHoanThanh = xong.Count,
                tongDonHuy = huy,
                tyLeHuy = don.Count == 0 ? 0 : Math.Round(huy * 100.0 / don.Count, 1),
                gmv = xong.Sum(d => d.TongTien),   // tổng giá trị đơn đã giao (GMV) — khác doanh thu nền tảng (phiNenTang)
                thoiGianGiaoTrungBinhPhut = thoiGianGiao.Count == 0 ? (double?)null : Math.Round(thoiGianGiao.Average(), 1),
                phiNenTang,
                phiGiaoHang = xong.Sum(d => d.PhiGiaoHang),
                khachMoi = await _db.TaiKhoans.CountAsync(t => t.VaiTro == "KhachHang" && t.NgayTao >= tuNgay),
                quanMoi = await _db.GianHangs.CountAsync(g => g.NgayDangKy >= tuNgay),
                taiXeMoi = await _db.TaiXes.CountAsync(t => t.NgayDangKy >= tuNgay),
                theoKy,
                topGianHang = xong.GroupBy(d => d.GianHang?.TenCuaHang ?? "?").Select(g => new { ten = g.Key, doanhThu = g.Sum(d => d.TongTien), soDon = g.Count() }).OrderByDescending(x => x.doanhThu).Take(10).ToList(),
                topMon = xong.SelectMany(d => d.ChiTiets).GroupBy(c => c.MonAn?.TenMon ?? "?").Select(g => new { ten = g.Key, soLuong = g.Sum(c => c.SoLuong) }).OrderByDescending(x => x.soLuong).Take(10).ToList(),
                khuVuc,
                theoThanhToan = xong.GroupBy(d => d.ThanhToan?.HinhThuc ?? "?").Select(g => new { hinhThuc = g.Key, soDon = g.Count(), tien = g.Sum(d => d.TongTien) }).OrderByDescending(x => x.tien).ToList(),
                topTaiXe = xong.Where(d => d.GiaoHang?.TaiXe != null).GroupBy(d => d.GiaoHang!.TaiXe!.HoTen).Select(g => new { ten = g.Key, soDon = g.Count(), thuNhap = g.Sum(d => d.PhiGiaoHang) }).OrderByDescending(x => x.soDon).Take(10).ToList(),
            });
        }

        // ------------------------------------------------------------------ 13. PHÂN QUYỀN quản trị (chỉ Admin tổng)
        public record AdminNhanVienReq(string? TenDangNhap, string? HoTen, string? Sdt, string? Email, string? CapQuyen, string? MatKhau);
        public record AdminQuyenReq(string[]? Quyen, bool MacDinh);
        public record AdminCapReq(string? CapQuyen);

        [HttpGet("nhan-vien")]
        public async Task<IActionResult> NhanViens()
        {
            var chan = await ChanSuperAsync(); if (chan != null) return chan;
            var ds = await (from q in _db.QuanTris.AsNoTracking() join t in _db.TaiKhoans.AsNoTracking() on q.MaTK equals t.MaTK orderby q.MaQuanTri
                            select new { q.MaTK, q.HoTen, q.SDT, q.Email, q.CapQuyenHan, q.QuyenChiTiet, t.TenDangNhap, BiKhoa = !t.TrangThai }).ToListAsync();
            return Ok(new
            {
                quyenTatCa = QuyenAdmin.TatCa.Select(x => new { khoa = x.Khoa, ten = x.Ten }),
                ds = ds.Select(x => new
                {
                    x.MaTK, x.HoTen, sdt = x.SDT, x.Email, x.TenDangNhap, capQuyen = x.CapQuyenHan, x.BiKhoa, x.QuyenChiTiet,
                    quyen = QuyenAdmin.Hieu(x.CapQuyenHan, x.QuyenChiTiet).OrderBy(k => k).ToArray(),
                    tuyChinh = !string.IsNullOrWhiteSpace(x.QuyenChiTiet),
                }),
            });
        }

        [HttpPost("nhan-vien")]
        public async Task<IActionResult> ThemNhanVien([FromBody] AdminNhanVienReq b)
        {
            var chan = await ChanSuperAsync(); if (chan != null) return chan;
            var cap = b.CapQuyen is "SuperAdmin" or "QuanLy" ? b.CapQuyen : "NhanVien";
            var ten = (b.TenDangNhap ?? "").Trim(); var hoTen = (b.HoTen ?? "").Trim();
            if (ten.Length < 3 || hoTen.Length < 2 || (b.MatKhau ?? "").Length < 6) return Loi("Nhập đủ tên đăng nhập (≥3 ký tự), họ tên và mật khẩu tối thiểu 6 ký tự.");
            if (await _db.TaiKhoans.AnyAsync(t => t.TenDangNhap == ten)) return Loi("Tên đăng nhập đã tồn tại.", 409);
            var tk = new TaiKhoan { TenDangNhap = ten, MatKhau = MatKhauHelper.Hash(b.MatKhau!), VaiTro = "QuanTri" };
            _db.TaiKhoans.Add(tk);
            await _db.SaveChangesAsync();
            _db.QuanTris.Add(new QuanTri { MaTK = tk.MaTK, HoTen = hoTen, SDT = (b.Sdt ?? "").Trim(), Email = string.IsNullOrWhiteSpace(b.Email) ? null : b.Email.Trim(), CapQuyenHan = cap! });
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = $"Đã tạo tài khoản \"{ten}\"." });
        }

        [HttpPut("nhan-vien/{maTK:int}/quyen")]
        public async Task<IActionResult> CapNhatQuyen(int maTK, [FromBody] AdminQuyenReq b)
        {
            var chan = await ChanSuperAsync(); if (chan != null) return chan;
            var q = await _db.QuanTris.FirstOrDefaultAsync(x => x.MaTK == maTK);
            if (q == null) return Loi("Không tìm thấy tài khoản quản trị.", 404);
            if (q.CapQuyenHan == "SuperAdmin") return Loi("Admin tổng luôn có toàn quyền.");
            var hopLe = QuyenAdmin.TatCa.Select(t => t.Khoa).ToHashSet();
            var chon = (b.Quyen ?? Array.Empty<string>()).Where(hopLe.Contains).Distinct().ToList();
            q.QuyenChiTiet = b.MacDinh ? null : chon.Count == 0 ? "-" : string.Join(",", chon);
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = q.QuyenChiTiet == null ? "Đã đặt về quyền mặc định theo cấp." : q.QuyenChiTiet == "-" ? "Đã thu hồi mọi quyền chức năng (chỉ còn xem)." : "Đã cập nhật quyền chi tiết." });
        }

        [HttpPut("nhan-vien/{maTK:int}/cap")]
        public async Task<IActionResult> DoiCap(int maTK, [FromBody] AdminCapReq b)
        {
            var chan = await ChanSuperAsync(); if (chan != null) return chan;
            if (maTK == MaTK) return Loi("Không thể tự đổi cấp của chính mình.");
            if (b.CapQuyen is not ("SuperAdmin" or "QuanLy" or "NhanVien")) return Loi("Cấp quyền không hợp lệ.");
            var q = await _db.QuanTris.FirstOrDefaultAsync(x => x.MaTK == maTK);
            if (q == null) return Loi("Không tìm thấy tài khoản quản trị.", 404);
            q.CapQuyenHan = b.CapQuyen; q.QuyenChiTiet = null;
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã đổi cấp quyền." });
        }
    }
}
