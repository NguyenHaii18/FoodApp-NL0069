using System.Collections.Concurrent;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// API /api/mobile bổ sung cho phần Đối tác / Gian hàng của FoodApp.Maui:
    /// giờ hoạt động & nhận đơn, đánh giá + phản hồi, thông báo, tài chính (phí nền tảng), quên mật khẩu.
    /// Cần chạy Database/FoodService_Database.sql (đã gồm 04_BoSung_DoiTac).
    /// </summary>
    [ApiController]
    [Route("api/mobile")]
    public class VendorMobileApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        public VendorMobileApiController(AppDbContext db) => _db = db;

        private int CurrentMaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static IActionResult Loi(string thongDiep, int status = 400) =>
            new ObjectResult(new { thongDiep }) { StatusCode = status };

        private Task<GianHang?> OwnStoreAsync(int id) =>
            _db.GianHangs.FirstOrDefaultAsync(g => g.MaGianHang == id && g.MaTK == CurrentMaTK);

        // ------------------------------------------------------------------ v64: đồng bộ tùy chọn món (size / topping / mức cay)
        public sealed class TuyChonDongBoItem { public string? Loai { get; set; } public string? Ten { get; set; } public decimal GiaThem { get; set; } }
        public sealed class TuyChonDongBoRequest { public List<TuyChonDongBoItem>? TuyChon { get; set; } }

        /// <summary>Thay toàn bộ tùy chọn của một món bằng danh sách gửi lên. Tùy chọn trùng (loại + tên) giữ nguyên mã để giỏ hàng cũ không mất tham chiếu.</summary>
        [HttpPut("gian-hang/{id:int}/mon-an/{maMon:int}/tuy-chon")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> DongBoTuyChonMon(int id, int maMon, TuyChonDongBoRequest request)
        {
            if (await OwnStoreAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var mon = await _db.MonAns.Include(m => m.DanhMuc)
                .FirstOrDefaultAsync(m => m.MaMonAn == maMon && m.DanhMuc!.MaGianHang == id);
            if (mon == null) return Loi("Không tìm thấy món trong gian hàng của bạn.", 404);

            var loais = new[] { "Size", "Topping", "MucCay", "MucDuong", "MucDa" };
            var moi = new List<(string Loai, string Ten, decimal Gia)>();
            foreach (var t in request?.TuyChon ?? new List<TuyChonDongBoItem>())
            {
                var loai = loais.FirstOrDefault(l => string.Equals(l, t.Loai?.Trim(), StringComparison.OrdinalIgnoreCase));
                var ten = (t.Ten ?? "").Trim();
                var gia = Math.Round(t.GiaThem, 0);
                if (loai == null) return Loi("Loại tùy chọn không hợp lệ.");
                if (ten.Length < 1 || ten.Length > 100) return Loi("Tên tùy chọn dài 1–100 ký tự.");
                if (gia < 0 || gia > 500_000m) return Loi($"Giá thêm của \"{ten}\" phải từ 0 đến 500.000đ.");
                if (moi.Any(x => x.Loai == loai && string.Equals(x.Ten, ten, StringComparison.OrdinalIgnoreCase)))
                    return Loi($"Tùy chọn \"{ten}\" bị trùng.");
                moi.Add((loai, ten, gia));
            }
            if (moi.Count > 30) return Loi("Mỗi món tối đa 30 tùy chọn.");

            var cu = await _db.TuyChonMons.Where(x => x.MaMonAn == maMon).ToListAsync();
            foreach (var c in cu.ToList())
            {
                var i = moi.FindIndex(x => x.Loai == c.Loai && string.Equals(x.Ten, c.TenTuyChon, StringComparison.OrdinalIgnoreCase));
                if (i < 0) { _db.TuyChonMons.Remove(c); cu.Remove(c); }   // đơn cũ lưu tùy chọn dạng chữ nên không bị ảnh hưởng
                else { c.TenTuyChon = moi[i].Ten; c.GiaThem = moi[i].Gia; }
            }
            foreach (var m in moi)
                if (!cu.Any(c => c.Loai == m.Loai && string.Equals(c.TenTuyChon, m.Ten, StringComparison.OrdinalIgnoreCase)))
                    _db.TuyChonMons.Add(new TuyChonMon { MaMonAn = maMon, Loai = m.Loai, TenTuyChon = m.Ten, GiaThem = m.Gia });
            await _db.SaveChangesAsync();

            var kq = await _db.TuyChonMons.AsNoTracking().Where(x => x.MaMonAn == maMon)
                .OrderBy(x => x.Loai).ThenBy(x => x.MaTuyChon)
                .Select(x => new { id = x.MaTuyChon, loai = x.Loai, ten = x.TenTuyChon, giaThem = x.GiaThem }).ToListAsync();
            return Ok(kq);
        }

        // ------------------------------------------------------------------ chiến dịch quảng cáo của gian hàng
        [HttpGet("gian-hang/{id:int}/chien-dich")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> DanhSachChienDich(int id)
        {
            if (await OwnStoreAsync(id) == null) return Loi("Bạn không có quyền xem gian hàng này.", 403);
            return Ok(await _db.ChienDichQuangCaos.Where(x => x.MaGianHang == id)
                .OrderByDescending(x => x.NgayTao).ToListAsync());
        }

        [HttpPost("gian-hang/{id:int}/chien-dich")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public Task<IActionResult> TaoChienDich(int id, ChienDichRequest request) => LuuChienDich(id, null, request);

        [HttpPut("gian-hang/{id:int}/chien-dich/{maChienDich:int}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public Task<IActionResult> SuaChienDich(int id, int maChienDich, ChienDichRequest request) =>
            LuuChienDich(id, maChienDich, request);

        private async Task<IActionResult> LuuChienDich(int id, int? maChienDich, ChienDichRequest request)
        {
            if (await OwnStoreAsync(id) == null) return Loi("Bạn không có quyền sửa gian hàng này.", 403);
            if (string.IsNullOrWhiteSpace(request.TenChienDich) || string.IsNullOrWhiteSpace(request.TieuDe))
                return Loi("Tên chiến dịch và tiêu đề không được để trống.");
            if (request.TenChienDich.Length > 150 || request.TieuDe.Length > 150 || request.NoiDung?.Length > 500 || request.HinhAnh?.Length > 500)
                return Loi("Nội dung chiến dịch vượt quá độ dài cho phép.");
            if (request.LoaiViTri is not ("Banner" or "NoiBat" or "GoiY")) return Loi("Vị trí quảng cáo không hợp lệ.");
            if (request.NgayKetThuc <= request.NgayBatDau) return Loi("Ngày kết thúc phải sau ngày bắt đầu.");
            if (request.NganSach < 0 || request.NganSach > 1_000_000_000m) return Loi("Ngân sách không hợp lệ.");

            var campaign = maChienDich == null
                ? new ChienDichQuangCao { MaGianHang = id }
                : await _db.ChienDichQuangCaos.SingleOrDefaultAsync(x => x.MaChienDich == maChienDich && x.MaGianHang == id);
            if (campaign == null) return Loi("Không tìm thấy chiến dịch.", 404);
            campaign.TenChienDich = request.TenChienDich.Trim();
            campaign.LoaiViTri = request.LoaiViTri;
            campaign.TieuDe = request.TieuDe.Trim();
            campaign.NoiDung = request.NoiDung?.Trim();
            campaign.HinhAnh = request.HinhAnh?.Trim();
            campaign.NgayBatDau = request.NgayBatDau;
            campaign.NgayKetThuc = request.NgayKetThuc;
            campaign.NganSach = request.NganSach;
            campaign.TrangThai = request.KichHoat ? "DangChay" : "BanNhap";
            if (maChienDich == null) _db.ChienDichQuangCaos.Add(campaign);
            await _db.SaveChangesAsync();
            return Ok(new { campaign.MaChienDich });
        }

        [HttpDelete("gian-hang/{id:int}/chien-dich/{maChienDich:int}")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> XoaChienDich(int id, int maChienDich)
        {
            if (await OwnStoreAsync(id) == null) return Loi("Bạn không có quyền sửa gian hàng này.", 403);
            var campaign = await _db.ChienDichQuangCaos.SingleOrDefaultAsync(x => x.MaChienDich == maChienDich && x.MaGianHang == id);
            if (campaign == null) return Loi("Không tìm thấy chiến dịch.", 404);
            _db.ChienDichQuangCaos.Remove(campaign);
            await _db.SaveChangesAsync();
            return NoContent();
        }


        // ------------------------------------------------------------------ giờ hoạt động / nhận đơn
        public record GioHoatDongRequest(string? GioMoCua, string? GioDongCua, bool DangNhanDon, bool DangMoCua);
        public record ChienDichRequest(string? TenChienDich, string? LoaiViTri, string? TieuDe,
            string? NoiDung, string? HinhAnh, DateTime NgayBatDau, DateTime NgayKetThuc,
            decimal NganSach, bool KichHoat);

        [HttpPut("gian-hang/{id:int}/gio-hoat-dong")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> GioHoatDong(int id, GioHoatDongRequest request)
        {
            var store = await OwnStoreAsync(id);
            if (store == null) return Loi("Không tìm thấy gian hàng.", 404);
            if (!TimeSpan.TryParse(request.GioMoCua, out var mo) || !TimeSpan.TryParse(request.GioDongCua, out var dong))
                return Loi("Giờ mở/đóng cửa không hợp lệ (định dạng HH:mm).");
            store.GioMoCua = mo;
            store.GioDongCua = dong;
            store.DangNhanDon = request.DangNhanDon;
            if (store.TrangThaiDuyet == "DaDuyet") store.TrangThaiKinhDoanh = request.DangMoCua ? "DangMo" : "DongCua";
            await _db.SaveChangesAsync();
            return Ok(new { gioMoCua = $"{mo:hh\\:mm}", gioDongCua = $"{dong:hh\\:mm}", dangNhanDon = store.DangNhanDon, dangMoCua = store.TrangThaiKinhDoanh == "DangMo" });
        }

        // ------------------------------------------------------------------ đánh giá + phản hồi
        [HttpGet("gian-hang/{id:int}/danh-gia")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> DanhGia(int id)
        {
            if (await OwnStoreAsync(id) == null) return Loi("Bạn không có quyền xem gian hàng này.", 403);
            var ds = await (from d in _db.DanhGias
                            join k in _db.KhachHangs on d.MaKH equals k.MaKH
                            where d.MaGianHang == id
                            orderby d.NgayDanhGia descending
                            select new
                            {
                                id = d.MaDanhGia,
                                donHangId = d.MaDonHang,
                                khachTen = k.HoTen,
                                soSao = d.SoSao,
                                soSaoGiaoHang = d.SoSaoGiaoHang,
                                theNhanXet = d.TheNhanXet ?? "",
                                anhDanhGia = d.AnhDanhGia ?? "",
                                noiDung = d.NoiDung ?? "",
                                ngay = d.NgayDanhGia,
                                phanHoi = d.PhanHoi ?? "",
                                ngayPhanHoi = d.NgayPhanHoi
                            }).ToListAsync();
            return Ok(ds);
        }

        public record PhanHoiRequest(string? NoiDung);

        [HttpPut("gian-hang/{id:int}/danh-gia/{maDanhGia:int}/phan-hoi")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> PhanHoiDanhGia(int id, int maDanhGia, PhanHoiRequest request)
        {
            if (await OwnStoreAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var dg = await _db.DanhGias.FirstOrDefaultAsync(d => d.MaDanhGia == maDanhGia && d.MaGianHang == id);
            if (dg == null) return Loi("Không tìm thấy đánh giá.", 404);
            var nd = request.NoiDung?.Trim();
            if (string.IsNullOrWhiteSpace(nd)) return Loi("Nội dung phản hồi không được để trống.");
            if (nd.Length > 500) return Loi("Phản hồi tối đa 500 ký tự.");
            dg.PhanHoi = nd;
            dg.NgayPhanHoi = DateTime.Now;
            await _db.SaveChangesAsync();
            return Ok(new { phanHoi = dg.PhanHoi, ngayPhanHoi = dg.NgayPhanHoi });
        }

        // ------------------------------------------------------------------ thông báo (suy ra từ đơn hàng & đánh giá gần đây)
        [HttpGet("gian-hang/{id:int}/thong-bao")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> ThongBao(int id)
        {
            if (await OwnStoreAsync(id) == null) return Loi("Bạn không có quyền xem gian hàng này.", 403);
            var tu = DateTime.Now.AddDays(-7);
            var don = await _db.DonHangs.Where(d => d.MaGianHang == id && d.NgayDat >= tu).OrderByDescending(d => d.NgayDat).Take(50).ToListAsync();
            var dg = await _db.DanhGias.Where(d => d.MaGianHang == id && d.NgayDanhGia >= tu).OrderByDescending(d => d.NgayDanhGia).Take(20).ToListAsync();

            var ds = new List<(DateTime Luc, object Item)>();
            foreach (var d in don)
            {
                if (d.TrangThai == "ChoXacNhan")
                    ds.Add((d.NgayDat, new { loai = "DonMoi", donHangId = d.MaDonHang, tieuDe = $"Đơn mới #{d.MaDonHang}", noiDung = $"Tổng {d.TongTien:N0}đ — hãy phản hồi trong 5 phút.", ngay = d.NgayDat }));
                else if (d.TrangThai == "DaHuy")
                    ds.Add((d.NgayDat, new { loai = "HuyDon", donHangId = d.MaDonHang, tieuDe = $"Đơn #{d.MaDonHang} đã hủy", noiDung = d.LyDoTuChoi ?? "", ngay = d.NgayDat }));
            }
            foreach (var d in dg)
                ds.Add((d.NgayDanhGia, new { loai = "DanhGiaMoi", donHangId = d.MaDonHang, tieuDe = $"Đánh giá mới {d.SoSao}★", noiDung = d.NoiDung ?? "", ngay = d.NgayDanhGia }));
            return Ok(ds.OrderByDescending(x => x.Luc).Select(x => x.Item));
        }

        // ------------------------------------------------------------------ tài chính: doanh thu, phí nền tảng, thực nhận
        [HttpGet("gian-hang/{id:int}/tai-chinh")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
        public async Task<IActionResult> TaiChinh(int id, DateTime? tu, DateTime? den)
        {
            var store = await OwnStoreAsync(id);
            if (store == null) return Loi("Bạn không có quyền xem gian hàng này.", 403);
            var tuNgay = (tu ?? DateTime.Today.AddDays(-29)).Date;
            var to = (den ?? DateTime.Today).Date.AddDays(1);

            var don = await _db.DonHangs.Include(d => d.ChiTiets)
                .Where(d => d.MaGianHang == id && d.TrangThai == "DaGiao" && d.NgayDat >= tuNgay && d.NgayDat < to).ToListAsync();
            // Doanh thu món = tiền hàng (không tính phí giao: phí giao thuộc về tài xế)
            var doanhThu = don.Sum(d => d.ChiTiets.Sum(c => c.DonGia * c.SoLuong));
            var phiNenTang = Math.Round(doanhThu * store.TyLeChietKhau, 0);
            var giaVon = (await (from c in _db.ChiTietDonHangs
                                 join d in _db.DonHangs on c.MaDonHang equals d.MaDonHang
                                 join m in _db.MonAns on c.MaMonAn equals m.MaMonAn
                                 where d.MaGianHang == id && d.TrangThai == "DaGiao" && d.NgayDat >= tuNgay && d.NgayDat < to
                                 select (decimal?)(m.GiaVon * c.SoLuong)).SumAsync()) ?? 0m;
            return Ok(new
            {
                tu = tuNgay, den = to.AddDays(-1),
                soDon = don.Count,
                doanhThuMon = doanhThu,
                tyLeChietKhau = store.TyLeChietKhau,
                phiNenTang,
                thucNhan = doanhThu - phiNenTang,
                giaVon,
                loiNhuan = doanhThu - phiNenTang - giaVon
            });
        }

        // Quên mật khẩu gian hàng: dùng luồng OTP chung (đã gỡ endpoint đặt lại bằng email + SĐT, vì không xác minh OTP):
        //   POST api/mobile/tai-khoan/quen-mat-khau    {taiKhoan}                   -> gửi OTP
        //   POST api/mobile/tai-khoan/dat-lai-mat-khau {taiKhoan, otp, matKhauMoi}  -> đổi mật khẩu sau khi OTP đúng
    }
}
