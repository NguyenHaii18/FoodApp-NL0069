using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>v68 — Quản lý thực đơn từ app của quán: xem toàn bộ (kể cả món hết/tạm ngừng), thêm/sửa/xóa món, đổi tình trạng, danh mục, ảnh món.
    /// Chỉ chủ gian hàng (JWT vai trò GianHang, MaTK trùng gian hàng). Món/danh mục bị quản trị ẩn (LyDoAn / DaAn) quán không tự mở lại được.</summary>
    [ApiController]
    [Route("api/mobile/gian-hang/{id:int}")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
    public class VendorThucDonApiController : ControllerBase
    {
        private static readonly string[] TinhTrangHopLe = { "ConHang", "HetHang", "TamNgung" };
        private readonly AppDbContext _db;
        private readonly IFileStorageService _luuTru;
        public VendorThucDonApiController(AppDbContext db, IFileStorageService luuTru) { _db = db; _luuTru = luuTru; }

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static IActionResult Loi(string m, int status = 400) => new ObjectResult(new { thongDiep = m }) { StatusCode = status };
        private Task<GianHang?> QuanCuaToiAsync(int id) => _db.GianHangs.FirstOrDefaultAsync(g => g.MaGianHang == id && g.MaTK == MaTK);

        public record MonReq(string? TenMon, decimal Gia, decimal GiaVon, string? MoTa, string? HinhAnh, string? DanhMuc, string? TinhTrang, bool NoiBat, bool ChoGhiChu = true);
        public record TinhTrangReq(string? TinhTrang);
        public record DanhMucReq(string? Ten);
        public record DoiTenReq(string? TenCu, string? TenMoi);

        // ------------------------------------------------------------------ THÔNG TIN CỬA HÀNG
        public record ThongTinQuanReq(string? TenGianHang, string? DiaChi, string? SoDienThoai, string? MoTa);

        /// <summary>Cập nhật tên, địa chỉ, SĐT, mô tả. Đổi địa chỉ thì xóa toạ độ cũ để hệ thống tự định vị lại (ảnh hưởng phí giao &amp; khoảng cách).</summary>
        [HttpPut("thong-tin")]
        public async Task<IActionResult> CapNhatThongTin(int id, ThongTinQuanReq r)
        {
            var quan = await QuanCuaToiAsync(id); if (quan == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var ten = (r.TenGianHang ?? "").Trim(); var diaChi = (r.DiaChi ?? "").Trim();
            var sdt = new string((r.SoDienThoai ?? "").Where(char.IsDigit).ToArray());
            if (ten.Length < 2 || ten.Length > 100) return Loi("Tên quán dài 2–100 ký tự.");
            if (diaChi.Length < 8 || diaChi.Length > 200) return Loi("Địa chỉ dài 8–200 ký tự (ghi rõ số nhà, đường, quận/huyện).");
            if (sdt.Length < 9 || sdt.Length > 11) return Loi("Số điện thoại phải có 9–11 chữ số.");
            if ((r.MoTa ?? "").Length > 500) return Loi("Mô tả tối đa 500 ký tự.");
            if (await _db.GianHangs.AnyAsync(g => g.MaGianHang != id && g.TenCuaHang.ToLower() == ten.ToLower())) return Loi("Tên quán đã có người dùng.", 409);
            var doiDiaChi = !string.Equals(quan.DiaChi, diaChi, StringComparison.OrdinalIgnoreCase);
            quan.TenCuaHang = ten; quan.DiaChi = diaChi; quan.SDT = sdt; quan.MoTa = string.IsNullOrWhiteSpace(r.MoTa) ? null : r.MoTa.Trim();
            if (doiDiaChi) { quan.ViDo = null; quan.KinhDo = null; }
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã cập nhật thông tin quán." + (doiDiaChi ? " Địa chỉ mới sẽ được định vị lại tự động." : "") });
        }

        // ------------------------------------------------------------------ XEM TOÀN BỘ THỰC ĐƠN (cùng dạng GET api/mobile/mon-an để app dùng chung mô hình)
        [HttpGet("thuc-don")]
        public async Task<IActionResult> Xem(int id)
        {
            var quan = await QuanCuaToiAsync(id); if (quan == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var danhMuc = await _db.DanhMucs.AsNoTracking().Where(d => d.MaGianHang == id).OrderBy(d => d.MaDanhMuc).Select(d => new { d.MaDanhMuc, d.TenDanhMuc, d.DaAn }).ToListAsync();
            var mon = await _db.MonAns.AsNoTracking().Where(m => m.DanhMuc!.MaGianHang == id).OrderBy(m => m.MaMonAn)
                .Select(m => new
                {
                    id = m.MaMonAn, tenMon = m.TenMon, gia = m.Gia, giaVon = m.GiaVon, hinhAnh = m.HinhAnh ?? "🍲", noiBat = m.NoiBat,
                    danhMuc = m.DanhMuc!.TenDanhMuc, gianHangId = id, conHang = m.TinhTrang == "ConHang", tamNgungBan = m.TinhTrang == "TamNgung",
                    choGhiChu = m.ChoGhiChu, moTa = m.MoTa ?? "", biQuanTriAn = m.LyDoAn != null, lyDoAn = m.LyDoAn,
                }).ToListAsync();
            var ids = mon.Select(m => m.id).ToList();
            var tuyChon = await _db.TuyChonMons.AsNoTracking().Where(t => ids.Contains(t.MaMonAn))
                .Select(t => new { t.MaMonAn, t.MaTuyChon, t.Loai, t.TenTuyChon, t.GiaThem }).ToListAsync();
            return Ok(new
            {
                danhMuc = danhMuc.Select(d => new { id = d.MaDanhMuc, ten = d.TenDanhMuc, daAn = d.DaAn }),
                mon = mon.Select(m => new
                {
                    m.id, m.tenMon, m.gia, m.giaVon, m.hinhAnh, m.noiBat, m.danhMuc, m.gianHangId, m.conHang, m.tamNgungBan, m.choGhiChu, m.moTa, m.biQuanTriAn, m.lyDoAn,
                    tuyChon = tuyChon.Where(t => t.MaMonAn == m.id).Select(t => new { id = t.MaTuyChon, loai = t.Loai, ten = t.TenTuyChon, giaThem = t.GiaThem }),
                }),
            });
        }

        // ------------------------------------------------------------------ DANH MỤC (theo tên: app quản lý danh mục bằng tên)
        private async Task<DanhMuc> LayHoacTaoDanhMucAsync(int maGianHang, string ten)
        {
            var dm = await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaGianHang == maGianHang && d.TenDanhMuc.ToLower() == ten.ToLower());
            if (dm != null) return dm;
            dm = new DanhMuc { MaGianHang = maGianHang, TenDanhMuc = ten };
            _db.DanhMucs.Add(dm);
            await _db.SaveChangesAsync();
            return dm;
        }

        [HttpPost("danh-muc")]
        public async Task<IActionResult> TaoDanhMuc(int id, DanhMucReq r)
        {
            if (await QuanCuaToiAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var ten = (r.Ten ?? "").Trim();
            if (ten.Length < 1 || ten.Length > 40) return Loi("Tên danh mục dài 1–40 ký tự.");
            var dm = await LayHoacTaoDanhMucAsync(id, ten);
            return Ok(new { id = dm.MaDanhMuc, ten = dm.TenDanhMuc });
        }

        [HttpPut("danh-muc/doi-ten")]
        public async Task<IActionResult> DoiTenDanhMuc(int id, DoiTenReq r)
        {
            if (await QuanCuaToiAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var cu = (r.TenCu ?? "").Trim(); var moi = (r.TenMoi ?? "").Trim();
            if (moi.Length < 1 || moi.Length > 40) return Loi("Tên danh mục dài 1–40 ký tự.");
            var dm = await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaGianHang == id && d.TenDanhMuc.ToLower() == cu.ToLower());
            if (dm == null) return Loi("Không tìm thấy danh mục.", 404);
            if (dm.DaAn) return Loi("Danh mục đang bị quản trị ẩn, bạn không thể sửa.", 403);
            if (!string.Equals(cu, moi, StringComparison.OrdinalIgnoreCase) && await _db.DanhMucs.AnyAsync(d => d.MaGianHang == id && d.TenDanhMuc.ToLower() == moi.ToLower()))
                return Loi("Đã có danh mục trùng tên.", 409);
            dm.TenDanhMuc = moi;
            await _db.SaveChangesAsync();
            return Ok(new { id = dm.MaDanhMuc, ten = dm.TenDanhMuc });
        }

        /// <summary>Xóa danh mục theo tên. Còn món thì bắt buộc chuyển sang danh mục khác (?chuyenSang=tên).</summary>
        [HttpDelete("danh-muc")]
        public async Task<IActionResult> XoaDanhMuc(int id, [FromQuery] string? ten, [FromQuery] string? chuyenSang)
        {
            if (await QuanCuaToiAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            ten = (ten ?? "").Trim();
            var dm = await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaGianHang == id && d.TenDanhMuc.ToLower() == ten.ToLower());
            if (dm == null) return Ok(new { thongDiep = "Danh mục không còn trên máy chủ." });
            if (dm.DaAn) return Loi("Danh mục đang bị quản trị ẩn, bạn không thể xóa.", 403);
            var mons = await _db.MonAns.Where(m => m.MaDanhMuc == dm.MaDanhMuc).ToListAsync();
            if (mons.Count > 0)
            {
                var dich = string.IsNullOrWhiteSpace(chuyenSang) ? null
                    : await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaGianHang == id && d.MaDanhMuc != dm.MaDanhMuc && d.TenDanhMuc.ToLower() == chuyenSang.Trim().ToLower());
                if (dich == null) return Loi("Danh mục còn món — hãy chọn danh mục đích để chuyển món sang.");
                foreach (var m in mons) m.MaDanhMuc = dich.MaDanhMuc;
            }
            _db.DanhMucs.Remove(dm);
            await _db.SaveChangesAsync();
            return Ok(new { thongDiep = "Đã xóa danh mục." });
        }

        // ------------------------------------------------------------------ MÓN ĂN
        private static string? KiemTraMon(MonReq r)
        {
            var ten = (r.TenMon ?? "").Trim();
            if (ten.Length < 1 || ten.Length > 100) return "Tên món dài 1–100 ký tự.";
            if (r.Gia <= 0 || r.Gia > 100_000_000m) return "Giá bán phải lớn hơn 0 và không quá 100.000.000đ.";
            if (r.GiaVon < 0 || r.GiaVon > 100_000_000m) return "Giá vốn không hợp lệ.";
            if ((r.MoTa ?? "").Length > 500) return "Mô tả tối đa 500 ký tự.";
            if ((r.HinhAnh ?? "").Length > 300) return "Đường dẫn ảnh quá dài.";
            var dm = (r.DanhMuc ?? "").Trim();
            if (dm.Length < 1 || dm.Length > 40) return "Chọn danh mục (1–40 ký tự).";
            if (r.TinhTrang != null && !TinhTrangHopLe.Contains(r.TinhTrang)) return "Tình trạng không hợp lệ.";
            return null;
        }

        private static object DongMon(MonAn m, string danhMuc, int maGianHang) => new
        {
            id = m.MaMonAn, tenMon = m.TenMon, gia = m.Gia, giaVon = m.GiaVon, hinhAnh = m.HinhAnh ?? "🍲", noiBat = m.NoiBat, danhMuc,
            gianHangId = maGianHang, conHang = m.TinhTrang == "ConHang", tamNgungBan = m.TinhTrang == "TamNgung", choGhiChu = m.ChoGhiChu, moTa = m.MoTa ?? "",
        };

        [HttpPost("mon-an")]
        public async Task<IActionResult> ThemMon(int id, MonReq r)
        {
            if (await QuanCuaToiAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var loi = KiemTraMon(r); if (loi != null) return Loi(loi);
            var ten = r.TenMon!.Trim();
            var dm = await LayHoacTaoDanhMucAsync(id, r.DanhMuc!.Trim());
            if (dm.DaAn) return Loi("Danh mục đang bị quản trị ẩn, không thể thêm món vào.", 403);
            if (await _db.MonAns.AnyAsync(m => m.DanhMuc!.MaGianHang == id && m.TenMon.ToLower() == ten.ToLower())) return Loi($"Quán đã có món \"{ten}\".", 409);
            var mon = new MonAn
            {
                MaDanhMuc = dm.MaDanhMuc, TenMon = ten, Gia = Math.Round(r.Gia, 0), GiaVon = Math.Round(r.GiaVon, 0), MoTa = string.IsNullOrWhiteSpace(r.MoTa) ? null : r.MoTa.Trim(),
                HinhAnh = string.IsNullOrWhiteSpace(r.HinhAnh) ? null : r.HinhAnh.Trim(), TinhTrang = r.TinhTrang ?? "ConHang", NoiBat = r.NoiBat, ChoGhiChu = r.ChoGhiChu,
            };
            _db.MonAns.Add(mon);
            await _db.SaveChangesAsync();
            return Ok(DongMon(mon, dm.TenDanhMuc, id));
        }

        [HttpPut("mon-an/{maMon:int}")]
        public async Task<IActionResult> SuaMon(int id, int maMon, MonReq r)
        {
            if (await QuanCuaToiAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var mon = await _db.MonAns.Include(m => m.DanhMuc).FirstOrDefaultAsync(m => m.MaMonAn == maMon && m.DanhMuc!.MaGianHang == id);
            if (mon == null) return Loi("Không tìm thấy món trong gian hàng của bạn.", 404);
            var loi = KiemTraMon(r); if (loi != null) return Loi(loi);
            var ten = r.TenMon!.Trim();
            if (!string.IsNullOrEmpty(mon.LyDoAn) && (r.TinhTrang ?? mon.TinhTrang) == "ConHang") return Loi("Món đang bị quản trị ẩn (" + mon.LyDoAn + "). Bạn không thể mở bán lại.", 403);
            if (await _db.MonAns.AnyAsync(m => m.MaMonAn != maMon && m.DanhMuc!.MaGianHang == id && m.TenMon.ToLower() == ten.ToLower())) return Loi($"Quán đã có món \"{ten}\".", 409);
            var dm = await LayHoacTaoDanhMucAsync(id, r.DanhMuc!.Trim());
            if (dm.DaAn && dm.MaDanhMuc != mon.MaDanhMuc) return Loi("Danh mục đích đang bị quản trị ẩn.", 403);
            mon.MaDanhMuc = dm.MaDanhMuc; mon.TenMon = ten; mon.Gia = Math.Round(r.Gia, 0); mon.GiaVon = Math.Round(r.GiaVon, 0);
            mon.MoTa = string.IsNullOrWhiteSpace(r.MoTa) ? null : r.MoTa.Trim();
            if (!string.IsNullOrWhiteSpace(r.HinhAnh)) mon.HinhAnh = r.HinhAnh.Trim();
            if (r.TinhTrang != null) mon.TinhTrang = r.TinhTrang;
            mon.NoiBat = r.NoiBat; mon.ChoGhiChu = r.ChoGhiChu;
            await _db.SaveChangesAsync();
            return Ok(DongMon(mon, dm.TenDanhMuc, id));
        }

        /// <summary>Còn hàng / hết hàng / tạm ngừng bán.</summary>
        [HttpPut("mon-an/{maMon:int}/tinh-trang")]
        public async Task<IActionResult> DoiTinhTrang(int id, int maMon, TinhTrangReq r)
        {
            if (await QuanCuaToiAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            if (r.TinhTrang == null || !TinhTrangHopLe.Contains(r.TinhTrang)) return Loi("Tình trạng không hợp lệ.");
            var mon = await _db.MonAns.FirstOrDefaultAsync(m => m.MaMonAn == maMon && m.DanhMuc!.MaGianHang == id);
            if (mon == null) return Loi("Không tìm thấy món trong gian hàng của bạn.", 404);
            if (!string.IsNullOrEmpty(mon.LyDoAn) && r.TinhTrang == "ConHang") return Loi("Món đang bị quản trị ẩn (" + mon.LyDoAn + "). Bạn không thể mở bán lại.", 403);
            mon.TinhTrang = r.TinhTrang;
            await _db.SaveChangesAsync();
            return Ok(new { tinhTrang = mon.TinhTrang });
        }

        /// <summary>Xóa món. Món đã nằm trong đơn hàng cũ không xóa được (giữ lịch sử/đối soát) → chuyển sang "tạm ngừng bán".</summary>
        [HttpDelete("mon-an/{maMon:int}")]
        public async Task<IActionResult> XoaMon(int id, int maMon)
        {
            if (await QuanCuaToiAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            var mon = await _db.MonAns.FirstOrDefaultAsync(m => m.MaMonAn == maMon && m.DanhMuc!.MaGianHang == id);
            if (mon == null) return Ok(new { daXoa = true, thongDiep = "Món không còn trên máy chủ." });
            if (await _db.ChiTietDonHangs.AnyAsync(c => c.MaMonAn == maMon))
            {
                if (string.IsNullOrEmpty(mon.LyDoAn)) mon.TinhTrang = "TamNgung";
                await _db.SaveChangesAsync();
                return Ok(new { daXoa = false, thongDiep = "Món đã có trong đơn hàng nên không xóa hẳn được; đã chuyển sang \"Tạm ngừng bán\" để khách không thấy." });
            }
            _db.GioHangChiTiets.RemoveRange(_db.GioHangChiTiets.Where(g => g.MaMonAn == maMon));
            _db.TuyChonMons.RemoveRange(_db.TuyChonMons.Where(t => t.MaMonAn == maMon));
            _db.MonAns.Remove(mon);
            await _db.SaveChangesAsync();
            return Ok(new { daXoa = true, thongDiep = "Đã xóa món." });
        }

        [HttpPost("mon-an/anh")]
        public async Task<IActionResult> TaiAnhMon(int id, IFormFile file)
        {
            if (await QuanCuaToiAsync(id) == null) return Loi("Bạn không có quyền với gian hàng này.", 403);
            try { return Ok(new { imageUrl = await _luuTru.SaveFileAsync(file, "monan") }); }
            catch (ArgumentException ex) { return Loi(ex.Message); }
        }
    }
}
