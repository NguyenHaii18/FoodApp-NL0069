using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// v55 — Tự động chọn tài xế (xem TuDongChonTaiXeXuLy). Xem gợi ý: mọi quản trị viên; gán tự động cần quyền "DonHang".
    ///   GET dieu-phoi/{id}/goi-y · PUT dieu-phoi/{id}/tu-dong · PUT dieu-phoi/tu-dong-tat-ca
    /// </summary>
    [ApiController]
    [Route("api/mobile/admin")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
    public class AdminMobileThongMinhApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        public AdminMobileThongMinhApiController(AppDbContext db) { _db = db; }
        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static ObjectResult Loi(string m, int status = 400) => new(new { thongDiep = m }) { StatusCode = status };

        [HttpGet("dieu-phoi/{id:int}/goi-y")]
        public async Task<IActionResult> GoiY(int id)
        {
            var don = await _db.DonHangs.AsNoTracking().FirstOrDefaultAsync(d => d.MaDonHang == id);
            if (don == null) return Loi("Không tìm thấy đơn.", 404);
            var cho = don.TrangThai == "DaXacNhan" && don.MaTaiXe == null && don.NguonGiao != "Quan";
            var ds = cho ? await TuDongChonTaiXeXuLy.XepHangAsync(_db, don) : new List<UngVienTaiXe>();
            return Ok(new { maDonHang = id, cho, quanTuGiao = don.NguonGiao == "Quan", ds });
        }

        [HttpPut("dieu-phoi/{id:int}/tu-dong")]
        public async Task<IActionResult> TuDong(int id)
        {
            if (!await QuyenAdmin.CoAsync(_db, MaTK, "DonHang")) return Loi("Bạn không có quyền điều phối đơn hàng.", 403);
            var kq = await TuDongChonTaiXeXuLy.TuDongAsync(_db, id, MaTK);
            return kq.Ok ? Ok(new { thongDiep = kq.ThongDiep }) : Loi(kq.ThongDiep, 409);
        }

        [HttpPut("dieu-phoi/tu-dong-tat-ca")]
        public async Task<IActionResult> TuDongTatCa()
        {
            if (!await QuyenAdmin.CoAsync(_db, MaTK, "DonHang")) return Loi("Bạn không có quyền điều phối đơn hàng.", 403);
            var ds = await _db.DonHangs.AsNoTracking().Where(d => d.TrangThai == "DaXacNhan" && d.MaTaiXe == null && d.NguonGiao != "Quan")
                .OrderByDescending(d => d.SanSangGiao).ThenBy(d => d.NgayDat).Select(d => d.MaDonHang).Take(30).ToListAsync();
            if (ds.Count == 0) return Ok(new { thongDiep = "Không có đơn nào đang chờ tài xế." });
            int ok = 0; var khong = new List<string>();
            foreach (var ma in ds)
            {
                var kq = await TuDongChonTaiXeXuLy.TuDongAsync(_db, ma, MaTK);
                _db.ChangeTracker.Clear();
                if (kq.Ok) ok++; else khong.Add("#" + ma);
            }
            return Ok(new { thongDiep = $"Đã tự động phân công {ok}/{ds.Count} đơn." + (khong.Count > 0 ? $" Chưa có tài xế phù hợp cho: {string.Join(", ", khong.Take(10))}." : "") });
        }
    }
}
