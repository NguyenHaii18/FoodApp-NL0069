using System.Globalization;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// v83 — Quản trị chỉnh phí giao hàng và tỉ lệ chia phí giao giữa tài xế / ứng dụng (thay cho việc sửa công thức trong bảng tính).
    ///   GET  api/mobile/admin/phi-giao                → cấu hình hiện tại + mặc định
    ///   PUT  api/mobile/admin/phi-giao                → lưu (chỉ Admin tổng); body { phiCoBan, kmCoBan, ..., tyLeTaiXe } toàn chuỗi, trường nào gửi mới đổi
    ///   POST api/mobile/admin/phi-giao/tinh-thu       → tính thử một đơn (có thể kèm cấu hình nháp chưa lưu)
    ///   GET  api/mobile/admin/phi-giao/thong-ke?ngay= → tổng quan phí ship / tiền tài xế / phần ứng dụng giữ lại
    /// Tỉ lệ tài xế chỉ áp dụng cho đơn đặt SAU khi đổi (đã chốt vào DonHang.TyLeTaiXe lúc đặt).
    /// </summary>
    [ApiController]
    [Route("api/mobile/admin/phi-giao")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
    public class AdminPhiGiaoApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly CauHinhService _cauHinh;
        public AdminPhiGiaoApiController(AppDbContext db, CauHinhService cauHinh) { _db = db; _cauHinh = cauHinh; }

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private static ObjectResult Loi(string m, int status = 400) => new(new { thongDiep = m }) { StatusCode = status };
        private Task<bool> LaSuperAsync() => _db.QuanTris.AnyAsync(q => q.MaTK == MaTK && q.CapQuyenHan == "SuperAdmin");

        /// <summary>Tên trường JSON ↔ khóa CauHinhHeThong.</summary>
        private static readonly (string Truong, string Khoa)[] BanDo =
        {
            ("phiCoBan", "Giao.PhiCoBan"), ("kmCoBan", "Giao.KmCoBan"), ("phiMoiKm", "Giao.PhiMoiKm"),
            ("phuPhiNgoaiThanh", "Giao.PhuPhiNgoaiThanh"), ("caoDiemPhanTram", "Giao.CaoDiemPhanTram"), ("khungCaoDiem", "Giao.CaoDiemKhungGio"),
            ("muaPhanTram", "Giao.MuaPhanTram"), ("dangMua", "Giao.DangMua"), ("phiToiThieu", "Giao.PhiToiThieu"), ("phiToiDa", "Giao.PhiToiDa"),
            ("phiMacDinh", "Giao.PhiMacDinh"), ("lamTron", "Giao.LamTron"), ("tyLeTaiXe", "ChiaTien.TyLeTaiXe"),
        };

        private static object Xuat(CauHinhPhiGiao c) => new
        {
            phiCoBan = c.PhiCoBan, kmCoBan = c.KmCoBan, phiMoiKm = c.PhiMoiKm, phuPhiNgoaiThanh = c.PhuPhiNgoaiThanh,
            caoDiemPhanTram = c.CaoDiemPhanTram, khungCaoDiem = c.KhungCaoDiem, muaPhanTram = c.MuaPhanTram, dangMua = c.DangMua,
            phiToiThieu = c.PhiToiThieu, phiToiDa = c.PhiToiDa, phiMacDinh = c.PhiMacDinh, lamTron = c.LamTron, tyLeTaiXe = c.TyLeTaiXe,
            tyLeUngDung = 1m - c.TyLeTaiXe,
        };

        private static decimal Dec(string s) => decimal.Parse(s, NumberStyles.Any, CultureInfo.InvariantCulture);

        /// <summary>Kiểm tra + chuẩn hóa các trường gửi lên. Trả (khóa → giá trị chuẩn) hoặc lỗi.</summary>
        private static (Dictionary<string, string>? Moi, string? Loi) KiemTra(Dictionary<string, string?>? body, CauHinhPhiGiao hienTai)
        {
            var moi = new Dictionary<string, string>();
            if (body == null) return (moi, null);
            foreach (var (truong, khoa) in BanDo)
            {
                if (!body.TryGetValue(truong, out var v) || v == null) continue;
                var meta = ChinhSachMeta.Tim(khoa);
                if (meta == null) continue;
                var loi = meta.KiemTra(v, out var chuan);
                if (loi != null) return (null, $"{meta.Nhan}: {loi}");
                if (khoa == "Giao.CaoDiemKhungGio")
                {
                    var l2 = PhiGiaoService.KiemTraKhungGio(chuan);
                    if (l2 != null) return (null, $"{meta.Nhan}: {l2}");
                }
                moi[khoa] = chuan;
            }
            var thieu = moi.TryGetValue("Giao.PhiToiThieu", out var a) ? Dec(a) : hienTai.PhiToiThieu;
            var da = moi.TryGetValue("Giao.PhiToiDa", out var b) ? Dec(b) : hienTai.PhiToiDa;
            if (da < thieu) return (null, "Phí giao tối đa phải lớn hơn hoặc bằng phí giao tối thiểu.");
            return (moi, null);
        }

        private static CauHinhPhiGiao Ap(CauHinhPhiGiao g, Dictionary<string, string> moi)
        {
            decimal D(string k, decimal mac) => moi.TryGetValue(k, out var s) ? Dec(s) : mac;
            return g with
            {
                PhiCoBan = D("Giao.PhiCoBan", g.PhiCoBan),
                KmCoBan = (double)D("Giao.KmCoBan", (decimal)g.KmCoBan),
                PhiMoiKm = D("Giao.PhiMoiKm", g.PhiMoiKm),
                PhuPhiNgoaiThanh = D("Giao.PhuPhiNgoaiThanh", g.PhuPhiNgoaiThanh),
                CaoDiemPhanTram = D("Giao.CaoDiemPhanTram", g.CaoDiemPhanTram),
                KhungCaoDiem = moi.TryGetValue("Giao.CaoDiemKhungGio", out var kg) ? kg : g.KhungCaoDiem,
                MuaPhanTram = D("Giao.MuaPhanTram", g.MuaPhanTram),
                DangMua = moi.TryGetValue("Giao.DangMua", out var dm) ? dm == "1" : g.DangMua,
                PhiToiThieu = D("Giao.PhiToiThieu", g.PhiToiThieu),
                PhiToiDa = D("Giao.PhiToiDa", g.PhiToiDa),
                PhiMacDinh = D("Giao.PhiMacDinh", g.PhiMacDinh),
                LamTron = D("Giao.LamTron", g.LamTron),
                TyLeTaiXe = D("ChiaTien.TyLeTaiXe", g.TyLeTaiXe),
            };
        }

        [HttpGet("")]
        public async Task<IActionResult> Xem()
        {
            await _cauHinh.DamBaoMacDinhAsync();
            return Ok(new
            {
                coQuyenSua = await LaSuperAsync(),
                cauHinh = Xuat(await PhiGiaoService.DocAsync(_db)),
                macDinh = Xuat(PhiGiaoService.MacDinh),
                ghiChu = "Phí giao = max(tối thiểu, cơ bản + km vượt + ngoại thành + %cao điểm + %mưa), làm tròn lên, không vượt tối đa. Tỉ lệ chia chỉ áp dụng cho đơn đặt sau khi đổi.",
            });
        }

        [HttpPut("")]
        public async Task<IActionResult> Luu([FromBody] Dictionary<string, string?>? body)
        {
            if (!await LaSuperAsync()) return Loi("Chỉ Admin tổng mới được đổi phí giao và tỉ lệ chia tiền.", 403);
            var hienTai = await PhiGiaoService.DocAsync(_db);
            var (moi, loi) = KiemTra(body, hienTai);
            if (loi != null || moi == null) return Loi(loi ?? "Dữ liệu không hợp lệ.");
            var cu = await _db.CauHinhHeThongs.AsNoTracking().Where(c => PhiGiaoService.CacKhoa.Contains(c.Khoa)).ToDictionaryAsync(c => c.Khoa, c => c.GiaTri);
            var doi = 0;
            foreach (var (khoa, gt) in moi)
            {
                if (cu.TryGetValue(khoa, out var g) && g == gt) continue;
                await _cauHinh.DatAsync(khoa, gt, MaTK);
                doi++;
            }
            return Ok(new
            {
                thongDiep = doi == 0 ? "Không có giá trị nào thay đổi." : $"Đã lưu {doi} thay đổi. Phí giao mới áp dụng cho đơn đặt từ bây giờ; tỉ lệ tài xế/ứng dụng chỉ áp cho đơn mới.",
                cauHinh = Xuat(await PhiGiaoService.DocAsync(_db)),
            });
        }

        public record TinhThuReq(double KhoangCachKm, decimal? GiaTriMon, string? Gio, bool? Mua, bool NgoaiThanh, decimal? UuDai, Dictionary<string, string?>? CauHinh);

        [HttpPost("tinh-thu")]
        public async Task<IActionResult> TinhThu([FromBody] TinhThuReq r)
        {
            if (r.KhoangCachKm < 0 || r.KhoangCachKm > 500) return Loi("Khoảng cách phải từ 0 đến 500 km.");
            var cfg = await PhiGiaoService.DocAsync(_db);
            if (r.CauHinh is { Count: > 0 })
            {
                var (moi, loi) = KiemTra(r.CauHinh, cfg);
                if (loi != null || moi == null) return Loi(loi ?? "Cấu hình nháp không hợp lệ.");
                cfg = Ap(cfg, moi);
            }
            var luc = DateTime.Now;
            if (!string.IsNullOrWhiteSpace(r.Gio))
            {
                if (!TimeSpan.TryParseExact(r.Gio.Trim(), new[] { "h\\:mm", "hh\\:mm" }, CultureInfo.InvariantCulture, out var t) || t >= TimeSpan.FromHours(24))
                    return Loi("Giờ giao phải dạng HH:mm (vd 18:30).");
                luc = DateTime.Today.Add(t);
            }
            var kq = PhiGiaoService.Tinh(cfg, r.KhoangCachKm, luc, r.NgoaiThanh, r.Mua);
            var mon = Math.Max(0m, r.GiaTriMon ?? 0m);
            var uuDai = Math.Clamp(r.UuDai ?? 0m, 0m, kq.Phi);              // ưu đãi áp trên phí giao
            var khachTraPhi = kq.Phi - uuDai;
            var taiXe = PhiGiaoService.TienTaiXe(kq.Phi, cfg.TyLeTaiXe);   // tài xế nhận trên phí GỐC; ứng dụng chịu phần ưu đãi
            return Ok(new
            {
                chiTiet = kq,
                gio = luc.ToString("HH:mm"),
                phiShipGoc = kq.Phi,
                uuDai,
                khachTraPhiShip = khachTraPhi,
                tongKhachTra = mon + khachTraPhi,
                tienTaiXe = taiXe,
                tyLeTaiXe = cfg.TyLeTaiXe,
                chenhLechPhiShip = khachTraPhi - taiXe,      // phần ứng dụng giữ lại (âm = ứng dụng bù)
            });
        }

        [HttpGet("thong-ke")]
        public async Task<IActionResult> ThongKe([FromQuery] int ngay = 30)
        {
            ngay = Math.Clamp(ngay, 1, 365);
            var tu = DateTime.Today.AddDays(1 - ngay);
            var don = await _db.DonHangs.AsNoTracking().Where(d => d.TrangThai == "DaGiao" && d.NgayDat >= tu)
                .Select(d => new { d.TongTien, d.PhiGiaoHang, d.TyLeTaiXe, d.TienGiam }).ToListAsync();
            var phiGoc = don.Sum(d => d.PhiGiaoHang);
            var taiXe = don.Sum(d => PhiGiaoService.TienTaiXe(d.PhiGiaoHang, d.TyLeTaiXe));
            var giam = don.Sum(d => d.TienGiam);
            return Ok(new
            {
                ngay, tuNgay = tu,
                soDon = don.Count,
                tongPhiShipGoc = phiGoc,
                tongKhachTra = don.Sum(d => d.TongTien),
                tienTaiXe = taiXe,
                tienUngDung = phiGoc - taiXe,
                tongGiamGia = giam,
                phiShipTrungBinh = don.Count == 0 ? 0m : Math.Round(phiGoc / don.Count, 0),
                chenhLech = phiGoc - taiXe,
            });
        }
    }
}
