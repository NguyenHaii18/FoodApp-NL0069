using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>
    /// v31 — API cho app gian hàng: quản lý tài xế của quán + chọn người giao (tài xế của quán / shipper ngoài).
    ///   GET  api/mobile/gian-hang/tai-xe                 danh sách tài xế của quán + cheDoGiao mặc định
    ///   POST api/mobile/gian-hang/tai-xe                 thêm tài xế của quán
    ///   PUT  api/mobile/gian-hang/tai-xe/{id}/hoat-dong  { hoatDong } khóa / mở khóa
    ///   PUT  api/mobile/gian-hang/che-do-giao            { che: "Quan" | "Ngoai" } mặc định cho đơn mới
    ///   PUT  api/mobile/don-hang/{id}/nguoi-giao         { nguon: "Quan" | "Ngoai", maTaiXe? } chọn người giao cho 1 đơn
    /// </summary>
    [ApiController]
    [Route("api/mobile")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "GianHang")]
    public class TaiXeQuanApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        public TaiXeQuanApiController(AppDbContext db) { _db = db; }

        private int CurrentMaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        private Task<int> MaGianHangAsync() => _db.GianHangs.Where(g => g.MaTK == CurrentMaTK).Select(g => g.MaGianHang).FirstOrDefaultAsync();
        private static IActionResult Loi(string msg, int status = 400) => new ObjectResult(new { message = msg, thongDiep = msg }) { StatusCode = status };

        [HttpGet("gian-hang/tai-xe")]
        public async Task<IActionResult> DanhSach()
        {
            var ma = await MaGianHangAsync();
            if (ma == 0) return Loi("Không tìm thấy gian hàng.", 404);
            var ds = await _db.TaiXes.Where(t => t.MaGianHang == ma).OrderBy(t => t.HoTen).ToListAsync();
            var maTk = ds.Select(t => t.MaTK).ToList();
            var hoatDong = await _db.TaiKhoans.Where(k => maTk.Contains(k.MaTK)).ToDictionaryAsync(k => k.MaTK, k => k.TrangThai);
            var maTx = ds.Select(t => t.MaTaiXe).ToList();
            var ban = await _db.DonHangs.Where(d => d.MaTaiXe != null && maTx.Contains(d.MaTaiXe.Value) && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao"))
                .Select(d => d.MaTaiXe!.Value).Distinct().ToListAsync();
            var che = await _db.GianHangs.Where(g => g.MaGianHang == ma).Select(g => g.CheDoGiao).FirstAsync();
            return Ok(new
            {
                cheDoGiao = che,
                taiXe = ds.Select(t => new
                {
                    id = t.MaTaiXe, hoTen = t.HoTen, sdt = t.SDT, phuongTien = t.PhuongTien, bienSo = t.BienSo,
                    hoatDong = hoatDong.TryGetValue(t.MaTK, out var b) && b, dangGiao = ban.Contains(t.MaTaiXe), trangThai = t.TrangThai
                })
            });
        }

        public sealed class TaiXeQuanRequest
        {
            public string TenDangNhap { get; set; } = "";
            public string MatKhau { get; set; } = "";
            public string HoTen { get; set; } = "";
            public string Sdt { get; set; } = "";
            public string? PhuongTien { get; set; }
            public string? BienSo { get; set; }
        }

        [HttpPost("gian-hang/tai-xe")]
        public async Task<IActionResult> Them([FromBody] TaiXeQuanRequest r)
        {
            var ma = await MaGianHangAsync();
            if (ma == 0) return Loi("Không tìm thấy gian hàng.", 404);
            var (kq, id) = await NguonGiaoXuLy.TaoTaiXeQuanAsync(_db, ma, r.TenDangNhap, r.MatKhau, r.HoTen, r.Sdt, r.PhuongTien, r.BienSo);
            return kq.Ok ? Ok(new { id, message = kq.ThongDiep, thongDiep = kq.ThongDiep }) : Loi(kq.ThongDiep);
        }

        public sealed class HoatDongRequest { public bool HoatDong { get; set; } }

        [HttpPut("gian-hang/tai-xe/{id:int}/hoat-dong")]
        public async Task<IActionResult> HoatDong(int id, [FromBody] HoatDongRequest r)
        {
            var ma = await MaGianHangAsync();
            var kq = await NguonGiaoXuLy.DatHoatDongAsync(_db, ma, id, r.HoatDong);
            return kq.Ok ? Ok(new { message = kq.ThongDiep, thongDiep = kq.ThongDiep }) : Loi(kq.ThongDiep, 409);
        }

        public sealed class CheDoRequest { public string Che { get; set; } = "Ngoai"; }

        [HttpPut("gian-hang/che-do-giao")]
        public async Task<IActionResult> CheDo([FromBody] CheDoRequest r)
        {
            var ma = await MaGianHangAsync();
            if (ma == 0) return Loi("Không tìm thấy gian hàng.", 404);
            var kq = await NguonGiaoXuLy.DatCheDoMacDinhAsync(_db, ma, r.Che);
            return kq.Ok ? Ok(new { cheDoGiao = NguonGiaoXuLy.ChuanHoa(r.Che), message = kq.ThongDiep, thongDiep = kq.ThongDiep }) : Loi(kq.ThongDiep, 409);
        }

        public sealed class NguoiGiaoRequest { public string Nguon { get; set; } = "Ngoai"; public int? MaTaiXe { get; set; } }

        [HttpPut("don-hang/{id:int}/nguoi-giao")]
        public async Task<IActionResult> NguoiGiao(int id, [FromBody] NguoiGiaoRequest r)
        {
            var ma = await MaGianHangAsync();
            var don = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaGianHang == ma);
            if (don == null) return Loi("Không tìm thấy đơn hàng hoặc bạn không có quyền.", 404);
            KetQuaGiao kq;
            if (NguonGiaoXuLy.ChuanHoa(r.Nguon) == NguonGiaoXuLy.Quan)
                kq = r.MaTaiXe == null ? new KetQuaGiao(false, "Hãy chọn một tài xế của quán.") : await NguonGiaoXuLy.GanTaiXeQuanAsync(_db, don, r.MaTaiXe.Value);
            else kq = await NguonGiaoXuLy.ChuyenShipperNgoaiAsync(_db, don);
            return kq.Ok ? Ok(new { nguonGiao = don.NguonGiao, maTaiXe = don.MaTaiXe, message = kq.ThongDiep, thongDiep = kq.ThongDiep }) : Loi(kq.ThongDiep, 409);
        }
    }
}
