using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers.Api
{
    /// <summary>Bật/tắt và theo dõi chế độ tự động phân công chạy nền trên máy chủ. Cần quyền "DonHang" (Admin tổng luôn có).</summary>
    [ApiController]
    [Route("api/mobile/admin/dieu-phoi/tu-dong")]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "QuanTri")]
    public class AdminTuDongApiController : ControllerBase
    {
        private readonly AppDbContext _db;
        private readonly CauHinhService _cauHinh;
        public AdminTuDongApiController(AppDbContext db, CauHinhService cauHinh) { _db = db; _cauHinh = cauHinh; }

        private int MaTK => int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        public record BatReq(bool Bat);

        private async Task<object> TrangThaiAsync() => new
        {
            bat = await TuDongPhanCongXuLy.DangBatAsync(_cauHinh),
            lanChayCuoi = TuDongPhanCongXuLy.LanChayCuoi,
            tongDaPhanCong = TuDongPhanCongXuLy.TongDaPhanCong,
            ketQuaCuoi = TuDongPhanCongXuLy.KetQuaCuoi,
            quanTriDieuPhoi = await GiaoHangXuLy.QuanTriDieuPhoiAsync(_db),
        };

        [HttpGet("")]
        public async Task<IActionResult> Xem() => Ok(await TrangThaiAsync());

        [HttpPut("")]
        public async Task<IActionResult> Dat(BatReq r)
        {
            if (!await QuyenAdmin.CoAsync(_db, MaTK, "DonHang")) return StatusCode(403, new { thongDiep = "Tài khoản của bạn chưa được cấp quyền điều phối." });
            await _cauHinh.DatAsync(TuDongPhanCongXuLy.KhoaCauHinh, r.Bat ? "1" : "0", MaTK);
            return Ok(new { thongDiep = r.Bat ? "Đã bật tự động phân công trên máy chủ (chạy nền 24/7)." : "Đã tắt tự động phân công.", trangThai = await TrangThaiAsync() });
        }

        [HttpPost("chay-ngay")]
        public async Task<IActionResult> ChayNgay()
        {
            if (!await QuyenAdmin.CoAsync(_db, MaTK, "DonHang")) return StatusCode(403, new { thongDiep = "Tài khoản của bạn chưa được cấp quyền điều phối." });
            var (ok, tom) = await TuDongPhanCongXuLy.ChayAsync(_db, MaTK, "Tự động phân công (chạy ngay theo yêu cầu quản trị)");
            return Ok(new { thongDiep = tom, daPhanCong = ok, trangThai = await TrangThaiAsync() });
        }
    }
}
