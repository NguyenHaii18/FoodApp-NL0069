using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>Quản lý banner / chiến dịch quảng cáo toàn hệ thống (cùng nhóm quyền "Thông báo").</summary>
    [Route("QuanTri/Banner")]
    [FoodServiceApp.Web.Filters.CoQuyenGhi("ThongBao")]
    public class AdminBannerController : AdminOpsBase
    {
        private readonly IFileStorageService _luuTru;
        public AdminBannerController(AppDbContext db, IFileStorageService luuTru) : base(db) { _luuTru = luuTru; }

        [HttpGet("")]
        public async Task<IActionResult> Index()
            => View(await Db.Banners.AsNoTracking().OrderBy(b => b.ThuTu).ThenByDescending(b => b.NgayTao).ToListAsync());

        [HttpPost("luu")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Luu(string tieuDe, string? lienKet, int thuTu, DateTime? ngayBatDau, DateTime? ngayKetThuc, IFormFile? hinhAnh)
        {
            tieuDe = (tieuDe ?? "").Trim();
            lienKet = string.IsNullOrWhiteSpace(lienKet) ? null : lienKet.Trim();
            if (tieuDe.Length < 3 || tieuDe.Length > 150) { TempData["LoiThongBao"] = "Tiêu đề từ 3 đến 150 ký tự."; return RedirectToAction(nameof(Index)); }
            if (hinhAnh == null || hinhAnh.Length == 0) { TempData["LoiThongBao"] = "Chọn ảnh banner."; return RedirectToAction(nameof(Index)); }
            if (lienKet != null && lienKet.Length > 300) { TempData["LoiThongBao"] = "Liên kết tối đa 300 ký tự."; return RedirectToAction(nameof(Index)); }
            // chỉ cho liên kết nội bộ (/...) hoặc http(s) để tránh javascript:...
            if (lienKet != null && !(lienKet.StartsWith("/") || lienKet.StartsWith("http://") || lienKet.StartsWith("https://")))
            { TempData["LoiThongBao"] = "Liên kết phải bắt đầu bằng / hoặc http(s)://"; return RedirectToAction(nameof(Index)); }
            if (ngayBatDau != null && ngayKetThuc != null && ngayKetThuc < ngayBatDau)
            { TempData["LoiThongBao"] = "Ngày kết thúc phải sau ngày bắt đầu."; return RedirectToAction(nameof(Index)); }

            string duongAnh;
            try { duongAnh = await _luuTru.SaveFileAsync(hinhAnh, "banner"); }
            catch (ArgumentException ex) { TempData["LoiThongBao"] = ex.Message; return RedirectToAction(nameof(Index)); }

            Db.Banners.Add(new Banner { TieuDe = tieuDe, LienKet = lienKet, ThuTu = thuTu, NgayBatDau = ngayBatDau, NgayKetThuc = ngayKetThuc, HinhAnh = duongAnh, MaTKTao = MaTK });
            await Db.SaveChangesAsync();
            TempData["ThongBao"] = "Đã tạo banner.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost("bat-tat/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BatTat(int id)
        {
            var b = await Db.Banners.FindAsync(id);
            if (b == null) return NotFound();
            b.TrangThai = !b.TrangThai;
            await Db.SaveChangesAsync();
            TempData["ThongBao"] = b.TrangThai ? "Đã bật banner." : "Đã tắt banner.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost("xoa/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Xoa(int id)
        {
            var b = await Db.Banners.FindAsync(id);
            if (b == null) return NotFound();
            Db.Banners.Remove(b);
            await Db.SaveChangesAsync();
            TempData["ThongBao"] = "Đã xóa banner.";
            return RedirectToAction(nameof(Index));
        }
    }
}
