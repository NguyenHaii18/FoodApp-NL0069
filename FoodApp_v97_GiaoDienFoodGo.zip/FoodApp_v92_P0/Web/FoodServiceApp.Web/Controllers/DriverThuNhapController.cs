using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.ViewModels;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>
    /// Thu nhập tài xế: phí giao từng đơn, thưởng/phụ cấp/điều chỉnh, tổng theo ngày/tuần/tháng, COD đã thu,
    /// trạng thái nền tảng đã trả hay chưa. Đơn bị hủy KHÔNG tính là hoàn thành (chỉ riêng giao thất bại do lỗi khách
    /// mới được giữ phí giao theo quy định, hiển thị tách riêng).
    /// </summary>
    [Route("TaiXe/ThuNhap")]
    public class DriverThuNhapController : TaiXeBaseController
    {
        private readonly AppDbContext _db;
        public DriverThuNhapController(AppDbContext db) { _db = db; }

        [HttpGet("")]
        public async Task<IActionResult> Index()
        {
            var homNay = DateTime.Today;
            var diff = ((int)homNay.DayOfWeek + 6) % 7;           // tuần bắt đầu thứ Hai
            var dauTuan = homNay.AddDays(-diff);
            var dauThang = new DateTime(homNay.Year, homNay.Month, 1);
            var tuNgay = homNay.AddDays(-29);
            var batDau = new[] { tuNgay, dauThang, dauTuan }.Min();

            var gh = await _db.GiaoHangs.Include(g => g.DonHang)
                .Where(g => g.MaTaiXe == CurrentTaiXeId && g.ThoiGianGiao >= batDau
                            && (g.TrangThai == "GiaoThanhCong" || (g.TrangThai == "GiaoThatBai" && g.TinhPhiThatBai)))
                .ToListAsync();
            var dc = await _db.DieuChinhThuNhaps.Where(x => x.MaTaiXe == CurrentTaiXeId && x.NgayTao >= batDau).ToListAsync();

            var dong = new List<DongThuNhap>();
            foreach (var g in gh)
                dong.Add(new DongThuNhap
                {
                    ThoiGian = g.ThoiGianGiao!.Value, MaDonHang = g.MaDonHang, SoTien = FoodServiceApp.Web.Services.PhiGiaoService.TienTaiXe(g.DonHang!.PhiGiaoHang, g.DonHang.TyLeTaiXe),
                    Loai = g.TrangThai == "GiaoThanhCong" ? "PhiGiao" : "PhiGiaoThatBai",
                    GhiChu = g.TrangThai == "GiaoThatBai" ? "Giao thất bại do khách: " + g.LyDoThatBai : null,
                    TrangThai = g.TrangThaiThuNhap, CodThu = g.TienThuCOD
                });
            foreach (var x in dc)
                dong.Add(new DongThuNhap { ThoiGian = x.NgayTao, MaDonHang = x.MaDonHang, SoTien = x.SoTien, Loai = x.Loai, GhiChu = x.LyDo, TrangThai = x.TrangThai });

            decimal Tong(DateTime tu) => dong.Where(d => d.ThoiGian >= tu).Sum(d => d.SoTien);
            int Don(DateTime tu) => dong.Count(d => d.ThoiGian >= tu && d.Loai == "PhiGiao");
            var d30 = dong.Where(d => d.ThoiGian >= tuNgay).ToList();

            var codDangCam = await _db.DonHangs
                .Where(d => d.MaTaiXe == CurrentTaiXeId && d.TrangThai == "DangGiao" && d.ThanhToan != null && d.ThanhToan.HinhThuc == "TienMat" && d.ThanhToan.TrangThai != "DaThanhToan")
                .SumAsync(d => (decimal?)d.TongTien) ?? 0;

            var codChoNop = await DriverDonXuLy.CodChuaNopAsync(_db, CurrentTaiXeId);

            var vm = new DriverThuNhapViewModel
            {
                CodCanNop = codChoNop.Sum(c => c.SoTien), CodChoNop = codChoNop,
                HomNay = Tong(homNay), TuanNay = Tong(dauTuan), ThangNay = Tong(dauThang),
                DonHomNay = Don(homNay), DonTuanNay = Don(dauTuan), DonThangNay = Don(dauThang),
                TongPhiGiao30Ngay = d30.Where(d => d.Loai is "PhiGiao" or "PhiGiaoThatBai").Sum(d => d.SoTien),
                TongThuongPhuCap30Ngay = d30.Where(d => (d.Loai is "Thuong" or "PhuCap" or "DieuChinh") && d.SoTien > 0).Sum(d => d.SoTien),
                TongTru30Ngay = d30.Where(d => d.Loai == "Phat" || (d.Loai == "DieuChinh" && d.SoTien < 0)).Sum(d => d.SoTien),
                TongThuNhap30Ngay = d30.Sum(d => d.SoTien),
                TongDonGiaoThanhCong30Ngay = d30.Count(d => d.Loai == "PhiGiao"),
                CodPhaiThuDangGiao = codDangCam,
                CodDaThu30Ngay = d30.Sum(d => d.CodThu ?? 0),
                ChoNenTangTra = d30.Where(d => d.TrangThai != "DaThanhToan").Sum(d => d.SoTien),
                DaDuocTra = d30.Where(d => d.TrangThai == "DaThanhToan").Sum(d => d.SoTien),
                ThuNhapTheoNgay = d30.GroupBy(d => d.ThoiGian.Date).OrderBy(g => g.Key).Select(g => (g.Key, g.Sum(x => x.SoTien))).ToList(),
                GiaoDich = d30.OrderByDescending(d => d.ThoiGian).Take(100).ToList(),
            };
            return View(vm);
        }
    }
}
