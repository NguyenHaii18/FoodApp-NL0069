using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>Gian hàng quản lý size / topping / mức cay của từng món (khách chọn ở trang món và giỏ hàng).</summary>
    public class TuyChonController : GianHangBaseController
    {
        private static readonly string[] Loais = { "Size", "Topping", "MucCay", "MucDuong", "MucDa" };
        private const int ToiDaMoiMon = 30;
        private const decimal GiaThemToiDa = 500_000m;

        private readonly AppDbContext _db;
        public TuyChonController(AppDbContext db) { _db = db; }

        private Task<MonAn?> MonCuaToiAsync(int maMonAn) =>
            _db.MonAns.Include(m => m.DanhMuc).FirstOrDefaultAsync(m => m.MaMonAn == maMonAn && m.DanhMuc!.MaGianHang == CurrentGianHangId);

        public async Task<IActionResult> Index(int maMonAn)
        {
            var mon = await MonCuaToiAsync(maMonAn);
            if (mon == null) return NotFound();
            ViewBag.Mon = mon;
            var ds = await _db.TuyChonMons.AsNoTracking().Where(t => t.MaMonAn == maMonAn).OrderBy(t => t.Loai).ThenBy(t => t.GiaThem).ThenBy(t => t.TenTuyChon).ToListAsync();
            return View(ds);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Them(int maMonAn, string? loai, string? ten, decimal giaThem)
        {
            var mon = await MonCuaToiAsync(maMonAn);
            if (mon == null) return NotFound();
            ten = ten?.Trim() ?? "";
            giaThem = Math.Round(giaThem, 0);
            string? loi = null;
            if (loai == null || !Loais.Contains(loai)) loi = "Loại tùy chọn không hợp lệ.";
            else if (ten.Length < 1 || ten.Length > 100) loi = "Tên tùy chọn dài 1–100 ký tự.";
            else if (giaThem < 0 || giaThem > GiaThemToiDa) loi = $"Giá thêm từ 0 đến {GiaThemToiDa:N0}đ.";
            else if (await _db.TuyChonMons.CountAsync(t => t.MaMonAn == maMonAn) >= ToiDaMoiMon) loi = $"Mỗi món tối đa {ToiDaMoiMon} tùy chọn.";
            else if (await _db.TuyChonMons.AnyAsync(t => t.MaMonAn == maMonAn && t.Loai == loai && t.TenTuyChon == ten)) loi = "Tùy chọn này đã có.";
            if (loi != null) { TempData["LoiThongBao"] = loi; return RedirectToAction("Index", new { maMonAn }); }

            _db.TuyChonMons.Add(new TuyChonMon { MaMonAn = maMonAn, Loai = loai!, TenTuyChon = ten, GiaThem = giaThem });
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = $"Đã thêm \"{ten}\".";
            return RedirectToAction("Index", new { maMonAn });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Xoa(int id)
        {
            var tc = await _db.TuyChonMons.FirstOrDefaultAsync(t => t.MaTuyChon == id);
            if (tc == null) return NotFound();
            var mon = await MonCuaToiAsync(tc.MaMonAn);      // chỉ xóa được tùy chọn thuộc món của chính gian hàng
            if (mon == null) return NotFound();
            _db.TuyChonMons.Remove(tc);                      // đơn cũ lưu tùy chọn dạng chữ nên không bị ảnh hưởng
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = $"Đã xóa \"{tc.TenTuyChon}\".";
            return RedirectToAction("Index", new { maMonAn = tc.MaMonAn });
        }
    }
}
