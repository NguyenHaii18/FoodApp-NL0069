using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>v31 — Gian hàng quản lý tài xế riêng của quán và chọn cách giao mặc định (tài xế của quán / shipper ngoài).</summary>
    public class TaiXeQuanController : GianHangBaseController
    {
        private readonly AppDbContext _db;
        public TaiXeQuanController(AppDbContext db) { _db = db; }

        public async Task<IActionResult> Index()
        {
            var ds = await _db.TaiXes.Where(t => t.MaGianHang == CurrentGianHangId).OrderBy(t => t.HoTen).ToListAsync();
            var maTk = ds.Select(t => t.MaTK).ToList();
            ViewBag.HoatDong = await _db.TaiKhoans.Where(k => maTk.Contains(k.MaTK)).ToDictionaryAsync(k => k.MaTK, k => k.TrangThai);
            var maTx = ds.Select(t => t.MaTaiXe).ToList();
            ViewBag.DangGiao = await _db.DonHangs.Where(d => d.MaTaiXe != null && maTx.Contains(d.MaTaiXe.Value) && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao"))
                .Select(d => d.MaTaiXe!.Value).Distinct().ToListAsync();
            ViewBag.CheDoGiao = await _db.GianHangs.Where(g => g.MaGianHang == CurrentGianHangId).Select(g => g.CheDoGiao).FirstOrDefaultAsync() ?? "Ngoai";
            return View(ds);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Them(string tenDangNhap, string matKhau, string hoTen, string sdt, string? phuongTien, string? bienSo)
        {
            var (kq, _) = await NguonGiaoXuLy.TaoTaiXeQuanAsync(_db, CurrentGianHangId, tenDangNhap, matKhau, hoTen, sdt, phuongTien, bienSo);
            TempData[kq.Ok ? "ThongBao" : "LoiThongBao"] = kq.ThongDiep;
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> HoatDong(int id, bool bat)
        {
            var kq = await NguonGiaoXuLy.DatHoatDongAsync(_db, CurrentGianHangId, id, bat);
            TempData[kq.Ok ? "ThongBao" : "LoiThongBao"] = kq.ThongDiep;
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> CheDoMacDinh(string che)
        {
            var kq = await NguonGiaoXuLy.DatCheDoMacDinhAsync(_db, CurrentGianHangId, che);
            TempData[kq.Ok ? "ThongBao" : "LoiThongBao"] = kq.ThongDiep;
            return RedirectToAction(nameof(Index));
        }
    }
}
