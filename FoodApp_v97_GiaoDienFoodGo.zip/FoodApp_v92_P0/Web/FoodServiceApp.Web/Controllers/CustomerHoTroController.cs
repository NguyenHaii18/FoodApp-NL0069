using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace FoodServiceApp.Web.Controllers
{
    // Trung tâm hỗ trợ: câu hỏi thường gặp + liên hệ + lối vào gửi yêu cầu hỗ trợ (CustomerPhanHoi) và xem lịch sử.
    [Route("MuaHang/HoTro")]
    public class CustomerHoTroController : CustomerBaseController
    {
        private readonly IConfiguration _config;
        private readonly FoodServiceApp.Web.Data.AppDbContext _db;
        public CustomerHoTroController(IConfiguration config, FoodServiceApp.Web.Data.AppDbContext db) { _config = config; _db = db; }

        [HttpGet("")]
        public async Task<IActionResult> Index()
        {
            // FAQ do quản trị biên tập (v47f); chưa có câu nào thì view dùng bộ câu mặc định.
            var faq = await _db.CauHoiThuongGaps.AsNoTracking().Where(x => x.TrangThai)
                .OrderBy(x => x.ThuTu).ThenBy(x => x.MaCauHoi).Select(x => new { x.CauHoi, x.TraLoi }).ToListAsync();
            ViewBag.FaqDb = faq.Select(x => (Q: x.CauHoi, A: x.TraLoi)).ToList();
            ViewBag.Hotline = _config["HoTro:Hotline"] ?? "1900 0000";
            ViewBag.Email = _config["HoTro:Email"] ?? "hotro@example.com";
            return View();
        }
    }
}
