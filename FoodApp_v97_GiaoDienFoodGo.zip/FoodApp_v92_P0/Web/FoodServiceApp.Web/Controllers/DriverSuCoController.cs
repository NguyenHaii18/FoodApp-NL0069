using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>Tài xế báo sự cố (tai nạn, món hư hỏng, an toàn, khách không liên lạc được, sai địa chỉ...) và báo sai lệch thu nhập / COD.</summary>
    [Route("TaiXe/SuCo")]
    public class DriverSuCoController : TaiXeBaseController
    {
        public static readonly Dictionary<string, string> Loais = new()
        {
            ["TaiNan"] = "Tai nạn giao thông", ["MonHuHong"] = "Món bị hư hỏng / đổ", ["AnToan"] = "Vấn đề an toàn (đe dọa, khu vực nguy hiểm)",
            ["KhachKhongLienLac"] = "Không liên lạc được khách", ["SaiDiaChi"] = "Sai địa chỉ giao hàng", ["KhachKhongNhan"] = "Khách không nhận hàng",
            ["QuanChuanBiCham"] = "Quán chuẩn bị chậm", ["KhongTimThayDon"] = "Không tìm thấy đơn tại quán", ["SaiMon"] = "Sai món",
            ["ThieuMon"] = "Thiếu món", ["VanDeBanGiao"] = "Vấn đề bàn giao tại quán",
            ["TranhChapGiaoHang"] = "Tranh chấp giao hàng (khách/quán khiếu nại)", ["SaiLechThuNhap"] = "Sai lệch thu nhập", ["SaiLechCOD"] = "Sai lệch tiền COD", ["Khac"] = "Khác",
        };

        private readonly AppDbContext _db;
        private readonly IFileStorageService _luuTru;
        public DriverSuCoController(AppDbContext db, IFileStorageService luuTru) { _db = db; _luuTru = luuTru; }

        [HttpGet("")]
        public async Task<IActionResult> Index(int? donHang, string? loai)
        {
            ViewBag.Loais = Loais;
            ViewBag.DonHang = donHang;
            ViewBag.LoaiChon = loai;
            return View(await _db.SuCoGiaoHangs.AsNoTracking().Where(x => x.MaTaiXe == CurrentTaiXeId).OrderByDescending(x => x.NgayTao).Take(50).ToListAsync());
        }

        [HttpPost("Tao")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Tao(string loai, string moTa, int? maDonHang, IFormFile? anh)
        {
            moTa = (moTa ?? "").Trim();
            if (!Loais.ContainsKey(loai ?? "")) { TempData["LoiThongBao"] = "Loại sự cố không hợp lệ."; return RedirectToAction(nameof(Index)); }
            if (moTa.Length < 5) { TempData["LoiThongBao"] = "Vui lòng mô tả sự cố (ít nhất 5 ký tự)."; return RedirectToAction(nameof(Index), new { donHang = maDonHang, loai }); }
            if (maDonHang != null && !await _db.GiaoHangs.AnyAsync(g => g.MaDonHang == maDonHang && g.MaTaiXe == CurrentTaiXeId))
            { TempData["LoiThongBao"] = "Đơn này không thuộc về bạn."; return RedirectToAction(nameof(Index)); }

            string? duongAnh = null;
            if (anh != null && anh.Length > 0)
            {
                try { duongAnh = await _luuTru.SaveFileAsync(anh, "suco"); }
                catch (ArgumentException ex) { TempData["LoiThongBao"] = ex.Message; return RedirectToAction(nameof(Index), new { donHang = maDonHang, loai }); }
            }
            var tx = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == CurrentTaiXeId);
            var kq = await DriverDonXuLy.TaoSuCoAsync(_db, tx, loai, moTa, maDonHang, duongAnh);
            if (!kq.Ok) { TempData["LoiThongBao"] = kq.ThongDiep; return RedirectToAction(nameof(Index), new { donHang = maDonHang, loai }); }
            TempData["ThongBao"] = "Đã gửi báo cáo. Quản trị sẽ xử lý và phản hồi tại đây.";
            return RedirectToAction(nameof(Index));
        }
    }
}
