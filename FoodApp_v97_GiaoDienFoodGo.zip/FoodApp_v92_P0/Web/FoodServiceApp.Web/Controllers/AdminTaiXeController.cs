using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Models.ViewModels;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers
{
    // Trước bản nâng cấp này, hệ thống KHÔNG có cách nào tạo tài khoản tài xế
    // (không tự đăng ký như Gian hàng, cũng không có nơi Quản trị tạo) — tài xế
    // chỉ có thể được thêm bằng tay trực tiếp trong CSDL. Controller này bổ sung
    // đúng phần còn thiếu: Quản trị viên tạo tài khoản, xem danh sách, khoá/mở.
    [Route("QuanTri/TaiXe")]
    [FoodServiceApp.Web.Filters.ChiSuperAdminGhi]
    public class AdminTaiXeController : QuanTriBaseController
    {
        private readonly AppDbContext _db;

        public AdminTaiXeController(AppDbContext db)
        {
            _db = db;
        }

        [HttpGet("")]
        public async Task<IActionResult> Index(string? timKiem)
        {
            var query = _db.TaiXes
                .Where(x => x.TrangThaiDuyet == "DaDuyet")
                .Join(_db.TaiKhoans, x => x.MaTK, t => t.MaTK, (x, t) => new { TaiXe = x, TaiKhoan = t });

            if (!string.IsNullOrWhiteSpace(timKiem))
                query = query.Where(x => x.TaiXe.HoTen.Contains(timKiem) || x.TaiXe.SDT.Contains(timKiem));

            var danhSach = await query.OrderBy(x => x.TaiXe.HoTen).ToListAsync();

            ViewBag.TimKiem = timKiem ?? "";
            ViewBag.SoChoDuyet = await _db.TaiXes.CountAsync(x => x.TrangThaiDuyet == "ChoDuyet");
            return View(danhSach.Select(x => (x.TaiXe, x.TaiKhoan)).ToList());
        }

        // Hồ sơ chi tiết: giấy tờ, phương tiện, hiệu suất, lịch sử giao, điều chỉnh thu nhập, phản ánh của tài xế
        [HttpGet("ChiTiet/{id:int}")]
        public async Task<IActionResult> ChiTiet(int id)
        {
            var tx = await _db.TaiXes.AsNoTracking().FirstOrDefaultAsync(x => x.MaTaiXe == id);
            if (tx == null) return NotFound();
            ViewBag.TaiKhoan = await _db.TaiKhoans.AsNoTracking().FirstAsync(t => t.MaTK == tx.MaTK);

            var giao = _db.GiaoHangs.AsNoTracking().Where(g => g.MaTaiXe == id);
            var thanhCong = await giao.CountAsync(g => g.TrangThai == "GiaoThanhCong");
            var thatBai = await giao.CountAsync(g => g.TrangThai == "GiaoThatBai");
            ViewBag.TongDon = await giao.CountAsync();
            ViewBag.ThanhCong = thanhCong;
            ViewBag.ThatBai = thatBai;
            ViewBag.DangLam = await giao.CountAsync(g => g.TrangThai == "DaNhan" || g.TrangThai == "DangGiao");
            // Tỷ lệ tính trên các đơn đã có kết quả (thành công + thất bại)
            ViewBag.TyLeHoanThanh = (thanhCong + thatBai) > 0 ? Math.Round(100.0 * thanhCong / (thanhCong + thatBai), 1) : (double?)null;
            ViewBag.TyLeThatBai = (thanhCong + thatBai) > 0 ? Math.Round(100.0 * thatBai / (thanhCong + thatBai), 1) : (double?)null;

            ViewBag.LichSu = await _db.GiaoHangs.AsNoTracking()
                .Include(g => g.DonHang).ThenInclude(d => d!.GianHang)
                .Where(g => g.MaTaiXe == id).OrderByDescending(g => g.MaGiaoHang).Take(50).ToListAsync();
            ViewBag.DieuChinhs = await _db.DieuChinhThuNhaps.AsNoTracking()
                .Where(x => x.MaTaiXe == id).OrderByDescending(x => x.NgayTao).Take(30).ToListAsync();
            ViewBag.SuCos = await _db.SuCoGiaoHangs.AsNoTracking()
                .Where(x => x.MaTaiXe == id).OrderByDescending(x => x.NgayTao).Take(20).ToListAsync();
            ViewBag.CodChuaNop = await DriverDonXuLy.CodChuaNopAsync(_db, id);
            return View(tx);
        }

        // Quản trị xác nhận đã nhận tiền COD tài xế nộp lại (toàn bộ khoản đang chờ; chưa hỗ trợ nộp từng phần)
        [HttpPost("XacNhanNopCod/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> XacNhanNopCod(int id)
        {
            var tx = await _db.TaiXes.FirstOrDefaultAsync(x => x.MaTaiXe == id);
            if (tx == null) return NotFound();
            if ((User.FindFirst("CapQuyenHan")?.Value ?? "") != "SuperAdmin")
            { TempData["LoiThongBao"] = "Chỉ Admin tổng được xác nhận nhận tiền COD."; return RedirectToAction("ChiTiet", new { id }); }

            var chuaNop = await _db.GiaoHangs.Where(g => g.MaTaiXe == id && g.TienThuCOD > 0 && g.CodDaNopLuc == null).ToListAsync();
            if (chuaNop.Count == 0) { TempData["LoiThongBao"] = "Tài xế không có khoản COD nào cần nộp."; return RedirectToAction("ChiTiet", new { id }); }
            var tong = chuaNop.Sum(g => g.TienThuCOD ?? 0);
            var luc = DateTime.Now;
            foreach (var g in chuaNop) g.CodDaNopLuc = luc;
            _db.ThongBaos.Add(new ThongBao
            {
                MaTK = tx.MaTK, Loai = "HeThong", TieuDe = "Đã nhận tiền COD bạn nộp",
                NoiDung = $"Quản trị xác nhận đã nhận {tong:N0}đ COD ({chuaNop.Count} đơn).",
            });
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = $"Đã xác nhận nhận {tong:N0}đ COD ({chuaNop.Count} đơn) từ tài xế \"{tx.HoTen}\".";
            return RedirectToAction("ChiTiet", new { id });
        }

        public const decimal DieuChinhToiDa = 5_000_000m;   // chặn nhập nhầm số quá lớn

        // Quản trị tạo thưởng / phụ cấp / phạt / điều chỉnh thu nhập cho tài xế (tài xế xem ở trang Thu nhập)
        [HttpPost("DieuChinhThuNhap/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GhiDieuChinh(int id, string? loai, decimal soTien, string? lyDo, int? maDonHang)
        {
            var tx = await _db.TaiXes.FirstOrDefaultAsync(x => x.MaTaiXe == id);
            if (tx == null) return NotFound();

            string? loi = null;
            lyDo = lyDo?.Trim() ?? "";
            if (loai is not ("Thuong" or "PhuCap" or "Phat" or "DieuChinh")) loi = "Loại điều chỉnh không hợp lệ.";
            else if (lyDo.Length < 5) loi = "Nhập lý do điều chỉnh (tối thiểu 5 ký tự).";
            else if (soTien == 0 || Math.Abs(soTien) > DieuChinhToiDa) loi = $"Số tiền phải khác 0 và không vượt quá {DieuChinhToiDa:N0}đ.";
            else if (maDonHang != null && !await _db.GiaoHangs.AnyAsync(g => g.MaDonHang == maDonHang && g.MaTaiXe == id))
                loi = $"Đơn #{maDonHang} không thuộc tài xế này.";
            if (loi != null) { TempData["LoiThongBao"] = loi; return RedirectToAction("ChiTiet", new { id }); }

            // Thưởng/phụ cấp luôn cộng, phạt luôn trừ; "điều chỉnh" giữ nguyên dấu người nhập
            var so = loai == "Phat" ? -Math.Abs(soTien) : (loai is "Thuong" or "PhuCap") ? Math.Abs(soTien) : soTien;
            int? maTkAdmin = int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var a) ? a : null;
            _db.DieuChinhThuNhaps.Add(new DieuChinhThuNhap { MaTaiXe = id, MaDonHang = maDonHang, Loai = loai!, SoTien = so, LyDo = lyDo, MaTK = maTkAdmin });
            _db.ThongBaos.Add(new ThongBao
            {
                MaTK = tx.MaTK, Loai = "HeThong", TieuDe = "Thu nhập của bạn được điều chỉnh",
                NoiDung = $"{(so > 0 ? "+" : "")}{so:N0}đ — {lyDo}" + (maDonHang != null ? $" (đơn #{maDonHang})" : ""),
            });
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = $"Đã ghi điều chỉnh {(so > 0 ? "+" : "")}{so:N0}đ cho tài xế \"{tx.HoTen}\".";
            return RedirectToAction("ChiTiet", new { id });
        }

        // Danh sách tài xế tự đăng ký, đang chờ Quản trị duyệt
        [HttpGet("ChoDuyet")]
        public async Task<IActionResult> ChoDuyet()
        {
            var danhSach = await _db.TaiXes
                .Where(x => x.TrangThaiDuyet == "ChoDuyet")
                .OrderBy(x => x.NgayDangKy)
                .ToListAsync();
            return View(danhSach);
        }

        [HttpPost("Duyet/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Duyet(int id)
        {
            var taiXe = await _db.TaiXes.FirstOrDefaultAsync(x => x.MaTaiXe == id);
            if (taiXe == null) return NotFound();

            taiXe.TrangThaiDuyet = "DaDuyet";
            taiXe.LyDoTuChoi = null;
            taiXe.YeuCauBoSung = null;
            _db.ThongBaos.Add(new FoodServiceApp.Web.Models.Entities.ThongBao { MaTK = taiXe.MaTK, Loai = "HeThong", TieuDe = "Hồ sơ tài xế đã được duyệt", NoiDung = "Tài khoản của bạn đã được kích hoạt, bạn có thể bật trạng thái sẵn sàng và nhận đơn." });
            await _db.SaveChangesAsync();

            TempData["ThongBao"] = $"Đã duyệt hồ sơ tài xế \"{taiXe.HoTen}\".";
            return RedirectToAction("ChoDuyet");
        }

        [HttpPost("BoSung/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BoSung(int id, string? yeuCau)
        {
            var tx = await _db.TaiXes.FirstOrDefaultAsync(x => x.MaTaiXe == id);
            if (tx == null) return NotFound();
            if (string.IsNullOrWhiteSpace(yeuCau)) { TempData["LoiThongBao"] = "Nhập nội dung cần bổ sung."; return RedirectToAction("ChoDuyet"); }
            tx.YeuCauBoSung = yeuCau.Trim();
            _db.ThongBaos.Add(new FoodServiceApp.Web.Models.Entities.ThongBao { MaTK = tx.MaTK, Loai = "HeThong", TieuDe = "Yêu cầu bổ sung hồ sơ tài xế", NoiDung = tx.YeuCauBoSung });
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = $"Đã yêu cầu tài xế \"{tx.HoTen}\" bổ sung hồ sơ.";
            return RedirectToAction("ChoDuyet");
        }

        [HttpPost("TuChoi/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TuChoi(int id, string? lyDo)
        {
            var taiXe = await _db.TaiXes.FirstOrDefaultAsync(x => x.MaTaiXe == id);
            if (taiXe == null) return NotFound();

            if (string.IsNullOrWhiteSpace(lyDo))
            {
                TempData["LoiThongBao"] = "Vui lòng nhập lý do từ chối.";
                return RedirectToAction("ChoDuyet");
            }
            taiXe.TrangThaiDuyet = "TuChoi";
            taiXe.LyDoTuChoi = lyDo.Trim();
            _db.ThongBaos.Add(new FoodServiceApp.Web.Models.Entities.ThongBao { MaTK = taiXe.MaTK, Loai = "HeThong", TieuDe = "Hồ sơ tài xế bị từ chối", NoiDung = "Lý do: " + taiXe.LyDoTuChoi });
            await _db.SaveChangesAsync();

            TempData["ThongBao"] = $"Đã từ chối hồ sơ tài xế \"{taiXe.HoTen}\".";
            return RedirectToAction("ChoDuyet");
        }

        [HttpGet("Them")]
        public IActionResult Them() => View(new AdminCreateDriverViewModel());

        [HttpPost("Them")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Them(AdminCreateDriverViewModel model)
        {
            if (model.MatKhau != model.XacNhanMatKhau)
                ModelState.AddModelError(nameof(model.XacNhanMatKhau), "Xác nhận mật khẩu không khớp.");

            if (await _db.TaiKhoans.AnyAsync(t => t.TenDangNhap == model.TenDangNhap))
                ModelState.AddModelError(nameof(model.TenDangNhap), "Tên đăng nhập đã tồn tại.");

            if (!ModelState.IsValid) return View(model);

            var taiKhoan = new TaiKhoan
            {
                TenDangNhap = model.TenDangNhap,
                MatKhau = MatKhauHelper.Hash(model.MatKhau),
                VaiTro = "TaiXe",
            };
            _db.TaiKhoans.Add(taiKhoan);
            await _db.SaveChangesAsync();

            var taiXe = new TaiXe
            {
                MaTK = taiKhoan.MaTK,
                HoTen = model.HoTen,
                SDT = model.SDT,
                PhuongTien = model.PhuongTien,
                BienSo = model.BienSo,
                KhuVucHoatDong = FoodServiceApp.Web.Services.KhuVucHelper.ChuanHoa(model.KhuVucHoatDong),
                TrangThai = "NgoaiTuyen", // tài xế tự bật "Sẵn sàng" khi đăng nhập lần đầu
                TrangThaiDuyet = "DaDuyet", // Quản trị tạo trực tiếp -> kích hoạt luôn
            };
            _db.TaiXes.Add(taiXe);
            await _db.SaveChangesAsync();

            TempData["ThongBao"] = $"Đã tạo tài khoản tài xế \"{taiXe.HoTen}\" — tên đăng nhập: {taiKhoan.TenDangNhap}.";
            return RedirectToAction("Index");
        }

        [HttpPost("ToggleKhoa/{maTK:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ToggleKhoa(int maTK)
        {
            var taiKhoan = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == maTK && t.VaiTro == "TaiXe");
            if (taiKhoan == null) return NotFound();

            taiKhoan.TrangThai = !taiKhoan.TrangThai;
            await _db.SaveChangesAsync();

            TempData["ThongBao"] = taiKhoan.TrangThai
                ? "Đã mở khoá tài khoản tài xế."
                : "Đã khoá tài khoản tài xế (do vi phạm/khiếu nại).";
            return RedirectToAction("Index");
        }
    }
}
