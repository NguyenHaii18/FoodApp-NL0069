using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>Bản đồ gian hàng: tìm gian hàng theo tên/địa chỉ và định vị trên bản đồ (chỉ đọc, mọi cấp quản trị đều xem được).</summary>
    [Route("QuanTri/BanDo")]
    public class AdminBanDoController : QuanTriBaseController
    {
        private readonly AppDbContext _db;
        public AdminBanDoController(AppDbContext db) { _db = db; }

        [HttpGet("")]
        public async Task<IActionResult> Index(string? timKiem)
        {
            var query = _db.GianHangs.AsQueryable();
            if (!string.IsNullOrWhiteSpace(timKiem))
                query = query.Where(g => g.TenCuaHang.Contains(timKiem) || g.DiaChi.Contains(timKiem));

            var ds = await query.OrderBy(g => g.TenCuaHang).Take(500)
                .Select(g => new GianHangBanDoVm
                {
                    MaGianHang = g.MaGianHang, Ten = g.TenCuaHang, DiaChi = g.DiaChi, Sdt = g.SDT,
                    TrangThaiDuyet = g.TrangThaiDuyet, TrangThaiKinhDoanh = g.TrangThaiKinhDoanh,
                    ViDo = g.ViDo, KinhDo = g.KinhDo
                }).ToListAsync();

            ViewBag.TimKiem = timKiem ?? "";
            return View(ds);
        }

        public class GianHangBanDoVm
        {
            public int MaGianHang { get; set; }
            public string Ten { get; set; } = "";
            public string DiaChi { get; set; } = "";
            public string Sdt { get; set; } = "";
            public string TrangThaiDuyet { get; set; } = "";
            public string TrangThaiKinhDoanh { get; set; } = "";
            public double? ViDo { get; set; }
            public double? KinhDo { get; set; }
        }
    }
}
