using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;

namespace FoodServiceApp.Web.Controllers
{
    [Route("QuanTri")]
    public class AdminDashboardController : QuanTriBaseController
    {
        private readonly AppDbContext _db;
        public AdminDashboardController(AppDbContext db) { _db = db; }

        // ky: hom-nay | 7-ngay | 30-ngay | nam | tu-chon (tuNgay, denNgay)
        [HttpGet("")]
        [HttpGet("Dashboard")]
        public async Task<IActionResult> Index(string ky = "hom-nay", DateTime? tuNgay = null, DateTime? denNgay = null)
        {
            var homNay = DateTime.Today;
            DateTime tu, den = DateTime.Now.AddMinutes(1);
            switch (ky)
            {
                case "7-ngay": tu = homNay.AddDays(-6); break;
                case "30-ngay": tu = homNay.AddDays(-29); break;
                case "nam": tu = new DateTime(homNay.Year, 1, 1); break;
                case "tu-chon" when tuNgay != null:
                    tu = tuNgay.Value.Date; den = (denNgay ?? tuNgay.Value).Date.AddDays(1); break;
                default: ky = "hom-nay"; tu = homNay; break;
            }
            ViewBag.Ky = ky; ViewBag.Tu = tu; ViewBag.Den = den;

            // ---- 4 thẻ số liệu đầu trang (tính từ dữ liệu thật, không phụ thuộc bộ lọc kỳ) ----
            var dauThang = new DateTime(homNay.Year, homNay.Month, 1);
            ViewBag.GianHangDaDuyet = await _db.GianHangs.CountAsync(g => g.TrangThaiDuyet == "DaDuyet");
            ViewBag.GianHangDuyetMoiThang = await _db.GianHangs.CountAsync(g => g.TrangThaiDuyet == "DaDuyet" && g.NgayDangKy >= dauThang);
            ViewBag.KhachMoiThang = await _db.KhachHangs.Join(_db.TaiKhoans, k => k.MaTK, t => t.MaTK, (k, t) => t.NgayTao).CountAsync(n => n >= dauThang);
            var tuan = homNay.AddDays(-6); var tuanTruoc = homNay.AddDays(-13);
            var dt7 = await _db.DonHangs.Where(d => d.TrangThai == "DaGiao" && d.NgayDat >= tuan).SumAsync(d => (decimal?)d.TongTien) ?? 0;
            var dt7Truoc = await _db.DonHangs.Where(d => d.TrangThai == "DaGiao" && d.NgayDat >= tuanTruoc && d.NgayDat < tuan).SumAsync(d => (decimal?)d.TongTien) ?? 0;
            ViewBag.DoanhThuTuan = dt7;
            ViewBag.DoanhThuTuanPhanTram = dt7Truoc > 0 ? (double?)((dt7 - dt7Truoc) / dt7Truoc * 100m) : null;
            ViewBag.DonHomNay = await _db.DonHangs.CountAsync(d => d.NgayDat >= homNay);
            ViewBag.DonHomQua = await _db.DonHangs.CountAsync(d => d.NgayDat >= homNay.AddDays(-1) && d.NgayDat < homNay);

            ViewBag.TongKhachHang = await _db.KhachHangs.CountAsync();
            ViewBag.TongGianHang = await _db.GianHangs.CountAsync();
            ViewBag.GianHangDangMo = await _db.GianHangs.CountAsync(g => g.TrangThaiKinhDoanh == "DangMo");
            ViewBag.TongTaiXe = await _db.TaiXes.CountAsync();
            ViewBag.TaiXeDaDuyet = await _db.TaiXes.CountAsync(t => t.TrangThaiDuyet == "DaDuyet");

            var donKy = _db.DonHangs.Where(d => d.NgayDat >= tu && d.NgayDat < den);
            ViewBag.TongDon = await donKy.CountAsync();
            ViewBag.DonTheoTrangThai = await donKy.GroupBy(d => d.TrangThai).Select(g => new { g.Key, SoLuong = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.SoLuong);
            ViewBag.DoanhThu = await donKy.Where(d => d.TrangThai == "DaGiao").SumAsync(d => (decimal?)d.TongTien) ?? 0;
            ViewBag.PhiNenTang = await donKy.Where(d => d.TrangThai == "DaGiao")
                .SumAsync(d => (decimal?)((d.TongTien - d.PhiGiaoHang) * d.GianHang!.TyLeChietKhau)) ?? 0;

            ViewBag.ThanhToan = await _db.ThanhToans
                .Where(t => donKy.Any(d => d.MaDonHang == t.MaDonHang))
                .GroupBy(t => t.TrangThai).Select(g => new { g.Key, SoLuong = g.Count() }).ToDictionaryAsync(x => x.Key, x => x.SoLuong);

            ViewBag.KhieuNaiCho = await _db.PhanHois.CountAsync(p => p.Loai == "KhieuNai" && p.TrangThai == "ChuaXuLy");
            ViewBag.PhanHoiCho = await _db.PhanHois.CountAsync(p => p.TrangThai == "ChuaXuLy");
            ViewBag.HoanTienCho = await _db.YeuCauHoanTiens.CountAsync(y => y.TrangThai == "ChoDuyet");
            ViewBag.BaoCaoDanhGiaCho = await _db.BaoCaoDanhGias.CountAsync(b => b.TrangThai == "ChoXuLy");
            ViewBag.SoChoDuyet = await _db.GianHangs.CountAsync(g => g.TrangThaiDuyet == "ChoDuyet");
            ViewBag.TaiXeChoDuyet = await _db.TaiXes.CountAsync(t => t.TrangThaiDuyet == "ChoDuyet");
            ViewBag.SoSuCo = await _db.DonHangs.CountAsync(d =>
                d.TrangThai == "DangGiao" && d.GiaoHang != null && d.GiaoHang.TrangThai == "GiaoThatBai");

            ViewBag.TopGianHang = await donKy.Where(d => d.TrangThai == "DaGiao")
                .GroupBy(d => d.GianHang!.TenCuaHang)
                .Select(g => new { TenGianHang = g.Key, DoanhThu = g.Sum(x => x.TongTien), SoDon = g.Count() })
                .OrderByDescending(x => x.DoanhThu).Take(5).ToListAsync();

            ViewBag.TopMon = await _db.ChiTietDonHangs
                .Where(c => donKy.Any(d => d.MaDonHang == c.MaDonHang && d.TrangThai == "DaGiao"))
                .GroupBy(c => c.MonAn!.TenMon)
                .Select(g => new { TenMon = g.Key, SoLuong = g.Sum(c => c.SoLuong) })
                .OrderByDescending(x => x.SoLuong).Take(5).ToListAsync();

            // Khu vực nhiều đơn: lấy quận/huyện từ địa chỉ giao (phần áp chót khi địa chỉ có >= 3 phần cách nhau dấu phẩy)
            var diaChis = await donKy.OrderByDescending(d => d.NgayDat).Select(d => d.DiaChiGiaoHang).Take(5000).ToListAsync();
            ViewBag.KhuVuc = diaChis
                .Select(a => a.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries))
                .Where(p => p.Length > 0)
                .Select(p => p.Length >= 3 ? p[^2] : p[^1])
                .GroupBy(x => x).Select(g => new KeyValuePair<string, int>(g.Key, g.Count()))
                .OrderByDescending(x => x.Value).Take(6).ToList();

            // ---- Dữ liệu cho giao diện "Lighting Food": biểu đồ 7 ngày, trạng thái đơn 7 ngày, đơn gần đây ----
            var dh7 = await _db.DonHangs.Where(d => d.NgayDat >= tuan).Select(d => new { d.NgayDat, d.TrangThai, d.TongTien }).ToListAsync();
            var dt7Ngay = new List<KeyValuePair<string, decimal>>();
            for (var i = 0; i < 7; i++)
            {
                var ngay = tuan.AddDays(i);
                dt7Ngay.Add(new KeyValuePair<string, decimal>(ngay.ToString("dd/MM"),
                    dh7.Where(d => d.TrangThai == "DaGiao" && d.NgayDat.Date == ngay).Sum(d => d.TongTien)));
            }
            ViewBag.DoanhThu7Ngay = dt7Ngay;
            ViewBag.TrangThai7Ngay = dh7.GroupBy(d => d.TrangThai).ToDictionary(g => g.Key, g => g.Count());
            ViewBag.DonGanDay = (await _db.DonHangs.OrderByDescending(d => d.NgayDat).Take(5)
                .Select(d => new { d.MaDonHang, KhachHang = d.KhachHang != null ? d.KhachHang.HoTen : "", d.TrangThai, d.NgayDat, d.TongTien })
                .ToListAsync()).Cast<dynamic>().ToList();

            // ---- v95: 15 chỉ số điều hành TOÀN HỆ THỐNG (không phụ thuộc bộ lọc kỳ) ----
            // Quy ước: tiền hàng = TongTien + TienGiam - PhiGiaoHang; hoa hồng = tiền hàng × TyLeChietKhau của quán;
            // giảm giá do nền tảng chịu = voucher toàn hệ thống (KhuyenMai.MaGianHang null); doanh thu nền tảng = hoa hồng - giảm giá nền tảng.
            var tatCa = _db.DonHangs;
            var xong = _db.DonHangs.Where(d => d.TrangThai == "DaGiao");
            ViewBag.TongDonToanHT = await tatCa.CountAsync();
            ViewBag.DonDangGiaoToanHT = await tatCa.CountAsync(d => d.TrangThai == "DangGiao");
            ViewBag.DonHoanThanhToanHT = await xong.CountAsync();
            ViewBag.DonHuyToanHT = await tatCa.CountAsync(d => d.TrangThai == "DaHuy");
            ViewBag.TongDoanhThuToanHT = await xong.SumAsync(d => (decimal?)d.TongTien) ?? 0;
            ViewBag.TongPhiGiaoToanHT = await xong.SumAsync(d => (decimal?)d.PhiGiaoHang) ?? 0;
            var tongHoaHong = await xong.SumAsync(d => (decimal?)((d.TongTien + d.TienGiam - d.PhiGiaoHang) * d.GianHang!.TyLeChietKhau)) ?? 0;
            var giamNenTang = await xong.Where(d => d.KhuyenMaiApDung != null && d.KhuyenMaiApDung.MaGianHang == null)
                .SumAsync(d => (decimal?)d.TienGiam) ?? 0;
            ViewBag.TongHoaHongToanHT = tongHoaHong;
            ViewBag.GiamGiaNenTangToanHT = giamNenTang;
            ViewBag.DoanhThuNenTangToanHT = tongHoaHong - giamNenTang;
            ViewBag.TongPhaiTraQuan = await xong.Where(d => d.QuanDaTraLuc == null)
                .SumAsync(d => (decimal?)((d.TongTien + d.TienGiam - d.PhiGiaoHang) * (1m - d.GianHang!.TyLeChietKhau))) ?? 0;

            // Biểu đồ 30 ngày: doanh thu (đơn hoàn thành) + số đơn đặt mỗi ngày
            var tu30 = homNay.AddDays(-29);
            var dh30 = await _db.DonHangs.Where(d => d.NgayDat >= tu30).Select(d => new { d.NgayDat, d.TrangThai, d.TongTien }).ToListAsync();
            var bieuDo30 = new List<(string Ngay, decimal DoanhThu, int SoDon)>();
            for (var i = 0; i < 30; i++)
            {
                var ngay = tu30.AddDays(i);
                bieuDo30.Add((ngay.ToString("dd/MM"),
                    dh30.Where(d => d.TrangThai == "DaGiao" && d.NgayDat.Date == ngay).Sum(d => d.TongTien),
                    dh30.Count(d => d.NgayDat.Date == ngay)));
            }
            ViewBag.BieuDo30Ngay = bieuDo30;
            var don7 = await _db.DonHangs.CountAsync(d => d.NgayDat >= tuan);
            var don7Truoc = await _db.DonHangs.CountAsync(d => d.NgayDat >= tuanTruoc && d.NgayDat < tuan);
            ViewBag.TangTruongDon7Ngay = don7Truoc > 0 ? (double?)((don7 - don7Truoc) * 100.0 / don7Truoc) : null;

            return View();
        }

        /// <summary>Tìm kiếm nhanh trên thanh trên cùng: chức năng, khách hàng, gian hàng, tài xế, đơn hàng.</summary>
        [HttpGet("TimKiem")]
        public async Task<IActionResult> TimKiem(string? q)
        {
            q = (q ?? "").Trim();
            ViewBag.Q = q;
            var laSuper = User.FindFirst("CapQuyenHan")?.Value == "SuperAdmin";

            var chucNang = new List<(string Ten, string Controller, string Action, string[] TuKhoa, bool Super)>
            {
                ("Tài khoản khách hàng", "AdminKhachHang", "Index", new[]{"khach","khách","nguoi dung","người dùng","tai khoan","tài khoản"}, false),
                ("Gian hàng (đối tác)", "AdminGianHang", "Index", new[]{"gian hang","gian hàng","cua hang","cửa hàng","doi tac","đối tác"}, false),
                ("Duyệt gian hàng", "AdminGianHang", "ChoDuyet", new[]{"duyet","duyệt","cho duyet","chờ duyệt"}, false),
                ("Tài xế", "AdminTaiXe", "Index", new[]{"tai xe","tài xế","shipper"}, false),
                ("Duyệt tài xế", "AdminTaiXe", "ChoDuyet", new[]{"duyet tai xe","duyệt tài xế","ho so","hồ sơ"}, false),
                ("Tất cả đơn hàng", "AdminDonHang", "Index", new[]{"don hang","đơn hàng","order"}, false),
                ("Điều phối giao hàng", "AdminDieuPhoi", "Index", new[]{"dieu phoi","điều phối","giao hang","giao hàng"}, false),
                ("Thanh toán & hoàn tiền", "AdminThanhToan", "Index", new[]{"thanh toan","thanh toán","hoan tien","hoàn tiền","tai chinh","tài chính"}, false),
                ("Khuyến mãi toàn hệ thống", "AdminKhuyenMai", "Index", new[]{"khuyen mai","khuyến mãi","voucher","ma giam gia","mã giảm giá"}, false),
                ("Vấn đề phát sinh", "AdminSuCo", "Index", new[]{"su co","sự cố","van de","vấn đề","phat sinh","phát sinh"}, false),
                ("Phản hồi khách hàng", "AdminPhanHoi", "Index", new[]{"phan hoi","phản hồi","khieu nai","khiếu nại"}, false),
                ("Thống kê & báo cáo", "AdminThongKe", "Index", new[]{"thong ke","thống kê","doanh thu","bao cao","báo cáo"}, false),
                ("Báo cáo / xuất CSV", "AdminBaoCao", "Index", new[]{"csv","xuat","xuất"}, false),
                ("Bản đồ gian hàng", "AdminBanDo", "Index", new[]{"ban do","bản đồ","dia chi","địa chỉ"}, false),
                ("Gửi thông báo", "AdminThongBao", "Index", new[]{"thong bao","thông báo"}, false),
                ("Hồ sơ & đổi mật khẩu", "AdminHoSo", "Index", new[]{"mat khau","mật khẩu","doi mat khau","đổi mật khẩu","ho so","hồ sơ"}, false),
                ("Bảo mật tài khoản", "BaoMat", "Index", new[]{"bao mat","bảo mật"}, false),
                ("Tài khoản quản trị / phân quyền", "AdminNhanVien", "Index", new[]{"quan tri","quản trị","phan quyen","phân quyền","nhan vien","nhân viên"}, true),
                ("Phí & chính sách", "AdminCauHinh", "Index", new[]{"phi","phí","chinh sach","chính sách"}, true),
                ("Hệ thống & phiên", "AdminHeThong", "Index", new[]{"he thong","hệ thống","phien","phiên"}, true),
                ("Nhật ký thao tác", "AdminNhatKy", "Index", new[]{"nhat ky","nhật ký","log"}, true),
            };
            var ql = q.ToLowerInvariant();
            ViewBag.ChucNang = string.IsNullOrEmpty(q) ? new List<dynamic>() :
                chucNang.Where(c => (!c.Super || laSuper) && (c.Ten.ToLowerInvariant().Contains(ql) || c.TuKhoa.Any(k => k.Contains(ql) || ql.Contains(k))))
                        .Select(c => (dynamic)new { c.Ten, c.Controller, c.Action }).ToList();

            if (string.IsNullOrEmpty(q))
            {
                ViewBag.KhachHang = new List<dynamic>(); ViewBag.GianHang = new List<dynamic>();
                ViewBag.TaiXe = new List<dynamic>(); ViewBag.DonHang = new List<dynamic>();
                return View();
            }

            ViewBag.KhachHang = (await _db.KhachHangs
                .Where(k => k.HoTen.Contains(q) || k.SDT.Contains(q))
                .OrderByDescending(k => k.MaKH).Take(10)
                .Select(k => new { k.MaKH, k.HoTen, k.SDT }).ToListAsync()).Cast<dynamic>().ToList();
            ViewBag.GianHang = (await _db.GianHangs
                .Where(g => g.TenCuaHang.Contains(q) || g.SDT.Contains(q) || g.DiaChi.Contains(q))
                .OrderByDescending(g => g.MaGianHang).Take(10)
                .Select(g => new { g.MaGianHang, g.TenCuaHang, g.DiaChi, g.TrangThaiDuyet }).ToListAsync()).Cast<dynamic>().ToList();
            ViewBag.TaiXe = (await _db.TaiXes
                .Where(t => t.HoTen.Contains(q) || t.SDT.Contains(q) || (t.BienSo != null && t.BienSo.Contains(q)))
                .OrderByDescending(t => t.MaTaiXe).Take(10)
                .Select(t => new { t.MaTaiXe, t.HoTen, t.SDT, t.TrangThaiDuyet }).ToListAsync()).Cast<dynamic>().ToList();

            var ds = new List<dynamic>();
            if (int.TryParse(q.TrimStart('#'), out var maDon))
            {
                ds = (await _db.DonHangs.Where(d => d.MaDonHang == maDon)
                    .Select(d => new { d.MaDonHang, d.TrangThai, d.TongTien, d.NgayDat }).ToListAsync()).Cast<dynamic>().ToList();
            }
            ViewBag.DonHang = ds;
            return View();
        }
    }
}
