using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers
{
    public class DriverHoSoViewModel
    {
        [Required(ErrorMessage = "Vui lòng nhập họ tên")]
        public string HoTen { get; set; } = "";
        [Required(ErrorMessage = "Vui lòng nhập số điện thoại")]
        public string SDT { get; set; } = "";
        public string? PhuongTien { get; set; }
        public string? BienSo { get; set; }
        public string? KhuVucHoatDong { get; set; }
        public string? MatKhauMoi { get; set; }
        public string? XacNhanMatKhauMoi { get; set; }

        // Giấy tờ
        public string? SoCCCD { get; set; }
        public string? SoGPLX { get; set; }

        // Chỉ để hiển thị (không nhận từ form)
        public string? AnhDaiDien { get; set; }
        public string? AnhGPLX { get; set; }
        public string TrangThaiDuyet { get; set; } = "DaDuyet";
        public string? LyDoTuChoi { get; set; }
        public string? YeuCauBoSung { get; set; }
    }

    [Route("TaiXe/HoSo")]
    public class DriverHoSoController : TaiXeBaseController
    {
        private readonly AppDbContext _db;
        private readonly IFileStorageService _luuTru;

        public DriverHoSoController(AppDbContext db, IFileStorageService luuTru)
        {
            _db = db;
            _luuTru = luuTru;
        }

        private static void NapHienThi(DriverHoSoViewModel vm, Models.Entities.TaiXe t)
        {
            vm.AnhDaiDien = t.AnhDaiDien;
            vm.AnhGPLX = t.AnhGPLX;
            vm.TrangThaiDuyet = t.TrangThaiDuyet;
            vm.LyDoTuChoi = t.LyDoTuChoi;
            vm.YeuCauBoSung = t.YeuCauBoSung;
        }

        [HttpGet("")]
        public async Task<IActionResult> Index()
        {
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == CurrentTaiXeId);
            var vm = new DriverHoSoViewModel
            {
                HoTen = taiXe.HoTen,
                SDT = taiXe.SDT,
                PhuongTien = taiXe.PhuongTien,
                BienSo = taiXe.BienSo,
                KhuVucHoatDong = taiXe.KhuVucHoatDong,
                SoCCCD = taiXe.SoCCCD,
                SoGPLX = taiXe.SoGPLX,
            };
            NapHienThi(vm, taiXe);
            return View(vm);
        }

        [HttpPost("")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(DriverHoSoViewModel vm, IFormFile? anhDaiDien, IFormFile? anhGplx)
        {
            if (!string.IsNullOrEmpty(vm.MatKhauMoi) && vm.MatKhauMoi != vm.XacNhanMatKhauMoi)
                ModelState.AddModelError(nameof(vm.XacNhanMatKhauMoi), "Xác nhận mật khẩu không khớp.");

            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == CurrentTaiXeId);
            if (!ModelState.IsValid) { NapHienThi(vm, taiXe); return View(vm); }

            var sdt = new string((vm.SDT ?? "").Where(char.IsDigit).ToArray());
            if (sdt.Length < 9 || sdt.Length > 11)
            {
                ModelState.AddModelError(nameof(vm.SDT), "Số điện thoại phải có 9–11 chữ số.");
                NapHienThi(vm, taiXe); return View(vm);
            }

            string? anhDaiDienMoi = null, anhGplxMoi = null;
            try
            {
                if (anhDaiDien is { Length: > 0 }) anhDaiDienMoi = await _luuTru.SaveFileAsync(anhDaiDien, "taixe");
                if (anhGplx is { Length: > 0 }) anhGplxMoi = await _luuTru.SaveFileAsync(anhGplx, "taixe-giayto");
            }
            catch (ArgumentException ex)
            {
                ModelState.AddModelError("", ex.Message);
                NapHienThi(vm, taiXe); return View(vm);
            }

            var doiGiayTo = anhGplxMoi != null
                || (vm.SoCCCD ?? "").Trim() != (taiXe.SoCCCD ?? "")
                || (vm.SoGPLX ?? "").Trim() != (taiXe.SoGPLX ?? "");
            taiXe.SoCCCD = string.IsNullOrWhiteSpace(vm.SoCCCD) ? null : vm.SoCCCD.Trim();
            taiXe.SoGPLX = string.IsNullOrWhiteSpace(vm.SoGPLX) ? null : vm.SoGPLX.Trim();
            if (anhDaiDienMoi != null) taiXe.AnhDaiDien = anhDaiDienMoi;
            if (anhGplxMoi != null) taiXe.AnhGPLX = anhGplxMoi;
            if (doiGiayTo) await DriverDonXuLy.BaoQuanTriDoiGiayToAsync(_db, taiXe);

            taiXe.HoTen = vm.HoTen;
            taiXe.SDT = vm.SDT;
            taiXe.PhuongTien = vm.PhuongTien;
            taiXe.BienSo = vm.BienSo;
            taiXe.KhuVucHoatDong = FoodServiceApp.Web.Services.KhuVucHelper.ChuanHoa(vm.KhuVucHoatDong);

            if (!string.IsNullOrEmpty(vm.MatKhauMoi))
            {
                var taiKhoan = await _db.TaiKhoans.FirstAsync(t => t.MaTK == taiXe.MaTK);
                taiKhoan.MatKhau = MatKhauHelper.Hash(vm.MatKhauMoi);
                taiKhoan.PhienHopLeTu = DateTime.UtcNow;   // thu hồi các token đã cấp (phải đăng nhập lại)
            }

            await _db.SaveChangesAsync();
            TempData["ThongBao"] = "Đã cập nhật hồ sơ.";
            return RedirectToAction("Index");
        }
    }
}
