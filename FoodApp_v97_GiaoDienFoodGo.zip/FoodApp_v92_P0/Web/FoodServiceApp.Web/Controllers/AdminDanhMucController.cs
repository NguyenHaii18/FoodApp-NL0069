using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>
    /// Quản lý danh mục món ăn: xem theo gian hàng, đổi tên (tên vi phạm), ẩn/hiện, xóa danh mục trống.
    /// Mọi thay đổi bắt buộc có lý do và gửi thông báo cho gian hàng. Không đụng tới giá món.
    /// </summary>
    [Route("QuanTri/DanhMuc")]
    [FoodServiceApp.Web.Filters.CoQuyenGhi("ThongBao")]
    public class AdminDanhMucController : QuanTriBaseController
    {
        private readonly AppDbContext _db;
        public AdminDanhMucController(AppDbContext db) { _db = db; }

        [HttpGet("")]
        public async Task<IActionResult> Index(int? maGianHang, string? tuKhoa, bool? daAn)
        {
            var q = _db.DanhMucs.AsNoTracking().Include(d => d.GianHang).Include(d => d.MonAns).AsQueryable();
            if (maGianHang != null) q = q.Where(d => d.MaGianHang == maGianHang);
            if (!string.IsNullOrWhiteSpace(tuKhoa)) q = q.Where(d => d.TenDanhMuc.Contains(tuKhoa));
            if (daAn == true) q = q.Where(d => d.DaAn);
            ViewBag.MaGianHang = maGianHang; ViewBag.TuKhoa = tuKhoa ?? ""; ViewBag.DaAn = daAn == true;
            ViewBag.GianHangs = await _db.GianHangs.AsNoTracking().OrderBy(g => g.TenCuaHang).Select(g => new { g.MaGianHang, g.TenCuaHang }).ToListAsync();
            return View(await q.OrderBy(d => d.MaGianHang).ThenBy(d => d.TenDanhMuc).Take(300).ToListAsync());
        }

        private async Task NhacGianHangAsync(DanhMuc dm, string tieuDe, string noiDung)
        {
            var gh = await _db.GianHangs.AsNoTracking().FirstOrDefaultAsync(g => g.MaGianHang == dm.MaGianHang);
            if (gh != null) _db.ThongBaos.Add(new ThongBao { MaTK = gh.MaTK, Loai = "HeThong", TieuDe = tieuDe, NoiDung = noiDung });
        }

        [HttpPost("{id:int}/doi-ten")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DoiTen(int id, string? tenMoi, string? lyDo)
        {
            var dm = await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaDanhMuc == id);
            if (dm == null) return NotFound();
            tenMoi = tenMoi?.Trim() ?? ""; lyDo = lyDo?.Trim() ?? "";
            string? loi = null;
            if (tenMoi.Length < 2 || tenMoi.Length > 100) loi = "Tên danh mục dài 2–100 ký tự.";
            else if (lyDo.Length < 5) loi = "Bắt buộc nhập lý do đổi tên (tối thiểu 5 ký tự).";
            else if (await _db.DanhMucs.AnyAsync(d => d.MaGianHang == dm.MaGianHang && d.MaDanhMuc != id && d.TenDanhMuc == tenMoi)) loi = "Gian hàng này đã có danh mục trùng tên.";
            if (loi != null) { TempData["LoiThongBao"] = loi; return RedirectToAction("Index", new { maGianHang = dm.MaGianHang }); }

            var cu = dm.TenDanhMuc;
            dm.TenDanhMuc = tenMoi;
            await NhacGianHangAsync(dm, $"Danh mục \"{cu}\" được đổi tên", $"Tên mới: \"{tenMoi}\". Lý do: {lyDo}");
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = $"Đã đổi tên danh mục thành \"{tenMoi}\".";
            return RedirectToAction("Index", new { maGianHang = dm.MaGianHang });
        }

        [HttpPost("{id:int}/an")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> An(int id, string? lyDo)
        {
            var dm = await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaDanhMuc == id);
            if (dm == null) return NotFound();
            if (string.IsNullOrWhiteSpace(lyDo)) { TempData["LoiThongBao"] = "Bắt buộc nhập lý do ẩn danh mục."; return RedirectToAction("Index", new { maGianHang = dm.MaGianHang }); }
            dm.DaAn = true;
            await NhacGianHangAsync(dm, $"Danh mục \"{dm.TenDanhMuc}\" bị ẩn", "Lý do: " + lyDo.Trim());
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = $"Đã ẩn danh mục \"{dm.TenDanhMuc}\".";
            return RedirectToAction("Index", new { maGianHang = dm.MaGianHang });
        }

        [HttpPost("{id:int}/hien")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Hien(int id)
        {
            var dm = await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaDanhMuc == id);
            if (dm == null) return NotFound();
            dm.DaAn = false;
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = $"Đã hiện lại danh mục \"{dm.TenDanhMuc}\".";
            return RedirectToAction("Index", new { maGianHang = dm.MaGianHang });
        }

        // Chỉ xóa danh mục không còn món và không nằm trong chương trình khuyến mãi (tránh mất dữ liệu / lỗi khóa ngoại)
        [HttpPost("{id:int}/xoa")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Xoa(int id, string? lyDo)
        {
            var dm = await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaDanhMuc == id);
            if (dm == null) return NotFound();
            string? loi = null;
            if (string.IsNullOrWhiteSpace(lyDo)) loi = "Bắt buộc nhập lý do xóa danh mục.";
            else if (await _db.MonAns.AnyAsync(m => m.MaDanhMuc == id)) loi = "Danh mục còn món ăn — hãy ẩn danh mục thay vì xóa.";
            else if (await _db.KhuyenMaiDanhMucs.AnyAsync(k => k.MaDanhMuc == id)) loi = "Danh mục đang được dùng trong chương trình khuyến mãi — hãy ẩn thay vì xóa.";
            if (loi != null) { TempData["LoiThongBao"] = loi; return RedirectToAction("Index", new { maGianHang = dm.MaGianHang }); }

            await NhacGianHangAsync(dm, $"Danh mục \"{dm.TenDanhMuc}\" đã bị xóa", "Lý do: " + lyDo!.Trim());
            _db.DanhMucs.Remove(dm);
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = $"Đã xóa danh mục \"{dm.TenDanhMuc}\".";
            return RedirectToAction("Index", new { maGianHang = dm.MaGianHang });
        }
    }
}
