using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;

namespace FoodServiceApp.Web.Controllers
{
    public class DonHangController : GianHangBaseController
    {
        private readonly AppDbContext _db;

        public DonHangController(AppDbContext db)
        {
            _db = db;
        }

        // GET /DonHang?trangThai=ChoXacNhan
        public async Task<IActionResult> Index(string? trangThai)
        {
            var query = _db.DonHangs
                .Include(d => d.GiaoHang)
                .Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .Where(d => d.MaGianHang == CurrentGianHangId);

            if (!string.IsNullOrEmpty(trangThai))
                query = query.Where(d => d.TrangThai == trangThai);

            var danhSach = await query.OrderByDescending(d => d.NgayDat).ToListAsync();

            ViewBag.TrangThaiDangLoc = trangThai ?? "";
            // v31: lựa chọn người giao (tài xế của quán / shipper ngoài)
            ViewBag.TaiXeQuan = await FoodServiceApp.Web.Services.NguonGiaoXuLy.TaiXeCuaQuan(_db, CurrentGianHangId).OrderBy(t => t.HoTen).ToListAsync();
            ViewBag.CheDoGiao = await _db.GianHangs.Where(g => g.MaGianHang == CurrentGianHangId).Select(g => g.CheDoGiao).FirstOrDefaultAsync() ?? "Ngoai";
            var maTx = danhSach.Where(d => d.MaTaiXe != null).Select(d => d.MaTaiXe!.Value).Distinct().ToList();
            ViewBag.TenTaiXe = await _db.TaiXes.Where(t => maTx.Contains(t.MaTaiXe)).ToDictionaryAsync(t => t.MaTaiXe, t => t.HoTen + (t.MaGianHang != null ? " (quán)" : " (shipper ngoài)"));
            return View(danhSach);
        }

        public async Task<IActionResult> ChiTiet(int id)
        {
            var don = await _db.DonHangs
                .Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .Include(d => d.ThanhToan)
                .FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaGianHang == CurrentGianHangId);

            if (don == null) return NotFound();
            return View(don);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TienDoChuanBi(int id, string buoc)
        {
            var don = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaGianHang == CurrentGianHangId);
            if (don == null) return NotFound();
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.DoiChuanBiAsync(_db, don, buoc);
            TempData[kq.Ok ? "ThongBao" : "LoiThongBao"] = kq.ThongDiep;
            return RedirectToAction("Index");
        }

        /// <summary>v31: quán chọn người giao cho đơn đã xác nhận: nguon = Quan (kèm maTaiXe) | Ngoai.</summary>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChonNguoiGiao(int id, string nguon, int? maTaiXe)
        {
            var don = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaGianHang == CurrentGianHangId);
            if (don == null) return NotFound();
            var kq = FoodServiceApp.Web.Services.NguonGiaoXuLy.ChuanHoa(nguon) == "Quan"
                ? (maTaiXe == null ? new FoodServiceApp.Web.Services.KetQuaGiao(false, "Hãy chọn một tài xế của quán.") : await FoodServiceApp.Web.Services.NguonGiaoXuLy.GanTaiXeQuanAsync(_db, don, maTaiXe.Value))
                : await FoodServiceApp.Web.Services.NguonGiaoXuLy.ChuyenShipperNgoaiAsync(_db, don);
            TempData[kq.Ok ? "ThongBao" : "LoiThongBao"] = kq.ThongDiep;
            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BanGiao(int id)
        {
            var don = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaGianHang == CurrentGianHangId);
            if (don == null) return NotFound();
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.BanGiaoAsync(_db, don);
            TempData[kq.Ok ? "ThongBao" : "LoiThongBao"] = kq.ThongDiep;
            return RedirectToAction("Index");
        }

        // Luồng trạng thái hợp lệ: ChoXacNhan -> DaXacNhan -> DangGiao -> DaGiao
        //                          ChoXacNhan/DaXacNhan -> DaHuy
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CapNhatTrangThai(int id, string trangThaiMoi, string? lyDo = null, int? chuanBiPhut = null)
        {
            var don = await _db.DonHangs.Include(d => d.ThanhToan)
                .FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaGianHang == CurrentGianHangId);
            if (don == null) return NotFound();

            if (!FoodServiceApp.Web.Services.TrangThaiDon.ChoPhep(don.TrangThai, trangThaiMoi, FoodServiceApp.Web.Services.TrangThaiDon.GianHang))
                await FoodServiceApp.Web.Services.TrangThaiDon.GhiTuChoiAsync(_db, HttpContext, don.MaDonHang, don.TrangThai, trangThaiMoi, FoodServiceApp.Web.Services.TrangThaiDon.GianHang, "Chuyển trạng thái không nằm trong quy trình cho phép.");
            if (FoodServiceApp.Web.Services.TrangThaiDon.ChoPhep(don.TrangThai, trangThaiMoi, FoodServiceApp.Web.Services.TrangThaiDon.GianHang))
            {
                // Từ chối / hủy đơn phải ghi rõ lý do để khách biết (và Quản trị đối soát)
                lyDo = lyDo?.Trim();
                if (trangThaiMoi == "DaHuy" && (string.IsNullOrWhiteSpace(lyDo) || lyDo.Length < 5))
                {
                    TempData["LoiThongBao"] = "Nhập lý do từ chối / hủy đơn (tối thiểu 5 ký tự).";
                    return RedirectToAction("Index");
                }
                don.TrangThai = trangThaiMoi;
                if (trangThaiMoi == "DaXacNhan" && chuanBiPhut is >= 5 and <= 120) don.ThoiGianChuanBiPhut = chuanBiPhut;   // ước tính thời gian chuẩn bị

                // Huỷ đơn đã thanh toán online -> đánh dấu hoàn tiền để Quản trị đối soát
                if (trangThaiMoi == "DaHuy")
                {
                    don.LyDoTuChoi = lyDo;
                    await FoodServiceApp.Web.Services.HoanTienXuLy.TaoYeuCauKhiHuyAsync(_db, don, "GianHang", "Gian hàng hủy đơn #" + don.MaDonHang);
                }

                if (trangThaiMoi == "DaXacNhan") await FoodServiceApp.Web.Services.GiaoHangXuLy.BaoQuanTriDonCanDieuPhoiAsync(_db, don, don.SanSangGiao);   // chuyển đơn lên Quản trị điều phối
                await _db.SaveChangesAsync();
                if (trangThaiMoi == "DaHuy") await FoodServiceApp.Web.Services.TrangThaiDon.SauKhiHuyAsync(_db, don, don.LyDoTuChoi ?? "Gian hàng hủy đơn");
                TempData["ThongBao"] = $"Đã cập nhật đơn #{don.MaDonHang} sang trạng thái mới.";
            }
            else
            {
                TempData["LoiThongBao"] = "Không thể chuyển sang trạng thái này từ trạng thái hiện tại.";
            }

            return RedirectToAction("Index");
        }
    }
}
