using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.ViewModels;

namespace FoodServiceApp.Web.Controllers
{
    public class DoanhThuController : GianHangBaseController
    {
        private readonly AppDbContext _db;

        public DoanhThuController(AppDbContext db)
        {
            _db = db;
        }

        // GET /DoanhThu?ky=ngay|tuan|thang   (&xuat=csv để tải báo cáo của kỳ đang xem)
        public async Task<IActionResult> Index(string? ky, string? xuat)
        {
            ky = ky is "ngay" or "tuan" or "thang" ? ky : "thang";
            var (tuNgay, tenKy) = ky switch
            {
                "ngay" => (DateTime.Today, "Hôm nay"),
                "tuan" => (DateTime.Today.AddDays(-6), "7 ngày gần nhất"),
                _ => (DateTime.Today.AddDays(-29), "30 ngày gần nhất"),
            };

            var tyLe = await _db.GianHangs.AsNoTracking().Where(g => g.MaGianHang == CurrentGianHangId).Select(g => g.TyLeChietKhau).FirstAsync();

            var donKy = await _db.DonHangs
                .Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .Where(d => d.MaGianHang == CurrentGianHangId
                            && d.NgayDat >= tuNgay
                            && (d.TrangThai == "DaGiao" || d.TrangThai == "DaHuy"))
                .ToListAsync();
            var donHoanThanh = donKy.Where(d => d.TrangThai == "DaGiao").ToList();
            var donHuy = donKy.Where(d => d.TrangThai == "DaHuy").ToList();

            // Cùng cách tính với báo cáo phí nền tảng của Quản trị: (tổng tiền - phí giao) x tỷ lệ chiết khấu
            decimal PhiNen(decimal tongTien, decimal phiGiao) => Math.Round((tongTien - phiGiao) * tyLe, 0);

            if (xuat == "csv")
            {
                var dong = donKy.OrderByDescending(d => d.NgayDat).Select(d =>
                {
                    var ok = d.TrangThai == "DaGiao";
                    var hang = d.TongTien - d.PhiGiaoHang;
                    var phi = ok ? PhiNen(d.TongTien, d.PhiGiaoHang) : 0;
                    return new object?[] { d.MaDonHang, d.NgayDat, ok ? "Hoàn thành" : "Đã hủy", hang, d.PhiGiaoHang, d.TongTien, phi, ok ? hang - phi : 0, ok ? "" : d.LyDoTuChoi };
                });
                return Csv("BaoCao_DoanhThu_" + ky,
                    new[] { "Mã đơn", "Ngày đặt", "Trạng thái", "Tiền hàng", "Phí giao hàng", "Tổng tiền", "Phí nền tảng", "Thực nhận", "Lý do hủy" }, dong);
            }

            var doanhThuTheoNgay = donHoanThanh
                .GroupBy(d => d.NgayDat.Date)
                .OrderBy(g => g.Key)
                .Select(g => (g.Key, g.Sum(d => d.TongTien)))
                .ToList();

            var monBanChay = donHoanThanh
                .SelectMany(d => d.ChiTiets)
                .GroupBy(c => c.MonAn?.TenMon ?? "Không rõ")
                .Select(g => (g.Key, g.Sum(c => c.SoLuong)))
                .OrderByDescending(x => x.Item2)
                .Take(5)
                .ToList();

            var tienHang = donHoanThanh.Sum(d => d.TongTien - d.PhiGiaoHang);
            var phiNenTang = donHoanThanh.Sum(d => PhiNen(d.TongTien, d.PhiGiaoHang));
            var tongTien = donHoanThanh.Sum(d => d.TongTien);

            // Yêu cầu hoàn tiền của các đơn thuộc gian hàng này trong kỳ
            var hoanTien = await _db.YeuCauHoanTiens.AsNoTracking()
                .Where(y => _db.DonHangs.Any(d => d.MaDonHang == y.MaDonHang && d.MaGianHang == CurrentGianHangId && d.NgayDat >= tuNgay))
                .ToListAsync();

            var vm = new DoanhThuViewModel
            {
                Ky = ky,
                TenKy = tenKy,
                TongDoanhThu30Ngay = tongTien,
                TongDonHoanThanh30Ngay = donHoanThanh.Count,
                DoanhThuTheoNgay = doanhThuTheoNgay,
                MonBanChay = monBanChay,
                TongTienHang = tienHang,
                PhiGiaoHang = donHoanThanh.Sum(d => d.PhiGiaoHang),
                TyLeChietKhau = tyLe,
                PhiNenTang = phiNenTang,
                ThucNhan = tienHang - phiNenTang,
                GiaTriTrungBinh = donHoanThanh.Count > 0 ? Math.Round(tongTien / donHoanThanh.Count, 0) : 0,
                SoDonHuy = donHuy.Count,
                SoYeuCauHoanTien = hoanTien.Count,
                TongHoanTienDaDuyet = hoanTien.Where(y => y.TrangThai == "DaDuyet").Sum(y => y.SoTien),
            };

            return View(vm);
        }

        // CSV UTF-8 có BOM để Excel đọc đúng tiếng Việt; chống CSV injection (giống báo cáo của Quản trị)
        private FileContentResult Csv(string tenFile, string[] tieuDe, IEnumerable<object?[]> dong)
        {
            static string Q(object? v)
            {
                var t = v switch
                {
                    null => "",
                    DateTime d => d.ToString("yyyy-MM-dd HH:mm:ss"),
                    decimal m => m.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture),
                    _ => v.ToString() ?? "",
                };
                if (t.Length > 0 && (t[0] == '=' || t[0] == '+' || t[0] == '-' || t[0] == '@')) t = "'" + t;
                return "\"" + t.Replace("\"", "\"\"") + "\"";
            }
            var sb = new StringBuilder();
            sb.AppendLine(string.Join(",", tieuDe.Select(Q)));
            foreach (var r in dong) sb.AppendLine(string.Join(",", r.Select(Q)));
            var bytes = new UTF8Encoding(true).GetPreamble().Concat(Encoding.UTF8.GetBytes(sb.ToString())).ToArray();
            return File(bytes, "text/csv; charset=utf-8", $"{tenFile}_{DateTime.Now:yyyyMMdd_HHmm}.csv");
        }
    }
}
