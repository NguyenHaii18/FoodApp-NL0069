using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;

namespace FoodServiceApp.Web.Controllers
{
    [Route("QuanTri/KhachHang")]
    [FoodServiceApp.Web.Filters.ChiSuperAdminGhi]
    public class AdminKhachHangController : QuanTriBaseController
    {
        private readonly AppDbContext _db;

        public AdminKhachHangController(AppDbContext db)
        {
            _db = db;
        }

        [HttpGet("")]
        public async Task<IActionResult> Index(string? timKiem)
        {
            var query = _db.KhachHangs
                .Join(_db.TaiKhoans, kh => kh.MaTK, tk => tk.MaTK, (kh, tk) => new { KhachHang = kh, TaiKhoan = tk });

            if (!string.IsNullOrWhiteSpace(timKiem))
                query = query.Where(x => x.KhachHang.HoTen.Contains(timKiem) || x.KhachHang.SDT.Contains(timKiem));

            var danhSach = await query.OrderByDescending(x => x.KhachHang.MaKH).ToListAsync();

            ViewBag.TimKiem = timKiem ?? "";
            return View(danhSach.Select(x => (x.KhachHang, x.TaiKhoan)).ToList());
        }

        [HttpGet("ChiTiet/{id:int}")]
        public async Task<IActionResult> ChiTiet(int id)
        {
            var kh = await _db.KhachHangs.FirstOrDefaultAsync(k => k.MaKH == id);
            if (kh == null) return NotFound();
            ViewBag.TaiKhoan = await _db.TaiKhoans.FirstAsync(t => t.MaTK == kh.MaTK);
            ViewBag.DonHangs = await _db.DonHangs.Include(d => d.GianHang).Where(d => d.MaKH == id).OrderByDescending(d => d.NgayDat).Take(50).ToListAsync();
            ViewBag.DiaChis = await _db.DiaChiKhachHangs.Where(d => d.MaKH == id).ToListAsync();
            ViewBag.PhanHois = await _db.PhanHois.Where(p => p.MaKH == id).OrderByDescending(p => p.NgayGui).Take(20).ToListAsync();
            ViewBag.BaoCao = await _db.BaoCaoDanhGias.CountAsync(b => b.MaKH == id);
            return View(kh);
        }

        // Xử lý vi phạm: khóa tài khoản kèm lý do (ghi nhật ký tự động + thông báo)
        [HttpPost("XuLyViPham/{maTK:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> XuLyViPham(int maTK, string? lyDo)
        {
            var tk = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == maTK && t.VaiTro == "KhachHang");
            if (tk == null) return NotFound();
            if (string.IsNullOrWhiteSpace(lyDo)) { TempData["LoiThongBao"] = "Nhập lý do xử lý vi phạm."; return RedirectToAction("Index"); }
            tk.TrangThai = false;
            _db.ThongBaos.Add(new FoodServiceApp.Web.Models.Entities.ThongBao { MaTK = tk.MaTK, Loai = "HeThong", TieuDe = "Tài khoản bị khóa do vi phạm", NoiDung = "Lý do: " + lyDo.Trim() });
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = "Đã khóa tài khoản vi phạm và thông báo cho khách.";
            return RedirectToAction("Index");
        }

        // Xử lý yêu cầu THAY ĐỔI dữ liệu cá nhân của khách (khách gửi qua phản hồi/hỗ trợ) — bắt buộc ghi lý do
        [HttpPost("CapNhatThongTin/{maKH:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CapNhatThongTin(int maKH, string? hoTen, string? sdt, string? email, string? lyDo)
        {
            var kh = await _db.KhachHangs.FirstOrDefaultAsync(k => k.MaKH == maKH);
            if (kh == null) return NotFound();
            var tk = await _db.TaiKhoans.FirstAsync(t => t.MaTK == kh.MaTK);

            hoTen = hoTen?.Trim() ?? "";
            var soDt = new string((sdt ?? "").Where(char.IsDigit).ToArray());
            email = email?.Trim();
            lyDo = lyDo?.Trim() ?? "";

            string? loi = null;
            if (lyDo.Length < 5) loi = "Nhập lý do thay đổi (tối thiểu 5 ký tự).";
            else if (hoTen.Length < 2 || hoTen.Length > 100) loi = "Họ tên dài 2–100 ký tự.";
            else if (soDt.Length < 9 || soDt.Length > 11) loi = "Số điện thoại phải có 9–11 chữ số.";
            else if (!string.IsNullOrEmpty(email) && (email.Length > 100 || !email.Contains('@') || email.Contains(' '))) loi = "Email không hợp lệ.";
            else if (await _db.KhachHangs.AnyAsync(k => k.SDT == soDt && k.MaKH != maKH)) loi = "Số điện thoại đã được khách khác sử dụng.";
            if (loi != null) { TempData["LoiThongBao"] = loi; return RedirectToAction("ChiTiet", new { id = maKH }); }

            var emailMoi = string.IsNullOrEmpty(email) ? null : email;
            if (!string.Equals(kh.Email, emailMoi, StringComparison.OrdinalIgnoreCase)) tk.EmailDaXacThuc = false;   // đổi email -> phải xác thực lại
            if (kh.SDT != soDt) tk.SdtDaXacThuc = false;
            kh.HoTen = hoTen; kh.SDT = soDt; kh.Email = emailMoi;

            _db.ThongBaos.Add(new FoodServiceApp.Web.Models.Entities.ThongBao
            { MaTK = tk.MaTK, Loai = "HeThong", TieuDe = "Thông tin tài khoản đã được cập nhật", NoiDung = "Theo yêu cầu của bạn. Ghi chú: " + lyDo });
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = "Đã cập nhật thông tin khách hàng theo yêu cầu.";
            return RedirectToAction("ChiTiet", new { id = maKH });
        }

        // Xử lý yêu cầu XÓA dữ liệu cá nhân: ẩn danh hồ sơ + xóa địa chỉ + khóa tài khoản + thu hồi phiên.
        // Giữ lại các đơn hàng (chứng từ giao dịch/đối soát) nhưng không còn gắn với thông tin định danh của khách.
        [HttpPost("AnDanhDuLieu/{maKH:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AnDanhDuLieu(int maKH, string? lyDo, string? xacNhan)
        {
            var kh = await _db.KhachHangs.FirstOrDefaultAsync(k => k.MaKH == maKH);
            if (kh == null) return NotFound();
            var tk = await _db.TaiKhoans.FirstAsync(t => t.MaTK == kh.MaTK);

            string? loi = null;
            if (string.IsNullOrWhiteSpace(lyDo) || lyDo.Trim().Length < 5) loi = "Nhập lý do / căn cứ xử lý yêu cầu xóa dữ liệu (tối thiểu 5 ký tự).";
            else if (xacNhan?.Trim() != "XOA") loi = "Gõ đúng chữ XOA vào ô xác nhận để thực hiện (thao tác không hoàn tác được).";
            else if (await _db.DonHangs.AnyAsync(d => d.MaKH == maKH && d.TrangThai != "DaGiao" && d.TrangThai != "DaHuy"))
                loi = "Khách còn đơn đang xử lý — chờ đơn hoàn tất hoặc hủy trước khi xóa dữ liệu.";
            if (loi != null) { TempData["LoiThongBao"] = loi; return RedirectToAction("ChiTiet", new { id = maKH }); }

            kh.HoTen = "Khách đã xóa dữ liệu";
            kh.SDT = "x" + kh.MaKH;            // cột SDT bắt buộc có giá trị
            kh.Email = null; kh.DiaChiGiaoHang = null; kh.AnhDaiDien = null;
            _db.DiaChiKhachHangs.RemoveRange(_db.DiaChiKhachHangs.Where(d => d.MaKH == maKH));

            tk.TrangThai = false;
            tk.TenDangNhap = "daxoa_" + kh.MaKH;   // giải phóng tên đăng nhập, không còn đăng nhập được
            tk.EmailDaXacThuc = false; tk.SdtDaXacThuc = false;
            var phien = await _db.PhienDangNhaps.Where(x => x.MaTK == tk.MaTK && x.ThuHoiLuc == null).ToListAsync();
            foreach (var x in phien) x.ThuHoiLuc = DateTime.Now;

            await _db.SaveChangesAsync();
            TempData["ThongBao"] = $"Đã ẩn danh dữ liệu khách #{maKH}, khóa tài khoản và thu hồi {phien.Count} phiên đăng nhập.";
            return RedirectToAction("ChiTiet", new { id = maKH });
        }

        [HttpPost("ToggleKhoa/{maTK:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ToggleKhoa(int maTK)
        {
            var taiKhoan = await _db.TaiKhoans.FirstOrDefaultAsync(t => t.MaTK == maTK && t.VaiTro == "KhachHang");
            if (taiKhoan == null) return NotFound();

            taiKhoan.TrangThai = !taiKhoan.TrangThai;
            await _db.SaveChangesAsync();

            TempData["ThongBao"] = taiKhoan.TrangThai ? "Đã mở khoá tài khoản." : "Đã khoá tài khoản.";
            return RedirectToAction("Index");
        }
    }
}
