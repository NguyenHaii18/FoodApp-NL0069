using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>Trang "Phí & chính sách" công khai cho khách, gian hàng, tài xế — đọc trực tiếp từ cấu hình quản trị đặt.</summary>
    [AllowAnonymous]
    [Route("ChinhSach")]
    public class ChinhSachController : Controller
    {
        private readonly CauHinhService _ch;
        public ChinhSachController(CauHinhService ch) { _ch = ch; }

        [HttpGet("")]
        public async Task<IActionResult> Index()
        {
            ViewBag.CS = await ChinhSachCongKhai.LayAsync(_ch);
            return View();
        }
    }

    /// <summary>Dữ liệu chính sách đang áp dụng (dùng chung cho trang web và API mobile).</summary>
    public class ChinhSachCongKhai
    {
        public decimal PhiMoiKm { get; set; }
        public decimal PhiMacDinh { get; set; }
        public decimal BanKinhKm { get; set; }
        public decimal HoaHongMacDinh { get; set; }
        public int TuHuyPhut { get; set; }
        public string QuyDinhHuyDon { get; set; } = "";
        public decimal NguongHoanTienQuanLy { get; set; }
        public string ChinhSachHoanTien { get; set; } = "";
        public int VoucherToiDaMoiKhach { get; set; }
        public int DuKienPhut { get; set; }
        public int TaiXePhanHoiPhut { get; set; }
        public string QuyDinhKhachHang { get; set; } = "";
        public string QuyDinhGianHang { get; set; } = "";
        public string QuyDinhTaiXe { get; set; } = "";

        public static async Task<ChinhSachCongKhai> LayAsync(CauHinhService ch)
        {
            string Mac(string k) => ChinhSachMeta.Tim(k)!.MacDinh;
            async Task<string> Chuoi(string k) => await ch.LayChuoiAsync(k, Mac(k)) ?? Mac(k);
            async Task<decimal> So(string k) => await ch.LaySoAsync(k, decimal.Parse(Mac(k), System.Globalization.CultureInfo.InvariantCulture));
            return new ChinhSachCongKhai
            {
                PhiMoiKm = await So("Giao.PhiMoiKm"),
                PhiMacDinh = await So("Giao.PhiMacDinh"),
                BanKinhKm = await So("Giao.BanKinhKm"),
                HoaHongMacDinh = await So("HoaHong.MacDinh"),
                TuHuyPhut = (int)await So("Don.TuHuyPhut"),
                QuyDinhHuyDon = await Chuoi("QuyDinh.HuyDon"),
                NguongHoanTienQuanLy = await So("HoanTien.NguongQuanLy"),
                ChinhSachHoanTien = await Chuoi("HoanTien.ChinhSach"),
                VoucherToiDaMoiKhach = (int)await So("Voucher.ToiDaMoiKhach"),
                DuKienPhut = (int)await So("Don.DuKienPhut"),
                TaiXePhanHoiPhut = (int)await So("Don.TaiXePhanHoiPhut"),
                QuyDinhKhachHang = await Chuoi("QuyDinh.KhachHang"),
                QuyDinhGianHang = await Chuoi("QuyDinh.GianHang"),
                QuyDinhTaiXe = await Chuoi("QuyDinh.TaiXe"),
            };
        }
    }
}
