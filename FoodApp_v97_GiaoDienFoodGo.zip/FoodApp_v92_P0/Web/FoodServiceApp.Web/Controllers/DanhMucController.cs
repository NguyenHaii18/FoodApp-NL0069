using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>Gian hàng tự quản lý danh mục món ăn: thêm, đổi tên, xóa (danh mục trống). Quản trị vẫn có quyền ẩn/đổi tên khi vi phạm.</summary>
    public class DanhMucController : GianHangBaseController
    {
        private readonly AppDbContext _db;
        public DanhMucController(AppDbContext db) { _db = db; }

        public async Task<IActionResult> Index()
        {
            var ds = await _db.DanhMucs.AsNoTracking().Include(d => d.MonAns)
                .Where(d => d.MaGianHang == CurrentGianHangId).OrderBy(d => d.TenDanhMuc).ToListAsync();
            return View(ds);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Them(string? ten)
        {
            ten = ten?.Trim() ?? "";
            if (ten.Length < 2 || ten.Length > 100) { TempData["LoiThongBao"] = "Tên danh mục dài 2–100 ký tự."; return RedirectToAction("Index"); }
            if (await _db.DanhMucs.AnyAsync(d => d.MaGianHang == CurrentGianHangId && d.TenDanhMuc == ten))
            { TempData["LoiThongBao"] = "Bạn đã có danh mục trùng tên."; return RedirectToAction("Index"); }
            _db.DanhMucs.Add(new DanhMuc { MaGianHang = CurrentGianHangId, TenDanhMuc = ten });
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = $"Đã thêm danh mục \"{ten}\".";
            return RedirectToAction("Index");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DoiTen(int id, string? ten)
        {
            var dm = await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaDanhMuc == id && d.MaGianHang == CurrentGianHangId);
            if (dm == null) return NotFound();
            ten = ten?.Trim() ?? "";
            if (ten.Length < 2 || ten.Length > 100) { TempData["LoiThongBao"] = "Tên danh mục dài 2–100 ký tự."; return RedirectToAction("Index"); }
            if (await _db.DanhMucs.AnyAsync(d => d.MaGianHang == CurrentGianHangId && d.MaDanhMuc != id && d.TenDanhMuc == ten))
            { TempData["LoiThongBao"] = "Bạn đã có danh mục trùng tên."; return RedirectToAction("Index"); }
            dm.TenDanhMuc = ten;
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = "Đã đổi tên danh mục.";
            return RedirectToAction("Index");
        }

        // Chỉ xóa danh mục không còn món và không nằm trong chương trình khuyến mãi (tránh mất dữ liệu / lỗi khóa ngoại)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Xoa(int id)
        {
            var dm = await _db.DanhMucs.FirstOrDefaultAsync(d => d.MaDanhMuc == id && d.MaGianHang == CurrentGianHangId);
            if (dm == null) return NotFound();
            if (await _db.MonAns.AnyAsync(m => m.MaDanhMuc == id))
            { TempData["LoiThongBao"] = "Danh mục còn món ăn — hãy chuyển hoặc xóa các món trước."; return RedirectToAction("Index"); }
            if (await _db.KhuyenMaiDanhMucs.AnyAsync(k => k.MaDanhMuc == id))
            { TempData["LoiThongBao"] = "Danh mục đang nằm trong chương trình khuyến mãi — hãy gỡ khỏi khuyến mãi trước."; return RedirectToAction("Index"); }
            _db.DanhMucs.Remove(dm);
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = $"Đã xóa danh mục \"{dm.TenDanhMuc}\".";
            return RedirectToAction("Index");
        }
    }
}
