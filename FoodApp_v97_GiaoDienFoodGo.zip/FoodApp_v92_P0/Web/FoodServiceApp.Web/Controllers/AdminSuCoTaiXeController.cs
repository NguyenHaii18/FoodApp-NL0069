using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>
    /// Phản ánh / sự cố do TÀI XẾ báo (tai nạn, món hư hỏng, khách không liên lạc được, sai lệch thu nhập/COD...).
    /// Khác với "Vấn đề phát sinh" (AdminSuCo, đơn giao thất bại cần can thiệp): đây là hộp thư phản ánh của tài xế.
    /// Nhân viên hỗ trợ cũng được xử lý (giống phản hồi khách hàng). Sai lệch thu nhập → chuyển sang trang tài xế để ghi điều chỉnh.
    /// </summary>
    [Route("QuanTri/SuCoTaiXe")]
    public class AdminSuCoTaiXeController : QuanTriBaseController
    {
        private readonly AppDbContext _db;
        public AdminSuCoTaiXeController(AppDbContext db) { _db = db; }

        [HttpGet("")]
        public async Task<IActionResult> Index(string? trangThai, string? loai)
        {
            var q = _db.SuCoGiaoHangs.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(trangThai)) q = q.Where(x => x.TrangThai == trangThai);
            if (!string.IsNullOrWhiteSpace(loai)) q = q.Where(x => x.Loai == loai);

            // Chưa xử lý lên trước, rồi mới nhất trước
            var ds = await q.OrderBy(x => x.TrangThai == "DaXuLy" ? 1 : 0).ThenByDescending(x => x.NgayTao).Take(200).ToListAsync();
            var ids = ds.Select(x => x.MaTaiXe).Distinct().ToList();
            ViewBag.TaiXes = await _db.TaiXes.AsNoTracking().Where(t => ids.Contains(t.MaTaiXe)).ToDictionaryAsync(t => t.MaTaiXe, t => t.HoTen);
            ViewBag.TrangThai = trangThai; ViewBag.Loai = loai;
            ViewBag.SoCho = await _db.SuCoGiaoHangs.CountAsync(x => x.TrangThai == "ChoXuLy");
            return View(ds);
        }

        [HttpPost("xu-ly/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> XuLy(int id, string? trangThai, string? phanHoi)
        {
            var sc = await _db.SuCoGiaoHangs.FirstOrDefaultAsync(x => x.MaSuCo == id);
            if (sc == null) return NotFound();
            if (trangThai is not ("DangXuLy" or "DaXuLy")) { TempData["LoiThongBao"] = "Trạng thái không hợp lệ."; return RedirectToAction("Index"); }
            phanHoi = phanHoi?.Trim();
            if (trangThai == "DaXuLy" && string.IsNullOrWhiteSpace(phanHoi))
            { TempData["LoiThongBao"] = "Nhập kết quả / lý do giải quyết trước khi đóng sự cố."; return RedirectToAction("Index"); }

            sc.TrangThai = trangThai;
            if (!string.IsNullOrWhiteSpace(phanHoi)) sc.PhanHoiQuanTri = phanHoi;
            sc.MaTKXuLy = int.TryParse(User.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value, out var a) ? a : null;
            if (trangThai == "DaXuLy") sc.NgayXuLy = DateTime.Now;

            var tx = await _db.TaiXes.FirstOrDefaultAsync(t => t.MaTaiXe == sc.MaTaiXe);
            if (tx != null)
                _db.ThongBaos.Add(new ThongBao
                {
                    MaTK = tx.MaTK, Loai = "HeThong",
                    TieuDe = trangThai == "DaXuLy" ? "Phản ánh của bạn đã được giải quyết" : "Phản ánh của bạn đang được xử lý",
                    NoiDung = string.IsNullOrWhiteSpace(sc.PhanHoiQuanTri) ? $"Sự cố #{sc.MaSuCo}" : $"Sự cố #{sc.MaSuCo}: {sc.PhanHoiQuanTri}",
                });
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = trangThai == "DaXuLy" ? $"Đã đóng sự cố #{sc.MaSuCo}." : $"Đã chuyển sự cố #{sc.MaSuCo} sang đang xử lý.";
            return RedirectToAction("Index");
        }
    }
}
