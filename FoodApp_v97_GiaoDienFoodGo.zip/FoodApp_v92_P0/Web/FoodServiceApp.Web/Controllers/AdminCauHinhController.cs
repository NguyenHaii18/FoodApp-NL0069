using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>
    /// Cài đặt phí & chính sách (phí giao, hoa hồng, hủy đơn, hoàn tiền, voucher, thời gian xử lý, quy định).
    /// Lưu trong CSDL, ghi lịch sử người đổi + thời điểm. Mọi quản trị viên được xem; chỉ Admin tổng được ghi.
    /// </summary>
    [Route("QuanTri/CauHinh")]
    [FoodServiceApp.Web.Filters.ChiSuperAdminGhi]
    public class AdminCauHinhController : AdminOpsBase
    {
        private readonly CauHinhService _cauHinh;
        public AdminCauHinhController(AppDbContext db, CauHinhService cauHinh) : base(db) { _cauHinh = cauHinh; }

        [HttpGet("")]
        public async Task<IActionResult> Index(string? khoa)
        {
            await _cauHinh.DamBaoMacDinhAsync();
            var dsKhoa = await Db.CauHinhHeThongs.AsNoTracking().ToListAsync();
            ViewBag.Gia = dsKhoa.ToDictionary(c => c.Khoa);

            var q = Db.CauHinhHeThongLichSus.AsNoTracking().AsQueryable();
            if (!string.IsNullOrWhiteSpace(khoa)) q = q.Where(l => l.Khoa == khoa);
            var ls = await q.OrderByDescending(l => l.ThoiGian).Take(string.IsNullOrWhiteSpace(khoa) ? 60 : 200).ToListAsync();

            var ma = ls.Where(l => l.MaTK != null).Select(l => l.MaTK!.Value)
                .Concat(dsKhoa.Where(c => c.MaTKSua != null).Select(c => c.MaTKSua!.Value)).Distinct().ToList();
            ViewBag.Ten = await Db.TaiKhoans.AsNoTracking().Where(t => ma.Contains(t.MaTK)).ToDictionaryAsync(t => t.MaTK, t => t.TenDangNhap);
            ViewBag.LichSu = ls;
            ViewBag.LocKhoa = khoa;
            ViewBag.Khac = dsKhoa.Where(c => ChinhSachMeta.Tim(c.Khoa) == null).OrderBy(c => c.Khoa).ToList();
            return View();
        }

        [HttpPost("luu")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Luu(string khoa, string giaTri)
        {
            var c = await Db.CauHinhHeThongs.AsNoTracking().FirstOrDefaultAsync(x => x.Khoa == khoa);
            if (c == null) return NotFound();

            var meta = ChinhSachMeta.Tim(khoa);
            var nhom = ChinhSachMeta.Nhom.FirstOrDefault(n => n.Muc.Any(m => m.Khoa == khoa))?.Id ?? "khac";
            string chuan;
            if (meta != null)
            {
                var loi = meta.KiemTra(giaTri, out chuan);
                if (loi != null) return Quay(nhom, $"{meta.Nhan}: {loi}", true);
            }
            else
            {
                chuan = (giaTri ?? "").Trim();
                if (chuan.Length == 0 || chuan.Length > 300) return Quay(nhom, "Giá trị không được để trống và tối đa 300 ký tự.", true);
            }

            if (c.GiaTri == chuan) return Quay(nhom, "Giá trị không thay đổi.", false);
            try { await _cauHinh.DatAsync(khoa, chuan, MaTK); }
            catch (DbUpdateException)
            {
                Db.ChangeTracker.Clear();
                return Quay(nhom, "Không lưu được. Nếu nội dung dài hơn 300 ký tự, hãy chạy Database/FoodService_NangCap.sql (mục v23) để mở rộng cột lưu.", true);
            }
            return Quay(nhom, $"Đã cập nhật «{meta?.Nhan ?? khoa}».", false);
        }

        private IActionResult Quay(string nhom, string tb, bool loi)
        {
            TempData[loi ? "LoiThongBao" : "ThongBao"] = tb;
            return Redirect(Url.Action(nameof(Index)) + "#" + nhom);
        }
    }
}
