using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers
{
    [Route("TaiXe/DonHang")]
    public class DriverDonHangController : TaiXeBaseController
    {
        private readonly AppDbContext _db;
        private readonly FoodServiceApp.Web.Services.IFileStorageService _luuTru;

        public DriverDonHangController(AppDbContext db, FoodServiceApp.Web.Services.IFileStorageService luuTru)
        {
            _db = db;
            _luuTru = luuTru;
        }

        // Danh sách đơn đã được gian hàng xác nhận, đang chờ tài xế nhận
        [HttpGet("ChoNhan")]
        public async Task<IActionResult> ChoNhan()
        {
            if (!await _db.TaiXes.AnyAsync(t => t.MaTaiXe == CurrentTaiXeId && t.TrangThaiDuyet == "DaDuyet"))
            {
                TempData["LoiThongBao"] = "Hồ sơ tài xế chưa được duyệt, chưa thể xem và nhận đơn.";
                return RedirectToAction("Index", "DriverDashboard");
            }

            if (await FoodServiceApp.Web.Services.GiaoHangXuLy.DangCoChuyenAsync(_db, CurrentTaiXeId))
            {
                TempData["LoiThongBao"] = "Bạn đang có một chuyến giao chưa hoàn thành, hãy xử lý xong trước khi nhận đơn mới.";
                return RedirectToAction("DonHienTai");
            }

            var phutPhanHoi = await FoodServiceApp.Web.Services.GiaoHangXuLy.LayPhutPhanHoiAsync(_db);
            await FoodServiceApp.Web.Services.GiaoHangXuLy.XuLyQuaHanNhanDonAsync(_db, phutPhanHoi);
            ViewBag.PhutPhanHoi = phutPhanHoi;
            var danhSach = await FoodServiceApp.Web.Services.GiaoHangXuLy.DonChoNhan(_db, CurrentTaiXeId)
                .Include(d => d.GianHang)
                .Include(d => d.ChiTiets)
                .OrderBy(d => d.NgayDat)
                .ToListAsync();

            return View(danhSach);
        }

        // Đơn của tôi theo nhóm: đã nhận / đang giao / hoàn thành / hủy - thất bại
        [HttpGet("CuaToi")]
        public async Task<IActionResult> DonCuaToi(string? tab)
        {
            tab = tab is "dang-giao" or "hoan-thanh" or "that-bai" ? tab : "nhan";
            var ds = await FoodServiceApp.Web.Services.DriverDonXuLy.Tab(_db, CurrentTaiXeId, tab).AsNoTracking()
                .Include(d => d.GianHang).Include(d => d.ThanhToan).Include(d => d.GiaoHang)
                .OrderByDescending(d => d.NgayDat).Take(100).ToListAsync();
            ViewBag.Tab = tab;
            ViewBag.Dem = new Dictionary<string, int>
            {
                ["nhan"] = await FoodServiceApp.Web.Services.DriverDonXuLy.Tab(_db, CurrentTaiXeId, "nhan").CountAsync(),
                ["dang-giao"] = await FoodServiceApp.Web.Services.DriverDonXuLy.Tab(_db, CurrentTaiXeId, "dang-giao").CountAsync(),
                ["hoan-thanh"] = await FoodServiceApp.Web.Services.DriverDonXuLy.Tab(_db, CurrentTaiXeId, "hoan-thanh").CountAsync(),
                ["that-bai"] = await FoodServiceApp.Web.Services.DriverDonXuLy.Tab(_db, CurrentTaiXeId, "that-bai").CountAsync(),
            };
            return View(ds);
        }

        // Chi tiết một đơn thuộc chuyến của tôi
        [HttpGet("ChiTiet/{id:int}")]
        public async Task<IActionResult> ChiTiet(int id)
        {
            var dto = await FoodServiceApp.Web.Services.DriverDonXuLy.ChiTietAsync(_db, CurrentTaiXeId, id);
            if (dto == null) return NotFound();
            return View(dto);
        }

        [HttpPost("TuChoi/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TuChoi(int id, string? lyDo)
        {
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == CurrentTaiXeId);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.TuChoiDonAsync(_db, taiXe, id, lyDo);
            if (kq.Ok) TempData["ThongBao"] = kq.ThongDiep; else TempData["LoiThongBao"] = kq.ThongDiep;
            return RedirectToAction("ChoNhan");
        }

        [HttpPost("Nhan/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Nhan(int id)
        {
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == CurrentTaiXeId);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.NhanDonAsync(_db, taiXe, id);
            if (!kq.Ok)
            {
                TempData["LoiThongBao"] = kq.ThongDiep;
                return RedirectToAction(kq.ThongDiep.Contains("chuyến giao") ? "DonHienTai" : "ChoNhan");
            }
            TempData["ThongBao"] = $"Đã nhận đơn #{id}. Hãy đến quán lấy món rồi bấm \"Đã lấy hàng\".";
            return RedirectToAction("DonHienTai");
        }

        // Chuyến giao hiện tại: đã nhận (đang đến quán) hoặc đang giao
        [HttpGet("HienTai")]
        public async Task<IActionResult> DonHienTai()
        {
            var don = await _db.DonHangs
                .Include(d => d.GianHang)
                .Include(d => d.KhachHang)
                .Include(d => d.ThanhToan)
                .Include(d => d.ChiTiets).ThenInclude(c => c.MonAn)
                .Include(d => d.GiaoHang)
                .FirstOrDefaultAsync(d => d.MaTaiXe == CurrentTaiXeId && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao"));

            return View(don);
        }

        // Đã lấy hàng tại quán -> bắt đầu giao
        [HttpPost("BatDauGiao/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> BatDauGiao(int id, string? maDon)
        {
            var don = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe == CurrentTaiXeId);
            var giaoHang = await _db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == id && g.MaTaiXe == CurrentTaiXeId);
            if (don == null || giaoHang == null) return NotFound();

            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.DaLayHangAsync(_db, don, giaoHang, maDon);
            if (!kq.Ok) TempData["LoiThongBao"] = kq.ThongDiep;
            return RedirectToAction("DonHienTai");
        }

        // Trình duyệt tài xế gửi vị trí định kỳ (chống dồn dập / nhảy bất thường trong GiaoHangXuLy.LuuViTriAsync)
        [HttpPost("ViTri/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ViTri(int id, double lat, double lng)
        {
            if (lat is < -90 or > 90 || lng is < -180 or > 180) return BadRequest(new { message = "Tọa độ không hợp lệ." });
            var coChuyen = await _db.DonHangs.AnyAsync(d => d.MaDonHang == id && d.MaTaiXe == CurrentTaiXeId && (d.TrangThai == "DaXacNhan" || d.TrangThai == "DangGiao"));
            if (!coChuyen) return NotFound();
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.LuuViTriAsync(_db, id, CurrentTaiXeId, lat, lng);
            return kq.Ok ? Ok(new { message = kq.ThongDiep }) : StatusCode(422, new { message = kq.ThongDiep });
        }

        [HttpPost("DenQuan/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DenQuan(int id)
        {
            var don = await _db.DonHangs.FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe == CurrentTaiXeId);
            var gh = await _db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == id && g.MaTaiXe == CurrentTaiXeId);
            if (don == null || gh == null) return NotFound();
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.DenQuanAsync(_db, don, gh);
            TempData[kq.Ok ? "ThongBao" : "LoiThongBao"] = kq.ThongDiep;
            return RedirectToAction("DonHienTai");
        }

        [HttpPost("HoanThanh/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> HoanThanh(int id, string? maXacNhan, IFormFile? anh, double? lat, double? lng, bool daThuCod = false)
        {
            var don = await _db.DonHangs.Include(d => d.ThanhToan).FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe == CurrentTaiXeId);
            var giaoHang = await _db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == id && g.MaTaiXe == CurrentTaiXeId);
            if (don == null || giaoHang == null) return NotFound();

            // Thu hộ COD: bắt buộc tài xế xác nhận đã thu đủ tiền trước khi hoàn thành
            if (don.ThanhToan != null && don.ThanhToan.HinhThuc == "TienMat" && don.ThanhToan.TrangThai != "DaThanhToan" && !daThuCod)
            { TempData["LoiThongBao"] = $"Đơn thu tiền mặt: hãy tích xác nhận đã thu đủ {don.TongTien:N0}đ trước khi hoàn thành."; return RedirectToAction("DonHienTai"); }

            if (anh != null && anh.Length > 0)
            {
                try { giaoHang.AnhBangChung = await _luuTru.SaveFileAsync(anh, "giaohang"); }
                catch (ArgumentException ex) { TempData["LoiThongBao"] = ex.Message; return RedirectToAction("DonHienTai"); }
            }
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == CurrentTaiXeId);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.HoanThanhAsync(_db, don, giaoHang, taiXe, maXacNhan, lat, lng);
            if (!kq.Ok) { await _db.SaveChangesAsync(); TempData["LoiThongBao"] = kq.ThongDiep; return RedirectToAction("DonHienTai"); }
            TempData["ThongBao"] = $"Đã hoàn thành giao đơn #{don.MaDonHang}.";
            return RedirectToAction("Index", "DriverDashboard");
        }

        [HttpPost("GiaoThatBai/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> GiaoThatBai(int id, string lyDo, IFormFile? anh, double? lat, double? lng)
        {
            var don = await _db.DonHangs.Include(d => d.ThanhToan).FirstOrDefaultAsync(d => d.MaDonHang == id && d.MaTaiXe == CurrentTaiXeId);
            var giaoHang = await _db.GiaoHangs.FirstOrDefaultAsync(g => g.MaDonHang == id && g.MaTaiXe == CurrentTaiXeId);
            if (don == null || giaoHang == null) return NotFound();

            if (anh != null && anh.Length > 0)
            {
                try { giaoHang.AnhBangChung = await _luuTru.SaveFileAsync(anh, "giaohang"); }
                catch (ArgumentException ex) { TempData["LoiThongBao"] = ex.Message; return RedirectToAction("DonHienTai"); }
            }
            var taiXe = await _db.TaiXes.FirstAsync(t => t.MaTaiXe == CurrentTaiXeId);
            var kq = await FoodServiceApp.Web.Services.GiaoHangXuLy.ThatBaiAsync(_db, don, giaoHang, taiXe, lyDo, lat, lng);
            if (!kq.Ok) { TempData["LoiThongBao"] = kq.ThongDiep; return RedirectToAction("DonHienTai"); }
            TempData["ThongBao"] = $"Đã ghi nhận giao thất bại đơn #{don.MaDonHang}. {kq.ThongDiep}";
            return RedirectToAction("Index", "DriverDashboard");
        }

        [HttpGet("LichSu")]
        public async Task<IActionResult> LichSu(DateTime? tu, DateTime? den, string? trangThai)
        {
            var q = _db.GiaoHangs
                .Include(g => g.DonHang).ThenInclude(d => d!.GianHang)
                .Where(g => g.MaTaiXe == CurrentTaiXeId && (g.TrangThai == "GiaoThanhCong" || g.TrangThai == "GiaoThatBai"));
            if (tu != null) q = q.Where(g => g.ThoiGianGiao >= tu.Value.Date);
            if (den != null) q = q.Where(g => g.ThoiGianGiao < den.Value.Date.AddDays(1));
            if (trangThai is "GiaoThanhCong" or "GiaoThatBai") q = q.Where(g => g.TrangThai == trangThai);
            var ds = await q.OrderByDescending(g => g.ThoiGianGiao).Take(200).ToListAsync();

            // Chỉ số hoạt động: tính trên toàn bộ lịch sử trong khoảng lọc (không phụ thuộc bộ lọc trạng thái)
            var goc = _db.GiaoHangs.Where(g => g.MaTaiXe == CurrentTaiXeId && (g.TrangThai == "GiaoThanhCong" || g.TrangThai == "GiaoThatBai"));
            if (tu != null) goc = goc.Where(g => g.ThoiGianGiao >= tu.Value.Date);
            if (den != null) goc = goc.Where(g => g.ThoiGianGiao < den.Value.Date.AddDays(1));
            var thongKe = await goc.Select(g => new { g.TrangThai, g.ThoiGianNhan, g.ThoiGianLayHang, g.ThoiGianGiao }).ToListAsync();
            var tc = thongKe.Count(x => x.TrangThai == "GiaoThanhCong");
            var tb = thongKe.Count - tc;
            var phut = thongKe.Where(x => x.TrangThai == "GiaoThanhCong" && x.ThoiGianGiao != null && (x.ThoiGianLayHang ?? x.ThoiGianNhan) != null)
                .Select(x => (x.ThoiGianGiao!.Value - (x.ThoiGianLayHang ?? x.ThoiGianNhan)!.Value).TotalMinutes).ToList();

            var maDons = ds.Select(g => g.MaDonHang).ToList();
            var dgs = await _db.DanhGias.AsNoTracking().Where(d => maDons.Contains(d.MaDonHang) && !d.DaAn).ToListAsync();
            var maDonTatCa = await goc.Select(g => g.MaDonHang).ToListAsync();
            var dgAll = await _db.DanhGias.AsNoTracking().Where(d => (d.MaTaiXe == CurrentTaiXeId || (d.MaTaiXe == null && maDonTatCa.Contains(d.MaDonHang))) && !d.DaAn && d.SoSaoGiaoHang != null).Select(d => d.SoSaoGiaoHang!.Value).ToListAsync();

            var vm = new FoodServiceApp.Web.Models.ViewModels.DriverLichSuViewModel
            {
                Danh = ds, Tu = tu, Den = den, TrangThai = trangThai,
                ThanhCong = tc, ThatBai = tb,
                TiLeHoanThanh = thongKe.Count == 0 ? 0 : Math.Round(tc * 100.0 / thongKe.Count, 1),
                PhutGiaoTrungBinh = phut.Count == 0 ? null : Math.Round(phut.Average(), 1),
                SaoGiaoHangTB = dgAll.Count == 0 ? null : Math.Round(dgAll.Average(), 2),
                SoDanhGia = dgAll.Count,
                SoSuCo = await _db.SuCoGiaoHangs.CountAsync(x => x.MaTaiXe == CurrentTaiXeId),
                SaoTheoDon = dgs.ToDictionary(d => d.MaDonHang, d => d.SoSaoGiaoHang),
            };
            // Phản hồi liên quan chất lượng giao hàng: nhận xét trong đánh giá (thẻ nhận xét / nội dung) + khiếu nại gắn với đơn
            foreach (var d in dgs.Where(d => !string.IsNullOrWhiteSpace(d.TheNhanXet) || (d.SoSaoGiaoHang != null && !string.IsNullOrWhiteSpace(d.NoiDung))))
                vm.PhanHoi.Add((d.MaDonHang, "Đánh giá", string.Join(" — ", new[] { d.TheNhanXet, d.NoiDung }.Where(x => !string.IsNullOrWhiteSpace(x))), d.NgayDanhGia));
            var kn = await _db.PhanHois.AsNoTracking().Where(p => p.MaDonHang != null && maDons.Contains(p.MaDonHang.Value) && p.Loai == "KhieuNai").ToListAsync();
            foreach (var p in kn) vm.PhanHoi.Add((p.MaDonHang!.Value, "Khiếu nại", p.TieuDe + ": " + p.NoiDung, p.NgayGui));
            vm.PhanHoi = vm.PhanHoi.OrderByDescending(x => x.Ngay).Take(30).ToList();
            return View(vm);
        }
    }
}
