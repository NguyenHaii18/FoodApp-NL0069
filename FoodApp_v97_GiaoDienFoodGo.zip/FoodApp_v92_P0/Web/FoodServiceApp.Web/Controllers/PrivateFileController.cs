using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>
    /// Tài liệu riêng tư (giấy phép kinh doanh, ATTP, GPLX): không còn nằm trong wwwroot nên không tải tĩnh được.
    /// Chỉ truy cập được khi:
    ///  1) là Quản trị; hoặc 2) là CHỦ của tài liệu (tài xế với GPLX của mình, gian hàng với giấy tờ của mình), qua Cookie (web) hoặc JWT (app); hoặc
    ///  3) có liên kết ký còn hạn (exp + sig) do <c>POST /api/files/link</c> cấp — để app mở ảnh trong WebView/Launcher không cần gắn header.
    /// </summary>
    [AllowAnonymous]
    public class PrivateFileController : Controller
    {
        private const int HieuLucLienKetGiay = 300;
        private readonly AppDbContext _db;
        private readonly IFileStorageService _luuTru;
        private readonly IConfiguration _cfg;

        public PrivateFileController(AppDbContext db, IFileStorageService luuTru, IConfiguration cfg)
        { _db = db; _luuTru = luuTru; _cfg = cfg; }

        private string Ky(string sub, string ten, long exp)
        {
            using var h = new HMACSHA256(Encoding.UTF8.GetBytes((_cfg["Jwt:Key"] ?? "") + "|private-file"));
            return Convert.ToHexString(h.ComputeHash(Encoding.UTF8.GetBytes($"{sub}/{ten}|{exp}"))).ToLowerInvariant();
        }

        private async Task<ClaimsPrincipal?> XacThucAsync()
        {
            foreach (var scheme in new[] { JwtBearerDefaults.AuthenticationScheme, CookieAuthenticationDefaults.AuthenticationScheme })
            {
                var r = await HttpContext.AuthenticateAsync(scheme);
                if (r.Succeeded && r.Principal != null) return r.Principal;
            }
            return null;
        }

        private async Task<bool> DuocPhepAsync(ClaimsPrincipal u, string sub, string ten)
        {
            if (u.IsInRole("QuanTri")) return true;
            if (!int.TryParse(u.FindFirstValue(ClaimTypes.NameIdentifier), out var maTK)) return false;
            var url = $"{LocalFileStorageService.TienToRiengTu}{sub}/{ten}";
            if (u.IsInRole("TaiXe"))
                return await _db.TaiXes.AnyAsync(t => t.MaTK == maTK && t.AnhGPLX == url);
            if (u.IsInRole("GianHang"))
                return await _db.GianHangs.AnyAsync(g => g.MaTK == maTK && (g.GiayPhepKinhDoanh == url || g.GiayChungNhanATTP == url));
            return false;
        }

        [HttpGet("/files/private/{sub}/{ten}")]
        public async Task<IActionResult> Tai(string sub, string ten, long? exp, string? sig)
        {
            var path = _luuTru.TimFileRiengTu(sub, ten);
            if (path == null) return NotFound();

            var hopLe = false;
            if (exp != null && !string.IsNullOrEmpty(sig) && exp.Value >= DateTimeOffset.UtcNow.ToUnixTimeSeconds())
            {
                var mong = Ky(sub, ten, exp.Value);
                hopLe = CryptographicOperations.FixedTimeEquals(Encoding.ASCII.GetBytes(mong), Encoding.ASCII.GetBytes(sig.ToLowerInvariant()));
            }
            if (!hopLe)
            {
                var u = await XacThucAsync();
                if (u == null) return Unauthorized();
                if (!await DuocPhepAsync(u, sub, ten)) return NotFound();   // không tiết lộ file có tồn tại hay không
            }

            Response.Headers["Cache-Control"] = "private, no-store";
            Response.Headers["X-Content-Type-Options"] = "nosniff";
            Response.Headers["Content-Security-Policy"] = "default-src 'none'; img-src 'self' data:; sandbox";
            var loai = Path.GetExtension(path).ToLowerInvariant() switch
            {
                ".jpg" => "image/jpeg", ".png" => "image/png", ".webp" => "image/webp", ".pdf" => "application/pdf",
                _ => "application/octet-stream"
            };
            return PhysicalFile(path, loai);
        }

        public record LienKetRequest(string? Url);

        /// <summary>Cấp liên kết tải có thời hạn (5 phút) cho một tài liệu mà người gọi có quyền xem.</summary>
        [HttpPost("/api/files/link")]
        public async Task<IActionResult> CapLienKet([FromBody] LienKetRequest r)
        {
            var u = await XacThucAsync();
            if (u == null) return Unauthorized();
            var url = (r?.Url ?? "").Trim();
            if (!url.StartsWith(LocalFileStorageService.TienToRiengTu, StringComparison.OrdinalIgnoreCase)) return BadRequest(new { message = "Không phải tài liệu riêng tư." });
            var phan = url.Substring(LocalFileStorageService.TienToRiengTu.Length).Split('/', 2);
            if (phan.Length != 2 || _luuTru.TimFileRiengTu(phan[0], phan[1]) == null) return NotFound();
            if (!await DuocPhepAsync(u, phan[0], phan[1])) return NotFound();

            var exp = DateTimeOffset.UtcNow.AddSeconds(HieuLucLienKetGiay).ToUnixTimeSeconds();
            return Ok(new { url = $"{url}?exp={exp}&sig={Ky(phan[0], phan[1], exp)}", hetHanSau = HieuLucLienKetGiay });
        }
    }
}
