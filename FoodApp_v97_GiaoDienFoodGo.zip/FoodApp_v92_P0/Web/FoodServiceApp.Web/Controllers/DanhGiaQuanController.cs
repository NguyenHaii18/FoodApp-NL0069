using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Controllers
{
    /// <summary>Gian hàng xem đánh giá của khách (có lọc theo sao), phản hồi đánh giá, và xem phản hồi/khiếu nại liên quan đến quán.</summary>
    public class DanhGiaQuanController : GianHangBaseController
    {
        private readonly AppDbContext _db;
        public DanhGiaQuanController(AppDbContext db) { _db = db; }

        public async Task<IActionResult> Index(int? sao)
        {
            var goc = _db.DanhGias.AsNoTracking().Where(d => d.MaGianHang == CurrentGianHangId && !d.DaAn);
            var soDanhGia = await goc.CountAsync();
            ViewBag.SoDanhGia = soDanhGia;
            ViewBag.DiemTB = soDanhGia > 0 ? await goc.AverageAsync(d => (double)d.SoSao) : 0.0;
            ViewBag.ChuaTraLoi = await goc.CountAsync(d => d.PhanHoi == null || d.PhanHoi == "");

            var q = goc;
            if (sao is >= 1 and <= 5) q = q.Where(d => d.SoSao == sao);
            var ds = await q.OrderByDescending(d => d.NgayDanhGia).Take(100).ToListAsync();

            // Chỉ hiện tên gọi (từ cuối) của khách, không lộ họ tên đầy đủ / liên hệ
            var ids = ds.Select(d => d.MaKH).Distinct().ToList();
            var ten = await _db.KhachHangs.AsNoTracking().Where(k => ids.Contains(k.MaKH)).ToDictionaryAsync(k => k.MaKH, k => k.HoTen);
            ViewBag.TenKhach = ten.ToDictionary(x => x.Key, x => (x.Value ?? "").Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries).LastOrDefault() ?? "Khách");

            ViewBag.PhanHois = await _db.PhanHois.AsNoTracking().Where(p => p.MaGianHang == CurrentGianHangId)
                .OrderByDescending(p => p.NgayGui).Take(30).ToListAsync();
            ViewBag.Sao = sao;
            return View(ds);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> TraLoi(int id, string? noiDung)
        {
            var dg = await _db.DanhGias.FirstOrDefaultAsync(d => d.MaDanhGia == id && d.MaGianHang == CurrentGianHangId && !d.DaAn);
            if (dg == null) return NotFound();
            noiDung = noiDung?.Trim() ?? "";
            if (noiDung.Length < 2 || noiDung.Length > 500)
            { TempData["LoiThongBao"] = "Nội dung phản hồi dài 2–500 ký tự."; return RedirectToAction("Index"); }

            dg.PhanHoi = noiDung;
            dg.NgayPhanHoi = DateTime.Now;
            var kh = await _db.KhachHangs.AsNoTracking().FirstOrDefaultAsync(k => k.MaKH == dg.MaKH);
            if (kh != null)
                _db.ThongBaos.Add(new ThongBao { MaTK = kh.MaTK, Loai = "HeThong", TieuDe = "Quán đã phản hồi đánh giá của bạn", NoiDung = noiDung, MaThamChieu = dg.MaDonHang.ToString() });
            await _db.SaveChangesAsync();
            TempData["ThongBao"] = "Đã gửi phản hồi tới khách.";
            return RedirectToAction("Index");
        }
    }
}
