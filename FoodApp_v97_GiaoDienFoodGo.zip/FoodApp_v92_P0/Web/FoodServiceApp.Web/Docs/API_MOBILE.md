# API cho FoodApp (.NET MAUI)

API nằm trong project `FoodServiceApp.Web`, controller `Controllers/Api/MobileApiController.cs`, base route:

`/api/mobile`

JSON dùng camelCase. API dùng JWT cho các nghiệp vụ sau đăng nhập; lỗi trả `4xx` dạng `{ "thongDiep": "..." }`.

## Catalog

| Method | URL | Auth | Trả về |
|---|---|---|---|
| GET | `/api/mobile/gian-hang` | Không | danh sách gian hàng đang mở/đã duyệt |
| GET | `/api/mobile/mon-an` | Không | danh sách món còn bán, có `gianHangId`, `danhMuc` |
| GET | `/api/mobile/khuyen-mai` | Không | mã khuyến mãi đang hiệu lực |

## Đăng nhập / đăng ký

| Method | URL | Body |
|---|---|---|
| POST | `/api/mobile/khach-hang/dang-nhap` | `{email, matKhau}` |
| POST | `/api/mobile/khach-hang/dang-ky` | `{hoTen, sdt, diaChi, email, matKhau}` |
| POST | `/api/mobile/gian-hang/dang-nhap` | `{email, matKhau}` |
| POST | `/api/mobile/gian-hang/dang-ky` | `{tenGianHang, diaChi, sdt, email, matKhau, moTa, hinhAnh}` |
| POST | `/api/mobile/tai-xe/dang-nhap` | `{sdt, matKhau}` |
| POST | `/api/mobile/admin/dang-nhap` | `{email, matKhau}` |

Tài khoản gian hàng seed cũ dùng username như `gianhang01`; API chấp nhận thêm dạng `gianhang01@gianhang.vn` để khớp ô Email của app.

## Khách hàng

| Method | URL |
|---|---|
| GET | `/api/mobile/khach-hang/don-hang` |
| POST | `/api/mobile/don-hang` |
| PUT | `/api/mobile/khach-hang/ho-so` |
| POST | `/api/mobile/van-de` |
| POST | `/api/mobile/danh-gia` |
| PUT | `/api/mobile/don-hang/{id}/huy` |

### Đặt hàng
Body:
```json
{
  "gianHangId": 1,
  "diaChiGiao": "123 Lê Lợi, Q.1, TP.HCM",
  "hinhThucThanhToan": "TienMat",
  "maKhuyenMai": "CODE10",
  "chiTiet": [
    { "monAnId": 10, "soLuong": 2 }
  ]
}
```

Server tự kiểm tra món thuộc cùng gian hàng, còn hàng, giá hiện tại, mã giảm giá và tự tính phí giao hàng. Response có `id`, `tongTien`, `phiGiaoHang`, `khoangCachKm`, `thoiGianDuKienPhut`, `maXacNhanGiao`; với VNPay có thêm `paymentUrl`.

## Gian hàng

| Method | URL |
|---|---|
| GET | `/api/mobile/gian-hang/{id}/don-hang` |
| PUT | `/api/mobile/gian-hang/{id}/trang-thai-kinh-doanh` |
| PUT | `/api/mobile/don-hang/{id}/xac-nhan` |
| PUT | `/api/mobile/don-hang/{id}/tu-choi` |
| PUT | `/api/mobile/don-hang/{id}/san-sang-giao` |

## Quản trị

| Method | URL |
|---|---|
| GET | `/api/mobile/admin/khach-hang` |
| GET | `/api/mobile/admin/van-de` |
| PUT | `/api/mobile/admin/gian-hang/{id}/duyet` |
| PUT | `/api/mobile/admin/gian-hang/{id}/tu-choi` |
| PUT | `/api/mobile/admin/gian-hang/{id}/khoa` |
| PUT | `/api/mobile/admin/gian-hang/{id}/mo-khoa` |
| PUT | `/api/mobile/admin/khach-hang/{id}/khoa` |
| PUT | `/api/mobile/admin/khach-hang/{id}/mo-khoa` |
| PUT | `/api/mobile/admin/van-de/{id}/dang-xu-ly` |
| PUT | `/api/mobile/admin/van-de/{id}/giai-quyet` |

## Tài xế / giao hàng

| Method | URL | Body |
|---|---|---|
| PUT | `/api/mobile/tai-xe/ho-so` | `{hoTen, soDienThoai, bienSoXe, loaiXe}` |
| GET | `/api/mobile/tai-xe/don-cho-nhan` | |
| PUT | `/api/mobile/tai-xe/don-hang/{id}/nhan` | |
| GET | `/api/mobile/tai-xe/dang-giao` | |
| PUT | `/api/mobile/tai-xe/vi-tri` | `{donHangId, viDo, kinhDo}` |
| PUT | `/api/mobile/don-hang/{id}/da-lay-hang` | |
| PUT | `/api/mobile/don-hang/{id}/hoan-thanh` | `{maXacNhan}` |
| PUT | `/api/mobile/don-hang/{id}/giao-that-bai` | `{lyDo, tinhPhi}` |
| PUT | `/api/mobile/don-hang/{id}/phi-giao-hang` | `{khoangCachKm, phiGiaoHang}` |

API kiểm tra tài xế đúng người nhận đơn; mã giao 4 số được server sinh khi tạo đơn. Vị trí tài xế hiện lưu trong memory của Web process vì CSDL tích hợp chưa có bảng vị trí thời gian thực.

## Bổ trợ

| Method | URL |
|---|---|
| PUT | `/api/mobile/doi-mat-khau` |
| POST | `/api/mobile/map/phi-giao-hang` |
| POST | `/api/mobile/payment/vnpay/tao-url` |

## Cấu trúc `DonHang` app nhận

Response đã được map đúng model MAUI, trong đó `chiTiet[]` có object `monAn` lồng bên trong. Các trường giao hàng bổ sung gồm:

`khoangCachKm`, `thoiGianDuKienPhut`, `khuVucLay`, `khuVucGiao`, `ngoaiThanh`, `phiKhoangCach`, `phuPhiKhuVuc`, `phiDaDieuChinh`, `taiXeId`, `taiXeTen`, `taiXeSdt`, `taiXeBienSo`, `daLayHang`, `taiXeLat`, `taiXeLng`, `viTriCapNhatLuc`, `maXacNhanGiao`, `giaoThatBai`, `lyDoGiaoThatBai`.


## Bổ sung Đối tác / Gian hàng (VendorMobileApiController)
| Method | URL | Body | Ghi chú |
|---|---|---|---|
| PUT | api/mobile/gian-hang/{id}/gio-hoat-dong | {gioMoCua:"HH:mm", gioDongCua, dangNhanDon, dangMoCua} | Giờ mở/đóng cửa, tạm dừng nhận đơn. Đặt hàng bị chặn khi ngoài giờ / tạm dừng |
| GET | api/mobile/gian-hang/{id}/danh-gia | | Đánh giá của gian hàng kèm phản hồi |
| PUT | api/mobile/gian-hang/{id}/danh-gia/{maDanhGia}/phan-hoi | {noiDung} | Gian hàng phản hồi đánh giá (≤ 500 ký tự) |
| GET | api/mobile/gian-hang/{id}/thong-bao | | Đơn mới / đơn hủy / đánh giá mới trong 7 ngày |
| GET | api/mobile/gian-hang/{id}/tai-chinh?tu=&den= | | Doanh thu món, phí nền tảng (TyLeChietKhau, mặc định 15%), thực nhận, giá vốn, lợi nhuận |
| POST | api/mobile/tai-khoan/dat-lai-mat-khau | {taiKhoan, otp, matKhauMoi} | Đặt lại mật khẩu gian hàng sau khi nhập OTP (gửi OTP bằng POST tai-khoan/quen-mat-khau). Endpoint cũ gian-hang/quen-mat-khau đã gỡ. |
| PUT | api/mobile/don-hang/{id}/tu-choi | {lyDo} | **Bắt buộc lý do** (NV04); đơn đã thanh toán được hoàn tiền |


## Bổ sung: Tài khoản & bảo mật (TaiKhoanApiController)
| Method | URL | Quyền | Ghi chú |
|---|---|---|---|
| POST | api/mobile/tai-khoan/quen-mat-khau `{taiKhoan}` | công khai | taiKhoan = tên đăng nhập / email / SĐT. Gửi OTP, luôn trả thông điệp chung. Chưa cấu hình SMTP + `Otp:HienMaDev=true` thì trả `maDev` để demo |
| POST | api/mobile/tai-khoan/dat-lai-mat-khau `{taiKhoan, otp, matKhauMoi}` | công khai | OTP 6 số, hiệu lực 5 phút, sai tối đa 5 lần |
| POST | api/mobile/tai-khoan/xac-thuc/gui-otp `{kenh: "email"\|"sms"}` | đã đăng nhập | |
| POST | api/mobile/tai-khoan/xac-thuc/xac-nhan `{kenh, otp}` | đã đăng nhập | |
| GET | api/mobile/tai-khoan/trang-thai-xac-thuc | đã đăng nhập | |
| GET | api/mobile/tai-khoan/lich-su-dang-nhap | đã đăng nhập | 30 sự kiện gần nhất |
| POST | api/mobile/tai-khoan/xoa `{matKhau}` | khách/gian hàng/tài xế | vô hiệu hóa + ẩn danh, chặn nếu còn đơn đang xử lý |
| PUT | api/mobile/tai-khoan/anh-dai-dien `{url}` | khách, tài xế | |
| PUT | api/mobile/gian-hang/giay-to `{giayPhepKinhDoanh, giayChungNhanAttp}` | gian hàng | |
| PUT | api/mobile/tai-xe/trang-thai `{trangThai: "SanSang"\|"NgoaiTuyen"}` | tài xế | |
| GET | api/mobile/admin/nhat-ky?nguon=&maTK=&trang=&kichThuoc= | Admin tổng | |
| GET/PUT | api/mobile/khach-hang/gio-hang | khách | PUT `{maGianHang, chiTiet:[{maMonAn,soLuong,ghiChu,tuyChon[]}]}`, chi tiết rỗng = xóa giỏ |

Đăng nhập sai 5 lần liên tiếp -> khóa tạm 15 phút (mọi vai trò). Mọi thao tác ghi (POST/PUT/DELETE) của người dùng đã đăng nhập tự vào bảng NhatKyHeThong.
Phân quyền quản trị: tài khoản `NhanVien` chỉ xem + xử lý phản hồi/sự cố; mọi thao tác duyệt/khóa/khuyến mãi (Web + API) cần `SuperAdmin`.


## Bổ sung v12 (app MAUI)
| Method | Đường dẫn | Vai trò | Ghi chú |
|---|---|---|---|
| POST | api/mobile/don-hang/{id}/bang-chung | TaiXe | multipart `file`; gọi trước hoan-thanh; đơn không có mã bắt buộc có ảnh |
| PUT | api/mobile/don-hang/{id}/da-lay-hang | TaiXe | trả `coMaXacNhan` |
| PUT | api/mobile/don-hang/{id}/bat-dau-chuan-bi | GianHang | TrangThaiChuanBi = DangChuanBi |
| PUT | api/mobile/don-hang/{id}/san-sang-giao | GianHang | TrangThaiChuanBi = SanSangGiao (lưu CSDL) |
| PUT | api/mobile/don-hang/{id}/ban-giao | GianHang | cần đã có tài xế; thông báo tài xế |
| PUT | api/mobile/don-hang/{id}/xac-nhan-nhan | KhachHang | đơn DaGiao; ghi KhachXacNhanLuc |
| POST | api/mobile/don-hang/{id}/chua-nhan | KhachHang | đơn DaGiao chưa xác nhận; tạo khiếu nại ChuaNhanHang |
| GET | api/mobile/don-hang/{id}/vi-tri | KhachHang | `viTriCu` > 90 giây |
| POST | api/mobile/admin/dang-nhap | — | trả thêm `capQuyenHan`, `quyen[]` (DonHang, ThanhToan, HoanTien, DanhGia, ThongBao) |

Trường mới trong đơn (mọi vai trò): `coMaXacNhan`, `trangThaiChuanBi`, `sanSangGiao`, `quanBanGiaoLuc`, `khachXacNhanLuc`. `maXacNhanGiao` chỉ gửi cho khách.

| PUT | api/mobile/tai-xe/don-hang/{id}/nhan | — | Tài xế nhận đơn (đường dẫn đúng; app gọi server trước rồi mới đổi giao diện) |
| PUT | api/mobile/don-hang/{id}/den-quan | — | Tài xế báo đã đến quán (mới) |
| GET | api/mobile/don-hang/{id}/tin-nhan | — | Chat khách ↔ tài xế của đơn (ChatApiController; bảng TinNhan, có MaClient chống gửi trùng) |
| POST | api/mobile/tin-nhan | {id, donHangId, noiDung} | Gửi tin nhắn (người gửi lấy từ JWT; bảng TinNhan) |


## Đối chiếu danh sách endpoint đề xuất (v48)

Các đường dẫn mẫu trong tài liệu thiết kế đã được đối chiếu với mã nguồn. Cột "Thực tế" là endpoint chính; "Bí danh" là đường dẫn đề xuất, nay trỏ cùng một xử lý (không nhân đôi logic).

| Nhóm | Đường dẫn đề xuất | Thực tế / bí danh |
|---|---|---|
| Xác thực | `POST /api/auth/login` | Mới: tự nhận vai trò theo tên đăng nhập. Vẫn giữ `POST /api/auth/login/{vaiTro}` và `POST /api/mobile/{khach-hang,gian-hang,tai-xe,admin}/dang-nhap` |
| Đăng ký | `POST /api/auth/register` | Bí danh của `POST /api/mobile/khach-hang/dang-ky`; thêm `/api/auth/register/{khach-hang,gian-hang,tai-xe}` |
| OTP | `POST /api/auth/otp/send`, `/verify` | Bí danh của `POST /api/mobile/tai-khoan/xac-thuc/{gui-otp,xac-nhan}` (xác thực email/SĐT cho tài khoản đang đăng nhập, cần JWT). OTP quên mật khẩu (không cần đăng nhập): `POST /api/mobile/tai-khoan/{quen-mat-khau,dat-lai-mat-khau}` |
| Danh sách quán | `GET /api/mobile/gian-hang` | Có sẵn |
| Chi tiết quán | `GET /api/mobile/gian-hang/{id}` | Bí danh của `GET /api/customer/stores/{id}` |
| Menu | `GET /api/mobile/gian-hang/{id}/mon-an` | Mới (`?tuKhoa=`, `?conHang=true`); cũng có `GET /api/customer/stores/{id}/menu`. Chi tiết một món: `GET /api/mobile/mon-an/{id}` |
| Giỏ hàng | `GET /api/mobile/khach-hang/gio-hang` | Có sẵn (kèm `PUT`) |
| Đặt hàng | `POST /api/mobile/don-hang` | Có sẵn |
| Lịch sử đơn | `GET /api/mobile/don-hang` | Bí danh của `GET /api/customer/orders` (cũng có `GET /api/mobile/khach-hang/don-hang`) |
| Chi tiết đơn | `GET /api/mobile/don-hang/{id}` | Bí danh của `GET /api/customer/orders/{id}` |
| Thanh toán | `POST /api/mobile/thanh-toan` | Mới: body `{maDonHang, phuongThuc?, noiDung?}`. Đơn VNPay → `{paymentUrl}`; đơn tiền mặt (COD) → trạng thái. Phương thức theo đơn đã đặt, không đổi sau khi đặt (trả 409 nếu yêu cầu khác). Có sẵn: `POST /api/mobile/payment/vnpay/tao-url`, `GET /api/mobile/don-hang/{id}/thanh-toan` |
| Chat đơn hàng | `GET/POST /api/mobile/don-hang/{id}/tin-nhan` | `GET` có sẵn; `POST` mới (cùng quy tắc với `POST /api/mobile/tin-nhan`) |
| Địa chỉ khách | `GET/POST /api/mobile/khach-hang/dia-chi` | Bí danh của `/api/customer/addresses`; thêm `POST .../dia-chi/{id}/mac-dinh`, `DELETE .../dia-chi/{id}` |
| Hồ sơ khách | `GET /api/mobile/khach-hang/ho-so` | Bí danh của `GET /api/customer/profile` (`PUT` có sẵn) |
| Đánh giá | `POST /api/mobile/danh-gia` | Có sẵn |
| Quản trị | `/api/admin/...` | Có sẵn (`/api/admin/*` và `/api/mobile/admin/*`) |
| Đối tác | `/api/vendor/...` | Có sẵn (`/api/vendor/*` và `/api/mobile/gian-hang/*`) |
| Tài xế | `/api/driver/...` | Có sẵn; nay **bổ sung vào mobile**: mọi endpoint `/api/driver/{x}` có thêm `/api/mobile/driver/{x}`; thêm tên tiếng Việt `GET /api/mobile/tai-xe/tong-quan`, `POST /api/mobile/tai-xe/bat-tat-san-sang`, `POST /api/mobile/tai-xe/bat-tat-nhan-don`; thu nhập: `GET /api/mobile/tai-xe/thu-nhap` (mới) |

`GET /api/mobile/tai-xe/thu-nhap` trả: số đơn đã nhận / đã giao / giao thất bại / bị hủy (30 ngày), thu nhập hôm nay – tuần – tháng, tổng phí giao + thưởng/phụ cấp − khoản trừ, COD đã thu, **COD cần nộp lại**, khoản nền tảng đã trả/chưa trả, thu nhập theo ngày và lịch sử giao dịch. Cùng cách tính với trang web `TaiXe/ThuNhap`.
