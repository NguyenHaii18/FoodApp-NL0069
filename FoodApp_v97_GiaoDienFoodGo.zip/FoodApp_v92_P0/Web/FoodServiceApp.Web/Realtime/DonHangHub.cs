using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace FoodServiceApp.Web.Realtime
{
    /// <summary>
    /// Kênh thời gian thực cho app: /hubs/don-hang (SignalR/WebSocket, JWT qua ?access_token=).
    /// Hub chỉ BÁO "có thay đổi" (mã đơn + trạng thái); nguồn dữ liệu chính vẫn là SQL qua API — app nhận tín hiệu rồi gọi lại API.
    /// Mỗi kết nối vào nhóm riêng của tài khoản (tk-{MaTK}) và nhóm theo vai trò (role-TaiXe, role-GianHang, ...).
    /// </summary>
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class DonHangHub : Hub
    {
        public override async Task OnConnectedAsync()
        {
            var user = Context.User;
            if (int.TryParse(user?.FindFirst(ClaimTypes.NameIdentifier)?.Value, out var maTK))
                await Groups.AddToGroupAsync(Context.ConnectionId, RealtimeBus.NhomTK(maTK));
            foreach (var vt in new[] { "KhachHang", "GianHang", "TaiXe", "QuanTri" })
                if (user?.IsInRole(vt) == true)
                    await Groups.AddToGroupAsync(Context.ConnectionId, RealtimeBus.NhomVaiTro(vt));
            await base.OnConnectedAsync();
        }
    }

    /// <summary>Cầu nối phát sự kiện từ tầng dữ liệu (AppDbContext) ra hub. Lỗi phát không bao giờ làm hỏng thao tác ghi SQL.</summary>
    public static class RealtimeBus
    {
        public static IHubContext<DonHangHub>? Hub { get; set; }

        public static string NhomTK(int maTK) => "tk-" + maTK;
        public static string NhomVaiTro(string vaiTro) => "role-" + vaiTro;

        public static void Phat(IEnumerable<string> nhom, string suKien, object noiDung)
        {
            var hub = Hub;
            if (hub == null) return;
            var ds = nhom.Distinct().ToArray();
            if (ds.Length == 0) return;
            _ = Task.Run(async () =>
            {
                try { await hub.Clients.Groups(ds).SendAsync(suKien, noiDung); }
                catch { /* không có ai nghe / mất kết nối: bỏ qua, app sẽ đồng bộ lại bằng API */ }
            });
        }
    }
}
