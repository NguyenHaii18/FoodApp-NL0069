using Microsoft.AspNetCore.Authentication;
using System.Text;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using FoodServiceApp.Web.Data;
using FoodServiceApp.Web.Services;
using FoodServiceApp.Web.Services.Configs;
using FoodServiceApp.Web.Services.Maps;
using FoodServiceApp.Web.Services.Payment;

// Tiện ích: tạo hash BCrypt cho mật khẩu (dùng với Database/BaoMat_VoHieuHoaTaiKhoanMau.sql):
//   dotnet run -- --hash "MatKhauMoiManh"
if (args.Length == 2 && args[0] == "--hash")
{
    Console.WriteLine(BCrypt.Net.BCrypt.HashPassword(args[1]));
    return;
}

var builder = WebApplication.CreateBuilder(args);

// MVC (Website: Gian hàng/Quản trị/Tài xế) + API Controllers (Controllers/Api/*, cho FoodApp mobile)
builder.Services.AddControllersWithViews(o => { o.Filters.AddService<FoodServiceApp.Web.Filters.NhatKyThaoTacFilter>(); o.Filters.Add<FoodServiceApp.Web.Filters.TranhChapDuLieuFilter>(); o.Filters.AddService<FoodServiceApp.Web.Filters.NhanVienQuyenFilter>(); });
builder.Services.AddScoped<FoodServiceApp.Web.Filters.NhatKyThaoTacFilter>();
builder.Services.AddScoped<FoodServiceApp.Web.Filters.NhanVienQuyenFilter>();
builder.Services.AddScoped<FoodServiceApp.Web.Services.OtpService>();
builder.Services.AddScoped<FoodServiceApp.Web.Services.TaiKhoanService>();
builder.Services.AddScoped<FoodServiceApp.Web.Services.CauHinhService>();
builder.Services.AddHostedService<FoodServiceApp.Web.Services.Payment.ThanhToanDoiSoatNen>();   // v51: hỏi lại cổng VNPay khi mất phản hồi
builder.Services.AddHostedService<FoodServiceApp.Web.Services.TuDongPhanCongNen>();
builder.Services.AddHostedService<FoodServiceApp.Web.Services.PhanPhoiNen>();   // v86: phân phối đơn cho tài xế (đề nghị có thời hạn, giám sát) — bật/tắt bằng PhanPhoi.TuDong   // tự động phân công tài xế chạy nền (bật bằng cấu hình DieuPhoi.TuDong)
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c => c.SwaggerDoc("v1", new() { Title = "FoodServiceApp API", Version = "v1" }));

// ---------- SQL Server ----------
// Tự tìm SQL Server instance đang chạy trên máy Windows. Ưu tiên instance đã có
// database QuanLyDichVuAnUong; nếu chưa có database thì dùng instance đầu tiên
// đang truy cập được để EF Core có thể tự tạo database. Có thể ghi đè bằng
// ConnectionStrings:DefaultConnection hoặc biến môi trường FOOD_DB_CONNECTION.
var configuredConnection = Environment.GetEnvironmentVariable("FOOD_DB_CONNECTION")
    ?? builder.Configuration.GetConnectionString("DefaultConnection");

var databaseName = "QuanLyDichVuAnUong";
var serverCandidates = builder.Configuration.GetSection("DatabaseServers").GetChildren()
    .Select(x => x.Value)
    .Where(x => !string.IsNullOrWhiteSpace(x))
    .Cast<string>()
    .ToArray();
if (serverCandidates.Length == 0)
{
    serverCandidates = new[] { "(localdb)\\MSSQLLocalDB", ".\\SQLEXPRESS", "localhost" };
}

string? selectedConnection = null;
var reachableServer = new List<string>();

if (!string.IsNullOrWhiteSpace(configuredConnection))
{
    try
    {
        var csb = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder(configuredConnection)
        { ConnectTimeout = 3 };
        using var test = new Microsoft.Data.SqlClient.SqlConnection(csb.ConnectionString);
        test.Open();
        selectedConnection = configuredConnection;
    }
    catch
    {
        // Nếu connection string cũ (ví dụ localhost) không chạy, thử các instance
        // phổ biến bên dưới thay vì làm ứng dụng crash ngay lúc khởi động.
    }
}

if (selectedConnection is null)
{
    foreach (var server in serverCandidates)
    {
        try
        {
            var masterCs = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder
            {
                DataSource = server,
                InitialCatalog = "master",
                IntegratedSecurity = true,
                TrustServerCertificate = true,
                ConnectTimeout = 3
            }.ConnectionString;

            using var test = new Microsoft.Data.SqlClient.SqlConnection(masterCs);
            test.Open();
            reachableServer.Add(server);

            using var cmd = test.CreateCommand();
            cmd.CommandText = "SELECT DB_ID(@db)";
            cmd.Parameters.AddWithValue("@db", databaseName);
            var scalar = cmd.ExecuteScalar();
            var exists = scalar is not null && scalar != DBNull.Value;
            if (exists)
            {
                selectedConnection = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder
                {
                    DataSource = server,
                    InitialCatalog = databaseName,
                    IntegratedSecurity = true,
                    TrustServerCertificate = true,
                    MultipleActiveResultSets = true
                }.ConnectionString;
                break;
            }
        }
        catch
        {
            // Instance không tồn tại/chưa chạy -> thử instance kế tiếp.
        }
    }
}

if (selectedConnection is null && reachableServer.Count > 0)
{
    var server = reachableServer[0];
    selectedConnection = new Microsoft.Data.SqlClient.SqlConnectionStringBuilder
    {
        DataSource = server,
        InitialCatalog = databaseName,
        IntegratedSecurity = true,
        TrustServerCertificate = true,
        MultipleActiveResultSets = true
    }.ConnectionString;
}

selectedConnection ??= configuredConnection
    ?? "Server=(localdb)\\MSSQLLocalDB;Database=QuanLyDichVuAnUong;Trusted_Connection=True;TrustServerCertificate=True;";

builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(selectedConnection));

// ---------- Storage / Maps / Payment ----------
builder.Services.AddSingleton<IFileStorageService, LocalFileStorageService>();

builder.Services.AddHttpContextAccessor();
builder.Services.AddMemoryCache();
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromHours(2);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});
builder.Services.AddScoped<FoodServiceApp.Web.Services.CartService>();

builder.Services.Configure<GoongMapsSettings>(builder.Configuration.GetSection("GoongMaps"));
builder.Services.AddHttpClient<IGoongMapsService, GoongMapsService>();

builder.Services.Configure<VnPaySettings>(builder.Configuration.GetSection("VnPay"));
builder.Services.AddHttpClient<IVnPayService, VnPayService>(c => c.Timeout = TimeSpan.FromSeconds(30));

// ---------- Xác thực: Cookie (Website, mặc định) + JWT (API cho mobile) ----------
// Khóa JWT: bắt buộc là bí mật ngẫu nhiên >= 32 ký tự, cấp qua biến môi trường Jwt__Key hoặc `dotnet user-secrets`.
// KHÔNG ghi khóa thật vào appsettings.json / mã nguồn. Môi trường Development không cấu hình thì tự sinh khóa tạm
// (token hiện có mất hiệu lực mỗi lần chạy lại); môi trường khác không cấu hình thì ứng dụng từ chối khởi động.
var jwtKeyCauHinh = builder.Configuration["Jwt:Key"];
if (string.IsNullOrWhiteSpace(jwtKeyCauHinh) || jwtKeyCauHinh.Length < 32 || jwtKeyCauHinh.StartsWith("DOI_CHUOI_NAY"))
{
    if (!builder.Environment.IsDevelopment())
        throw new InvalidOperationException("Chưa cấu hình Jwt:Key (>= 32 ký tự ngẫu nhiên). Đặt biến môi trường Jwt__Key hoặc dùng secret store. Xem Docs/CAU_HINH_BAO_MAT.md.");
    builder.Configuration["Jwt:Key"] = Convert.ToBase64String(System.Security.Cryptography.RandomNumberGenerator.GetBytes(48));
    Console.WriteLine("[Bảo mật] Jwt:Key chưa cấu hình: đang dùng khóa tạm ngẫu nhiên (chỉ Development). Token cũ sẽ mất hiệu lực khi chạy lại.");
}
var jwtSection = builder.Configuration.GetSection("Jwt");

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Auth/Login";
        options.LogoutPath = "/Auth/Logout";
        options.AccessDeniedPath = "/Auth/Login";
        options.ExpireTimeSpan = TimeSpan.FromHours(8);
        options.Cookie.Name = "FoodServiceApp.Auth";

        // Route /QuanTri/* chưa đăng nhập -> đưa về trang đăng nhập Quản trị,
        // /TaiXe/* -> đưa về trang đăng nhập Tài xế, còn lại -> Gian hàng.
        // Lưu ý: các route /api/* dùng JWT (AuthenticationSchemes chỉ định rõ ở
        // từng controller trong Controllers/Api/), nên KHÔNG rơi vào các sự kiện
        // redirect này — API trả 401 JSON như bình thường khi thiếu/sai token.
        options.Events.OnRedirectToLogin = context =>
        {
            var path = context.Request.Path;
            var target = path.StartsWithSegments("/QuanTri") ? "/AdminAuth/Login"
                       : path.StartsWithSegments("/TaiXe") ? "/DriverAuth/Login"
                       : path.StartsWithSegments("/MuaHang") ? "/MuaHang/Auth/Login"
                       : options.LoginPath;
            context.Response.Redirect($"{target}?ReturnUrl={Uri.EscapeDataString(context.Request.Path)}");
            return Task.CompletedTask;
        };
        options.Events.OnRedirectToAccessDenied = context =>
        {
            var path = context.Request.Path;
            var target = path.StartsWithSegments("/QuanTri") ? "/AdminAuth/Login"
                       : path.StartsWithSegments("/TaiXe") ? "/DriverAuth/Login"
                       : path.StartsWithSegments("/MuaHang") ? "/MuaHang/Auth/Login"
                       : options.LoginPath;
            context.Response.Redirect(target);
            return Task.CompletedTask;
        };

        // Theo dõi phiên đăng nhập: mỗi lần đăng nhập web tạo 1 dòng PhienDangNhap + claim "MaPhien";
        // phiên bị thu hồi ("đăng xuất thiết bị khác") sẽ bị từ chối ở request kế tiếp.
        options.Events.OnSigningIn = async context =>
        {
            try
            {
                if (context.Principal?.Identity is System.Security.Claims.ClaimsIdentity id
                    && int.TryParse(id.FindFirst(System.Security.Claims.ClaimTypes.NameIdentifier)?.Value, out var maTK))
                {
                    var db = context.HttpContext.RequestServices.GetRequiredService<AppDbContext>();
                    var ua = context.HttpContext.Request.Headers.UserAgent.ToString();
                    var phien = new FoodServiceApp.Web.Models.Entities.PhienDangNhap
                    {
                        MaPhien = Guid.NewGuid(),
                        MaTK = maTK,
                        Kenh = "web",
                        ThietBi = ua.Length > 190 ? ua[..190] : ua,
                        DiaChiIP = context.HttpContext.Connection.RemoteIpAddress?.ToString(),
                    };
                    db.PhienDangNhaps.Add(phien);
                    await db.SaveChangesAsync();
                    id.AddClaim(new System.Security.Claims.Claim("MaPhien", phien.MaPhien.ToString()));
                }
            }
            catch { /* không để lỗi ghi phiên chặn đăng nhập */ }
        };
        options.Events.OnValidatePrincipal = async context =>
        {
            var v = context.Principal?.FindFirst("MaPhien")?.Value;
            if (!Guid.TryParse(v, out var maPhien)) return;
            try
            {
                var db = context.HttpContext.RequestServices.GetRequiredService<AppDbContext>();
                var phien = await db.PhienDangNhaps.FirstOrDefaultAsync(p => p.MaPhien == maPhien);
                if (phien != null && phien.ThuHoiLuc != null)
                {
                    context.RejectPrincipal();
                    await context.HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                    return;
                }
                if (phien != null && (DateTime.Now - phien.LanCuoi).TotalMinutes > 5)
                {
                    phien.LanCuoi = DateTime.Now;
                    await db.SaveChangesAsync();
                }
            }
            catch { }
        };
    })
    .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = jwtSection["Issuer"],
            ValidAudience = jwtSection["Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSection["Key"]!)),
        };
        // Quản lý phiên phía máy chủ: tài khoản bị khóa/xóa hoặc phiên bị thu hồi thì token cũ bị từ chối ngay (không chờ hết hạn)
        options.Events = new JwtBearerEvents
        {
            OnTokenValidated = PhienJwt.KiemTraAsync,
            // WebSocket không gửi được header Authorization: SignalR đưa JWT qua ?access_token= (chỉ chấp nhận cho đường dẫn /hubs)
            OnMessageReceived = ctx =>
            {
                var token = ctx.Request.Query["access_token"];
                if (!string.IsNullOrEmpty(token) && ctx.HttpContext.Request.Path.StartsWithSegments("/hubs"))
                    ctx.Token = token;
                return Task.CompletedTask;
            }
        };
    });

builder.Services.AddAuthorization();
builder.Services.AddSignalR();   // thời gian thực: /hubs/don-hang (xem Realtime/DonHangHub.cs)

// v84: chạy sau Nginx/reverse proxy (ReverseProxy__Bat=true): tin X-Forwarded-* để biết đúng https + IP khách (rate limit, nhật ký, HTTPS redirect).
// Chỉ bật khi Kestrel KHÔNG mở ra Internet (chỉ Nginx gọi tới) — xem deploy/nginx-foodapp.conf.
if (builder.Configuration.GetValue<bool>("ReverseProxy:Bat"))
{
    builder.Services.Configure<Microsoft.AspNetCore.Builder.ForwardedHeadersOptions>(o =>
    {
        o.ForwardedHeaders = Microsoft.AspNetCore.HttpOverrides.ForwardedHeaders.XForwardedFor | Microsoft.AspNetCore.HttpOverrides.ForwardedHeaders.XForwardedProto | Microsoft.AspNetCore.HttpOverrides.ForwardedHeaders.XForwardedHost;
        o.KnownNetworks.Clear();
        o.KnownProxies.Clear();
    });
}

// CORS chỉ áp dụng cho trình duyệt (app MAUI gọi API trực tiếp, không bị CORS chặn).
// Cấu hình danh sách origin được phép ở "Cors:AllowedOrigins" (mảng). Để trống: Development mở hết để thử,
// các môi trường khác KHÔNG cho origin nào.
var corsOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>()?.Where(o => !string.IsNullOrWhiteSpace(o)).ToArray() ?? Array.Empty<string>();
builder.Services.AddCors(options =>
{
    options.AddPolicy("MobileApp", policy =>
    {
        if (corsOrigins.Length > 0) policy.WithOrigins(corsOrigins).AllowAnyMethod().AllowAnyHeader();
        else if (builder.Environment.IsDevelopment()) policy.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader();
        // else: không thêm origin nào => trình duyệt từ origin khác bị chặn
    });
});

var app = builder.Build();

if (app.Configuration.GetValue<bool>("ReverseProxy:Bat")) app.UseForwardedHeaders();
// v84: kiểm tra cấu hình theo môi trường (Staging/Production không dùng chung CSDL thử nghiệm, không lộ OTP...)
FoodServiceApp.Web.Services.MoiTruongKiemTra.Chay(app.Configuration, app.Environment,
    Environment.GetEnvironmentVariable("FOOD_DB_CONNECTION") ?? app.Configuration.GetConnectionString("DefaultConnection"));

// Nạp khóa Goong do quản trị nhập trong ứng dụng (nếu có) — ưu tiên hơn appsettings. Lỗi DB thì bỏ qua.
try
{
    using var scopeGoong = app.Services.CreateScope();
    var khoaGoong = scopeGoong.ServiceProvider.GetRequiredService<FoodServiceApp.Web.Services.CauHinhService>()
        .LayChuoiAsync(FoodServiceApp.Web.Services.Maps.GoongKhoa.KhoaCauHinh).GetAwaiter().GetResult();
    FoodServiceApp.Web.Services.Maps.GoongKhoa.DatGhiDe(khoaGoong);
}
catch { }

// Tạo database/schema tự động nếu instance đã chạy nhưng database chưa tồn tại.
// Nếu bạn có file QuanLyDichVuAnUong_Full.sql, vẫn nên chạy file SQL đó để có dữ liệu mẫu.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    IReadOnlyList<string> loiSchema = Array.Empty<string>();
    try
    {
        // EnsureCreated chỉ tạo CSDL MỚI; nó không nâng cấp CSDL đã có -> kiểm tra lệch schema ngay bên dưới.
        db.Database.EnsureCreated();
        loiSchema = FoodServiceApp.Web.Services.KiemTraSchema.KiemTraAsync(db).GetAwaiter().GetResult();
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[Database] Không thể khởi tạo SQL Server: {ex.Message}");
    }

    if (loiSchema.Count > 0)
    {
        Console.WriteLine($"[Database] CẢNH BÁO: CSDL đang dùng KHÔNG khớp mã nguồn ({loiSchema.Count} mục thiếu). Truy vấn liên quan sẽ lỗi lúc chạy.");
        foreach (var m in loiSchema.Take(30)) Console.WriteLine("[Database]   - " + m);
        if (loiSchema.Count > 30) Console.WriteLine($"[Database]   ... và {loiSchema.Count - 30} mục nữa");
        Console.WriteLine("[Database] Cách sửa: SAO LƯU CSDL, rồi chạy Database/FoodService_NangCap.sql (không xóa dữ liệu). TUYỆT ĐỐI không đặt @CHO_PHEP_XOA_DB = 1 trong FoodService_Database.sql trên CSDL có dữ liệu cần giữ.");
        // Muốn dừng hẳn thay vì chỉ cảnh báo (vd. môi trường triển khai): đặt "Database:DungKhiLechSchema": true
        if (app.Configuration.GetValue<bool>("Database:DungKhiLechSchema"))
            throw new InvalidOperationException("Schema CSDL không khớp mã nguồn: " + string.Join("; ", loiSchema.Take(10)));
    }

    // Chuyển tài khoản cũ còn lưu mật khẩu rõ sang BCrypt (chạy một lần, các lần sau không còn gì để chuyển).
    try
    {
        var matKhauRo = db.TaiKhoans.Where(t => t.MatKhau != null && !t.MatKhau.StartsWith("$2")).ToList();
        foreach (var t in matKhauRo) t.MatKhau = MatKhauHelper.Hash(t.MatKhau);
        if (matKhauRo.Count > 0)
        {
            db.SaveChanges();
            Console.WriteLine($"[Bảo mật] Đã chuyển {matKhauRo.Count} tài khoản từ mật khẩu rõ sang BCrypt.");
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"[Bảo mật] Không chuyển được mật khẩu cũ sang BCrypt: {ex.Message}");
    }

    if (!app.Environment.IsDevelopment())
    {
        // Chặn chạy thật khi còn tài khoản mẫu dùng mật khẩu demo công khai (123456 / admin123 trong FoodService_Database.sql).
        // Xử lý: chạy Database/BaoMat_VoHieuHoaTaiKhoanMau.sql. Chỉ khi cố ý (ví dụ máy chấm điểm/demo) mới đặt BaoMat__ChoPhepTaiKhoanMau=true.
        try
        {
            string[] hashMau =
            {
                "$2b$11$mLzNATvh4ekIRUaoX0zQQ.vsKJ5gCrdGNEsQ3YZaAG.GoRnAuRhiu",
                "$2b$11$/kiGvUEE4J218RaDaW8cReCEE3eH53tJBuwpXN5FzQc/BPWr3MHMO",
                "$2b$11$OEARrK8p.cB1O2wFsKq.j.2mAuC/7.MsCfpubv6AXzRqwqG9QDkaS",
                "$2b$11$4W4e54I7Wm8IZICGB5WG5eJicrEVilueK2EWGeKHOeTK/8ZNZnzzW",
            };
            var soMau = db.TaiKhoans.Count(t => t.TrangThai && hashMau.Contains(t.MatKhau));
            if (soMau > 0)
            {
                var msg = $"[Bảo mật] Còn {soMau} tài khoản đang bật với mật khẩu demo công khai (123456/admin123). Chạy Database/BaoMat_VoHieuHoaTaiKhoanMau.sql để khóa/đặt lại, hoặc đặt BaoMat__ChoPhepTaiKhoanMau=true nếu cố ý demo.";
                if (!app.Configuration.GetValue<bool>("BaoMat:ChoPhepTaiKhoanMau")) throw new InvalidOperationException(msg);
                Console.WriteLine(msg + " (đang được cho phép)");
            }
        }
        catch (InvalidOperationException) { throw; }
        catch (Exception ex) { Console.WriteLine($"[Bảo mật] Không kiểm tra được tài khoản mẫu: {ex.Message}"); }

        if (string.IsNullOrWhiteSpace(app.Configuration["Smtp:Host"]))
            Console.WriteLine("[Cấu hình] Chưa cấu hình Smtp:* -> OTP qua email sẽ không gửi được (đặt biến môi trường Smtp__Host, Smtp__User, Smtp__Password, Smtp__From).");
        if (app.Configuration["VnPay:HashSecret"]?.StartsWith("DIEN_") != false)
            Console.WriteLine("[Cấu hình] VnPay:TmnCode/HashSecret chưa điền -> thanh toán VNPay sẽ không hoạt động.");
    }
}

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(); // /swagger — chỉ để test các route /api/*, không ảnh hưởng Website
}
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

// Ghi log lỗi hệ thống (exception chưa được xử lý) vào NhatKyHeThong rồi ném lại cho trình xử lý lỗi chung
app.Use(async (ctx, next) =>
{
    try { await next(); }
    catch (Exception ex)
    {
        try
        {
            using var scope = ctx.RequestServices.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            await FoodServiceApp.Web.Services.NhatKy.GhiAsync(db, ctx, "LoiHeThong", ex.GetType().Name + ": " + ex.Message, null, "Error", 500);
        }
        catch { }
        throw;
    }
});

// v96: chế độ MÁY CHỦ LAN — Web chạy http://0.0.0.0:5000 cho điện thoại/emulator trong cùng mạng gọi vào (chỉ Development).
// Bật bằng chay_may_chu.ps1 hoặc biến môi trường MayChu__ChoPhepLAN=true. Khi bật thì KHÔNG chuyển hướng http -> https
// (app gọi http://IP:5000 sẽ bị chuyển sang https://localhost:5001 và hỏng).
var cheDoMayChuLan = app.Environment.IsDevelopment() && app.Configuration.GetValue<bool>("MayChu:ChoPhepLAN");
if (!cheDoMayChuLan) app.UseHttpsRedirection();

// Tài liệu riêng tư KHÔNG được phục vụ tĩnh: chặn mọi đường dẫn cũ /uploads/giayto|taixe-giayto (kể cả file còn sót trong wwwroot).
app.Use(async (ctx, next) =>
{
    var p = ctx.Request.Path;
    if (p.StartsWithSegments("/uploads/giayto", StringComparison.OrdinalIgnoreCase) || p.StartsWithSegments("/uploads/taixe-giayto", StringComparison.OrdinalIgnoreCase))
    { ctx.Response.StatusCode = StatusCodes.Status404NotFound; return; }
    await next();
});
app.UseStaticFiles();
app.UseRouting();

app.UseSession();

app.UseCors("MobileApp");

app.UseAuthentication();
app.UseAuthorization();

// Giám sát: /health trả 200 nếu ứng dụng + SQL Server còn kết nối được, 503 nếu không
app.MapGet("/health", async (AppDbContext db) =>
{
    try { return await db.Database.CanConnectAsync() ? Results.Ok(new { trangThai = "OK", sql = "OK", moiTruong = app.Environment.EnvironmentName, canhBaoCauHinh = FoodServiceApp.Web.Services.MoiTruongKiemTra.SoCanhBao, thoiGian = DateTime.Now }) : Results.Json(new { trangThai = "LOI", sql = "KhongKetNoi" }, statusCode: 503); }
    catch (Exception ex) { return Results.Json(new { trangThai = "LOI", sql = ex.Message }, statusCode: 503); }
});

// v96: app gọi điểm này để biết máy chủ (Website) đang sống, đúng phiên bản và thấy địa chỉ LAN để nhập vào Cài đặt.
// Ẩn danh; chỉ trả địa chỉ mạng nội bộ khi Development hoặc MayChu:ChoPhepLAN (Production không lộ gì ngoài trạng thái).
app.MapGet("/api/may-chu/thong-tin", async (AppDbContext db) =>
{
    var sqlOk = false;
    try { sqlOk = await db.Database.CanConnectAsync(); } catch { }
    var hienDiaChi = app.Environment.IsDevelopment() || app.Configuration.GetValue<bool>("MayChu:ChoPhepLAN");
    var diaChi = new List<string>();
    if (hienDiaChi)
    {
        try
        {
            foreach (var ni in System.Net.NetworkInformation.NetworkInterface.GetAllNetworkInterfaces()
                         .Where(n => n.OperationalStatus == System.Net.NetworkInformation.OperationalStatus.Up
                                     && n.NetworkInterfaceType != System.Net.NetworkInformation.NetworkInterfaceType.Loopback))
                foreach (var ua in ni.GetIPProperties().UnicastAddresses.Where(u => u.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork))
                    diaChi.Add($"http://{ua.Address}:5000");
        }
        catch { }
    }
    return Results.Ok(new
    {
        tenMayChu = "FoodServiceApp",
        trangThai = sqlOk ? "SanSang" : "SqlKhongKetNoi",
        sql = sqlOk,
        moiTruong = app.Environment.EnvironmentName,
        cheDoLan = cheDoMayChuLan,
        api = "/api/mobile",
        realtime = "/hubs/don-hang",
        diaChiLan = diaChi,
        thoiGian = DateTime.Now
    });
});

app.MapControllers(); // API attribute-routed trong Controllers/Api/*
app.MapHub<FoodServiceApp.Web.Realtime.DonHangHub>("/hubs/don-hang");
FoodServiceApp.Web.Realtime.RealtimeBus.Hub = app.Services.GetRequiredService<Microsoft.AspNetCore.SignalR.IHubContext<FoodServiceApp.Web.Realtime.DonHangHub>>();
// Không đặt default controller/action nữa — nếu không, "/" sẽ vừa khớp route quy
// ước (Dashboard/Index) vừa khớp [HttpGet("/")] của CustomerHomeController, gây
// xung đột AmbiguousMatch. "/" giờ chỉ do CustomerHomeController xử lý (trang chủ
// công khai cho khách hàng); các link nội bộ (asp-controller/asp-action) của
// Gian hàng/Quản trị/Tài xế vẫn hoạt động bình thường vì luôn sinh URL đầy đủ.
app.MapControllerRoute(
    name: "default",
    pattern: "{controller}/{action}/{id?}");

// Chuyển giấy tờ cũ (nếu còn trong wwwroot/uploads) sang kho riêng tư App_Data/private.
FoodServiceApp.Web.Services.FileRiengTuMigration.ChayAsync(app.Services, app.Logger).GetAwaiter().GetResult();

app.Run();
