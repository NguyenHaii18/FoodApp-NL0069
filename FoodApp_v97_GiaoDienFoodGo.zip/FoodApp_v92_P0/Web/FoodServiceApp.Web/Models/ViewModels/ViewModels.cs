using System.ComponentModel.DataAnnotations;
using FoodServiceApp.Web.Models.Entities;

namespace FoodServiceApp.Web.Models.ViewModels
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Vui lòng nhập tên đăng nhập")]
        public string TenDangNhap { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập mật khẩu")]
        [DataType(DataType.Password)]
        public string MatKhau { get; set; } = "";

        public string? LoiThongBao { get; set; }
    }

    public class VendorRegisterViewModel
    {
        [Required(ErrorMessage = "Vui lòng nhập tên cửa hàng")]
        public string TenCuaHang { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập địa chỉ")]
        public string DiaChi { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập số điện thoại")]
        public string SDT { get; set; } = "";

        public string? MoTa { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập tên đăng nhập")]
        public string TenDangNhap { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập mật khẩu")]
        [DataType(DataType.Password)]
        public string MatKhau { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng xác nhận mật khẩu")]
        [DataType(DataType.Password)]
        public string XacNhanMatKhau { get; set; } = "";
    }

    public class DriverRegisterViewModel
    {
        [Required(ErrorMessage = "Vui lòng nhập họ tên")]
        public string HoTen { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập số điện thoại")]
        public string SDT { get; set; } = "";

        public string? PhuongTien { get; set; }
        public string? BienSo { get; set; }
        public string? KhuVucHoatDong { get; set; }
        public string? SoCCCD { get; set; }
        public string? SoGPLX { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập tên đăng nhập")]
        public string TenDangNhap { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập mật khẩu")]
        [DataType(DataType.Password)]
        public string MatKhau { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng xác nhận mật khẩu")]
        [DataType(DataType.Password)]
        public string XacNhanMatKhau { get; set; } = "";
    }

    public class AdminCreateDriverViewModel
    {
        [Required(ErrorMessage = "Vui lòng nhập họ tên")]
        public string HoTen { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập số điện thoại")]
        public string SDT { get; set; } = "";

        public string? PhuongTien { get; set; }
        public string? BienSo { get; set; }
        public string? KhuVucHoatDong { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập tên đăng nhập")]
        public string TenDangNhap { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập mật khẩu")]
        [DataType(DataType.Password)]
        public string MatKhau { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng xác nhận mật khẩu")]
        [DataType(DataType.Password)]
        public string XacNhanMatKhau { get; set; } = "";
    }

    public class DashboardViewModel
    {
        public GianHang GianHang { get; set; } = null!;
        public decimal DoanhThuHomNay { get; set; }
        public int SoDonHomNay { get; set; }
        public int SoDonChoXacNhan { get; set; }
        public int SoMonAn { get; set; }
        public List<DonHang> DonMoiNhat { get; set; } = new();
    }

    public class MonAnFormViewModel
    {
        public int MaMonAn { get; set; }
        public int MaDanhMuc { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập tên món")]
        public string TenMon { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập giá")]
        [Range(0, 100000000, ErrorMessage = "Giá không hợp lệ")]
        public decimal Gia { get; set; }

        public string? MoTa { get; set; }
        public string? HinhAnhHienTai { get; set; }
        public IFormFile? AnhMoi { get; set; }
        public bool NoiBat { get; set; }

        public string? Email { get; set; }
        [RegularExpression(@"^([01]\d|2[0-3]):[0-5]\d$", ErrorMessage = "Giờ mở cửa dạng HH:mm")]
        public string GioMoCua { get; set; } = "00:00";
        [RegularExpression(@"^([01]\d|2[0-3]):[0-5]\d$", ErrorMessage = "Giờ đóng cửa dạng HH:mm")]
        public string GioDongCua { get; set; } = "23:59";
        public bool DangNhanDon { get; set; } = true;
        public string? GiayPhepHienTai { get; set; }
        public string? GiayAttpHienTai { get; set; }
        public IFormFile? GiayPhepMoi { get; set; }
        public IFormFile? GiayAttpMoi { get; set; }
        public bool ConHang { get; set; } = true;
        [Range(0, 100000, ErrorMessage = "Số lượng tồn không hợp lệ")]
        public int? SoLuongTon { get; set; }   // để trống = không giới hạn

        public string TenDanhMucMoi { get; set; } = "";
        public List<DanhMuc> DanhSachDanhMuc { get; set; } = new();
    }

    public class KhuyenMaiFormViewModel
    {
        public int MaKhuyenMai { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập mã khuyến mãi")]
        public string MaCode { get; set; } = "";

        public string? MoTa { get; set; }

        [Required] public string LoaiGiam { get; set; } = "PhanTram"; // PhanTram / SoTien
        public decimal GiaTriGiam { get; set; }
        public string? DieuKienApDung { get; set; }

        // Nâng cao (Quản trị): đơn tối thiểu, giảm tối đa, giới hạn lượt, phạm vi áp dụng
        public string? TenChuongTrinh { get; set; }
        public decimal? GiamToiDa { get; set; }
        public decimal GiaTriDonToiThieu { get; set; }
        public int? SoLuongToiDa { get; set; }
        public bool MoiKhachMotLan { get; set; }
        /// <summary>Danh sách mã (cách nhau dấu phẩy); để trống = không giới hạn.</summary>
        public string? DsGianHang { get; set; }
        public string? DsDanhMuc { get; set; }
        public string? DsMonAn { get; set; }

        [Required] public DateTime NgayBatDau { get; set; } = DateTime.Today;
        [Required] public DateTime NgayKetThuc { get; set; } = DateTime.Today.AddMonths(1);
        public bool TrangThai { get; set; } = true;
    }

    public class HoSoViewModel
    {
        [Required(ErrorMessage = "Vui lòng nhập tên cửa hàng")]
        public string TenCuaHang { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập địa chỉ")]
        public string DiaChi { get; set; } = "";

        [Required(ErrorMessage = "Vui lòng nhập số điện thoại")]
        public string SDT { get; set; } = "";

        public string? MoTa { get; set; }
        public string? HinhAnhHienTai { get; set; }
        public IFormFile? AnhMoi { get; set; }
        public string? AnhBiaHienTai { get; set; }
        public IFormFile? AnhBiaMoi { get; set; }

        [EmailAddress(ErrorMessage = "Email không hợp lệ")]
        public string? Email { get; set; }
        public string GioMoCua { get; set; } = "00:00";
        public string GioDongCua { get; set; } = "23:59";
        public bool DangNhanDon { get; set; } = true;
        public string? GiayPhepHienTai { get; set; }
        public IFormFile? GiayPhepMoi { get; set; }
        public string? GiayAttpHienTai { get; set; }
        public IFormFile? GiayAttpMoi { get; set; }

        public string? MatKhauMoi { get; set; }
        public string? XacNhanMatKhauMoi { get; set; }
    }

    public class DoanhThuViewModel
    {
        public decimal TongDoanhThu30Ngay { get; set; }
        public int TongDonHoanThanh30Ngay { get; set; }
        public List<(DateTime Ngay, decimal DoanhThu)> DoanhThuTheoNgay { get; set; } = new();
        public List<(string TenMon, int SoLuongBan)> MonBanChay { get; set; } = new();

        // ---- Báo cáo theo kỳ (ngày / tuần / tháng) ----
        public string Ky { get; set; } = "thang";                 // ngay | tuan | thang
        public string TenKy { get; set; } = "30 ngày gần nhất";
        public decimal TongTienHang { get; set; }                 // doanh thu món = tổng tiền - phí giao
        public decimal PhiGiaoHang { get; set; }
        public decimal TyLeChietKhau { get; set; }                // 0.15 = 15%
        public decimal PhiNenTang { get; set; }                   // tiền hàng x tỷ lệ chiết khấu
        public decimal ThucNhan { get; set; }                     // tiền hàng - phí nền tảng
        public decimal GiaTriTrungBinh { get; set; }              // tổng tiền / số đơn hoàn thành
        public int SoDonHuy { get; set; }
        public int SoYeuCauHoanTien { get; set; }
        public decimal TongHoanTienDaDuyet { get; set; }
    }

    public class DriverThuNhapViewModel
    {
        public decimal HomNay { get; set; }
        public decimal TuanNay { get; set; }
        public decimal ThangNay { get; set; }
        public int DonHomNay { get; set; }
        public int DonTuanNay { get; set; }
        public int DonThangNay { get; set; }
        public decimal TongPhiGiao30Ngay { get; set; }
        public decimal TongThuongPhuCap30Ngay { get; set; }
        public decimal TongTru30Ngay { get; set; }
        public decimal TongThuNhap30Ngay { get; set; }
        public int TongDonGiaoThanhCong30Ngay { get; set; }
        public decimal CodPhaiThuDangGiao { get; set; }       // COD của chuyến đang cầm
        public decimal CodDaThu30Ngay { get; set; }
        public decimal CodCanNop { get; set; }                // COD đã thu, chưa nộp lại cho nền tảng
        public List<FoodServiceApp.Web.Services.DriverDonXuLy.CodChoNopDong> CodChoNop { get; set; } = new();
        public decimal ChoNenTangTra { get; set; }            // thu nhập đã phát sinh nhưng nền tảng chưa trả
        public decimal DaDuocTra { get; set; }
        public List<(DateTime Ngay, decimal ThuNhap)> ThuNhapTheoNgay { get; set; } = new();
        public List<DongThuNhap> GiaoDich { get; set; } = new();
    }

    public class DongThuNhap
    {
        public DateTime ThoiGian { get; set; }
        public string Loai { get; set; } = "";      // PhiGiao | PhiGiaoThatBai | Thuong | PhuCap | Phat | DieuChinh
        public int? MaDonHang { get; set; }
        public decimal SoTien { get; set; }
        public string? GhiChu { get; set; }
        public string TrangThai { get; set; } = "ChoThanhToan";
        public decimal? CodThu { get; set; }
    }

    public class DriverLichSuViewModel
    {
        public List<GiaoHang> Danh { get; set; } = new();
        public DateTime? Tu { get; set; }
        public DateTime? Den { get; set; }
        public string? TrangThai { get; set; }
        public int ThanhCong { get; set; }
        public int ThatBai { get; set; }
        public double TiLeHoanThanh { get; set; }
        public double? PhutGiaoTrungBinh { get; set; }
        public double? SaoGiaoHangTB { get; set; }
        public int SoDanhGia { get; set; }
        public int SoSuCo { get; set; }
        public Dictionary<int, int?> SaoTheoDon { get; set; } = new();
        public List<(int MaDon, string Loai, string NoiDung, DateTime Ngay)> PhanHoi { get; set; } = new();
    }
}
