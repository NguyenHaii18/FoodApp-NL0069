using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FoodServiceApp.Web.Models.Entities
{
    [Table("TaiKhoan")]
    public class TaiKhoan
    {
        [Key] public int MaTK { get; set; }
        public string TenDangNhap { get; set; } = "";
        public string MatKhau { get; set; } = "";
        public string VaiTro { get; set; } = ""; // KhachHang / GianHang / QuanTri / TaiXe
        public DateTime NgayTao { get; set; } = DateTime.Now;
        public bool TrangThai { get; set; } = true;
        public int SoLanDangNhapSai { get; set; }
        public DateTime? KhoaDen { get; set; }
        public DateTime? LanDangNhapCuoi { get; set; }
        public bool EmailDaXacThuc { get; set; }
        public bool SdtDaXacThuc { get; set; }
        public DateTime? DongYDieuKhoanLuc { get; set; }
        public DateTime? PhienHopLeTu { get; set; }          // UTC: token JWT cấp TRƯỚC thời điểm này bị thu hồi (đổi mật khẩu, đăng xuất mọi thiết bị)
    }

    [Table("GianHang")]
    public class GianHang
    {
        /// <summary>v80: số đơn đang chế biến tối đa cùng lúc (giờ cao điểm); 0 = không giới hạn.</summary>
        public int ToiDaDonDong { get; set; } = 0;
        public string? YeuCauBoSung { get; set; }
        [Key] public int MaGianHang { get; set; }
        public int MaTK { get; set; }
        public TaiKhoan? TaiKhoan { get; set; }
        public string TenCuaHang { get; set; } = "";
        public string DiaChi { get; set; } = "";
        public string SDT { get; set; } = "";
        public string? MoTa { get; set; }
        public string? HinhAnh { get; set; }
        public string? Email { get; set; }
        public string? AnhBia { get; set; }            // ảnh bìa trang quán (HinhAnh = logo/ảnh đại diện)
        public string? GiayPhepKinhDoanh { get; set; } // đường dẫn ảnh/tệp giấy phép KD
        public string? GiayChungNhanATTP { get; set; } // đường dẫn giấy chứng nhận ATTP
        public string? LyDoTuChoi { get; set; }        // lý do Quản trị từ chối hồ sơ
        public string TrangThaiKinhDoanh { get; set; } = "DangMo"; // DangMo / DongCua / TamNgung
        public string TrangThaiDuyet { get; set; } = "ChoDuyet"; // ChoDuyet / DaDuyet / TuChoi
        public DateTime NgayDangKy { get; set; } = DateTime.Now;
        // Bổ sung Đối tác (SQL/04_BoSung_DoiTac.sql)
        public TimeSpan GioMoCua { get; set; } = TimeSpan.Zero;                          // 00:00–23:59 = hoạt động cả ngày
        public TimeSpan GioDongCua { get; set; } = new TimeSpan(23, 59, 0);
        public bool DangNhanDon { get; set; } = true;                                    // tạm dừng nhận đơn nhưng vẫn mở cửa
        public decimal TyLeChietKhau { get; set; } = 0.15m;                              // phí nền tảng (NV09), 0.15 = 15%
        /// <summary>Toạ độ gian hàng (v18) — tự geocode từ địa chỉ khi cần lọc/sắp xếp theo khoảng cách; null = chưa xác định.</summary>
        public double? ViDo { get; set; }
        public double? KinhDo { get; set; }
        /// <summary>Cách giao mặc định cho đơn mới (v31): "Ngoai" = shipper ngoài (nền tảng) | "Quan" = tài xế của quán. Quán vẫn đổi được từng đơn.</summary>
        public string CheDoGiao { get; set; } = "Ngoai";

        public ICollection<DanhMuc> DanhMucs { get; set; } = new List<DanhMuc>();
        public ICollection<DonHang> DonHangs { get; set; } = new List<DonHang>();
        public ICollection<KhuyenMai> KhuyenMais { get; set; } = new List<KhuyenMai>();
    }

    [Table("ChienDichQuangCao")]
    public class ChienDichQuangCao
    {
        [Key] public int MaChienDich { get; set; }
        public int MaGianHang { get; set; }
        public GianHang? GianHang { get; set; }
        public string TenChienDich { get; set; } = "";
        public string LoaiViTri { get; set; } = "NoiBat";
        public string TieuDe { get; set; } = "";
        public string? NoiDung { get; set; }
        public string? HinhAnh { get; set; }
        public DateTime NgayBatDau { get; set; }
        public DateTime NgayKetThuc { get; set; }
        public decimal NganSach { get; set; }
        public string TrangThai { get; set; } = "BanNhap";
        public int LuotHienThi { get; set; }
        public int LuotTuongTac { get; set; }
        public DateTime NgayTao { get; set; } = DateTime.Now;
    }

    [Table("QuanTri")]
    public class QuanTri
    {
        [Key] public int MaQuanTri { get; set; }
        public int MaTK { get; set; }
        public string HoTen { get; set; } = "";
        public string SDT { get; set; } = "";
        public string? Email { get; set; }
        public string CapQuyenHan { get; set; } = "NhanVien";
        public string? PhongBanPhuTrach { get; set; }
        /// <summary>Quyền chi tiết theo chức năng, cách nhau dấu phẩy. Null = dùng mặc định theo CapQuyenHan.</summary>
        public string? QuyenChiTiet { get; set; }
    }

    [Table("KhachHang")]
    public class KhachHang
    {
        [Key] public int MaKH { get; set; }
        public int MaTK { get; set; }
        public TaiKhoan? TaiKhoan { get; set; }
        public string HoTen { get; set; } = "";
        public string SDT { get; set; } = "";
        public string? Email { get; set; }
        public string? DiaChiGiaoHang { get; set; }
        public string? AnhDaiDien { get; set; }

        public bool NhanTbDonHang { get; set; } = true;
        public bool NhanTbThanhToan { get; set; } = true;
        public bool NhanTbKhuyenMai { get; set; } = true;
    }

    [Table("TaiXe")]
    public class TaiXe
    {
        public string? YeuCauBoSung { get; set; }
        [Key] public int MaTaiXe { get; set; }
        public int MaTK { get; set; }
        public string HoTen { get; set; } = "";
        public string SDT { get; set; } = "";
        public string? PhuongTien { get; set; }
        public string? BienSo { get; set; }
        public string? KhuVucHoatDong { get; set; }
        public string TrangThai { get; set; } = "SanSang";
        public string TrangThaiDuyet { get; set; } = "DaDuyet"; // ChoDuyet / DaDuyet / TuChoi
        public DateTime NgayDangKy { get; set; } = DateTime.Now;
        public string? SoCCCD { get; set; }
        public string? SoGPLX { get; set; }
        public string? AnhGPLX { get; set; }
        public string? LyDoTuChoi { get; set; }
        public string? AnhDaiDien { get; set; }
        /// <summary>null = shipper ngoài (nền tảng); có giá trị = tài xế nội bộ của gian hàng đó (v31).</summary>
        public int? MaGianHang { get; set; }

        // ---- v86: nhịp kết nối + vị trí gần nhất của tài xế (phân phối đơn tự động) ----
        public double? ViDo { get; set; }                       // vị trí gần nhất tài xế gửi lên (kể cả khi đang rảnh)
        public double? KinhDo { get; set; }
        public DateTime? ViTriLuc { get; set; }                 // lúc nhận được vị trí GPS hợp lệ
        public DateTime? NhipLuc { get; set; }                  // lần cuối app tài xế báo "còn kết nối" (heartbeat)
        public int SoLanKhongPhanHoi { get; set; }              // số đề nghị liên tiếp bỏ qua (reset khi nhận/từ chối)
        public int SoLanHuySauNhan { get; set; }                // tổng số lần hủy sau khi đã nhận đơn
        public DateTime? TamKhoaNhanDenLuc { get; set; }        // tạm ngừng đề nghị tự động tới lúc này (do bỏ lỡ nhiều lần)

        public ICollection<GiaoHang> GiaoHangs { get; set; } = new List<GiaoHang>();
    }

    [Table("DanhMuc")]
    public class DanhMuc
    {
        [Key] public int MaDanhMuc { get; set; }
        public int MaGianHang { get; set; }
        public GianHang? GianHang { get; set; }
        public string TenDanhMuc { get; set; } = "";
        public bool DaAn { get; set; }                     // ẩn danh mục khỏi khách (v18)

        public ICollection<MonAn> MonAns { get; set; } = new List<MonAn>();
    }

    [Table("MonAn")]
    public class MonAn
    {
        /// <summary>v80: thời gian chuẩn bị món (phút), khung giờ bán và món ăn kèm — quán chỉnh trong Vận hành.</summary>
        public int? ThoiGianChuanBiPhut { get; set; }
        public TimeSpan? BanTuGio { get; set; }
        public TimeSpan? BanDenGio { get; set; }
        public string? MonAnKem { get; set; }
        public string? LyDoAn { get; set; }
        [Key] public int MaMonAn { get; set; }
        public int MaDanhMuc { get; set; }
        public DanhMuc? DanhMuc { get; set; }
        public string TenMon { get; set; } = "";
        public decimal Gia { get; set; }
        public string? MoTa { get; set; }
        public string? HinhAnh { get; set; }
        public string TinhTrang { get; set; } = "ConHang"; // ConHang / HetHang / TamNgung
        public bool NoiBat { get; set; }                   // quán tự đánh dấu món nổi bật (hiện đầu mục "Nổi bật" ở trang quán)
        public decimal GiaVon { get; set; }                // giá vốn/phần, dùng tính lợi nhuận (0 = chưa nhập)
        public bool ChoGhiChu { get; set; } = true;
        /// <summary>v95: số phần còn lại (null = không giới hạn). Token đồng thời: hai đơn cùng lúc không thể cùng lấy phần cuối.</summary>
        [System.ComponentModel.DataAnnotations.ConcurrencyCheck] public int? SoLuongTon { get; set; }
    }

    [Table("DonHang")]
    public class DonHang
    {
        /// <summary>v51: token đồng thời (rowversion). Hai người cùng sửa một đơn (quán xác nhận vs khách hủy, hai quản trị cùng phân công…) → người ghi sau bị từ chối thay vì ghi đè âm thầm.</summary>
        [System.ComponentModel.DataAnnotations.Timestamp] public byte[]? RowVer { get; set; }
        public decimal TienGiam { get; set; }
        [Key] public int MaDonHang { get; set; }
        public int MaKH { get; set; }
        public KhachHang? KhachHang { get; set; }
        public int MaGianHang { get; set; }
        public GianHang? GianHang { get; set; }
        public int? MaTaiXe { get; set; }
        public DateTime NgayDat { get; set; } = DateTime.Now;
        // ChoXacNhan / DaXacNhan / DangGiao / DaGiao / DaHuy
        public string TrangThai { get; set; } = "ChoXacNhan";
        public decimal TongTien { get; set; }
        /// <summary>Phí giao hàng (tính theo khoảng cách qua Goong Maps, xem CustomerCartController) — toàn bộ khoản này là thu nhập của tài xế khi giao thành công.</summary>
        public decimal PhiGiaoHang { get; set; } = 0;
        /// <summary>v83: tỉ lệ phí giao tài xế nhận, chốt lúc đặt đơn (0..1). NULL = đơn cũ → tài xế nhận 100%. Phần còn lại là của ứng dụng.</summary>
        public decimal? TyLeTaiXe { get; set; }
        public string DiaChiGiaoHang { get; set; } = "";
        public string? GhiChu { get; set; }
        public int? MaKhuyenMaiApDung { get; set; }
        public KhuyenMai? KhuyenMaiApDung { get; set; }
        public string? MaYeuCauDat { get; set; }           // token chống tạo đơn trùng
        public DateTime? HenGiaoLuc { get; set; }          // v66: đơn đặt theo lịch — giờ khách muốn nhận (null = giao ngay)
        public string? LyDoTuChoi { get; set; }            // gian hàng từ chối / tự hủy quá hạn: bắt buộc có lý do (NV04)
        /// <summary>Mã 4 số khách đọc cho tài xế khi nhận hàng. KHÔNG bao giờ trả cho tài xế/gian hàng.</summary>
        public string? MaXacNhanGiao { get; set; }
        public bool SanSangGiao { get; set; }              // cột SanSangGiao (v8) — đồng bộ với TrangThaiChuanBi, app MAUI đọc cờ này
        public double? KhoangCachKm { get; set; }          // quãng đường ước tính lúc đặt (Goong)
        public int? ThoiGianDuKienPhut { get; set; }
        public int? ThoiGianChuanBiPhut { get; set; }      // quán ước tính thời gian chuẩn bị món khi xác nhận đơn
        public bool NgoaiThanh { get; set; }
        public bool PhiDaDieuChinh { get; set; }           // tài xế điều chỉnh phí giao theo quãng đường thực tế
        public double? KhoangCachThucTeKm { get; set; }
        public string? TrangThaiChuanBi { get; set; }      // null | DangChuanBi | SanSangGiao (quán báo)
        public DateTime? ThoiGianSanSang { get; set; }
        public DateTime? KhachXacNhanLuc { get; set; }     // khách bấm "Đã nhận hàng"
        /// <summary>Nguồn giao (v31): "Ngoai" = shipper ngoài nhận đơn ở hàng chờ | "Quan" = tài xế của quán do quán gán.</summary>
        public string NguonGiao { get; set; } = "Ngoai";
        public int SoLanSaiMa { get; set; }                // nhập sai quá 5 lần -> khóa, cần Quản trị mở
        public DateTime? QuanDaTraLuc { get; set; }        // v47f: quản trị đã chuyển phần tiền hàng (sau phí nền tảng) cho quán; null = chưa trả

        public ICollection<ChiTietDonHang> ChiTiets { get; set; } = new List<ChiTietDonHang>();
        public ThanhToan? ThanhToan { get; set; }
        public GiaoHang? GiaoHang { get; set; }
    }

    [Table("ChiTietDonHang")]
    public class ChiTietDonHang
    {
        [Key] public int MaCTDH { get; set; }
        public int MaDonHang { get; set; }
        public int MaMonAn { get; set; }
        public MonAn? MonAn { get; set; }
        public int SoLuong { get; set; }
        public decimal DonGia { get; set; }
        public string? GhiChu { get; set; }
        public string? TuyChon { get; set; }      // "Lớn; Trân châu"

        [NotMapped] public decimal ThanhTien => SoLuong * DonGia;
    }

    [Table("ThanhToan")]
    public class ThanhToan
    {
        /// <summary>v51: vnp_CreateDate của lần tạo link thanh toán gần nhất (yyyyMMddHHmmss) — cần để hỏi lại cổng (querydr) khi mất phản hồi.</summary>
        public string? NgayTaoLinkCong { get; set; }
        public bool DaDoiSoat { get; set; }
        public DateTime? NgayDoiSoat { get; set; }
        [Key] public int MaThanhToan { get; set; }
        public int MaDonHang { get; set; }
        public string HinhThuc { get; set; } = "TienMat"; // TienMat / VNPay / Momo
        public string TrangThai { get; set; } = "ChoThanhToan";
        public string? MaGiaoDich { get; set; }
        public DateTime? NgayThanhToan { get; set; }
        // Hoàn tiền qua cổng (v13)
        public string? NgayGiaoDichCong { get; set; }   // vnp_PayDate (yyyyMMddHHmmss) — cần cho API hoàn tiền VNPay
        public string? MaGiaoDichHoan { get; set; }     // mã giao dịch hoàn do cổng trả về (hoặc mã nhập tay)
        public DateTime? NgayHoan { get; set; }
        public string? KetQuaHoan { get; set; }         // thông điệp cổng trả về / ghi chú thủ công
    }

    [Table("KhuyenMai")]
    public class KhuyenMai
    {
        // Cột đã có từ SQL v9 — nay dùng thật
        public string? TenChuongTrinh { get; set; }
        public string LoaiGiam { get; set; } = "PhanTram";   // PhanTram / SoTien / GiamPhiVanChuyen
        public decimal? GiamToiDa { get; set; }
        public decimal GiaTriDonToiThieu { get; set; }
        public int? SoLuongToiDa { get; set; }
        public int SoLuongDaDung { get; set; }
        public bool MoiKhachMotLan { get; set; }
        [Key] public int MaKhuyenMai { get; set; }
        public int? MaGianHang { get; set; } // null = áp dụng toàn hệ thống
        public string MaCode { get; set; } = "";
        public string? MoTa { get; set; }
        public decimal? PhanTramGiam { get; set; }
        public decimal? SoTienGiam { get; set; }
        public string? DieuKienApDung { get; set; }
        public DateTime NgayBatDau { get; set; }
        public DateTime NgayKetThuc { get; set; }
        public bool TrangThai { get; set; } = true;

        [NotMapped] public bool ApDungToanHeThong => MaGianHang == null;
        [NotMapped] public bool ConHan => DateTime.Now <= NgayKetThuc;
        [NotMapped] public bool ChuaBatDau => DateTime.Now < NgayBatDau;
    }

    [Table("DanhGia")]
    public class DanhGia
    {
        public bool DaAn { get; set; }
        public string? LyDoAn { get; set; }
        [Key] public int MaDanhGia { get; set; }
        public int MaKH { get; set; }
        public int MaGianHang { get; set; }
        public int MaDonHang { get; set; }
        public int SoSao { get; set; }
        public int? MaTaiXe { get; set; }                  // tài xế giao đơn này (gắn tự động khi tạo đánh giá)
        public string? NoiDung { get; set; }
        public DateTime NgayDanhGia { get; set; } = DateTime.Now;
        public int? SoSaoGiaoHang { get; set; }
        public int? SoSaoMon { get; set; }                 // điểm riêng cho MÓN ĂN (SoSao = điểm cho QUÁN); null với đánh giá cũ chỉ có một điểm
        public string? TheNhanXet { get; set; }
        public string? AnhDanhGia { get; set; }            // tối đa 3 đường dẫn ảnh (/uploads/danhgia/...) ngăn cách bằng |
        public string? PhanHoi { get; set; }               // gian hàng phản hồi đánh giá
        public DateTime? NgayPhanHoi { get; set; }
    }

    [Table("GiaoHang")]
    public class GiaoHang
    {
        [Key] public int MaGiaoHang { get; set; }
        public int MaDonHang { get; set; }
        public DonHang? DonHang { get; set; }
        public int MaTaiXe { get; set; }
        public TaiXe? TaiXe { get; set; }
        // DaNhan / DangGiao / GiaoThanhCong / GiaoThatBai
        public string TrangThai { get; set; } = "DaNhan";
        public DateTime? ThoiGianNhan { get; set; }
        public DateTime? ThoiGianGiao { get; set; }
        // Bằng chứng giao hàng & giao thất bại (v14)
        public string? AnhBangChung { get; set; }          // ảnh tài xế chụp lúc giao/giao thất bại
        public double? ViDoGiao { get; set; }              // vị trí tài xế lúc bấm hoàn thành/thất bại
        public double? KinhDoGiao { get; set; }
        public string? LyDoThatBai { get; set; }
        public bool TinhPhiThatBai { get; set; }           // lỗi do khách -> tài xế vẫn nhận phí giao
        public string? NguoiGayLoi { get; set; }          // KhachHang | GianHang | TaiXe | Khac
        public decimal? TienThuCOD { get; set; }           // tiền mặt thực thu khi giao thành công
        public DateTime? QuanBanGiaoLuc { get; set; }       // quán bấm "Đã bàn giao cho tài xế"
        public DateTime? ThoiGianDenQuan { get; set; }      // tài xế bấm "Đã đến quán"
        public DateTime? ThoiGianLayHang { get; set; }      // lúc tài xế bấm "Đã lấy hàng"
        public string TrangThaiThuNhap { get; set; } = "ChoThanhToan";   // ChoThanhToan | DaThanhToan (nền tảng đã trả thu nhập cho tài xế)
        public DateTime? NgayThanhToanThuNhap { get; set; }
        public DateTime? CodDaNopLuc { get; set; }          // quản trị xác nhận đã nhận tiền COD tài xế nộp lại (null = chưa nộp)
    }

    /// <summary>Vị trí mới nhất của tài xế theo đơn (lưu bền để không mất khi server khởi động lại).</summary>
    [Table("TaiXeViTri")]
    public class TaiXeViTri
    {
        [Key] public int MaDonHang { get; set; }
        public int MaTaiXe { get; set; }
        public double ViDo { get; set; }
        public double KinhDo { get; set; }
        public DateTime CapNhatLuc { get; set; } = DateTime.Now;
    }

    /// <summary>Tài xế từ chối một đơn chờ nhận: đơn không còn hiện cho tài xế đó (xóa khi đơn quá hạn để điều phối lại).</summary>
    /// <summary>
    /// v86 — Đề nghị giao đơn: hệ thống đề nghị một đơn cho MỘT tài xế trong thời hạn ngắn; tài xế Nhận / Từ chối / để hết hạn.
    /// Chỉ có tối đa 1 đề nghị "ChoPhanHoi" cho mỗi đơn và cho mỗi tài xế (chỉ mục duy nhất có điều kiện trong SQL).
    /// </summary>
    [Table("DeNghiGiaoDon")]
    public class DeNghiGiaoDon
    {
        [Key] public long MaDeNghi { get; set; }
        public int MaDonHang { get; set; }
        public int MaTaiXe { get; set; }
        public int Vong { get; set; } = 1;                              // lượt tìm (mở rộng bán kính dần)
        [MaxLength(20)] public string TrangThai { get; set; } = "ChoPhanHoi";   // ChoPhanHoi | DaNhan | TuChoi | HetHan | Huy
        public double Diem { get; set; }
        public double? KmDenQuan { get; set; }
        [MaxLength(400)] public string? LyDoChon { get; set; }
        [MaxLength(200)] public string? LyDoPhanHoi { get; set; }
        public DateTime TaoLuc { get; set; } = DateTime.Now;
        public DateTime HetHanLuc { get; set; }
        public DateTime? PhanHoiLuc { get; set; }
    }

    [Table("TaiXeTuChoiDon")]
    public class TaiXeTuChoiDon
    {
        [Key] public int MaTuChoi { get; set; }
        public int MaDonHang { get; set; }
        public int MaTaiXe { get; set; }
        public string? LyDo { get; set; }
        public DateTime ThoiGian { get; set; } = DateTime.Now;
    }

    [Table("DanhGiaMon")]
    public class DanhGiaMon
    {
        [Key] public int MaDanhGiaMon { get; set; }
        public int MaKH { get; set; }
        public int MaMonAn { get; set; }
        public MonAn? MonAn { get; set; }
        public int MaDonHang { get; set; }
        public int SoSao { get; set; }
        public string? NoiDung { get; set; }
        public DateTime NgayDanhGia { get; set; } = DateTime.Now;
    }

    [Table("DiaChiKhachHang")]
    public class DiaChiKhachHang
    {
        [Key] public int MaDiaChi { get; set; }
        public int MaKH { get; set; }
        public string Nhan { get; set; } = "Nhà"; // Nhà / Cơ quan / ...
        public string DiaChi { get; set; } = "";
        public bool MacDinh { get; set; }
        public string? Tinh { get; set; }
        public string? Quan { get; set; }
        public string? Phuong { get; set; }
        public string? HuongDan { get; set; }
        public decimal? Lat { get; set; }
        public decimal? Lng { get; set; }
    }

    [Table("PhanHoi")]
    public class PhanHoi
    {
        public int? MaTKPhuTrach { get; set; }
        public string? YeuCauBoSung { get; set; }
        public string? PhanLoai { get; set; }
        [Key] public int MaPhanHoi { get; set; }
        public int MaKH { get; set; }
        public KhachHang? KhachHang { get; set; }
        public int? MaDonHang { get; set; }
        public int? MaGianHang { get; set; }
        public string Loai { get; set; } = "GopY"; // GopY / KhieuNai / Khac
        public string TieuDe { get; set; } = "";
        public string NoiDung { get; set; } = "";
        public string TrangThai { get; set; } = "ChuaXuLy"; // ChuaXuLy / DaXuLy
        public string? TraLoi { get; set; }
        public DateTime NgayGui { get; set; } = DateTime.Now;
        public DateTime? NgayXuLy { get; set; }
    }

}
