using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FoodServiceApp.Web.Models.Entities
{
    /// <summary>Banner / chiến dịch quảng cáo do quản trị tạo; hiển thị ở trang chủ khách (web) và qua API cho app.</summary>
    [Table("Banner")]
    public class Banner
    {
        [Key] public int MaBanner { get; set; }
        [Required, MaxLength(150)] public string TieuDe { get; set; } = "";
        [MaxLength(300)] public string HinhAnh { get; set; } = "";
        [MaxLength(300)] public string? LienKet { get; set; }          // đường dẫn khi bấm vào (tùy chọn)
        public int ThuTu { get; set; }                                   // nhỏ hiện trước
        public DateTime? NgayBatDau { get; set; }
        public DateTime? NgayKetThuc { get; set; }
        public bool TrangThai { get; set; } = true;
        public DateTime NgayTao { get; set; } = DateTime.Now;
        public int? MaTKTao { get; set; }
    }
}
