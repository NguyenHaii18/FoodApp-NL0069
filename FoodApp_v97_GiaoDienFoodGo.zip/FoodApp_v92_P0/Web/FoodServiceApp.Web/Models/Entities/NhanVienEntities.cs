using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FoodServiceApp.Web.Models.Entities
{
    /// <summary>
    /// Tài khoản nhân viên của một gian hàng. Chủ quán tạo; nhân viên đăng nhập bằng tên đăng nhập riêng
    /// (POST api/mobile/gian-hang/nhan-vien/dang-nhap) và chỉ làm được những việc nằm trong <see cref="Quyen"/>.
    /// </summary>
    [Table("NhanVienGianHang")]
    public class NhanVienGianHang
    {
        [Key] public int MaNV { get; set; }
        public int MaGianHang { get; set; }
        [MaxLength(50)] public string TenDangNhap { get; set; } = "";
        [MaxLength(100)] public string HoTen { get; set; } = "";
        [MaxLength(200)] public string MatKhau { get; set; } = "";       // hash BCrypt
        /// <summary>Danh sách quyền, ngăn cách bằng dấu phẩy: DonHang,ThucDon,KhuyenMai,DanhGia,TaiChinh.</summary>
        [MaxLength(200)] public string Quyen { get; set; } = "DonHang";
        public bool TrangThai { get; set; } = true;                      // false = đã khóa
        public DateTime NgayTao { get; set; } = DateTime.Now;
        public DateTime? LanDangNhapCuoi { get; set; }
    }
}
