using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FoodServiceApp.Web.Models.Entities
{
    /// <summary>Câu hỏi thường gặp do quản trị biên tập (v47f); hiển thị ở Trung tâm hỗ trợ của khách (web + app).</summary>
    [Table("CauHoiThuongGap")]
    public class CauHoiThuongGap
    {
        [Key] public int MaCauHoi { get; set; }
        [Required, MaxLength(300)] public string CauHoi { get; set; } = "";
        [Required, MaxLength(2000)] public string TraLoi { get; set; } = "";
        public int ThuTu { get; set; }
        public bool TrangThai { get; set; } = true;
        public DateTime NgayTao { get; set; } = DateTime.Now;
        public int? MaTKTao { get; set; }
    }
}
