/* admin.js — hành vi giao diện Quản trị: nhóm menu, dropdown, tùy chỉnh thẻ chức năng. */
(function () {
  'use strict';

  /* Nhóm menu bên trái: bấm để mở/đóng */
  document.querySelectorAll('[data-nav-toggle]').forEach(function (b) {
    b.addEventListener('click', function () {
      var sub = document.getElementById('nav-' + b.getAttribute('data-nav-toggle'));
      if (!sub) return;
      var open = sub.classList.toggle('open');
      b.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  });

  /* Dropdown chuông thông báo + menu người dùng */
  var dds = document.querySelectorAll('[data-dd]');
  function closeAll(except) { dds.forEach(function (d) { if (d !== except) d.classList.remove('open'); }); }
  dds.forEach(function (d) {
    var t = d.querySelector('[data-dd-toggle]');
    if (t) t.addEventListener('click', function (e) { e.stopPropagation(); closeAll(d); d.classList.toggle('open'); });
  });
  document.addEventListener('click', function (e) { if (!e.target.closest('[data-dd]')) closeAll(null); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeAll(null); });

  /* Dashboard: "Tùy chỉnh" — ẩn/hiện thẻ chức năng, nhớ trên trình duyệt này */
  var btn = document.getElementById('btnCustomize'), panel = document.getElementById('custPanel');
  var KEY = 'adm.tiles.hidden';
  function load() { try { return JSON.parse(localStorage.getItem(KEY) || '[]'); } catch (e) { return []; } }
  function save(v) { try { localStorage.setItem(KEY, JSON.stringify(v)); } catch (e) { /* bỏ qua */ } }
  function apply() {
    var hidden = load();
    document.querySelectorAll('.tile[data-tile]').forEach(function (t) { t.hidden = hidden.indexOf(t.getAttribute('data-tile')) >= 0; });
    document.querySelectorAll('#custPanel input[data-tile-cb]').forEach(function (c) { c.checked = hidden.indexOf(c.getAttribute('data-tile-cb')) < 0; });
  }
  if (btn && panel) {
    btn.addEventListener('click', function () { panel.classList.toggle('open'); });
    panel.addEventListener('change', function (e) {
      var c = e.target; if (!c.matches('input[data-tile-cb]')) return;
      var key = c.getAttribute('data-tile-cb'), hidden = load().filter(function (k) { return k !== key; });
      if (!c.checked) hidden.push(key);
      save(hidden); apply();
    });
    apply();
  }

  /* Nút toàn màn hình trên thanh trên cùng */
  document.querySelectorAll('[data-fullscreen]').forEach(function (b) {
    b.addEventListener('click', function () {
      try {
        if (document.fullscreenElement) document.exitFullscreen();
        else document.documentElement.requestFullscreen();
      } catch (e) { /* trình duyệt không hỗ trợ */ }
    });
  });

  /* Đồng hồ ở banner chào */
  var clk = document.getElementById('admClock');
  if (clk) {
    var tick = function () { var d = new Date(); clk.textContent = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2); };
    tick(); setInterval(tick, 30000);
  }
})();
