/* site.js — hành vi giao diện dùng chung (không phụ thuộc jQuery, không đổi nghiệp vụ). */
(function () {
  'use strict';
  var body = document.body;

  /* 1. Menu trượt trên điện thoại (Gian hàng / Quản trị / Tài xế) */
  function setDrawer(open) {
    body.classList.toggle('drawer-open', open);
    document.querySelectorAll('[data-drawer-toggle]').forEach(function (b) { b.setAttribute('aria-expanded', open ? 'true' : 'false'); });
  }
  document.addEventListener('click', function (e) {
    if (e.target.closest('[data-drawer-toggle]')) { setDrawer(!body.classList.contains('drawer-open')); return; }
    if (e.target.closest('[data-drawer-close]')) { setDrawer(false); return; }
    if (body.classList.contains('drawer-open') && e.target.closest('.sidebar a.nav-item')) setDrawer(false);
  });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setDrawer(false); });
  window.addEventListener('resize', function () { if (window.innerWidth > 960) setDrawer(false); });

  /* 2. Bảng rộng tự cuộn ngang thay vì làm vỡ trang trên màn nhỏ */
  document.querySelectorAll('table.data-table').forEach(function (t) {
    if (t.parentElement && t.parentElement.classList.contains('table-wrap')) return;
    var w = document.createElement('div'); w.className = 'table-wrap';
    t.parentNode.insertBefore(w, t); w.appendChild(t);
  });

  /* 3. Chống bấm gửi biểu mẫu 2 lần (đặt hàng, thanh toán...). Form có data-no-lock được bỏ qua. */
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (!(f instanceof HTMLFormElement) || f.hasAttribute('data-no-lock') || e.defaultPrevented) return;
    if (f.dataset.locked === '1') { e.preventDefault(); return; }
    setTimeout(function () {
      if (e.defaultPrevented) return;
      var invalid = window.jQuery && window.jQuery(f).valid && !window.jQuery(f).valid();
      if (invalid) return;
      f.dataset.locked = '1';
      f.querySelectorAll('button[type=submit],input[type=submit]').forEach(function (b) { b.setAttribute('aria-busy', 'true'); });
      setTimeout(function () { f.dataset.locked = '0'; f.querySelectorAll('[aria-busy]').forEach(function (b) { b.removeAttribute('aria-busy'); }); }, 8000);
    }, 0);
  });

  /* 4. Thông báo thành công tự tắt sau 6 giây, có nút đóng */
  document.querySelectorAll('.alert-success, .alert-danger').forEach(function (a) {
    if (a.closest('.card') || a.hasAttribute('data-keep')) return;
    a.setAttribute('role', a.classList.contains('alert-danger') ? 'alert' : 'status');
    a.setAttribute('data-dismiss', '');
    var x = document.createElement('button'); x.type = 'button'; x.className = 'alert-close'; x.setAttribute('aria-label', 'Đóng thông báo'); x.textContent = '×';
    x.addEventListener('click', function () { a.remove(); });
    a.appendChild(x);
    if (a.classList.contains('alert-success')) setTimeout(function () { if (a.isConnected) a.remove(); }, 6000);
  });
})();
