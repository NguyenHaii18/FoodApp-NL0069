# v90 — Bổ sung chức năng Khách hàng còn thiếu (mobile)
CHƯA build/chạy thử (môi trường không có .NET) — chỉ kiểm tra tĩnh (XML, ngoặc, handler). Hãy `dotnet build` rồi thử.

## Đã bổ sung
| Mục yêu cầu | Thay đổi | File chính |
|---|---|---|
| 3. Quán đang khuyến mãi / mới tham gia | 2 chip lọc ở Trang chủ | TrangChuPage, TimKiemService |
| 4. Ảnh không gian, vị trí bản đồ, thời gian chuẩn bị, phạm vi giao, số lượt bán, chính sách quán | Thêm vào trang quán | MenuCartPage, ThongTinQuan, ChinhSachService |
| 5. Món mới | Nhãn "🆕 Món mới" + mục riêng (app tự nhớ lần đầu thấy món, vì CSDL chưa có ngày tạo món) | MonMoiService |
| 6. Sửa tùy chọn món trong giỏ; đơn tối thiểu; phí dịch vụ; kiểm tra giá & tình trạng trước khi đặt | ✏️ trong giỏ; cảnh báo/chặn đơn tối thiểu; dòng "Phí dịch vụ"; so lại giá/hết món/ngoài giờ bán, hỏi khách | PaymentPage, GioHangService |
| 7. Phương thức giao, kiểm tra thông tin đơn | Thẻ "Giao tận nơi"; hộp xác nhận có địa chỉ, giờ, thanh toán, mã giảm | PaymentPage |
| 8. Dùng điểm thưởng | Nút chọn voucher đã đổi điểm (máy chủ xác thực) | PaymentPage |
| 9. Trạng thái đơn chi tiết + thông báo | 9 trạng thái (đang tìm tài xế, đã lấy món…) + toast khi đổi | OrderTrackingPage |
| 10. Báo món lỗi / giao chậm; lịch sử đánh giá | 2 nút ở màn đánh giá; trang mới trong Tài khoản | ReviewPage, LichSuDanhGiaPage |
| 11. Nhận voucher, nhập mã, ưu đãi sinh nhật | Nút Nhận, tab "Của tôi", ô nhập mã, ngày sinh | UuDaiPage, VoucherCuaToiService |
| 12. Báo mất hàng, thanh toán lỗi, liên hệ CSKH | 2 loại mới (gửi bằng loại gần nhất + tiền tố), nút liên hệ | HoTroPage |

## Cần máy chủ hỗ trợ thêm (app đã sẵn trường, thiếu thì dùng mặc định)
- `GET api/mobile/gian-hang`: `anhKhongGian[]`, `donToiThieu`, `banKinhGiaoKm`, `thoiGianChuanBiPhut`, `chinhSach`. Máy chủ phải tự kiểm tra đơn tối thiểu khi đặt.
- `GET api/mobile/chinh-sach`: `phiDichVu` (máy chủ phải tính vào tổng đơn), `hotlineCskh`, `emailCskh`.
- `MatHang` / `ThanhToanLoi` hiện gửi dưới loại `ThieuMon` / `HoanTien` với tiền tố trong nội dung.

## Chưa làm (cần backend, không giả lập)
- Giao "tự đến lấy" (pickup), chat trực tiếp với CSKH, ngày sinh đồng bộ máy chủ (hiện lưu trên máy), voucher sinh nhật tự cấp.

## Gộp vào v89 (Đối tác) mới
- Gộp 3 chiều (v89 cũ → v90 + v89 mới): `Models.cs`, `AppShell.xaml.cs`, `TrangChuPage.xaml(.cs)` gộp tự động không xung đột; các file còn lại lấy nguyên từ hai phía.
- Tích hợp: kiểm tra giỏ trước khi đặt giờ tính cả `TonKho` (món còn ít hơn số lượng chọn sẽ bị báo).
- Vẫn CHƯA build — cần `dotnet build` trên máy.

## Bổ sung: Mức đường / Mức đá (Phần I.5 "Chọn mức đường, đá, cay")
- Thêm 2 loại tùy chọn mới `MucDuong`, `MucDa` (khách chọn 1 trong mỗi nhóm), song song với Size/Topping/MucCay.
- SQL: `Database/FoodService_BoSung_MucDuongDa.sql` (chạy 1 lần trên CSDL cũ, mở rộng CHECK của `TuyChonMon.Loai`); đã sửa CHECK trong `FoodService_Database.sql` và `FoodService_NangCap.sql`.
- Backend: `VendorMobileApiController`, `TuyChonController`, `TuyChonHelper` (Keys + luật chỉ chọn 1 đường/1 đá), `_ChonTuyChon.cshtml`, `TuyChon/Index.cshtml`.
- Mobile: `Models/DoiTac.cs`, `VendorMenuItemEditPage` (đối tác tạo lựa chọn bấm sẵn cho đường/đá). Trang khách hiển thị theo `Loai` nên tự nhận nhóm mới.
- Chưa build/chạy thử.

## Bổ sung Phần IV Tài xế
- Rà soát: hầu hết 8 mục đã có (gọi/nhắn khách, OTP/mã xác nhận giao, báo sai địa chỉ, khách không liên lạc/không có nhà, báo sự cố, thu nhập, chat điều phối...).
- Thêm vào màn Hiệu suất: thẻ "Tỷ lệ hủy / không thành công" và "Tỷ lệ hoàn thành".
- Chưa làm: "Tỷ lệ nhận đơn" (cần backend đếm lời mời bị từ chối/hết hạn theo tài xế).

## Sửa lỗi biên dịch web
- `Entities.cs`: 7 cột v86 (ViDo, KinhDo, ViTriLuc, NhipLuc, SoLanKhongPhanHoi, SoLanHuySauNhan, TamKhoaNhanDenLuc) nằm nhầm trong `KhachHang` → chuyển sang `TaiXe` (khớp cột SQL bảng TaiXe).
- `DriverDonHangController`, `DriverThuNhapController`: thêm `using FoodServiceApp.Web.Services;` (lỗi `DriverDonXuLy`).
- `Views/DonHang/Index.cshtml`: bỏ `@{ }` lồng trong khối code (lỗi Razor `Unexpected "{" after "@"`).

## Gộp tất cả vào f90 (v89 Đối tác + v90 Khách hàng + v90 Bổ sung + v91 Tài xế)
- Nền: v89 Đối tác mới; gộp v90 Khách hàng; gộp `FoodApp_v90_BoSung` (mức đường/đá, hiệu suất tài xế, sửa lỗi biên dịch web); gộp v91 Tài xế (xem `CHANGELOG_TaiXe_v91.md`).
- Gộp 3 chiều, không xung đột. Bản `34b4cf` trùng hệt v89 mới nên không thêm gì.
- Tương thích: màn "Sửa tùy chọn trong giỏ" xử lý theo `Loai` nên tự nhận nhóm Mức đường / Mức đá.
- Còn chạy SQL `Database/FoodService_BoSung_MucDuongDa.sql` một lần trên CSDL cũ.
- Vẫn CHƯA build — cần `dotnet build` cả Mobile và Web.
## Sửa trang chủ khách (app mobile/desktop): "Quán gần bạn" không bấm được + bố cục
- Nguyên nhân: `OnGianHangTapped` chỉ nhận sender là `Frame`, nhưng ô quán đã đổi sang `Border` → chạm không làm gì. Nay lấy quán từ `TappedEventArgs.Parameter`.
- Thay `CollectionView` ngang lồng trong header (bị cắt chiều cao, nuốt thao tác chạm trên Windows) bằng `ScrollView` ngang + `FlexLayout`/`BindableLayout` (1–2 hàng, chiều cao tính theo số hàng).

## Thanh tab khách hàng đưa xuống dưới (Windows)
- Shell trên Windows đặt tab ở phía trên. Nay ẩn tab gốc trên WinUI (`Shell.TabBarIsVisible` theo OnPlatform) và thêm `Views/CustomerNavBar.cs` (Trang chủ · Đơn hàng · Ưu đãi · Tài khoản) gắn cuối 4 trang; Android/iOS giữ tab dưới gốc.

## Sửa văng khi bấm biểu tượng bản đồ
- `BanDoPage.MoAsync` (mọi nơi mở bản đồ dùng chung) bọc try/catch: lỗi ghi vào `%LOCALAPPDATA%\FoodApp_crash.log`, hiện hộp thoại ngắn và mở Google Maps thay thế thay vì làm sập app.
- `OnBanDoTapped` (trang chủ) bọc try/catch; khởi tạo WebView trong `BanDoPage` bọc try/catch.

## Gộp vào v91 (3 chiều: v90 gốc → v91 + bản bổ sung của tôi)
- Các mục đã có sẵn trong v91 giữ nguyên: mức đường/đá, thẻ tỷ lệ hủy, sửa lỗi biên dịch web (TaiXe/DriverDonXuLy/@{), ô "Quán gần bạn" bấm được, thanh tab dưới Windows.
- Xung đột duy nhất là sửa lỗi nút bản đồ (`BanDoPage.xaml.cs`, `TrangChuPage.OnBanDoTapped`): giữ bản của v91 (kiểm tra WebView + Google Maps dự phòng).
- Gộp tự động `ProfilePage`, `UuDaiPage`, `VendorMenuItemEditPage` (.xaml.cs) cùng các sửa Việt hóa/gõ tiếng Việt của v91.
- Chưa build/chạy thử.

## v92 — Xử lý 10 mục P0 (production) — xem Docs/CAU_HINH_PRODUCTION_P0.md
- Mobile: bản Release ép Production, không nạp dữ liệu mẫu/OTP demo ngoài Development, không rơi về localhost, bỏ cleartext Android (network_security_config), tải GPLX qua `api/upload/giayto-taixe`.
- Web: giấy tờ riêng tư ngoài wwwroot (`PrivateFileController`, liên kết ký 5 phút, tự chuyển file cũ), kiểm tra chữ ký file, SMS OTP qua cổng HTTP cấu hình, kiểm tra cấu hình Production (sa, TrustServerCertificate, khóa mẫu).
- Deploy: tài khoản SQL riêng (`db-init`), volume `private`, sao lưu `private_*.tar.gz`.
- Chưa build/chạy thử.

## Chọn ngày giờ khi tạo khuyến mãi (Đối tác + Quản trị, mobile)
- Trước chỉ chọn ngày. Nay chọn cả GIỜ:PHÚT cho thời điểm bắt đầu và kết thúc (DatePicker + TimePicker), có nút nhanh "Hôm nay / +7 ngày / +30 ngày" và dòng tóm tắt "Hiệu lực ... → ... (n ngày h giờ)", cảnh báo khi kết thúc ≤ bắt đầu.
- Mặc định: bắt đầu = hiện tại, kết thúc = 23:59 sau 1 tháng. Hết hạn hết phút đã chọn (:59 giây).
- Chưa sửa form web (KhuyenMai/_Form.cshtml vẫn chọn theo ngày). Chưa build.

## Sửa ô chọn ngày giờ khi tạo khuyến mãi (Đối tác + Quản trị)
- Thay cặp `DatePicker` + `TimePicker` (TimePicker trên Windows bỏ qua định dạng 24h, hiện AM/PM, hẹp bị cắt) bằng control mới `Views/ChonNgayGio.cs`: ngày (dd/MM/yyyy) + danh sách Giờ 00–23 + danh sách Phút 00–59.
- Áp dụng cho `VendorPromotionEditPage` và `AdminPromotionEditPage`; logic lưu/kiểm tra khoảng thời gian giữ nguyên. Chưa build/chạy thử.

## Sửa lỗi script SQL (Database/)
- `FoodService_BoSung_ThietKe.sql`: lỗi `Invalid column name 'LyDo' / 'ThoiGian'` ở `sp_DongBoPhanCongGiaoHang` — bảng `TaiXeTuChoiDon` (và `DieuPhoiLog`) tạo từ bản cũ thiếu cột. Thêm bước 11.2b bổ sung cột còn thiếu (không xóa dữ liệu) trước khi tạo thủ tục; lỗi kéo theo `Could not find stored procedure 'sp_DongBoPhanCongGiaoHang'` cũng hết.
- `FoodService_Database.sql`: khối v80 (`MonAn`...) và v68 nằm SAU `SET NOEXEC OFF` nên khi CSDL đã tồn tại chúng chạy nhầm vào `master` → loạt lỗi `Cannot find the object "MonAn"`. Đã đưa `SET NOEXEC OFF` xuống cuối file.
- Cả 3 file: mọi `CREATE [UNIQUE] INDEX` (đã có `IF NOT EXISTS` bao ngoài) được bọc `EXEC(N'...')` để SSMS/IntelliSense không báo "index already exists" giả (danh sách 131 lỗi trong Error List). Hành vi chạy không đổi.
- Chưa chạy trên SQL Server (không có trong môi trường soạn).

## Sửa lỗi biên dịch app MAUI (sau khi gộp v92)
- `Views/DriverProfilePage.xaml.cs`: khối "giấy tờ bổ sung v91" (`DuongDan`, `CapNhatGiayToPhu`, `OnGiayToPhuClicked`) bị rơi vào trong lớp `HoSoMayChuDto` → chuyển lại vào `DriverProfilePage`. Hết lỗi LblThanhCong / LblLoi / LblGiayToPhu / HienLoi / CapNhatGiayToPhu / DisplayActionSheet.
- `Views/DriverEarningsPage.xaml.cs`: `OnXuatBaoCaoClicked`, `OnThuongClicked` bị rơi vào lớp `CodDonDto` → chuyển lại vào `DriverEarningsPage`. Hết lỗi `CodDonDto` → `Page` và `SetAppThemeColor`.


## v94 — Bản đồ & phí giao hàng (mục 48–55)
Nguyên tắc: phí ước tính theo quận/huyện (dự phòng) **không dùng làm căn cứ thu tiền cuối**; phí chính thức luôn là số máy chủ tính theo quãng đường thật.

| # | Mục | Đã làm trong app | Còn lại / không thể làm ở đây |
|---|---|---|---|
| 48 | Bản đồ nhúng | Đã có Leaflet/OSM trong WebView (chọn địa chỉ, theo dõi đơn, lộ trình). Bổ sung cảnh báo + nút xử lý khi không có đường (xem 54) | Chưa chạy thử trên máy thật; chưa dùng ô bản đồ Goong |
| 49 | Khóa Goong | Màn hình **Admin → Kiểm thử bản đồ & phí giao** hiện khóa còn placeholder hay đã hợp lệ + nút thử khóa; mọi chỗ báo rõ khi thiếu khóa | **Phải tự nhập khóa Goong thật** (Admin → Khóa bản đồ Goong hoặc `GoongMaps:ApiKey`) |
| 50 | Tìm địa chỉ | `DiaChiToaDoService`: Goong qua máy chủ trước, OpenStreetMap dự phòng, chuẩn hóa thêm "TP.HCM". Trang kiểm thử chạy 10 địa chỉ thật + 1 địa chỉ cố ý sai + địa chỉ tự nhập, so Goong với OSM | Cần chạy trang kiểm thử khi có khóa để có kết quả thật |
| 51 | Quãng đường | `DuongDiService` phân loại lỗi, thử lại 1 lần, luôn kèm số ước tính ghi rõ "đường thẳng"; máy chủ thêm `POST api/map/duong-di` (trước đây app gọi nhưng **máy chủ chưa có**) | — |
| 52 | ETA | ETA = Goong × hệ số giờ; giao diện ghi "ước tính theo giờ, chưa phải kẹt xe trực tiếp" | Không có dữ liệu giao thông thời gian thực (Goong DistanceMatrix không cung cấp) |
| 53 | Phí giao | Thanh toán: hiện nguồn số (`✔ theo quãng đường thật` / `⚠ tạm tính`), hỏi lại máy chủ ngay trước khi đặt, phí đổi → khách phải đồng ý lại; VNPay + phí chưa xác minh → cảnh báo; sau đặt lấy phí/km/phút/tổng theo máy chủ. Danh sách quán ghi "ước tính". Trang kiểm thử so phí ước tính với phí máy chủ từng tuyến và gợi ý chỉnh hệ số | Biểu phí cục bộ (`GiaoHangService`) và biểu phí admin (`PhiGiaoService`) vẫn là 2 bộ số; số cuối cùng là của máy chủ |
| 54 | Lộ trình thay thế | Bản đồ theo dõi: banner lý do + "Tìm lại tuyến" + "Mở Google Maps"; tài xế: nút "🚧 Đường bị chặn / tìm tuyến khác" (tính lại, mở Google Maps, nhắn khách báo trễ, ghi nhật ký) | Goong không có tham số tránh đường nên app không tự vẽ đường vòng |
| 55 | Theo dõi hành trình | Bản đồ khách hiện "vị trí cập nhật X giây trước" và số lần thay đổi/phút; cảnh báo mất GPS (đã có). Trang kiểm thử có quy trình 2 thiết bị | **Phải kiểm thử bằng 2 thiết bị thật** |

Máy chủ (sửa nhỏ để app dùng được):
- `MapController`: thêm `POST api/map/duong-di` và `POST api/map/geocode`.
- `MobileApiController`: `map/phi-giao-hang` trả thêm `daXacMinh`, `nguon`, `ghiChu`, `ngoaiThanh`; tạo đơn trả thêm `daXacMinhTuyen`.

App: mới `Services/PhiGiaoXacMinhService.cs`, `DiaChiToaDoService.cs`, `TuyenThayTheService.cs`, `Views/AdminKiemTraBanDoPage.cs`; sửa `DuongDiService`, `GiaoHangService` (`KetQuaTuyen.DaXacMinh`, `DungKetQuaMayChu`, `KmChimBay`), `PaymentPage`, `TimKiemService`, `TheoDoiBanDoPage`, `DriverDeliveryDetailPage`, `DuLieuService.DatHangDto`, `AppShell`, `AdminPages2`.
**Chưa build/chạy** (không có .NET SDK): chỉ kiểm tra cân bằng ngoặc, XAML hợp lệ, tên khớp. Cần Build lại cả Web và App.
