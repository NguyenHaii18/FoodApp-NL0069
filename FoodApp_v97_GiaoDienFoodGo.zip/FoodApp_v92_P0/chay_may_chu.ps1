# FoodApp — chạy WEBSITE làm MÁY CHỦ cho app (chế độ LAN, dùng khi phát triển / demo)
# Cách dùng (PowerShell, nên Run as Administrator để tự mở tường lửa):  .\chay_may_chu.ps1
# Việc script làm: (1) tìm IP LAN  (2) mở cổng 5000 trên tường lửa  (3) ghi IP vào app (appsettings.json + network_security_config.xml)
#                  (4) chạy Web ở http://0.0.0.0:5000.  Sau khi script ghi IP, BUILD LẠI app MAUI một lần.
param([int]$Port = 5000, [string]$Ip = "")
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$web = Join-Path $root "Web\FoodServiceApp.Web"
$app = Join-Path $root "Mobile_FoodApp.Maui"

if (-not $Ip) {
  $ips = Get-NetIPAddress -AddressFamily IPv4 |
    Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" -and $_.PrefixOrigin -ne "WellKnown" } |
    Select-Object -ExpandProperty IPAddress
  $Ip = ($ips | Where-Object { $_ -like "192.168.*" } | Select-Object -First 1)
  if (-not $Ip) { $Ip = $ips | Select-Object -First 1 }
}
if (-not $Ip) { Write-Host "Không tìm thấy IP mạng. Nối Wi-Fi/LAN hoặc chạy: .\chay_may_chu.ps1 -Ip 192.168.x.x" -ForegroundColor Red; exit 1 }
$url = "http://${Ip}:$Port"

# 1) Tường lửa Windows: cho phép điện thoại trong mạng gọi vào cổng
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if ($isAdmin) {
  if (-not (Get-NetFirewallRule -DisplayName "FoodApp-MayChu-$Port" -ErrorAction SilentlyContinue)) {
    New-NetFirewallRule -DisplayName "FoodApp-MayChu-$Port" -Direction Inbound -Protocol TCP -LocalPort $Port -Action Allow -Profile Private,Domain | Out-Null
    Write-Host "Đã mở tường lửa cổng $Port (mạng Private/Domain)."
  }
} else { Write-Host "Chưa chạy bằng Administrator: nếu điện thoại không vào được, hãy mở cổng $Port trên tường lửa hoặc chạy lại bằng Administrator." -ForegroundColor Yellow }

# 2) Ghi địa chỉ máy chủ vào app
$cfgPath = Join-Path $app "Resources\Raw\appsettings.json"
$cfg = Get-Content $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
$cfg.Api.BaseUrlThietBiThat = $url
$cfg.Api.DungThietBiThat = $true
$cfg | ConvertTo-Json -Depth 5 | Set-Content $cfgPath -Encoding UTF8
$xmlPath = Join-Path $app "Platforms\Android\Resources\xml\network_security_config.xml"
$xml = Get-Content $xmlPath -Raw -Encoding UTF8
if ($xml -notmatch [regex]::Escape(">$Ip<")) {
  $xml = $xml -replace '(<domain includeSubdomains="false">localhost</domain>)', "`$1`r`n        <domain includeSubdomains=`"false`">$Ip</domain>"
  Set-Content $xmlPath $xml -Encoding UTF8
}
Write-Host ""
Write-Host "==== MÁY CHỦ WEBSITE ====" -ForegroundColor Green
Write-Host "Địa chỉ cho app (điện thoại thật):  $url"
Write-Host "Android emulator dùng:              http://10.0.2.2:$Port"
Write-Host "Kiểm tra từ điện thoại (trình duyệt): $url/api/may-chu/thong-tin"
Write-Host "Swagger:                             $url/swagger"
Write-Host "Đã ghi $url vào app. BUILD LẠI app MAUI rồi cài lên điện thoại (cùng Wi-Fi với máy này)." -ForegroundColor Yellow
Write-Host "Lưu ý: VNPay cần địa chỉ công khai (https) để cổng thanh toán gọi lại — dùng tunnel (ngrok/cloudflared) hoặc máy chủ thật." -ForegroundColor Yellow
Write-Host ""

# 3) Chạy Web (Development + chế độ LAN: http, không chuyển sang https)
$env:ASPNETCORE_ENVIRONMENT = "Development"
$env:MayChu__ChoPhepLAN = "true"
dotnet run --project $web --no-launch-profile --urls "http://0.0.0.0:$Port"
