FOODAPP - Mobile (MAUI) + SQL
Mobile_FoodApp.Maui/  : xem CHAY_MOBILE.txt (chay Windows: dotnet run -f net8.0-windows10.0.19041.0)
Database/             : script SQL Server
App chay duoc khong can may chu (ngoai tuyen, du lieu luu tren may). Trang Dashboard quan tri
tu dong tinh so lieu tu du lieu tren may khi khong ket noi duoc API.
Muon noi SQL that: can API /api/mobile, sua BaseUrlWindows trong Resources/Raw/appsettings.json.
