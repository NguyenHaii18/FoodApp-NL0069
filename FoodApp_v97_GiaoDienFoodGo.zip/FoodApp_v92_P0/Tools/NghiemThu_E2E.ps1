﻿<#
  NGHIỆM THU END-TO-END qua API thật (/api/mobile) + kiểm tra dữ liệu trên SQL Server.
  Cách chạy (Web đang chạy, DB đã chạy đủ script tới FoodService_NangCap.sql hoặc FoodService_Database.sql):
     powershell -ExecutionPolicy Bypass -File Tools\NghiemThu_E2E.ps1 -BaseUrl https://localhost:7000 `
        -KhachEmail a@gmail.com -KhachMk <mật khẩu> -GianHang gianhang01 -GianHangMk <mật khẩu> `
        -TaiXeSdt <sdt tài xế đã duyệt> -TaiXeMk <mật khẩu> -AdminEmail quanly@huit.edu.vn -AdminMk <mật khẩu>
  Kịch bản: khách đặt đơn tiền mặt -> quán xác nhận -> chuẩn bị/sẵn sàng -> tài xế nhận -> đến quán -> lấy hàng ->
            hoàn thành bằng mã 4 số của khách -> khách đánh giá -> kiểm tra SQL + quyền quản trị.
  Mỗi bước in PASS/FAIL. Cuối cùng in tổng kết; mã thoát 1 nếu có FAIL.
#>
param(
  [string]$BaseUrl = "https://localhost:7000",
  [string]$KhachEmail = "a@gmail.com", [string]$KhachMk = "123456",
  [string]$GianHang = "gianhang01", [string]$GianHangMk = "123456",
  [string]$TaiXeSdt = "", [string]$TaiXeMk = "123456",
  [string]$AdminEmail = "quanly@huit.edu.vn", [string]$AdminMk = "admin123",
  [string]$SqlServer = "(localdb)\MSSQLLocalDB", [string]$Db = "QuanLyDichVuAnUong"
)
$ErrorActionPreference = "Stop"
if ($PSVersionTable.PSVersion.Major -lt 7) { Add-Type 'using System.Net;using System.Security.Cryptography.X509Certificates;public class TrustAll:ICertificatePolicy{public bool CheckValidationResult(ServicePoint s,X509Certificate c,WebRequest r,int p){return true;}}'; [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAll }
$api = "$BaseUrl/api/mobile"; $script:fail = 0; $script:ids = @{}
function Goi($method, $path, $token, $body) {
  $h = @{}; if ($token) { $h["Authorization"] = "Bearer $token" }
  $p = @{ Method = $method; Uri = "$api/$path"; Headers = $h; ContentType = "application/json" }
  if ($PSVersionTable.PSVersion.Major -ge 7) { $p["SkipCertificateCheck"] = $true }
  if ($body) { $p["Body"] = ($body | ConvertTo-Json -Depth 6) }
  try { return Invoke-RestMethod @p } catch { $m = $_.ErrorDetails.Message; if (-not $m) { $m = $_.Exception.Message }; throw "HTTP lỗi tại $method $path : $m" }
}
function Buoc($ten, [scriptblock]$f) {
  try { $r = & $f; Write-Host ("PASS  " + $ten) -ForegroundColor Green; return $r }
  catch { Write-Host ("FAIL  " + $ten + "  -> " + $_) -ForegroundColor Red; $script:fail++; return $null }
}
function Khang($dk, $msg) { if (-not $dk) { throw $msg } }

$kh = Buoc "Khách đăng nhập" { (Goi POST "khach-hang/dang-nhap" $null @{ email = $KhachEmail; matKhau = $KhachMk }).token }
$gh = Buoc "Gian hàng đăng nhập" { Goi POST "gian-hang/dang-nhap" $null @{ email = $GianHang; matKhau = $GianHangMk } }
$tx = Buoc "Tài xế đăng nhập" { (Goi POST "tai-xe/dang-nhap" $null @{ sdt = $TaiXeSdt; matKhau = $TaiXeMk }).token }
$ad = Buoc "Quản trị đăng nhập" { (Goi POST "admin/dang-nhap" $null @{ email = $AdminEmail; matKhau = $AdminMk }).token }
if (-not ($kh -and $gh -and $tx)) { Write-Host "Thiếu tài khoản đăng nhập - dừng." -ForegroundColor Red; exit 1 }
$ghTok = $gh.token; $ghId = $gh.gianHang.id

$mon = Buoc "Lấy menu gian hàng" {
  $ds = Goi GET "mon-an" $null $null
  $m = $ds | Where-Object { $_.gianHangId -eq $ghId } | Select-Object -First 1
  Khang $m "Gian hàng chưa có món đang bán/đang mở cửa"; $m }
$don = Buoc "Khách đặt đơn (tiền mặt)" {
  $r = Goi POST "don-hang" $kh @{ gianHangId = $ghId; diaChiGiao = "123 Lê Lợi, Q.1, TP.HCM"; ghiChu = "nghiem thu e2e"; hinhThucThanhToan = "TienMat"; maKhuyenMai = $null; chiTiet = @(@{ monAnId = $mon.id; soLuong = 2 }) }
  Khang ($r.maDonHang -gt 0) "Không có mã đơn"; Khang ($r.maXacNhanGiao) "Server không trả mã xác nhận giao"; $r }
if (-not $don) { exit 1 }
$id = $don.maDonHang; $ma = $don.maXacNhanGiao; Write-Host "      Đơn #$id, tổng $($don.tongTien)đ" -ForegroundColor Cyan

Buoc "Quán thấy đơn mới trong danh sách" { $l = Goi GET "gian-hang/$ghId/don-hang" $ghTok $null; Khang ($l | Where-Object { $_.id -eq $id }) "Không thấy đơn" } | Out-Null
Buoc "Tài xế KHÔNG thấy đơn khi quán chưa xác nhận" { $l = Goi GET "tai-xe/don-cho-nhan" $tx $null; Khang (-not ($l | Where-Object { $_.id -eq $id })) "Đơn lộ ra sớm" } | Out-Null
Buoc "Tài xế không nhận được đơn chưa xác nhận" { try { Goi PUT "tai-xe/don-hang/$id/nhan" $tx $null | Out-Null; throw "Đã nhận được!" } catch { if ("$_" -match "Đã nhận được") { throw $_ } } } | Out-Null
Buoc "Quán xác nhận đơn" { Goi PUT "don-hang/$id/xac-nhan" $ghTok $null | Out-Null } | Out-Null
Buoc "Quán báo sẵn sàng giao" { $r = Goi PUT "don-hang/$id/san-sang-giao" $ghTok $null; Khang ($r.trangThaiChuanBi -eq "SanSangGiao") "Chưa SanSangGiao" } | Out-Null
Buoc "Tài xế thấy đơn chờ nhận" { $l = Goi GET "tai-xe/don-cho-nhan" $tx $null; Khang ($l | Where-Object { $_.id -eq $id }) "Không thấy đơn" } | Out-Null
Buoc "Tài xế nhận đơn" { Goi PUT "tai-xe/don-hang/$id/nhan" $tx $null | Out-Null } | Out-Null
Buoc "Nhận lần 2 phải bị từ chối (chống nhận trùng)" { try { Goi PUT "tai-xe/don-hang/$id/nhan" $tx $null | Out-Null; throw "Nhận trùng thành công!" } catch { if ("$_" -match "Nhận trùng") { throw $_ } } } | Out-Null
Buoc "Tài xế báo đã đến quán" { Goi PUT "don-hang/$id/tai-xe-den-quan" $tx $null | Out-Null } | Out-Null
Buoc "Hoàn thành khi chưa lấy hàng bị chặn" { try { Goi PUT "don-hang/$id/hoan-thanh" $tx @{ maXacNhan = $ma } | Out-Null; throw "Hoàn thành được khi chưa lấy hàng!" } catch { if ("$_" -match "Hoàn thành được") { throw $_ } } } | Out-Null
Buoc "Tài xế đã lấy hàng" { Goi PUT "don-hang/$id/da-lay-hang" $tx $null | Out-Null } | Out-Null
Buoc "Tài xế gửi vị trí" { Goi PUT "tai-xe/vi-tri" $tx @{ donHangId = $id; viDo = 10.7769; kinhDo = 106.7009 } | Out-Null } | Out-Null
Buoc "Hoàn thành với mã SAI bị từ chối" { try { Goi PUT "don-hang/$id/hoan-thanh" $tx @{ maXacNhan = "0000x" } | Out-Null; throw "Mã sai vẫn qua!" } catch { if ("$_" -match "Mã sai") { throw $_ } } } | Out-Null
Buoc "Hoàn thành với mã đúng của khách" { $r = Goi PUT "don-hang/$id/hoan-thanh" $tx @{ maXacNhan = $ma; viDo = 10.7769; kinhDo = 106.7009 }; Khang ($r.trangThai -eq "DaGiao") "Trạng thái $($r.trangThai)" } | Out-Null
Buoc "Khách đánh giá đơn" { Goi POST "danh-gia" $kh @{ donHangId = $id; soSaoMonAn = 5; soSaoGiaoHang = 5; noiDung = "nghiem thu e2e" } | Out-Null } | Out-Null
Buoc "Đánh giá lần 2 bị từ chối" { try { Goi POST "danh-gia" $kh @{ donHangId = $id; soSaoMonAn = 4; soSaoGiaoHang = 4; noiDung = "x" } | Out-Null; throw "Đánh giá trùng được!" } catch { if ("$_" -match "Đánh giá trùng") { throw $_ } } } | Out-Null
Buoc "Khách nhận thông báo" { $r = Goi GET "thong-bao" $kh $null; Khang ($r.items.Count -gt 0) "Không có thông báo" } | Out-Null
Buoc "Tài xế thấy chuyến vừa giao trong lịch sử + điểm giao hàng" { $l = Goi GET "tai-xe/don-da-giao" $tx $null; $d = $l | Where-Object { $_.id -eq $id }; Khang $d "Không có trong lịch sử"; Khang ($d.diemTaiXe -eq 5) "diemTaiXe=$($d.diemTaiXe), kỳ vọng 5" } | Out-Null
if ($ad) { Buoc "Quản trị thấy đơn trong thống kê toàn hệ thống" { $l = Goi GET "admin/don-hang" $ad $null; Khang ($l | Where-Object { $_.id -eq $id }) "Không thấy đơn" } | Out-Null }
if ($ad) { Buoc "Quản trị xem được nhật ký" { Goi GET "admin/nhat-ky?trang=1&kichThuoc=20" $ad $null | Out-Null } | Out-Null }
Buoc "Khách không dùng được API tài xế (phân quyền)" { try { Goi GET "tai-xe/don-cho-nhan" $kh $null | Out-Null; throw "Khách gọi được API tài xế!" } catch { if ("$_" -match "Khách gọi được") { throw $_ } } } | Out-Null

# ---- kiểm tra dữ liệu trong SQL Server
$sql = Get-Command sqlcmd -ErrorAction SilentlyContinue
if ($sql) {
  Write-Host "`n=== Kiểm tra SQL Server cho đơn #$id ===" -ForegroundColor Cyan
  $tmp = Join-Path $env:TEMP "nghiemthu_$id.sql"
  (Get-Content (Join-Path $PSScriptRoot "..\Database\FoodService_NghiemThu_SaoLuu.sql") -Raw -Encoding UTF8).Split('@@SAO_LUU_PHUC_HOI@@')[0].Replace('DECLARE @MaDon INT = NULL;', "DECLARE @MaDon INT = $id;") | Set-Content $tmp -Encoding UTF8
  & sqlcmd -S $SqlServer -d $Db -E -b -f 65001 -i $tmp
  if ($LASTEXITCODE -ne 0) { $script:fail++ }
} else { Write-Host "`nKhông có sqlcmd: mở Database\FoodService_NghiemThu_SaoLuu.sql trong SSMS, sửa dòng DECLARE @MaDon = $id và chạy." -ForegroundColor Yellow }

Write-Host ("`nKẾT QUẢ: " + $(if ($script:fail -eq 0) { "TẤT CẢ ĐẠT" } else { "$($script:fail) BƯỚC LỖI" })) -ForegroundColor $(if ($script:fail -eq 0) { "Green" } else { "Red" })
exit $(if ($script:fail -eq 0) { 0 } else { 1 })
